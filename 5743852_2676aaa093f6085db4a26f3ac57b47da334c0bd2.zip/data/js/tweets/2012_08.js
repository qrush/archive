Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/0eHgPyxL",
      "expanded_url" : "http:\/\/instagr.am\/p\/PBGB7rM6vz\/",
      "display_url" : "instagr.am\/p\/PBGB7rM6vz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "241734669433982976",
  "text" : "For Sale http:\/\/t.co\/0eHgPyxL",
  "id" : 241734669433982976,
  "created_at" : "2012-09-01 03:10:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 14, 27 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241701058265612288",
  "text" : "Bringing back @herpderpedia to further expose stupidity on Twitter. Tonight's edition: blue moon is not blue.",
  "id" : 241701058265612288,
  "created_at" : "2012-09-01 00:56:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/Jn2SHGZR",
      "expanded_url" : "http:\/\/instagr.am\/p\/PA0mD_s6hd\/",
      "display_url" : "instagr.am\/p\/PA0mD_s6hd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "241696269536460801",
  "text" : "Incan Gold! http:\/\/t.co\/Jn2SHGZR",
  "id" : 241696269536460801,
  "created_at" : "2012-09-01 00:37:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241675571262795777",
  "text" : "@juliepagano ......",
  "id" : 241675571262795777,
  "created_at" : "2012-08-31 23:15:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    }, {
      "name" : "Marie Williams",
      "screen_name" : "me_williams",
      "indices" : [ 14, 26 ],
      "id_str" : "141453519",
      "id" : 141453519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241628566176034816",
  "geo" : { },
  "id_str" : "241628726994018305",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams @me_williams congrats!!!!",
  "id" : 241628726994018305,
  "in_reply_to_status_id" : 241628566176034816,
  "created_at" : "2012-08-31 20:09:12 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Myles White",
      "screen_name" : "johnmyleswhite",
      "indices" : [ 0, 15 ],
      "id_str" : "15379361",
      "id" : 15379361
    }, {
      "name" : "DataGotham",
      "screen_name" : "datagotham",
      "indices" : [ 16, 27 ],
      "id_str" : "583434310",
      "id" : 583434310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241609819574910977",
  "geo" : { },
  "id_str" : "241610278960250880",
  "in_reply_to_user_id" : 15379361,
  "text" : "@johnmyleswhite @datagotham Agreed. There's a lot of tech user groups in the other major NY cities that would love to hear about this.",
  "id" : 241610278960250880,
  "in_reply_to_status_id" : 241609819574910977,
  "created_at" : "2012-08-31 18:55:54 +0000",
  "in_reply_to_screen_name" : "johnmyleswhite",
  "in_reply_to_user_id_str" : "15379361",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Myles White",
      "screen_name" : "johnmyleswhite",
      "indices" : [ 0, 15 ],
      "id_str" : "15379361",
      "id" : 15379361
    }, {
      "name" : "DataGotham",
      "screen_name" : "datagotham",
      "indices" : [ 16, 27 ],
      "id_str" : "583434310",
      "id" : 583434310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241570707417468929",
  "geo" : { },
  "id_str" : "241608978537254912",
  "in_reply_to_user_id" : 15379361,
  "text" : "@johnmyleswhite @datagotham first i've heard of this in Buffalo. There's more in your \"empire state\" than NYC! :)",
  "id" : 241608978537254912,
  "in_reply_to_status_id" : 241570707417468929,
  "created_at" : "2012-08-31 18:50:44 +0000",
  "in_reply_to_screen_name" : "johnmyleswhite",
  "in_reply_to_user_id_str" : "15379361",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roaming Buffalo",
      "screen_name" : "RoamingBuffalo1",
      "indices" : [ 3, 19 ],
      "id_str" : "195824825",
      "id" : 195824825
    }, {
      "name" : "LevelUp",
      "screen_name" : "TheLevelUp",
      "indices" : [ 60, 71 ],
      "id_str" : "245936814",
      "id" : 245936814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241576409645056000",
  "text" : "RT @RoamingBuffalo1: The Roaming Buffalo is now set up with @thelevelup Download the app and earn customer loyalty points with us! #Buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LevelUp",
        "screen_name" : "TheLevelUp",
        "indices" : [ 39, 50 ],
        "id_str" : "245936814",
        "id" : 245936814
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.8215104668, -78.68061536 ]
    },
    "id_str" : "241576195303563264",
    "text" : "The Roaming Buffalo is now set up with @thelevelup Download the app and earn customer loyalty points with us! #Buffalo",
    "id" : 241576195303563264,
    "created_at" : "2012-08-31 16:40:27 +0000",
    "user" : {
      "name" : "Roaming Buffalo",
      "screen_name" : "RoamingBuffalo1",
      "protected" : false,
      "id_str" : "195824825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2562843964\/image_normal.jpg",
      "id" : 195824825,
      "verified" : false
    }
  },
  "id" : 241576409645056000,
  "created_at" : "2012-08-31 16:41:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 3, 13 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/V7bdLHc3",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/84-million-new-yorkers-suddenly-realize-new-york-c,18003\/",
      "display_url" : "theonion.com\/articles\/84-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241559691715563522",
  "text" : "RT @stevelosh: still the best onion article http:\/\/t.co\/V7bdLHc3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/V7bdLHc3",
        "expanded_url" : "http:\/\/www.theonion.com\/articles\/84-million-new-yorkers-suddenly-realize-new-york-c,18003\/",
        "display_url" : "theonion.com\/articles\/84-mi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241559481249570817",
    "text" : "still the best onion article http:\/\/t.co\/V7bdLHc3",
    "id" : 241559481249570817,
    "created_at" : "2012-08-31 15:34:02 +0000",
    "user" : {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "protected" : false,
      "id_str" : "727813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430207936774696960\/iAyNTOdO_normal.jpeg",
      "id" : 727813,
      "verified" : false
    }
  },
  "id" : 241559691715563522,
  "created_at" : "2012-08-31 15:34:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241557276639502337",
  "geo" : { },
  "id_str" : "241557614545207296",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog awesome! would love some better sound on this one",
  "id" : 241557614545207296,
  "in_reply_to_status_id" : 241557276639502337,
  "created_at" : "2012-08-31 15:26:37 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241556362931363840",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik you're the last person I expected to be part of Svbtle :(",
  "id" : 241556362931363840,
  "created_at" : "2012-08-31 15:21:39 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241542139325067264",
  "geo" : { },
  "id_str" : "241542335924695040",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy this is the best one yet!",
  "id" : 241542335924695040,
  "in_reply_to_status_id" : 241542139325067264,
  "created_at" : "2012-08-31 14:25:55 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 52, 66 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241542306329657344",
  "text" : "RT @kevinpurdy: Every 2 weeks, I audit &amp; reduce @coworkbuffalo's coffee how-to. Right now, it's basically \"Pour ALL the water, over  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 36, 50 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241542139325067264",
    "text" : "Every 2 weeks, I audit &amp; reduce @coworkbuffalo's coffee how-to. Right now, it's basically \"Pour ALL the water, over ALL the beans, slowly.\"",
    "id" : 241542139325067264,
    "created_at" : "2012-08-31 14:25:08 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 241542306329657344,
  "created_at" : "2012-08-31 14:25:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 3, 11 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 46, 60 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/UiLeXoPV",
      "expanded_url" : "http:\/\/facebook.com\/CoworkBuffalo",
      "display_url" : "facebook.com\/CoworkBuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "241374117645930496",
  "text" : "RT @fending: Without anticipation or fanfare, @coworkbuffalo has this FB page http:\/\/t.co\/UiLeXoPV to tweet about.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 33, 47 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/UiLeXoPV",
        "expanded_url" : "http:\/\/facebook.com\/CoworkBuffalo",
        "display_url" : "facebook.com\/CoworkBuffalo"
      } ]
    },
    "geo" : { },
    "id_str" : "241366504187244544",
    "text" : "Without anticipation or fanfare, @coworkbuffalo has this FB page http:\/\/t.co\/UiLeXoPV to tweet about.",
    "id" : 241366504187244544,
    "created_at" : "2012-08-31 02:47:13 +0000",
    "user" : {
      "name" : "fending",
      "screen_name" : "fending",
      "protected" : false,
      "id_str" : "14672651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468101796\/ed9f5bca1aff3f91233b2986acb0fd4e_normal.jpeg",
      "id" : 14672651,
      "verified" : false
    }
  },
  "id" : 241374117645930496,
  "created_at" : "2012-08-31 03:17:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Bird",
      "screen_name" : "7hunderbird",
      "indices" : [ 3, 15 ],
      "id_str" : "14243643",
      "id" : 14243643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/CNUmIgGI",
      "expanded_url" : "http:\/\/www.engineyard.com\/blog\/2012\/engine-yard-and-wnyruby-or-the-little-ruby-group-that-could\/",
      "display_url" : "engineyard.com\/blog\/2012\/engi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241345290291011584",
  "text" : "RT @7hunderbird: Engine Yard and WNYRuby or The Little Ruby Group that Could - Engine Yard Blog | Engine Yard Blog http:\/\/t.co\/CNUmIgGI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/CNUmIgGI",
        "expanded_url" : "http:\/\/www.engineyard.com\/blog\/2012\/engine-yard-and-wnyruby-or-the-little-ruby-group-that-could\/",
        "display_url" : "engineyard.com\/blog\/2012\/engi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241338654033846272",
    "text" : "Engine Yard and WNYRuby or The Little Ruby Group that Could - Engine Yard Blog | Engine Yard Blog http:\/\/t.co\/CNUmIgGI",
    "id" : 241338654033846272,
    "created_at" : "2012-08-31 00:56:33 +0000",
    "user" : {
      "name" : "Tyler Bird",
      "screen_name" : "7hunderbird",
      "protected" : false,
      "id_str" : "14243643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570440680749535232\/FJSCkZEU_normal.png",
      "id" : 14243643,
      "verified" : false
    }
  },
  "id" : 241345290291011584,
  "created_at" : "2012-08-31 01:22:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Tyler Poland",
      "screen_name" : "tylerpoland",
      "indices" : [ 88, 100 ],
      "id_str" : "56105138",
      "id" : 56105138
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 105, 115 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/rLQVvrKs",
      "expanded_url" : "http:\/\/j.mp\/PmWkEZ",
      "display_url" : "j.mp\/PmWkEZ"
    } ]
  },
  "geo" : { },
  "id_str" : "241313044016287746",
  "text" : "RT @wnyruby: REMINDER: next #WNYRuby meetup will be MONDAY 9\/10! http:\/\/t.co\/rLQVvrKs - @tylerpoland and @aquaranto will give talks!  Mo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyler Poland",
        "screen_name" : "tylerpoland",
        "indices" : [ 75, 87 ],
        "id_str" : "56105138",
        "id" : 56105138
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 92, 102 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNYRuby",
        "indices" : [ 15, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/rLQVvrKs",
        "expanded_url" : "http:\/\/j.mp\/PmWkEZ",
        "display_url" : "j.mp\/PmWkEZ"
      } ]
    },
    "geo" : { },
    "id_str" : "241311975836110848",
    "text" : "REMINDER: next #WNYRuby meetup will be MONDAY 9\/10! http:\/\/t.co\/rLQVvrKs - @tylerpoland and @aquaranto will give talks!  More fun to come!!",
    "id" : 241311975836110848,
    "created_at" : "2012-08-30 23:10:33 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 241313044016287746,
  "created_at" : "2012-08-30 23:14:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241250324197801984",
  "text" : "git regret: when you should have committed something 15 minutes ago, and now it doesn't work anymore.",
  "id" : 241250324197801984,
  "created_at" : "2012-08-30 19:05:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "241187047661006848",
  "text" : "DJing in the CoworkBuffalo room. Now playing Gotye Vs Notorious B.I.G. #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 241187047661006848,
  "created_at" : "2012-08-30 14:54:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241022031905320962",
  "geo" : { },
  "id_str" : "241022351473520640",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety oh hai?",
  "id" : 241022351473520640,
  "in_reply_to_status_id" : 241022031905320962,
  "created_at" : "2012-08-30 03:59:41 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240992965651218433",
  "geo" : { },
  "id_str" : "240999353051922433",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub still amazed people play this game",
  "id" : 240999353051922433,
  "in_reply_to_status_id" : 240992965651218433,
  "created_at" : "2012-08-30 02:28:17 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240958897005944832",
  "text" : "Liberty Hound and Blue Monk in one day. BEERSPLOSION!",
  "id" : 240958897005944832,
  "created_at" : "2012-08-29 23:47:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240948793116344320",
  "geo" : { },
  "id_str" : "240950159947726848",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky what about Ninja themed?",
  "id" : 240950159947726848,
  "in_reply_to_status_id" : 240948793116344320,
  "created_at" : "2012-08-29 23:12:49 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marty Haught",
      "screen_name" : "mghaught",
      "indices" : [ 0, 9 ],
      "id_str" : "17875219",
      "id" : 17875219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240946676540526592",
  "geo" : { },
  "id_str" : "240947064689807361",
  "in_reply_to_user_id" : 17875219,
  "text" : "@mghaught I'd specify that it's meant for that community. Feels like it's excluding others right now.",
  "id" : 240947064689807361,
  "in_reply_to_status_id" : 240946676540526592,
  "created_at" : "2012-08-29 23:00:31 +0000",
  "in_reply_to_screen_name" : "mghaught",
  "in_reply_to_user_id_str" : "17875219",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky Mountain Ruby",
      "screen_name" : "rockymtnruby",
      "indices" : [ 0, 13 ],
      "id_str" : "288454983",
      "id" : 288454983
    }, {
      "name" : "Marty Haught",
      "screen_name" : "mghaught",
      "indices" : [ 14, 23 ],
      "id_str" : "17875219",
      "id" : 17875219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240941829565063168",
  "geo" : { },
  "id_str" : "240946369316147201",
  "in_reply_to_user_id" : 288454983,
  "text" : "@rockymtnruby @mghaught cool but this seems only accessible to those who can get to Boulder easily? \"Full\" seems to imply travel.",
  "id" : 240946369316147201,
  "in_reply_to_status_id" : 240941829565063168,
  "created_at" : "2012-08-29 22:57:45 +0000",
  "in_reply_to_screen_name" : "rockymtnruby",
  "in_reply_to_user_id_str" : "288454983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit.txt",
      "screen_name" : "Reddit_txt",
      "indices" : [ 85, 96 ],
      "id_str" : "489467009",
      "id" : 489467009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240934022983843840",
  "text" : "Reminder that the President is answering questions on the same site as these people: @Reddit_txt",
  "id" : 240934022983843840,
  "created_at" : "2012-08-29 22:08:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240929769179455489",
  "geo" : { },
  "id_str" : "240930722548953089",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh thats turrible",
  "id" : 240930722548953089,
  "in_reply_to_status_id" : 240929769179455489,
  "created_at" : "2012-08-29 21:55:35 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Stradley",
      "screen_name" : "StephStradley",
      "indices" : [ 3, 17 ],
      "id_str" : "46664685",
      "id" : 46664685
    }, {
      "name" : "Jamie Mottram",
      "screen_name" : "JamieMottram",
      "indices" : [ 77, 90 ],
      "id_str" : "16538135",
      "id" : 16538135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aGNyG1LE",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/benjaminj4\/how-white-is-the-new-internet",
      "display_url" : "buzzfeed.com\/benjaminj4\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240917191405481984",
  "text" : "RT @StephStradley: Good ol boy network is a real thing. Because it's easy RT @jamiemottram: Man, the Internet is super-white + super-mal ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jamie Mottram",
        "screen_name" : "JamieMottram",
        "indices" : [ 58, 71 ],
        "id_str" : "16538135",
        "id" : 16538135
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/aGNyG1LE",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/benjaminj4\/how-white-is-the-new-internet",
        "display_url" : "buzzfeed.com\/benjaminj4\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "240861433305378816",
    "text" : "Good ol boy network is a real thing. Because it's easy RT @jamiemottram: Man, the Internet is super-white + super-male. http:\/\/t.co\/aGNyG1LE",
    "id" : 240861433305378816,
    "created_at" : "2012-08-29 17:20:15 +0000",
    "user" : {
      "name" : "Stephanie Stradley",
      "screen_name" : "StephStradley",
      "protected" : false,
      "id_str" : "46664685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466621133458903040\/xlJVoxTd_normal.jpeg",
      "id" : 46664685,
      "verified" : false
    }
  },
  "id" : 240917191405481984,
  "created_at" : "2012-08-29 21:01:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240916610251104256",
  "text" : "I stop checking the Internet for a few hours and President Obama is doing an AMA on Reddit. Maybe I should do that more often.",
  "id" : 240916610251104256,
  "created_at" : "2012-08-29 20:59:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "indices" : [ 0, 12 ],
      "id_str" : "198661893",
      "id" : 198661893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "240846437980704768",
  "geo" : { },
  "id_str" : "240847203294388224",
  "in_reply_to_user_id" : 198661893,
  "text" : "@eliseworthy the default web steps used to be a good place but purists have removed them. Check out http:\/\/t.co\/t7WATcFT's cukes.",
  "id" : 240847203294388224,
  "in_reply_to_status_id" : 240846437980704768,
  "created_at" : "2012-08-29 16:23:42 +0000",
  "in_reply_to_screen_name" : "eliseworthy",
  "in_reply_to_user_id_str" : "198661893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 12, 19 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Matthew Kent",
      "screen_name" : "matthewdalekent",
      "indices" : [ 40, 56 ],
      "id_str" : "260113110",
      "id" : 260113110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 132 ],
      "url" : "https:\/\/t.co\/LVajVAKw",
      "expanded_url" : "https:\/\/github.com\/opscode\/mixlib-shellout",
      "display_url" : "github.com\/opscode\/mixlib\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "240831505033752576",
  "geo" : { },
  "id_str" : "240833895447277568",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot @jyurek hey! found out from @matthewdalekent that mixlib-shellout does the same stuff, no windows: https:\/\/t.co\/LVajVAKw",
  "id" : 240833895447277568,
  "in_reply_to_status_id" : 240831505033752576,
  "created_at" : "2012-08-29 15:30:49 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240655287978184706",
  "text" : "Some neat internal Chrome URLs: chrome:\/\/about\/ chrome:\/\/omnibox\/ chrome:\/\/memory\/ chrome:\/\/dns\/ chrome:\/\/view-http-cache",
  "id" : 240655287978184706,
  "created_at" : "2012-08-29 03:41:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 33, 41 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 96, 106 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240592173140152323",
  "geo" : { },
  "id_str" : "240592684325154817",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi we should hook this up for @wnyruby too! Really a good idea for fresh speaking blood. \/cc @aspleenic",
  "id" : 240592684325154817,
  "in_reply_to_status_id" : 240592173140152323,
  "created_at" : "2012-08-28 23:32:20 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Busigin",
      "screen_name" : "mbusigin",
      "indices" : [ 0, 9 ],
      "id_str" : "19111917",
      "id" : 19111917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240522555604230144",
  "geo" : { },
  "id_str" : "240523046195179520",
  "in_reply_to_user_id" : 19111917,
  "text" : "@mbusigin that's a shitload of \"experience\" for an \"intern\". why don't you just switch it to \"full time developer paid for less\" ?",
  "id" : 240523046195179520,
  "in_reply_to_status_id" : 240522555604230144,
  "created_at" : "2012-08-28 18:55:37 +0000",
  "in_reply_to_screen_name" : "mbusigin",
  "in_reply_to_user_id_str" : "19111917",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240495334931972097",
  "geo" : { },
  "id_str" : "240496394048241664",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense huskies are a shitload of work, but very worth it. if you want to talk about it let me know!",
  "id" : 240496394048241664,
  "in_reply_to_status_id" : 240495334931972097,
  "created_at" : "2012-08-28 17:09:43 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/pdOpkvG7",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/bill-destler\/todd-akin-rape-global-warming-_b_1833817.html",
      "display_url" : "huffingtonpost.com\/bill-destler\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240493054212071424",
  "text" : "Hell yes, RIT's president is awesome: http:\/\/t.co\/pdOpkvG7",
  "id" : 240493054212071424,
  "created_at" : "2012-08-28 16:56:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240477674844352512",
  "geo" : { },
  "id_str" : "240479203580055552",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten i've been told 2-3 hours nearly every time I've visited there or PF's. so stupid.",
  "id" : 240479203580055552,
  "in_reply_to_status_id" : 240477674844352512,
  "created_at" : "2012-08-28 16:01:24 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240464650234372097",
  "geo" : { },
  "id_str" : "240465244374319104",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner QUEUED. Try some Armcannon when you get a chance.",
  "id" : 240465244374319104,
  "in_reply_to_status_id" : 240464650234372097,
  "created_at" : "2012-08-28 15:05:56 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "240462420156510208",
  "text" : "Seriously, come play some music: http:\/\/t.co\/epnjp2aB",
  "id" : 240462420156510208,
  "created_at" : "2012-08-28 14:54:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240455766950178818",
  "geo" : { },
  "id_str" : "240458428143771649",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed thanks for helping out yesterday!",
  "id" : 240458428143771649,
  "in_reply_to_status_id" : 240455766950178818,
  "created_at" : "2012-08-28 14:38:51 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 3, 14 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 77, 91 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wnyruby",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240458067853066240",
  "text" : "RT @Jonplussed: So much fun and knowledge with the #wnyruby novices group at @coworkbuffalo. Interested in learning to code? Every Mon,  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 61, 75 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wnyruby",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "240455766950178818",
    "text" : "So much fun and knowledge with the #wnyruby novices group at @coworkbuffalo. Interested in learning to code? Every Mon, 6:30pm ~ 8:30pm!",
    "id" : 240455766950178818,
    "created_at" : "2012-08-28 14:28:16 +0000",
    "user" : {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "protected" : false,
      "id_str" : "38408851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471328341526462464\/hNg5dFGn_normal.jpeg",
      "id" : 38408851,
      "verified" : false
    }
  },
  "id" : 240458067853066240,
  "created_at" : "2012-08-28 14:37:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/BamG7pEk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fHZnzFVZ3_o",
      "display_url" : "youtube.com\/watch?v=fHZnzF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "240299066783842305",
  "geo" : { },
  "id_str" : "240299422620188673",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes hah! just saying, taking vc\/funding just to pay rent sounds like a turrible idea http:\/\/t.co\/BamG7pEk",
  "id" : 240299422620188673,
  "in_reply_to_status_id" : 240299066783842305,
  "created_at" : "2012-08-28 04:07:01 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240297528887742464",
  "geo" : { },
  "id_str" : "240298937632829441",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes move out of one of the most expensive areas of the country, maybe this won't be a problem? ;)",
  "id" : 240298937632829441,
  "in_reply_to_status_id" : 240297528887742464,
  "created_at" : "2012-08-28 04:05:05 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/5GF8hI9N",
      "expanded_url" : "http:\/\/37.com\/main.htm",
      "display_url" : "37.com\/main.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "240284649211973632",
  "text" : "lol: http:\/\/t.co\/5GF8hI9N",
  "id" : 240284649211973632,
  "created_at" : "2012-08-28 03:08:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240256238645022720",
  "geo" : { },
  "id_str" : "240256491397980160",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH I know you're trolling, but what you just said does not help someone absolutely new at all.",
  "id" : 240256491397980160,
  "in_reply_to_status_id" : 240256238645022720,
  "created_at" : "2012-08-28 01:16:25 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Dorrans",
      "screen_name" : "blowdart",
      "indices" : [ 0, 9 ],
      "id_str" : "1847381",
      "id" : 1847381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240256123045822465",
  "geo" : { },
  "id_str" : "240256248459706368",
  "in_reply_to_user_id" : 1847381,
  "text" : "@blowdart good luck!",
  "id" : 240256248459706368,
  "in_reply_to_status_id" : 240256123045822465,
  "created_at" : "2012-08-28 01:15:28 +0000",
  "in_reply_to_screen_name" : "blowdart",
  "in_reply_to_user_id_str" : "1847381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240255994150649856",
  "text" : "There's so much taken for granted mentally about what we do on a daily basis in our craft. I only hope this doesn't discourage newcomers.",
  "id" : 240255994150649856,
  "created_at" : "2012-08-28 01:14:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240255705272160256",
  "text" : "When's the last time you explained basic coding concepts? Indexing an array. How behavior differs from state. Doing a 2 dimensional loop.",
  "id" : 240255705272160256,
  "created_at" : "2012-08-28 01:13:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240252359396179968",
  "geo" : { },
  "id_str" : "240254675046236161",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH trying a different language is nothing like teaching the thought and decision processes behind coding",
  "id" : 240254675046236161,
  "in_reply_to_status_id" : 240252359396179968,
  "created_at" : "2012-08-28 01:09:12 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240251885758607360",
  "text" : "It's so unbelievably difficult to think like a programming beginner. Holy moley.",
  "id" : 240251885758607360,
  "created_at" : "2012-08-28 00:58:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Andy Staple",
      "screen_name" : "AndyStaple",
      "indices" : [ 11, 22 ],
      "id_str" : "34352961",
      "id" : 34352961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 44 ],
      "url" : "https:\/\/t.co\/lpU50VvY",
      "expanded_url" : "https:\/\/gist.github.com\/3493919",
      "display_url" : "gist.github.com\/3493919"
    } ]
  },
  "geo" : { },
  "id_str" : "240249739248025601",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto @andystaple https:\/\/t.co\/lpU50VvY",
  "id" : 240249739248025601,
  "created_at" : "2012-08-28 00:49:36 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240207538010869760",
  "geo" : { },
  "id_str" : "240207810711924737",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH I love this city, and I'm working hard to improve it. Buffalo News just loves harping on terrible shit.",
  "id" : 240207810711924737,
  "in_reply_to_status_id" : 240207538010869760,
  "created_at" : "2012-08-27 22:02:59 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 51 ],
      "url" : "https:\/\/t.co\/eAB78z4W",
      "expanded_url" : "https:\/\/img.skitch.com\/20120827-ee4khwn2m5phwgj13wy32f54yw.png",
      "display_url" : "img.skitch.com\/20120827-ee4kh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240206694314037248",
  "text" : "Buffalo: We're talking PROUD! https:\/\/t.co\/eAB78z4W",
  "id" : 240206694314037248,
  "created_at" : "2012-08-27 21:58:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/8ZGrLQW3",
      "expanded_url" : "http:\/\/www.runbasic.com\/",
      "display_url" : "runbasic.com"
    } ]
  },
  "geo" : { },
  "id_str" : "240203155827195905",
  "text" : "This showed up in a Facebook ad: \"Web programming for people who really like to program! Just $59.95!\" http:\/\/t.co\/8ZGrLQW3",
  "id" : 240203155827195905,
  "created_at" : "2012-08-27 21:44:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 79 ],
      "url" : "https:\/\/t.co\/PmXvnt4e",
      "expanded_url" : "https:\/\/twitter.com\/#!\/search\/realtime\/jajaja",
      "display_url" : "twitter.com\/#!\/search\/real\u2026"
    }, {
      "indices" : [ 80, 101 ],
      "url" : "https:\/\/t.co\/ib7QrpRg",
      "expanded_url" : "https:\/\/twitter.com\/#!\/search\/jajajajajajajajajajajaja",
      "display_url" : "twitter.com\/#!\/search\/jaja\u2026"
    }, {
      "indices" : [ 102, 123 ],
      "url" : "https:\/\/t.co\/jQiPLJFU",
      "expanded_url" : "https:\/\/twitter.com\/#!\/search\/realtime\/jajajajajajajajajajajajajajajajajajajajajajajaja",
      "display_url" : "twitter.com\/#!\/search\/real\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240192135259893760",
  "text" : "I need a graph of \"jajajaja\" length with tweet frequency. https:\/\/t.co\/PmXvnt4e https:\/\/t.co\/ib7QrpRg https:\/\/t.co\/jQiPLJFU",
  "id" : 240192135259893760,
  "created_at" : "2012-08-27 21:00:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 37 ],
      "url" : "https:\/\/t.co\/WIAnX5Rx",
      "expanded_url" : "https:\/\/twitter.com\/#!\/search\/realtime\/jajajajaja",
      "display_url" : "twitter.com\/#!\/search\/real\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240188471552143361",
  "text" : "Current status: https:\/\/t.co\/WIAnX5Rx",
  "id" : 240188471552143361,
  "created_at" : "2012-08-27 20:46:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240187329300537344",
  "text" : "Anniversary cake topper ordered. Love that we can get a fresh one for free. Also, it's almost been a year!!!?",
  "id" : 240187329300537344,
  "created_at" : "2012-08-27 20:41:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pascal Rettig",
      "screen_name" : "cykod",
      "indices" : [ 0, 6 ],
      "id_str" : "18439491",
      "id" : 18439491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240174969307410432",
  "geo" : { },
  "id_str" : "240175475647983616",
  "in_reply_to_user_id" : 18439491,
  "text" : "@cykod does it double as a rollercoaster!!?!",
  "id" : 240175475647983616,
  "in_reply_to_status_id" : 240174969307410432,
  "created_at" : "2012-08-27 19:54:30 +0000",
  "in_reply_to_screen_name" : "cykod",
  "in_reply_to_user_id_str" : "18439491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PragmaticProgrammers",
      "screen_name" : "pragprog",
      "indices" : [ 3, 12 ],
      "id_str" : "26576418",
      "id" : 26576418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/yWGpqqws",
      "expanded_url" : "http:\/\/pragprog.com",
      "display_url" : "pragprog.com"
    } ]
  },
  "geo" : { },
  "id_str" : "240155663534268417",
  "text" : "RT @pragprog: Randy the Gerbil here! Save 40% http:\/\/t.co\/yWGpqqws w\/code randy_lives_63077563, good for at least a few hours. Then it's ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/yWGpqqws",
        "expanded_url" : "http:\/\/pragprog.com",
        "display_url" : "pragprog.com"
      } ]
    },
    "geo" : { },
    "id_str" : "240152195570466817",
    "text" : "Randy the Gerbil here! Save 40% http:\/\/t.co\/yWGpqqws w\/code randy_lives_63077563, good for at least a few hours. Then it's kibble time!",
    "id" : 240152195570466817,
    "created_at" : "2012-08-27 18:21:59 +0000",
    "user" : {
      "name" : "PragmaticProgrammers",
      "screen_name" : "pragprog",
      "protected" : false,
      "id_str" : "26576418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/290486223\/pp_for_twitter_normal.png",
      "id" : 26576418,
      "verified" : false
    }
  },
  "id" : 240155663534268417,
  "created_at" : "2012-08-27 18:35:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240142185805279232",
  "text" : "Holy living fuck, the fucking Moon. Over.",
  "id" : 240142185805279232,
  "created_at" : "2012-08-27 17:42:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 0, 8 ],
      "id_str" : "1235521",
      "id" : 1235521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 30 ],
      "url" : "https:\/\/t.co\/v0VGwhBD",
      "expanded_url" : "https:\/\/github.com\/josh\/useragent",
      "display_url" : "github.com\/josh\/useragent"
    } ]
  },
  "in_reply_to_status_id_str" : "240134950903504896",
  "geo" : { },
  "id_str" : "240135752422416384",
  "in_reply_to_user_id" : 1235521,
  "text" : "@timbray https:\/\/t.co\/v0VGwhBD",
  "id" : 240135752422416384,
  "in_reply_to_status_id" : 240134950903504896,
  "created_at" : "2012-08-27 17:16:39 +0000",
  "in_reply_to_screen_name" : "timbray",
  "in_reply_to_user_id_str" : "1235521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "240132724688556032",
  "text" : "DJing in the CoworkBuffalo room. Now playing Welt: Digital September [daft Punk Vs Earth Wind And Fire] \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 240132724688556032,
  "created_at" : "2012-08-27 17:04:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/GigNGt0e",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3238-paul-horowitz-and-the-real-37-signals",
      "display_url" : "37signals.com\/svn\/posts\/3238\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240117271329132544",
  "text" : "RT @jasonfried: Paul Horowitz and the real 37 signals. What a wonderful surprise: http:\/\/t.co\/GigNGt0e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/GigNGt0e",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3238-paul-horowitz-and-the-real-37-signals",
        "display_url" : "37signals.com\/svn\/posts\/3238\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "240117095201898496",
    "text" : "Paul Horowitz and the real 37 signals. What a wonderful surprise: http:\/\/t.co\/GigNGt0e",
    "id" : 240117095201898496,
    "created_at" : "2012-08-27 16:02:31 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 240117271329132544,
  "created_at" : "2012-08-27 16:03:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hipster Hacker",
      "screen_name" : "hipsterhacker",
      "indices" : [ 39, 53 ],
      "id_str" : "261546340",
      "id" : 261546340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240114934162264065",
  "text" : "OH \"I know what Haskell is, because of @hipsterhacker\"",
  "id" : 240114934162264065,
  "created_at" : "2012-08-27 15:53:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/FwcgZ2Lh",
      "expanded_url" : "http:\/\/imgur.com\/a\/vnC8Z",
      "display_url" : "imgur.com\/a\/vnC8Z"
    } ]
  },
  "geo" : { },
  "id_str" : "240111728527032321",
  "text" : "I am also going crazy seeing Nick Cage's face everywhere: http:\/\/t.co\/FwcgZ2Lh",
  "id" : 240111728527032321,
  "created_at" : "2012-08-27 15:41:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 43, 50 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/LAGrlqvy",
      "expanded_url" : "http:\/\/i.imgur.com\/FQ5sc.jpg",
      "display_url" : "i.imgur.com\/FQ5sc.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "240111622474039296",
  "text" : "Current status: http:\/\/t.co\/LAGrlqvy  (via @jmazzi)",
  "id" : 240111622474039296,
  "created_at" : "2012-08-27 15:40:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Mullen",
      "screen_name" : "samullen",
      "indices" : [ 0, 9 ],
      "id_str" : "23062047",
      "id" : 23062047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 86 ],
      "url" : "https:\/\/t.co\/XRPWzFjJ",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/commits\/master?page=68",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "240109237454372864",
  "geo" : { },
  "id_str" : "240111057794912256",
  "in_reply_to_user_id" : 23062047,
  "text" : "@samullen it was always open. started as two small sinatra apps. https:\/\/t.co\/XRPWzFjJ",
  "id" : 240111057794912256,
  "in_reply_to_status_id" : 240109237454372864,
  "created_at" : "2012-08-27 15:38:31 +0000",
  "in_reply_to_screen_name" : "samullen",
  "in_reply_to_user_id_str" : "23062047",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Vaucher",
      "screen_name" : "vaucherb",
      "indices" : [ 0, 9 ],
      "id_str" : "12000242",
      "id" : 12000242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240079536270749697",
  "geo" : { },
  "id_str" : "240097185834881024",
  "in_reply_to_user_id" : 12000242,
  "text" : "@vaucherb maybe S3\/CloudFront is blocked for you?",
  "id" : 240097185834881024,
  "in_reply_to_status_id" : 240079536270749697,
  "created_at" : "2012-08-27 14:43:24 +0000",
  "in_reply_to_screen_name" : "vaucherb",
  "in_reply_to_user_id_str" : "12000242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240020008112111616",
  "geo" : { },
  "id_str" : "240084206745690112",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath thanks!!",
  "id" : 240084206745690112,
  "in_reply_to_status_id" : 240020008112111616,
  "created_at" : "2012-08-27 13:51:50 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 0, 14 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240071553285517312",
  "geo" : { },
  "id_str" : "240079931500007425",
  "in_reply_to_user_id" : 491801330,
  "text" : "@coworkbuffalo bike tires need a refill. Will be down by 1015.",
  "id" : 240079931500007425,
  "in_reply_to_status_id" : 240071553285517312,
  "created_at" : "2012-08-27 13:34:50 +0000",
  "in_reply_to_screen_name" : "coworkbuffalo",
  "in_reply_to_user_id_str" : "491801330",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gisi",
      "screen_name" : "gisikw",
      "indices" : [ 0, 7 ],
      "id_str" : "14308739",
      "id" : 14308739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239927319093968896",
  "geo" : { },
  "id_str" : "239927612250664960",
  "in_reply_to_user_id" : 14308739,
  "text" : "@gisikw where did all of this certification nonsense come from?",
  "id" : 239927612250664960,
  "in_reply_to_status_id" : 239927319093968896,
  "created_at" : "2012-08-27 03:29:35 +0000",
  "in_reply_to_screen_name" : "gisikw",
  "in_reply_to_user_id_str" : "14308739",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 0, 11 ],
      "id_str" : "56423575",
      "id" : 56423575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239924200914161664",
  "geo" : { },
  "id_str" : "239926092742393856",
  "in_reply_to_user_id" : 56423575,
  "text" : "@luisjoseve Sure! it's going to be ridiculously cold, just a heads up :)",
  "id" : 239926092742393856,
  "in_reply_to_status_id" : 239924200914161664,
  "created_at" : "2012-08-27 03:23:32 +0000",
  "in_reply_to_screen_name" : "luisjoseve",
  "in_reply_to_user_id_str" : "56423575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg ",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 49 ],
      "url" : "https:\/\/t.co\/1gJJmETT",
      "expanded_url" : "https:\/\/img.skitch.com\/20120827-j4u9gmu3fcc9mq1rpqf9na4ajn.png",
      "display_url" : "img.skitch.com\/20120827-j4u9g\u2026"
    }, {
      "indices" : [ 50, 71 ],
      "url" : "https:\/\/t.co\/T5TR8aTj",
      "expanded_url" : "https:\/\/img.skitch.com\/20120827-ttwipf5jejk29gfaarpmhnyfep.png",
      "display_url" : "img.skitch.com\/20120827-ttwip\u2026"
    }, {
      "indices" : [ 72, 93 ],
      "url" : "https:\/\/t.co\/gre0JmqI",
      "expanded_url" : "https:\/\/img.skitch.com\/20120827-f7dwn2sxu8cftxuenit8trqjui.png",
      "display_url" : "img.skitch.com\/20120827-f7dwn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "239922167515582464",
  "geo" : { },
  "id_str" : "239925621323612160",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg my current fort: https:\/\/t.co\/1gJJmETT https:\/\/t.co\/T5TR8aTj https:\/\/t.co\/gre0JmqI",
  "id" : 239925621323612160,
  "in_reply_to_status_id" : 239922167515582464,
  "created_at" : "2012-08-27 03:21:40 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 0, 11 ],
      "id_str" : "56423575",
      "id" : 56423575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239914243917496320",
  "geo" : { },
  "id_str" : "239921396082434050",
  "in_reply_to_user_id" : 56423575,
  "text" : "@luisjoseve it's rarely frozen. why?",
  "id" : 239921396082434050,
  "in_reply_to_status_id" : 239914243917496320,
  "created_at" : "2012-08-27 03:04:53 +0000",
  "in_reply_to_screen_name" : "luisjoseve",
  "in_reply_to_user_id_str" : "56423575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg ",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239920522895429633",
  "geo" : { },
  "id_str" : "239920874038366208",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg HELL YES. I have yet to articulate my thoughts about it...it's just ridiculously deep, and so wide open.",
  "id" : 239920874038366208,
  "in_reply_to_status_id" : 239920522895429633,
  "created_at" : "2012-08-27 03:02:48 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 23, 37 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239911380302589952",
  "text" : "Excited to get back to @coworkbuffalo this week!",
  "id" : 239911380302589952,
  "created_at" : "2012-08-27 02:25:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239910402832605186",
  "text" : "Are there any counter apps on iOS that are retina ready and don't suck?",
  "id" : 239910402832605186,
  "created_at" : "2012-08-27 02:21:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 3, 10 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239910253695737856",
  "text" : "RT @wycats: I think I'm going to actively try to avoid my posts getting on HN from now on. The negativity really crowds out useful discu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "239910144861949953",
    "text" : "I think I'm going to actively try to avoid my posts getting on HN from now on. The negativity really crowds out useful discussions.",
    "id" : 239910144861949953,
    "created_at" : "2012-08-27 02:20:10 +0000",
    "user" : {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "protected" : false,
      "id_str" : "8526432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3250074047\/46d910af94e25187832cb4a3bc84b2b5_normal.jpeg",
      "id" : 8526432,
      "verified" : false
    }
  },
  "id" : 239910253695737856,
  "created_at" : "2012-08-27 02:20:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/oqGpDNdK",
      "expanded_url" : "http:\/\/www.seasteading.org\/",
      "display_url" : "seasteading.org"
    } ]
  },
  "geo" : { },
  "id_str" : "239909707031117824",
  "text" : "Finally, a way for all of Hacker News commenters to get together and create their own society, far away from others: http:\/\/t.co\/oqGpDNdK",
  "id" : 239909707031117824,
  "created_at" : "2012-08-27 02:18:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 27, 35 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/239909060802117633\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/IF4H9VVF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1RUBQvCAAMNm5O.jpg",
      "id_str" : "239909060806311939",
      "id" : 239909060806311939,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1RUBQvCAAMNm5O.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      } ],
      "display_url" : "pic.twitter.com\/IF4H9VVF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/ldTFdCaM",
      "expanded_url" : "http:\/\/kara.allthingsd.com\/files\/2009\/07\/twitterpage1.jpg",
      "display_url" : "kara.allthingsd.com\/files\/2009\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "239909060802117633",
  "text" : "Spotted some lightbulbs at @Wegmans with a very...familiar stock logo. http:\/\/t.co\/ldTFdCaM http:\/\/t.co\/IF4H9VVF",
  "id" : 239909060802117633,
  "created_at" : "2012-08-27 02:15:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/239884721230856193\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/UgKJW2cA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1Q94gyCQAAmbHt.jpg",
      "id_str" : "239884721239244800",
      "id" : 239884721239244800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1Q94gyCQAAmbHt.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UgKJW2cA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239884721230856193",
  "text" : "It's always been humbling to see Gemcutter in print. Something much more real. http:\/\/t.co\/UgKJW2cA",
  "id" : 239884721230856193,
  "created_at" : "2012-08-27 00:39:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239881422318477313",
  "text" : "Since when does Barnes and Noble have a huge strategy game section? Blown away by how many choices it has.",
  "id" : 239881422318477313,
  "created_at" : "2012-08-27 00:26:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239802158084657153",
  "text" : "It's about 20 degrees too hot for Elmwood Arts.",
  "id" : 239802158084657153,
  "created_at" : "2012-08-26 19:11:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/JBRoZb4I",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wAkCLpMtjlM",
      "display_url" : "youtube.com\/watch?v=wAkCLp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "239603453394055168",
  "text" : "I can only imagine that the guy filming the last video is this guy: http:\/\/t.co\/JBRoZb4I",
  "id" : 239603453394055168,
  "created_at" : "2012-08-26 06:01:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/GdLzpi2Z",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kPpywcACZzk",
      "display_url" : "youtube.com\/watch?v=kPpywc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "239601169293520897",
  "text" : "Current status: http:\/\/t.co\/GdLzpi2Z",
  "id" : 239601169293520897,
  "created_at" : "2012-08-26 05:52:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/0UvzXyBi",
      "expanded_url" : "http:\/\/instagr.am\/p\/OxxYudM6gT\/",
      "display_url" : "instagr.am\/p\/OxxYudM6gT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "239578146972790785",
  "text" : "Not looking good. http:\/\/t.co\/0UvzXyBi",
  "id" : 239578146972790785,
  "created_at" : "2012-08-26 04:20:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/moRtLSac",
      "expanded_url" : "http:\/\/instagr.am\/p\/OxxOnvs6gJ\/",
      "display_url" : "instagr.am\/p\/OxxOnvs6gJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "239577803199246336",
  "text" : "Descent! Of course I chose the dwarf that lugs around a beer mug. http:\/\/t.co\/moRtLSac",
  "id" : 239577803199246336,
  "created_at" : "2012-08-26 04:19:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239560915647877120",
  "geo" : { },
  "id_str" : "239561967642214400",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson BOOO",
  "id" : 239561967642214400,
  "in_reply_to_status_id" : 239560915647877120,
  "created_at" : "2012-08-26 03:16:38 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239557687019450369",
  "geo" : { },
  "id_str" : "239559396210917377",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson playing some games at a friends. You up for it?",
  "id" : 239559396210917377,
  "in_reply_to_status_id" : 239557687019450369,
  "created_at" : "2012-08-26 03:06:25 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 47, 59 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239203672393928704",
  "text" : "Approximately one hour from wheels down BUF to @whereslloyd. TOP SCORE!",
  "id" : 239203672393928704,
  "created_at" : "2012-08-25 03:32:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 0, 9 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239196442462388224",
  "geo" : { },
  "id_str" : "239203352477581312",
  "in_reply_to_user_id" : 15494948,
  "text" : "@coderjoe you can make up for it.",
  "id" : 239203352477581312,
  "in_reply_to_status_id" : 239196442462388224,
  "created_at" : "2012-08-25 03:31:38 +0000",
  "in_reply_to_screen_name" : "coderjoe",
  "in_reply_to_user_id_str" : "15494948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239196719701688320",
  "geo" : { },
  "id_str" : "239203274312519680",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr yes.",
  "id" : 239203274312519680,
  "in_reply_to_status_id" : 239196719701688320,
  "created_at" : "2012-08-25 03:31:19 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 77, 89 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239195378463952898",
  "text" : "Returning to Buffalo after a week means within an hour I'm going to get some @whereslloyd.",
  "id" : 239195378463952898,
  "created_at" : "2012-08-25 02:59:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 0, 11 ],
      "id_str" : "10774712",
      "id" : 10774712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239137768545087488",
  "geo" : { },
  "id_str" : "239188720367050752",
  "in_reply_to_user_id" : 10774712,
  "text" : "@richdownie nope!",
  "id" : 239188720367050752,
  "in_reply_to_status_id" : 239137768545087488,
  "created_at" : "2012-08-25 02:33:29 +0000",
  "in_reply_to_screen_name" : "richdownie",
  "in_reply_to_user_id_str" : "10774712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/239141017142571008\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/QgpNvfn5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1GZfPKCMAA2DV5.png",
      "id_str" : "239141017150959616",
      "id" : 239141017150959616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1GZfPKCMAA2DV5.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/QgpNvfn5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239141017142571008",
  "text" : "Google's mobile UI for flight searches is gorgeous. Why can't these guys work on Gmail or Groups? http:\/\/t.co\/QgpNvfn5",
  "id" : 239141017142571008,
  "created_at" : "2012-08-24 23:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/t11CrsVA",
      "expanded_url" : "http:\/\/instagr.am\/p\/OumOnbM6kh\/",
      "display_url" : "instagr.am\/p\/OumOnbM6kh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "239131591266422784",
  "text" : "Didn't get lost in ORD this time, and no free massage. Hurray! http:\/\/t.co\/t11CrsVA",
  "id" : 239131591266422784,
  "created_at" : "2012-08-24 22:46:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 3, 10 ],
      "id_str" : "15395778",
      "id" : 15395778
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239120861024645120",
  "text" : "RT @jmazzi: @aquaranto Quaranto gifs never disappoint.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 0, 10 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "239113073242284032",
    "geo" : { },
    "id_str" : "239113357192478721",
    "in_reply_to_user_id" : 5744442,
    "text" : "@aquaranto Quaranto gifs never disappoint.",
    "id" : 239113357192478721,
    "in_reply_to_status_id" : 239113073242284032,
    "created_at" : "2012-08-24 21:34:01 +0000",
    "in_reply_to_screen_name" : "aquaranto",
    "in_reply_to_user_id_str" : "5744442",
    "user" : {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "protected" : false,
      "id_str" : "15395778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413712456620322816\/Ki1bebJu_normal.jpeg",
      "id" : 15395778,
      "verified" : false
    }
  },
  "id" : 239120861024645120,
  "created_at" : "2012-08-24 22:03:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239112736750067713",
  "text" : "Bye Chicago! It was fun this time, as usual. I need to explore you more.",
  "id" : 239112736750067713,
  "created_at" : "2012-08-24 21:31:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239111460683411456",
  "text" : "RT @aquaranto: \"...since in Ruby, 'Class' is a class...\" mind = blown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "239109919717068800",
    "text" : "\"...since in Ruby, 'Class' is a class...\" mind = blown",
    "id" : 239109919717068800,
    "created_at" : "2012-08-24 21:20:21 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 239111460683411456,
  "created_at" : "2012-08-24 21:26:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239074450862112768",
  "geo" : { },
  "id_str" : "239078805757632513",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield yes, love it.",
  "id" : 239078805757632513,
  "in_reply_to_status_id" : 239074450862112768,
  "created_at" : "2012-08-24 19:16:43 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 53, 63 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/W6ZtaXgr",
      "expanded_url" : "http:\/\/instagr.am\/p\/OuMMEMM6hG\/",
      "display_url" : "instagr.am\/p\/OuMMEMM6hG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "239074259262111744",
  "text" : "Finally fit some Guillotine in. Need some more games @37signals. http:\/\/t.co\/W6ZtaXgr",
  "id" : 239074259262111744,
  "created_at" : "2012-08-24 18:58:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239039051208994817",
  "geo" : { },
  "id_str" : "239041453572104192",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark no doubt?",
  "id" : 239041453572104192,
  "in_reply_to_status_id" : 239039051208994817,
  "created_at" : "2012-08-24 16:48:18 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/BnZXBMUd",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=4d_FvgQ1csE",
      "display_url" : "youtube.com\/watch?v=4d_Fvg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "239026668067512321",
  "text" : "Current status: http:\/\/t.co\/BnZXBMUd",
  "id" : 239026668067512321,
  "created_at" : "2012-08-24 15:49:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238011962271879168",
  "geo" : { },
  "id_str" : "238905809965285376",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu please make it work!!",
  "id" : 238905809965285376,
  "in_reply_to_status_id" : 238011962271879168,
  "created_at" : "2012-08-24 07:49:18 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 15, 21 ],
      "id_str" : "24425454",
      "id" : 24425454
    }, {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 22, 31 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238304877724463105",
  "geo" : { },
  "id_str" : "238905553290682368",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @hgmnz @schneems catching up here, and this thread. I think we need to blurgh more about how we use concerns at 37s.",
  "id" : 238905553290682368,
  "in_reply_to_status_id" : 238304877724463105,
  "created_at" : "2012-08-24 07:48:17 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238896790810787841",
  "geo" : { },
  "id_str" : "238899128619380737",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo wow.",
  "id" : 238899128619380737,
  "in_reply_to_status_id" : 238896790810787841,
  "created_at" : "2012-08-24 07:22:45 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 12, 18 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/mfzozFmL",
      "expanded_url" : "http:\/\/phish.com\/#\/media\/galleries\/memories-of-marley",
      "display_url" : "phish.com\/#\/media\/galler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238863878929412096",
  "text" : "Didn't know @phish was a dog band. http:\/\/t.co\/mfzozFmL",
  "id" : 238863878929412096,
  "created_at" : "2012-08-24 05:02:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 8, 13 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/UaouH0Y4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=I-4FtBjjelA",
      "display_url" : "youtube.com\/watch?v=I-4FtB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238857131930050560",
  "text" : "I think @r00k needs to get on the reggae genre: http:\/\/t.co\/UaouH0Y4",
  "id" : 238857131930050560,
  "created_at" : "2012-08-24 04:35:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238853084196007937",
  "geo" : { },
  "id_str" : "238856276048760832",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik butts",
  "id" : 238856276048760832,
  "in_reply_to_status_id" : 238853084196007937,
  "created_at" : "2012-08-24 04:32:28 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Whelton",
      "screen_name" : "jwhelton",
      "indices" : [ 0, 9 ],
      "id_str" : "2216243766",
      "id" : 2216243766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238778126673534976",
  "geo" : { },
  "id_str" : "238853002683883520",
  "in_reply_to_user_id" : 14901457,
  "text" : "@jwhelton the amount of script text on this page hurt my head. literally.",
  "id" : 238853002683883520,
  "in_reply_to_status_id" : 238778126673534976,
  "created_at" : "2012-08-24 04:19:28 +0000",
  "in_reply_to_screen_name" : "Whelton",
  "in_reply_to_user_id_str" : "14901457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 20, 30 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238850931062632448",
  "text" : "My favorite part of @37signals meetups: spending time with coworkers getting to be with them, outside of work. More special when it's rare.",
  "id" : 238850931062632448,
  "created_at" : "2012-08-24 04:11:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Erie.rb",
      "screen_name" : "erierb",
      "indices" : [ 58, 65 ],
      "id_str" : "776151728",
      "id" : 776151728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238846064550105088",
  "text" : "RT @aquaranto: Erie has a Ruby users meetup!!! Hooray for @erierb !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erie.rb",
        "screen_name" : "erierb",
        "indices" : [ 43, 50 ],
        "id_str" : "776151728",
        "id" : 776151728
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238841966186602496",
    "text" : "Erie has a Ruby users meetup!!! Hooray for @erierb !",
    "id" : 238841966186602496,
    "created_at" : "2012-08-24 03:35:36 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 238846064550105088,
  "created_at" : "2012-08-24 03:51:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/YbNc6qlH",
      "expanded_url" : "http:\/\/i-am-cc.org",
      "display_url" : "i-am-cc.org"
    } ]
  },
  "geo" : { },
  "id_str" : "238777957739528192",
  "text" : "I started sharing my Instagram photos under a Creative Commons license. Join me and set your Instagram free! http:\/\/t.co\/YbNc6qlH",
  "id" : 238777957739528192,
  "created_at" : "2012-08-23 23:21:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238775999184125954",
  "geo" : { },
  "id_str" : "238777038436192256",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky 3) Experience Bjj.",
  "id" : 238777038436192256,
  "in_reply_to_status_id" : 238775999184125954,
  "created_at" : "2012-08-23 23:17:36 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/238754141403492354\/photo\/1",
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Ap9buUJH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1A5oGtCMAEppkN.jpg",
      "id_str" : "238754141407686657",
      "id" : 238754141407686657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1A5oGtCMAEppkN.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/Ap9buUJH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238754141403492354",
  "text" : "I love this fucking poster. http:\/\/t.co\/Ap9buUJH",
  "id" : 238754141403492354,
  "created_at" : "2012-08-23 21:46:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238742666446266368",
  "text" : "OH \"Eagles don't give a shit.\"",
  "id" : 238742666446266368,
  "created_at" : "2012-08-23 21:01:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/1VBxWD2q",
      "expanded_url" : "http:\/\/www.voont.com\/files\/images\/madness\/ape.gif",
      "display_url" : "voont.com\/files\/images\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238711406411784192",
  "text" : "Current status: http:\/\/t.co\/1VBxWD2q",
  "id" : 238711406411784192,
  "created_at" : "2012-08-23 18:56:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238710127291686912",
  "geo" : { },
  "id_str" : "238710370653589504",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Boohiss! Not everyone is in XCode :)",
  "id" : 238710370653589504,
  "in_reply_to_status_id" : 238710127291686912,
  "created_at" : "2012-08-23 18:52:42 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238523126667943936",
  "geo" : { },
  "id_str" : "238710040645750784",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza the lack of convention here is the problem. In Ruby, it's simple: rake. \"Build\" in XCode is not enough.",
  "id" : 238710040645750784,
  "in_reply_to_status_id" : 238523126667943936,
  "created_at" : "2012-08-23 18:51:23 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 25, 33 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238706630156509186",
  "text" : "RT @aquaranto: Any of my @wnyruby buddies interested in pairing with some Ruby newbies monday night (8\/27)?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 10, 18 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237940849273602048",
    "text" : "Any of my @wnyruby buddies interested in pairing with some Ruby newbies monday night (8\/27)?",
    "id" : 237940849273602048,
    "created_at" : "2012-08-21 15:54:53 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 238706630156509186,
  "created_at" : "2012-08-23 18:37:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238702319993229312",
  "geo" : { },
  "id_str" : "238702451186880512",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes it should do that...maybe something is broken",
  "id" : 238702451186880512,
  "in_reply_to_status_id" : 238702319993229312,
  "created_at" : "2012-08-23 18:21:13 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238700822521851904",
  "geo" : { },
  "id_str" : "238701203565977601",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark Estefan's Dilemma.",
  "id" : 238701203565977601,
  "in_reply_to_status_id" : 238700822521851904,
  "created_at" : "2012-08-23 18:16:16 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 11, 22 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238672371379224576",
  "geo" : { },
  "id_str" : "238674815261761536",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh @trevorturk awesome! more emoji too!!?",
  "id" : 238674815261761536,
  "in_reply_to_status_id" : 238672371379224576,
  "created_at" : "2012-08-23 16:31:24 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Berger",
      "screen_name" : "bergatron",
      "indices" : [ 33, 43 ],
      "id_str" : "15517749",
      "id" : 15517749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238671925000409088",
  "text" : "Spilled water on my MacBook Pro, @bergatron tuned it up and then I cleaned the screen. Feels like a new computer! Who needs a Retina now!?",
  "id" : 238671925000409088,
  "created_at" : "2012-08-23 16:19:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 3, 14 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/sJ0noOdc",
      "expanded_url" : "http:\/\/123.campfirenow.com\/images\/what.gif",
      "display_url" : "123.campfirenow.com\/images\/what.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "238671697044185088",
  "text" : "RT @trevorturk: http:\/\/t.co\/sJ0noOdc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/sJ0noOdc",
        "expanded_url" : "http:\/\/123.campfirenow.com\/images\/what.gif",
        "display_url" : "123.campfirenow.com\/images\/what.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "238671383574482944",
    "text" : "http:\/\/t.co\/sJ0noOdc",
    "id" : 238671383574482944,
    "created_at" : "2012-08-23 16:17:46 +0000",
    "user" : {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "protected" : false,
      "id_str" : "1742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/59730474\/costco_normal.png",
      "id" : 1742,
      "verified" : false
    }
  },
  "id" : 238671697044185088,
  "created_at" : "2012-08-23 16:19:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 3, 14 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238652132562190337",
  "text" : "RT @trevorturk: \/play what",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238651810385125376",
    "text" : "\/play what",
    "id" : 238651810385125376,
    "created_at" : "2012-08-23 15:00:00 +0000",
    "user" : {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "protected" : false,
      "id_str" : "1742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/59730474\/costco_normal.png",
      "id" : 1742,
      "verified" : false
    }
  },
  "id" : 238652132562190337,
  "created_at" : "2012-08-23 15:01:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 123 ],
      "url" : "https:\/\/t.co\/wqVOlBeq",
      "expanded_url" : "https:\/\/gist.github.com\/3430820#gistcomment-404471",
      "display_url" : "gist.github.com\/3430820#gistco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238644243634212865",
  "text" : "RT @steveklabnik: \u201CI\u2019m just a man, I can\u2019t control myself, so I can\u2019t be held accountable\u201D - @12dcode https:\/\/t.co\/wqVOlBeq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 105 ],
        "url" : "https:\/\/t.co\/wqVOlBeq",
        "expanded_url" : "https:\/\/gist.github.com\/3430820#gistcomment-404471",
        "display_url" : "gist.github.com\/3430820#gistco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "238644007188705280",
    "text" : "\u201CI\u2019m just a man, I can\u2019t control myself, so I can\u2019t be held accountable\u201D - @12dcode https:\/\/t.co\/wqVOlBeq",
    "id" : 238644007188705280,
    "created_at" : "2012-08-23 14:28:59 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 238644243634212865,
  "created_at" : "2012-08-23 14:29:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    }, {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 14, 24 ],
      "id_str" : "170605832",
      "id" : 170605832
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 25, 32 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238643654682615808",
  "geo" : { },
  "id_str" : "238643941736599553",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey @nexxylove @github yeah, he's been banned. the stupidness continued on Gist too.",
  "id" : 238643941736599553,
  "in_reply_to_status_id" : 238643654682615808,
  "created_at" : "2012-08-23 14:28:44 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wardell",
      "screen_name" : "draginol",
      "indices" : [ 0, 9 ],
      "id_str" : "13972382",
      "id" : 13972382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238638702635667456",
  "geo" : { },
  "id_str" : "238639017242001408",
  "in_reply_to_user_id" : 13972382,
  "text" : "@draginol i can't wait for this to explode. going to be fun to watch.",
  "id" : 238639017242001408,
  "in_reply_to_status_id" : 238638702635667456,
  "created_at" : "2012-08-23 14:09:10 +0000",
  "in_reply_to_screen_name" : "draginol",
  "in_reply_to_user_id_str" : "13972382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 56, 66 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 50 ],
      "url" : "https:\/\/t.co\/lIi2MhH6",
      "expanded_url" : "https:\/\/github.com\/cainiac",
      "display_url" : "github.com\/cainiac"
    } ]
  },
  "geo" : { },
  "id_str" : "238638760936488960",
  "text" : "holy shit, what an asshole.  https:\/\/t.co\/lIi2MhH6 (via @nexxylove)",
  "id" : 238638760936488960,
  "created_at" : "2012-08-23 14:08:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238494777111375873",
  "geo" : { },
  "id_str" : "238496848199958528",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense anchorman 2?!",
  "id" : 238496848199958528,
  "in_reply_to_status_id" : 238494777111375873,
  "created_at" : "2012-08-23 04:44:14 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238496435258142720",
  "geo" : { },
  "id_str" : "238496733640921089",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette Togo cup from a bar and some hooker glitter on your shoes with a little blood splatter?",
  "id" : 238496733640921089,
  "in_reply_to_status_id" : 238496435258142720,
  "created_at" : "2012-08-23 04:43:47 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238491307960573952",
  "geo" : { },
  "id_str" : "238492888848293888",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt build an evil fortress\/mansion in an abandoned grain mill. or go to the moon.",
  "id" : 238492888848293888,
  "in_reply_to_status_id" : 238491307960573952,
  "created_at" : "2012-08-23 04:28:30 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 26, 38 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 44, 54 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/asianmack\/status\/238440411666984961\/photo\/1",
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/2ZvYckVI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A08cSoYCMAAjanG.jpg",
      "id_str" : "238440411675373568",
      "id" : 238440411675373568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A08cSoYCMAAjanG.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/2ZvYckVI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238443249696649216",
  "text" : "RT @asianmack: I just met @sstephenson from @37signals!!! http:\/\/t.co\/2ZvYckVI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Stephenson",
        "screen_name" : "sstephenson",
        "indices" : [ 11, 23 ],
        "id_str" : "6707392",
        "id" : 6707392
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 29, 39 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/asianmack\/status\/238440411666984961\/photo\/1",
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/2ZvYckVI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A08cSoYCMAAjanG.jpg",
        "id_str" : "238440411675373568",
        "id" : 238440411675373568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A08cSoYCMAAjanG.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/2ZvYckVI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238440411666984961",
    "text" : "I just met @sstephenson from @37signals!!! http:\/\/t.co\/2ZvYckVI",
    "id" : 238440411666984961,
    "created_at" : "2012-08-23 00:59:59 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 238443249696649216,
  "created_at" : "2012-08-23 01:11:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 26, 35 ],
      "id_str" : "1051521",
      "id" : 1051521
    }, {
      "name" : "Threadless",
      "screen_name" : "threadless",
      "indices" : [ 41, 52 ],
      "id_str" : "5380672",
      "id" : 5380672
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/asianmack\/status\/238428702625652736\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/q1nkcEoC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A08RpEyCYAAk3jh.jpg",
      "id_str" : "238428702629847040",
      "id" : 238428702629847040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A08RpEyCYAAk3jh.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/q1nkcEoC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238428878408933377",
  "text" : "RT @asianmack: I just met @migreyes from @threadless!!! http:\/\/t.co\/q1nkcEoC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mig Reyes",
        "screen_name" : "migreyes",
        "indices" : [ 11, 20 ],
        "id_str" : "1051521",
        "id" : 1051521
      }, {
        "name" : "Threadless",
        "screen_name" : "threadless",
        "indices" : [ 26, 37 ],
        "id_str" : "5380672",
        "id" : 5380672
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/asianmack\/status\/238428702625652736\/photo\/1",
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/q1nkcEoC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A08RpEyCYAAk3jh.jpg",
        "id_str" : "238428702629847040",
        "id" : 238428702629847040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A08RpEyCYAAk3jh.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/q1nkcEoC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238428702625652736",
    "text" : "I just met @migreyes from @threadless!!! http:\/\/t.co\/q1nkcEoC",
    "id" : 238428702625652736,
    "created_at" : "2012-08-23 00:13:27 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 238428878408933377,
  "created_at" : "2012-08-23 00:14:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 8, 20 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 25, 36 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238353237797896192",
  "text" : "I think @sstephenson and @kevinpurdy need to have a Top-Chef esque Chemex bakeoff for best coffee. So good!",
  "id" : 238353237797896192,
  "created_at" : "2012-08-22 19:13:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 14, 24 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/238323140286095360\/photo\/1",
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/j5bI9Sh8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A06xoibCIAA2jb_.png",
      "id_str" : "238323140290289664",
      "id" : 238323140290289664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A06xoibCIAA2jb_.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/j5bI9Sh8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238323140286095360",
  "text" : "We found some @37signals employees at work! http:\/\/t.co\/j5bI9Sh8",
  "id" : 238323140286095360,
  "created_at" : "2012-08-22 17:13:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Santiago Pastorino",
      "screen_name" : "spastorino",
      "indices" : [ 0, 11 ],
      "id_str" : "19661139",
      "id" : 19661139
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 12, 23 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238306253921742848",
  "geo" : { },
  "id_str" : "238308254176911361",
  "in_reply_to_user_id" : 19661139,
  "text" : "@spastorino @tenderlove AGREE",
  "id" : 238308254176911361,
  "in_reply_to_status_id" : 238306253921742848,
  "created_at" : "2012-08-22 16:14:50 +0000",
  "in_reply_to_screen_name" : "spastorino",
  "in_reply_to_user_id_str" : "19661139",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diego Desani",
      "screen_name" : "ddesani",
      "indices" : [ 0, 8 ],
      "id_str" : "29903479",
      "id" : 29903479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238271831449169920",
  "geo" : { },
  "id_str" : "238272086760620032",
  "in_reply_to_user_id" : 29903479,
  "text" : "@ddesani feel free to email me, nick@quaran.to",
  "id" : 238272086760620032,
  "in_reply_to_status_id" : 238271831449169920,
  "created_at" : "2012-08-22 13:51:07 +0000",
  "in_reply_to_screen_name" : "ddesani",
  "in_reply_to_user_id_str" : "29903479",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You and Who",
      "screen_name" : "You_and_Who",
      "indices" : [ 7, 19 ],
      "id_str" : "184659541",
      "id" : 184659541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/SIN2rUYS",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ooc-PNM6gs\/",
      "display_url" : "instagr.am\/p\/Ooc-PNM6gs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "238266795973300225",
  "text" : "It's a @You_and_Who kind of Chicago morning. http:\/\/t.co\/SIN2rUYS",
  "id" : 238266795973300225,
  "created_at" : "2012-08-22 13:30:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 12, 21 ],
      "id_str" : "787975",
      "id" : 787975
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 22, 32 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238129110570897408",
  "geo" : { },
  "id_str" : "238162273837907970",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @mathiasx @aquaranto and I call this \"sleepy haha\". No other way to describe it.",
  "id" : 238162273837907970,
  "in_reply_to_status_id" : 238129110570897408,
  "created_at" : "2012-08-22 06:34:45 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237913917123334144",
  "geo" : { },
  "id_str" : "237915627891879937",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten pretty sure you know what you're missing.",
  "id" : 237915627891879937,
  "in_reply_to_status_id" : 237913917123334144,
  "created_at" : "2012-08-21 14:14:40 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237874466372321280",
  "geo" : { },
  "id_str" : "237905727769952256",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier looks great!",
  "id" : 237905727769952256,
  "in_reply_to_status_id" : 237874466372321280,
  "created_at" : "2012-08-21 13:35:20 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 42, 50 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 51, 59 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/Fx92ms1s",
      "expanded_url" : "http:\/\/aws.amazon.com\/glacier\/",
      "display_url" : "aws.amazon.com\/glacier\/"
    }, {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/apfDjNsT",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SRH-Ywpz1_I",
      "display_url" : "youtube.com\/watch?v=SRH-Yw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237905333236932608",
  "text" : "Also, http:\/\/t.co\/Fx92ms1s looks awesome. @evanphx @drbrain let's get some gems IN THE COOLER http:\/\/t.co\/apfDjNsT",
  "id" : 237905333236932608,
  "created_at" : "2012-08-21 13:33:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 17, 31 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/NmIZGY55",
      "expanded_url" : "http:\/\/ciembor.github.com\/4bit\/",
      "display_url" : "ciembor.github.com\/4bit\/"
    } ]
  },
  "geo" : { },
  "id_str" : "237905211954434048",
  "text" : "I have a feeling @joshuaclayton will squee at this: http:\/\/t.co\/NmIZGY55",
  "id" : 237905211954434048,
  "created_at" : "2012-08-21 13:33:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/UsTkhGmN",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ok1Hi3s6s2\/",
      "display_url" : "instagr.am\/p\/Ok1Hi3s6s2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "237756901536956416",
  "text" : "Crystal Beach on ascent this morning. Be back on Saturday! http:\/\/t.co\/UsTkhGmN",
  "id" : 237756901536956416,
  "created_at" : "2012-08-21 03:43:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 24 ],
      "url" : "http:\/\/t.co\/GFgAckPK",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ok0aW2s6sf\/",
      "display_url" : "instagr.am\/p\/Ok0aW2s6sf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "237755255973113858",
  "text" : "\uD83C\uDDFA\uD83C\uDDF8\u26BE http:\/\/t.co\/GFgAckPK",
  "id" : 237755255973113858,
  "created_at" : "2012-08-21 03:37:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237581261353385985",
  "text" : "I hate \"Like\" as a unit of online engagement. I don't want to Like sad, offensive, scary, controversial, or otherwise not positive stuff.",
  "id" : 237581261353385985,
  "created_at" : "2012-08-20 16:06:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237544694576455680",
  "geo" : { },
  "id_str" : "237571045777879040",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape the horrors our vacuum cleaner have seen are innumerable",
  "id" : 237571045777879040,
  "in_reply_to_status_id" : 237544694576455680,
  "created_at" : "2012-08-20 15:25:25 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Whelton",
      "screen_name" : "jwhelton",
      "indices" : [ 0, 9 ],
      "id_str" : "2216243766",
      "id" : 2216243766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237549062491086849",
  "geo" : { },
  "id_str" : "237570924717674496",
  "in_reply_to_user_id" : 14901457,
  "text" : "@jwhelton ha, thanks. worked on it long ago, it needs serious help but I have too many projects now :(",
  "id" : 237570924717674496,
  "in_reply_to_status_id" : 237549062491086849,
  "created_at" : "2012-08-20 15:24:56 +0000",
  "in_reply_to_screen_name" : "Whelton",
  "in_reply_to_user_id_str" : "14901457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 66, 80 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237569346510139392",
  "text" : "RT @kevinpurdy: Coffee carafe, more mugs, paper towel stockpiles: @coworkbuffalo is basically a 22-year-old filling out its first adult  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 50, 64 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237568623202430976",
    "text" : "Coffee carafe, more mugs, paper towel stockpiles: @coworkbuffalo is basically a 22-year-old filling out its first adult apartment.",
    "id" : 237568623202430976,
    "created_at" : "2012-08-20 15:15:48 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 237569346510139392,
  "created_at" : "2012-08-20 15:18:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237569178150772736",
  "text" : "Current status: \/\/ duraci\u00F3n de la animaci\u00F3n de despliegue al pulsar el bot\u00F3n principal",
  "id" : 237569178150772736,
  "created_at" : "2012-08-20 15:18:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237541220728057857",
  "geo" : { },
  "id_str" : "237542245241331713",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape dude, you have no idea. Get a furminator brush.",
  "id" : 237542245241331713,
  "in_reply_to_status_id" : 237541220728057857,
  "created_at" : "2012-08-20 13:30:59 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237533940246802432",
  "text" : "Oh yeah: Hi Chicago!",
  "id" : 237533940246802432,
  "created_at" : "2012-08-20 12:57:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237530789112315904",
  "geo" : { },
  "id_str" : "237533661124247552",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies just the headphone jack.",
  "id" : 237533661124247552,
  "in_reply_to_status_id" : 237530789112315904,
  "created_at" : "2012-08-20 12:56:52 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237530153343934464",
  "geo" : { },
  "id_str" : "237530375092576256",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase \uD83D\uDC80",
  "id" : 237530375092576256,
  "in_reply_to_status_id" : 237530153343934464,
  "created_at" : "2012-08-20 12:43:49 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237529747725365248",
  "geo" : { },
  "id_str" : "237530266946650112",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar yep!",
  "id" : 237530266946650112,
  "in_reply_to_status_id" : 237529747725365248,
  "created_at" : "2012-08-20 12:43:23 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237528845056614400",
  "text" : "First time listening to the airplane radio on descent. Somehow calmed my flight nerves more than normal, love hearing the pilots and tower.",
  "id" : 237528845056614400,
  "created_at" : "2012-08-20 12:37:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Whelton",
      "screen_name" : "jwhelton",
      "indices" : [ 0, 9 ],
      "id_str" : "2216243766",
      "id" : 2216243766
    }, {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 10, 21 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237368298956800000",
  "geo" : { },
  "id_str" : "237476651380924416",
  "in_reply_to_user_id" : 14901457,
  "text" : "@jwhelton @Alex_Godin if you feel insulted by a Disney teen show, you should feel insulted by a Disney teen show.",
  "id" : 237476651380924416,
  "in_reply_to_status_id" : 237368298956800000,
  "created_at" : "2012-08-20 09:10:20 +0000",
  "in_reply_to_screen_name" : "Whelton",
  "in_reply_to_user_id_str" : "14901457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237395103008817152",
  "geo" : { },
  "id_str" : "237475354103652352",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella congrats dude!!",
  "id" : 237475354103652352,
  "in_reply_to_status_id" : 237395103008817152,
  "created_at" : "2012-08-20 09:05:11 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237393046822608897",
  "text" : "Settled on Quarriors, Guillotine, Citadels, Munchkin, Chrononauts. See you tomorrow Chicago!",
  "id" : 237393046822608897,
  "created_at" : "2012-08-20 03:38:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/237392876361879554\/photo\/1",
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/hbz9V0cU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0tjkDSCEAAthyO.png",
      "id_str" : "237392876374462464",
      "id" : 237392876374462464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0tjkDSCEAAthyO.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hbz9V0cU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237392876361879554",
  "text" : "Possibly the best home screen wallpaper? http:\/\/t.co\/hbz9V0cU",
  "id" : 237392876361879554,
  "created_at" : "2012-08-20 03:37:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237382671209218048",
  "geo" : { },
  "id_str" : "237384278697181184",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried Carlin is the best.",
  "id" : 237384278697181184,
  "in_reply_to_status_id" : 237382671209218048,
  "created_at" : "2012-08-20 03:03:17 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237372213962108929",
  "geo" : { },
  "id_str" : "237382544566390784",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney ah, one of my favorite slave trading^H^H^H^H^H^H^H^H resource building games. Sounds good, Carcassone will stay.",
  "id" : 237382544566390784,
  "in_reply_to_status_id" : 237372213962108929,
  "created_at" : "2012-08-20 02:56:23 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237365753341431808",
  "geo" : { },
  "id_str" : "237366369778278401",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton it's easily the best 6-7 player game I've played so far. The simultaneous turns make it so good and quick.",
  "id" : 237366369778278401,
  "in_reply_to_status_id" : 237365753341431808,
  "created_at" : "2012-08-20 01:52:07 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237365058223620097",
  "geo" : { },
  "id_str" : "237365437833297920",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton oh man...so good but I don't own it. 2 friends do.",
  "id" : 237365437833297920,
  "in_reply_to_status_id" : 237365058223620097,
  "created_at" : "2012-08-20 01:48:25 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237364478382071808",
  "geo" : { },
  "id_str" : "237364980926799872",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton quite fitting but it's so obnoxious to teach",
  "id" : 237364980926799872,
  "in_reply_to_status_id" : 237364478382071808,
  "created_at" : "2012-08-20 01:46:36 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 22, 32 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237364165474385920",
  "text" : "It's time for another @37signals meetup this week. What board games should I pack? Thinking Carcassone, Citadels, Guillotine, Munchkin?",
  "id" : 237364165474385920,
  "created_at" : "2012-08-20 01:43:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/iEbaoxOB",
      "expanded_url" : "http:\/\/instagr.am\/p\/Oh8p-Cs6v7\/",
      "display_url" : "instagr.am\/p\/Oh8p-Cs6v7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "237351365519753216",
  "text" : "Buffalo from Crystal Beach. Such a clear day. http:\/\/t.co\/iEbaoxOB",
  "id" : 237351365519753216,
  "created_at" : "2012-08-20 00:52:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237305143362723840",
  "geo" : { },
  "id_str" : "237310870932316162",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I can't :( enough. :(",
  "id" : 237310870932316162,
  "in_reply_to_status_id" : 237305143362723840,
  "created_at" : "2012-08-19 22:11:35 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/1JuQp0iE",
      "expanded_url" : "http:\/\/instagr.am\/p\/OhLe3ms6km\/",
      "display_url" : "instagr.am\/p\/OhLe3ms6km\/"
    } ]
  },
  "geo" : { },
  "id_str" : "237243128543850496",
  "text" : "Found a 1940s computer. Computing for real! http:\/\/t.co\/1JuQp0iE",
  "id" : 237243128543850496,
  "created_at" : "2012-08-19 17:42:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/iSp73IsF",
      "expanded_url" : "http:\/\/instagr.am\/p\/OhLYB9s6kf\/",
      "display_url" : "instagr.am\/p\/OhLYB9s6kf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "237242810103914496",
  "text" : "Love the loading instructions. http:\/\/t.co\/iSp73IsF",
  "id" : 237242810103914496,
  "created_at" : "2012-08-19 17:41:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olaf Delgado",
      "screen_name" : "olafdf",
      "indices" : [ 0, 7 ],
      "id_str" : "312993932",
      "id" : 312993932
    }, {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 8, 16 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237090615979020288",
  "geo" : { },
  "id_str" : "237218337086656512",
  "in_reply_to_user_id" : 312993932,
  "text" : "@olafdf @zedshaw totally agree. Go's for loop makes me weep in its simplicity.",
  "id" : 237218337086656512,
  "in_reply_to_status_id" : 237090615979020288,
  "created_at" : "2012-08-19 16:03:53 +0000",
  "in_reply_to_screen_name" : "olafdf",
  "in_reply_to_user_id_str" : "312993932",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 52, 62 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/FoodNDHY",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/08\/19\/opinion\/sunday\/be-more-productive-shorten-the-workweek.html",
      "display_url" : "nytimes.com\/2012\/08\/19\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237199556914327553",
  "text" : "All of this and more is why I'm super proud to work @37signals: http:\/\/t.co\/FoodNDHY",
  "id" : 237199556914327553,
  "created_at" : "2012-08-19 14:49:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/237033420251877376\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/eEBZnCWH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0oco85CUAE1_6H.png",
      "id_str" : "237033420256071681",
      "id" : 237033420256071681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0oco85CUAE1_6H.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 712,
        "resize" : "fit",
        "w" : 392
      }, {
        "h" : 712,
        "resize" : "fit",
        "w" : 392
      }, {
        "h" : 712,
        "resize" : "fit",
        "w" : 392
      }, {
        "h" : 617,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eEBZnCWH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237033420251877376",
  "text" : "And today we learned that after 10 replies in a twitter conversation, a dingdong will appear. http:\/\/t.co\/eEBZnCWH",
  "id" : 237033420251877376,
  "created_at" : "2012-08-19 03:49:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0425\u043B\u0443\u0434\u0435\u0432a \u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0430",
      "screen_name" : "casualpro",
      "indices" : [ 0, 10 ],
      "id_str" : "2815471651",
      "id" : 2815471651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237031714403262467",
  "geo" : { },
  "id_str" : "237032054448074752",
  "in_reply_to_user_id" : 120837801,
  "text" : "@casualpro Harborcreek, PA.",
  "id" : 237032054448074752,
  "in_reply_to_status_id" : 237031714403262467,
  "created_at" : "2012-08-19 03:43:40 +0000",
  "in_reply_to_screen_name" : "davejachimiak",
  "in_reply_to_user_id_str" : "120837801",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 7, 14 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/HFLWx6zY",
      "expanded_url" : "http:\/\/app.net\/about\/",
      "display_url" : "app.net\/about\/"
    } ]
  },
  "in_reply_to_status_id_str" : "237028494897475586",
  "geo" : { },
  "id_str" : "237028884296634368",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz @holman totally thought they were bootstrapping. LOL NOPE http:\/\/t.co\/HFLWx6zY",
  "id" : 237028884296634368,
  "in_reply_to_status_id" : 237028494897475586,
  "created_at" : "2012-08-19 03:31:04 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237025031060860928",
  "geo" : { },
  "id_str" : "237025888045264897",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I don't see how this is relevant. they would want money.",
  "id" : 237025888045264897,
  "in_reply_to_status_id" : 237025031060860928,
  "created_at" : "2012-08-19 03:19:10 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237025076443226112",
  "geo" : { },
  "id_str" : "237025595614167040",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier wat? \"give money for soon-to-be-real thing\" is a standard, normal concept. Think of the dopes giving $50 for gold coins.",
  "id" : 237025595614167040,
  "in_reply_to_status_id" : 237025076443226112,
  "created_at" : "2012-08-19 03:18:00 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Junayeed Ahnaf",
      "screen_name" : "Nirjhor",
      "indices" : [ 0, 8 ],
      "id_str" : "15859693",
      "id" : 15859693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237024844737286144",
  "geo" : { },
  "id_str" : "237025124824522752",
  "in_reply_to_user_id" : 15859693,
  "text" : "@Nirjhor who cares about this? I certainly don't. It's a tweet, they don't matter.",
  "id" : 237025124824522752,
  "in_reply_to_status_id" : 237024844737286144,
  "created_at" : "2012-08-19 03:16:08 +0000",
  "in_reply_to_screen_name" : "Nirjhor",
  "in_reply_to_user_id_str" : "15859693",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237024426745536512",
  "geo" : { },
  "id_str" : "237024645449125888",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes they really haven't. on desktop I use the web client, but they're rarely an issue.",
  "id" : 237024645449125888,
  "in_reply_to_status_id" : 237024426745536512,
  "created_at" : "2012-08-19 03:14:13 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 1, 21 ],
      "url" : "http:\/\/t.co\/H9WUYPCv",
      "expanded_url" : "http:\/\/App.net",
      "display_url" : "App.net"
    } ]
  },
  "geo" : { },
  "id_str" : "237024534224572416",
  "text" : "\"http:\/\/t.co\/H9WUYPCv is a real-time social feed without the ads.\" No normal person would ever understand what this means.",
  "id" : 237024534224572416,
  "created_at" : "2012-08-19 03:13:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Grn7N8Ce",
      "expanded_url" : "http:\/\/app.net",
      "display_url" : "app.net"
    } ]
  },
  "geo" : { },
  "id_str" : "237024130870947840",
  "text" : "So can someone confirm that http:\/\/t.co\/Grn7N8Ce is just twitter, just $50, and no ads? Why can't I just give that money to twitter?",
  "id" : 237024130870947840,
  "created_at" : "2012-08-19 03:12:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 14, 28 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237002656084799488",
  "geo" : { },
  "id_str" : "237003062160523264",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @garybernhardt :( programming is hard, let's go shopping. No, seriously. Getting stressed about this stuff is not worth it :)",
  "id" : 237003062160523264,
  "in_reply_to_status_id" : 237002656084799488,
  "created_at" : "2012-08-19 01:48:27 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236996413702148097",
  "geo" : { },
  "id_str" : "237001999957258240",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt also, this is why bundler should be used for any ruby project. Gemfile everywhere and this problem doesn't happen.",
  "id" : 237001999957258240,
  "in_reply_to_status_id" : 236996413702148097,
  "created_at" : "2012-08-19 01:44:14 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236996521206353921",
  "geo" : { },
  "id_str" : "236998091897729026",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt make something better, do it! In the meantime, I don't enjoy paying for hosting and i like the push workflow.",
  "id" : 236998091897729026,
  "in_reply_to_status_id" : 236996521206353921,
  "created_at" : "2012-08-19 01:28:42 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236996521206353921",
  "geo" : { },
  "id_str" : "236997772593737728",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt yep, it's a fragile beast. Meant to run in a hindered\/protected state thanks to GH pages.",
  "id" : 236997772593737728,
  "in_reply_to_status_id" : 236996521206353921,
  "created_at" : "2012-08-19 01:27:26 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236995878215352320",
  "geo" : { },
  "id_str" : "236996167337140225",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt you can't run Jekyll locally? That's the entire point of that gem. I can help you with it once I'm home.",
  "id" : 236996167337140225,
  "in_reply_to_status_id" : 236995878215352320,
  "created_at" : "2012-08-19 01:21:04 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236995275644882944",
  "geo" : { },
  "id_str" : "236995653320994817",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt what does this do over github pages? Just email?",
  "id" : 236995653320994817,
  "in_reply_to_status_id" : 236995275644882944,
  "created_at" : "2012-08-19 01:19:01 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236978411602595840",
  "geo" : { },
  "id_str" : "236986398039744512",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten a hidden path through a subdivision that requires climbing down 10' of rock is definitely secret.",
  "id" : 236986398039744512,
  "in_reply_to_status_id" : 236978411602595840,
  "created_at" : "2012-08-19 00:42:14 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/eTeA7DC2",
      "expanded_url" : "http:\/\/instagr.am\/p\/OfTXebs6oY\/",
      "display_url" : "instagr.am\/p\/OfTXebs6oY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236978888452997120",
  "text" : "Secret Lake Erie. Part 3. http:\/\/t.co\/eTeA7DC2",
  "id" : 236978888452997120,
  "created_at" : "2012-08-19 00:12:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/eoQWUuYy",
      "expanded_url" : "http:\/\/instagr.am\/p\/OfTQqds6oS\/",
      "display_url" : "instagr.am\/p\/OfTQqds6oS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236978643086213120",
  "text" : "Secret Lake Erie, part 2 http:\/\/t.co\/eoQWUuYy",
  "id" : 236978643086213120,
  "created_at" : "2012-08-19 00:11:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/nqFWLo8c",
      "expanded_url" : "http:\/\/instagr.am\/p\/OfTDUcM6oG\/",
      "display_url" : "instagr.am\/p\/OfTDUcM6oG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236978202294243329",
  "text" : "Secret Lake Erie part 1! http:\/\/t.co\/nqFWLo8c",
  "id" : 236978202294243329,
  "created_at" : "2012-08-19 00:09:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HI\u039BTVS",
      "screen_name" : "inky",
      "indices" : [ 0, 5 ],
      "id_str" : "13148",
      "id" : 13148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236941473537466368",
  "geo" : { },
  "id_str" : "236941736587427840",
  "in_reply_to_user_id" : 13148,
  "text" : "@inky the graphic novel is awesome. Same with V for Vendetta.",
  "id" : 236941736587427840,
  "in_reply_to_status_id" : 236941473537466368,
  "created_at" : "2012-08-18 21:44:46 +0000",
  "in_reply_to_screen_name" : "inky",
  "in_reply_to_user_id_str" : "13148",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Klett",
      "screen_name" : "moklett",
      "indices" : [ 0, 8 ],
      "id_str" : "14792320",
      "id" : 14792320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236872477526085633",
  "geo" : { },
  "id_str" : "236878113689190401",
  "in_reply_to_user_id" : 14792320,
  "text" : "@moklett nope. Crystal Beach, ON.",
  "id" : 236878113689190401,
  "in_reply_to_status_id" : 236872477526085633,
  "created_at" : "2012-08-18 17:31:57 +0000",
  "in_reply_to_screen_name" : "moklett",
  "in_reply_to_user_id_str" : "14792320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/1LlYVrYH",
      "expanded_url" : "http:\/\/instagr.am\/p\/OehXM6M6uw\/",
      "display_url" : "instagr.am\/p\/OehXM6M6uw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236868937621573633",
  "text" : "I love seeing old junk in antique stores. http:\/\/t.co\/1LlYVrYH",
  "id" : 236868937621573633,
  "created_at" : "2012-08-18 16:55:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236706426565832704",
  "text" : "RT @sstephenson: Not to defend Twitter, but step back from our little tech bubble and I bet you\u2019ll find most people have no idea what a  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236321886408146944",
    "text" : "Not to defend Twitter, but step back from our little tech bubble and I bet you\u2019ll find most people have no idea what a \u201C3rd party client\u201D is",
    "id" : 236321886408146944,
    "created_at" : "2012-08-17 04:41:43 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 236706426565832704,
  "created_at" : "2012-08-18 06:09:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236626975253471232",
  "text" : "Witnessed my first Kanjam slot win. I lost.",
  "id" : 236626975253471232,
  "created_at" : "2012-08-18 00:54:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 7, 20 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/SaWW7p5I",
      "expanded_url" : "http:\/\/instagr.am\/p\/OcLddalJLH\/",
      "display_url" : "instagr.am\/p\/OcLddalJLH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236585366298173440",
  "text" : "Thanks @steveklabnik for saying what ought to be said: http:\/\/t.co\/SaWW7p5I",
  "id" : 236585366298173440,
  "created_at" : "2012-08-17 22:08:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 3, 10 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 37, 50 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/xgRTlTKv",
      "expanded_url" : "http:\/\/instagr.am\/p\/OcLddalJLH\/",
      "display_url" : "instagr.am\/p\/OcLddalJLH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236585253886636032",
  "text" : "RT @sferik: Biggest applause line of @steveklabnik's talk  @ Hotel M\u00FCggelsee http:\/\/t.co\/xgRTlTKv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Dream of the 90s",
        "screen_name" : "steveklabnik",
        "indices" : [ 25, 38 ],
        "id_str" : "22386062",
        "id" : 22386062
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/xgRTlTKv",
        "expanded_url" : "http:\/\/instagr.am\/p\/OcLddalJLH\/",
        "display_url" : "instagr.am\/p\/OcLddalJLH\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.4258465741, 13.6414790154 ]
    },
    "id_str" : "236540210278723584",
    "text" : "Biggest applause line of @steveklabnik's talk  @ Hotel M\u00FCggelsee http:\/\/t.co\/xgRTlTKv",
    "id" : 236540210278723584,
    "created_at" : "2012-08-17 19:09:15 +0000",
    "user" : {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "protected" : false,
      "id_str" : "7505382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567932260847206401\/ErQwT5za_normal.jpeg",
      "id" : 7505382,
      "verified" : false
    }
  },
  "id" : 236585253886636032,
  "created_at" : "2012-08-17 22:08:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236496322700660737",
  "geo" : { },
  "id_str" : "236496705128914944",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k heck yes!",
  "id" : 236496705128914944,
  "in_reply_to_status_id" : 236496322700660737,
  "created_at" : "2012-08-17 16:16:23 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236490559601123328",
  "geo" : { },
  "id_str" : "236490838950170624",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini the exist public projects also have developers in them...they're one and the same.",
  "id" : 236490838950170624,
  "in_reply_to_status_id" : 236490559601123328,
  "created_at" : "2012-08-17 15:53:04 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236489251460632577",
  "geo" : { },
  "id_str" : "236490161729466371",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini we typically would kick that off in basecamp then, link the code via github.",
  "id" : 236490161729466371,
  "in_reply_to_status_id" : 236489251460632577,
  "created_at" : "2012-08-17 15:50:22 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236488603646185473",
  "geo" : { },
  "id_str" : "236489006085455872",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini code reviews stay where the code is.",
  "id" : 236489006085455872,
  "in_reply_to_status_id" : 236488603646185473,
  "created_at" : "2012-08-17 15:45:47 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Akins",
      "screen_name" : "akinsgre",
      "indices" : [ 0, 9 ],
      "id_str" : "3543711",
      "id" : 3543711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236488561224994816",
  "geo" : { },
  "id_str" : "236488966797414400",
  "in_reply_to_user_id" : 3543711,
  "text" : "@akinsgre we're back up, but `gem install` should work as normal.",
  "id" : 236488966797414400,
  "in_reply_to_status_id" : 236488561224994816,
  "created_at" : "2012-08-17 15:45:38 +0000",
  "in_reply_to_screen_name" : "akinsgre",
  "in_reply_to_user_id_str" : "3543711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236488339476344832",
  "geo" : { },
  "id_str" : "236488449018961920",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini pull requests.",
  "id" : 236488449018961920,
  "in_reply_to_status_id" : 236488339476344832,
  "created_at" : "2012-08-17 15:43:34 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236482652801216512",
  "text" : "RT @rubygems_status: Ok, everything is back! Sorry for the outage folks. We're going to be doing a post-mortem today and get things back ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236481467914526720",
    "text" : "Ok, everything is back! Sorry for the outage folks. We're going to be doing a post-mortem today and get things back in order.",
    "id" : 236481467914526720,
    "created_at" : "2012-08-17 15:15:50 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 236482652801216512,
  "created_at" : "2012-08-17 15:20:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236475858821447680",
  "geo" : { },
  "id_str" : "236477435875557376",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx oh nice! Still going to hack on a non-redis mode.",
  "id" : 236477435875557376,
  "in_reply_to_status_id" : 236475858821447680,
  "created_at" : "2012-08-17 14:59:48 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Akins",
      "screen_name" : "akinsgre",
      "indices" : [ 0, 9 ],
      "id_str" : "3543711",
      "id" : 3543711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236476736378925056",
  "geo" : { },
  "id_str" : "236476953241219073",
  "in_reply_to_user_id" : 3543711,
  "text" : "@akinsgre what are you SOL with?",
  "id" : 236476953241219073,
  "in_reply_to_status_id" : 236476736378925056,
  "created_at" : "2012-08-17 14:57:53 +0000",
  "in_reply_to_screen_name" : "akinsgre",
  "in_reply_to_user_id_str" : "3543711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "Rails Girls Berlin",
      "screen_name" : "railsgirls_bln",
      "indices" : [ 17, 32 ],
      "id_str" : "553622948",
      "id" : 553622948
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 33, 41 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236472713701621761",
  "geo" : { },
  "id_str" : "236472917091819520",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase @railsgirls_bln @evanphx could be hours, not sure right now. trying to get the pages back up sans redis.",
  "id" : 236472917091819520,
  "in_reply_to_status_id" : 236472713701621761,
  "created_at" : "2012-08-17 14:41:51 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "djeisyn.luys.",
      "screen_name" : "canweriotnow",
      "indices" : [ 0, 13 ],
      "id_str" : "158606135",
      "id" : 158606135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236471703469953024",
  "geo" : { },
  "id_str" : "236471914607030272",
  "in_reply_to_user_id" : 158606135,
  "text" : "@canweriotnow bundle install should still work. is it not?",
  "id" : 236471914607030272,
  "in_reply_to_status_id" : 236471703469953024,
  "created_at" : "2012-08-17 14:37:52 +0000",
  "in_reply_to_screen_name" : "canweriotnow",
  "in_reply_to_user_id_str" : "158606135",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 54, 62 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236470485834162177",
  "geo" : { },
  "id_str" : "236470706420973568",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH Wow that looks complicated. ops stuff is up to @evanphx.",
  "id" : 236470706420973568,
  "in_reply_to_status_id" : 236470485834162177,
  "created_at" : "2012-08-17 14:33:04 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "236470285027663872",
  "text" : "Hey folks, http:\/\/t.co\/bdjsRgTW is down. We're going to try to get the site's pages back up while Redis is still restoring. Hold on!",
  "id" : 236470285027663872,
  "created_at" : "2012-08-17 14:31:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "404",
      "screen_name" : "why404",
      "indices" : [ 0, 7 ],
      "id_str" : "28538150",
      "id" : 28538150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236463732958572544",
  "geo" : { },
  "id_str" : "236467384230236160",
  "in_reply_to_user_id" : 28538150,
  "text" : "@why404 yeah, sorry...the \"new\" API (Gemcutter's) won't be back online until the site is. we're in read-only mode right now.",
  "id" : 236467384230236160,
  "in_reply_to_status_id" : 236463732958572544,
  "created_at" : "2012-08-17 14:19:52 +0000",
  "in_reply_to_screen_name" : "why404",
  "in_reply_to_user_id_str" : "28538150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wood",
      "screen_name" : "JellybobUK",
      "indices" : [ 0, 11 ],
      "id_str" : "16557322",
      "id" : 16557322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236466614210527235",
  "geo" : { },
  "id_str" : "236467288797237248",
  "in_reply_to_user_id" : 16557322,
  "text" : "@JellybobUK gem fetching\/installing\/bundling should all be working....is something not?",
  "id" : 236467288797237248,
  "in_reply_to_status_id" : 236466614210527235,
  "created_at" : "2012-08-17 14:19:29 +0000",
  "in_reply_to_screen_name" : "JellybobUK",
  "in_reply_to_user_id_str" : "16557322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/CvmVYTAs",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dJs5zPYw",
      "expanded_url" : "http:\/\/status.rubygems.org",
      "display_url" : "status.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "236466240804253698",
  "text" : "RT @rubygems_status: Partial outage effecting http:\/\/t.co\/CvmVYTAs going on now. Working to restore access, could be a few hours. Watch  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/CvmVYTAs",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      }, {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/dJs5zPYw",
        "expanded_url" : "http:\/\/status.rubygems.org",
        "display_url" : "status.rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "236440884663697408",
    "text" : "Partial outage effecting http:\/\/t.co\/CvmVYTAs going on now. Working to restore access, could be a few hours. Watch http:\/\/t.co\/dJs5zPYw.",
    "id" : 236440884663697408,
    "created_at" : "2012-08-17 12:34:34 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 236466240804253698,
  "created_at" : "2012-08-17 14:15:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 3, 10 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/AVDl0tcw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Q_RpbaUU7NI",
      "display_url" : "youtube.com\/watch?v=Q_Rpba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236464759569014784",
  "text" : "RT @jmazzi: This is your periodic reminder that swords are dangerous http:\/\/t.co\/AVDl0tcw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/AVDl0tcw",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Q_RpbaUU7NI",
        "display_url" : "youtube.com\/watch?v=Q_Rpba\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "236463104907681792",
    "text" : "This is your periodic reminder that swords are dangerous http:\/\/t.co\/AVDl0tcw",
    "id" : 236463104907681792,
    "created_at" : "2012-08-17 14:02:52 +0000",
    "user" : {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "protected" : false,
      "id_str" : "15395778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413712456620322816\/Ki1bebJu_normal.jpeg",
      "id" : 15395778,
      "verified" : false
    }
  },
  "id" : 236464759569014784,
  "created_at" : "2012-08-17 14:09:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "Rails Girls Berlin",
      "screen_name" : "railsgirls_bln",
      "indices" : [ 17, 32 ],
      "id_str" : "553622948",
      "id" : 553622948
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 80, 88 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236436984170692609",
  "geo" : { },
  "id_str" : "236461958973517824",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase @railsgirls_bln sorry just woke up. Looks like we crashed? \/cc @evanphx",
  "id" : 236461958973517824,
  "in_reply_to_status_id" : 236436984170692609,
  "created_at" : "2012-08-17 13:58:18 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/yMFDIUkD",
      "expanded_url" : "http:\/\/instagr.am\/p\/OansyLM6va\/",
      "display_url" : "instagr.am\/p\/OansyLM6va\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236319878787760128",
  "text" : "Carcassone! http:\/\/t.co\/yMFDIUkD",
  "id" : 236319878787760128,
  "created_at" : "2012-08-17 04:33:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 4, 9 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 10, 21 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 22, 35 ],
      "id_str" : "23820237",
      "id" : 23820237
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 36, 51 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 52, 58 ],
      "id_str" : "34287352",
      "id" : 34287352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236236787780042752",
  "text" : "Hey @jhsu @Jonplussed @IanCAnderson @1ofyourmeteors @byllc board games at my place tonight? DM me if you want to come over!",
  "id" : 236236787780042752,
  "created_at" : "2012-08-16 23:03:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 3, 13 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "Massively Fun",
      "screen_name" : "massivelyfun",
      "indices" : [ 45, 58 ],
      "id_str" : "206341251",
      "id" : 206341251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/ahNzUClj",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/massively-fun-sets-sail-settlers-catan-game",
      "display_url" : "geekwire.com\/2012\/massively\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236124334417145857",
  "text" : "RT @bleything: I see that my friends over at @massivelyfun have announced their Catan game! http:\/\/t.co\/ahNzUClj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Massively Fun",
        "screen_name" : "massivelyfun",
        "indices" : [ 30, 43 ],
        "id_str" : "206341251",
        "id" : 206341251
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/ahNzUClj",
        "expanded_url" : "http:\/\/www.geekwire.com\/2012\/massively-fun-sets-sail-settlers-catan-game",
        "display_url" : "geekwire.com\/2012\/massively\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "236123874377494528",
    "text" : "I see that my friends over at @massivelyfun have announced their Catan game! http:\/\/t.co\/ahNzUClj",
    "id" : 236123874377494528,
    "created_at" : "2012-08-16 15:34:53 +0000",
    "user" : {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "protected" : false,
      "id_str" : "823615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1260090298\/foo_normal.png",
      "id" : 823615,
      "verified" : false
    }
  },
  "id" : 236124334417145857,
  "created_at" : "2012-08-16 15:36:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235985682521276416",
  "text" : "Late night porch \/r\/buffalo meetup in the EV. Love this town and this community. So glad I'm in Buffalo.",
  "id" : 235985682521276416,
  "created_at" : "2012-08-16 06:25:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/T0GdvUEn",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9bZkp7q19f0",
      "display_url" : "youtube.com\/watch?v=9bZkp7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235929300145143808",
  "text" : "Current status: http:\/\/t.co\/T0GdvUEn",
  "id" : 235929300145143808,
  "created_at" : "2012-08-16 02:41:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235817376006955008",
  "geo" : { },
  "id_str" : "235880334116388865",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh been hopping the border every day this week. Canada side is much nicer and well put together. Not just the people but the surroundings.",
  "id" : 235880334116388865,
  "in_reply_to_status_id" : 235817376006955008,
  "created_at" : "2012-08-15 23:27:08 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235879463513100288",
  "text" : "OH 'Showed my boss my code on github today, she says, \"Why did you spend so much time coloring all of these words?\"'",
  "id" : 235879463513100288,
  "created_at" : "2012-08-15 23:23:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235747291099697152",
  "geo" : { },
  "id_str" : "235752182689976320",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson SO ADVANCED",
  "id" : 235752182689976320,
  "in_reply_to_status_id" : 235747291099697152,
  "created_at" : "2012-08-15 14:57:55 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackernews",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/vz61rzTY",
      "expanded_url" : "http:\/\/images.apple.com\/mac\/home\/images\/productbrowser\/macbookpro.jpg",
      "display_url" : "images.apple.com\/mac\/home\/image\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235752141501906944",
  "text" : "RT @sstephenson: Check out my new single-element, pure CSS MacBook Pro. #hackernews \u007B width: 130px; height: 130px; background: url(http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hackernews",
        "indices" : [ 55, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/vz61rzTY",
        "expanded_url" : "http:\/\/images.apple.com\/mac\/home\/images\/productbrowser\/macbookpro.jpg",
        "display_url" : "images.apple.com\/mac\/home\/image\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "235747291099697152",
    "text" : "Check out my new single-element, pure CSS MacBook Pro. #hackernews \u007B width: 130px; height: 130px; background: url(http:\/\/t.co\/vz61rzTY) \u007D",
    "id" : 235747291099697152,
    "created_at" : "2012-08-15 14:38:28 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 235752141501906944,
  "created_at" : "2012-08-15 14:57:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/K5BU0u3g",
      "expanded_url" : "http:\/\/worldofsu.com\/philipsu\/2012\/08\/ten-things-i-hate-about-working-at-facebook\/",
      "display_url" : "worldofsu.com\/philipsu\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235561943790936064",
  "text" : "\u0CA0_\u0CA0 \"There is a fully-working hot tub in the New York office that interviews are conducted in.\" http:\/\/t.co\/K5BU0u3g",
  "id" : 235561943790936064,
  "created_at" : "2012-08-15 02:21:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Gaynor",
      "screen_name" : "alex_gaynor",
      "indices" : [ 0, 12 ],
      "id_str" : "14635493",
      "id" : 14635493
    }, {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 13, 20 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235481604821241856",
  "geo" : { },
  "id_str" : "235542892939198465",
  "in_reply_to_user_id" : 14635493,
  "text" : "@alex_gaynor @jmazzi why is this significant?",
  "id" : 235542892939198465,
  "in_reply_to_status_id" : 235481604821241856,
  "created_at" : "2012-08-15 01:06:16 +0000",
  "in_reply_to_screen_name" : "alex_gaynor",
  "in_reply_to_user_id_str" : "14635493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235533265564467200",
  "geo" : { },
  "id_str" : "235535049997561857",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Y U NO AT WNYRUBY?",
  "id" : 235535049997561857,
  "in_reply_to_status_id" : 235533265564467200,
  "created_at" : "2012-08-15 00:35:06 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235377836259692545",
  "geo" : { },
  "id_str" : "235381594930679808",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV the receipts are the worst.",
  "id" : 235381594930679808,
  "in_reply_to_status_id" : 235377836259692545,
  "created_at" : "2012-08-14 14:25:20 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 3, 16 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/hcgFBhyR",
      "expanded_url" : "http:\/\/richkidsofinstagram.tumblr.com",
      "display_url" : "richkidsofinstagram.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "235381542191497216",
  "text" : "RT @ChrisSmithAV: Holy shit, this is enraging. http:\/\/t.co\/hcgFBhyR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/hcgFBhyR",
        "expanded_url" : "http:\/\/richkidsofinstagram.tumblr.com",
        "display_url" : "richkidsofinstagram.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "235377836259692545",
    "text" : "Holy shit, this is enraging. http:\/\/t.co\/hcgFBhyR",
    "id" : 235377836259692545,
    "created_at" : "2012-08-14 14:10:23 +0000",
    "user" : {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "protected" : true,
      "id_str" : "5911122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563454542260359168\/QWS_s6Pd_normal.png",
      "id" : 5911122,
      "verified" : false
    }
  },
  "id" : 235381542191497216,
  "created_at" : "2012-08-14 14:25:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235354937377316864",
  "geo" : { },
  "id_str" : "235359729046671360",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant holy crap dude. Did a car flip?",
  "id" : 235359729046671360,
  "in_reply_to_status_id" : 235354937377316864,
  "created_at" : "2012-08-14 12:58:26 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "imagetic",
      "screen_name" : "imagetic",
      "indices" : [ 0, 9 ],
      "id_str" : "2542507225",
      "id" : 2542507225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235232648434442240",
  "geo" : { },
  "id_str" : "235233120088104960",
  "in_reply_to_user_id" : 5508892,
  "text" : "@imagetic very much yes. They still have a block on outgoing links.",
  "id" : 235233120088104960,
  "in_reply_to_status_id" : 235232648434442240,
  "created_at" : "2012-08-14 04:35:20 +0000",
  "in_reply_to_screen_name" : "willduncanphoto",
  "in_reply_to_user_id_str" : "5508892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 12, 22 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235229116587188224",
  "geo" : { },
  "id_str" : "235229829149110272",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @listrophy dress as giant injured turkey; pour gravy all over self in oversized bowl; throw prethanksgiving party in August",
  "id" : 235229829149110272,
  "in_reply_to_status_id" : 235229116587188224,
  "created_at" : "2012-08-14 04:22:16 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235185222205992962",
  "geo" : { },
  "id_str" : "235185603531137024",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine the amount of pointy objects that flopped out of the bag was scary. it's just an umbrella!",
  "id" : 235185603531137024,
  "in_reply_to_status_id" : 235185222205992962,
  "created_at" : "2012-08-14 01:26:32 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235184348633124864",
  "geo" : { },
  "id_str" : "235184600421392384",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine it was, property of my aunt's. quite a complicated beast.",
  "id" : 235184600421392384,
  "in_reply_to_status_id" : 235184348633124864,
  "created_at" : "2012-08-14 01:22:32 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235182402304106496",
  "geo" : { },
  "id_str" : "235184354702262274",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH oh snap!",
  "id" : 235184354702262274,
  "in_reply_to_status_id" : 235182402304106496,
  "created_at" : "2012-08-14 01:21:34 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 25, 35 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235182494427799552",
  "text" : "Also, super proud to see @aquaranto on stage for MagicRuby. Woot!",
  "id" : 235182494427799552,
  "created_at" : "2012-08-14 01:14:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Rim40VSR",
      "expanded_url" : "http:\/\/magic-ruby.com\/",
      "display_url" : "magic-ruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "235182044496412672",
  "text" : "Registered for MagicRuby. Heck yeah Disney! http:\/\/t.co\/Rim40VSR",
  "id" : 235182044496412672,
  "created_at" : "2012-08-14 01:12:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235115620755189760",
  "geo" : { },
  "id_str" : "235176452423835649",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi thanks for the kind words :)",
  "id" : 235176452423835649,
  "in_reply_to_status_id" : 235115620755189760,
  "created_at" : "2012-08-14 00:50:10 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/2ETpXF4G",
      "expanded_url" : "http:\/\/instagr.am\/p\/OSfUFQM6os\/",
      "display_url" : "instagr.am\/p\/OSfUFQM6os\/"
    } ]
  },
  "geo" : { },
  "id_str" : "235175643736854528",
  "text" : "Crystal Beach, Day 1. Love that this is 30 minutes from Buffalo. http:\/\/t.co\/2ETpXF4G",
  "id" : 235175643736854528,
  "created_at" : "2012-08-14 00:46:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235027774635638785",
  "geo" : { },
  "id_str" : "235031000361598976",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape on vacation this week. Shoot me an email.",
  "id" : 235031000361598976,
  "in_reply_to_status_id" : 235027774635638785,
  "created_at" : "2012-08-13 15:12:11 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 90, 104 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/234812447943438336\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/DwQ2EQEa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0I4rWUCMAAGyLa.jpg",
      "id_str" : "234812447951826944",
      "id" : 234812447951826944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0I4rWUCMAAGyLa.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DwQ2EQEa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234812447943438336",
  "text" : "Went a little overboard at the dime toss. This picture is missing 2 glasses as well. Yay, @coworkbuffalo has new mugs! http:\/\/t.co\/DwQ2EQEa",
  "id" : 234812447943438336,
  "created_at" : "2012-08-13 00:43:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 27, 32 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/234772442697043969\/photo\/1",
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/7M4z7lnB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0IUSvJCEAE-N9v.jpg",
      "id_str" : "234772442701238273",
      "id" : 234772442701238273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0IUSvJCEAE-N9v.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7M4z7lnB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234772442697043969",
  "text" : "TNG Bridge playset, but no @wilw :( http:\/\/t.co\/7M4z7lnB",
  "id" : 234772442697043969,
  "created_at" : "2012-08-12 22:04:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/234766859524771841\/photo\/1",
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/g7HS8Kdb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0IPN0VCEAAYA6E.jpg",
      "id_str" : "234766860636262400",
      "id" : 234766860636262400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0IPN0VCEAAYA6E.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/g7HS8Kdb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234766859524771841",
  "text" : "Apparently someone got a prize for putting together a Lego set. http:\/\/t.co\/g7HS8Kdb",
  "id" : 234766859524771841,
  "created_at" : "2012-08-12 21:42:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234763414839361537",
  "geo" : { },
  "id_str" : "234765059899924480",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten yes but haven't seen any on a human",
  "id" : 234765059899924480,
  "in_reply_to_status_id" : 234763414839361537,
  "created_at" : "2012-08-12 21:35:26 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stupidshirtsatthefair",
      "indices" : [ 102, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234762988626784257",
  "text" : "If you like these guns (arrows pointing at arms) I'll give you this rocket (arrow pointing at crotch) #stupidshirtsatthefair",
  "id" : 234762988626784257,
  "created_at" : "2012-08-12 21:27:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stupidshirtsatthefair",
      "indices" : [ 16, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234762788722053120",
  "text" : "SWAG\nOVER\nLOAD\n\n#stupidshirtsatthefair",
  "id" : 234762788722053120,
  "created_at" : "2012-08-12 21:26:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 37, 48 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/YdRe9t31",
      "expanded_url" : "http:\/\/4sq.com\/Pbo8uo",
      "display_url" : "4sq.com\/Pbo8uo"
    } ]
  },
  "geo" : { },
  "id_str" : "234727578420776960",
  "text" : "I just unlocked the \"Swarm\" badge on @foursquare! http:\/\/t.co\/YdRe9t31",
  "id" : 234727578420776960,
  "created_at" : "2012-08-12 19:06:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/vJuYeTAr",
      "expanded_url" : "http:\/\/4sq.com\/PboaT4",
      "display_url" : "4sq.com\/PboaT4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.7366427979, -78.8194799423 ]
  },
  "id_str" : "234727580966744065",
  "text" : "Erie County Fair time! (@ Erie County Fairgrounds w\/ 50 others) http:\/\/t.co\/vJuYeTAr",
  "id" : 234727580966744065,
  "created_at" : "2012-08-12 19:06:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 3, 14 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/kJ1rvUQI",
      "expanded_url" : "http:\/\/app.net",
      "display_url" : "app.net"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/xgFPD7H8",
      "expanded_url" : "http:\/\/twitpic.com\/aijiq1",
      "display_url" : "twitpic.com\/aijiq1"
    } ]
  },
  "geo" : { },
  "id_str" : "234653140325122049",
  "text" : "RT @shanselman: There's something about the http:\/\/t.co\/kJ1rvUQI demographic...I can't put my finger on it... http:\/\/t.co\/xgFPD7H8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/kJ1rvUQI",
        "expanded_url" : "http:\/\/app.net",
        "display_url" : "app.net"
      }, {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/xgFPD7H8",
        "expanded_url" : "http:\/\/twitpic.com\/aijiq1",
        "display_url" : "twitpic.com\/aijiq1"
      } ]
    },
    "geo" : { },
    "id_str" : "234651164774395904",
    "text" : "There's something about the http:\/\/t.co\/kJ1rvUQI demographic...I can't put my finger on it... http:\/\/t.co\/xgFPD7H8",
    "id" : 234651164774395904,
    "created_at" : "2012-08-12 14:02:51 +0000",
    "user" : {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "protected" : false,
      "id_str" : "5676102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459455847165218816\/I_sH-zvU_normal.jpeg",
      "id" : 5676102,
      "verified" : true
    }
  },
  "id" : 234653140325122049,
  "created_at" : "2012-08-12 14:10:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 6, 19 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234513329677299712",
  "geo" : { },
  "id_str" : "234520445683109888",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @steveklabnik TLDR, neckbeards gonna neckbeard. I feel bad for anyone who uses this guy's projects and wants to contribute.",
  "id" : 234520445683109888,
  "in_reply_to_status_id" : 234513329677299712,
  "created_at" : "2012-08-12 05:23:26 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234470888341377025",
  "text" : "OH: \"If you can suck N nuts, you would suck N+1 nuts\"",
  "id" : 234470888341377025,
  "created_at" : "2012-08-12 02:06:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234459692070494208",
  "text" : "OH \"I'm going to take this tub of ice cream and eat it in the hot hub\" \"who are you, Hedonism Bot?\"",
  "id" : 234459692070494208,
  "created_at" : "2012-08-12 01:22:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234435695530348544",
  "text" : "What's the correct\/funny response to \"damn I'm old\"? Yes, this is for an obnoxious twitter bot.",
  "id" : 234435695530348544,
  "created_at" : "2012-08-11 23:46:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian",
      "screen_name" : "jnx",
      "indices" : [ 0, 4 ],
      "id_str" : "8029592",
      "id" : 8029592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234394613799075841",
  "geo" : { },
  "id_str" : "234397353761730560",
  "in_reply_to_user_id" : 8029592,
  "text" : "@jnx Zoar Valley, NY.",
  "id" : 234397353761730560,
  "in_reply_to_status_id" : 234394613799075841,
  "created_at" : "2012-08-11 21:14:18 +0000",
  "in_reply_to_screen_name" : "jnx",
  "in_reply_to_user_id_str" : "8029592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/lyfRHOlU",
      "expanded_url" : "http:\/\/instagr.am\/p\/OM02M-s6lY\/",
      "display_url" : "instagr.am\/p\/OM02M-s6lY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "234378544556429312",
  "text" : "Another from Zoar, with some scale. Need to go back for another hike. http:\/\/t.co\/lyfRHOlU",
  "id" : 234378544556429312,
  "created_at" : "2012-08-11 19:59:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/xudlaydy",
      "expanded_url" : "http:\/\/instagr.am\/p\/OMpYQ9s6s5\/",
      "display_url" : "instagr.am\/p\/OMpYQ9s6s5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "234353306519097344",
  "text" : "Zoar Valley is awesome. http:\/\/t.co\/xudlaydy",
  "id" : 234353306519097344,
  "created_at" : "2012-08-11 18:19:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234262067547365377",
  "geo" : { },
  "id_str" : "234262485866258432",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove please tell me you actually did this",
  "id" : 234262485866258432,
  "in_reply_to_status_id" : 234262067547365377,
  "created_at" : "2012-08-11 12:18:23 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/JxYJL66g",
      "expanded_url" : "http:\/\/instagr.am\/p\/OLAIpjs6l4\/",
      "display_url" : "instagr.am\/p\/OLAIpjs6l4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "234122364143685633",
  "text" : "Power Struggle round 2! So many managers. http:\/\/t.co\/JxYJL66g",
  "id" : 234122364143685633,
  "created_at" : "2012-08-11 03:01:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234099662712344576",
  "geo" : { },
  "id_str" : "234099909052207104",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders strong strong -1.",
  "id" : 234099909052207104,
  "in_reply_to_status_id" : 234099662712344576,
  "created_at" : "2012-08-11 01:32:22 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 14, 26 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234099043922505728",
  "geo" : { },
  "id_str" : "234099810406375425",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @coreyhaines programming is hard, let's go shopping. It's easy to abuse or neglect any feature of a language or framework.",
  "id" : 234099810406375425,
  "in_reply_to_status_id" : 234099043922505728,
  "created_at" : "2012-08-11 01:31:58 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 13, 26 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234089286012661760",
  "geo" : { },
  "id_str" : "234098798253703168",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @steveklabnik this doesn't excuse you from designing a ball of mud, but it does serve a good purpose.",
  "id" : 234098798253703168,
  "in_reply_to_status_id" : 234089286012661760,
  "created_at" : "2012-08-11 01:27:57 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 13, 26 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234089286012661760",
  "geo" : { },
  "id_str" : "234098493285871616",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @steveklabnik I was very skeptical as well, but it enables simple refactoring and code sharing between classes.",
  "id" : 234098493285871616,
  "in_reply_to_status_id" : 234089286012661760,
  "created_at" : "2012-08-11 01:26:44 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234073442532601856",
  "geo" : { },
  "id_str" : "234083560259203072",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes The problem isn't  dreaming. From someone who doesn't live in a major tech hub, it just seems like a big valley sausagefest.",
  "id" : 234083560259203072,
  "in_reply_to_status_id" : 234073442532601856,
  "created_at" : "2012-08-11 00:27:24 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 3, 13 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234073878618583040",
  "text" : "RT @jbarnette: Holy shit, our dog is bilingual.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234071112579956736",
    "text" : "Holy shit, our dog is bilingual.",
    "id" : 234071112579956736,
    "created_at" : "2012-08-10 23:37:56 +0000",
    "user" : {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "protected" : false,
      "id_str" : "10453902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482193494002642944\/J3ZE2OBm_normal.jpeg",
      "id" : 10453902,
      "verified" : false
    }
  },
  "id" : 234073878618583040,
  "created_at" : "2012-08-10 23:48:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Y9JrMEQp",
      "expanded_url" : "http:\/\/instagr.am\/p\/OKnhTwM6hS\/",
      "display_url" : "instagr.am\/p\/OKnhTwM6hS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "234067865920233472",
  "text" : "Blue Monk never disappoints. http:\/\/t.co\/Y9JrMEQp",
  "id" : 234067865920233472,
  "created_at" : "2012-08-10 23:25:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/n9zHDCF2",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Timeline_of_the_far_future",
      "display_url" : "en.m.wikipedia.org\/wiki\/Timeline_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "234059631201243137",
  "geo" : { },
  "id_str" : "234061269794172928",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler http:\/\/t.co\/n9zHDCF2",
  "id" : 234061269794172928,
  "in_reply_to_status_id" : 234059631201243137,
  "created_at" : "2012-08-10 22:58:50 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/234045520740487170\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/eko3aoII",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Az9_KT5CEAA4U_T.jpg",
      "id_str" : "234045520761458688",
      "id" : 234045520761458688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az9_KT5CEAA4U_T.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eko3aoII"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234045520740487170",
  "text" : "Alright, this Bernese and St Bernard puppy playing at the park is helping out. http:\/\/t.co\/eko3aoII",
  "id" : 234045520740487170,
  "created_at" : "2012-08-10 21:56:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234028116337651712",
  "geo" : { },
  "id_str" : "234030480020873216",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef where?",
  "id" : 234030480020873216,
  "in_reply_to_status_id" : 234028116337651712,
  "created_at" : "2012-08-10 20:56:29 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234024998765998081",
  "geo" : { },
  "id_str" : "234025448160501760",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy good idea! Maybe once a month or so posting? Feels dirty sometimes.",
  "id" : 234025448160501760,
  "in_reply_to_status_id" : 234024998765998081,
  "created_at" : "2012-08-10 20:36:29 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234008831011717121",
  "text" : "Can I just restart today? I need a Restart Day button.",
  "id" : 234008831011717121,
  "created_at" : "2012-08-10 19:30:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Brault",
      "screen_name" : "adambrault",
      "indices" : [ 3, 14 ],
      "id_str" : "1568",
      "id" : 1568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233981004367400960",
  "text" : "RT @adambrault: Free nerdcore rapper name: Busta Cache",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233980649499934721",
    "text" : "Free nerdcore rapper name: Busta Cache",
    "id" : 233980649499934721,
    "created_at" : "2012-08-10 17:38:28 +0000",
    "user" : {
      "name" : "Adam Brault",
      "screen_name" : "adambrault",
      "protected" : false,
      "id_str" : "1568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474848741849968641\/vN5qcXaZ_normal.jpeg",
      "id" : 1568,
      "verified" : false
    }
  },
  "id" : 233981004367400960,
  "created_at" : "2012-08-10 17:39:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/7KBsKwOD",
      "expanded_url" : "http:\/\/www.informit.com\/articles\/article.aspx?p=1926692",
      "display_url" : "informit.com\/articles\/artic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233975687478923266",
  "text" : "\"In the future, stay the Hell out of other people's code.\" http:\/\/t.co\/7KBsKwOD Serious ego check for all programmers.",
  "id" : 233975687478923266,
  "created_at" : "2012-08-10 17:18:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 91, 105 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 128 ],
      "url" : "https:\/\/t.co\/4oibP0Db",
      "expanded_url" : "https:\/\/skitch.com\/kevinpurdy\/emsfg\/coffee-grid",
      "display_url" : "skitch.com\/kevinpurdy\/ems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233974719253200897",
  "text" : "RT @kevinpurdy: Here's a coffee chart (sans formatting) for Chemex and Hario pour-overs at @coworkbuffalo: https:\/\/t.co\/4oibP0Db Coffee  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 75, 89 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 112 ],
        "url" : "https:\/\/t.co\/4oibP0Db",
        "expanded_url" : "https:\/\/skitch.com\/kevinpurdy\/emsfg\/coffee-grid",
        "display_url" : "skitch.com\/kevinpurdy\/ems\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "233925318799392768",
    "text" : "Here's a coffee chart (sans formatting) for Chemex and Hario pour-overs at @coworkbuffalo: https:\/\/t.co\/4oibP0Db Coffee snobs, have at it?",
    "id" : 233925318799392768,
    "created_at" : "2012-08-10 13:58:36 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 233974719253200897,
  "created_at" : "2012-08-10 17:14:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233955238149779456",
  "geo" : { },
  "id_str" : "233967377149227009",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Beer is my official payment processor.",
  "id" : 233967377149227009,
  "in_reply_to_status_id" : 233955238149779456,
  "created_at" : "2012-08-10 16:45:44 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233965962737623040",
  "text" : "Ged is slowly getting used to the backpack. Loaded both sides, wouldn't look at me at the start of the walk, by the end was doing better.",
  "id" : 233965962737623040,
  "created_at" : "2012-08-10 16:40:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 3, 17 ],
      "id_str" : "5543292",
      "id" : 5543292
    }, {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 139, 140 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2RIOQh4V",
      "expanded_url" : "http:\/\/goo.gl\/JsNy3",
      "display_url" : "goo.gl\/JsNy3"
    } ]
  },
  "geo" : { },
  "id_str" : "233918955138449408",
  "text" : "RT @edwardmichael: As the father of a toddler girl, I totally get this. Truer words were never spoken. Welcome, Nate. http:\/\/t.co\/2RIOQh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nate Benson",
        "screen_name" : "natebenson",
        "indices" : [ 124, 135 ],
        "id_str" : "25678101",
        "id" : 25678101
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/2RIOQh4V",
        "expanded_url" : "http:\/\/goo.gl\/JsNy3",
        "display_url" : "goo.gl\/JsNy3"
      } ]
    },
    "geo" : { },
    "id_str" : "233910930612817920",
    "text" : "As the father of a toddler girl, I totally get this. Truer words were never spoken. Welcome, Nate. http:\/\/t.co\/2RIOQh4V via @natebenson",
    "id" : 233910930612817920,
    "created_at" : "2012-08-10 13:01:26 +0000",
    "user" : {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "protected" : false,
      "id_str" : "5543292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557388021344243712\/I0XrDV7N_normal.jpeg",
      "id" : 5543292,
      "verified" : false
    }
  },
  "id" : 233918955138449408,
  "created_at" : "2012-08-10 13:33:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 3, 16 ],
      "id_str" : "15375238",
      "id" : 15375238
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 18, 24 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233768993348022273",
  "text" : "RT @codemastermm: @qrush but I agree - RIT, one of my best decisions, too.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "233767230360412160",
    "geo" : { },
    "id_str" : "233768941015674881",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush but I agree - RIT, one of my best decisions, too.",
    "id" : 233768941015674881,
    "in_reply_to_status_id" : 233767230360412160,
    "created_at" : "2012-08-10 03:37:13 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "protected" : false,
      "id_str" : "15375238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2362207395\/57dmpi6unqtrh9le126t_normal.jpeg",
      "id" : 15375238,
      "verified" : false
    }
  },
  "id" : 233768993348022273,
  "created_at" : "2012-08-10 03:37:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233768748962705409",
  "geo" : { },
  "id_str" : "233768935894433792",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm By not showing up. that's probably the most basic thing that RIT taught me. Show the fuck up.",
  "id" : 233768935894433792,
  "in_reply_to_status_id" : 233768748962705409,
  "created_at" : "2012-08-10 03:37:12 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steve corona",
      "screen_name" : "stevencorona",
      "indices" : [ 0, 13 ],
      "id_str" : "65739266",
      "id" : 65739266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233768379482243072",
  "in_reply_to_user_id" : 65739266,
  "text" : "@stevencorona props for dropping out and still making it. you're different from most people that drop out of RIT: Most don't give a fuck.",
  "id" : 233768379482243072,
  "created_at" : "2012-08-10 03:34:59 +0000",
  "in_reply_to_screen_name" : "stevencorona",
  "in_reply_to_user_id_str" : "65739266",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233768152113233922",
  "text" : "I need to restart my blog someday. :(",
  "id" : 233768152113233922,
  "created_at" : "2012-08-10 03:34:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/zTInCdxJ",
      "expanded_url" : "http:\/\/stevecorona.com\/college-was-my-biggest-mistake",
      "display_url" : "stevecorona.com\/college-was-my\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233767230360412160",
  "text" : "Ah, RIT: It chews kids up and spits them out. College was one of my best decisions. Haters gonna hate. http:\/\/t.co\/zTInCdxJ",
  "id" : 233767230360412160,
  "created_at" : "2012-08-10 03:30:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233765639720955904",
  "text" : "Why did I wait this long to start watching Arrested Development?",
  "id" : 233765639720955904,
  "created_at" : "2012-08-10 03:24:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 0, 10 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233758114065813504",
  "geo" : { },
  "id_str" : "233765371646210048",
  "in_reply_to_user_id" : 13235612,
  "text" : "@alindeman start from scratch and read the tutorials exactly. Make sure to use your apple ID.",
  "id" : 233765371646210048,
  "in_reply_to_status_id" : 233758114065813504,
  "created_at" : "2012-08-10 03:23:02 +0000",
  "in_reply_to_screen_name" : "alindeman",
  "in_reply_to_user_id_str" : "13235612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 13, 23 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233755091902013440",
  "geo" : { },
  "id_str" : "233756647082840064",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @patmaddox oh yeah, he's going to love it. Going to load it up. Just getting him used to it.",
  "id" : 233756647082840064,
  "in_reply_to_status_id" : 233755091902013440,
  "created_at" : "2012-08-10 02:48:22 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Rosenthal",
      "screen_name" : "caseyrosenthal",
      "indices" : [ 0, 15 ],
      "id_str" : "17850415",
      "id" : 17850415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233755365496471552",
  "geo" : { },
  "id_str" : "233756480145346561",
  "in_reply_to_user_id" : 17850415,
  "text" : "@caseyrosenthal ha, no weight to start. He did fine while moving.",
  "id" : 233756480145346561,
  "in_reply_to_status_id" : 233755365496471552,
  "created_at" : "2012-08-10 02:47:42 +0000",
  "in_reply_to_screen_name" : "caseyrosenthal",
  "in_reply_to_user_id_str" : "17850415",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/oIxFXvNt",
      "expanded_url" : "http:\/\/instagr.am\/p\/OIZEfsM6mh\/",
      "display_url" : "instagr.am\/p\/OIZEfsM6mh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "233754445723365377",
  "text" : "Going hiking on Saturday. Ged is not happy about having a job to do with his new backpack. http:\/\/t.co\/oIxFXvNt",
  "id" : 233754445723365377,
  "created_at" : "2012-08-10 02:39:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason MacBain",
      "screen_name" : "JaBain",
      "indices" : [ 3, 10 ],
      "id_str" : "50678283",
      "id" : 50678283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/xoexUYLd",
      "expanded_url" : "http:\/\/lockerz.com\/s\/232997051",
      "display_url" : "lockerz.com\/s\/232997051"
    } ]
  },
  "geo" : { },
  "id_str" : "233752324173099008",
  "text" : "RT @JaBain: This is a real ad in the Bills program. You can't make this stuff up.\nhttp:\/\/t.co\/xoexUYLd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/xoexUYLd",
        "expanded_url" : "http:\/\/lockerz.com\/s\/232997051",
        "display_url" : "lockerz.com\/s\/232997051"
      } ]
    },
    "geo" : { },
    "id_str" : "233740542557683713",
    "text" : "This is a real ad in the Bills program. You can't make this stuff up.\nhttp:\/\/t.co\/xoexUYLd",
    "id" : 233740542557683713,
    "created_at" : "2012-08-10 01:44:22 +0000",
    "user" : {
      "name" : "Jason MacBain",
      "screen_name" : "JaBain",
      "protected" : false,
      "id_str" : "50678283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854292201\/me_normal.jpg",
      "id" : 50678283,
      "verified" : false
    }
  },
  "id" : 233752324173099008,
  "created_at" : "2012-08-10 02:31:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233652671742083074",
  "geo" : { },
  "id_str" : "233652930916532224",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner \/play rimshot",
  "id" : 233652930916532224,
  "in_reply_to_status_id" : 233652671742083074,
  "created_at" : "2012-08-09 19:56:14 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233652651135492096",
  "text" : "Ah, fuck...2010. :(",
  "id" : 233652651135492096,
  "created_at" : "2012-08-09 19:55:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 3, 13 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 15, 24 ],
      "id_str" : "717973",
      "id" : 717973
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 25, 31 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233652608752029696",
  "text" : "RT @stevelosh: @ceejayoz @qrush 20 Nov 2010",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C. Sternal-Johnson",
        "screen_name" : "ceejayoz",
        "indices" : [ 0, 9 ],
        "id_str" : "717973",
        "id" : 717973
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 10, 16 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "233652379285848064",
    "geo" : { },
    "id_str" : "233652486752317440",
    "in_reply_to_user_id" : 717973,
    "text" : "@ceejayoz @qrush 20 Nov 2010",
    "id" : 233652486752317440,
    "in_reply_to_status_id" : 233652379285848064,
    "created_at" : "2012-08-09 19:54:28 +0000",
    "in_reply_to_screen_name" : "ceejayoz",
    "in_reply_to_user_id_str" : "717973",
    "user" : {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "protected" : false,
      "id_str" : "727813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430207936774696960\/iAyNTOdO_normal.jpeg",
      "id" : 727813,
      "verified" : false
    }
  },
  "id" : 233652608752029696,
  "created_at" : "2012-08-09 19:54:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/r1IxAcgB",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/news\/religion\/the-pope\/8148944\/The-Pope-drops-Catholic-ban-on-condoms-in-historic-shift.html",
      "display_url" : "telegraph.co.uk\/news\/religion\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233652191892738048",
  "text" : "Holy shit. I had to double check making sure this wasn't The Onion. http:\/\/t.co\/r1IxAcgB",
  "id" : 233652191892738048,
  "created_at" : "2012-08-09 19:53:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 21, 32 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/aMr9QZSZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wdVRaDJth4s",
      "display_url" : "youtube.com\/watch?v=wdVRaD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233651571840393216",
  "text" : "This one goes out to @shellscape: http:\/\/t.co\/aMr9QZSZ",
  "id" : 233651571840393216,
  "created_at" : "2012-08-09 19:50:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Galineau",
      "screen_name" : "sgalineau",
      "indices" : [ 3, 13 ],
      "id_str" : "24609163",
      "id" : 24609163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233637403120787456",
  "text" : "RT @sgalineau: To show they understand the risks of a -webkit monoculture, developers now working hard to optimize sites for the .1% wit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233635398788718592",
    "text" : "To show they understand the risks of a -webkit monoculture, developers now working hard to optimize sites for the .1% with Retina Macbooks.",
    "id" : 233635398788718592,
    "created_at" : "2012-08-09 18:46:34 +0000",
    "user" : {
      "name" : "Sylvain Galineau",
      "screen_name" : "sgalineau",
      "protected" : false,
      "id_str" : "24609163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1350870912\/Capture_normal.PNG",
      "id" : 24609163,
      "verified" : false
    }
  },
  "id" : 233637403120787456,
  "created_at" : "2012-08-09 18:54:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233634197674274818",
  "geo" : { },
  "id_str" : "233634320571576320",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Not enough complaining.",
  "id" : 233634320571576320,
  "in_reply_to_status_id" : 233634197674274818,
  "created_at" : "2012-08-09 18:42:17 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233626163526897664",
  "geo" : { },
  "id_str" : "233630629584056320",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Fuck yes.",
  "id" : 233630629584056320,
  "in_reply_to_status_id" : 233626163526897664,
  "created_at" : "2012-08-09 18:27:37 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233622414305685505",
  "geo" : { },
  "id_str" : "233622574561640448",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Shippin it!",
  "id" : 233622574561640448,
  "in_reply_to_status_id" : 233622414305685505,
  "created_at" : "2012-08-09 17:55:36 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yoder",
      "screen_name" : "doug_yoder",
      "indices" : [ 0, 11 ],
      "id_str" : "14680570",
      "id" : 14680570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233617156082917376",
  "geo" : { },
  "id_str" : "233618378932224000",
  "in_reply_to_user_id" : 14680570,
  "text" : "@doug_yoder they're still selling textmate. pretty sure vim is donation only.",
  "id" : 233618378932224000,
  "in_reply_to_status_id" : 233617156082917376,
  "created_at" : "2012-08-09 17:38:56 +0000",
  "in_reply_to_screen_name" : "doug_yoder",
  "in_reply_to_user_id_str" : "14680570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stats Canada",
      "screen_name" : "stats_canada",
      "indices" : [ 3, 16 ],
      "id_str" : "701267743",
      "id" : 701267743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233617959644434433",
  "text" : "RT @stats_canada: In Canada, 1% of the population controls 99% of the maple syrup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233617297728733184",
    "text" : "In Canada, 1% of the population controls 99% of the maple syrup",
    "id" : 233617297728733184,
    "created_at" : "2012-08-09 17:34:38 +0000",
    "user" : {
      "name" : "Stats Canada",
      "screen_name" : "stats_canada",
      "protected" : false,
      "id_str" : "701267743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2752781064\/decdee41e5324dfe1af9a1a1c8c9846b_normal.png",
      "id" : 701267743,
      "verified" : false
    }
  },
  "id" : 233617959644434433,
  "created_at" : "2012-08-09 17:37:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/uZWv9PuZ",
      "expanded_url" : "http:\/\/turntable.fm\/mashupfm",
      "display_url" : "turntable.fm\/mashupfm"
    } ]
  },
  "geo" : { },
  "id_str" : "233617782615445504",
  "text" : "The mashup.fm channel on TurnTable plays the most ridiculous stuff. Lion King mashup earlier, Inspector Gadget now. http:\/\/t.co\/uZWv9PuZ",
  "id" : 233617782615445504,
  "created_at" : "2012-08-09 17:36:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233617063674011648",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic hey can you jump in IRC? or ping me on gchat (my normal email)",
  "id" : 233617063674011648,
  "created_at" : "2012-08-09 17:33:43 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233613889768652800",
  "text" : "OH: \"Ok, now, you shove this gem in your ass, run this rake command... and vroom!\"",
  "id" : 233613889768652800,
  "created_at" : "2012-08-09 17:21:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 3, 9 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233613061167120385",
  "text" : "RT @ahuj9: I'm sorry Steve Streza, it really is nothing personal, but good lord",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233608246999535616",
    "text" : "I'm sorry Steve Streza, it really is nothing personal, but good lord",
    "id" : 233608246999535616,
    "created_at" : "2012-08-09 16:58:40 +0000",
    "user" : {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "protected" : false,
      "id_str" : "205281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2438738477\/m3tcrt9kvs9x0ff84b31_normal.jpeg",
      "id" : 205281746,
      "verified" : false
    }
  },
  "id" : 233613061167120385,
  "created_at" : "2012-08-09 17:17:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 12, 20 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/XhblhGXS",
      "expanded_url" : "http:\/\/www.google.com\/trends\/?q=neckbeard,+big+data&ctab=0&geo=all&date=all&sort=0",
      "display_url" : "google.com\/trends\/?q=neck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "233611765085245440",
  "geo" : { },
  "id_str" : "233612074448736259",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff @noahhlo this just in: http:\/\/t.co\/XhblhGXS",
  "id" : 233612074448736259,
  "in_reply_to_status_id" : 233611765085245440,
  "created_at" : "2012-08-09 17:13:53 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/fZJIjaiL",
      "expanded_url" : "http:\/\/www.google.com\/trends\/?q=bullshit,+big+data&ctab=0&geo=all&date=all&sort=0",
      "display_url" : "google.com\/trends\/?q=bull\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "233610368587542528",
  "geo" : { },
  "id_str" : "233610782259171329",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo quick, trend analysis comparsion: http:\/\/t.co\/fZJIjaiL",
  "id" : 233610782259171329,
  "in_reply_to_status_id" : 233610368587542528,
  "created_at" : "2012-08-09 17:08:45 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/uZKCEN0w",
      "expanded_url" : "http:\/\/ecx.images-amazon.com\/images\/I\/51%2BWc-4r0hL.jpg",
      "display_url" : "ecx.images-amazon.com\/images\/I\/51%2B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233603359523893249",
  "text" : "Dog backpacks, or, the face of humiliation: http:\/\/t.co\/uZKCEN0w",
  "id" : 233603359523893249,
  "created_at" : "2012-08-09 16:39:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 55 ],
      "url" : "https:\/\/t.co\/ESK6lddt",
      "expanded_url" : "https:\/\/github.com\/textmate\/textmate\/issues\/2",
      "display_url" : "github.com\/textmate\/textm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233595269151870976",
  "text" : "*\u007D[^^&amp;OPEN SOURCE!&amp;^^]\u007B*\n\nhttps:\/\/t.co\/ESK6lddt\n\nIt sucks much.",
  "id" : 233595269151870976,
  "created_at" : "2012-08-09 16:07:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CoworkingDay",
      "indices" : [ 31, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233594687955546114",
  "text" : "RT @coworkbuffalo: Also, Happy #CoworkingDay !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CoworkingDay",
        "indices" : [ 12, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233591115377430529",
    "text" : "Also, Happy #CoworkingDay !",
    "id" : 233591115377430529,
    "created_at" : "2012-08-09 15:50:36 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 233594687955546114,
  "created_at" : "2012-08-09 16:04:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "indices" : [ 3, 16 ],
      "id_str" : "3479601",
      "id" : 3479601
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 41, 55 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233594494979825664",
  "text" : "RT @justingoboom: Happy coworking day to @coworkbuffalo !!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 23, 37 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233594096625799168",
    "text" : "Happy coworking day to @coworkbuffalo !!!",
    "id" : 233594096625799168,
    "created_at" : "2012-08-09 16:02:27 +0000",
    "user" : {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "protected" : false,
      "id_str" : "3479601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1477957942\/74E164F3-C522-4E41-98D1-C7A780056F92_normal",
      "id" : 3479601,
      "verified" : false
    }
  },
  "id" : 233594494979825664,
  "created_at" : "2012-08-09 16:04:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233579393723793408",
  "geo" : { },
  "id_str" : "233580300045791233",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik what is the problem here? it's experimental. so what?",
  "id" : 233580300045791233,
  "in_reply_to_status_id" : 233579393723793408,
  "created_at" : "2012-08-09 15:07:37 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233580097314119680",
  "geo" : { },
  "id_str" : "233580241115807745",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy you can pin tabs in Chrome.",
  "id" : 233580241115807745,
  "in_reply_to_status_id" : 233580097314119680,
  "created_at" : "2012-08-09 15:07:23 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233575696050565120",
  "geo" : { },
  "id_str" : "233575844596027392",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage wat?",
  "id" : 233575844596027392,
  "in_reply_to_status_id" : 233575696050565120,
  "created_at" : "2012-08-09 14:49:55 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233574948944367616",
  "text" : "Remember when everyone used Firefox? Good times.",
  "id" : 233574948944367616,
  "created_at" : "2012-08-09 14:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 7, 18 ],
      "id_str" : "20751318",
      "id" : 20751318
    }, {
      "name" : "Dave Morgan",
      "screen_name" : "devmorgan",
      "indices" : [ 19, 29 ],
      "id_str" : "14223065",
      "id" : 14223065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233551621580288001",
  "geo" : { },
  "id_str" : "233552428425949185",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn @BarCampRoc @devmorgan booyah. Let's sit down and do this at the event. Basically just need to i18n the content.",
  "id" : 233552428425949185,
  "in_reply_to_status_id" : 233551621580288001,
  "created_at" : "2012-08-09 13:16:52 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233349684666724352",
  "text" : "Nothing prepares you for cleaning exploded \uD83D\uDCA9 off a staircase and bannister.",
  "id" : 233349684666724352,
  "created_at" : "2012-08-08 23:51:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233260943986028544",
  "geo" : { },
  "id_str" : "233261342121934851",
  "in_reply_to_user_id" : 896641,
  "text" : "@JZ EXTREMELY LIKELY!!! 480\u00BA KICKFLIP COMBO BONUS!",
  "id" : 233261342121934851,
  "in_reply_to_status_id" : 233260943986028544,
  "created_at" : "2012-08-08 18:00:12 +0000",
  "in_reply_to_screen_name" : "jasonzimdars",
  "in_reply_to_user_id_str" : "896641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 6, 13 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233249588784545793",
  "geo" : { },
  "id_str" : "233254433792876544",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu @zoomba he must have ascended to an astral plane. he can see through time and space, and down all paths of time.",
  "id" : 233254433792876544,
  "in_reply_to_status_id" : 233249588784545793,
  "created_at" : "2012-08-08 17:32:45 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233241214944681984",
  "geo" : { },
  "id_str" : "233243043485085696",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin did...you do this?",
  "id" : 233243043485085696,
  "in_reply_to_status_id" : 233241214944681984,
  "created_at" : "2012-08-08 16:47:29 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    }, {
      "name" : "ruby_dcamp",
      "screen_name" : "ruby_dcamp",
      "indices" : [ 12, 23 ],
      "id_str" : "15386856",
      "id" : 15386856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233239469682212864",
  "geo" : { },
  "id_str" : "233242977072459776",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger @ruby_dcamp yep!",
  "id" : 233242977072459776,
  "in_reply_to_status_id" : 233239469682212864,
  "created_at" : "2012-08-08 16:47:13 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/GwZfAmF9",
      "expanded_url" : "http:\/\/www.panoramas.dk\/mars\/greeley-haven.html#ReadAbout",
      "display_url" : "panoramas.dk\/mars\/greeley-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233232208758968320",
  "text" : "Correction, http:\/\/t.co\/GwZfAmF9 is not from Curiosity.",
  "id" : 233232208758968320,
  "created_at" : "2012-08-08 16:04:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/jt6C4D9o",
      "expanded_url" : "http:\/\/www.panoramas.dk\/mars\/greeley-haven.html",
      "display_url" : "panoramas.dk\/mars\/greeley-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233231496171909120",
  "text" : "Chills: http:\/\/t.co\/jt6C4D9o",
  "id" : 233231496171909120,
  "created_at" : "2012-08-08 16:01:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233229174876274688",
  "geo" : { },
  "id_str" : "233229374931996672",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits do you work for vooza?!",
  "id" : 233229374931996672,
  "in_reply_to_status_id" : 233229174876274688,
  "created_at" : "2012-08-08 15:53:10 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 0, 11 ],
      "id_str" : "20751318",
      "id" : 20751318
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 12, 18 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "Dave Morgan",
      "screen_name" : "devmorgan",
      "indices" : [ 19, 29 ],
      "id_str" : "14223065",
      "id" : 14223065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 119 ],
      "url" : "https:\/\/t.co\/smnJUxHt",
      "expanded_url" : "https:\/\/github.com\/coworkbuffalo\/barcampbuffalo",
      "display_url" : "github.com\/coworkbuffalo\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "233227606361788416",
  "geo" : { },
  "id_str" : "233228225021628416",
  "in_reply_to_user_id" : 20751318,
  "text" : "@BarCampRoc @chorn @DevMorgan damn, maybe next barcamp we can get Roc's and BUF's systems merged: https:\/\/t.co\/smnJUxHt",
  "id" : 233228225021628416,
  "in_reply_to_status_id" : 233227606361788416,
  "created_at" : "2012-08-08 15:48:36 +0000",
  "in_reply_to_screen_name" : "BarCampRoc",
  "in_reply_to_user_id_str" : "20751318",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232587324318420992",
  "geo" : { },
  "id_str" : "233223200874573825",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby these are great! are any from day 1 going up?",
  "id" : 233223200874573825,
  "in_reply_to_status_id" : 232587324318420992,
  "created_at" : "2012-08-08 15:28:38 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 138 ],
      "url" : "https:\/\/t.co\/PR7TVk2P",
      "expanded_url" : "https:\/\/github.com\/CocoaPods\/CocoaPods\/pull\/448",
      "display_url" : "github.com\/CocoaPods\/Coco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233222002096369664",
  "text" : "Gem maintainers: Please don't force your gem users to upgrade, or spit out messages when you're supposed to upgrade. https:\/\/t.co\/PR7TVk2P",
  "id" : 233222002096369664,
  "created_at" : "2012-08-08 15:23:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    }, {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 16, 21 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233209669752078336",
  "geo" : { },
  "id_str" : "233211217127305217",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba oh man. @jhsu was raving about this spice as well. Need to try it.",
  "id" : 233211217127305217,
  "in_reply_to_status_id" : 233209669752078336,
  "created_at" : "2012-08-08 14:41:01 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232993312762642432",
  "geo" : { },
  "id_str" : "233070725077016576",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits just heard the good news! Congrats!",
  "id" : 233070725077016576,
  "in_reply_to_status_id" : 232993312762642432,
  "created_at" : "2012-08-08 05:22:45 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233054915092697088",
  "geo" : { },
  "id_str" : "233056423905464321",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz no, the text backwards. everything maybe.",
  "id" : 233056423905464321,
  "in_reply_to_status_id" : 233054915092697088,
  "created_at" : "2012-08-08 04:25:56 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233053289099444224",
  "geo" : { },
  "id_str" : "233053610408284160",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes you'd think his title would be \"Villain\"",
  "id" : 233053610408284160,
  "in_reply_to_status_id" : 233053289099444224,
  "created_at" : "2012-08-08 04:14:45 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/9Ndc8FjE",
      "expanded_url" : "http:\/\/elgoog.com\/",
      "display_url" : "elgoog.com"
    } ]
  },
  "geo" : { },
  "id_str" : "233053145192857603",
  "text" : "Dumb, tired, late night idea: register http:\/\/t.co\/9Ndc8FjE, render all search results backwards.",
  "id" : 233053145192857603,
  "created_at" : "2012-08-08 04:12:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/3XGhIbCl",
      "expanded_url" : "http:\/\/css12.com\/",
      "display_url" : "css12.com"
    } ]
  },
  "geo" : { },
  "id_str" : "233052755189694464",
  "text" : "Looks like by the time CSS12 is out, we're all back to using FrontPage 6.0. http:\/\/t.co\/3XGhIbCl",
  "id" : 233052755189694464,
  "created_at" : "2012-08-08 04:11:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/dyHa3kBF",
      "expanded_url" : "http:\/\/www.css6.com\/",
      "display_url" : "css6.com"
    } ]
  },
  "geo" : { },
  "id_str" : "233052136919932929",
  "text" : "I can't wait for CSS6. This looks way more fun than CSS3! http:\/\/t.co\/dyHa3kBF",
  "id" : 233052136919932929,
  "created_at" : "2012-08-08 04:08:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/C0cctAn2",
      "expanded_url" : "http:\/\/css4.com\/",
      "display_url" : "css4.com"
    } ]
  },
  "geo" : { },
  "id_str" : "233051993671864320",
  "text" : "Lulz: http:\/\/t.co\/C0cctAn2",
  "id" : 233051993671864320,
  "created_at" : "2012-08-08 04:08:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233051232602828800",
  "text" : "Starbucks is getting Square?! I'll set up a tab on Register, and take a grande Mocha Frappe IV tap DIRECTLY INTO MY VEINS PLEASE",
  "id" : 233051232602828800,
  "created_at" : "2012-08-08 04:05:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233042537173118976",
  "geo" : { },
  "id_str" : "233048295163981824",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz oh i'm sure, it just seems like a silly way to obfuscate it",
  "id" : 233048295163981824,
  "in_reply_to_status_id" : 233042537173118976,
  "created_at" : "2012-08-08 03:53:38 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233042581762752512",
  "geo" : { },
  "id_str" : "233046691694125057",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt writing is hard, let's go shopping",
  "id" : 233046691694125057,
  "in_reply_to_status_id" : 233042581762752512,
  "created_at" : "2012-08-08 03:47:15 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233041542716215296",
  "geo" : { },
  "id_str" : "233042229156007936",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt thanks! I need to redo my blog or something and get writing again. Embarrassed by its layout.",
  "id" : 233042229156007936,
  "in_reply_to_status_id" : 233041542716215296,
  "created_at" : "2012-08-08 03:29:31 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/5Z4YVhlI",
      "expanded_url" : "http:\/\/0xced.blogspot.co.at\/2012\/08\/prepare-your-apps-for-new-iphone.html",
      "display_url" : "0xced.blogspot.co.at\/2012\/08\/prepar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233042080786685952",
  "text" : "Really Apple? &lt;key&gt;EagleEnabled&lt;\/key&gt; &lt;key&gt;GiraffeEnabled&lt;\/key&gt; http:\/\/t.co\/5Z4YVhlI This is just pathetic.",
  "id" : 233042080786685952,
  "created_at" : "2012-08-08 03:28:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/VSrtIF1g",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/6nc1h\/im_in_college_and_i_want_to_contribute_to_an_oss\/c04cnad",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233039773571358720",
  "text" : "\"Don't pick a project and then go ask them how you can help. Just help. Now.\" http:\/\/t.co\/VSrtIF1g",
  "id" : 233039773571358720,
  "created_at" : "2012-08-08 03:19:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 124 ],
      "url" : "https:\/\/t.co\/nfgEmc3H",
      "expanded_url" : "https:\/\/groups.google.com\/group\/buffalo-opencoffee-club\/msg\/e7be3d6c83b0a1f9",
      "display_url" : "groups.google.com\/group\/buffalo-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233029255829782528",
  "text" : "Just realized 4 years ago I didn't work on any OSS at all... what's the next 4-5 years going to bring? https:\/\/t.co\/nfgEmc3H",
  "id" : 233029255829782528,
  "created_at" : "2012-08-08 02:37:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/NzCkJISQ",
      "expanded_url" : "http:\/\/instagr.am\/p\/ODIBMUM6pN\/",
      "display_url" : "instagr.am\/p\/ODIBMUM6pN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "233013492096061441",
  "text" : "GedFood batch 2 completed! Last batch lasted 3 weeks, and now Geddy instantly goes to his crate when we leav http:\/\/t.co\/NzCkJISQ",
  "id" : 233013492096061441,
  "created_at" : "2012-08-08 01:35:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/XCmEbZSM",
      "expanded_url" : "http:\/\/instagr.am\/p\/ODH4C-s6o8\/",
      "display_url" : "instagr.am\/p\/ODH4C-s6o8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "233012989018652672",
  "text" : "GedFood brewing process. http:\/\/t.co\/XCmEbZSM",
  "id" : 233012989018652672,
  "created_at" : "2012-08-08 01:33:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/fO6o6yRB",
      "expanded_url" : "http:\/\/instagr.am\/p\/ODFqfqM6nX\/",
      "display_url" : "instagr.am\/p\/ODFqfqM6nX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "233008135420387331",
  "text" : "Kong Stuffer Round 2. Only making one batch tonight. http:\/\/t.co\/fO6o6yRB",
  "id" : 233008135420387331,
  "created_at" : "2012-08-08 01:14:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 3, 15 ],
      "id_str" : "16454301",
      "id" : 16454301
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 17, 23 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232997131894530048",
  "text" : "RT @jonasdowney: @qrush those sorts of redesigns are like judging a trial without access to any of the evidence.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "232986582012018688",
    "geo" : { },
    "id_str" : "232994929197064193",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush those sorts of redesigns are like judging a trial without access to any of the evidence.",
    "id" : 232994929197064193,
    "in_reply_to_status_id" : 232986582012018688,
    "created_at" : "2012-08-08 00:21:34 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "protected" : false,
      "id_str" : "16454301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153090409\/f136c60eca258e42e43b2d1760196833_normal.jpeg",
      "id" : 16454301,
      "verified" : false
    }
  },
  "id" : 232997131894530048,
  "created_at" : "2012-08-08 00:30:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/L470EtgC",
      "expanded_url" : "http:\/\/www.wikipediaredefined.com\/",
      "display_url" : "wikipediaredefined.com"
    } ]
  },
  "geo" : { },
  "id_str" : "232986582012018688",
  "text" : "Wiki redesign: http:\/\/t.co\/L470EtgC Less mocks, more working code.",
  "id" : 232986582012018688,
  "created_at" : "2012-08-07 23:48:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/GSR9c9lf",
      "expanded_url" : "http:\/\/wikipediaredesigned.com",
      "display_url" : "wikipediaredesigned.com"
    } ]
  },
  "geo" : { },
  "id_str" : "232983169434013696",
  "text" : "Maybe if http:\/\/t.co\/GSR9c9lf actually spent time in the hell that is MediaWiki themes, it would be worth something substantial. :(",
  "id" : 232983169434013696,
  "created_at" : "2012-08-07 23:34:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 8, 15 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232938514101194753",
  "geo" : { },
  "id_str" : "232973795990859776",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @mwhuss this doesn't surprise me one bit.",
  "id" : 232973795990859776,
  "in_reply_to_status_id" : 232938514101194753,
  "created_at" : "2012-08-07 22:57:36 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232923929453404160",
  "geo" : { },
  "id_str" : "232927164046139393",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx thanks man!",
  "id" : 232927164046139393,
  "in_reply_to_status_id" : 232923929453404160,
  "created_at" : "2012-08-07 19:52:18 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Twomey",
      "screen_name" : "rtwomey",
      "indices" : [ 0, 8 ],
      "id_str" : "6371202",
      "id" : 6371202
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 9, 17 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 18, 26 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 67, 73 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232921788751941632",
  "geo" : { },
  "id_str" : "232922393188909056",
  "in_reply_to_user_id" : 6371202,
  "text" : "@rtwomey @sikachu @evanphx you seeing this? is our DNS screwy? \/cc @aeden",
  "id" : 232922393188909056,
  "in_reply_to_status_id" : 232921788751941632,
  "created_at" : "2012-08-07 19:33:20 +0000",
  "in_reply_to_screen_name" : "rtwomey",
  "in_reply_to_user_id_str" : "6371202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232920343470276609",
  "geo" : { },
  "id_str" : "232920872539783168",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu ?",
  "id" : 232920872539783168,
  "in_reply_to_status_id" : 232920343470276609,
  "created_at" : "2012-08-07 19:27:18 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/kMeKdfAF",
      "expanded_url" : "http:\/\/mattgemmell.com\/2012\/05\/24\/api-design\/",
      "display_url" : "mattgemmell.com\/2012\/05\/24\/api\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232901510009327617",
  "text" : "Required reading for anyone doing any kind of iOS dev. I think 90% of projects I've seen on GitHub violate Rule 7. http:\/\/t.co\/kMeKdfAF",
  "id" : 232901510009327617,
  "created_at" : "2012-08-07 18:10:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232899273082167296",
  "geo" : { },
  "id_str" : "232900791139201025",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit i see this as a generational problem. i don't know know one 20-~30 yr old that watches local news, period. who cares?",
  "id" : 232900791139201025,
  "in_reply_to_status_id" : 232899273082167296,
  "created_at" : "2012-08-07 18:07:30 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 3, 13 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232899800541040640",
  "text" : "RT @stevelosh: now that github has switched to stars there's no way to search them any more.  cool I didn't need to ever get to any of t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232899257584218113",
    "text" : "now that github has switched to stars there's no way to search them any more.  cool I didn't need to ever get to any of those ever again",
    "id" : 232899257584218113,
    "created_at" : "2012-08-07 18:01:24 +0000",
    "user" : {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "protected" : false,
      "id_str" : "727813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430207936774696960\/iAyNTOdO_normal.jpeg",
      "id" : 727813,
      "verified" : false
    }
  },
  "id" : 232899800541040640,
  "created_at" : "2012-08-07 18:03:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "232898243212742656",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Ice Cube: It Was A Good Day \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 232898243212742656,
  "created_at" : "2012-08-07 17:57:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 25, 37 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/hemIfgch",
      "expanded_url" : "http:\/\/instagr.am\/p\/OCSUwcs6mZ\/",
      "display_url" : "instagr.am\/p\/OCSUwcs6mZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "232895263184912385",
  "text" : "It's about that time for @whereslloyd! http:\/\/t.co\/hemIfgch",
  "id" : 232895263184912385,
  "created_at" : "2012-08-07 17:45:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zefrank",
      "screen_name" : "zefrank",
      "indices" : [ 7, 15 ],
      "id_str" : "11340982",
      "id" : 11340982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/LpdCQPit",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=pVumgiMJeag",
      "display_url" : "youtube.com\/watch?v=pVumgi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232873593246199808",
  "text" : "Loving @zefrank's advice on public speaking. Mine: Practice. PRACTICE. Make people laugh. http:\/\/t.co\/LpdCQPit",
  "id" : 232873593246199808,
  "created_at" : "2012-08-07 16:19:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Kox9UKuR",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=VFUKKlhprOQ",
      "display_url" : "youtube.com\/watch?v=VFUKKl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232847659487084544",
  "text" : "Current status: http:\/\/t.co\/Kox9UKuR",
  "id" : 232847659487084544,
  "created_at" : "2012-08-07 14:36:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232798823406260225",
  "geo" : { },
  "id_str" : "232801802280660992",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase yeah not pleased. I will fix today.",
  "id" : 232801802280660992,
  "in_reply_to_status_id" : 232798823406260225,
  "created_at" : "2012-08-07 11:34:09 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232688900278190081",
  "text" : "Does anyone else feel that github bragging they haven't lost any employees is a little too much? Good for you, but this is going to happen.",
  "id" : 232688900278190081,
  "created_at" : "2012-08-07 04:05:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 3, 6 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232669867038363648",
  "text" : "RT @jm: I'm really happy to say that nearly 20% of our speakers for MagicRuby are women.  w00t!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232535473921335298",
    "text" : "I'm really happy to say that nearly 20% of our speakers for MagicRuby are women.  w00t!",
    "id" : 232535473921335298,
    "created_at" : "2012-08-06 17:55:51 +0000",
    "user" : {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "protected" : false,
      "id_str" : "937561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485973888715599872\/2FQpRyqG_normal.jpeg",
      "id" : 937561,
      "verified" : false
    }
  },
  "id" : 232669867038363648,
  "created_at" : "2012-08-07 02:49:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232625017265999872",
  "geo" : { },
  "id_str" : "232626208758706176",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx no, not happy with this. need to desaturate the logo too. i'll take a look.",
  "id" : 232626208758706176,
  "in_reply_to_status_id" : 232625017265999872,
  "created_at" : "2012-08-06 23:56:24 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232624807856971777",
  "text" : "RUH RUH RUH RUH RUH RUHHHHAAAOOOOOOAOAOOWOWOWOWOWOWOOWO",
  "id" : 232624807856971777,
  "created_at" : "2012-08-06 23:50:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry O'Brien",
      "screen_name" : "lobrien",
      "indices" : [ 0, 8 ],
      "id_str" : "6151482",
      "id" : 6151482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232621060758065152",
  "geo" : { },
  "id_str" : "232622191634685952",
  "in_reply_to_user_id" : 6151482,
  "text" : "@lobrien They don't stop when breathing even, it's more of a low rumble like an engine idling.",
  "id" : 232622191634685952,
  "in_reply_to_status_id" : 232621060758065152,
  "created_at" : "2012-08-06 23:40:27 +0000",
  "in_reply_to_screen_name" : "lobrien",
  "in_reply_to_user_id_str" : "6151482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232617306193268736",
  "text" : "I'm so glad my dog is not an alarm barker.",
  "id" : 232617306193268736,
  "created_at" : "2012-08-06 23:21:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232617227411652608",
  "text" : "Still barking. 45 straight minutes.",
  "id" : 232617227411652608,
  "created_at" : "2012-08-06 23:20:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/jEBXXKm7",
      "expanded_url" : "http:\/\/games.amazon.com\/",
      "display_url" : "games.amazon.com"
    } ]
  },
  "geo" : { },
  "id_str" : "232613281452400641",
  "text" : "Why is Amazon making Facebook\/Zynga style games? I really thought higher of them. http:\/\/t.co\/jEBXXKm7",
  "id" : 232613281452400641,
  "created_at" : "2012-08-06 23:05:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232613113642508291",
  "text" : "I have the wrong avatar for this.",
  "id" : 232613113642508291,
  "created_at" : "2012-08-06 23:04:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232613063654797312",
  "text" : "WHUP. WHUUUUUP. HAWWWOOWOWOWOWOWOWOWWWOWOOOOWOWOWOOWOWOOOOOOOOOOOOO",
  "id" : 232613063654797312,
  "created_at" : "2012-08-06 23:04:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232612961871601665",
  "text" : "BARK. BAAARK. HAWWOOOOO. HAWOOOOOOOOOOOOOOOOOOO. HAAWWWWWWHWHWHWHWHWOOOOOOOOOOOOOOOOOOOOOOOO",
  "id" : 232612961871601665,
  "created_at" : "2012-08-06 23:03:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232612579086839808",
  "text" : "Next door's spaniels have been barking for 30 minutes straight. How do?",
  "id" : 232612579086839808,
  "created_at" : "2012-08-06 23:02:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 20, 33 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232542227459608577",
  "geo" : { },
  "id_str" : "232542596885532672",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich I think @IanCAnderson might know!",
  "id" : 232542596885532672,
  "in_reply_to_status_id" : 232542227459608577,
  "created_at" : "2012-08-06 18:24:10 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolobuffalony",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232491202132447233",
  "text" : "You Only Lunch Once #yolobuffalony",
  "id" : 232491202132447233,
  "created_at" : "2012-08-06 14:59:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/CIId7HVs",
      "expanded_url" : "http:\/\/www.yolobuffalony.com\/",
      "display_url" : "yolobuffalony.com"
    } ]
  },
  "geo" : { },
  "id_str" : "232488010749452288",
  "text" : "Why.... http:\/\/t.co\/CIId7HVs",
  "id" : 232488010749452288,
  "created_at" : "2012-08-06 14:47:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Dolman",
      "screen_name" : "bdolman",
      "indices" : [ 3, 11 ],
      "id_str" : "15447634",
      "id" : 15447634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232353673819336704",
  "text" : "RT @bdolman: Gold medal for NASA in the 563 billion meters",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232348836503355392",
    "text" : "Gold medal for NASA in the 563 billion meters",
    "id" : 232348836503355392,
    "created_at" : "2012-08-06 05:34:14 +0000",
    "user" : {
      "name" : "Ben Dolman",
      "screen_name" : "bdolman",
      "protected" : false,
      "id_str" : "15447634",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536762857006706688\/gzMSj-_Y_normal.jpeg",
      "id" : 15447634,
      "verified" : false
    }
  },
  "id" : 232353673819336704,
  "created_at" : "2012-08-06 05:53:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ellis",
      "screen_name" : "jzellis",
      "indices" : [ 3, 11 ],
      "id_str" : "1002941",
      "id" : 1002941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232352050372030464",
  "text" : "RT @jzellis: WE JUST FLUNG A ROBOT 350 MILLION MILES ACROSS THE SOLAR SYSTEM AND IT FUCKING WORKED",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232348699735515136",
    "text" : "WE JUST FLUNG A ROBOT 350 MILLION MILES ACROSS THE SOLAR SYSTEM AND IT FUCKING WORKED",
    "id" : 232348699735515136,
    "created_at" : "2012-08-06 05:33:41 +0000",
    "user" : {
      "name" : "Joshua Ellis",
      "screen_name" : "jzellis",
      "protected" : false,
      "id_str" : "1002941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551452242075598848\/e8PKwVL3_normal.jpeg",
      "id" : 1002941,
      "verified" : false
    }
  },
  "id" : 232352050372030464,
  "created_at" : "2012-08-06 05:47:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ziegler",
      "screen_name" : "zpower",
      "indices" : [ 3, 10 ],
      "id_str" : "15006743",
      "id" : 15006743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232350997488496640",
  "text" : "RT @zpower: and for the rest of their lives, they can respond to anything with \"yeah, well, I programmed a car to autonomously land on a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232350366912622592",
    "text" : "and for the rest of their lives, they can respond to anything with \"yeah, well, I programmed a car to autonomously land on another planet\"",
    "id" : 232350366912622592,
    "created_at" : "2012-08-06 05:40:18 +0000",
    "user" : {
      "name" : "Chris Ziegler",
      "screen_name" : "zpower",
      "protected" : false,
      "id_str" : "15006743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563896775879426048\/2iRHnSsO_normal.jpeg",
      "id" : 15006743,
      "verified" : true
    }
  },
  "id" : 232350997488496640,
  "created_at" : "2012-08-06 05:42:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Scott",
      "screen_name" : "tomscott",
      "indices" : [ 3, 12 ],
      "id_str" : "7816392",
      "id" : 7816392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232350148305514496",
  "text" : "RT @tomscott: Humanity just dropped a NUCLEAR-POWERED CAR, intact, onto ANOTHER PLANET with a SKY CRANE and it\u2019s SENDING US STUFF. BRING ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232349625208688640",
    "text" : "Humanity just dropped a NUCLEAR-POWERED CAR, intact, onto ANOTHER PLANET with a SKY CRANE and it\u2019s SENDING US STUFF. BRING IT ON UNIVERSE.",
    "id" : 232349625208688640,
    "created_at" : "2012-08-06 05:37:22 +0000",
    "user" : {
      "name" : "Tom Scott",
      "screen_name" : "tomscott",
      "protected" : false,
      "id_str" : "7816392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418422190359343104\/UQXoTiOR_normal.jpeg",
      "id" : 7816392,
      "verified" : false
    }
  },
  "id" : 232350148305514496,
  "created_at" : "2012-08-06 05:39:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232349062169497600",
  "text" : "RT @MarsCuriosity: I'm safely on the surface of Mars. GALE CRATER I AM IN YOU!!! #MSL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 62, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232348380431544320",
    "text" : "I'm safely on the surface of Mars. GALE CRATER I AM IN YOU!!! #MSL",
    "id" : 232348380431544320,
    "created_at" : "2012-08-06 05:32:25 +0000",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2793288186\/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 232349062169497600,
  "created_at" : "2012-08-06 05:35:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232348811144605696",
  "text" : "Fuck yes MARS! That was awesome to listen to live.",
  "id" : 232348811144605696,
  "created_at" : "2012-08-06 05:34:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrendanEich",
      "screen_name" : "BrendanEich",
      "indices" : [ 3, 15 ],
      "id_str" : "9533042",
      "id" : 9533042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/GTFGqNre",
      "expanded_url" : "http:\/\/www.ustream.tv\/nasajpl",
      "display_url" : "ustream.tv\/nasajpl"
    } ]
  },
  "geo" : { },
  "id_str" : "232347595287175168",
  "text" : "RT @BrendanEich: 5 min. to entry interface... http:\/\/t.co\/GTFGqNre",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/GTFGqNre",
        "expanded_url" : "http:\/\/www.ustream.tv\/nasajpl",
        "display_url" : "ustream.tv\/nasajpl"
      } ]
    },
    "geo" : { },
    "id_str" : "232345259923881984",
    "text" : "5 min. to entry interface... http:\/\/t.co\/GTFGqNre",
    "id" : 232345259923881984,
    "created_at" : "2012-08-06 05:20:01 +0000",
    "user" : {
      "name" : "BrendanEich",
      "screen_name" : "BrendanEich",
      "protected" : false,
      "id_str" : "9533042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000422625578\/aa4926528b3a1297ae2d9f5738d537a4_normal.jpeg",
      "id" : 9533042,
      "verified" : false
    }
  },
  "id" : 232347595287175168,
  "created_at" : "2012-08-06 05:29:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232324966601859072",
  "geo" : { },
  "id_str" : "232346755201654784",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr we have groups that play almost weekly\u2026nothing formal. You\u2019re welcome to join\u2026if you can drive into the city.",
  "id" : 232346755201654784,
  "in_reply_to_status_id" : 232324966601859072,
  "created_at" : "2012-08-06 05:25:57 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judson",
      "screen_name" : "judsonlester",
      "indices" : [ 0, 13 ],
      "id_str" : "216126673",
      "id" : 216126673
    }, {
      "name" : "FoCA",
      "screen_name" : "foca",
      "indices" : [ 14, 19 ],
      "id_str" : "3069991",
      "id" : 3069991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232331383996043265",
  "geo" : { },
  "id_str" : "232346576029360128",
  "in_reply_to_user_id" : 216126673,
  "text" : "@judsonlester @foca yeah I need to try it out!",
  "id" : 232346576029360128,
  "in_reply_to_status_id" : 232331383996043265,
  "created_at" : "2012-08-06 05:25:15 +0000",
  "in_reply_to_screen_name" : "judsonlester",
  "in_reply_to_user_id_str" : "216126673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/0FiOgDO4",
      "expanded_url" : "http:\/\/instagr.am\/p\/N-Ozf-M6oM\/",
      "display_url" : "instagr.am\/p\/N-Ozf-M6oM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "232324628180246528",
  "text" : "Le Havre. So many think thoughts. http:\/\/t.co\/0FiOgDO4",
  "id" : 232324628180246528,
  "created_at" : "2012-08-06 03:58:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232184251339116544",
  "geo" : { },
  "id_str" : "232260939557261313",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca took us a while to figure that out but it was great",
  "id" : 232260939557261313,
  "in_reply_to_status_id" : 232184251339116544,
  "created_at" : "2012-08-05 23:44:57 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232239905839931392",
  "geo" : { },
  "id_str" : "232260861555773440",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr not at all. Probably spent 1.5-2 hours deciphering broken English rules. Found a better manual online.",
  "id" : 232260861555773440,
  "in_reply_to_status_id" : 232239905839931392,
  "created_at" : "2012-08-05 23:44:39 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232251767348396032",
  "geo" : { },
  "id_str" : "232260716621611008",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer mostly lots of friends equally or more obsessed.",
  "id" : 232260716621611008,
  "in_reply_to_status_id" : 232251767348396032,
  "created_at" : "2012-08-05 23:44:04 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/NVITumwv",
      "expanded_url" : "http:\/\/instagr.am\/p\/N9kZ5MM6oU\/",
      "display_url" : "instagr.am\/p\/N9kZ5MM6oU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "232231260171415552",
  "text" : "Power Struggle is ridiculous. And awesome. http:\/\/t.co\/NVITumwv",
  "id" : 232231260171415552,
  "created_at" : "2012-08-05 21:47:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/mj0YJVuW",
      "expanded_url" : "http:\/\/instagr.am\/p\/N9O0RZM6m1\/",
      "display_url" : "instagr.am\/p\/N9O0RZM6m1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "232183796533960704",
  "text" : "The artwork for Power Struggle is fantastic. http:\/\/t.co\/mj0YJVuW",
  "id" : 232183796533960704,
  "created_at" : "2012-08-05 18:38:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231952454214897665",
  "geo" : { },
  "id_str" : "232163959707430913",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm will there be lightning talks?",
  "id" : 232163959707430913,
  "in_reply_to_status_id" : 231952454214897665,
  "created_at" : "2012-08-05 17:19:36 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/232128463253958656\/photo\/1",
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/kkKI7DE9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Azivm4LCcAAFEBA.jpg",
      "id_str" : "232128463258152960",
      "id" : 232128463258152960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Azivm4LCcAAFEBA.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/kkKI7DE9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232128463253958656",
  "text" : "Not happy about this\u2026Power Struggle\u2019s box says it plays 2 players. Instructions say 3. :[ http:\/\/t.co\/kkKI7DE9",
  "id" : 232128463253958656,
  "created_at" : "2012-08-05 14:58:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 6, 19 ],
      "id_str" : "23820237",
      "id" : 23820237
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 20, 31 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232124496549670913",
  "geo" : { },
  "id_str" : "232127370964905984",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu @IanCAnderson @Jonplussed \u0CA0_\u0CA0",
  "id" : 232127370964905984,
  "in_reply_to_status_id" : 232124496549670913,
  "created_at" : "2012-08-05 14:54:12 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 6, 19 ],
      "id_str" : "23820237",
      "id" : 23820237
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 20, 31 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232124028280791042",
  "geo" : { },
  "id_str" : "232124332086816769",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu @IanCAnderson @Jonplussed wtf?",
  "id" : 232124332086816769,
  "in_reply_to_status_id" : 232124028280791042,
  "created_at" : "2012-08-05 14:42:08 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232123401454620672",
  "text" : "@juliepagano woot!",
  "id" : 232123401454620672,
  "created_at" : "2012-08-05 14:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231980627157721089",
  "text" : "Nights without Geddy are pretty much guaranteed to include several Husky puppy YouTube rambles at the Q house. Picking him back up tomorrow!",
  "id" : 231980627157721089,
  "created_at" : "2012-08-05 05:11:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 12, 17 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 18, 29 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "Chad Metcalf",
      "screen_name" : "Capn_Sanjuro",
      "indices" : [ 30, 43 ],
      "id_str" : "316705897",
      "id" : 316705897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231972595451453440",
  "geo" : { },
  "id_str" : "231972917544640514",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @jhsu @Jonplussed @Capn_Sanjuro agh, we should have stayed another night. At home now though.",
  "id" : 231972917544640514,
  "in_reply_to_status_id" : 231972595451453440,
  "created_at" : "2012-08-05 04:40:28 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 13, 23 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "Joel Levin",
      "screen_name" : "joeldev",
      "indices" : [ 24, 32 ],
      "id_str" : "14130572",
      "id" : 14130572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231971124056055808",
  "geo" : { },
  "id_str" : "231971551275261952",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza @stevelosh @joeldev there\u2019s an actual reason. So many hidden assumptions in iOS\/Mac dev that seems to only come with time :[",
  "id" : 231971551275261952,
  "in_reply_to_status_id" : 231971124056055808,
  "created_at" : "2012-08-05 04:35:02 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Buffalogal in NYC",
      "screen_name" : "Buffalogal",
      "indices" : [ 0, 11 ],
      "id_str" : "14500105",
      "id" : 14500105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231970012569673729",
  "geo" : { },
  "id_str" : "231970896552808448",
  "in_reply_to_user_id" : 14500105,
  "text" : "@Buffalogal herp derp amherst swamps suburbs cheaper commute truck nutz",
  "id" : 231970896552808448,
  "in_reply_to_status_id" : 231970012569673729,
  "created_at" : "2012-08-05 04:32:26 +0000",
  "in_reply_to_screen_name" : "Buffalogal",
  "in_reply_to_user_id_str" : "14500105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 11, 23 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Joel Levin",
      "screen_name" : "joeldev",
      "indices" : [ 24, 32 ],
      "id_str" : "14130572",
      "id" : 14130572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231967645816201216",
  "geo" : { },
  "id_str" : "231970268900388864",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh @SteveStreza @joeldev same. I have always felt that type culture is broken somehow.",
  "id" : 231970268900388864,
  "in_reply_to_status_id" : 231967645816201216,
  "created_at" : "2012-08-05 04:29:56 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/siGrtqZU",
      "expanded_url" : "http:\/\/instagr.am\/p\/N7Luems6oB\/",
      "display_url" : "instagr.am\/p\/N7Luems6oB\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.5485600333, -80.0364119167 ]
  },
  "id_str" : "231895554098094080",
  "text" : "Picked up Citadels and Power Struggle on our way out of PGH. And...gross.  @ Legions Hobbies &amp; Games http:\/\/t.co\/siGrtqZU",
  "id" : 231895554098094080,
  "created_at" : "2012-08-04 23:33:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "231836228671119360",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary this reminds me! lets get some codeclimate buttons on http:\/\/t.co\/bdjsRgTW :D",
  "id" : 231836228671119360,
  "created_at" : "2012-08-04 19:37:18 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/39aBPPZs",
      "expanded_url" : "http:\/\/gittip.com",
      "display_url" : "gittip.com"
    }, {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 81, 102 ],
      "url" : "https:\/\/t.co\/MOSbzNd0",
      "expanded_url" : "https:\/\/github.com\/whit537\/www.gittip.com\/issues\/223",
      "display_url" : "github.com\/whit537\/www.gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231836006796623872",
  "text" : "Let's get http:\/\/t.co\/39aBPPZs on http:\/\/t.co\/bdjsRgTW! Anyone else +1 for this? https:\/\/t.co\/MOSbzNd0",
  "id" : 231836006796623872,
  "created_at" : "2012-08-04 19:36:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231733278678323200",
  "geo" : { },
  "id_str" : "231828479996477440",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 where are you? Have an idea for you.",
  "id" : 231828479996477440,
  "in_reply_to_status_id" : 231733278678323200,
  "created_at" : "2012-08-04 19:06:31 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/NJdqWZAL",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "231824593705394179",
  "text" : "Plowed through at least 200 support emails from http:\/\/t.co\/NJdqWZAL, and we're officially at inbox zero again. Feeling exhausted.",
  "id" : 231824593705394179,
  "created_at" : "2012-08-04 18:51:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "emacs",
      "screen_name" : "emachnic",
      "indices" : [ 0, 9 ],
      "id_str" : "16414747",
      "id" : 16414747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231807863922765824",
  "geo" : { },
  "id_str" : "231808123726356482",
  "in_reply_to_user_id" : 16414747,
  "text" : "@emachnic love the name of this gem for obvious reasons.",
  "id" : 231808123726356482,
  "in_reply_to_status_id" : 231807863922765824,
  "created_at" : "2012-08-04 17:45:38 +0000",
  "in_reply_to_screen_name" : "emachnic",
  "in_reply_to_user_id_str" : "16414747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Len Smith",
      "screen_name" : "ignu",
      "indices" : [ 0, 5 ],
      "id_str" : "6649832",
      "id" : 6649832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231801690544807936",
  "geo" : { },
  "id_str" : "231802173317578752",
  "in_reply_to_user_id" : 6649832,
  "text" : "@ignu how is this inaccurate?",
  "id" : 231802173317578752,
  "in_reply_to_status_id" : 231801690544807936,
  "created_at" : "2012-08-04 17:21:59 +0000",
  "in_reply_to_screen_name" : "ignu",
  "in_reply_to_user_id_str" : "6649832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231796881016098816",
  "geo" : { },
  "id_str" : "231798923214323713",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine lots of farmers markets but no all year indoor (and newish) ones",
  "id" : 231798923214323713,
  "in_reply_to_status_id" : 231796881016098816,
  "created_at" : "2012-08-04 17:09:04 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231791574336557056",
  "text" : "Went to the Pittsburgh Public Market for lunch. Holy crap, Buffalo needs a place like this. $35\/day for vendors, Fri\/Sat\/Sun all year.",
  "id" : 231791574336557056,
  "created_at" : "2012-08-04 16:39:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231738912446480385",
  "geo" : { },
  "id_str" : "231742661294428161",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 dude\u2026.",
  "id" : 231742661294428161,
  "in_reply_to_status_id" : 231738912446480385,
  "created_at" : "2012-08-04 13:25:30 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231586961759010817",
  "geo" : { },
  "id_str" : "231622488726061056",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 well, at least I can say I've high five punched the gittip guy.",
  "id" : 231622488726061056,
  "in_reply_to_status_id" : 231586961759010817,
  "created_at" : "2012-08-04 05:27:59 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 77, 91 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 97, 107 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231622274720083968",
  "text" : "Very happy to have hosted 10-15ish people to some board games new and old at @SteelCityRuby with @aquaranto. Love this kind of thing.",
  "id" : 231622274720083968,
  "created_at" : "2012-08-04 05:27:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231622080511229953",
  "text" : "RT @ashedryden: Board games need to become a staple at tech conferences.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231599973815422977",
    "text" : "Board games need to become a staple at tech conferences.",
    "id" : 231599973815422977,
    "created_at" : "2012-08-04 03:58:31 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 231622080511229953,
  "created_at" : "2012-08-04 05:26:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bryan von",
      "screen_name" : "alifeinwords",
      "indices" : [ 0, 13 ],
      "id_str" : "29196534",
      "id" : 29196534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231615671161741312",
  "geo" : { },
  "id_str" : "231620252528676864",
  "in_reply_to_user_id" : 29196534,
  "text" : "@alifeinwords so jonesing for Lloyd\u2019s right now.",
  "id" : 231620252528676864,
  "in_reply_to_status_id" : 231615671161741312,
  "created_at" : "2012-08-04 05:19:06 +0000",
  "in_reply_to_screen_name" : "alifeinwords",
  "in_reply_to_user_id_str" : "29196534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231560287071895552",
  "geo" : { },
  "id_str" : "231563112602542081",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison on the bus, arriving shortly",
  "id" : 231563112602542081,
  "in_reply_to_status_id" : 231560287071895552,
  "created_at" : "2012-08-04 01:32:02 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 46, 60 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc2012",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231560937121914880",
  "text" : "Heading back to the Hampton Inn for some post @SteelCityRuby games. Anyone else up, some to the lobby! #scrc2012",
  "id" : 231560937121914880,
  "created_at" : "2012-08-04 01:23:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231545745541578752",
  "text" : "Guessing that this is the first time Daft Punk has been played at this irish themed Pittsburgh sports bar.",
  "id" : 231545745541578752,
  "created_at" : "2012-08-04 00:23:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 1, 12 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 13, 26 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 27, 39 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc12",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231541518366801920",
  "text" : ".@ashedryden @steveklabnik @wesgarrison ZOMG board games at some point tonight? Or anyone from #scrc12 ?!",
  "id" : 231541518366801920,
  "created_at" : "2012-08-04 00:06:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/b3uLya8e",
      "expanded_url" : "http:\/\/4sq.com\/QO5vNH",
      "display_url" : "4sq.com\/QO5vNH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4439178805, -79.9973076582 ]
  },
  "id_str" : "231523386650677249",
  "text" : "This pub's huge beer selection makes up for its logo's use of Comic Sans. (@ Sharp Edge Bistro on Penn w\/ 2 others) http:\/\/t.co\/b3uLya8e",
  "id" : 231523386650677249,
  "created_at" : "2012-08-03 22:54:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231503395410829312",
  "geo" : { },
  "id_str" : "231504157587156992",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger we\u2019re on our way.",
  "id" : 231504157587156992,
  "in_reply_to_status_id" : 231503395410829312,
  "created_at" : "2012-08-03 21:37:46 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231502678453264384",
  "geo" : { },
  "id_str" : "231503187025207296",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger leaving Conf hotel now\u2026where are you?",
  "id" : 231503187025207296,
  "in_reply_to_status_id" : 231502678453264384,
  "created_at" : "2012-08-03 21:33:55 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 10, 24 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231501273856356352",
  "text" : "Anyone at @SteelCityRuby want to go for some burgers\/good beers before the ModCloth shindigs go down? Heading to Sharp Edge Bistro on Penn.",
  "id" : 231501273856356352,
  "created_at" : "2012-08-03 21:26:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231494088107651072",
  "geo" : { },
  "id_str" : "231494874938101760",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw feeling obligated to watch it now",
  "id" : 231494874938101760,
  "in_reply_to_status_id" : 231494088107651072,
  "created_at" : "2012-08-03 21:00:53 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 21, 27 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 111, 123 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 124, 127 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231489758948360192",
  "text" : "RT @aquaranto: Sorry @qrush, the best part of marrying you is getting to hang with the cool kids at scrc.  cc\/ @coreyhaines @j3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 6, 12 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Your Hype Man YEAH!",
        "screen_name" : "coreyhaines",
        "indices" : [ 96, 108 ],
        "id_str" : "11458102",
        "id" : 11458102
      }, {
        "name" : "Jeff Casimir",
        "screen_name" : "j3",
        "indices" : [ 109, 112 ],
        "id_str" : "1133971",
        "id" : 1133971
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231488770606759936",
    "text" : "Sorry @qrush, the best part of marrying you is getting to hang with the cool kids at scrc.  cc\/ @coreyhaines @j3",
    "id" : 231488770606759936,
    "created_at" : "2012-08-03 20:36:38 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 231489758948360192,
  "created_at" : "2012-08-03 20:40:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/HVkFUsYu",
      "expanded_url" : "http:\/\/i.imgur.com\/zhspP.gif",
      "display_url" : "i.imgur.com\/zhspP.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "231488293001371648",
  "text" : "13000 symbols on Rails boot. http:\/\/t.co\/HVkFUsYu",
  "id" : 231488293001371648,
  "created_at" : "2012-08-03 20:34:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231487973949071361",
  "text" : "On console boot, Symbol.all_symbols.size:\n\nirb 1.9.3-p194&gt;: 2958\n\nrails 3.2.3&gt; 13218",
  "id" : 231487973949071361,
  "created_at" : "2012-08-03 20:33:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 36, 39 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/HSUk9nwM",
      "expanded_url" : "http:\/\/i.imgur.com\/wB7E2.gif",
      "display_url" : "i.imgur.com\/wB7E2.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "231487545077272578",
  "text" : "Today's Ruby lesson courtesy of Mr. @j3: Symbol.all_symbols exists. http:\/\/t.co\/HSUk9nwM",
  "id" : 231487545077272578,
  "created_at" : "2012-08-03 20:31:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HVkFUsYu",
      "expanded_url" : "http:\/\/i.imgur.com\/zhspP.gif",
      "display_url" : "i.imgur.com\/zhspP.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "231475222656741376",
  "geo" : { },
  "id_str" : "231477047279620097",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden http:\/\/t.co\/HVkFUsYu",
  "id" : 231477047279620097,
  "in_reply_to_status_id" : 231475222656741376,
  "created_at" : "2012-08-03 19:50:03 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231476470688669696",
  "geo" : { },
  "id_str" : "231476952748412928",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle sadly i dont think github pages will support that :[",
  "id" : 231476952748412928,
  "in_reply_to_status_id" : 231476470688669696,
  "created_at" : "2012-08-03 19:49:40 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Burton",
      "screen_name" : "bjburton",
      "indices" : [ 0, 9 ],
      "id_str" : "14858358",
      "id" : 14858358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231475678967631872",
  "geo" : { },
  "id_str" : "231476044052434945",
  "in_reply_to_user_id" : 14858358,
  "text" : "@bjburton haha thanks. GIFs ftw!",
  "id" : 231476044052434945,
  "in_reply_to_status_id" : 231475678967631872,
  "created_at" : "2012-08-03 19:46:04 +0000",
  "in_reply_to_screen_name" : "bjburton",
  "in_reply_to_user_id_str" : "14858358",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Burton",
      "screen_name" : "bjburton",
      "indices" : [ 3, 12 ],
      "id_str" : "14858358",
      "id" : 14858358
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 101, 115 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc12",
      "indices" : [ 116, 123 ]
    }, {
      "text" : "bears",
      "indices" : [ 124, 130 ]
    }, {
      "text" : "tacos",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/hqI7dSzT",
      "expanded_url" : "http:\/\/github.com\/qrush\/m",
      "display_url" : "github.com\/qrush\/m"
    } ]
  },
  "geo" : { },
  "id_str" : "231475995687919617",
  "text" : "RT @bjburton: @qrush just gave the funniest lightning talk I've ever seen on http:\/\/t.co\/hqI7dSzT at @SteelCityRuby #scrc12 #bears #tacos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 87, 101 ],
        "id_str" : "404851600",
        "id" : 404851600
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scrc12",
        "indices" : [ 102, 109 ]
      }, {
        "text" : "bears",
        "indices" : [ 110, 116 ]
      }, {
        "text" : "tacos",
        "indices" : [ 117, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/hqI7dSzT",
        "expanded_url" : "http:\/\/github.com\/qrush\/m",
        "display_url" : "github.com\/qrush\/m"
      } ]
    },
    "geo" : { },
    "id_str" : "231475678967631872",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush just gave the funniest lightning talk I've ever seen on http:\/\/t.co\/hqI7dSzT at @SteelCityRuby #scrc12 #bears #tacos",
    "id" : 231475678967631872,
    "created_at" : "2012-08-03 19:44:37 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Ben Burton",
      "screen_name" : "bjburton",
      "protected" : false,
      "id_str" : "14858358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460844747490209793\/OYG4GJLt_normal.png",
      "id" : 14858358,
      "verified" : false
    }
  },
  "id" : 231475995687919617,
  "created_at" : "2012-08-03 19:45:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0425\u043B\u0443\u0434\u0435\u0432a \u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0430",
      "screen_name" : "casualpro",
      "indices" : [ 0, 10 ],
      "id_str" : "2815471651",
      "id" : 2815471651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/OYHmmgLA",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "231468296287961088",
  "geo" : { },
  "id_str" : "231475840179900416",
  "in_reply_to_user_id" : 120837801,
  "text" : "@casualpro BOOM! http:\/\/t.co\/OYHmmgLA",
  "id" : 231475840179900416,
  "in_reply_to_status_id" : 231468296287961088,
  "created_at" : "2012-08-03 19:45:15 +0000",
  "in_reply_to_screen_name" : "davejachimiak",
  "in_reply_to_user_id_str" : "120837801",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 37, 51 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/hc4ViZzS",
      "expanded_url" : "http:\/\/quaran.to\/m\/",
      "display_url" : "quaran.to\/m\/"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/4mbNKXRA",
      "expanded_url" : "http:\/\/github.com\/qrush\/m",
      "display_url" : "github.com\/qrush\/m"
    } ]
  },
  "geo" : { },
  "id_str" : "231475687918292995",
  "text" : "Did a little lightning talk again at @SteelCityRuby about m! Go run your tests by line number! http:\/\/t.co\/hc4ViZzS http:\/\/t.co\/4mbNKXRA",
  "id" : 231475687918292995,
  "created_at" : "2012-08-03 19:44:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/LBDOmaqK",
      "expanded_url" : "http:\/\/instagr.am\/p\/N358NuM6kF\/",
      "display_url" : "instagr.am\/p\/N358NuM6kF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4506772834, -79.9854486163 ]
  },
  "id_str" : "231434258043006976",
  "text" : "Stillers country official food.  @ Primanti Brothers http:\/\/t.co\/LBDOmaqK",
  "id" : 231434258043006976,
  "created_at" : "2012-08-03 17:00:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 28, 39 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/0y26BQOz",
      "expanded_url" : "http:\/\/4sq.com\/NQQSKn",
      "display_url" : "4sq.com\/NQQSKn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4506772834, -79.9854486163 ]
  },
  "id_str" : "231429857345667072",
  "text" : "I'm at Primanti Brothers w\/ @tenderlove http:\/\/t.co\/0y26BQOz",
  "id" : 231429857345667072,
  "created_at" : "2012-08-03 16:42:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 3, 13 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wWmWyfjK",
      "expanded_url" : "http:\/\/bit.ly\/NXBvgv",
      "display_url" : "bit.ly\/NXBvgv"
    } ]
  },
  "geo" : { },
  "id_str" : "231417971522813952",
  "text" : "RT @magnachef: .@CoworkBuffalo is a great example of just getting shit done in #Buffalo. We didn\u2019t wait for gov\u2019t. 4 guys, minimal $$ ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 1, 15 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/wWmWyfjK",
        "expanded_url" : "http:\/\/bit.ly\/NXBvgv",
        "display_url" : "bit.ly\/NXBvgv"
      } ]
    },
    "geo" : { },
    "id_str" : "231417062193496064",
    "text" : ".@CoworkBuffalo is a great example of just getting shit done in #Buffalo. We didn\u2019t wait for gov\u2019t. 4 guys, minimal $$ http:\/\/t.co\/wWmWyfjK",
    "id" : 231417062193496064,
    "created_at" : "2012-08-03 15:51:41 +0000",
    "user" : {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "protected" : false,
      "id_str" : "23703410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557740024620261376\/4Td91096_normal.jpeg",
      "id" : 23703410,
      "verified" : false
    }
  },
  "id" : 231417971522813952,
  "created_at" : "2012-08-03 15:55:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/6L0QHmak",
      "expanded_url" : "http:\/\/innovationtrail.org\/post\/coworkbuffalo-crafts-community-office-space",
      "display_url" : "innovationtrail.org\/post\/coworkbuf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231413880306405377",
  "text" : "Super proud to be doing something positive for Buffalo: http:\/\/t.co\/6L0QHmak",
  "id" : 231413880306405377,
  "created_at" : "2012-08-03 15:39:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robison",
      "screen_name" : "robisonrobison",
      "indices" : [ 0, 15 ],
      "id_str" : "47352570",
      "id" : 47352570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231386358869016577",
  "geo" : { },
  "id_str" : "231386542281736193",
  "in_reply_to_user_id" : 47352570,
  "text" : "@robisonrobison woot!! Thanks man.",
  "id" : 231386542281736193,
  "in_reply_to_status_id" : 231386358869016577,
  "created_at" : "2012-08-03 13:50:25 +0000",
  "in_reply_to_screen_name" : "robisonrobison",
  "in_reply_to_user_id_str" : "47352570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231382985537093632",
  "geo" : { },
  "id_str" : "231385454346387457",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy is it online yet?!",
  "id" : 231385454346387457,
  "in_reply_to_status_id" : 231382985537093632,
  "created_at" : "2012-08-03 13:46:05 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 13, 27 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231385383026438144",
  "text" : "Hey hey it\u2019s @SteelCityRuby time! Pumped for these two days.",
  "id" : 231385383026438144,
  "created_at" : "2012-08-03 13:45:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 37, 42 ],
      "id_str" : "20612109",
      "id" : 20612109
    }, {
      "name" : "Robison",
      "screen_name" : "robisonrobison",
      "indices" : [ 120, 135 ],
      "id_str" : "47352570",
      "id" : 47352570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231358115818397696",
  "text" : "RT @coworkbuffalo: We were *just* on @WBFO this morning! Likely again later, and we'll post the link online. Nice work, @robisonrobison !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WBFO",
        "screen_name" : "WBFO",
        "indices" : [ 18, 23 ],
        "id_str" : "20612109",
        "id" : 20612109
      }, {
        "name" : "Robison",
        "screen_name" : "robisonrobison",
        "indices" : [ 101, 116 ],
        "id_str" : "47352570",
        "id" : 47352570
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231354720458002432",
    "text" : "We were *just* on @WBFO this morning! Likely again later, and we'll post the link online. Nice work, @robisonrobison !",
    "id" : 231354720458002432,
    "created_at" : "2012-08-03 11:43:58 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 231358115818397696,
  "created_at" : "2012-08-03 11:57:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/Z4JeE3RM",
      "expanded_url" : "https:\/\/plus.google.com\/101960720994009339267\/posts\/R58WgWwN9jp",
      "display_url" : "plus.google.com\/10196072099400\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231251915973984256",
  "text" : "\"I'm pretty sure the concept of a hidden file was an unintended consequence. It was certainly a mistake.\" https:\/\/t.co\/Z4JeE3RM",
  "id" : 231251915973984256,
  "created_at" : "2012-08-03 04:55:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231248802240163841",
  "geo" : { },
  "id_str" : "231251639070244864",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove haha no. :[",
  "id" : 231251639070244864,
  "in_reply_to_status_id" : 231248802240163841,
  "created_at" : "2012-08-03 04:54:21 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231244311096856576",
  "geo" : { },
  "id_str" : "231248222117576704",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove I thought you liked sausage parties?",
  "id" : 231248222117576704,
  "in_reply_to_status_id" : 231244311096856576,
  "created_at" : "2012-08-03 04:40:47 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 3, 14 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 64, 70 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 75, 85 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SteelCityRuby",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231248136339873794",
  "text" : "RT @Jonplussed: Pre-gamed #SteelCityRuby with games courtesy of @qrush and @aquaranto. I love this group. See errbody in the AM!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 48, 54 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 59, 69 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SteelCityRuby",
        "indices" : [ 10, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231246288912523265",
    "text" : "Pre-gamed #SteelCityRuby with games courtesy of @qrush and @aquaranto. I love this group. See errbody in the AM!",
    "id" : 231246288912523265,
    "created_at" : "2012-08-03 04:33:06 +0000",
    "user" : {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "protected" : false,
      "id_str" : "38408851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471328341526462464\/hNg5dFGn_normal.jpeg",
      "id" : 38408851,
      "verified" : false
    }
  },
  "id" : 231248136339873794,
  "created_at" : "2012-08-03 04:40:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231239960945111040",
  "geo" : { },
  "id_str" : "231241515601645568",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik \/play trombone",
  "id" : 231241515601645568,
  "in_reply_to_status_id" : 231239960945111040,
  "created_at" : "2012-08-03 04:14:08 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc2012",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231239377337069569",
  "text" : "Broke out some board games in the hotel lobby at #scrc2012. Yap.",
  "id" : 231239377337069569,
  "created_at" : "2012-08-03 04:05:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231238737936392193",
  "geo" : { },
  "id_str" : "231239112844275712",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove some folks are in the hotel lobby if you want to say hi!!",
  "id" : 231239112844275712,
  "in_reply_to_status_id" : 231238737936392193,
  "created_at" : "2012-08-03 04:04:35 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231222539635011586",
  "geo" : { },
  "id_str" : "231222733223104512",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman we could be drinking yanglings right now.",
  "id" : 231222733223104512,
  "in_reply_to_status_id" : 231222539635011586,
  "created_at" : "2012-08-03 02:59:30 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 11, 23 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231221860132610048",
  "geo" : { },
  "id_str" : "231222117574774784",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @wesgarrison is there a table in there?! We have one in our room.",
  "id" : 231222117574774784,
  "in_reply_to_status_id" : 231221860132610048,
  "created_at" : "2012-08-03 02:57:03 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231221534537158656",
  "geo" : { },
  "id_str" : "231221821607927809",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden ah. Kind of done driving tonight\u2026tomorrow!",
  "id" : 231221821607927809,
  "in_reply_to_status_id" : 231221534537158656,
  "created_at" : "2012-08-03 02:55:52 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231220513232539649",
  "text" : "Pittsburgh! Hello! You are yellow.",
  "id" : 231220513232539649,
  "created_at" : "2012-08-03 02:50:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231195167615512576",
  "geo" : { },
  "id_str" : "231218222706356224",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Conf hotel. Arrived.",
  "id" : 231218222706356224,
  "in_reply_to_status_id" : 231195167615512576,
  "created_at" : "2012-08-03 02:41:34 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 27, 41 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc12",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231191231131176960",
  "text" : "~2 hours to Pittsburgh for @SteelCityRuby ! Anyone going to be up for drinks\/games? #scrc12",
  "id" : 231191231131176960,
  "created_at" : "2012-08-03 00:54:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231071756025204736",
  "geo" : { },
  "id_str" : "231072172486053888",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd seriously guys! no food trucks downtown at all this week :(",
  "id" : 231072172486053888,
  "in_reply_to_status_id" : 231071756025204736,
  "created_at" : "2012-08-02 17:01:13 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 44, 58 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231061015343812609",
  "text" : "Saying goodbye to Shipmaster Dog avatar for @SteelCityRuby. Pumped to head to Pittsburgh tonight!",
  "id" : 231061015343812609,
  "created_at" : "2012-08-02 16:16:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Levett",
      "screen_name" : "justjonlevett",
      "indices" : [ 0, 14 ],
      "id_str" : "186551909",
      "id" : 186551909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 130 ],
      "url" : "https:\/\/t.co\/ufU8NUiv",
      "expanded_url" : "https:\/\/github.com\/37signals\/campfire-api",
      "display_url" : "github.com\/37signals\/camp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "231055457614176257",
  "geo" : { },
  "id_str" : "231058915222233089",
  "in_reply_to_user_id" : 186551909,
  "text" : "@justjonlevett hey, I'd try contacting the maintainers of that library. Or, give a shot at writing your own: https:\/\/t.co\/ufU8NUiv",
  "id" : 231058915222233089,
  "in_reply_to_status_id" : 231055457614176257,
  "created_at" : "2012-08-02 16:08:32 +0000",
  "in_reply_to_screen_name" : "justjonlevett",
  "in_reply_to_user_id_str" : "186551909",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230877031565516800",
  "geo" : { },
  "id_str" : "230877329889583105",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle disown your family for 3, combo deal",
  "id" : 230877329889583105,
  "in_reply_to_status_id" : 230877031565516800,
  "created_at" : "2012-08-02 04:06:59 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230875999334711296",
  "text" : "The scientologists were out on Elmwood with a table and cookies today. Looked very inconspicuous until the ARE YOU HAPPY? flyers.",
  "id" : 230875999334711296,
  "created_at" : "2012-08-02 04:01:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230841012606599168",
  "geo" : { },
  "id_str" : "230848720302907392",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending adorable. Needs to meet Geddy soon.",
  "id" : 230848720302907392,
  "in_reply_to_status_id" : 230841012606599168,
  "created_at" : "2012-08-02 02:13:18 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230847448883535872",
  "geo" : { },
  "id_str" : "230847650075922432",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison we\u2019re heading out Saturday. :\/",
  "id" : 230847650075922432,
  "in_reply_to_status_id" : 230847448883535872,
  "created_at" : "2012-08-02 02:09:03 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230845476600172544",
  "geo" : { },
  "id_str" : "230847300975620097",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison going to bring some but not sure when we\u2019ll have time.",
  "id" : 230847300975620097,
  "in_reply_to_status_id" : 230845476600172544,
  "created_at" : "2012-08-02 02:07:40 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 7, 16 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230802335922790401",
  "geo" : { },
  "id_str" : "230802418860969985",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @bquarant that was no.",
  "id" : 230802418860969985,
  "in_reply_to_status_id" : 230802335922790401,
  "created_at" : "2012-08-01 23:09:19 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230800540404174848",
  "geo" : { },
  "id_str" : "230802335922790401",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant",
  "id" : 230802335922790401,
  "in_reply_to_status_id" : 230800540404174848,
  "created_at" : "2012-08-01 23:08:59 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230798472817831937",
  "text" : "Dogs are the original mouthbreathers. Especially after ~3 mile bike rides.",
  "id" : 230798472817831937,
  "created_at" : "2012-08-01 22:53:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230735146364579840",
  "text" : "RT @rjs: Habitually reading posts about startup life creates an illusion of making progress. Beware time spent on Hacker News vs. on you ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230729780956377088",
    "text" : "Habitually reading posts about startup life creates an illusion of making progress. Beware time spent on Hacker News vs. on your product.",
    "id" : 230729780956377088,
    "created_at" : "2012-08-01 18:20:41 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 230735146364579840,
  "created_at" : "2012-08-01 18:42:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "indices" : [ 0, 6 ],
      "id_str" : "3116191",
      "id" : 3116191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230724881900261378",
  "geo" : { },
  "id_str" : "230725006664019968",
  "in_reply_to_user_id" : 3116191,
  "text" : "@rails THANK YOU",
  "id" : 230725006664019968,
  "in_reply_to_status_id" : 230724881900261378,
  "created_at" : "2012-08-01 18:01:42 +0000",
  "in_reply_to_screen_name" : "rails",
  "in_reply_to_user_id_str" : "3116191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "indices" : [ 3, 9 ],
      "id_str" : "3116191",
      "id" : 3116191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230724977010298880",
  "text" : "RT @rails: We have decided to stop introducing API deprecations in all point releases going forward. From now on, it'll only happen in m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230724881900261378",
    "text" : "We have decided to stop introducing API deprecations in all point releases going forward. From now on, it'll only happen in majors\/minors.",
    "id" : 230724881900261378,
    "created_at" : "2012-08-01 18:01:13 +0000",
    "user" : {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "protected" : false,
      "id_str" : "3116191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000296761640\/2e69482e09113a93ccdd109c36f7fca7_normal.png",
      "id" : 3116191,
      "verified" : false
    }
  },
  "id" : 230724977010298880,
  "created_at" : "2012-08-01 18:01:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "230710716250857472",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing The Rolling Stones: Loving Cup \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 230710716250857472,
  "created_at" : "2012-08-01 17:04:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0E50Vr0t",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/arts-and-lifestyle\/2012\/08\/geography-bars-and-restaurants\/2770\/",
      "display_url" : "theatlanticcities.com\/arts-and-lifes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230700043362004992",
  "text" : "RT @BuffaloRising: NOT SHOCKING: Buffalo has 6.8 bars per 10,000 households, the 7th highest ratio of any city in the country. http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/0E50Vr0t",
        "expanded_url" : "http:\/\/www.theatlanticcities.com\/arts-and-lifestyle\/2012\/08\/geography-bars-and-restaurants\/2770\/",
        "display_url" : "theatlanticcities.com\/arts-and-lifes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "230699622534885378",
    "text" : "NOT SHOCKING: Buffalo has 6.8 bars per 10,000 households, the 7th highest ratio of any city in the country. http:\/\/t.co\/0E50Vr0t",
    "id" : 230699622534885378,
    "created_at" : "2012-08-01 16:20:50 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 230700043362004992,
  "created_at" : "2012-08-01 16:22:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "230683087539933184",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 230683087539933184,
  "created_at" : "2012-08-01 15:15:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 3, 9 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230680397602775040",
  "text" : "RT @ahuj9: If you play The Beatles backwards, it's three guys helping a resurrected man quit heroin, then teaming up to be the perfect b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230679132260941824",
    "text" : "If you play The Beatles backwards, it's three guys helping a resurrected man quit heroin, then teaming up to be the perfect boy band.",
    "id" : 230679132260941824,
    "created_at" : "2012-08-01 14:59:25 +0000",
    "user" : {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "protected" : false,
      "id_str" : "205281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2438738477\/m3tcrt9kvs9x0ff84b31_normal.jpeg",
      "id" : 205281746,
      "verified" : false
    }
  },
  "id" : 230680397602775040,
  "created_at" : "2012-08-01 15:04:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230505951067770880",
  "geo" : { },
  "id_str" : "230673806702821377",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz welcome to the 5 letter handle club. HGMNZZZZ",
  "id" : 230673806702821377,
  "in_reply_to_status_id" : 230505951067770880,
  "created_at" : "2012-08-01 14:38:15 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 7, 18 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230437405457530881",
  "geo" : { },
  "id_str" : "230671940904423425",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan @trevorturk Update updates update Update updating update Update",
  "id" : 230671940904423425,
  "in_reply_to_status_id" : 230437405457530881,
  "created_at" : "2012-08-01 14:30:51 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230432841840865281",
  "geo" : { },
  "id_str" : "230669114899836928",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog these are great. thanks dude!",
  "id" : 230669114899836928,
  "in_reply_to_status_id" : 230432841840865281,
  "created_at" : "2012-08-01 14:19:37 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Knapp",
      "screen_name" : "coffeeandcode",
      "indices" : [ 0, 14 ],
      "id_str" : "15466288",
      "id" : 15466288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230644506691764224",
  "geo" : { },
  "id_str" : "230651679945678848",
  "in_reply_to_user_id" : 15466288,
  "text" : "@coffeeandcode sure!",
  "id" : 230651679945678848,
  "in_reply_to_status_id" : 230644506691764224,
  "created_at" : "2012-08-01 13:10:20 +0000",
  "in_reply_to_screen_name" : "coffeeandcode",
  "in_reply_to_user_id_str" : "15466288",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2008_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1089417265",
  "text" : "Happy 2009!",
  "id" : 1089417265,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Martens",
      "screen_name" : "boblmartens",
      "indices" : [ 0, 12 ],
      "id_str" : "14486263",
      "id" : 14486263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1086232544",
  "geo" : { },
  "id_str" : "1087230009",
  "in_reply_to_user_id" : 14486263,
  "text" : "@boblmartens I fail.",
  "id" : 1087230009,
  "in_reply_to_status_id" : 1086232544,
  "created_at" : "2008-12-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "boblmartens",
  "in_reply_to_user_id_str" : "14486263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1087873854",
  "text" : "It would be really nice if this stupid laptop didn't freeze every few minutes. (Someone buy me a mac...PLEASE)",
  "id" : 1087873854,
  "created_at" : "2008-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1088370905",
  "text" : "Boston is a tad bit snowy today.",
  "id" : 1088370905,
  "created_at" : "2008-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1088395344",
  "text" : "There's a lot of awesome little shops and cafes on Tremont St next to the Common. Did I mention I like Boston?",
  "id" : 1088395344,
  "created_at" : "2008-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1083098367",
  "text" : "Next year Bills. You'll get them. (As long as they actually play Trent Edwards)",
  "id" : 1083098367,
  "created_at" : "2008-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1083521385",
  "text" : "C-C-C-Crustacean Breaker! http:\/\/tinyurl.com\/884n9c",
  "id" : 1083521385,
  "created_at" : "2008-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1083544631",
  "text" : "Every time I visit GoDaddy it looks different.",
  "id" : 1083544631,
  "created_at" : "2008-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Hooks",
      "screen_name" : "matthooks",
      "indices" : [ 0, 10 ],
      "id_str" : "14592020",
      "id" : 14592020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1083674427",
  "geo" : { },
  "id_str" : "1083988946",
  "in_reply_to_user_id" : 14592020,
  "text" : "@matthooks Asking nicely, having a readme, and linking me to your project helps :) I'm going to be posting what I consider guidelines soon.",
  "id" : 1083988946,
  "in_reply_to_status_id" : 1083674427,
  "created_at" : "2008-12-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "matthooks",
  "in_reply_to_user_id_str" : "14592020",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1082258452",
  "text" : "It's 60 degrees out in Buffalo and ridiculously windy. Seriously, this is some wacky weather for December. Bills game will be nuts today.",
  "id" : 1082258452,
  "created_at" : "2008-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080487059",
  "text" : "I forgot how awesome Super Smash Bros and Mario Tennis are for the N64. Nothing beats a good game of either even on modern systems.",
  "id" : 1080487059,
  "created_at" : "2008-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Nakajima",
      "screen_name" : "nakajima",
      "indices" : [ 0, 9 ],
      "id_str" : "652983",
      "id" : 652983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1080511240",
  "geo" : { },
  "id_str" : "1080529234",
  "in_reply_to_user_id" : 652983,
  "text" : "@nakajima Last name domains ftw! I own quaran.to :D",
  "id" : 1080529234,
  "in_reply_to_status_id" : 1080511240,
  "created_at" : "2008-12-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "nakajima",
  "in_reply_to_user_id_str" : "652983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1081344120",
  "text" : "THERE CAN ONLY BE ONE. http:\/\/i40.tinypic.com\/2hi1gmt.jpg",
  "id" : 1081344120,
  "created_at" : "2008-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1078946153",
  "text" : "Got a GitHub fork you shirt for christmas. @ablissfulgal rules.",
  "id" : 1078946153,
  "created_at" : "2008-12-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079543961",
  "text" : "Wondering if I dare to head to the mall today. It'll probably be a madhouse.",
  "id" : 1079543961,
  "created_at" : "2008-12-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075524606",
  "text" : "ack --thpppt",
  "id" : 1075524606,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075535972",
  "text" : "Firefox feels it's necessary to tell me about my rights. Does it really matter?",
  "id" : 1075535972,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lockfort",
      "screen_name" : "clockfort",
      "indices" : [ 0, 10 ],
      "id_str" : "16381663",
      "id" : 16381663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1075760868",
  "geo" : { },
  "id_str" : "1075764872",
  "in_reply_to_user_id" : 16381663,
  "text" : "@clockfort welcome to the dark side (being git) if you want help let me know!",
  "id" : 1075764872,
  "in_reply_to_status_id" : 1075760868,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "clockfort",
  "in_reply_to_user_id_str" : "16381663",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075767620",
  "text" : "Being home means playing my old N64. And it means I just unlocked Ness again in Super Smash Brothers. Hell yes, PK thunder.",
  "id" : 1075767620,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1075765531",
  "geo" : { },
  "id_str" : "1075769350",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy UR DOIN IT WRONG. gem sources -a http:\/\/gems.github.com; gem install username-project. It's that easy.",
  "id" : 1075769350,
  "in_reply_to_status_id" : 1075765531,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake DHH",
      "screen_name" : "faked2h",
      "indices" : [ 3, 11 ],
      "id_str" : "18298949",
      "id" : 18298949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073482803",
  "text" : "RT @faked2h: Look at all the REAL applications using Rails: http:\/\/is.gd\/cPI4 Yeah, you're welcome sluts. You all owe me big time.",
  "id" : 1073482803,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073651771",
  "text" : "Just can't seem to get motivated tonight.",
  "id" : 1073651771,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073860277",
  "text" : "I'd love to put my blog on GitHub...but I need to find a way for my RSS feed to live and get links to redirect. I'd miss my domain name too.",
  "id" : 1073860277,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075250368",
  "text" : "Holy crap, Merb and Rails are merging.",
  "id" : 1075250368,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tatrick pulskie",
      "screen_name" : "PatrickTulskie",
      "indices" : [ 0, 15 ],
      "id_str" : "9723312",
      "id" : 9723312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1071854472",
  "geo" : { },
  "id_str" : "1072763981",
  "in_reply_to_user_id" : 9723312,
  "text" : "@PatrickTulskie Failwhale spotted, port bow!",
  "id" : 1072763981,
  "in_reply_to_status_id" : 1071854472,
  "created_at" : "2008-12-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "PatrickTulskie",
  "in_reply_to_user_id_str" : "9723312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069780076",
  "text" : "Legal Sea Foods is so delicious. Doesn't matter what you order, it's gonna be fantastic.",
  "id" : 1069780076,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070925121",
  "text" : "Made it back to Rochester in one piece. Horrible snow storms out there today.",
  "id" : 1070925121,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068188280",
  "text" : "Waiting for the Nutcracker to start! Excited to see my little cousin on the big stage.",
  "id" : 1068188280,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069271915",
  "text" : "In awe of the Lisp Machine at the MIT Museum. I want to build one.",
  "id" : 1069271915,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067220595",
  "text" : "Got into Boston just find and had to pay for the internet. Boohiss!",
  "id" : 1067220595,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067349167",
  "text" : "SNOW. IT IS COMING.",
  "id" : 1067349167,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067654840",
  "text" : "Snow is starting to fall here in Boston! About time.",
  "id" : 1067654840,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068054007",
  "text" : "Trying to finish a quiz on obscure C knowledge for my PLC class. I really dislike C...I wish it wasn't so important or widely used.",
  "id" : 1068054007,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1065453644",
  "text" : "How can people stand Slashdot's commenting system? There's so many little doodads and widgets. So much for simple design.",
  "id" : 1065453644,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1065574021",
  "text" : "The Rails\/Merb animosity is worse than Livejournal drama. I can really see why the Ruby community is sometimes compared to Fight Club.",
  "id" : 1065574021,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    }, {
      "name" : "Antonio Cagiano",
      "screen_name" : "ACagiano",
      "indices" : [ 19, 28 ],
      "id_str" : "1180006508",
      "id" : 1180006508
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 76, 83 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1065577553",
  "geo" : { },
  "id_str" : "1065585667",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist Check out @acagiano 's merb post. I'm quite impressed at how civil @wycats comes across as in the comments.",
  "id" : 1065585667,
  "in_reply_to_status_id" : 1065577553,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    }, {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 48, 58 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1065588011",
  "geo" : { },
  "id_str" : "1065589595",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist I suck at names. Stupid phone. I meant @acangiano",
  "id" : 1065589595,
  "in_reply_to_status_id" : 1065588011,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1065760298",
  "text" : "Looks like I'm headed for Boston tonight with @ablissfulgal so we can avoid the oncoming snowfall. NWS says 9 inches expected here in Roch.",
  "id" : 1065760298,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1065830639",
  "text" : "Wow, Gov. Paterson wants to see an obesity tax placed on drinks with high calorie content in an NYT editorial. This guy loves controversy.",
  "id" : 1065830639,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061978110",
  "text" : "Feeling like a Perl hacker.  \/((private|protected|default|public)( static)?)\\s+\\w+\\s+(\\w+)\\((.*)\\)\/ SO UGLY.",
  "id" : 1061978110,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063190517",
  "text" : "It shouldn't take 10 minutes to transfer 30 megs to my 8 gig thumb drive. WTF, OSX.",
  "id" : 1063190517,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063499548",
  "text" : "Another awesome part about winter: clementines. Delicious.",
  "id" : 1063499548,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063501747",
  "text" : "SO MUCH STAR TREK. Why wasn't I alerted of this before. http:\/\/tinyurl.com\/4npwne",
  "id" : 1063501747,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061204044",
  "text" : "Seriously, who is on top of GCCIS and why are they making so much noise? The entire classroom is shaking!",
  "id" : 1061204044,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061241925",
  "text" : "Seriously I don't want to be around when the ceiling collapses here. The whole room is getting shook up by whatever they are doing.",
  "id" : 1061241925,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061371595",
  "text" : "Ruby is pretty crazy in how things can be renamed\/aliased on the fly, but Forth is just batshit insane in how it allows aliasing of keywords",
  "id" : 1061371595,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Sonstein",
      "screen_name" : "jeffsonstein",
      "indices" : [ 0, 13 ],
      "id_str" : "14360516",
      "id" : 14360516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1061551039",
  "geo" : { },
  "id_str" : "1061552284",
  "in_reply_to_user_id" : 14360516,
  "text" : "@jeffsonstein how sad. all se\/cs\/it majors should know how to use grep\/regex. its like a carpenter not knowing how to use a saw.",
  "id" : 1061552284,
  "in_reply_to_status_id" : 1061551039,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeffsonstein",
  "in_reply_to_user_id_str" : "14360516",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059841596",
  "text" : "GitHub pages are a great idea (for big projects!). Now if I could find something useful to put on here. http:\/\/qrush.github.com\/",
  "id" : 1059841596,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060016486",
  "text" : "I really hate recursion.",
  "id" : 1060016486,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060066150",
  "text" : "Got a handle on the recursion by sketching out the algorithm with formulas. Definitely a lot easier that way.",
  "id" : 1060066150,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Nakajima",
      "screen_name" : "nakajima",
      "indices" : [ 0, 9 ],
      "id_str" : "652983",
      "id" : 652983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1060078937",
  "geo" : { },
  "id_str" : "1060451838",
  "in_reply_to_user_id" : 652983,
  "text" : "@nakajima I think my class will be touring Scheme later in the quarter, so I'll definitely be reading it. (Along with Prolog, Forth, C iirc)",
  "id" : 1060451838,
  "in_reply_to_status_id" : 1060078937,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "nakajima",
  "in_reply_to_user_id_str" : "652983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060499325",
  "text" : "Tests at 8am FTL.",
  "id" : 1060499325,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060650525",
  "text" : "Flying Spaghetti Monster in christmas lights. Epic. http:\/\/tinyurl.com\/5ocwnf",
  "id" : 1060650525,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061168340",
  "text" : "Finishing up creating a presentation on Dahl and Nygaard, the fathers of OO programming. Yes, I snuck Family Guy and Tron in there.",
  "id" : 1061168340,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1057938324",
  "text" : "Reading the Watchmen when I really should be catching on my homework for this week.",
  "id" : 1057938324,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 82, 93 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058001002",
  "text" : "GitHub Rebase #8: Plenty of new projects, and featuring http:\/\/cappuccino.org and @jnunemaker. Stats failboated though. :( http:\/\/is.gd\/bIAO",
  "id" : 1058001002,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1058385064",
  "geo" : { },
  "id_str" : "1058813473",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker No problem :) Keep it up!",
  "id" : 1058813473,
  "in_reply_to_status_id" : 1058385064,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1058741118",
  "geo" : { },
  "id_str" : "1058813933",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal Oh snap. I better get yours at some point. (Crap.)",
  "id" : 1058813933,
  "in_reply_to_status_id" : 1058741118,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059239562",
  "text" : "http:\/\/whendoitest.com\/",
  "id" : 1059239562,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059378617",
  "text" : "Some frank advice to incoming CS students. I think it applies to pretty much any student in the computing field: http:\/\/is.gd\/bQvu",
  "id" : 1059378617,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1057286709",
  "text" : "I hate the Jets.",
  "id" : 1057286709,
  "created_at" : "2008-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1055415343",
  "text" : "Spotted around 5 different series of trucks with cherrypickers on the 90 heading to Erie. Where are they all going?",
  "id" : 1055415343,
  "created_at" : "2008-12-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1052421600",
  "geo" : { },
  "id_str" : "1052423792",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat I love the comment \"+1 Also could you add support for the BREW method, as POST is deprecated for modern coffee pots.\"",
  "id" : 1052423792,
  "in_reply_to_status_id" : 1052421600,
  "created_at" : "2008-12-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1052220182",
  "geo" : { },
  "id_str" : "1052464985",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Maybe you smell.",
  "id" : 1052464985,
  "in_reply_to_status_id" : 1052220182,
  "created_at" : "2008-12-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1053557669",
  "text" : "SIMBL + MegaZoomer = awesome fullscreen Terminal by just hitting Command+Enter.  http:\/\/is.gd\/87d",
  "id" : 1053557669,
  "created_at" : "2008-12-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1053672992",
  "geo" : { },
  "id_str" : "1053676471",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman I don't think there's a way. Just print a bunch of warnings.",
  "id" : 1053676471,
  "in_reply_to_status_id" : 1053672992,
  "created_at" : "2008-12-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051401556",
  "text" : "Yay truth tables! if only all engineering was this simple (and fun)",
  "id" : 1051401556,
  "created_at" : "2008-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051754949",
  "text" : "Looks like I waited long enough to upgrade to WP 2.6.whatever that 2.7 came out. I really hate upgrading Wordpress.",
  "id" : 1051754949,
  "created_at" : "2008-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051805009",
  "text" : "If you could only follow 10 people on twitter, who would they be? Here's my list, what's yours? http:\/\/is.gd\/bc8z",
  "id" : 1051805009,
  "created_at" : "2008-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051947356",
  "text" : "Sweet, my group will be presenting on Erlang for my PLC class. Finally a chance to learn its dark magic has come.",
  "id" : 1051947356,
  "created_at" : "2008-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051954969",
  "text" : "I don't know what people are doing on the roof of Building 70, but they're making a crapload of noise. WHY.",
  "id" : 1051954969,
  "created_at" : "2008-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1048619290",
  "text" : "Whittled down to 1,337 following. Much harder than I thought. I wonder if there's some API call to unfollow that I can use instead.",
  "id" : 1048619290,
  "created_at" : "2008-12-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1049813765",
  "geo" : { },
  "id_str" : "1049924061",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold I never want to take a virtual class in Second Life. I just wish they would stop wasting tuition money on this nonsense.",
  "id" : 1049924061,
  "in_reply_to_status_id" : 1049813765,
  "created_at" : "2008-12-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1046112403",
  "text" : "GitHub Rebase #7 is now up! http:\/\/tinyurl.com\/58ga97 I'm also in charge of setting the featured project for now on. Woot!",
  "id" : 1046112403,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1046531432",
  "text" : "Giving up for tonight. Laptop has kicked the bucket again, don't feel like setting up @ablissfulgal's mac again. What a horrible Monday.",
  "id" : 1046531432,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1047636226",
  "text" : "PowerPoint Slide's Wall of Text hits you for 1000 damage! Attention over.",
  "id" : 1047636226,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1047710409",
  "text" : "Perl seems a lot uglier than Java. Using functions\/subs and passing arguments seems very unnatural.",
  "id" : 1047710409,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1047773266",
  "text" : "Prof is trying to teach regular expressions. So much easier just to USE them. And annoying kid won't stop bantering with the prof.",
  "id" : 1047773266,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1047729292",
  "geo" : { },
  "id_str" : "1047780439",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Your lack of $faith disturbs me.",
  "id" : 1047780439,
  "in_reply_to_status_id" : 1047729292,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 0, 12 ],
      "id_str" : "13168222",
      "id" : 13168222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1047767373",
  "geo" : { },
  "id_str" : "1047782783",
  "in_reply_to_user_id" : 13168222,
  "text" : "@mark_menard Learning it for a class....Programming Language Concepts. This is just the first stop on the tour.",
  "id" : 1047782783,
  "in_reply_to_status_id" : 1047767373,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mark_menard",
  "in_reply_to_user_id_str" : "13168222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1047917341",
  "text" : "My Dell m1330's mobo is dead. So now the mobo, screen, HDD, keyboard, and power cord have been or will be replaced.",
  "id" : 1047917341,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1047929230",
  "geo" : { },
  "id_str" : "1047934794",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge Not yet...I got it earlier this year before I really got into Ruby. I want to get a MacBook but that would just be frivolous.",
  "id" : 1047934794,
  "in_reply_to_status_id" : 1047929230,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 0, 12 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1047933066",
  "geo" : { },
  "id_str" : "1047937636",
  "in_reply_to_user_id" : 6556972,
  "text" : "@techpickles did you get laid off? or just offering your leet hax for mad cash?",
  "id" : 1047937636,
  "in_reply_to_status_id" : 1047933066,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "techpickles",
  "in_reply_to_user_id_str" : "6556972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1045190000",
  "text" : "My Dell XPS m1330 has died again. Won't even get to the BIOS. I am getting sick of this.",
  "id" : 1045190000,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1045796819",
  "text" : "Note to self: don't unplug mac mini when running. Makes mini unhappy.",
  "id" : 1045796819,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "kopertop",
      "indices" : [ 0, 9 ],
      "id_str" : "11989152",
      "id" : 11989152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1045793522",
  "geo" : { },
  "id_str" : "1045810243",
  "in_reply_to_user_id" : 11989152,
  "text" : "@kopertop I think the Second Life push from RIT is such a joke. Last year they gave out flyers about MMO addiction and now this.",
  "id" : 1045810243,
  "in_reply_to_status_id" : 1045793522,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "kopertop",
  "in_reply_to_user_id_str" : "11989152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1045499980",
  "geo" : { },
  "id_str" : "1045812170",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold CAN I HAZ VISIT TO SEE NEW KITTY",
  "id" : 1045812170,
  "in_reply_to_status_id" : 1045499980,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1045905038",
  "text" : "My laptop seems to have turned on now. Didn't do anything out of the ordinary. I think it has a mind of its own.",
  "id" : 1045905038,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1043070325",
  "text" : "Windows won't even boot on mom's laptop. Not even into safe mode...it just blue screens. Attempting to SpinRite. :\/",
  "id" : 1043070325,
  "created_at" : "2008-12-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1041359773",
  "text" : "Watching a top 10 roller coaster show on the Discovery channel (from 2002, but it's in HD?). Some people love rides a little TOO much.",
  "id" : 1041359773,
  "created_at" : "2008-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1039517213",
  "text" : "Gave a talk today...\"Open Source Collaboration with Git and GitHub\". Check out the slides here: http:\/\/is.gd\/aiyW",
  "id" : 1039517213,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1039208263",
  "geo" : { },
  "id_str" : "1039580543",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold What's even worse is that he showed up at my talk today. Luckily he wasn't too annoying.",
  "id" : 1039580543,
  "in_reply_to_status_id" : 1039208263,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 0, 7 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1039526755",
  "geo" : { },
  "id_str" : "1039583342",
  "in_reply_to_user_id" : 15198826,
  "text" : "@paco36 You can download the PPT from Slideshare or just embed it. I'm not sure how to convert it. http:\/\/is.gd\/aiRk",
  "id" : 1039583342,
  "in_reply_to_status_id" : 1039526755,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1039669341",
  "text" : "Can't seem to make it to bed, and not getting any work done. This is going to be a problem since I need to get up early again tomorrow.",
  "id" : 1039669341,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1039670222",
  "text" : "SOMEONE SHUT OFF THE TUBES.",
  "id" : 1039670222,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1039675935",
  "text" : "Holy crap. 3rd result for googling my name summons the fail whale.",
  "id" : 1039675935,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notcheap",
      "indices" : [ 113, 122 ]
    }, {
      "text" : "ridiculous",
      "indices" : [ 123, 134 ]
    }, {
      "text" : "lame",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1040216973",
  "text" : "I don't think the 'labor' costs I just paid at the dealer were justified for the little amount of work they did. #notcheap #ridiculous #lame",
  "id" : 1040216973,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yebyen",
      "screen_name" : "yebyen",
      "indices" : [ 0, 7 ],
      "id_str" : "9391642",
      "id" : 9391642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1039207094",
  "geo" : { },
  "id_str" : "1039265564",
  "in_reply_to_user_id" : 9391642,
  "text" : "@yebyen hope you enjoyed it! :) I need to get the slides and a new blog post up.",
  "id" : 1039265564,
  "in_reply_to_status_id" : 1039207094,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "yebyen",
  "in_reply_to_user_id_str" : "9391642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1039344240",
  "text" : "If you don't do your job, I'll shoot you.",
  "id" : 1039344240,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1038075534",
  "text" : "I love working out in the morning, but doing quads\/hamstrings really makes walking to class a chore.",
  "id" : 1038075534,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1038262587",
  "text" : "I'm so glad that I woke up at 6:30 do the homework my professor just pushed back to next week. Makes me feel warm, fuzzy, and murderous.",
  "id" : 1038262587,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1038320051",
  "text" : "Rails gets templates. Goodbye bootstrap rails apps, hello simplicity: http:\/\/tinyurl.com\/5wtyrp",
  "id" : 1038320051,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 0, 7 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1038328493",
  "geo" : { },
  "id_str" : "1038591515",
  "in_reply_to_user_id" : 15198826,
  "text" : "@paco36 Thanks! Will you be attending?",
  "id" : 1038591515,
  "in_reply_to_status_id" : 1038328493,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 0, 7 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1038622944",
  "geo" : { },
  "id_str" : "1038638821",
  "in_reply_to_user_id" : 15198826,
  "text" : "@paco36 Yeah, Jeff just told me. Boohiss. I'll be putting my slides on my blog soonly for ya.",
  "id" : 1038638821,
  "in_reply_to_status_id" : 1038622944,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1038708197",
  "text" : "Doing some free association on the term \"Scripting Language\" in Programming Language Concepts. First thing annoying kid says: SLOW.",
  "id" : 1038708197,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1035663430",
  "text" : "Ruby: 1, Nick: 0. Failing on trying to fix a plugin tonight.",
  "id" : 1035663430,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1036729085",
  "text" : "Getting a ton of new followers on Twitter. Was twitterati.alltop linked somewhere?",
  "id" : 1036729085,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Bookbinder",
      "screen_name" : "y2kdread",
      "indices" : [ 3, 12 ],
      "id_str" : "14512202",
      "id" : 14512202
    }, {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 14, 24 ],
      "id_str" : "14198120",
      "id" : 14198120
    }, {
      "name" : "Maury Postal",
      "screen_name" : "mopostal",
      "indices" : [ 25, 34 ],
      "id_str" : "14204918",
      "id" : 14204918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1036742754",
  "text" : "RT @y2kdread: @JComboBox @mopostal - comic a about RIT http:\/\/www.dustinland.com\/archives\/archives319.html",
  "id" : 1036742754,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Riedinger",
      "screen_name" : "chrisriedinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14857000",
      "id" : 14857000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1036738134",
  "geo" : { },
  "id_str" : "1036762272",
  "in_reply_to_user_id" : 14857000,
  "text" : "@chrisriedinger Thanks man. Perhaps we should start an RIT Twitter facebook group if there's not one already to attempt to find others!",
  "id" : 1036762272,
  "in_reply_to_status_id" : 1036738134,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrisriedinger",
  "in_reply_to_user_id_str" : "14857000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yebyen",
      "screen_name" : "yebyen",
      "indices" : [ 0, 7 ],
      "id_str" : "9391642",
      "id" : 9391642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1036761155",
  "geo" : { },
  "id_str" : "1037090996",
  "in_reply_to_user_id" : 12591,
  "text" : "@yebyen http:\/\/tweetdeck.com GOOGOGOG",
  "id" : 1037090996,
  "in_reply_to_status_id" : 1036761155,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "snookca",
  "in_reply_to_user_id_str" : "12591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1033404870",
  "text" : "Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo buffalo http:\/\/is.gd\/c7h",
  "id" : 1033404870,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1034101916",
  "text" : "First 8am class this quarter at RIT.  Luckily it's not too crappy outside.  Also, I need to fill up my car's windshield fluid.",
  "id" : 1034101916,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1034164640",
  "text" : "GNU screen seems pretty kickass. I think I'm going to switch back to using irssi instead of xchat on my laptop.",
  "id" : 1034164640,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 0, 12 ],
      "id_str" : "13168222",
      "id" : 13168222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1034321901",
  "geo" : { },
  "id_str" : "1034643730",
  "in_reply_to_user_id" : 13168222,
  "text" : "@mark_menard Yeah. gnome terminal was ridiculously slow to switch tabs, but screen is loads faster.",
  "id" : 1034643730,
  "in_reply_to_status_id" : 1034321901,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mark_menard",
  "in_reply_to_user_id_str" : "13168222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doll",
      "screen_name" : "briandoll",
      "indices" : [ 0, 10 ],
      "id_str" : "7459092",
      "id" : 7459092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1034405419",
  "geo" : { },
  "id_str" : "1034644214",
  "in_reply_to_user_id" : 7459092,
  "text" : "@briandoll Are you still in the Rochester\/Buffalo area?",
  "id" : 1034644214,
  "in_reply_to_status_id" : 1034405419,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "briandoll",
  "in_reply_to_user_id_str" : "7459092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jurgen Appelo",
      "screen_name" : "jurgenappelo",
      "indices" : [ 0, 13 ],
      "id_str" : "14116283",
      "id" : 14116283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1034760557",
  "geo" : { },
  "id_str" : "1034762712",
  "in_reply_to_user_id" : 14116283,
  "text" : "@jurgenappelo He's continued his blog on GitHub. http:\/\/github.com\/raganwald\/homoiconic\/tree\/master",
  "id" : 1034762712,
  "in_reply_to_status_id" : 1034760557,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "jurgenappelo",
  "in_reply_to_user_id_str" : "14116283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1034797851",
  "text" : "Looking at a Fortran card in Programming Language Concepts. Really glad we're past that.",
  "id" : 1034797851,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1034821967",
  "text" : "Why does every class need to have that one annoying kid that never shuts his mouth? DON'T INTERRUPT THE PROFESSOR.",
  "id" : 1034821967,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cacophony",
      "screen_name" : "RyanCacophony",
      "indices" : [ 0, 14 ],
      "id_str" : "257296691",
      "id" : 257296691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1034903995",
  "geo" : { },
  "id_str" : "1034906059",
  "in_reply_to_user_id" : 16816665,
  "text" : "@RyanCacophony Better than zero!",
  "id" : 1034906059,
  "in_reply_to_status_id" : 1034903995,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "RCacophony",
  "in_reply_to_user_id_str" : "16816665",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1034907646",
  "text" : "Just pushed my way into a Database Concepts class. Now at least I can say I've got some formal education on the stuff I work with daily.",
  "id" : 1034907646,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
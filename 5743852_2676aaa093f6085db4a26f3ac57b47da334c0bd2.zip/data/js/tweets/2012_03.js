Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/Re84WNil",
      "expanded_url" : "http:\/\/watbutton.com\/",
      "display_url" : "watbutton.com"
    } ]
  },
  "geo" : { },
  "id_str" : "186299024360488960",
  "text" : "http:\/\/t.co\/Re84WNil makes me laugh, every time.",
  "id" : 186299024360488960,
  "created_at" : "2012-04-01 03:48:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/186277957319397377\/photo\/1",
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/8w8mlkRo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApXK0LPCEAA9NFz.jpg",
      "id_str" : "186277957323591680",
      "id" : 186277957323591680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApXK0LPCEAA9NFz.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/8w8mlkRo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186277957319397377",
  "text" : "Rivals of Catan is 2 player only. Geddy disagrees. http:\/\/t.co\/8w8mlkRo",
  "id" : 186277957319397377,
  "created_at" : "2012-04-01 02:25:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186254592902823937",
  "geo" : { },
  "id_str" : "186258382691368960",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan it's all about how you treat twitter. Its a firehose for me, don't care about missing updates. Drink and get out.",
  "id" : 186258382691368960,
  "in_reply_to_status_id" : 186254592902823937,
  "created_at" : "2012-04-01 01:07:13 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186255805501280256",
  "geo" : { },
  "id_str" : "186258076217786368",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt git reflog maybe? Still got the terminal output?",
  "id" : 186258076217786368,
  "in_reply_to_status_id" : 186255805501280256,
  "created_at" : "2012-04-01 01:06:00 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185910751502929920",
  "geo" : { },
  "id_str" : "185913285265195008",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k DK\/paintball mode, only slappers?",
  "id" : 185913285265195008,
  "in_reply_to_status_id" : 185910751502929920,
  "created_at" : "2012-03-31 02:15:55 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185913228876972032",
  "text" : "RT @r00k: I ain't impressed with this javascript shit until we can play Goldeneye in the browser.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185910751502929920",
    "text" : "I ain't impressed with this javascript shit until we can play Goldeneye in the browser.",
    "id" : 185910751502929920,
    "created_at" : "2012-03-31 02:05:51 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 185913228876972032,
  "created_at" : "2012-03-31 02:15:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/ZSUEzxVv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=rNBaA19q3Mo",
      "display_url" : "youtube.com\/watch?v=rNBaA1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185734711853854721",
  "text" : "No idea what these commericals are about, but this deep-voiced Japanese-talking Shiba Inu is a riot http:\/\/t.co\/ZSUEzxVv",
  "id" : 185734711853854721,
  "created_at" : "2012-03-30 14:26:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/T25KLiCc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=xP1-oquwoL8",
      "display_url" : "youtube.com\/watch?v=xP1-oq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185546866862194688",
  "text" : "Current status: http:\/\/t.co\/T25KLiCc",
  "id" : 185546866862194688,
  "created_at" : "2012-03-30 01:59:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Ko",
      "screen_name" : "justinko",
      "indices" : [ 0, 9 ],
      "id_str" : "23165791",
      "id" : 23165791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185523194856349696",
  "geo" : { },
  "id_str" : "185526714322010113",
  "in_reply_to_user_id" : 23165791,
  "text" : "@justinko no.",
  "id" : 185526714322010113,
  "in_reply_to_status_id" : 185523194856349696,
  "created_at" : "2012-03-30 00:39:50 +0000",
  "in_reply_to_screen_name" : "justinko",
  "in_reply_to_user_id_str" : "23165791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/L1bUDmFT",
      "expanded_url" : "http:\/\/gizmodo.com\/5897530\/nothing-says-im-drunk-like-bellowing-queens-bohemian-rhapsody-in-a-police-car",
      "display_url" : "gizmodo.com\/5897530\/nothin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185504798383144960",
  "text" : "This guy is my hero. http:\/\/t.co\/L1bUDmFT",
  "id" : 185504798383144960,
  "created_at" : "2012-03-29 23:12:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/QhoQLbXW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/John_von_Neumann",
      "display_url" : "en.wikipedia.org\/wiki\/John_von_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "185489450913107968",
  "geo" : { },
  "id_str" : "185490287542542336",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej http:\/\/t.co\/QhoQLbXW",
  "id" : 185490287542542336,
  "in_reply_to_status_id" : 185489450913107968,
  "created_at" : "2012-03-29 22:15:05 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185490225437474816",
  "text" : "I think the best I'll be able to do on my deathbed is recite word-for-word quotes from Anchorman.",
  "id" : 185490225437474816,
  "created_at" : "2012-03-29 22:14:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185490119988494336",
  "text" : "\"On his death bed, he entertained his brother with word-for-word recitations of the first few lines of each page of Goethe's Faust.\"",
  "id" : 185490119988494336,
  "created_at" : "2012-03-29 22:14:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185489977596059648",
  "text" : "\"admonished his wife for preparing a quiet study for him to work in [...] preferring the couple's living room with its TV playing loudly\"",
  "id" : 185489977596059648,
  "created_at" : "2012-03-29 22:13:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185489662813544448",
  "text" : "\"playing extremely loud German marching music on his gramophone, which distracted those [...], including Einstein, from their work.\"",
  "id" : 185489662813544448,
  "created_at" : "2012-03-29 22:12:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185489397200855041",
  "text" : "\"He died under military security lest he reveal military secrets while heavily medicated.\"",
  "id" : 185489397200855041,
  "created_at" : "2012-03-29 22:11:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/QhoQLbXW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/John_von_Neumann",
      "display_url" : "en.wikipedia.org\/wiki\/John_von_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185489038634000384",
  "text" : "von Neumann was such a badass. http:\/\/t.co\/QhoQLbXW",
  "id" : 185489038634000384,
  "created_at" : "2012-03-29 22:10:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/EoRcJkq8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PSEYXWmEse8",
      "display_url" : "youtube.com\/watch?v=PSEYXW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185461598398332928",
  "text" : "Current status: http:\/\/t.co\/EoRcJkq8",
  "id" : 185461598398332928,
  "created_at" : "2012-03-29 20:21:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/apwZU7BU",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v5Lmkm5EF5E",
      "display_url" : "youtube.com\/watch?v=v5Lmkm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185449272655876097",
  "text" : "Required viewing for all Buffalonians: http:\/\/t.co\/apwZU7BU",
  "id" : 185449272655876097,
  "created_at" : "2012-03-29 19:32:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "zenspider",
      "screen_name" : "zenspider",
      "indices" : [ 12, 22 ],
      "id_str" : "14989847",
      "id" : 14989847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185425176744308736",
  "geo" : { },
  "id_str" : "185426331675275265",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @zenspider use it all the in rspec instead of defining instance vars. lazy loading, cleaner setups.",
  "id" : 185426331675275265,
  "in_reply_to_status_id" : 185425176744308736,
  "created_at" : "2012-03-29 18:00:57 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "let",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185424389695746049",
  "text" : "MiniTest::Spec supports #let. Hell yes!",
  "id" : 185424389695746049,
  "created_at" : "2012-03-29 17:53:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek",
      "screen_name" : "perezd",
      "indices" : [ 0, 7 ],
      "id_str" : "811649",
      "id" : 811649
    }, {
      "name" : "Bernard Poon",
      "screen_name" : "StackOverflow",
      "indices" : [ 8, 22 ],
      "id_str" : "128700677",
      "id" : 128700677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185414307767517184",
  "geo" : { },
  "id_str" : "185415153385353218",
  "in_reply_to_user_id" : 811649,
  "text" : "@perezd @stackoverflow pretty sure that's the only reason. that avatar makes me laugh every time.",
  "id" : 185415153385353218,
  "in_reply_to_status_id" : 185414307767517184,
  "created_at" : "2012-03-29 17:16:32 +0000",
  "in_reply_to_screen_name" : "perezd",
  "in_reply_to_user_id_str" : "811649",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernard Poon",
      "screen_name" : "StackOverflow",
      "indices" : [ 10, 24 ],
      "id_str" : "128700677",
      "id" : 128700677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185413017159208960",
  "text" : "When will @StackOverflow drop OpenID? Just take my username and password. It's not hard.",
  "id" : 185413017159208960,
  "created_at" : "2012-03-29 17:08:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myron Marston",
      "screen_name" : "myronmarston",
      "indices" : [ 0, 13 ],
      "id_str" : "89517808",
      "id" : 89517808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185409336883953666",
  "geo" : { },
  "id_str" : "185412867791654912",
  "in_reply_to_user_id" : 89517808,
  "text" : "@myronmarston yeah very clearly academic. i like the visualizations though!",
  "id" : 185412867791654912,
  "in_reply_to_status_id" : 185409336883953666,
  "created_at" : "2012-03-29 17:07:27 +0000",
  "in_reply_to_screen_name" : "myronmarston",
  "in_reply_to_user_id_str" : "89517808",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 28, 37 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/yhlOxUkB",
      "expanded_url" : "http:\/\/jkabbedijk.nl\/?q=node\/5",
      "display_url" : "jkabbedijk.nl\/?q=node\/5"
    } ]
  },
  "geo" : { },
  "id_str" : "185394031306620929",
  "text" : "Pretty awesome study of the @rubygems ecosystem! First mention in an academic paper here. http:\/\/t.co\/yhlOxUkB",
  "id" : 185394031306620929,
  "created_at" : "2012-03-29 15:52:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185387589954572289",
  "geo" : { },
  "id_str" : "185387914593714178",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal $25!?",
  "id" : 185387914593714178,
  "in_reply_to_status_id" : 185387589954572289,
  "created_at" : "2012-03-29 15:28:17 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185387128757301250",
  "geo" : { },
  "id_str" : "185387431221145600",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal holy crap! where is this?",
  "id" : 185387431221145600,
  "in_reply_to_status_id" : 185387128757301250,
  "created_at" : "2012-03-29 15:26:22 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/2vm4eBLB",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?src_vid=RcBm78rpbnI&annotation_id=annotation_350060&feature=iv&v=jluv2HxFEqs",
      "display_url" : "youtube.com\/watch?src_vid=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185374145117302784",
  "text" : "Fixed classic video: http:\/\/t.co\/2vm4eBLB",
  "id" : 185374145117302784,
  "created_at" : "2012-03-29 14:33:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/YQHfK5gn",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?src_vid=RcBm78rpbnI",
      "display_url" : "youtube.com\/watch?src_vid=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185372835525562368",
  "text" : "Still a classic. http:\/\/t.co\/YQHfK5gn",
  "id" : 185372835525562368,
  "created_at" : "2012-03-29 14:28:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 4, 15 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 35, 43 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Gy9uMc24",
      "expanded_url" : "http:\/\/www.boston.com\/Boston\/businessupdates\/2012\/03\/wegmans-scouting-boston-locations\/MxjCDthYiODpYJxs7UZR1K\/index.html",
      "display_url" : "boston.com\/Boston\/busines\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185120627869495297",
  "text" : "Hey @thoughtbot, watch out. A wild @Wegmans approaches! http:\/\/t.co\/Gy9uMc24",
  "id" : 185120627869495297,
  "created_at" : "2012-03-28 21:46:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185118253213958144",
  "geo" : { },
  "id_str" : "185120257055268864",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams holy shit!",
  "id" : 185120257055268864,
  "in_reply_to_status_id" : 185118253213958144,
  "created_at" : "2012-03-28 21:44:43 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Zfv7YCNk",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3149-the-all-new-api-for-the-all-new-basecamp",
      "display_url" : "37signals.com\/svn\/posts\/3149\u2026"
    }, {
      "indices" : [ 113, 134 ],
      "url" : "https:\/\/t.co\/2kj72glC",
      "expanded_url" : "https:\/\/github.com\/rails\/jbuilder",
      "display_url" : "github.com\/rails\/jbuilder"
    } ]
  },
  "geo" : { },
  "id_str" : "185115624517808128",
  "text" : "RT @dhh: Finally got the API done for the new Basecamp: http:\/\/t.co\/Zfv7YCNk -- lovingly crafted using jbuilder: https:\/\/t.co\/2kj72glC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/Zfv7YCNk",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3149-the-all-new-api-for-the-all-new-basecamp",
        "display_url" : "37signals.com\/svn\/posts\/3149\u2026"
      }, {
        "indices" : [ 104, 125 ],
        "url" : "https:\/\/t.co\/2kj72glC",
        "expanded_url" : "https:\/\/github.com\/rails\/jbuilder",
        "display_url" : "github.com\/rails\/jbuilder"
      } ]
    },
    "geo" : { },
    "id_str" : "185114625476534274",
    "text" : "Finally got the API done for the new Basecamp: http:\/\/t.co\/Zfv7YCNk -- lovingly crafted using jbuilder: https:\/\/t.co\/2kj72glC",
    "id" : 185114625476534274,
    "created_at" : "2012-03-28 21:22:20 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 185115624517808128,
  "created_at" : "2012-03-28 21:26:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Wynn Netherland",
      "screen_name" : "pengwynn",
      "indices" : [ 6, 15 ],
      "id_str" : "14100886",
      "id" : 14100886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/nTz2A8Zr",
      "expanded_url" : "http:\/\/vb.net",
      "display_url" : "vb.net"
    } ]
  },
  "in_reply_to_status_id_str" : "185104761253658624",
  "geo" : { },
  "id_str" : "185105313425399808",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @pengwynn same story here. did http:\/\/t.co\/nTz2A8Zr \/c# prior. :(",
  "id" : 185105313425399808,
  "in_reply_to_status_id" : 185104761253658624,
  "created_at" : "2012-03-28 20:45:20 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/IXMDYaFC",
      "expanded_url" : "http:\/\/i.imgur.com\/6IBxr.gif",
      "display_url" : "i.imgur.com\/6IBxr.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "185088394261565440",
  "text" : "Current status: http:\/\/t.co\/IXMDYaFC",
  "id" : 185088394261565440,
  "created_at" : "2012-03-28 19:38:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185062137125806080",
  "geo" : { },
  "id_str" : "185062297457274880",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef hunkered down at Elmwood Spot. I need to get a bike.",
  "id" : 185062297457274880,
  "in_reply_to_status_id" : 185062137125806080,
  "created_at" : "2012-03-28 17:54:24 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit.txt",
      "screen_name" : "Reddit_txt",
      "indices" : [ 37, 48 ],
      "id_str" : "489467009",
      "id" : 489467009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185055130985570304",
  "text" : "Considering starting an account like @Reddit_txt, but for HN. One major problem with this idea: I'd actually have to read the comments.",
  "id" : 185055130985570304,
  "created_at" : "2012-03-28 17:25:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185053847323017216",
  "geo" : { },
  "id_str" : "185054386848923649",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek ah lame, oh well. would be cool to hook up.",
  "id" : 185054386848923649,
  "in_reply_to_status_id" : 185053847323017216,
  "created_at" : "2012-03-28 17:22:58 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185051794664198145",
  "text" : "As in, the page you're linking to is inside of the same repo.",
  "id" : 185051794664198145,
  "created_at" : "2012-03-28 17:12:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 36, 43 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185051720315977729",
  "text" : "Is there a way to link to a page on @github from a README and have it be PJAX'd up?",
  "id" : 185051720315977729,
  "created_at" : "2012-03-28 17:12:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "racheldonovan",
      "screen_name" : "racheldonovan",
      "indices" : [ 0, 14 ],
      "id_str" : "17181310",
      "id" : 17181310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185048371172622338",
  "geo" : { },
  "id_str" : "185050803084599296",
  "in_reply_to_user_id" : 17181310,
  "text" : "@racheldonovan isn't Firefox on...11 now? :)",
  "id" : 185050803084599296,
  "in_reply_to_status_id" : 185048371172622338,
  "created_at" : "2012-03-28 17:08:44 +0000",
  "in_reply_to_screen_name" : "racheldonovan",
  "in_reply_to_user_id_str" : "17181310",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "racheldonovan",
      "screen_name" : "racheldonovan",
      "indices" : [ 0, 14 ],
      "id_str" : "17181310",
      "id" : 17181310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185048023565467648",
  "geo" : { },
  "id_str" : "185048148325044224",
  "in_reply_to_user_id" : 17181310,
  "text" : "@racheldonovan what browser is that?",
  "id" : 185048148325044224,
  "in_reply_to_status_id" : 185048023565467648,
  "created_at" : "2012-03-28 16:58:11 +0000",
  "in_reply_to_screen_name" : "racheldonovan",
  "in_reply_to_user_id_str" : "17181310",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivingSocial",
      "screen_name" : "LivingSocial",
      "indices" : [ 91, 104 ],
      "id_str" : "14773982",
      "id" : 14773982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/KgVDngCv",
      "expanded_url" : "http:\/\/www.livingsocial.com\/cities\/41-cleveland-westside\/deals\/210588",
      "display_url" : "livingsocial.com\/cities\/41-clev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184721154601271296",
  "text" : "\"If you're looking to romance that special someone\", Get them a Cleveland Steamer! Only on @LivingSocial. http:\/\/t.co\/KgVDngCv",
  "id" : 184721154601271296,
  "created_at" : "2012-03-27 19:18:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 15, 22 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 23, 31 ],
      "id_str" : "14436348",
      "id" : 14436348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184612541530521601",
  "geo" : { },
  "id_str" : "184631147203010563",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @gabebw @adarshp Seriously? need to think a bit about who and why you're actually writing software for.",
  "id" : 184631147203010563,
  "in_reply_to_status_id" : 184612541530521601,
  "created_at" : "2012-03-27 13:21:10 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moesta",
      "screen_name" : "bmoesta",
      "indices" : [ 0, 8 ],
      "id_str" : "15458287",
      "id" : 15458287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184607168216047616",
  "geo" : { },
  "id_str" : "184608980478345218",
  "in_reply_to_user_id" : 15458287,
  "text" : "@bmoesta used to live around the corner there...many a morning fueled up. Good luck!",
  "id" : 184608980478345218,
  "in_reply_to_status_id" : 184607168216047616,
  "created_at" : "2012-03-27 11:53:05 +0000",
  "in_reply_to_screen_name" : "bmoesta",
  "in_reply_to_user_id_str" : "15458287",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 8, 16 ],
      "id_str" : "14436348",
      "id" : 14436348
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 17, 31 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184430454886252544",
  "geo" : { },
  "id_str" : "184608697723531265",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw @adarshp @joshuaclayton you're missing a lot if that's the only reason. Just sayin'",
  "id" : 184608697723531265,
  "in_reply_to_status_id" : 184430454886252544,
  "created_at" : "2012-03-27 11:51:58 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randall Thomas",
      "screen_name" : "daksis",
      "indices" : [ 0, 7 ],
      "id_str" : "5437372",
      "id" : 5437372
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 8, 15 ],
      "id_str" : "659933",
      "id" : 659933
    }, {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 16, 23 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184418688366153728",
  "geo" : { },
  "id_str" : "184420013917216768",
  "in_reply_to_user_id" : 5437372,
  "text" : "@daksis @bryanl @tsaleh congrats guys!",
  "id" : 184420013917216768,
  "in_reply_to_status_id" : 184418688366153728,
  "created_at" : "2012-03-26 23:22:12 +0000",
  "in_reply_to_screen_name" : "daksis",
  "in_reply_to_user_id_str" : "5437372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184413705843376128",
  "geo" : { },
  "id_str" : "184415372496224257",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety yeah basically.",
  "id" : 184415372496224257,
  "in_reply_to_status_id" : 184413705843376128,
  "created_at" : "2012-03-26 23:03:45 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184411993351012352",
  "text" : "My editor crashing is equivalent to getting punched in the stomach. Feels like the wind was sucked out of my workflow :(",
  "id" : 184411993351012352,
  "created_at" : "2012-03-26 22:50:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Waldron",
      "screen_name" : "erebor",
      "indices" : [ 0, 7 ],
      "id_str" : "1011261",
      "id" : 1011261
    }, {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 8, 17 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 97 ],
      "url" : "https:\/\/t.co\/DoEDUs6m",
      "expanded_url" : "https:\/\/gist.github.com\/2210217",
      "display_url" : "gist.github.com\/2210217"
    } ]
  },
  "in_reply_to_status_id_str" : "184404401480404995",
  "geo" : { },
  "id_str" : "184405693082775552",
  "in_reply_to_user_id" : 1011261,
  "text" : "@erebor @blowmage Here's how i'm doing it on Rails 3.2. Might work with 3.x https:\/\/t.co\/DoEDUs6m",
  "id" : 184405693082775552,
  "in_reply_to_status_id" : 184404401480404995,
  "created_at" : "2012-03-26 22:25:17 +0000",
  "in_reply_to_screen_name" : "erebor",
  "in_reply_to_user_id_str" : "1011261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184397287311687685",
  "text" : "Nothing frustrates me more than when a computer just simply doesn't work. I don't understand how others put it up with it.",
  "id" : 184397287311687685,
  "created_at" : "2012-03-26 21:51:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184349288699146241",
  "geo" : { },
  "id_str" : "184350213157302272",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano @bquarant haha yep!",
  "id" : 184350213157302272,
  "in_reply_to_status_id" : 184349288699146241,
  "created_at" : "2012-03-26 18:44:50 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184346800264712194",
  "geo" : { },
  "id_str" : "184349019768750081",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano @bquarant you haven't learned to just ignore him yet?",
  "id" : 184349019768750081,
  "in_reply_to_status_id" : 184346800264712194,
  "created_at" : "2012-03-26 18:40:06 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184334076868698112",
  "geo" : { },
  "id_str" : "184344167831445504",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule have you tried it?",
  "id" : 184344167831445504,
  "in_reply_to_status_id" : 184334076868698112,
  "created_at" : "2012-03-26 18:20:49 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Max Wood",
      "screen_name" : "cmaxw",
      "indices" : [ 0, 6 ],
      "id_str" : "14847041",
      "id" : 14847041
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 7, 14 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 15, 23 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184295569269850112",
  "geo" : { },
  "id_str" : "184299866468515841",
  "in_reply_to_user_id" : 14847041,
  "text" : "@cmaxw @elight @sikachu my birthday is 11\/13...not today :)",
  "id" : 184299866468515841,
  "in_reply_to_status_id" : 184295569269850112,
  "created_at" : "2012-03-26 15:24:46 +0000",
  "in_reply_to_screen_name" : "cmaxw",
  "in_reply_to_user_id_str" : "14847041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/vGYqnMaX",
      "expanded_url" : "http:\/\/blog.steveklabnik.com\/posts\/2012-03-26-birthday-cards-for-dad",
      "display_url" : "blog.steveklabnik.com\/posts\/2012-03-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184298385484951553",
  "text" : "RT @steveklabnik: Hey everyone. Because of my father's cancer, his last birthday is Sunday. Send him a birthday card: http:\/\/t.co\/vGYqnMaX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/vGYqnMaX",
        "expanded_url" : "http:\/\/blog.steveklabnik.com\/posts\/2012-03-26-birthday-cards-for-dad",
        "display_url" : "blog.steveklabnik.com\/posts\/2012-03-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "184293124980477952",
    "text" : "Hey everyone. Because of my father's cancer, his last birthday is Sunday. Send him a birthday card: http:\/\/t.co\/vGYqnMaX",
    "id" : 184293124980477952,
    "created_at" : "2012-03-26 14:57:59 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 184298385484951553,
  "created_at" : "2012-03-26 15:18:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 3, 11 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184287843756163073",
  "text" : "RT @noahhlo: How to lose business: publicize someone as your customer without asking first.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184286872531509248",
    "text" : "How to lose business: publicize someone as your customer without asking first.",
    "id" : 184286872531509248,
    "created_at" : "2012-03-26 14:33:08 +0000",
    "user" : {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "protected" : false,
      "id_str" : "234465384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412045673408651264\/CPEGZ-93_normal.jpeg",
      "id" : 234465384,
      "verified" : false
    }
  },
  "id" : 184287843756163073,
  "created_at" : "2012-03-26 14:37:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183958429054943234",
  "geo" : { },
  "id_str" : "184083325755985922",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit did you get a dog??",
  "id" : 184083325755985922,
  "in_reply_to_status_id" : 183958429054943234,
  "created_at" : "2012-03-26 01:04:19 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 15, 21 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 22, 31 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/t7WFqMGN",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "183806699856076800",
  "geo" : { },
  "id_str" : "183809214588780544",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt @nzkoz @rtomayko still possible with bundler, but it's clunky and your repo size gets huge. (see http:\/\/t.co\/t7WFqMGN) \uD83D\uDE2D",
  "id" : 183809214588780544,
  "in_reply_to_status_id" : 183806699856076800,
  "created_at" : "2012-03-25 06:55:06 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183800627615375360",
  "text" : "Tweet spam is getting terrible.",
  "id" : 183800627615375360,
  "created_at" : "2012-03-25 06:20:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 0, 9 ],
      "id_str" : "9267332",
      "id" : 9267332
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 10, 24 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183799315079237632",
  "geo" : { },
  "id_str" : "183800195035828224",
  "in_reply_to_user_id" : 9267332,
  "text" : "@rtomayko @garybernhardt that being said...I'd work with bundler and rails being cranky any day over other stacks.  Detritus be damned.",
  "id" : 183800195035828224,
  "in_reply_to_status_id" : 183799315079237632,
  "created_at" : "2012-03-25 06:19:15 +0000",
  "in_reply_to_screen_name" : "rtomayko",
  "in_reply_to_user_id_str" : "9267332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 0, 9 ],
      "id_str" : "9267332",
      "id" : 9267332
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 10, 24 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183799315079237632",
  "geo" : { },
  "id_str" : "183799776750469120",
  "in_reply_to_user_id" : 9267332,
  "text" : "@rtomayko @garybernhardt if you're looking to influence\/make changes to RubyGems to make this mess easier, now is the time (2.0 on master)",
  "id" : 183799776750469120,
  "in_reply_to_status_id" : 183799315079237632,
  "created_at" : "2012-03-25 06:17:36 +0000",
  "in_reply_to_screen_name" : "rtomayko",
  "in_reply_to_user_id_str" : "9267332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/T9Bv1DvS",
      "expanded_url" : "http:\/\/instagr.am\/p\/IlTl-qM6uJ\/",
      "display_url" : "instagr.am\/p\/IlTl-qM6uJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "183780683968294914",
  "text" : "40 points in 7 Wonders. Didn't win but love this game. http:\/\/t.co\/T9Bv1DvS",
  "id" : 183780683968294914,
  "created_at" : "2012-03-25 05:01:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183661080990588929",
  "geo" : { },
  "id_str" : "183670541285212160",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens welcome to ruby! Don't look back, it's bad for your mental health.",
  "id" : 183670541285212160,
  "in_reply_to_status_id" : 183661080990588929,
  "created_at" : "2012-03-24 21:44:04 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 17, 23 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183649581005938689",
  "geo" : { },
  "id_str" : "183657460391882752",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @sferik @cmeik roger! And yeah, we could wait until Monday, do some testing this weekend. No rush.",
  "id" : 183657460391882752,
  "in_reply_to_status_id" : 183649581005938689,
  "created_at" : "2012-03-24 20:52:05 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 8, 14 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183625805182664705",
  "geo" : { },
  "id_str" : "183626396944441344",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @cmeik I can push in a few. Heading out for a few hours ATM.",
  "id" : 183626396944441344,
  "in_reply_to_status_id" : 183625805182664705,
  "created_at" : "2012-03-24 18:48:39 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 4, 14 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "UB Hacking",
      "screen_name" : "UBHacking",
      "indices" : [ 37, 47 ],
      "id_str" : "489825278",
      "id" : 489825278
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 53, 59 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 60, 67 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183625042821783553",
  "text" : "Got @gemcutter green on Rails 3.2 at @UBHacking! Hey @cmeik @sferik deploy party this weekend?",
  "id" : 183625042821783553,
  "created_at" : "2012-03-24 18:43:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 17, 24 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183623320271454208",
  "geo" : { },
  "id_str" : "183624765985128448",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair maybe @Croaky knows!",
  "id" : 183624765985128448,
  "in_reply_to_status_id" : 183623320271454208,
  "created_at" : "2012-03-24 18:42:10 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UB Hacking",
      "screen_name" : "UBHacking",
      "indices" : [ 87, 97 ],
      "id_str" : "489825278",
      "id" : 489825278
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/183614705485623296\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/vzyGU5sM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoxUmhCCMAA-aP0.jpg",
      "id_str" : "183614705494011904",
      "id" : 183614705494011904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoxUmhCCMAA-aP0.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/vzyGU5sM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183614705485623296",
  "text" : "Apparently Google wants more brogrammers, they sent aviators and sweatbands as swag to @ubhacking. http:\/\/t.co\/vzyGU5sM",
  "id" : 183614705485623296,
  "created_at" : "2012-03-24 18:02:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183578643371540481",
  "geo" : { },
  "id_str" : "183587977761521664",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting wat",
  "id" : 183587977761521664,
  "in_reply_to_status_id" : 183578643371540481,
  "created_at" : "2012-03-24 16:15:59 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UB Hacking",
      "screen_name" : "UBHacking",
      "indices" : [ 36, 46 ],
      "id_str" : "489825278",
      "id" : 489825278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/v1itkXmE",
      "expanded_url" : "http:\/\/cloudcamproc.org\/",
      "display_url" : "cloudcamproc.org"
    } ]
  },
  "geo" : { },
  "id_str" : "183561298439712770",
  "text" : "Apparently Rochester will be MIA at @ubhacking: http:\/\/t.co\/v1itkXmE.",
  "id" : 183561298439712770,
  "created_at" : "2012-03-24 14:29:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/5m9HzH8p",
      "expanded_url" : "http:\/\/ubhacking.com\/talksched.html",
      "display_url" : "ubhacking.com\/talksched.html"
    } ]
  },
  "geo" : { },
  "id_str" : "183558562503606272",
  "text" : "Hey Buffalo, Rochester folks! Come down for some talks at UB today: http:\/\/t.co\/5m9HzH8p",
  "id" : 183558562503606272,
  "created_at" : "2012-03-24 14:19:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/QToKYxie",
      "expanded_url" : "http:\/\/blogs.nasa.gov\/cm\/blog\/nasadotgov\/posts\/post_1306860816073.html",
      "display_url" : "blogs.nasa.gov\/cm\/blog\/nasado\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183544045358944256",
  "text" : "The real reason NASA isn't going to space anymore: they can't even change one DNS record. Such incompetence. http:\/\/t.co\/QToKYxie",
  "id" : 183544045358944256,
  "created_at" : "2012-03-24 13:21:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 7, 20 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183359101819039744",
  "geo" : { },
  "id_str" : "183543810838630401",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @nicksergeant yeah that's total bullshit. absolute incompetence at a government agency, SURPRISING.",
  "id" : 183543810838630401,
  "in_reply_to_status_id" : 183359101819039744,
  "created_at" : "2012-03-24 13:20:29 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183303046493765632",
  "geo" : { },
  "id_str" : "183525200594350080",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh at least it isn't VB. AndAlso, OrElse are logical operators! Definitely some Stockholm going on. I can feel for that guy, Ruby freed me",
  "id" : 183525200594350080,
  "in_reply_to_status_id" : 183303046493765632,
  "created_at" : "2012-03-24 12:06:32 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183517784041472000",
  "geo" : { },
  "id_str" : "183524283513974785",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant god speed bro! Pulling for ya!!!",
  "id" : 183524283513974785,
  "in_reply_to_status_id" : 183517784041472000,
  "created_at" : "2012-03-24 12:02:53 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183298048112345090",
  "text" : "TIL that encodeURIComponent() != encodeURI(). Herp derp.",
  "id" : 183298048112345090,
  "created_at" : "2012-03-23 21:03:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183278123083771904",
  "text" : "Had no idea you could hold a key down in OSX to get diacritics. \u00C5w\u0119s\u00F8m\u00EA!",
  "id" : 183278123083771904,
  "created_at" : "2012-03-23 19:44:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UB Hacking",
      "screen_name" : "UBHacking",
      "indices" : [ 3, 13 ],
      "id_str" : "489825278",
      "id" : 489825278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/cOSWk9s5",
      "expanded_url" : "http:\/\/ubhacking.com\/talksched.html",
      "display_url" : "ubhacking.com\/talksched.html"
    }, {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/0Pg4xoc9",
      "expanded_url" : "http:\/\/fb.me\/XVLEwSIt",
      "display_url" : "fb.me\/XVLEwSIt"
    } ]
  },
  "geo" : { },
  "id_str" : "183261783270768640",
  "text" : "RT @UBHacking: Saturday's talk schedule is up: http:\/\/t.co\/cOSWk9s5 http:\/\/t.co\/0Pg4xoc9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/cOSWk9s5",
        "expanded_url" : "http:\/\/ubhacking.com\/talksched.html",
        "display_url" : "ubhacking.com\/talksched.html"
      }, {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/0Pg4xoc9",
        "expanded_url" : "http:\/\/fb.me\/XVLEwSIt",
        "display_url" : "fb.me\/XVLEwSIt"
      } ]
    },
    "geo" : { },
    "id_str" : "183233118642257922",
    "text" : "Saturday's talk schedule is up: http:\/\/t.co\/cOSWk9s5 http:\/\/t.co\/0Pg4xoc9",
    "id" : 183233118642257922,
    "created_at" : "2012-03-23 16:45:54 +0000",
    "user" : {
      "name" : "UB Hacking",
      "screen_name" : "UBHacking",
      "protected" : false,
      "id_str" : "489825278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530815303370821633\/9eBRNf6P_normal.png",
      "id" : 489825278,
      "verified" : false
    }
  },
  "id" : 183261783270768640,
  "created_at" : "2012-03-23 18:39:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 32, 42 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183190728237785089",
  "text" : "Had a nightmare last night that @gemcutter had a security hole, and I couldn't fix it. Ruby, you did this to me!",
  "id" : 183190728237785089,
  "created_at" : "2012-03-23 13:57:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 12, 23 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183011598871437312",
  "geo" : { },
  "id_str" : "183015717136908288",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape @timocratic now mostly afraid.",
  "id" : 183015717136908288,
  "in_reply_to_status_id" : 183011598871437312,
  "created_at" : "2012-03-23 02:22:01 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 11, 21 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182961217722265600",
  "geo" : { },
  "id_str" : "182965315351744512",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @theediguy oh man i've heard awesome rumors about the pizza\/dranks place. gotta get some!",
  "id" : 182965315351744512,
  "in_reply_to_status_id" : 182961217722265600,
  "created_at" : "2012-03-22 23:01:45 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/XI3l7RNE",
      "expanded_url" : "http:\/\/screenshotsofdespair.tumblr.com\/",
      "display_url" : "screenshotsofdespair.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "182924918118289411",
  "text" : "Love this. http:\/\/t.co\/XI3l7RNE",
  "id" : 182924918118289411,
  "created_at" : "2012-03-22 20:21:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/BbaoGdwG",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ie5LvkM6ga\/",
      "display_url" : "instagr.am\/p\/Ie5LvkM6ga\/"
    } ]
  },
  "geo" : { },
  "id_str" : "182878179738914816",
  "text" : "Best vet office photo ever? http:\/\/t.co\/BbaoGdwG",
  "id" : 182878179738914816,
  "created_at" : "2012-03-22 17:15:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stevens",
      "screen_name" : "kevdog",
      "indices" : [ 0, 7 ],
      "id_str" : "10696812",
      "id" : 10696812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/6ta1pisL",
      "expanded_url" : "http:\/\/www.unitedpixelworkers.com\/products\/buffalo",
      "display_url" : "unitedpixelworkers.com\/products\/buffa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "182852032644911105",
  "geo" : { },
  "id_str" : "182852326845984769",
  "in_reply_to_user_id" : 10696812,
  "text" : "@kevdog http:\/\/t.co\/6ta1pisL",
  "id" : 182852326845984769,
  "in_reply_to_status_id" : 182852032644911105,
  "created_at" : "2012-03-22 15:32:46 +0000",
  "in_reply_to_screen_name" : "kevdog",
  "in_reply_to_user_id_str" : "10696812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182703735162671105",
  "geo" : { },
  "id_str" : "182848459643166722",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 railsconf week!",
  "id" : 182848459643166722,
  "in_reply_to_status_id" : 182703735162671105,
  "created_at" : "2012-03-22 15:17:24 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/TtcVfWjO",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ieqqmrs6ui\/",
      "display_url" : "instagr.am\/p\/Ieqqmrs6ui\/"
    } ]
  },
  "geo" : { },
  "id_str" : "182846202965016577",
  "text" : "Finally got my Buffalo Pixelworkers shirt! http:\/\/t.co\/TtcVfWjO",
  "id" : 182846202965016577,
  "created_at" : "2012-03-22 15:08:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 0, 5 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182837634496856064",
  "geo" : { },
  "id_str" : "182838368915304448",
  "in_reply_to_user_id" : 637533,
  "text" : "@coda \"500 CTO Defensive And Touchy\" ultimate trolling. good work sir.",
  "id" : 182838368915304448,
  "in_reply_to_status_id" : 182837634496856064,
  "created_at" : "2012-03-22 14:37:18 +0000",
  "in_reply_to_screen_name" : "coda",
  "in_reply_to_user_id_str" : "637533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/MP0sf0va",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6r5f2jfa29w",
      "display_url" : "youtube.com\/watch?v=6r5f2j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182837583833866241",
  "text" : "Current status: http:\/\/t.co\/MP0sf0va",
  "id" : 182837583833866241,
  "created_at" : "2012-03-22 14:34:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182698723455942657",
  "text" : "Every night, me: \"oh let me pick up my phone and set my alarm so I wake up at a reasonable hour.\" an hour later, me: \"Fuck.\"",
  "id" : 182698723455942657,
  "created_at" : "2012-03-22 05:22:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abarone",
      "screen_name" : "abarone",
      "indices" : [ 0, 8 ],
      "id_str" : "14064164",
      "id" : 14064164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182664652499587074",
  "geo" : { },
  "id_str" : "182671479991844864",
  "in_reply_to_user_id" : 14064164,
  "text" : "@abarone sure! i'll be missing the first day of the conf, getting in late Monday.",
  "id" : 182671479991844864,
  "in_reply_to_status_id" : 182664652499587074,
  "created_at" : "2012-03-22 03:34:09 +0000",
  "in_reply_to_screen_name" : "abarone",
  "in_reply_to_user_id_str" : "14064164",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 7, 15 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182657838433316864",
  "geo" : { },
  "id_str" : "182671369769730048",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr @ddollar just one day...going to be a tight squeeze that day too. :(",
  "id" : 182671369769730048,
  "in_reply_to_status_id" : 182657838433316864,
  "created_at" : "2012-03-22 03:33:43 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182654544126291970",
  "text" : "Holy carp, April southern Q trip booked! BUF =&gt; CLT =&gt; ATL =&gt; AUS. Excited to see old friends and make new ones.",
  "id" : 182654544126291970,
  "created_at" : "2012-03-22 02:26:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Limi",
      "screen_name" : "limi",
      "indices" : [ 3, 8 ],
      "id_str" : "1045541",
      "id" : 1045541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/KAEuVRRI",
      "expanded_url" : "http:\/\/www.winsupersite.com\/content\/content\/142613\/cal_peek.jpg",
      "display_url" : "winsupersite.com\/content\/conten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182632080545558530",
  "text" : "RT @limi: Holy crap, Microsoft \u2014 really? This is Outlook (Office) 15's UI, not a joke: http:\/\/t.co\/KAEuVRRI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/KAEuVRRI",
        "expanded_url" : "http:\/\/www.winsupersite.com\/content\/content\/142613\/cal_peek.jpg",
        "display_url" : "winsupersite.com\/content\/conten\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182482394123739136",
    "text" : "Holy crap, Microsoft \u2014 really? This is Outlook (Office) 15's UI, not a joke: http:\/\/t.co\/KAEuVRRI",
    "id" : 182482394123739136,
    "created_at" : "2012-03-21 15:02:47 +0000",
    "user" : {
      "name" : "Alex Limi",
      "screen_name" : "limi",
      "protected" : false,
      "id_str" : "1045541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454481985742712832\/rNnol8l7_normal.png",
      "id" : 1045541,
      "verified" : false
    }
  },
  "id" : 182632080545558530,
  "created_at" : "2012-03-22 00:57:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 64, 75 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182625603235745792",
  "geo" : { },
  "id_str" : "182628599826886656",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic i've been on the nail gun side a lot as well :) \/cc @shellscape",
  "id" : 182628599826886656,
  "in_reply_to_status_id" : 182625603235745792,
  "created_at" : "2012-03-22 00:43:45 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/WNB3JUS1",
      "expanded_url" : "http:\/\/instagr.am\/p\/IdCQveM6gH\/",
      "display_url" : "instagr.am\/p\/IdCQveM6gH\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9324374127, -78.8760316372 ]
  },
  "id_str" : "182616647889199104",
  "text" : "Planets &amp; Art!  @ Albright-Knox Art Gallery http:\/\/t.co\/WNB3JUS1",
  "id" : 182616647889199104,
  "created_at" : "2012-03-21 23:56:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 20, 30 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182583749630902272",
  "geo" : { },
  "id_str" : "182615408652713984",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic no ride, @aquaranto is seeing Casablanca",
  "id" : 182615408652713984,
  "in_reply_to_status_id" : 182583749630902272,
  "created_at" : "2012-03-21 23:51:20 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/RwW6naZm",
      "expanded_url" : "http:\/\/instagr.am\/p\/IdBT5ds6vz\/",
      "display_url" : "instagr.am\/p\/IdBT5ds6vz\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9323730633, -78.8736133644 ]
  },
  "id_str" : "182614509767229441",
  "text" : "Fuck yeah!  @ Hoyt Lake http:\/\/t.co\/RwW6naZm",
  "id" : 182614509767229441,
  "created_at" : "2012-03-21 23:47:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/VwJaav4J",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ic6o7lM6uX\/",
      "display_url" : "instagr.am\/p\/Ic6o7lM6uX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "182599884120137729",
  "text" : "Sleepy pup is sleepy. http:\/\/t.co\/VwJaav4J",
  "id" : 182599884120137729,
  "created_at" : "2012-03-21 22:49:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/wjwL0v7x",
      "expanded_url" : "http:\/\/goo.gl\/qODv5",
      "display_url" : "goo.gl\/qODv5"
    } ]
  },
  "geo" : { },
  "id_str" : "182594569827921920",
  "text" : "\"How many projects will you have to fail before you accept [...] that you don\u2019t, in fact, know everything?\" http:\/\/t.co\/wjwL0v7x",
  "id" : 182594569827921920,
  "created_at" : "2012-03-21 22:28:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182558123482025984",
  "text" : "At what point of getting tattoos on your face and 2\" ear gauges do you start regretting your life decisions?",
  "id" : 182558123482025984,
  "created_at" : "2012-03-21 20:03:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182553271716679680",
  "text" : "RABBLE RABBLE RABBLE!",
  "id" : 182553271716679680,
  "created_at" : "2012-03-21 19:44:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/sXdv1kdi",
      "expanded_url" : "http:\/\/www.southparkstudios.com\/clips\/153618\/rabble-rabble-rabble",
      "display_url" : "southparkstudios.com\/clips\/153618\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182553214783197185",
  "text" : "How I feel about most blog posts these days: http:\/\/t.co\/sXdv1kdi",
  "id" : 182553214783197185,
  "created_at" : "2012-03-21 19:44:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/ogGb0veD",
      "expanded_url" : "http:\/\/railsconf2012.com\/cfp",
      "display_url" : "railsconf2012.com\/cfp"
    } ]
  },
  "geo" : { },
  "id_str" : "182547115237588992",
  "text" : "Just submitted a talk for RailsConf 2012. There's still 2 more days to submit! http:\/\/t.co\/ogGb0veD",
  "id" : 182547115237588992,
  "created_at" : "2012-03-21 19:19:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182541423374118912",
  "geo" : { },
  "id_str" : "182543041171685377",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Agreed. Made me super uncomfortable.",
  "id" : 182543041171685377,
  "in_reply_to_status_id" : 182541423374118912,
  "created_at" : "2012-03-21 19:03:47 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Foodler",
      "screen_name" : "Foodler",
      "indices" : [ 9, 17 ],
      "id_str" : "18194176",
      "id" : 18194176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/yWiSpIAf",
      "expanded_url" : "http:\/\/ragetoons.com\/wp-content\/uploads\/2009\/12\/rage-pho.gif",
      "display_url" : "ragetoons.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "182509927326167040",
  "geo" : { },
  "id_str" : "182510249398370305",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu @foodler http:\/\/t.co\/yWiSpIAf ?",
  "id" : 182510249398370305,
  "in_reply_to_status_id" : 182509927326167040,
  "created_at" : "2012-03-21 16:53:28 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/7iy4h6S7",
      "expanded_url" : "http:\/\/img2.timeinc.net\/ew\/dynamic\/imgs\/060901\/14380__idiocracy_l.jpg",
      "display_url" : "img2.timeinc.net\/ew\/dynamic\/img\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "182480213366669313",
  "geo" : { },
  "id_str" : "182480529164222464",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette http:\/\/t.co\/7iy4h6S7",
  "id" : 182480529164222464,
  "in_reply_to_status_id" : 182480213366669313,
  "created_at" : "2012-03-21 14:55:23 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182322968100225025",
  "geo" : { },
  "id_str" : "182323201991376897",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath \"Submit a pull request to ask for feedback\"",
  "id" : 182323201991376897,
  "in_reply_to_status_id" : 182322968100225025,
  "created_at" : "2012-03-21 04:30:13 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    }, {
      "name" : "Eric Lindvall",
      "screen_name" : "lindvall",
      "indices" : [ 8, 17 ],
      "id_str" : "7383702",
      "id" : 7383702
    }, {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 18, 28 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182322395858747392",
  "geo" : { },
  "id_str" : "182322851951546369",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath @lindvall @jbarnette is this OSS?",
  "id" : 182322851951546369,
  "in_reply_to_status_id" : 182322395858747392,
  "created_at" : "2012-03-21 04:28:49 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182317206133157889",
  "geo" : { },
  "id_str" : "182319126663020544",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta ah, just caught up on the conspiracy theories. I hope they're wrong too.",
  "id" : 182319126663020544,
  "in_reply_to_status_id" : 182317206133157889,
  "created_at" : "2012-03-21 04:14:01 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/0uzpi5dj",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2012\/03\/human-bird-wings\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182315653926092801",
  "text" : "Well guys and girls, we're all losing. This dude can FLY. http:\/\/t.co\/0uzpi5dj",
  "id" : 182315653926092801,
  "created_at" : "2012-03-21 04:00:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182312922163326976",
  "geo" : { },
  "id_str" : "182313316910239744",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi No, nothing goon-related is good.",
  "id" : 182313316910239744,
  "in_reply_to_status_id" : 182312922163326976,
  "created_at" : "2012-03-21 03:50:56 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182311336523468800",
  "geo" : { },
  "id_str" : "182311782596091904",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle rubycentral does.",
  "id" : 182311782596091904,
  "in_reply_to_status_id" : 182311336523468800,
  "created_at" : "2012-03-21 03:44:50 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Lindvall",
      "screen_name" : "lindvall",
      "indices" : [ 3, 12 ],
      "id_str" : "7383702",
      "id" : 7383702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/uxnS3Zz3",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ia24KkjIzC\/",
      "display_url" : "instagr.am\/p\/Ia24KkjIzC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "182310323775221762",
  "text" : "RT @lindvall: iStrike: Featuring Campfire  @ Alderwood Mall http:\/\/t.co\/uxnS3Zz3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/uxnS3Zz3",
        "expanded_url" : "http:\/\/instagr.am\/p\/Ia24KkjIzC\/",
        "display_url" : "instagr.am\/p\/Ia24KkjIzC\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.8297808914, -122.273154259 ]
    },
    "id_str" : "182310253025705984",
    "text" : "iStrike: Featuring Campfire  @ Alderwood Mall http:\/\/t.co\/uxnS3Zz3",
    "id" : 182310253025705984,
    "created_at" : "2012-03-21 03:38:46 +0000",
    "user" : {
      "name" : "Eric Lindvall",
      "screen_name" : "lindvall",
      "protected" : false,
      "id_str" : "7383702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416073981\/eric-avatar-coffee-square-2_normal.png",
      "id" : 7383702,
      "verified" : false
    }
  },
  "id" : 182310323775221762,
  "created_at" : "2012-03-21 03:39:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 0, 9 ],
      "id_str" : "9267332",
      "id" : 9267332
    }, {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 51, 58 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182293079993233409",
  "geo" : { },
  "id_str" : "182309649578594305",
  "in_reply_to_user_id" : 9267332,
  "text" : "@rtomayko get that on Streaks. good luck dude. \/cc @maddox",
  "id" : 182309649578594305,
  "in_reply_to_status_id" : 182293079993233409,
  "created_at" : "2012-03-21 03:36:22 +0000",
  "in_reply_to_screen_name" : "rtomayko",
  "in_reply_to_user_id_str" : "9267332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 78, 88 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182309217468817409",
  "text" : "I love seeing these stats. 9.22942187 terabytes pushed out of CloudFront from @gemcutter in February.",
  "id" : 182309217468817409,
  "created_at" : "2012-03-21 03:34:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "In\u00E9s Sombra",
      "screen_name" : "randommood",
      "indices" : [ 0, 11 ],
      "id_str" : "18139160",
      "id" : 18139160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182299663498625028",
  "geo" : { },
  "id_str" : "182303205605122048",
  "in_reply_to_user_id" : 18139160,
  "text" : "@randommood thanks, glad you're thinking about it too. wasn't trolling :)",
  "id" : 182303205605122048,
  "in_reply_to_status_id" : 182299663498625028,
  "created_at" : "2012-03-21 03:10:45 +0000",
  "in_reply_to_screen_name" : "randommood",
  "in_reply_to_user_id_str" : "18139160",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/3X1bFgKm",
      "expanded_url" : "http:\/\/status.rubygems.org",
      "display_url" : "status.rubygems.org"
    }, {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/HkqixLyl",
      "expanded_url" : "http:\/\/uptime.rubygems.org",
      "display_url" : "uptime.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "182299309285441537",
  "geo" : { },
  "id_str" : "182299723133222912",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic Everything looks fine here. http:\/\/t.co\/3X1bFgKm http:\/\/t.co\/HkqixLyl all clear.",
  "id" : 182299723133222912,
  "in_reply_to_status_id" : 182299309285441537,
  "created_at" : "2012-03-21 02:56:55 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Wintheiser",
      "screen_name" : "swintheiser",
      "indices" : [ 0, 12 ],
      "id_str" : "15949476",
      "id" : 15949476
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 39, 49 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182279901355847680",
  "geo" : { },
  "id_str" : "182286476241936384",
  "in_reply_to_user_id" : 15949476,
  "text" : "@swintheiser we use Redis and Memcache @37signals. Reacting in general to talks I've seen though",
  "id" : 182286476241936384,
  "in_reply_to_status_id" : 182279901355847680,
  "created_at" : "2012-03-21 02:04:17 +0000",
  "in_reply_to_screen_name" : "swintheiser",
  "in_reply_to_user_id_str" : "15949476",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "scottgonyea",
      "indices" : [ 0, 12 ],
      "id_str" : "15051550",
      "id" : 15051550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182275525035831296",
  "geo" : { },
  "id_str" : "182275942943690756",
  "in_reply_to_user_id" : 15051550,
  "text" : "@scottgonyea yeah the \"no migrations\" tag line is such bullshit. What a joke.",
  "id" : 182275942943690756,
  "in_reply_to_status_id" : 182275525035831296,
  "created_at" : "2012-03-21 01:22:25 +0000",
  "in_reply_to_screen_name" : "scottgonyea",
  "in_reply_to_user_id_str" : "15051550",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "In\u00E9s Sombra",
      "screen_name" : "randommood",
      "indices" : [ 11, 22 ],
      "id_str" : "18139160",
      "id" : 18139160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182273460909776896",
  "geo" : { },
  "id_str" : "182273702975643649",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @randommood not complaining about this talk! Just an observation across many meetups\/confs",
  "id" : 182273702975643649,
  "in_reply_to_status_id" : 182273460909776896,
  "created_at" : "2012-03-21 01:13:31 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rosania",
      "screen_name" : "paulrosania",
      "indices" : [ 0, 12 ],
      "id_str" : "889212900",
      "id" : 889212900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182272723135897600",
  "geo" : { },
  "id_str" : "182273109993328641",
  "in_reply_to_user_id" : 15007480,
  "text" : "@paulrosania thanks dude!",
  "id" : 182273109993328641,
  "in_reply_to_status_id" : 182272723135897600,
  "created_at" : "2012-03-21 01:11:10 +0000",
  "in_reply_to_screen_name" : "ptr",
  "in_reply_to_user_id_str" : "15007480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182272967886123008",
  "text" : "Tell me why it isn't taught in school. Why it's not in books. Why I need to pay a vendor to put out fires. What makes it awesome regardless.",
  "id" : 182272967886123008,
  "created_at" : "2012-03-21 01:10:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182272577937485824",
  "text" : "Show me how to model data. What the code looks like. Why it's a pain. How changing your relational data will hurt and help.",
  "id" : 182272577937485824,
  "created_at" : "2012-03-21 01:09:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182272176039280640",
  "text" : "Finally noticed a pattern about NoSQL talks: too many focus on setup, hardware. Not enough on how it's actually used day to day in an app.",
  "id" : 182272176039280640,
  "created_at" : "2012-03-21 01:07:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182251685761130496",
  "geo" : { },
  "id_str" : "182256251097448448",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson there better be cat gifs.",
  "id" : 182256251097448448,
  "in_reply_to_status_id" : 182251685761130496,
  "created_at" : "2012-03-21 00:04:11 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/182248787341873153\/photo\/1",
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/Ly4kELxe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aod6TnaCEAA0g5s.jpg",
      "id_str" : "182248787346067456",
      "id" : 182248787346067456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aod6TnaCEAA0g5s.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/Ly4kELxe"
    } ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182248787341873153",
  "text" : "Lots of folks at #WNYRuby tonight! http:\/\/t.co\/Ly4kELxe",
  "id" : 182248787341873153,
  "created_at" : "2012-03-20 23:34:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/ofOhj1mu",
      "expanded_url" : "http:\/\/api.jquery.com\/jQuery.ajax\/",
      "display_url" : "api.jquery.com\/jQuery.ajax\/"
    } ]
  },
  "geo" : { },
  "id_str" : "182227784364597250",
  "text" : "Just found out about statusCode for jQuery.ajax. Hell yes. http:\/\/t.co\/ofOhj1mu",
  "id" : 182227784364597250,
  "created_at" : "2012-03-20 22:11:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/182224704193560577\/photo\/1",
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/CiqpzdHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AodkZysCAAAN1zv.jpg",
      "id_str" : "182224704197754880",
      "id" : 182224704197754880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AodkZysCAAAN1zv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CiqpzdHb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182224704193560577",
  "text" : "Current dog status. http:\/\/t.co\/CiqpzdHb",
  "id" : 182224704193560577,
  "created_at" : "2012-03-20 21:58:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 0, 9 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/1099RHhl",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/51549782\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "182215614042091521",
  "geo" : { },
  "id_str" : "182217768848994304",
  "in_reply_to_user_id" : 16450420,
  "text" : "@ivyhurst Going to, at http:\/\/t.co\/1099RHhl tonight!",
  "id" : 182217768848994304,
  "in_reply_to_status_id" : 182215614042091521,
  "created_at" : "2012-03-20 21:31:16 +0000",
  "in_reply_to_screen_name" : "ivyhurst",
  "in_reply_to_user_id_str" : "16450420",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 14, 22 ],
      "id_str" : "22682102",
      "id" : 22682102
    }, {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 27, 36 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/H6KaXGJJ",
      "expanded_url" : "http:\/\/blog.cloudmine.me\/post\/19639699720\/about-sexism-in-tech",
      "display_url" : "blog.cloudmine.me\/post\/196396997\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182217352610447360",
  "text" : "Very proud of @dmansen and @marcweil for   standing up against this ridiculous crap. http:\/\/t.co\/H6KaXGJJ",
  "id" : 182217352610447360,
  "created_at" : "2012-03-20 21:29:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 0, 9 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182215200966062080",
  "geo" : { },
  "id_str" : "182215492709265408",
  "in_reply_to_user_id" : 16450420,
  "text" : "@ivyhurst Feeling that way. On the porch and it's 80 out! IN MARCH.",
  "id" : 182215492709265408,
  "in_reply_to_status_id" : 182215200966062080,
  "created_at" : "2012-03-20 21:22:13 +0000",
  "in_reply_to_screen_name" : "ivyhurst",
  "in_reply_to_user_id_str" : "16450420",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 3, 15 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "CloudMine",
      "screen_name" : "CloudMine",
      "indices" : [ 24, 34 ],
      "id_str" : "321499248",
      "id" : 321499248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/0EVgFrAF",
      "expanded_url" : "http:\/\/blog.cloudmine.me\/post\/19639692371\/sexism-in-tech",
      "display_url" : "blog.cloudmine.me\/post\/196396923\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182214461959053312",
  "text" : "RT @rocketslide: Thanks @cloudmine for standing up against sexist bullshit: http:\/\/t.co\/0EVgFrAF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CloudMine",
        "screen_name" : "CloudMine",
        "indices" : [ 7, 17 ],
        "id_str" : "321499248",
        "id" : 321499248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/0EVgFrAF",
        "expanded_url" : "http:\/\/blog.cloudmine.me\/post\/19639692371\/sexism-in-tech",
        "display_url" : "blog.cloudmine.me\/post\/196396923\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182214332392816640",
    "text" : "Thanks @cloudmine for standing up against sexist bullshit: http:\/\/t.co\/0EVgFrAF",
    "id" : 182214332392816640,
    "created_at" : "2012-03-20 21:17:36 +0000",
    "user" : {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "protected" : false,
      "id_str" : "10035582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525804195408904192\/Li3G9oYy_normal.jpeg",
      "id" : 10035582,
      "verified" : false
    }
  },
  "id" : 182214461959053312,
  "created_at" : "2012-03-20 21:18:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182211051943768065",
  "text" : "That moment when you wrap up a lot of work, run the tests you thought were passing, and they all fail. :(",
  "id" : 182211051943768065,
  "created_at" : "2012-03-20 21:04:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/4fULFtC4",
      "expanded_url" : "http:\/\/uncyclopedia.wikia.com\/wiki\/Pac-Man_(walkthrough)",
      "display_url" : "uncyclopedia.wikia.com\/wiki\/Pac-Man_(\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182181737982476288",
  "text" : "This made my day: http:\/\/t.co\/4fULFtC4",
  "id" : 182181737982476288,
  "created_at" : "2012-03-20 19:08:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182158825774784512",
  "geo" : { },
  "id_str" : "182161005655244801",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius then what is Tim Hortons?",
  "id" : 182161005655244801,
  "in_reply_to_status_id" : 182158825774784512,
  "created_at" : "2012-03-20 17:45:42 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182157478291705857",
  "geo" : { },
  "id_str" : "182158904166318081",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh boom! Congrats dude!",
  "id" : 182158904166318081,
  "in_reply_to_status_id" : 182157478291705857,
  "created_at" : "2012-03-20 17:37:21 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakim El Hattab",
      "screen_name" : "hakimel",
      "indices" : [ 0, 8 ],
      "id_str" : "73339662",
      "id" : 73339662
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 9, 21 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182108372848484352",
  "geo" : { },
  "id_str" : "182127040034635776",
  "in_reply_to_user_id" : 73339662,
  "text" : "@hakimel @SaraJChipps I love how the discussion just continued on as normal.",
  "id" : 182127040034635776,
  "in_reply_to_status_id" : 182108372848484352,
  "created_at" : "2012-03-20 15:30:44 +0000",
  "in_reply_to_screen_name" : "hakimel",
  "in_reply_to_user_id_str" : "73339662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 3, 15 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182094639417929728",
  "text" : "RT @techpickles: may your rebases fail to automerge - old developer's curse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182089674540584960",
    "text" : "may your rebases fail to automerge - old developer's curse",
    "id" : 182089674540584960,
    "created_at" : "2012-03-20 13:02:16 +0000",
    "user" : {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "protected" : false,
      "id_str" : "6556972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3557013243\/43646b13149e21c8c9b76f3d272e41e5_normal.jpeg",
      "id" : 6556972,
      "verified" : false
    }
  },
  "id" : 182094639417929728,
  "created_at" : "2012-03-20 13:21:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181922781133418497",
  "text" : "Alright, seriously it's Yuengling time. Monday!!!!",
  "id" : 181922781133418497,
  "created_at" : "2012-03-20 01:59:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 54, 62 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181921965915906048",
  "text" : "RT @rubygems_status: Huge upside to the issues today: @evanphx's infrastructure changes meant gem serving was not interrupted. BIG +1!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan Phoenix",
        "screen_name" : "evanphx",
        "indices" : [ 33, 41 ],
        "id_str" : "5444392",
        "id" : 5444392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181921937805676544",
    "text" : "Huge upside to the issues today: @evanphx's infrastructure changes meant gem serving was not interrupted. BIG +1!!",
    "id" : 181921937805676544,
    "created_at" : "2012-03-20 01:55:44 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 181921965915906048,
  "created_at" : "2012-03-20 01:55:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181913553635262464",
  "geo" : { },
  "id_str" : "181916019877625856",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris thanks man.",
  "id" : 181916019877625856,
  "in_reply_to_status_id" : 181913553635262464,
  "created_at" : "2012-03-20 01:32:13 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Schofield",
      "screen_name" : "uberzealot",
      "indices" : [ 0, 11 ],
      "id_str" : "227046773",
      "id" : 227046773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181906296960860160",
  "geo" : { },
  "id_str" : "181912211143401472",
  "in_reply_to_user_id" : 227046773,
  "text" : "@uberzealot thanks. need that right now.",
  "id" : 181912211143401472,
  "in_reply_to_status_id" : 181906296960860160,
  "created_at" : "2012-03-20 01:17:05 +0000",
  "in_reply_to_screen_name" : "uberzealot",
  "in_reply_to_user_id_str" : "227046773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Garside",
      "screen_name" : "geoffgarside",
      "indices" : [ 0, 13 ],
      "id_str" : "801234",
      "id" : 801234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181906858758508546",
  "geo" : { },
  "id_str" : "181908494545461248",
  "in_reply_to_user_id" : 801234,
  "text" : "@geoffgarside our indexer died, it's showing up now. sorry man.",
  "id" : 181908494545461248,
  "in_reply_to_status_id" : 181906858758508546,
  "created_at" : "2012-03-20 01:02:19 +0000",
  "in_reply_to_screen_name" : "geoffgarside",
  "in_reply_to_user_id_str" : "801234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 139, 140 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181905799726104576",
  "text" : "RT @rubygems_status: Rotten gems have been deleted and authors notified. Going to start debugging what happened here. Rough Monday for @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gemcutter",
        "screen_name" : "gemcutter",
        "indices" : [ 114, 124 ],
        "id_str" : "42259749",
        "id" : 42259749
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181905721066127360",
    "text" : "Rotten gems have been deleted and authors notified. Going to start debugging what happened here. Rough Monday for @gemcutter today :(",
    "id" : 181905721066127360,
    "created_at" : "2012-03-20 00:51:18 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 181905799726104576,
  "created_at" : "2012-03-20 00:51:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181904393883496450",
  "geo" : { },
  "id_str" : "181905475305082880",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills blew those away, yep. :(",
  "id" : 181905475305082880,
  "in_reply_to_status_id" : 181904393883496450,
  "created_at" : "2012-03-20 00:50:19 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Garside",
      "screen_name" : "geoffgarside",
      "indices" : [ 0, 13 ],
      "id_str" : "801234",
      "id" : 801234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181865252017807360",
  "geo" : { },
  "id_str" : "181900244563410944",
  "in_reply_to_user_id" : 801234,
  "text" : "@geoffgarside yes, i think so. we're also dealing with a few missing gems...whats up?",
  "id" : 181900244563410944,
  "in_reply_to_status_id" : 181865252017807360,
  "created_at" : "2012-03-20 00:29:32 +0000",
  "in_reply_to_screen_name" : "geoffgarside",
  "in_reply_to_user_id_str" : "801234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181896226139144192",
  "text" : "RT @rubygems_status: For a safety\/sanity check we'll verify all of the gems that were pushed today so we don't miss any.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181896204622376961",
    "text" : "For a safety\/sanity check we'll verify all of the gems that were pushed today so we don't miss any.",
    "id" : 181896204622376961,
    "created_at" : "2012-03-20 00:13:29 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 181896226139144192,
  "created_at" : "2012-03-20 00:13:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181886748819865600",
  "geo" : { },
  "id_str" : "181896092277948416",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus I'm not seeing this in our list of missing gems. I'll check it out.",
  "id" : 181896092277948416,
  "in_reply_to_status_id" : 181886748819865600,
  "created_at" : "2012-03-20 00:13:02 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 97, 103 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181895231451561987",
  "text" : "RT @rubygems_status: If you have a gem that was pushed and it's not showing up on S3, please let @qrush know and we'll take care of it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 76, 82 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181895164497891329",
    "text" : "If you have a gem that was pushed and it's not showing up on S3, please let @qrush know and we'll take care of it!",
    "id" : 181895164497891329,
    "created_at" : "2012-03-20 00:09:21 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 181895231451561987,
  "created_at" : "2012-03-20 00:09:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 95, 101 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181895223947964418",
  "text" : "RT @rubygems_status: Basically, we've lost the gems from the past hour or so that were pushed. @qrush will be emailing gem authors about ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 74, 80 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181894477823217664",
    "text" : "Basically, we've lost the gems from the past hour or so that were pushed. @qrush will be emailing gem authors about getting them back.",
    "id" : 181894477823217664,
    "created_at" : "2012-03-20 00:06:37 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 181895223947964418,
  "created_at" : "2012-03-20 00:09:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abernardes",
      "screen_name" : "abernardes",
      "indices" : [ 0, 11 ],
      "id_str" : "17511586",
      "id" : 17511586
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 46, 62 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181837919080816641",
  "geo" : { },
  "id_str" : "181838101801467904",
  "in_reply_to_user_id" : 17511586,
  "text" : "@abernardes yes, we're working on it. more at @rubygems_status",
  "id" : 181838101801467904,
  "in_reply_to_status_id" : 181837919080816641,
  "created_at" : "2012-03-19 20:22:36 +0000",
  "in_reply_to_screen_name" : "abernardes",
  "in_reply_to_user_id_str" : "17511586",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181837392691470338",
  "text" : "RT @rubygems_status: We're down, investigating. Hold on!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181837313633026048",
    "text" : "We're down, investigating. Hold on!",
    "id" : 181837313633026048,
    "created_at" : "2012-03-19 20:19:28 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 181837392691470338,
  "created_at" : "2012-03-19 20:19:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/3W2MHINw",
      "expanded_url" : "http:\/\/pandodaily.com\/2012\/03\/18\/the-midwest-mentality\/",
      "display_url" : "pandodaily.com\/2012\/03\/18\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181818555459842048",
  "text" : "\"The Midwest Mentality\", or, \"Sacrifice your life, family, and anything else you care about to make money\". http:\/\/t.co\/3W2MHINw",
  "id" : 181818555459842048,
  "created_at" : "2012-03-19 19:04:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 87, 103 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181793102439268353",
  "text" : "RT @gemcutter: Hey folks, we're about to deploy some infrastructure changes. Check out @rubygems_status for more info (for now on too!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems Status",
        "screen_name" : "rubygems_status",
        "indices" : [ 72, 88 ],
        "id_str" : "529540581",
        "id" : 529540581
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181792508827803648",
    "text" : "Hey folks, we're about to deploy some infrastructure changes. Check out @rubygems_status for more info (for now on too!)",
    "id" : 181792508827803648,
    "created_at" : "2012-03-19 17:21:26 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 181793102439268353,
  "created_at" : "2012-03-19 17:23:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Ku",
      "screen_name" : "rubyku",
      "indices" : [ 3, 10 ],
      "id_str" : "754833",
      "id" : 754833
    }, {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 42, 51 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "Ruby Ku",
      "screen_name" : "rubyku",
      "indices" : [ 68, 75 ],
      "id_str" : "754833",
      "id" : 754833
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 120, 130 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/K0IU2jnE",
      "expanded_url" : "http:\/\/etsy.me\/FPL5gd",
      "display_url" : "etsy.me\/FPL5gd"
    } ]
  },
  "geo" : { },
  "id_str" : "181760480875003904",
  "text" : "RT @rubyku: Perfect 4 my Toronto trip! RT @schneems: Just surprised @rubyku with some awesome fingerless gloves made by @aquaranto http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Professor S",
        "screen_name" : "schneems",
        "indices" : [ 30, 39 ],
        "id_str" : "23621187",
        "id" : 23621187
      }, {
        "name" : "Ruby Ku",
        "screen_name" : "rubyku",
        "indices" : [ 56, 63 ],
        "id_str" : "754833",
        "id" : 754833
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 108, 118 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/K0IU2jnE",
        "expanded_url" : "http:\/\/etsy.me\/FPL5gd",
        "display_url" : "etsy.me\/FPL5gd"
      } ]
    },
    "geo" : { },
    "id_str" : "181425964302073857",
    "text" : "Perfect 4 my Toronto trip! RT @schneems: Just surprised @rubyku with some awesome fingerless gloves made by @aquaranto http:\/\/t.co\/K0IU2jnE",
    "id" : 181425964302073857,
    "created_at" : "2012-03-18 17:04:55 +0000",
    "user" : {
      "name" : "Ruby Ku",
      "screen_name" : "rubyku",
      "protected" : false,
      "id_str" : "754833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422920819203772416\/3ity3Jxo_normal.jpeg",
      "id" : 754833,
      "verified" : false
    }
  },
  "id" : 181760480875003904,
  "created_at" : "2012-03-19 15:14:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 7, 15 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/9o2Hh2hS",
      "expanded_url" : "http:\/\/columbia.patch.com\/articles\/wegmans-expansion-in-maryland-nationwide-spurs-supermarket-wars",
      "display_url" : "columbia.patch.com\/articles\/wegma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181747809698070529",
  "text" : "TL;DR: @Wegmans dominates. http:\/\/t.co\/9o2Hh2hS",
  "id" : 181747809698070529,
  "created_at" : "2012-03-19 14:23:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EYouTube on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/raOGZKSh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=U43Ate3Itjs&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=U43Ate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181237088795111424",
  "text" : "Current status. http:\/\/t.co\/raOGZKSh",
  "id" : 181237088795111424,
  "created_at" : "2012-03-18 04:34:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 3, 13 ],
      "id_str" : "15001533",
      "id" : 15001533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181232822810460160",
  "text" : "RT @mikeburns: Yes, yes, your text editor and shell are tools that you should improve, but so is English. Start there.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178605739374415872",
    "text" : "Yes, yes, your text editor and shell are tools that you should improve, but so is English. Start there.",
    "id" : 178605739374415872,
    "created_at" : "2012-03-10 22:18:21 +0000",
    "user" : {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "protected" : false,
      "id_str" : "15001533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1535039668\/6098112041_6010e8fc10_o__Modified_20_3___normal.jpg",
      "id" : 15001533,
      "verified" : false
    }
  },
  "id" : 181232822810460160,
  "created_at" : "2012-03-18 04:17:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/Vv6Q1BT2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1ytCEuuW2_A",
      "display_url" : "youtube.com\/watch?v=1ytCEu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "181195089635328000",
  "geo" : { },
  "id_str" : "181196888425508864",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius http:\/\/t.co\/Vv6Q1BT2",
  "id" : 181196888425508864,
  "in_reply_to_status_id" : 181195089635328000,
  "created_at" : "2012-03-18 01:54:39 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 3, 10 ],
      "id_str" : "30495974",
      "id" : 30495974
    }, {
      "name" : "jamie monberg",
      "screen_name" : "lomcovak",
      "indices" : [ 139, 140 ],
      "id_str" : "83941330",
      "id" : 83941330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181188026905538560",
  "text" : "RT @berkun: \"An iphone today has more computing power than NASA did in 1969. They put a man on the moon, and we throw birds at pigs\" @lo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jamie monberg",
        "screen_name" : "lomcovak",
        "indices" : [ 121, 130 ],
        "id_str" : "83941330",
        "id" : 83941330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180682617077764096",
    "text" : "\"An iphone today has more computing power than NASA did in 1969. They put a man on the moon, and we throw birds at pigs\" @lomcovak",
    "id" : 180682617077764096,
    "created_at" : "2012-03-16 15:51:07 +0000",
    "user" : {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "protected" : false,
      "id_str" : "30495974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553404565974810624\/-W0w3VbD_normal.jpeg",
      "id" : 30495974,
      "verified" : false
    }
  },
  "id" : 181188026905538560,
  "created_at" : "2012-03-18 01:19:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181184305509302272",
  "geo" : { },
  "id_str" : "181185380975001600",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines --binstubs dude",
  "id" : 181185380975001600,
  "in_reply_to_status_id" : 181184305509302272,
  "created_at" : "2012-03-18 01:08:55 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181120588310523905",
  "geo" : { },
  "id_str" : "181121705060728832",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y well, what else would you be doing on that page? :)",
  "id" : 181121705060728832,
  "in_reply_to_status_id" : 181120588310523905,
  "created_at" : "2012-03-17 20:55:54 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Potter",
      "screen_name" : "cookingforgeeks",
      "indices" : [ 3, 19 ],
      "id_str" : "3032961809",
      "id" : 3032961809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/hmLduc3R",
      "expanded_url" : "http:\/\/bit.ly\/FOOyNn",
      "display_url" : "bit.ly\/FOOyNn"
    } ]
  },
  "geo" : { },
  "id_str" : "181050775974318080",
  "text" : "RT @cookingforgeeks: Author of \"Fast Food Nation\" on state of food, ten years later: http:\/\/t.co\/hmLduc3R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/hmLduc3R",
        "expanded_url" : "http:\/\/bit.ly\/FOOyNn",
        "display_url" : "bit.ly\/FOOyNn"
      } ]
    },
    "geo" : { },
    "id_str" : "181040439376347137",
    "text" : "Author of \"Fast Food Nation\" on state of food, ten years later: http:\/\/t.co\/hmLduc3R",
    "id" : 181040439376347137,
    "created_at" : "2012-03-17 15:32:58 +0000",
    "user" : {
      "name" : "Jeff Potter",
      "screen_name" : "jeffpotterusa",
      "protected" : false,
      "id_str" : "50159591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570280060054032384\/uLRW5Twt_normal.jpeg",
      "id" : 50159591,
      "verified" : false
    }
  },
  "id" : 181050775974318080,
  "created_at" : "2012-03-17 16:14:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/qHpf3AWd",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=m8rzkCkFIus",
      "display_url" : "youtube.com\/watch?v=m8rzkC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181032046209138688",
  "text" : "Current status: http:\/\/t.co\/qHpf3AWd",
  "id" : 181032046209138688,
  "created_at" : "2012-03-17 14:59:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180901609419714561",
  "text" : "Using Google Hangouts for the first time. This interface is so terrible, but at least it's not Skype!",
  "id" : 180901609419714561,
  "created_at" : "2012-03-17 06:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180889072376614912",
  "text" : "OH: \"You should have seen me on Day 16 of Steak Month.\"",
  "id" : 180889072376614912,
  "created_at" : "2012-03-17 05:31:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian",
      "screen_name" : "brixen",
      "indices" : [ 0, 7 ],
      "id_str" : "2897551",
      "id" : 2897551
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 8, 19 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180806531841921027",
  "geo" : { },
  "id_str" : "180845858076635137",
  "in_reply_to_user_id" : 2897551,
  "text" : "@brixen @joshsusser what? How can you say this when so many businesses use it?",
  "id" : 180845858076635137,
  "in_reply_to_status_id" : 180806531841921027,
  "created_at" : "2012-03-17 02:39:47 +0000",
  "in_reply_to_screen_name" : "brixen",
  "in_reply_to_user_id_str" : "2897551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180844407317217280",
  "text" : "\"As an EMC Employee, I just hope they let us use Pivotal Tracker!\" LOL this is going to go well.",
  "id" : 180844407317217280,
  "created_at" : "2012-03-17 02:34:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trajectory",
      "screen_name" : "apptrajectory",
      "indices" : [ 85, 99 ],
      "id_str" : "227333900",
      "id" : 227333900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180820448580354049",
  "text" : "Blown away by the Pivotal buyout. Really? I hope it generates way more attention for @apptrajectory.",
  "id" : 180820448580354049,
  "created_at" : "2012-03-17 00:58:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/74JEkENW",
      "expanded_url" : "http:\/\/instagr.am\/p\/IQKENks6iZ\/",
      "display_url" : "instagr.am\/p\/IQKENks6iZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "180804418638323713",
  "text" : "This photo does not do justice to the creepiness of fog and hundreds of gulls squawking just beyond sight. http:\/\/t.co\/74JEkENW",
  "id" : 180804418638323713,
  "created_at" : "2012-03-16 23:55:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 25, 36 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/5cUOwEB5",
      "expanded_url" : "http:\/\/blog.codeacademy.org\/post\/19400078354\/featured-mentor-trevor-turk",
      "display_url" : "blog.codeacademy.org\/post\/194000783\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180719211058970624",
  "text" : "RT @jasonfried: Proud of @trevorturk for giving his time to mentor at Code Academy in Chicago. His story: http:\/\/t.co\/5cUOwEB5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trevor Turk",
        "screen_name" : "trevorturk",
        "indices" : [ 9, 20 ],
        "id_str" : "1742",
        "id" : 1742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/5cUOwEB5",
        "expanded_url" : "http:\/\/blog.codeacademy.org\/post\/19400078354\/featured-mentor-trevor-turk",
        "display_url" : "blog.codeacademy.org\/post\/194000783\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "180715746807132161",
    "text" : "Proud of @trevorturk for giving his time to mentor at Code Academy in Chicago. His story: http:\/\/t.co\/5cUOwEB5",
    "id" : 180715746807132161,
    "created_at" : "2012-03-16 18:02:46 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 180719211058970624,
  "created_at" : "2012-03-16 18:16:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/GIToyu97",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eTvVa6kBOTg",
      "display_url" : "youtube.com\/watch?v=eTvVa6\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "180690036939964416",
  "geo" : { },
  "id_str" : "180690548573749249",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky http:\/\/t.co\/GIToyu97",
  "id" : 180690548573749249,
  "in_reply_to_status_id" : 180690036939964416,
  "created_at" : "2012-03-16 16:22:38 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/l4tNQsfG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8Q7FFjUpVLg",
      "display_url" : "youtube.com\/watch?v=8Q7FFj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180689874645557248",
  "text" : "Current status: http:\/\/t.co\/l4tNQsfG",
  "id" : 180689874645557248,
  "created_at" : "2012-03-16 16:19:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/l4tNQsfG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8Q7FFjUpVLg",
      "display_url" : "youtube.com\/watch?v=8Q7FFj\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "180689318275330048",
  "geo" : { },
  "id_str" : "180689725873590273",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky how about \"day bow boww\" http:\/\/t.co\/l4tNQsfG",
  "id" : 180689725873590273,
  "in_reply_to_status_id" : 180689318275330048,
  "created_at" : "2012-03-16 16:19:22 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180684906014318592",
  "geo" : { },
  "id_str" : "180685179008974850",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef dude...",
  "id" : 180685179008974850,
  "in_reply_to_status_id" : 180684906014318592,
  "created_at" : "2012-03-16 16:01:18 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "indices" : [ 0, 5 ],
      "id_str" : "14184324",
      "id" : 14184324
    }, {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 6, 15 ],
      "id_str" : "57753",
      "id" : 57753
    }, {
      "name" : "Coby Randquist",
      "screen_name" : "kobier",
      "indices" : [ 16, 23 ],
      "id_str" : "5284122",
      "id" : 5284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180684341205143552",
  "in_reply_to_user_id" : 14184324,
  "text" : "@mwrc @blowmage @kobier working now!",
  "id" : 180684341205143552,
  "created_at" : "2012-03-16 15:57:58 +0000",
  "in_reply_to_screen_name" : "mwrc",
  "in_reply_to_user_id_str" : "14184324",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "indices" : [ 0, 5 ],
      "id_str" : "14184324",
      "id" : 14184324
    }, {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 6, 15 ],
      "id_str" : "57753",
      "id" : 57753
    }, {
      "name" : "Coby Randquist",
      "screen_name" : "kobier",
      "indices" : [ 16, 23 ],
      "id_str" : "5284122",
      "id" : 5284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180683439568207872",
  "geo" : { },
  "id_str" : "180683888702660611",
  "in_reply_to_user_id" : 14184324,
  "text" : "@mwrc @blowmage @kobier not getting any sound",
  "id" : 180683888702660611,
  "in_reply_to_status_id" : 180683439568207872,
  "created_at" : "2012-03-16 15:56:10 +0000",
  "in_reply_to_screen_name" : "mwrc",
  "in_reply_to_user_id_str" : "14184324",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 25, 36 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "copycopter",
      "screen_name" : "copycopter",
      "indices" : [ 52, 63 ],
      "id_str" : "227332599",
      "id" : 227332599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 134 ],
      "url" : "https:\/\/t.co\/ZAoEZapg",
      "expanded_url" : "https:\/\/github.com\/copycopter\/copycopter-server",
      "display_url" : "github.com\/copycopter\/cop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180666881714290688",
  "text" : "Seriously good move from @thoughtbot to open source @copycopter. Read some code, lots of awesome sauce in there! https:\/\/t.co\/ZAoEZapg",
  "id" : 180666881714290688,
  "created_at" : "2012-03-16 14:48:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/SXS5qbnH",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/19388751626\/copycopter-is-now-open-source",
      "display_url" : "robots.thoughtbot.com\/post\/193887516\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180666501018300416",
  "text" : "RT @thoughtbot: Copycopter is now open source! http:\/\/t.co\/SXS5qbnH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/SXS5qbnH",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/19388751626\/copycopter-is-now-open-source",
        "display_url" : "robots.thoughtbot.com\/post\/193887516\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "180553146576277505",
    "text" : "Copycopter is now open source! http:\/\/t.co\/SXS5qbnH",
    "id" : 180553146576277505,
    "created_at" : "2012-03-16 07:16:39 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 180666501018300416,
  "created_at" : "2012-03-16 14:47:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich S",
      "screen_name" : "DamnedFacts",
      "indices" : [ 3, 15 ],
      "id_str" : "15153333",
      "id" : 15153333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180665765299634177",
  "text" : "RT @DamnedFacts: The RIT gunman debacle just shows the delicate balance between people playing citizen cop vs. citizen spreading fear, u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180644583980539904",
    "text" : "The RIT gunman debacle just shows the delicate balance between people playing citizen cop vs. citizen spreading fear, uncertainty, and doubt",
    "id" : 180644583980539904,
    "created_at" : "2012-03-16 13:19:59 +0000",
    "user" : {
      "name" : "Rich S",
      "screen_name" : "DamnedFacts",
      "protected" : false,
      "id_str" : "15153333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1742611163\/188578_1605654429297_1474257450_31266221_3061197_n_normal.jpeg",
      "id" : 15153333,
      "verified" : false
    }
  },
  "id" : 180665765299634177,
  "created_at" : "2012-03-16 14:44:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180441288930369537",
  "geo" : { },
  "id_str" : "180447398320025600",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan i think them being drunk is more dangerous",
  "id" : 180447398320025600,
  "in_reply_to_status_id" : 180441288930369537,
  "created_at" : "2012-03-16 00:16:26 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180432073830563840",
  "text" : "Dog ownership: Never feel bad for wasting food from dropping it on the ground again.",
  "id" : 180432073830563840,
  "created_at" : "2012-03-15 23:15:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/180429307515113472\/photo\/1",
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/fDUpDsGW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoEDf83CEAAXJND.jpg",
      "id_str" : "180429307519307776",
      "id" : 180429307519307776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoEDf83CEAAXJND.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fDUpDsGW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180428684279291905",
  "geo" : { },
  "id_str" : "180429307515113472",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik sounds like a chance for INTERNET HIGH FIVE http:\/\/t.co\/fDUpDsGW",
  "id" : 180429307515113472,
  "in_reply_to_status_id" : 180428684279291905,
  "created_at" : "2012-03-15 23:04:34 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180427588068585473",
  "geo" : { },
  "id_str" : "180428493883060224",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik consuming the feed.",
  "id" : 180428493883060224,
  "in_reply_to_status_id" : 180427588068585473,
  "created_at" : "2012-03-15 23:01:19 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Danger",
      "screen_name" : "jackdanger",
      "indices" : [ 1, 12 ],
      "id_str" : "3496901",
      "id" : 3496901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/PXdi0AZB",
      "expanded_url" : "http:\/\/williamedwardscoder.tumblr.com\/post\/18065079081\/cogs-bad",
      "display_url" : "williamedwardscoder.tumblr.com\/post\/180650790\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180426858360344576",
  "text" : ".@jackdanger's talk at #mwrc is reminding me of http:\/\/t.co\/PXdi0AZB",
  "id" : 180426858360344576,
  "created_at" : "2012-03-15 22:54:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180410943975596032",
  "text" : "Porch office....ACTIVATE",
  "id" : 180410943975596032,
  "created_at" : "2012-03-15 21:51:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180402406817939458",
  "geo" : { },
  "id_str" : "180402722502213632",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano @bquarant check out this 18th century bromanticism",
  "id" : 180402722502213632,
  "in_reply_to_status_id" : 180402406817939458,
  "created_at" : "2012-03-15 21:18:55 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 10, 20 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180398355497746434",
  "text" : "Work chat @37signals has devolved into Adventure Time fanboyism. MATHEMATICAL!",
  "id" : 180398355497746434,
  "created_at" : "2012-03-15 21:01:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180391414507646976",
  "geo" : { },
  "id_str" : "180393210886098944",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant deep",
  "id" : 180393210886098944,
  "in_reply_to_status_id" : 180391414507646976,
  "created_at" : "2012-03-15 20:41:07 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180390843293777921",
  "geo" : { },
  "id_str" : "180391192964509699",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant i feel old.",
  "id" : 180391192964509699,
  "in_reply_to_status_id" : 180390843293777921,
  "created_at" : "2012-03-15 20:33:06 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    }, {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 14, 25 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https:\/\/t.co\/LA8XPDdx",
      "expanded_url" : "https:\/\/twitter.com\/#!\/search\/realtime\/%22all%20intensive%20purposes%22",
      "display_url" : "twitter.com\/#!\/search\/real\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "180385748514635776",
  "geo" : { },
  "id_str" : "180386004706918400",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm @mikerubits commence the Derpness: https:\/\/t.co\/LA8XPDdx",
  "id" : 180386004706918400,
  "in_reply_to_status_id" : 180385748514635776,
  "created_at" : "2012-03-15 20:12:29 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180382328810516481",
  "text" : "Apparently it's cut-off jeans weather in Buffalo.",
  "id" : 180382328810516481,
  "created_at" : "2012-03-15 19:57:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 39 ],
      "url" : "https:\/\/t.co\/3eKAvCha",
      "expanded_url" : "https:\/\/img.skitch.com\/20120315-qx7irrck65rx591sxxykm78sfn.png",
      "display_url" : "img.skitch.com\/20120315-qx7ir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180378075228413952",
  "text" : "Seriously though: https:\/\/t.co\/3eKAvCha",
  "id" : 180378075228413952,
  "created_at" : "2012-03-15 19:40:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180377591235088385",
  "text" : "Noticing the parallels between big sports hires and big tech hires today...not sure what to think of this.",
  "id" : 180377591235088385,
  "created_at" : "2012-03-15 19:39:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180354691887144960",
  "geo" : { },
  "id_str" : "180355721886580737",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto a man can dream, can't he?",
  "id" : 180355721886580737,
  "in_reply_to_status_id" : 180354691887144960,
  "created_at" : "2012-03-15 18:12:09 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180354691887144960",
  "geo" : { },
  "id_str" : "180354793116663808",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto *jumps down pipe*",
  "id" : 180354793116663808,
  "in_reply_to_status_id" : 180354691887144960,
  "created_at" : "2012-03-15 18:08:28 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180354380170674176",
  "text" : "Gotta be honest, the temptation to dress up as Mario and get Bills season tickets is at an all time high.",
  "id" : 180354380170674176,
  "created_at" : "2012-03-15 18:06:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 20, 27 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180333507497820160",
  "text" : "I have no idea what @dbrady is talking about at #mwrc or how it has to do with Ruby but I'm loving it.",
  "id" : 180333507497820160,
  "created_at" : "2012-03-15 16:43:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Sampimon",
      "screen_name" : "nathan_scott",
      "indices" : [ 0, 13 ],
      "id_str" : "4959061",
      "id" : 4959061
    }, {
      "name" : "Philip",
      "screen_name" : "parndt",
      "indices" : [ 14, 21 ],
      "id_str" : "15346781",
      "id" : 15346781
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 56, 63 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180297412286488576",
  "geo" : { },
  "id_str" : "180310261515812864",
  "in_reply_to_user_id" : 4959061,
  "text" : "@nathan_scott @parndt however...that's way too big. \/cc @sferik",
  "id" : 180310261515812864,
  "in_reply_to_status_id" : 180297412286488576,
  "created_at" : "2012-03-15 15:11:31 +0000",
  "in_reply_to_screen_name" : "nathan_scott",
  "in_reply_to_user_id_str" : "4959061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Sampimon",
      "screen_name" : "nathan_scott",
      "indices" : [ 0, 13 ],
      "id_str" : "4959061",
      "id" : 4959061
    }, {
      "name" : "Philip",
      "screen_name" : "parndt",
      "indices" : [ 14, 21 ],
      "id_str" : "15346781",
      "id" : 15346781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180297412286488576",
  "geo" : { },
  "id_str" : "180310184302870529",
  "in_reply_to_user_id" : 4959061,
  "text" : "@nathan_scott @parndt we update gems a lot, and we need to keep gems bundled in the repo in case the site goes down.",
  "id" : 180310184302870529,
  "in_reply_to_status_id" : 180297412286488576,
  "created_at" : "2012-03-15 15:11:12 +0000",
  "in_reply_to_screen_name" : "nathan_scott",
  "in_reply_to_user_id_str" : "4959061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/TIvEbHyc",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks#\/w\/2763962368",
      "display_url" : "justin.tv\/confreaks#\/w\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180309923102593024",
  "text" : "Watch MWRC live, bummed I'm missing it this year. http:\/\/t.co\/TIvEbHyc",
  "id" : 180309923102593024,
  "created_at" : "2012-03-15 15:10:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180308373210808320",
  "geo" : { },
  "id_str" : "180308548306219009",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike Feeling the same about it. Clearly the dude wants privacy, why must everyone lavish attention and both him?",
  "id" : 180308548306219009,
  "in_reply_to_status_id" : 180308373210808320,
  "created_at" : "2012-03-15 15:04:42 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180140035268550657",
  "geo" : { },
  "id_str" : "180143185333452800",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike nope! Quite the effort.",
  "id" : 180143185333452800,
  "in_reply_to_status_id" : 180140035268550657,
  "created_at" : "2012-03-15 04:07:36 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit.txt",
      "screen_name" : "Reddit_txt",
      "indices" : [ 5, 16 ],
      "id_str" : "489467009",
      "id" : 489467009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180135858362515456",
  "text" : "Yep. @Reddit_txt. Just...yep.",
  "id" : 180135858362515456,
  "created_at" : "2012-03-15 03:38:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 8, 17 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180133458004283394",
  "geo" : { },
  "id_str" : "180135720856469504",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly @indirect apparently now we're roflscale too",
  "id" : 180135720856469504,
  "in_reply_to_status_id" : 180133458004283394,
  "created_at" : "2012-03-15 03:37:57 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roflscale Tips",
      "screen_name" : "RoflscaleTips",
      "indices" : [ 3, 17 ],
      "id_str" : "264007125",
      "id" : 264007125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180135646483066881",
  "text" : "RT @RoflscaleTips: roflscale your bundling with Bundler 1.1.1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180133842022170624",
    "text" : "roflscale your bundling with Bundler 1.1.1",
    "id" : 180133842022170624,
    "created_at" : "2012-03-15 03:30:29 +0000",
    "user" : {
      "name" : "Roflscale Tips",
      "screen_name" : "RoflscaleTips",
      "protected" : false,
      "id_str" : "264007125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268527763\/roflscale_normal.jpg",
      "id" : 264007125,
      "verified" : false
    }
  },
  "id" : 180135646483066881,
  "created_at" : "2012-03-15 03:37:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 0, 6 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180027199179587586",
  "geo" : { },
  "id_str" : "180028415926214656",
  "in_reply_to_user_id" : 44282335,
  "text" : "@dozba i blame ack.",
  "id" : 180028415926214656,
  "in_reply_to_status_id" : 180027199179587586,
  "created_at" : "2012-03-14 20:31:33 +0000",
  "in_reply_to_screen_name" : "dozba",
  "in_reply_to_user_id_str" : "44282335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 0, 6 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 40 ],
      "url" : "https:\/\/t.co\/kSOvLwge",
      "expanded_url" : "https:\/\/gist.github.com\/2039210",
      "display_url" : "gist.github.com\/2039210"
    } ]
  },
  "in_reply_to_status_id_str" : "180023503943237634",
  "geo" : { },
  "id_str" : "180025084180840448",
  "in_reply_to_user_id" : 44282335,
  "text" : "@dozba bro-oosted: https:\/\/t.co\/kSOvLwge",
  "id" : 180025084180840448,
  "in_reply_to_status_id" : 180023503943237634,
  "created_at" : "2012-03-14 20:18:19 +0000",
  "in_reply_to_screen_name" : "dozba",
  "in_reply_to_user_id_str" : "44282335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179985876124835842",
  "text" : "Stupid twitter bot idea: Respond to all tweets containing \"can i go to the bathroom\" with \"MAY i go to the bathroom\"",
  "id" : 179985876124835842,
  "created_at" : "2012-03-14 17:42:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/uC9wbUDv",
      "expanded_url" : "http:\/\/cerealize.com\/",
      "display_url" : "cerealize.com"
    } ]
  },
  "geo" : { },
  "id_str" : "179963773589790721",
  "text" : "Brilliant. http:\/\/t.co\/uC9wbUDv",
  "id" : 179963773589790721,
  "created_at" : "2012-03-14 16:14:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179642283107434496",
  "text" : "Learned very quickly that the dog can fit through the porch gate we have. Really glad I leashed him as a backup.",
  "id" : 179642283107434496,
  "created_at" : "2012-03-13 18:57:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179634009595326464",
  "geo" : { },
  "id_str" : "179634189866516480",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock haha nooo.",
  "id" : 179634189866516480,
  "in_reply_to_status_id" : 179634009595326464,
  "created_at" : "2012-03-13 18:25:02 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179632820325597185",
  "geo" : { },
  "id_str" : "179633367422205953",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt you are now officially a meme",
  "id" : 179633367422205953,
  "in_reply_to_status_id" : 179632820325597185,
  "created_at" : "2012-03-13 18:21:46 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Qu-craft",
      "screen_name" : "qucraft",
      "indices" : [ 44, 52 ],
      "id_str" : "138345111",
      "id" : 138345111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179632406465220608",
  "text" : "Going to need to take royalties for dubbing @QuCraft's tagline of \"Friggin' Awesome Handmade Stuff\" :shipit:",
  "id" : 179632406465220608,
  "created_at" : "2012-03-13 18:17:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "qucrafts",
      "indices" : [ 3, 12 ],
      "id_str" : "523387572",
      "id" : 523387572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/t8JZA2ZN",
      "expanded_url" : "http:\/\/www.etsy.com\/shop\/QuCrafts",
      "display_url" : "etsy.com\/shop\/QuCrafts"
    } ]
  },
  "geo" : { },
  "id_str" : "179632150050648064",
  "text" : "RT @qucrafts: I'm excited to get the word out about my shop. http:\/\/t.co\/t8JZA2ZN . Follow for updates on new items and sales!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/t8JZA2ZN",
        "expanded_url" : "http:\/\/www.etsy.com\/shop\/QuCrafts",
        "display_url" : "etsy.com\/shop\/QuCrafts"
      } ]
    },
    "geo" : { },
    "id_str" : "179605764393017344",
    "text" : "I'm excited to get the word out about my shop. http:\/\/t.co\/t8JZA2ZN . Follow for updates on new items and sales!",
    "id" : 179605764393017344,
    "created_at" : "2012-03-13 16:32:05 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "qucrafts",
      "protected" : false,
      "id_str" : "523387572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1894263377\/IMG_1924_normal.jpg",
      "id" : 523387572,
      "verified" : false
    }
  },
  "id" : 179632150050648064,
  "created_at" : "2012-03-13 18:16:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sky Mayhew",
      "screen_name" : "skymayhew",
      "indices" : [ 0, 10 ],
      "id_str" : "17912374",
      "id" : 17912374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179430434021720065",
  "geo" : { },
  "id_str" : "179433241969827840",
  "in_reply_to_user_id" : 17912374,
  "text" : "@skymayhew Yep.",
  "id" : 179433241969827840,
  "in_reply_to_status_id" : 179430434021720065,
  "created_at" : "2012-03-13 05:06:33 +0000",
  "in_reply_to_screen_name" : "skymayhew",
  "in_reply_to_user_id_str" : "17912374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/179427384171302912\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/kTbwV9py",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/An10QVjCEAAHPgY.png",
      "id_str" : "179427384175497216",
      "id" : 179427384175497216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/An10QVjCEAAHPgY.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/kTbwV9py"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179427384171302912",
  "text" : "Found a 10 floor waterfall close to my base. Going to recenter base around it, build bridges across the gorge. http:\/\/t.co\/kTbwV9py",
  "id" : 179427384171302912,
  "created_at" : "2012-03-13 04:43:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/qJcTuXHm",
      "expanded_url" : "http:\/\/dwarffortresswiki.org\/images\/e\/e6\/FlowchartDF.png",
      "display_url" : "dwarffortresswiki.org\/images\/e\/e6\/Fl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179394562782007296",
  "text" : "SO YOU WANT TO PLAY DORF FORTRESS. PLEASE REFER TO THIS EASY AND SIMPLE FLOWCHART. http:\/\/t.co\/qJcTuXHm",
  "id" : 179394562782007296,
  "created_at" : "2012-03-13 02:32:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179393393816903681",
  "text" : "Current status: `brew install dwarf-fortress`",
  "id" : 179393393816903681,
  "created_at" : "2012-03-13 02:28:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/XFA7Ix9L",
      "expanded_url" : "http:\/\/troll.me\/images\/brian-kelly-u-mad-bro\/you-mad-bro.jpg",
      "display_url" : "troll.me\/images\/brian-k\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "179352282763243520",
  "geo" : { },
  "id_str" : "179352756392427521",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape http:\/\/t.co\/XFA7Ix9L",
  "id" : 179352756392427521,
  "in_reply_to_status_id" : 179352282763243520,
  "created_at" : "2012-03-12 23:46:43 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/wln4bE72",
      "expanded_url" : "http:\/\/www.geek.com\/articles\/geek-pick\/a-real-user-proves-windows-8-fails-on-the-desktop-20120312\/",
      "display_url" : "geek.com\/articles\/geek-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179351045053497344",
  "text" : "This is just absolutely embarrassing for anyone using Windows or who works at MSFT. http:\/\/t.co\/wln4bE72",
  "id" : 179351045053497344,
  "created_at" : "2012-03-12 23:39:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 14, 24 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/7Be27BbQ",
      "expanded_url" : "http:\/\/www.etsy.com\/shop\/QuCrafts",
      "display_url" : "etsy.com\/shop\/QuCrafts"
    }, {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/P5OP6l64",
      "expanded_url" : "http:\/\/shipitsquirrel.github.com\/",
      "display_url" : "shipitsquirrel.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "179344177677598720",
  "text" : "Very proud of @aquaranto, shipping her first REAL thing this week! http:\/\/t.co\/7Be27BbQ http:\/\/t.co\/P5OP6l64",
  "id" : 179344177677598720,
  "created_at" : "2012-03-12 23:12:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179336184584077312",
  "geo" : { },
  "id_str" : "179336412326400001",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope why is this helpful",
  "id" : 179336412326400001,
  "in_reply_to_status_id" : 179336184584077312,
  "created_at" : "2012-03-12 22:41:47 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ogKR75kP",
      "expanded_url" : "http:\/\/www.graylog2.org\/",
      "display_url" : "graylog2.org"
    } ]
  },
  "geo" : { },
  "id_str" : "179298948614324224",
  "text" : "&lt;3 OSS marketing. \"Manage your logs in the dark and have lasers going and make it look like you're from space.\" http:\/\/t.co\/ogKR75kP",
  "id" : 179298948614324224,
  "created_at" : "2012-03-12 20:12:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 0, 8 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179233829456850944",
  "geo" : { },
  "id_str" : "179235030273507330",
  "in_reply_to_user_id" : 205886758,
  "text" : "@wnyruby Solved that problem.",
  "id" : 179235030273507330,
  "in_reply_to_status_id" : 179233829456850944,
  "created_at" : "2012-03-12 15:58:55 +0000",
  "in_reply_to_screen_name" : "wnyruby",
  "in_reply_to_user_id_str" : "205886758",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179234268906651648",
  "geo" : { },
  "id_str" : "179234583924056064",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove let's change it to :MAYBE, :WRONG",
  "id" : 179234583924056064,
  "in_reply_to_status_id" : 179234268906651648,
  "created_at" : "2012-03-12 15:57:09 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Kane Parker",
      "screen_name" : "moonmaster9000",
      "indices" : [ 0, 15 ],
      "id_str" : "14391298",
      "id" : 14391298
    }, {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 16, 32 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179013976376619008",
  "geo" : { },
  "id_str" : "179021610194436097",
  "in_reply_to_user_id" : 14391298,
  "text" : "@moonmaster9000 @RobotDeathSquad ...What?",
  "id" : 179021610194436097,
  "in_reply_to_status_id" : 179013976376619008,
  "created_at" : "2012-03-12 01:50:52 +0000",
  "in_reply_to_screen_name" : "moonmaster9000",
  "in_reply_to_user_id_str" : "14391298",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    }, {
      "name" : "Dave Moffitt",
      "screen_name" : "davemoffitt",
      "indices" : [ 43, 55 ],
      "id_str" : "280823241",
      "id" : 280823241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179007039811489793",
  "geo" : { },
  "id_str" : "179007603689529344",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich maybe coworking rochester? \/cc @davemoffitt",
  "id" : 179007603689529344,
  "in_reply_to_status_id" : 179007039811489793,
  "created_at" : "2012-03-12 00:55:13 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178977164601999360",
  "text" : "At a Lebanese restaurant playing Daft Punk's Tron soundtrack. And I walked here. Love this city.",
  "id" : 178977164601999360,
  "created_at" : "2012-03-11 22:54:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Nesbitt",
      "screen_name" : "teabass",
      "indices" : [ 3, 11 ],
      "id_str" : "686803",
      "id" : 686803
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 62, 71 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 119 ],
      "url" : "https:\/\/t.co\/XQRF9ISA",
      "expanded_url" : "https:\/\/rubygems.org\/gems\/sinatra\/stats",
      "display_url" : "rubygems.org\/gems\/sinatra\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178960483431350272",
  "text" : "RT @teabass: The pull request for interactive stats graphs on @rubygems I made has been deployed: https:\/\/t.co\/XQRF9ISA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 49, 58 ],
        "id_str" : "14881835",
        "id" : 14881835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 106 ],
        "url" : "https:\/\/t.co\/XQRF9ISA",
        "expanded_url" : "https:\/\/rubygems.org\/gems\/sinatra\/stats",
        "display_url" : "rubygems.org\/gems\/sinatra\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "178956981497892864",
    "text" : "The pull request for interactive stats graphs on @rubygems I made has been deployed: https:\/\/t.co\/XQRF9ISA",
    "id" : 178956981497892864,
    "created_at" : "2012-03-11 21:34:03 +0000",
    "user" : {
      "name" : "Andrew Nesbitt",
      "screen_name" : "teabass",
      "protected" : false,
      "id_str" : "686803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448561484625215488\/XamY_DAf_normal.jpeg",
      "id" : 686803,
      "verified" : false
    }
  },
  "id" : 178960483431350272,
  "created_at" : "2012-03-11 21:47:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Nesbitt",
      "screen_name" : "teabass",
      "indices" : [ 0, 8 ],
      "id_str" : "686803",
      "id" : 686803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178956981497892864",
  "geo" : { },
  "id_str" : "178960471544700929",
  "in_reply_to_user_id" : 686803,
  "text" : "@teabass this is awesome!!",
  "id" : 178960471544700929,
  "in_reply_to_status_id" : 178956981497892864,
  "created_at" : "2012-03-11 21:47:56 +0000",
  "in_reply_to_screen_name" : "teabass",
  "in_reply_to_user_id_str" : "686803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Luchetti",
      "screen_name" : "luchetti",
      "indices" : [ 3, 12 ],
      "id_str" : "349367540",
      "id" : 349367540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178951377534451712",
  "text" : "RT @luchetti: 140 caracteres? \uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.qip.ru\/\" rel=\"nofollow\"\u003EQIP 2012\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177524100930084864",
    "text" : "140 caracteres? \uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF\uDBC3\uDFFF?\uDBC3\uDFFF\uDBC3\uDFFF?",
    "id" : 177524100930084864,
    "created_at" : "2012-03-07 22:40:18 +0000",
    "user" : {
      "name" : "Edney Cunha",
      "screen_name" : "EdneyCunha",
      "protected" : false,
      "id_str" : "16826650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000544926632\/bbe74eef6ee7298048899e4aee569cf0_normal.jpeg",
      "id" : 16826650,
      "verified" : false
    }
  },
  "id" : 178951377534451712,
  "created_at" : "2012-03-11 21:11:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178672622119301120",
  "geo" : { },
  "id_str" : "178948854236971008",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair game was way faster too, and can play up to 8. Less strategy, but still good",
  "id" : 178948854236971008,
  "in_reply_to_status_id" : 178672622119301120,
  "created_at" : "2012-03-11 21:01:46 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Turner",
      "screen_name" : "amerine",
      "indices" : [ 0, 8 ],
      "id_str" : "6221832",
      "id" : 6221832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178682369870532608",
  "geo" : { },
  "id_str" : "178948661760360448",
  "in_reply_to_user_id" : 6221832,
  "text" : "@amerine it's very Pandemic like. Excited to try the harder modes.",
  "id" : 178948661760360448,
  "in_reply_to_status_id" : 178682369870532608,
  "created_at" : "2012-03-11 21:01:00 +0000",
  "in_reply_to_screen_name" : "amerine",
  "in_reply_to_user_id_str" : "6221832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel Martin",
      "screen_name" : "GabrielMtn",
      "indices" : [ 0, 11 ],
      "id_str" : "139358992",
      "id" : 139358992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178948123832500224",
  "geo" : { },
  "id_str" : "178948523646128128",
  "in_reply_to_user_id" : 139358992,
  "text" : "@GabrielMtn yeah, thanks!",
  "id" : 178948523646128128,
  "in_reply_to_status_id" : 178948123832500224,
  "created_at" : "2012-03-11 21:00:27 +0000",
  "in_reply_to_screen_name" : "GabrielMtn",
  "in_reply_to_user_id_str" : "139358992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178947760047919104",
  "text" : "Absolutely gorgeous day in Buffalo. Lost count of number of dogs met on Elmwood. Ged, of course, needed to meet every one DESPERATELY.",
  "id" : 178947760047919104,
  "created_at" : "2012-03-11 20:57:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 29, 42 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/a2q1xgci",
      "expanded_url" : "http:\/\/bit.ly\/AErDg6",
      "display_url" : "bit.ly\/AErDg6"
    } ]
  },
  "geo" : { },
  "id_str" : "178891811727740928",
  "text" : "If someone wants to create a @herpderpedia esque account, today is your day: http:\/\/t.co\/a2q1xgci I can't handle the Derpness.",
  "id" : 178891811727740928,
  "created_at" : "2012-03-11 17:15:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/jvkYF96M",
      "expanded_url" : "http:\/\/instagr.am\/p\/ICOJG1M6oQ\/",
      "display_url" : "instagr.am\/p\/ICOJG1M6oQ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9233425856, -78.877038 ]
  },
  "id_str" : "178842965400227840",
  "text" : "Can't wait for Spring to really start.  @ Bidwell park http:\/\/t.co\/jvkYF96M",
  "id" : 178842965400227840,
  "created_at" : "2012-03-11 14:01:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/7iBlBXzp",
      "expanded_url" : "http:\/\/instagr.am\/p\/IBAR_6M6t0\/",
      "display_url" : "instagr.am\/p\/IBAR_6M6t0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "178672570021838849",
  "text" : "Setting up Flashpoint! http:\/\/t.co\/7iBlBXzp",
  "id" : 178672570021838849,
  "created_at" : "2012-03-11 02:43:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/vtgFZFH8",
      "expanded_url" : "http:\/\/instagr.am\/p\/IA-08ms6tj\/",
      "display_url" : "instagr.am\/p\/IA-08ms6tj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "178670929449205760",
  "text" : "Tied to win! Tsuro is kind of like Carcassone. http:\/\/t.co\/vtgFZFH8",
  "id" : 178670929449205760,
  "created_at" : "2012-03-11 02:37:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/58MSGGM0",
      "expanded_url" : "http:\/\/instagr.am\/p\/IA9ITWs6tK\/",
      "display_url" : "instagr.am\/p\/IA9ITWs6tK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "178664648504115200",
  "text" : "It's Tsuro time. http:\/\/t.co\/58MSGGM0",
  "id" : 178664648504115200,
  "created_at" : "2012-03-11 02:12:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 24, 34 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/iNypAB7v",
      "expanded_url" : "http:\/\/instagr.am\/p\/IAXTKhs6jk\/",
      "display_url" : "instagr.am\/p\/IAXTKhs6jk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "178581974250815488",
  "text" : "Loved the chalk drawing @37signals this week. http:\/\/t.co\/iNypAB7v",
  "id" : 178581974250815488,
  "created_at" : "2012-03-10 20:43:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Barnes",
      "screen_name" : "vinbarnes",
      "indices" : [ 0, 10 ],
      "id_str" : "9922972",
      "id" : 9922972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178513826499665921",
  "geo" : { },
  "id_str" : "178516053494734848",
  "in_reply_to_user_id" : 9922972,
  "text" : "@vinbarnes I do that, but regardless they direct you towards the machines",
  "id" : 178516053494734848,
  "in_reply_to_status_id" : 178513826499665921,
  "created_at" : "2012-03-10 16:21:58 +0000",
  "in_reply_to_screen_name" : "vinbarnes",
  "in_reply_to_user_id_str" : "9922972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178492811799298048",
  "text" : "Pumped to be back in Buffalo soon. Love going places but hate getting there. I can't be the only one like this.",
  "id" : 178492811799298048,
  "created_at" : "2012-03-10 14:49:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 9, 17 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178490394231848960",
  "geo" : { },
  "id_str" : "178492482454159360",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @sikachu where can I sign up?!",
  "id" : 178492482454159360,
  "in_reply_to_status_id" : 178490394231848960,
  "created_at" : "2012-03-10 14:48:18 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Borenstein",
      "screen_name" : "pborenstein",
      "indices" : [ 0, 12 ],
      "id_str" : "3675931",
      "id" : 3675931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178490088592908289",
  "geo" : { },
  "id_str" : "178492316028383233",
  "in_reply_to_user_id" : 3675931,
  "text" : "@pborenstein usually it's as I'm walking INTO the metal detector, and the agents point you towards the cancer machine!",
  "id" : 178492316028383233,
  "in_reply_to_status_id" : 178490088592908289,
  "created_at" : "2012-03-10 14:47:39 +0000",
  "in_reply_to_screen_name" : "pborenstein",
  "in_reply_to_user_id_str" : "3675931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178485052861190144",
  "text" : "Seriously though, EVERY time I opt out, I'm in the metal detector line. Fucking hate airports.",
  "id" : 178485052861190144,
  "created_at" : "2012-03-10 14:18:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178484805556633601",
  "text" : "Got to wait in a line for 30 mins, then got a free massage at ORD! These TSA agents need to work in my lower back next time.",
  "id" : 178484805556633601,
  "created_at" : "2012-03-10 14:17:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 3, 12 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178363041140850688",
  "text" : "RT @ubuwaits: The best experiences are those that cross the boundary of what is possible or permissible or acceptable.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178335594462707713",
    "text" : "The best experiences are those that cross the boundary of what is possible or permissible or acceptable.",
    "id" : 178335594462707713,
    "created_at" : "2012-03-10 04:24:53 +0000",
    "user" : {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "protected" : false,
      "id_str" : "6980232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558939000488996864\/n0Z8lT5p_normal.jpeg",
      "id" : 6980232,
      "verified" : false
    }
  },
  "id" : 178363041140850688,
  "created_at" : "2012-03-10 06:13:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moesta",
      "screen_name" : "bmoesta",
      "indices" : [ 0, 8 ],
      "id_str" : "15458287",
      "id" : 15458287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178337512144650240",
  "geo" : { },
  "id_str" : "178362995741691905",
  "in_reply_to_user_id" : 15458287,
  "text" : "@bmoesta you've infected how I think about decisions of consumers, and mine too. Not sure if I'll ever be able to forget. Thanks immensely.",
  "id" : 178362995741691905,
  "in_reply_to_status_id" : 178337512144650240,
  "created_at" : "2012-03-10 06:13:46 +0000",
  "in_reply_to_screen_name" : "bmoesta",
  "in_reply_to_user_id_str" : "15458287",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178358785499348992",
  "text" : "If I could visit Revolution Brewery on every future trip to Chicago, things would be pretty alright.",
  "id" : 178358785499348992,
  "created_at" : "2012-03-10 05:57:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 3, 15 ],
      "id_str" : "16454301",
      "id" : 16454301
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 58, 68 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178267797531529216",
  "text" : "RT @jonasdowney: Not to be all horn tootin', but man, the @37signals crew is awesome. So glad to be a part of it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 41, 51 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178267603901497345",
    "text" : "Not to be all horn tootin', but man, the @37signals crew is awesome. So glad to be a part of it.",
    "id" : 178267603901497345,
    "created_at" : "2012-03-09 23:54:43 +0000",
    "user" : {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "protected" : false,
      "id_str" : "16454301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153090409\/f136c60eca258e42e43b2d1760196833_normal.jpeg",
      "id" : 16454301,
      "verified" : false
    }
  },
  "id" : 178267797531529216,
  "created_at" : "2012-03-09 23:55:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178234483428962304",
  "text" : "Lots of fun, positive Bundler news with the 1.1 release. This is just the start. Love this community.",
  "id" : 178234483428962304,
  "created_at" : "2012-03-09 21:43:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatsuhiko Miyagawa",
      "screen_name" : "miyagawa",
      "indices" : [ 3, 12 ],
      "id_str" : "731253",
      "id" : 731253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178234337672704001",
  "text" : "RT @miyagawa: bundler 1.1 is amazingly fast #rubygems",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubygems",
        "indices" : [ 30, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177522806739832833",
    "text" : "bundler 1.1 is amazingly fast #rubygems",
    "id" : 177522806739832833,
    "created_at" : "2012-03-07 22:35:10 +0000",
    "user" : {
      "name" : "Tatsuhiko Miyagawa",
      "screen_name" : "miyagawa",
      "protected" : false,
      "id_str" : "731253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1107507727\/userpic-square_normal.jpg",
      "id" : 731253,
      "verified" : false
    }
  },
  "id" : 178234337672704001,
  "created_at" : "2012-03-09 21:42:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lucapette",
      "screen_name" : "lucapette",
      "indices" : [ 3, 13 ],
      "id_str" : "17483049",
      "id" : 17483049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178234323189764098",
  "text" : "RT @lucapette: new fast bundler is fast",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178059702394040320",
    "text" : "new fast bundler is fast",
    "id" : 178059702394040320,
    "created_at" : "2012-03-09 10:08:35 +0000",
    "user" : {
      "name" : "lucapette",
      "screen_name" : "lucapette",
      "protected" : false,
      "id_str" : "17483049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517439096495423488\/kMOPqdmG_normal.jpeg",
      "id" : 17483049,
      "verified" : false
    }
  },
  "id" : 178234323189764098,
  "created_at" : "2012-03-09 21:42:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ric Roberts",
      "screen_name" : "RicRoberts",
      "indices" : [ 3, 14 ],
      "id_str" : "16550758",
      "id" : 16550758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178234297851973633",
  "text" : "RT @RicRoberts: I \u2665 bundler 1.1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178227211785084928",
    "text" : "I \u2665 bundler 1.1",
    "id" : 178227211785084928,
    "created_at" : "2012-03-09 21:14:13 +0000",
    "user" : {
      "name" : "Ric Roberts",
      "screen_name" : "RicRoberts",
      "protected" : false,
      "id_str" : "16550758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3116080153\/ba1477325473f2e3f061c59999a8fefb_normal.jpeg",
      "id" : 16550758,
      "verified" : false
    }
  },
  "id" : 178234297851973633,
  "created_at" : "2012-03-09 21:42:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 3, 16 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178234234497011712",
  "text" : "RT @jordansissel: Whoa, bundler 1.1.0 is crazy fast.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178222084672073728",
    "text" : "Whoa, bundler 1.1.0 is crazy fast.",
    "id" : 178222084672073728,
    "created_at" : "2012-03-09 20:53:50 +0000",
    "user" : {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "protected" : false,
      "id_str" : "15782607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568888532127600640\/MCwi3w4b_normal.jpeg",
      "id" : 15782607,
      "verified" : false
    }
  },
  "id" : 178234234497011712,
  "created_at" : "2012-03-09 21:42:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/UJ22CDtb",
      "expanded_url" : "http:\/\/tmblr.co\/Z5PrDwHjNfGN",
      "display_url" : "tmblr.co\/Z5PrDwHjNfGN"
    } ]
  },
  "geo" : { },
  "id_str" : "178233254728581120",
  "text" : "Is this the first gif used to promote a movie? http:\/\/t.co\/UJ22CDtb Loving this tumblr campaign.",
  "id" : 178233254728581120,
  "created_at" : "2012-03-09 21:38:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    }, {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 7, 18 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178189724761071616",
  "geo" : { },
  "id_str" : "178190973740912640",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope @supaspoida oh, wow. we should make a vim OG keyboard.",
  "id" : 178190973740912640,
  "in_reply_to_status_id" : 178189724761071616,
  "created_at" : "2012-03-09 18:50:13 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/Mi7oyOXe",
      "expanded_url" : "http:\/\/www.catonmat.net\/blog\/why-vim-uses-hjkl-as-arrow-keys\/",
      "display_url" : "catonmat.net\/blog\/why-vim-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178187559451639809",
  "text" : "I love computer history posts like this. Here's the terminal vi was made on. http:\/\/t.co\/Mi7oyOXe",
  "id" : 178187559451639809,
  "created_at" : "2012-03-09 18:36:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178149613251985408",
  "geo" : { },
  "id_str" : "178149728561803264",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn fridge.",
  "id" : 178149728561803264,
  "in_reply_to_status_id" : 178149613251985408,
  "created_at" : "2012-03-09 16:06:19 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 60, 71 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178103741440987136",
  "geo" : { },
  "id_str" : "178104369663840257",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez ha! Maybe we will try it out then...last I checked @pnoordhuis said it was a bad idea to publicly expose it",
  "id" : 178104369663840257,
  "in_reply_to_status_id" : 178103741440987136,
  "created_at" : "2012-03-09 13:06:05 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 115, 124 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178099699377647617",
  "geo" : { },
  "id_str" : "178100299167301633",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez yes, but clients are meant to close sockets properly, etc? Was considering using this as a public API for @rubygems downloads.",
  "id" : 178100299167301633,
  "in_reply_to_status_id" : 178099699377647617,
  "created_at" : "2012-03-09 12:49:54 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178087160098988032",
  "geo" : { },
  "id_str" : "178098621013704704",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez I thought this was a bad idea, since the clients are assumed to do nice things?",
  "id" : 178098621013704704,
  "in_reply_to_status_id" : 178087160098988032,
  "created_at" : "2012-03-09 12:43:14 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 3, 16 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178007093457063936",
  "text" : "RT @Horse_ebooks: Prioritizing Interruptions\nMinimizing Interruptions\nIdentifying Time",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178005076835713024",
    "text" : "Prioritizing Interruptions\nMinimizing Interruptions\nIdentifying Time",
    "id" : 178005076835713024,
    "created_at" : "2012-03-09 06:31:32 +0000",
    "user" : {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "protected" : false,
      "id_str" : "174958347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096005346\/1_normal.jpg",
      "id" : 174958347,
      "verified" : false
    }
  },
  "id" : 178007093457063936,
  "created_at" : "2012-03-09 06:39:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 3, 16 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178003453589725184",
  "text" : "RT @Horse_ebooks: dangerous methods",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178003222785572864",
    "text" : "dangerous methods",
    "id" : 178003222785572864,
    "created_at" : "2012-03-09 06:24:10 +0000",
    "user" : {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "protected" : false,
      "id_str" : "174958347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096005346\/1_normal.jpg",
      "id" : 174958347,
      "verified" : false
    }
  },
  "id" : 178003453589725184,
  "created_at" : "2012-03-09 06:25:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178001909695791104",
  "text" : "First PB&J tonight. Pizza, Pabst, Jameson. Feeling like a real Chicagoan.",
  "id" : 178001909695791104,
  "created_at" : "2012-03-09 06:18:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 7, 15 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177906443599613953",
  "geo" : { },
  "id_str" : "177906538726436865",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi @evanphx wonderful.",
  "id" : 177906538726436865,
  "in_reply_to_status_id" : 177906443599613953,
  "created_at" : "2012-03-08 23:59:58 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 9, 15 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177904120122978305",
  "geo" : { },
  "id_str" : "177906243942354945",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @raggi this is meant to speed up gem installs, not replace bundler, right?",
  "id" : 177906243942354945,
  "in_reply_to_status_id" : 177904120122978305,
  "created_at" : "2012-03-08 23:58:48 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/iprM3YJ2",
      "expanded_url" : "http:\/\/www.mediumdifficulty.com\/2012\/03\/06\/how-i-helped-destroy-star-wars-galaxies\/",
      "display_url" : "mediumdifficulty.com\/2012\/03\/06\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177885235634126848",
  "text" : "This guy helped destroy an MMO. As a former MMO addict, this confirms that I still really hate MMOs. http:\/\/t.co\/iprM3YJ2",
  "id" : 177885235634126848,
  "created_at" : "2012-03-08 22:35:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/yTX07v1P",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=R97Ao5e3m5E",
      "display_url" : "youtube.com\/watch?v=R97Ao5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177857448579829762",
  "text" : "Current status: http:\/\/t.co\/yTX07v1P",
  "id" : 177857448579829762,
  "created_at" : "2012-03-08 20:44:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 8, 18 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/ABlw1Yj9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=GaoLU6zKaws",
      "display_url" : "youtube.com\/watch?v=GaoLU6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177853620354691072",
  "text" : "Current @37signals office status: http:\/\/t.co\/ABlw1Yj9",
  "id" : 177853620354691072,
  "created_at" : "2012-03-08 20:29:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gareth Adams",
      "screen_name" : "garethadams",
      "indices" : [ 0, 12 ],
      "id_str" : "20007147",
      "id" : 20007147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177799872332832769",
  "geo" : { },
  "id_str" : "177829999074754561",
  "in_reply_to_user_id" : 20007147,
  "text" : "@garethadams all of our team uses pow daily. not abandoned at all. it's open source, cmon man.",
  "id" : 177829999074754561,
  "in_reply_to_status_id" : 177799872332832769,
  "created_at" : "2012-03-08 18:55:50 +0000",
  "in_reply_to_screen_name" : "garethadams",
  "in_reply_to_user_id_str" : "20007147",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177826873051586560",
  "geo" : { },
  "id_str" : "177827202900033536",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg Yes, it's hourly.",
  "id" : 177827202900033536,
  "in_reply_to_status_id" : 177826873051586560,
  "created_at" : "2012-03-08 18:44:43 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 3, 11 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177815430612783105",
  "text" : "RT @noahhlo: The Redis instance backing up our statsd infrastructure has processed 13.46 BILLION commands without a hiccup. Rock solid.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177812062095941632",
    "text" : "The Redis instance backing up our statsd infrastructure has processed 13.46 BILLION commands without a hiccup. Rock solid.",
    "id" : 177812062095941632,
    "created_at" : "2012-03-08 17:44:33 +0000",
    "user" : {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "protected" : false,
      "id_str" : "234465384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412045673408651264\/CPEGZ-93_normal.jpeg",
      "id" : 234465384,
      "verified" : false
    }
  },
  "id" : 177815430612783105,
  "created_at" : "2012-03-08 17:57:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaroslav Markin",
      "screen_name" : "yaroslav",
      "indices" : [ 0, 9 ],
      "id_str" : "7605802",
      "id" : 7605802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177782466399059969",
  "geo" : { },
  "id_str" : "177782608573374464",
  "in_reply_to_user_id" : 7605802,
  "text" : "@yaroslav i really dont see this as sad, it's evolution.",
  "id" : 177782608573374464,
  "in_reply_to_status_id" : 177782466399059969,
  "created_at" : "2012-03-08 15:47:31 +0000",
  "in_reply_to_screen_name" : "yaroslav",
  "in_reply_to_user_id_str" : "7605802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaroslav Markin",
      "screen_name" : "yaroslav",
      "indices" : [ 0, 9 ],
      "id_str" : "7605802",
      "id" : 7605802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177781151811895296",
  "geo" : { },
  "id_str" : "177781879221661696",
  "in_reply_to_user_id" : 7605802,
  "text" : "@yaroslav not sure why this is a bad thing?",
  "id" : 177781879221661696,
  "in_reply_to_status_id" : 177781151811895296,
  "created_at" : "2012-03-08 15:44:37 +0000",
  "in_reply_to_screen_name" : "yaroslav",
  "in_reply_to_user_id_str" : "7605802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 125 ],
      "url" : "https:\/\/t.co\/kZsSQQjE",
      "expanded_url" : "https:\/\/rpm.newrelic.com\/public\/charts\/iLtQ9vdb5LM",
      "display_url" : "rpm.newrelic.com\/public\/charts\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177780359881175040",
  "text" : "New Bundler endpoint has been performing wonderfully! The big drop is due to pipelining Redis commands! https:\/\/t.co\/kZsSQQjE",
  "id" : 177780359881175040,
  "created_at" : "2012-03-08 15:38:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 56, 67 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 69, 76 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177753057990426626",
  "geo" : { },
  "id_str" : "177764033909358593",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot bourbon just aged deliciously! Awesome work @phillapier, @rbates !!",
  "id" : 177764033909358593,
  "in_reply_to_status_id" : 177753057990426626,
  "created_at" : "2012-03-08 14:33:43 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/o5T6667D",
      "expanded_url" : "http:\/\/railscasts.com\/episodes\/330-better-sass-with-bourbon",
      "display_url" : "railscasts.com\/episodes\/330-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177763738433228802",
  "text" : "RT @thoughtbot: Railscast: Better Sass with Bourbon http:\/\/t.co\/o5T6667D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/o5T6667D",
        "expanded_url" : "http:\/\/railscasts.com\/episodes\/330-better-sass-with-bourbon",
        "display_url" : "railscasts.com\/episodes\/330-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "177753057990426626",
    "text" : "Railscast: Better Sass with Bourbon http:\/\/t.co\/o5T6667D",
    "id" : 177753057990426626,
    "created_at" : "2012-03-08 13:50:06 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 177763738433228802,
  "created_at" : "2012-03-08 14:32:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 13, 21 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/msFns1aA",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "177622709012934656",
  "text" : "RT @evanphx: @antirez Upgraded http:\/\/t.co\/msFns1aA from redis 2.0 to 2.4.8 and reduced heap size from 4.1G to 2.7G! redis FTW!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salvatore Sanfilippo",
        "screen_name" : "antirez",
        "indices" : [ 0, 8 ],
        "id_str" : "5813712",
        "id" : 5813712
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/msFns1aA",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "177622330015617024",
    "in_reply_to_user_id" : 5813712,
    "text" : "@antirez Upgraded http:\/\/t.co\/msFns1aA from redis 2.0 to 2.4.8 and reduced heap size from 4.1G to 2.7G! redis FTW!",
    "id" : 177622330015617024,
    "created_at" : "2012-03-08 05:10:38 +0000",
    "in_reply_to_screen_name" : "antirez",
    "in_reply_to_user_id_str" : "5813712",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 177622709012934656,
  "created_at" : "2012-03-08 05:12:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177611876459479040",
  "geo" : { },
  "id_str" : "177618701196079106",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod I'm going to toss a graph on the new status site...more transparency FTW!",
  "id" : 177618701196079106,
  "in_reply_to_status_id" : 177611876459479040,
  "created_at" : "2012-03-08 04:56:13 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177611876459479040",
  "geo" : { },
  "id_str" : "177618586574139392",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod yeah it's a live graph! Basically it's a lot faster to pipeline many redis commands.",
  "id" : 177618586574139392,
  "in_reply_to_status_id" : 177611876459479040,
  "created_at" : "2012-03-08 04:55:45 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/177581883377467392\/photo\/1",
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/2RUttD6Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnblyDWCQAA9hui.jpg",
      "id_str" : "177581883381661696",
      "id" : 177581883381661696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnblyDWCQAA9hui.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/2RUttD6Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.853624, -87.645985 ]
  },
  "id_str" : "177581883377467392",
  "text" : "At least this restaurant is honest. http:\/\/t.co\/2RUttD6Z",
  "id" : 177581883377467392,
  "created_at" : "2012-03-08 02:29:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177574086342488064",
  "geo" : { },
  "id_str" : "177581100355428352",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn yeah...going to embed a better one in the new status site.",
  "id" : 177581100355428352,
  "in_reply_to_status_id" : 177574086342488064,
  "created_at" : "2012-03-08 02:26:48 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alexander rakoczy",
      "screen_name" : "scissorjammer",
      "indices" : [ 0, 14 ],
      "id_str" : "1413246176",
      "id" : 1413246176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 36 ],
      "url" : "https:\/\/t.co\/L4aCNxHX",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/commit\/d3b915fe98bd0774e76d85679cc6546aa605473e",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "177550293125431297",
  "geo" : { },
  "id_str" : "177559170436964352",
  "in_reply_to_user_id" : 14238988,
  "text" : "@scissorjammer https:\/\/t.co\/L4aCNxHX",
  "id" : 177559170436964352,
  "in_reply_to_status_id" : 177550293125431297,
  "created_at" : "2012-03-08 00:59:39 +0000",
  "in_reply_to_screen_name" : "toothrot",
  "in_reply_to_user_id_str" : "14238988",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 72, 82 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 105 ],
      "url" : "https:\/\/t.co\/SDXwgGHp",
      "expanded_url" : "https:\/\/rpm.newrelic.com\/public\/charts\/c8wM2zHCgCc",
      "display_url" : "rpm.newrelic.com\/public\/charts\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177549203034210305",
  "text" : "Before, after pipelining Redis commands for the new Bundler endpoint on @gemcutter: https:\/\/t.co\/SDXwgGHp BOOM!",
  "id" : 177549203034210305,
  "created_at" : "2012-03-08 00:20:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/hHQjWLuh",
      "expanded_url" : "http:\/\/redis.io\/topics\/pipelining",
      "display_url" : "redis.io\/topics\/pipelin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "177545866226307072",
  "geo" : { },
  "id_str" : "177548623381413888",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu http:\/\/t.co\/hHQjWLuh",
  "id" : 177548623381413888,
  "in_reply_to_status_id" : 177545866226307072,
  "created_at" : "2012-03-08 00:17:45 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 4, 14 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/177545371277471744\/photo\/1",
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/UNqgEhFo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnbEkxKCMAImr1j.jpg",
      "id_str" : "177545371277471746",
      "id" : 177545371277471746,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnbEkxKCMAImr1j.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/UNqgEhFo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177545371277471744",
  "text" : "Aw, @37signals Snap! http:\/\/t.co\/UNqgEhFo",
  "id" : 177545371277471744,
  "created_at" : "2012-03-08 00:04:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 21, 31 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177544586653212672",
  "text" : "Deployed a change to @gemcutter to make the new Bundler EVEN faster. And we're going to upgrade Redis tonight too. SPEEED!",
  "id" : 177544586653212672,
  "created_at" : "2012-03-08 00:01:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/NaPbJ2eP",
      "expanded_url" : "http:\/\/patshaughnessy.net\/2011\/10\/14\/why-bundler-1-1-will-be-much-faster",
      "display_url" : "patshaughnessy.net\/2011\/10\/14\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177522269147512832",
  "text" : "Really glad Bundler 1.1 is out! SPEED! Here's why it's faster: http:\/\/t.co\/NaPbJ2eP",
  "id" : 177522269147512832,
  "created_at" : "2012-03-07 22:33:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Klein",
      "screen_name" : "kleinmatic",
      "indices" : [ 0, 11 ],
      "id_str" : "6183492",
      "id" : 6183492
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 12, 19 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 58, 66 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177513940379648000",
  "geo" : { },
  "id_str" : "177519731685855232",
  "in_reply_to_user_id" : 6183492,
  "text" : "@kleinmatic @wycats that's how it was before 1.1 as well. @evanphx is working on mirrors and making things way more robust.",
  "id" : 177519731685855232,
  "in_reply_to_status_id" : 177513940379648000,
  "created_at" : "2012-03-07 22:22:56 +0000",
  "in_reply_to_screen_name" : "kleinmatic",
  "in_reply_to_user_id_str" : "6183492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 3, 10 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177492542085021696",
  "text" : "RT @hone02: bundler 1.1.0 is out in the wild. It's been a long road. Thanks for bearing with us! &lt;3 &lt;3 hopefully everyone spends l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177491840528949248",
    "text" : "bundler 1.1.0 is out in the wild. It's been a long road. Thanks for bearing with us! &lt;3 &lt;3 hopefully everyone spends less time waiting.",
    "id" : 177491840528949248,
    "created_at" : "2012-03-07 20:32:07 +0000",
    "user" : {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "protected" : false,
      "id_str" : "15317640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2928200808\/9e35a1697bb4504604356d454a86d5b9_normal.png",
      "id" : 15317640,
      "verified" : false
    }
  },
  "id" : 177492542085021696,
  "created_at" : "2012-03-07 20:34:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/UySl71j7",
      "expanded_url" : "http:\/\/instagr.am\/p\/H4f860s6hA\/",
      "display_url" : "instagr.am\/p\/H4f860s6hA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "177474720596377600",
  "text" : "You know what they say about big doors. http:\/\/t.co\/UySl71j7",
  "id" : 177474720596377600,
  "created_at" : "2012-03-07 19:24:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177467316068548608",
  "geo" : { },
  "id_str" : "177468798406893568",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin not right now bro!",
  "id" : 177468798406893568,
  "in_reply_to_status_id" : 177467316068548608,
  "created_at" : "2012-03-07 19:00:33 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 25, 32 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177457533257129985",
  "text" : "In any case, awesome job @github for doing the SSH key audit. :D",
  "id" : 177457533257129985,
  "created_at" : "2012-03-07 18:15:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177457461060583424",
  "text" : "Suddenly, the sound of thousands of failed CI builds due to the GitHub SSH audit rose up and screamed...",
  "id" : 177457461060583424,
  "created_at" : "2012-03-07 18:15:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 3, 12 ],
      "id_str" : "16891384",
      "id" : 16891384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177400361114542080",
  "text" : "RT @KentBeck: the complexity created by a programmer is in inverse proportion to their ability to handle complexity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177374915018756096",
    "text" : "the complexity created by a programmer is in inverse proportion to their ability to handle complexity",
    "id" : 177374915018756096,
    "created_at" : "2012-03-07 12:47:29 +0000",
    "user" : {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "protected" : false,
      "id_str" : "16891384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2550670043\/xq10bqclqpsezgerjxhi_normal.jpeg",
      "id" : 16891384,
      "verified" : false
    }
  },
  "id" : 177400361114542080,
  "created_at" : "2012-03-07 14:28:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 73, 83 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177280004651098112",
  "text" : "Feeling proud, humbled, and ready to learn more. Basecamp Day 2 tomorrow @37signals. More excited than the first, if that's even possible!",
  "id" : 177280004651098112,
  "created_at" : "2012-03-07 06:30:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Kent",
      "screen_name" : "matthewdalekent",
      "indices" : [ 0, 16 ],
      "id_str" : "260113110",
      "id" : 260113110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177268817389568001",
  "geo" : { },
  "id_str" : "177274480358465537",
  "in_reply_to_user_id" : 260113110,
  "text" : "@matthewdalekent seriously! Much to learn and even more excited now.",
  "id" : 177274480358465537,
  "in_reply_to_status_id" : 177268817389568001,
  "created_at" : "2012-03-07 06:08:24 +0000",
  "in_reply_to_screen_name" : "matthewdalekent",
  "in_reply_to_user_id_str" : "260113110",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 16, 23 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 49, 59 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177246488483737603",
  "text" : "For some reason @will_j put on Pink Floyd in the @37signals office. Visions of The Wall playing mentally. Productivity...zero.",
  "id" : 177246488483737603,
  "created_at" : "2012-03-07 04:17:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/fqFY8jfE",
      "expanded_url" : "http:\/\/yfrog.com\/kl9mwzp",
      "display_url" : "yfrog.com\/kl9mwzp"
    } ]
  },
  "geo" : { },
  "id_str" : "177174438033358849",
  "text" : "RT @37signals: Campfire sound celebration when we passed 10,000 signups for the new Basecamp:  http:\/\/t.co\/fqFY8jfE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/fqFY8jfE",
        "expanded_url" : "http:\/\/yfrog.com\/kl9mwzp",
        "display_url" : "yfrog.com\/kl9mwzp"
      } ]
    },
    "geo" : { },
    "id_str" : "177174160060055552",
    "text" : "Campfire sound celebration when we passed 10,000 signups for the new Basecamp:  http:\/\/t.co\/fqFY8jfE",
    "id" : 177174160060055552,
    "created_at" : "2012-03-06 23:29:46 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 177174438033358849,
  "created_at" : "2012-03-06 23:30:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177172022860845057",
  "geo" : { },
  "id_str" : "177172941899972610",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror i really suggest you try it out. i was really skeptical at first, now I don't ever want to look back.",
  "id" : 177172941899972610,
  "in_reply_to_status_id" : 177172022860845057,
  "created_at" : "2012-03-06 23:24:55 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177170825957490688",
  "geo" : { },
  "id_str" : "177171418826555392",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror have you actually tried to write any?",
  "id" : 177171418826555392,
  "in_reply_to_status_id" : 177170825957490688,
  "created_at" : "2012-03-06 23:18:52 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177168474232201218",
  "geo" : { },
  "id_str" : "177168680344485888",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos no way, you like money too!?",
  "id" : 177168680344485888,
  "in_reply_to_status_id" : 177168474232201218,
  "created_at" : "2012-03-06 23:07:59 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177168255528611840",
  "geo" : { },
  "id_str" : "177168558986510336",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg Drive?",
  "id" : 177168558986510336,
  "in_reply_to_status_id" : 177168255528611840,
  "created_at" : "2012-03-06 23:07:30 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 3, 13 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177145168191963136",
  "text" : "RT @bleything: LOOK OUT, EVERYBODY! I'M WRITING RAILS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177145023211646976",
    "text" : "LOOK OUT, EVERYBODY! I'M WRITING RAILS",
    "id" : 177145023211646976,
    "created_at" : "2012-03-06 21:33:59 +0000",
    "user" : {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "protected" : false,
      "id_str" : "823615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1260090298\/foo_normal.png",
      "id" : 823615,
      "verified" : false
    }
  },
  "id" : 177145168191963136,
  "created_at" : "2012-03-06 21:34:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 21, 31 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177140309795414016",
  "geo" : { },
  "id_str" : "177140440049532928",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez yep, @37signals is all in chicago this week!",
  "id" : 177140440049532928,
  "in_reply_to_status_id" : 177140309795414016,
  "created_at" : "2012-03-06 21:15:46 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Tiernan",
      "screen_name" : "mjtiernan",
      "indices" : [ 3, 13 ],
      "id_str" : "55596295",
      "id" : 55596295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "craftbeer",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/HTUHu8ny",
      "expanded_url" : "http:\/\/www.todaysbeerapp.com\/",
      "display_url" : "todaysbeerapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "177136175851646976",
  "text" : "RT @mjtiernan: Todays Beer: Nice iPhone\/iPad (and hopefully Android SOON) app made by devs from Buffalo - http:\/\/t.co\/HTUHu8ny #craftbeer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "craftbeer",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/HTUHu8ny",
        "expanded_url" : "http:\/\/www.todaysbeerapp.com\/",
        "display_url" : "todaysbeerapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "177132024853835776",
    "text" : "Todays Beer: Nice iPhone\/iPad (and hopefully Android SOON) app made by devs from Buffalo - http:\/\/t.co\/HTUHu8ny #craftbeer",
    "id" : 177132024853835776,
    "created_at" : "2012-03-06 20:42:20 +0000",
    "user" : {
      "name" : "Matt Tiernan",
      "screen_name" : "mjtiernan",
      "protected" : false,
      "id_str" : "55596295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522440688193916928\/yX_QJCQ9_normal.png",
      "id" : 55596295,
      "verified" : false
    }
  },
  "id" : 177136175851646976,
  "created_at" : "2012-03-06 20:58:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177115998703452160",
  "text" : "Absolutely gorgeous out today in Chicago.",
  "id" : 177115998703452160,
  "created_at" : "2012-03-06 19:38:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/QFh9rPry",
      "expanded_url" : "http:\/\/basecamp.com\/humans.txt",
      "display_url" : "basecamp.com\/humans.txt"
    } ]
  },
  "geo" : { },
  "id_str" : "177076401881616384",
  "text" : "Proud to be on this team: http:\/\/t.co\/QFh9rPry",
  "id" : 177076401881616384,
  "created_at" : "2012-03-06 17:01:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177032036857561089",
  "geo" : { },
  "id_str" : "177047702662692864",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik his comment is on top though? HN fail? :(",
  "id" : 177047702662692864,
  "in_reply_to_status_id" : 177032036857561089,
  "created_at" : "2012-03-06 15:07:16 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/KZGpOfcr",
      "expanded_url" : "http:\/\/i.imgur.com\/hLXv9.gif",
      "display_url" : "i.imgur.com\/hLXv9.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "177021935018983425",
  "text" : "Current Basecamp Next status: http:\/\/t.co\/KZGpOfcr",
  "id" : 177021935018983425,
  "created_at" : "2012-03-06 13:24:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Bcmln4jK",
      "expanded_url" : "http:\/\/basecamp.com\/",
      "display_url" : "basecamp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "177021860448440320",
  "text" : "RT @sstephenson: The all-new Basecamp is live: http:\/\/t.co\/Bcmln4jK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/Bcmln4jK",
        "expanded_url" : "http:\/\/basecamp.com\/",
        "display_url" : "basecamp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "177021796720189440",
    "text" : "The all-new Basecamp is live: http:\/\/t.co\/Bcmln4jK",
    "id" : 177021796720189440,
    "created_at" : "2012-03-06 13:24:19 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 177021860448440320,
  "created_at" : "2012-03-06 13:24:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 58, 68 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176864144572694529",
  "text" : "Having a lot of fun and learning an immense amount at the @37signals meetup\/final BCX  sprint! Pumped for tomorrow!",
  "id" : 176864144572694529,
  "created_at" : "2012-03-06 02:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/u8sK7v8R",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/1548448\/contenteditable-breaks-page-up-down-buttons-in-firefox",
      "display_url" : "stackoverflow.com\/questions\/1548\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176831803489918976",
  "text" : "Best response to a stackoverflow question: \"Since no one answered i'm going to sulk and play with matches\" http:\/\/t.co\/u8sK7v8R",
  "id" : 176831803489918976,
  "created_at" : "2012-03-06 00:49:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 38, 50 ],
      "id_str" : "11886642",
      "id" : 11886642
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 51, 63 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/rhzfxKha",
      "expanded_url" : "http:\/\/gunshowcomic.com\/516",
      "display_url" : "gunshowcomic.com\/516"
    } ]
  },
  "geo" : { },
  "id_str" : "176746157710655488",
  "text" : "NOCLIP MODE! http:\/\/t.co\/rhzfxKha \/cc @fredyatesiv @tristandunn",
  "id" : 176746157710655488,
  "created_at" : "2012-03-05 19:09:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176719781616029696",
  "geo" : { },
  "id_str" : "176720077373186048",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox did this once in boston, takes ~2 hours to get back via commuter rail. was terrible.",
  "id" : 176720077373186048,
  "in_reply_to_status_id" : 176719781616029696,
  "created_at" : "2012-03-05 17:25:24 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 3, 7 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176706602143973376",
  "text" : "RT @rsl: i just got a walk-on role on AMC's Breaking Build",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "176704652052668416",
    "text" : "i just got a walk-on role on AMC's Breaking Build",
    "id" : 176704652052668416,
    "created_at" : "2012-03-05 16:24:06 +0000",
    "user" : {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "protected" : false,
      "id_str" : "82863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609922628\/avatar_normal.jpg",
      "id" : 82863,
      "verified" : false
    }
  },
  "id" : 176706602143973376,
  "created_at" : "2012-03-05 16:31:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 26, 36 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/176684597634015233\/photo\/1",
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/4C4O1Gan",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnO1tJeCIAI4dBY.jpg",
      "id_str" : "176684597638209538",
      "id" : 176684597638209538,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnO1tJeCIAI4dBY.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/4C4O1Gan"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176684597634015233",
  "text" : "Just an average Monday at @37signals http:\/\/t.co\/4C4O1Gan",
  "id" : 176684597634015233,
  "created_at" : "2012-03-05 15:04:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176674519258374144",
  "text" : "There are two hard things in Computer Science: being original and this stupid fucking quote.",
  "id" : 176674519258374144,
  "created_at" : "2012-03-05 14:24:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 3, 16 ],
      "id_str" : "5911122",
      "id" : 5911122
    }, {
      "name" : "Peapod Delivers",
      "screen_name" : "PeapodDelivers",
      "indices" : [ 34, 49 ],
      "id_str" : "31168579",
      "id" : 31168579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176669791136919554",
  "text" : "RT @ChrisSmithAV: I wish we had a @PeapodDelivers service in #Buffalo. I miss this service.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peapod Delivers",
        "screen_name" : "PeapodDelivers",
        "indices" : [ 16, 31 ],
        "id_str" : "31168579",
        "id" : 31168579
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "176668050853072896",
    "text" : "I wish we had a @PeapodDelivers service in #Buffalo. I miss this service.",
    "id" : 176668050853072896,
    "created_at" : "2012-03-05 13:58:40 +0000",
    "user" : {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "protected" : true,
      "id_str" : "5911122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563454542260359168\/QWS_s6Pd_normal.png",
      "id" : 5911122,
      "verified" : false
    }
  },
  "id" : 176669791136919554,
  "created_at" : "2012-03-05 14:05:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176653651153133568",
  "geo" : { },
  "id_str" : "176654295146577920",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 Enterprise\u2122",
  "id" : 176654295146577920,
  "in_reply_to_status_id" : 176653651153133568,
  "created_at" : "2012-03-05 13:04:00 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176652901832343553",
  "text" : "Ooh, you can show ALL the history. TRANSPARENCY ALL THE THINGS!",
  "id" : 176652901832343553,
  "created_at" : "2012-03-05 12:58:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/QeG3j17N",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/",
      "display_url" : "uptime.rubygems.org"
    }, {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/8gR9o0Wa",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/131647\/history",
      "display_url" : "uptime.rubygems.org\/131647\/history"
    } ]
  },
  "geo" : { },
  "id_str" : "176652616066019328",
  "text" : "That was easy! http:\/\/t.co\/QeG3j17N And http:\/\/t.co\/8gR9o0Wa (click in for detailed reports of the last 3 months!)",
  "id" : 176652616066019328,
  "created_at" : "2012-03-05 12:57:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176650316421402624",
  "text" : "HAPPY MONDAY!!!!!!!",
  "id" : 176650316421402624,
  "created_at" : "2012-03-05 12:48:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176493009918107648",
  "text" : "Hi Chicago!",
  "id" : 176493009918107648,
  "created_at" : "2012-03-05 02:23:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0BF5\u0BF8\u0BD0 \u0BB7 \u0BA3\u0BB4 \u0B87\u0B88 \u0B16\u0B5F",
      "screen_name" : "PaulDacus99",
      "indices" : [ 0, 12 ],
      "id_str" : "383250801",
      "id" : 383250801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176452974686646273",
  "geo" : { },
  "id_str" : "176456136738869251",
  "in_reply_to_user_id" : 383250801,
  "text" : "@PaulDacus99 yeah clearly most people are awesome, I just feel we should be grateful for the shoulders which we stand on.",
  "id" : 176456136738869251,
  "in_reply_to_status_id" : 176452974686646273,
  "created_at" : "2012-03-04 23:56:36 +0000",
  "in_reply_to_screen_name" : "PaulDacus99",
  "in_reply_to_user_id_str" : "383250801",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/Zuun1rgG",
      "expanded_url" : "http:\/\/news.ycombinator.com",
      "display_url" : "news.ycombinator.com"
    } ]
  },
  "in_reply_to_status_id_str" : "176448942983217152",
  "geo" : { },
  "id_str" : "176450564836700161",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz 127.0.0.1 http:\/\/t.co\/Zuun1rgG in \/etc\/hosts has helped me immensely.",
  "id" : 176450564836700161,
  "in_reply_to_status_id" : 176448942983217152,
  "created_at" : "2012-03-04 23:34:27 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176448675906727938",
  "geo" : { },
  "id_str" : "176448924503126016",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen make it more human. avatars would help. aligning,  sorting projects by importance\/relevance perhaps?",
  "id" : 176448924503126016,
  "in_reply_to_status_id" : 176448675906727938,
  "created_at" : "2012-03-04 23:27:56 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John E. Vincent",
      "screen_name" : "lusis",
      "indices" : [ 0, 6 ],
      "id_str" : "14586723",
      "id" : 14586723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176446995664355329",
  "geo" : { },
  "id_str" : "176447413001789440",
  "in_reply_to_user_id" : 14586723,
  "text" : "@lusis I'm more focused on the community reaction, discussion, and how this must look to those outside\/new to these issues. Just depressing.",
  "id" : 176447413001789440,
  "in_reply_to_status_id" : 176446995664355329,
  "created_at" : "2012-03-04 23:21:56 +0000",
  "in_reply_to_screen_name" : "lusis",
  "in_reply_to_user_id_str" : "14586723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176446814118088704",
  "text" : "Not sure how the situation can be improved but the utter lack of humility and gratitude showed by some for thankless work is appalling.",
  "id" : 176446814118088704,
  "created_at" : "2012-03-04 23:19:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176446691099164672",
  "text" : "This GitHub\/Rails debacle continues to prove my theory that mos OSS consumers are mean, unpolite, and careless compared to producers.",
  "id" : 176446691099164672,
  "created_at" : "2012-03-04 23:19:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 3, 17 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176401887992627201",
  "text" : "RT @PhilDarnowsky: A brief history of the Web:\n\nTIM B-L: \"I invented this stateless protocol.\"\n\nEVERYONE ELSE: \"Neat! Here's a silly hac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "176400800149540864",
    "text" : "A brief history of the Web:\n\nTIM B-L: \"I invented this stateless protocol.\"\n\nEVERYONE ELSE: \"Neat! Here's a silly hack to add state to it.\"",
    "id" : 176400800149540864,
    "created_at" : "2012-03-04 20:16:42 +0000",
    "user" : {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "protected" : false,
      "id_str" : "16930130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000515208563\/76d0685667e16cddd2e830195d42abc4_normal.jpeg",
      "id" : 16930130,
      "verified" : false
    }
  },
  "id" : 176401887992627201,
  "created_at" : "2012-03-04 20:21:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Fallon",
      "screen_name" : "jayfallon",
      "indices" : [ 0, 10 ],
      "id_str" : "814754",
      "id" : 814754
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 11, 25 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176371897712381953",
  "geo" : { },
  "id_str" : "176383857661186049",
  "in_reply_to_user_id" : 814754,
  "text" : "@jayfallon @joshuaclayton some people just like to watch the world burn",
  "id" : 176383857661186049,
  "in_reply_to_status_id" : 176371897712381953,
  "created_at" : "2012-03-04 19:09:23 +0000",
  "in_reply_to_screen_name" : "jayfallon",
  "in_reply_to_user_id_str" : "814754",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176382061123350528",
  "geo" : { },
  "id_str" : "176382579329597442",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza thanks! oh the game ragequits for me. My favorite: \"crushed to death by an exploding drawbridge\"",
  "id" : 176382579329597442,
  "in_reply_to_status_id" : 176382061123350528,
  "created_at" : "2012-03-04 19:04:18 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176381317636825089",
  "geo" : { },
  "id_str" : "176381686853009408",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza my #1 reason for not beating MM9 yet. so unforgiving and painful (this from a proud nethack player, too!)",
  "id" : 176381686853009408,
  "in_reply_to_status_id" : 176381317636825089,
  "created_at" : "2012-03-04 19:00:45 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    }, {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 7, 16 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176377930514042880",
  "geo" : { },
  "id_str" : "176378205027057665",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos @roidrage PIIIIIZZZZZAAAAAAA P I ZZ A",
  "id" : 176378205027057665,
  "in_reply_to_status_id" : 176377930514042880,
  "created_at" : "2012-03-04 18:46:55 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176326454311796736",
  "geo" : { },
  "id_str" : "176362023809064960",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits IMO they should all be copy-pastable. embrace the copy-pasta, you're italian.",
  "id" : 176362023809064960,
  "in_reply_to_status_id" : 176326454311796736,
  "created_at" : "2012-03-04 17:42:37 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176130839724306433",
  "geo" : { },
  "id_str" : "176131949411315713",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d I think you finally tweeting is better.",
  "id" : 176131949411315713,
  "in_reply_to_status_id" : 176130839724306433,
  "created_at" : "2012-03-04 02:28:23 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176070283399135232",
  "geo" : { },
  "id_str" : "176070630486192128",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary WTF?",
  "id" : 176070630486192128,
  "in_reply_to_status_id" : 176070283399135232,
  "created_at" : "2012-03-03 22:24:44 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/2RDBhw9C",
      "expanded_url" : "http:\/\/vimeo.com\/37822969",
      "display_url" : "vimeo.com\/37822969"
    } ]
  },
  "geo" : { },
  "id_str" : "176045051380629504",
  "text" : "RT @37signals: Visualizing the process of building the all new Basecamp: http:\/\/t.co\/2RDBhw9C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/2RDBhw9C",
        "expanded_url" : "http:\/\/vimeo.com\/37822969",
        "display_url" : "vimeo.com\/37822969"
      } ]
    },
    "geo" : { },
    "id_str" : "176043990314008576",
    "text" : "Visualizing the process of building the all new Basecamp: http:\/\/t.co\/2RDBhw9C",
    "id" : 176043990314008576,
    "created_at" : "2012-03-03 20:38:52 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 176045051380629504,
  "created_at" : "2012-03-03 20:43:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176026656161546240",
  "geo" : { },
  "id_str" : "176044792021663745",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel took me a minute. But awesome.",
  "id" : 176044792021663745,
  "in_reply_to_status_id" : 176026656161546240,
  "created_at" : "2012-03-03 20:42:03 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175841104669851648",
  "geo" : { },
  "id_str" : "175961946196156416",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits if you're coming by Buffalo, you know what to do! :)",
  "id" : 175961946196156416,
  "in_reply_to_status_id" : 175841104669851648,
  "created_at" : "2012-03-03 15:12:51 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175807188013547520",
  "text" : "Dog escaped from his crate and somehow didn't destroy anything. Not sure if good dog?",
  "id" : 175807188013547520,
  "created_at" : "2012-03-03 04:57:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/8N7Zzavj",
      "expanded_url" : "http:\/\/instagr.am\/p\/HscRivs6sI\/",
      "display_url" : "instagr.am\/p\/HscRivs6sI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "175777782918422531",
  "text" : "First time at Cantina Loco. Loving Elmwood\/Allentown. http:\/\/t.co\/8N7Zzavj",
  "id" : 175777782918422531,
  "created_at" : "2012-03-03 03:01:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 17, 25 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175717623282143233",
  "geo" : { },
  "id_str" : "175718079605649408",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene @evanphx I honestly have no idea what you're asking.",
  "id" : 175718079605649408,
  "in_reply_to_status_id" : 175717623282143233,
  "created_at" : "2012-03-02 23:03:49 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 0, 11 ],
      "id_str" : "10774712",
      "id" : 10774712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175688938575499264",
  "geo" : { },
  "id_str" : "175689918620770305",
  "in_reply_to_user_id" : 10774712,
  "text" : "@richdownie no :(",
  "id" : 175689918620770305,
  "in_reply_to_status_id" : 175688938575499264,
  "created_at" : "2012-03-02 21:11:55 +0000",
  "in_reply_to_screen_name" : "richdownie",
  "in_reply_to_user_id_str" : "10774712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/xnboxGyA",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3128-basecamp-next-in-phases-and-flow",
      "display_url" : "37signals.com\/svn\/posts\/3128\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175681879805136898",
  "text" : "Whipped up a gource animation for Basecamp Next. Excited to see it launch next week! http:\/\/t.co\/xnboxGyA",
  "id" : 175681879805136898,
  "created_at" : "2012-03-02 20:39:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Drew Streib",
      "screen_name" : "dtype",
      "indices" : [ 0, 6 ],
      "id_str" : "14353555",
      "id" : 14353555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175475172298596352",
  "geo" : { },
  "id_str" : "175580006829932544",
  "in_reply_to_user_id" : 14353555,
  "text" : "@dtype your time wasting graphs prove it :) my team: #. Crushed to death by an exploding drawbridge.",
  "id" : 175580006829932544,
  "in_reply_to_status_id" : 175475172298596352,
  "created_at" : "2012-03-02 13:55:10 +0000",
  "in_reply_to_screen_name" : "dtype",
  "in_reply_to_user_id_str" : "14353555",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 3, 17 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175462449762414595",
  "text" : "RT @joshuaclayton: Finally got pow working; I think Apache was broken before. Love how easy it is to set up and use.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175460721184870400",
    "text" : "Finally got pow working; I think Apache was broken before. Love how easy it is to set up and use.",
    "id" : 175460721184870400,
    "created_at" : "2012-03-02 06:01:10 +0000",
    "user" : {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "protected" : false,
      "id_str" : "10293122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1156127762\/Josh-Clayton_normal.png",
      "id" : 10293122,
      "verified" : false
    }
  },
  "id" : 175462449762414595,
  "created_at" : "2012-03-02 06:08:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/BK62nqms",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-all.php?player=DoctorNick&sort=2",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "175458480075968512",
  "geo" : { },
  "id_str" : "175459932395679744",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates it's been a multi-year thing for me. Been playing since 2007. http:\/\/t.co\/BK62nqms",
  "id" : 175459932395679744,
  "in_reply_to_status_id" : 175458480075968512,
  "created_at" : "2012-03-02 05:58:02 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/28ErDHLW",
      "expanded_url" : "http:\/\/alt.org\/nethack\/mostascensions.html",
      "display_url" : "alt.org\/nethack\/mostas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175454964712357888",
  "text" : "Some days I wonder if my quarterly NetHack obsession is too much. Then I look at http:\/\/t.co\/28ErDHLW and stop worrying.",
  "id" : 175454964712357888,
  "created_at" : "2012-03-02 05:38:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Drew Streib",
      "screen_name" : "dtype",
      "indices" : [ 58, 64 ],
      "id_str" : "14353555",
      "id" : 14353555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/dNeQYUBD",
      "expanded_url" : "http:\/\/nethack.alt.org",
      "display_url" : "nethack.alt.org"
    } ]
  },
  "geo" : { },
  "id_str" : "175453938777202689",
  "text" : "As usual, http:\/\/t.co\/dNeQYUBD is awesome. Huge thanks to @dtype for the hours\/days\/who knows who long of ascending.",
  "id" : 175453938777202689,
  "created_at" : "2012-03-02 05:34:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/gq4k9ppt",
      "expanded_url" : "http:\/\/gunshowcomic.com\/515",
      "display_url" : "gunshowcomic.com\/515"
    } ]
  },
  "geo" : { },
  "id_str" : "175452209230774272",
  "text" : "I WANNA BE AN OWL! http:\/\/t.co\/gq4k9ppt",
  "id" : 175452209230774272,
  "created_at" : "2012-03-02 05:27:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175451432944803844",
  "text" : "Never had to deal with Liches on Astral before. Not recommended. Genocide L!",
  "id" : 175451432944803844,
  "created_at" : "2012-03-02 05:24:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/a6klpXSa",
      "expanded_url" : "http:\/\/alt.org\/nethack\/userdata\/D\/DoctorNick\/dumplog\/1330476557.nh343.txt",
      "display_url" : "alt.org\/nethack\/userda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175450516451622912",
  "text" : "Ascension #8: Archeologist! Toughest ascension yet! Astral was a mess. http:\/\/t.co\/a6klpXSa",
  "id" : 175450516451622912,
  "created_at" : "2012-03-02 05:20:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/175417283076816897\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/EEhTctNd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am81Fu3CAAEsdJB.png",
      "id_str" : "175417283085205505",
      "id" : 175417283085205505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am81Fu3CAAEsdJB.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 657,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1384
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EEhTctNd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/dNeQYUBD",
      "expanded_url" : "http:\/\/nethack.alt.org",
      "display_url" : "nethack.alt.org"
    } ]
  },
  "geo" : { },
  "id_str" : "175417283076816897",
  "text" : "Starting to ascend this Arch. `telnet http:\/\/t.co\/dNeQYUBD` and watch DoctorNick's game if you want to see! http:\/\/t.co\/EEhTctNd",
  "id" : 175417283076816897,
  "created_at" : "2012-03-02 03:08:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FX\u3067\u5B66\u8CBB1\u5E74\u5206+\u03B1\u6EB6\u304B\u3057\u305F\u3068\u3068\u3068",
      "screen_name" : "__t2",
      "indices" : [ 0, 5 ],
      "id_str" : "184964814",
      "id" : 184964814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/YdGTV4Uo",
      "expanded_url" : "http:\/\/code.google.com\/p\/gource\/",
      "display_url" : "code.google.com\/p\/gource\/"
    } ]
  },
  "in_reply_to_status_id_str" : "175407733124759552",
  "geo" : { },
  "id_str" : "175408909643816960",
  "in_reply_to_user_id" : 16450691,
  "text" : "@__t2 gitx? or maybe http:\/\/t.co\/YdGTV4Uo ?",
  "id" : 175408909643816960,
  "in_reply_to_status_id" : 175407733124759552,
  "created_at" : "2012-03-02 02:35:17 +0000",
  "in_reply_to_screen_name" : "trentkocurek",
  "in_reply_to_user_id_str" : "16450691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175395993053962240",
  "text" : "Deep in Gehennom: \"You have a little trouble lifting a wand of wishing.\" !!! If I don't ascend this guy, I'm a tool.",
  "id" : 175395993053962240,
  "created_at" : "2012-03-02 01:43:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175301933458931713",
  "geo" : { },
  "id_str" : "175302199134519297",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh wouldn't be the first time",
  "id" : 175302199134519297,
  "in_reply_to_status_id" : 175301933458931713,
  "created_at" : "2012-03-01 19:31:15 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175300906345185281",
  "geo" : { },
  "id_str" : "175301736251146240",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt i think it's worse when someone calls you \"boss\", but then calls the next dude in line \"boss\". ERR::TOOMANYBOSSES",
  "id" : 175301736251146240,
  "in_reply_to_status_id" : 175300906345185281,
  "created_at" : "2012-03-01 19:29:25 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 3, 11 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/TmX6yB7U",
      "expanded_url" : "http:\/\/vhx.tv\/!4C7S",
      "display_url" : "vhx.tv\/!4C7S"
    } ]
  },
  "geo" : { },
  "id_str" : "175296833625665536",
  "text" : "RT @grahams: Dubstep has now ended. http:\/\/t.co\/TmX6yB7U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vhx.tv\" rel=\"nofollow\"\u003EVHX\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/TmX6yB7U",
        "expanded_url" : "http:\/\/vhx.tv\/!4C7S",
        "display_url" : "vhx.tv\/!4C7S"
      } ]
    },
    "geo" : { },
    "id_str" : "175294676016959490",
    "text" : "Dubstep has now ended. http:\/\/t.co\/TmX6yB7U",
    "id" : 175294676016959490,
    "created_at" : "2012-03-01 19:01:22 +0000",
    "user" : {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "protected" : false,
      "id_str" : "758727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1759661499\/image1326737842_normal.png",
      "id" : 758727,
      "verified" : false
    }
  },
  "id" : 175296833625665536,
  "created_at" : "2012-03-01 19:09:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/cME6jUpg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nxhgP6xsrsY",
      "display_url" : "youtube.com\/watch?v=nxhgP6\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "175260553118359553",
  "geo" : { },
  "id_str" : "175260655065112576",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant http:\/\/t.co\/cME6jUpg",
  "id" : 175260655065112576,
  "in_reply_to_status_id" : 175260553118359553,
  "created_at" : "2012-03-01 16:46:11 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Sveller",
      "screen_name" : "shanesveller",
      "indices" : [ 0, 13 ],
      "id_str" : "6161632",
      "id" : 6161632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175087326316343296",
  "geo" : { },
  "id_str" : "175216945942102016",
  "in_reply_to_user_id" : 6161632,
  "text" : "@shanesveller nope, it's Geddy. Best bass player ever, duh!",
  "id" : 175216945942102016,
  "in_reply_to_status_id" : 175087326316343296,
  "created_at" : "2012-03-01 13:52:29 +0000",
  "in_reply_to_screen_name" : "shanesveller",
  "in_reply_to_user_id_str" : "6161632",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175213053208571905",
  "geo" : { },
  "id_str" : "175216828023451648",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu fetch",
  "id" : 175216828023451648,
  "in_reply_to_status_id" : 175213053208571905,
  "created_at" : "2012-03-01 13:52:01 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
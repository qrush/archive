Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9825009358864386",
  "text" : "RT @gemcutter: Autopsy on the broken download counts: http:\/\/is.gd\/i1D7l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9824841091784704",
    "text" : "Autopsy on the broken download counts: http:\/\/is.gd\/i1D7l",
    "id" : 9824841091784704,
    "created_at" : "2010-12-01 04:23:19 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 9825009358864386,
  "created_at" : "2010-12-01 04:23:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 11, 21 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9817823824052224",
  "text" : "Also, wow, @gemcutter has served up nearly 50 million requests THIS WEEK https:\/\/rpm.newrelic.com\/public\/notes\/8gmRPFcphKA",
  "id" : 9817823824052224,
  "created_at" : "2010-12-01 03:55:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 6, 16 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9816979816845313",
  "text" : "Dang, @gemcutter has a lot of app instance restarts. Is this normal? https:\/\/rpm.newrelic.com\/public\/notes\/lfdyZDGEphf",
  "id" : 9816979816845313,
  "created_at" : "2010-12-01 03:52:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9802126817497088",
  "geo" : { },
  "id_str" : "9802613298044928",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum yanking removes a gem from the index, so `gem list` and bundler can't see it, but you can still go download the .gem manually",
  "id" : 9802613298044928,
  "in_reply_to_status_id" : 9802126817497088,
  "created_at" : "2010-12-01 02:54:59 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    }, {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 9, 18 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9799425325015040",
  "geo" : { },
  "id_str" : "9801751012052992",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky @nirvdrum download the .gem manually and stick it in vendor\/cache. No clue why you guys need that old, broken version.",
  "id" : 9801751012052992,
  "in_reply_to_status_id" : 9799425325015040,
  "created_at" : "2010-12-01 02:51:34 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9795314332471296",
  "geo" : { },
  "id_str" : "9796914476224512",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky 0.5.0 was really broken and did horrible things to your $LOAD_PATH. considering removing all old version of that gem actually",
  "id" : 9796914476224512,
  "in_reply_to_status_id" : 9795314332471296,
  "created_at" : "2010-12-01 02:32:21 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 95, 104 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9741492448923648",
  "text" : "...I'm not gonna be doing any Ruby work here after all. Now I need to find some freelance (via @marcweil) &lt; Someone get him a Ruby job!",
  "id" : 9741492448923648,
  "created_at" : "2010-11-30 22:52:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9735038132297729",
  "geo" : { },
  "id_str" : "9736345685590017",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil WEAK",
  "id" : 9736345685590017,
  "in_reply_to_status_id" : 9735038132297729,
  "created_at" : "2010-11-30 22:31:40 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9721912045342720",
  "text" : "MERGE MERGE MERGE MERGE MERGE MERGE MERGE MERGE",
  "id" : 9721912045342720,
  "created_at" : "2010-11-30 21:34:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9715311557214208",
  "text" : "What's up Titanlings? http:\/\/is.gd\/i0DcC",
  "id" : 9715311557214208,
  "created_at" : "2010-11-30 21:08:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 10, 18 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9707162150379520",
  "geo" : { },
  "id_str" : "9707859981893632",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil @headius is there any open source stuff that Oracle actually likes? First Hudson, now this?",
  "id" : 9707859981893632,
  "in_reply_to_status_id" : 9707162150379520,
  "created_at" : "2010-11-30 20:38:28 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9634309803614208",
  "text" : "\"Fork it, change the name. Oracle needs to learn a lesson here.\" +1 This is what OSS is all about, MOVE IT. http:\/\/bit.ly\/hJ2xnO",
  "id" : 9634309803614208,
  "created_at" : "2010-11-30 15:46:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Mead",
      "screen_name" : "floehopper",
      "indices" : [ 0, 11 ],
      "id_str" : "6989742",
      "id" : 6989742
    }, {
      "name" : "Hudson CI",
      "screen_name" : "hudsonci",
      "indices" : [ 29, 38 ],
      "id_str" : "245535216",
      "id" : 245535216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9612669342457856",
  "geo" : { },
  "id_str" : "9613837414178818",
  "in_reply_to_user_id" : 6989742,
  "text" : "@floehopper that's pathetic. @hudsonci has been awesome for us, I hope this doesn't fragment that community",
  "id" : 9613837414178818,
  "in_reply_to_status_id" : 9612669342457856,
  "created_at" : "2010-11-30 14:24:52 +0000",
  "in_reply_to_screen_name" : "floehopper",
  "in_reply_to_user_id_str" : "6989742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9485556069175296",
  "geo" : { },
  "id_str" : "9492780313219073",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman every single rubygem download on rubygems.org goes through Sinatra. The real magic is Rack, Sinatra's DSL is icing on the cake",
  "id" : 9492780313219073,
  "in_reply_to_status_id" : 9485556069175296,
  "created_at" : "2010-11-30 06:23:49 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9481431654866944",
  "geo" : { },
  "id_str" : "9481598231646208",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety no it's like mint for dentists",
  "id" : 9481598231646208,
  "in_reply_to_status_id" : 9481431654866944,
  "created_at" : "2010-11-30 05:39:23 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 24, 34 ],
      "id_str" : "220097555",
      "id" : 220097555
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 49, 57 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9480264547827712",
  "text" : "First hidden feature of @radishapp discovered by @jayunit tonight: it's actually a group chat application.",
  "id" : 9480264547827712,
  "created_at" : "2010-11-30 05:34:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 3, 11 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 38, 48 ],
      "id_str" : "220097555",
      "id" : 220097555
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 52, 58 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9473696141942784",
  "text" : "RT @jayunit: Just got a sneak peek at @radishapp by @qrush - it's sick!  Monitor and visualize your Redis installations.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Radish",
        "screen_name" : "radishapp",
        "indices" : [ 25, 35 ],
        "id_str" : "220097555",
        "id" : 220097555
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 39, 45 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9473425659658240",
    "text" : "Just got a sneak peek at @radishapp by @qrush - it's sick!  Monitor and visualize your Redis installations.",
    "id" : 9473425659658240,
    "created_at" : "2010-11-30 05:06:55 +0000",
    "user" : {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "protected" : false,
      "id_str" : "14238213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1435351938\/jason2_normal.png",
      "id" : 14238213,
      "verified" : false
    }
  },
  "id" : 9473696141942784,
  "created_at" : "2010-11-30 05:07:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9464959087939584",
  "geo" : { },
  "id_str" : "9465668378296320",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit please put cat DNA in there instead",
  "id" : 9465668378296320,
  "in_reply_to_status_id" : 9464959087939584,
  "created_at" : "2010-11-30 04:36:05 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 17, 27 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9389030504398850",
  "geo" : { },
  "id_str" : "9389551785082880",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck all of @gemcutter's s3 uploads are fog powered. Excon is pretty cool too.",
  "id" : 9389551785082880,
  "in_reply_to_status_id" : 9389030504398850,
  "created_at" : "2010-11-29 23:33:38 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 40, 47 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9376543377723392",
  "geo" : { },
  "id_str" : "9385306402848768",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck not out of anger, but because @geemus is awesome",
  "id" : 9385306402848768,
  "in_reply_to_status_id" : 9376543377723392,
  "created_at" : "2010-11-29 23:16:46 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9377453520715776",
  "geo" : { },
  "id_str" : "9378546812194816",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith dude, seriously",
  "id" : 9378546812194816,
  "in_reply_to_status_id" : 9377453520715776,
  "created_at" : "2010-11-29 22:49:54 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 81, 89 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Ernie Bello",
      "screen_name" : "ebello",
      "indices" : [ 91, 98 ],
      "id_str" : "12983272",
      "id" : 12983272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9351750796447744",
  "text" : "Ahaha .NET has it too http:\/\/msdn.microsoft.com\/en-us\/library\/dd402862.aspx (via @rubiety, @ebello)",
  "id" : 9351750796447744,
  "created_at" : "2010-11-29 21:03:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 3, 11 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9344905360973824",
  "text" : "RT @capotej: O_O http:\/\/svn.codehaus.org\/groovy\/trunk\/groovy\/groovy-core\/src\/main\/org\/codehaus\/groovy\/runtime\/ArrayUtil.java",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9340896537477120",
    "text" : "O_O http:\/\/svn.codehaus.org\/groovy\/trunk\/groovy\/groovy-core\/src\/main\/org\/codehaus\/groovy\/runtime\/ArrayUtil.java",
    "id" : 9340896537477120,
    "created_at" : "2010-11-29 20:20:17 +0000",
    "user" : {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "protected" : false,
      "id_str" : "8898642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497932410890510337\/i-8d5ayf_normal.jpeg",
      "id" : 8898642,
      "verified" : false
    }
  },
  "id" : 9344905360973824,
  "created_at" : "2010-11-29 20:36:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9273151963795456",
  "text" : "RT @thoughtbot: 50% off the Test Driven Rails workshop on December 1-2 with the coupon code \"CYBERMONDAY\", today only",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9272211252715520",
    "text" : "50% off the Test Driven Rails workshop on December 1-2 with the coupon code \"CYBERMONDAY\", today only",
    "id" : 9272211252715520,
    "created_at" : "2010-11-29 15:47:22 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 9273151963795456,
  "created_at" : "2010-11-29 15:51:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "indices" : [ 4, 15 ],
      "id_str" : "5539522",
      "id" : 5539522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9255913214971904",
  "text" : "Hey @AskedRelic apparently you're a pretty cool dude. http:\/\/www.mastersincomputerscience.com\/the-top-50-computer-science-bloggers\/",
  "id" : 9255913214971904,
  "created_at" : "2010-11-29 14:42:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerry Buckley",
      "screen_name" : "kerryb",
      "indices" : [ 0, 7 ],
      "id_str" : "5659312",
      "id" : 5659312
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 52, 59 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 60, 67 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 68, 77 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9236441993314304",
  "geo" : { },
  "id_str" : "9246012623294464",
  "in_reply_to_user_id" : 5659312,
  "text" : "@kerryb iirc in $GEM_HOME\/bundler...might be wrong. @wycats @hone02 @indirect any ideas?",
  "id" : 9246012623294464,
  "in_reply_to_status_id" : 9236441993314304,
  "created_at" : "2010-11-29 14:03:15 +0000",
  "in_reply_to_screen_name" : "kerryb",
  "in_reply_to_user_id_str" : "5659312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerry Buckley",
      "screen_name" : "kerryb",
      "indices" : [ 0, 7 ],
      "id_str" : "5659312",
      "id" : 5659312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9196860610711552",
  "geo" : { },
  "id_str" : "9236015080280064",
  "in_reply_to_user_id" : 5659312,
  "text" : "@kerryb latest version of bundler definitely did for me this weekend. What version are you on?",
  "id" : 9236015080280064,
  "in_reply_to_status_id" : 9196860610711552,
  "created_at" : "2010-11-29 13:23:32 +0000",
  "in_reply_to_screen_name" : "kerryb",
  "in_reply_to_user_id_str" : "5659312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9117526856310785",
  "geo" : { },
  "id_str" : "9118744425013248",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm side project of mine :)",
  "id" : 9118744425013248,
  "in_reply_to_status_id" : 9117526856310785,
  "created_at" : "2010-11-29 05:37:32 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9117701351936000",
  "geo" : { },
  "id_str" : "9118286386044928",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist exactly what i'm aiming for. excited to get others using it and see where feedback leads development of the analysis tools.",
  "id" : 9118286386044928,
  "in_reply_to_status_id" : 9117701351936000,
  "created_at" : "2010-11-29 05:35:43 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 5, 15 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 90, 100 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9115790125039616",
  "text" : "Wow. @gemcutter's redis instance is running around 161 commands\/sec. Learned already from @radishapp we're not SAVE'ing enough.",
  "id" : 9115790125039616,
  "created_at" : "2010-11-29 05:25:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9112120926932992",
  "geo" : { },
  "id_str" : "9112497403465729",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit haha yep",
  "id" : 9112497403465729,
  "in_reply_to_status_id" : 9112120926932992,
  "created_at" : "2010-11-29 05:12:43 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 103, 110 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 111, 120 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Kate Peruzzini",
      "screen_name" : "KeightP",
      "indices" : [ 121, 129 ],
      "id_str" : "18247553",
      "id" : 18247553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9101389707874304",
  "text" : "Apparently there's a whole song dedicated to Brookline. http:\/\/www.youtube.com\/watch?v=UWliiRKi4p0 \/cc @jayroh @bquarant @KeightP",
  "id" : 9101389707874304,
  "created_at" : "2010-11-29 04:28:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 31, 39 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 42, 48 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9087963568807936",
  "text" : "This commit log is approaching @jayunit + @qrush levels of ridiculousness. https:\/\/gist.github.com\/719554",
  "id" : 9087963568807936,
  "created_at" : "2010-11-29 03:35:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 36, 44 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9000117403131904",
  "geo" : { },
  "id_str" : "9086804221235200",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal I should write a blog post. @jayunit showed me during RubyConf, it's way easier to set up than I thought.",
  "id" : 9086804221235200,
  "in_reply_to_status_id" : 9000117403131904,
  "created_at" : "2010-11-29 03:30:37 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9085872917975040",
  "text" : "Welp, now Google is analyzing\/doing whatever with my DNS traffic. It's Comcastic!",
  "id" : 9085872917975040,
  "created_at" : "2010-11-29 03:26:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt MattTodd Todd",
      "screen_name" : "mtodd",
      "indices" : [ 0, 6 ],
      "id_str" : "5933482",
      "id" : 5933482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9081925733974016",
  "geo" : { },
  "id_str" : "9082588509503489",
  "in_reply_to_user_id" : 5933482,
  "text" : "@mtodd idiocracy. It's got electrolytes.",
  "id" : 9082588509503489,
  "in_reply_to_status_id" : 9081925733974016,
  "created_at" : "2010-11-29 03:13:52 +0000",
  "in_reply_to_screen_name" : "mtodd",
  "in_reply_to_user_id_str" : "5933482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 111, 123 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9082478186729472",
  "text" : "Home in Boston, unpacked, and unwinding after a backwoods CT shortcut and extreme Masspike avoidance thanks to @fredyatesiv. Thanks dude.",
  "id" : 9082478186729472,
  "created_at" : "2010-11-29 03:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9010252473171968",
  "text" : "Connecticut: The Under 30mph State",
  "id" : 9010252473171968,
  "created_at" : "2010-11-28 22:26:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9007868565000192",
  "text" : "Hooked up jquery.ui.autocomplete in under an hour. Seriously impressed with each new widget I've played with.",
  "id" : 9007868565000192,
  "created_at" : "2010-11-28 22:16:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iain Hecker",
      "screen_name" : "iain_nl",
      "indices" : [ 0, 8 ],
      "id_str" : "14214888",
      "id" : 14214888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8999861894512641",
  "geo" : { },
  "id_str" : "9007147400564736",
  "in_reply_to_user_id" : 14214888,
  "text" : "@iain_nl that's unique gems. There's over 80k (probably near 90 now) versions",
  "id" : 9007147400564736,
  "in_reply_to_status_id" : 8999861894512641,
  "created_at" : "2010-11-28 22:14:05 +0000",
  "in_reply_to_screen_name" : "iain_nl",
  "in_reply_to_user_id_str" : "14214888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwrd Ocampo-Gooding",
      "screen_name" : "edwardog",
      "indices" : [ 0, 9 ],
      "id_str" : "14251580",
      "id" : 14251580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8982760257495040",
  "geo" : { },
  "id_str" : "8983637110292480",
  "in_reply_to_user_id" : 14251580,
  "text" : "@edwardog been using ssh tunnels\/socks proxies since that came out. Sad state of affairs for open wifi networks.",
  "id" : 8983637110292480,
  "in_reply_to_status_id" : 8982760257495040,
  "created_at" : "2010-11-28 20:40:40 +0000",
  "in_reply_to_screen_name" : "edwardog",
  "in_reply_to_user_id_str" : "14251580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8983585864294400",
  "text" : "Listened to the depressing half of the bills game, now out of AM radio range and missing the exciting half :(",
  "id" : 8983585864294400,
  "created_at" : "2010-11-28 20:40:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8686273975812097",
  "geo" : { },
  "id_str" : "8717167495225346",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats factory_girl. Her factories bring all the models to the yard, and they're like it's better than yours",
  "id" : 8717167495225346,
  "in_reply_to_status_id" : 8686273975812097,
  "created_at" : "2010-11-28 03:01:49 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8639633810259969",
  "geo" : { },
  "id_str" : "8640131065970688",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey language has nothing to do with it. Tests and docs are what matters.",
  "id" : 8640131065970688,
  "in_reply_to_status_id" : 8639633810259969,
  "created_at" : "2010-11-27 21:55:42 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kacy fortner",
      "screen_name" : "kacyf",
      "indices" : [ 0, 6 ],
      "id_str" : "1192561",
      "id" : 1192561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7604047070629888",
  "geo" : { },
  "id_str" : "8537668740718592",
  "in_reply_to_user_id" : 1192561,
  "text" : "@kacyf create a request on http:\/\/help.rubygems.org, we'll get you sorted",
  "id" : 8537668740718592,
  "in_reply_to_status_id" : 7604047070629888,
  "created_at" : "2010-11-27 15:08:33 +0000",
  "in_reply_to_screen_name" : "kacyf",
  "in_reply_to_user_id_str" : "1192561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Riethmayer",
      "screen_name" : "riethmayer",
      "indices" : [ 0, 11 ],
      "id_str" : "15403290",
      "id" : 15403290
    }, {
      "name" : "urbanvention",
      "screen_name" : "urbanvention",
      "indices" : [ 12, 25 ],
      "id_str" : "123291276",
      "id" : 123291276
    }, {
      "name" : "Moritz Lawitschka",
      "screen_name" : "lawitschka",
      "indices" : [ 26, 37 ],
      "id_str" : "90653532",
      "id" : 90653532
    }, {
      "name" : "Pingdom",
      "screen_name" : "pingdomalert",
      "indices" : [ 77, 90 ],
      "id_str" : "71544889",
      "id" : 71544889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8231895355625472",
  "geo" : { },
  "id_str" : "8537607575179264",
  "in_reply_to_user_id" : 15403290,
  "text" : "@riethmayer @urbanvention @lawitschka I didn't see any downtime notices from @pingdomalert yesterday...maybe it was a DNS issue?",
  "id" : 8537607575179264,
  "in_reply_to_status_id" : 8231895355625472,
  "created_at" : "2010-11-27 15:08:18 +0000",
  "in_reply_to_screen_name" : "riethmayer",
  "in_reply_to_user_id_str" : "15403290",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Kr\u00E4uter | 5v3n",
      "screen_name" : "sven_kr",
      "indices" : [ 0, 8 ],
      "id_str" : "61437533",
      "id" : 61437533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8267030809546752",
  "geo" : { },
  "id_str" : "8275930220863489",
  "in_reply_to_user_id" : 61437533,
  "text" : "@sven_kr don't forget, lots of mirrors are combing the site as well",
  "id" : 8275930220863489,
  "in_reply_to_status_id" : 8267030809546752,
  "created_at" : "2010-11-26 21:48:30 +0000",
  "in_reply_to_screen_name" : "sven_kr",
  "in_reply_to_user_id_str" : "61437533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8254036356632576",
  "text" : "OH: \"We have to buy all of them security programs...to get rid of the Trojan horses.\"",
  "id" : 8254036356632576,
  "created_at" : "2010-11-26 20:21:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7927069941956608",
  "geo" : { },
  "id_str" : "8243087360925696",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg http:\/\/rubygems.org ? :)",
  "id" : 8243087360925696,
  "in_reply_to_status_id" : 7927069941956608,
  "created_at" : "2010-11-26 19:37:59 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 29, 37 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8228866531266560",
  "text" : "RT @drbrain: I disagree with @mperham, Ruby\u2019s stdlib is not a Ghetto: http:\/\/bit.ly\/not_a_ghetto",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Perham",
        "screen_name" : "mperham",
        "indices" : [ 16, 24 ],
        "id_str" : "14060922",
        "id" : 14060922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7575021190909952",
    "text" : "I disagree with @mperham, Ruby\u2019s stdlib is not a Ghetto: http:\/\/bit.ly\/not_a_ghetto",
    "id" : 7575021190909952,
    "created_at" : "2010-11-24 23:23:20 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 8228866531266560,
  "created_at" : "2010-11-26 18:41:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8190734469435392",
  "geo" : { },
  "id_str" : "8228616055816192",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler any reason you're looking? We do sell a hosted version :)",
  "id" : 8228616055816192,
  "in_reply_to_status_id" : 8190734469435392,
  "created_at" : "2010-11-26 18:40:29 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 43, 53 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8212800824410112",
  "geo" : { },
  "id_str" : "8228470723186689",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini bourne, its mocha + spies from @joeferris",
  "id" : 8228470723186689,
  "in_reply_to_status_id" : 8212800824410112,
  "created_at" : "2010-11-26 18:39:54 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7812137598582784",
  "text" : "Only Colin Quinn can break out a Nazi joke on national TV during the Thanksgiving parade.",
  "id" : 7812137598582784,
  "created_at" : "2010-11-25 15:05:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 11, 18 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7662072741498880",
  "geo" : { },
  "id_str" : "7669708232859648",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything @bryanl tmux.",
  "id" : 7669708232859648,
  "in_reply_to_status_id" : 7662072741498880,
  "created_at" : "2010-11-25 05:39:35 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7668663821795329",
  "geo" : { },
  "id_str" : "7669497393586176",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini shpadoinkle!",
  "id" : 7669497393586176,
  "in_reply_to_status_id" : 7668663821795329,
  "created_at" : "2010-11-25 05:38:45 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7656813449187328",
  "geo" : { },
  "id_str" : "7660646904631296",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza dude same here. One huge reason I stopped going to conferences last year until graduation",
  "id" : 7660646904631296,
  "in_reply_to_status_id" : 7656813449187328,
  "created_at" : "2010-11-25 05:03:35 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7654823214194688",
  "geo" : { },
  "id_str" : "7656038627016704",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini nope, Hubbard. Spitting distance from PA.",
  "id" : 7656038627016704,
  "in_reply_to_status_id" : 7654823214194688,
  "created_at" : "2010-11-25 04:45:16 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7653493900836865",
  "text" : "OHIOOOOOO",
  "id" : 7653493900836865,
  "created_at" : "2010-11-25 04:35:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7558639996903424",
  "geo" : { },
  "id_str" : "7559400340328448",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i not cool bro. Seriously?",
  "id" : 7559400340328448,
  "in_reply_to_status_id" : 7558639996903424,
  "created_at" : "2010-11-24 22:21:16 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7557267226361856",
  "text" : "Apparently if we stop, we won't be in Ohio until 1am or so. Weeeeak.",
  "id" : 7557267226361856,
  "created_at" : "2010-11-24 22:12:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7553407929815040",
  "geo" : { },
  "id_str" : "7555900113948673",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos just wait until we get to truck world tonight. Been waiting all month for this.",
  "id" : 7555900113948673,
  "in_reply_to_status_id" : 7553407929815040,
  "created_at" : "2010-11-24 22:07:21 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 67, 74 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7550911064838144",
  "text" : "Not even in PA yet...any suggestions for food around Scranton? \/cc @paco36",
  "id" : 7550911064838144,
  "created_at" : "2010-11-24 21:47:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7514862460600320",
  "geo" : { },
  "id_str" : "7515495305580545",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton hahaha, I just have to blame someonw :)",
  "id" : 7515495305580545,
  "in_reply_to_status_id" : 7514862460600320,
  "created_at" : "2010-11-24 19:26:48 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7451427202932737",
  "geo" : { },
  "id_str" : "7452465762926592",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein nothing enforces that format on the language level. i feel that the fundamental problem is that there are no abstractions",
  "id" : 7452465762926592,
  "in_reply_to_status_id" : 7451427202932737,
  "created_at" : "2010-11-24 15:16:20 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7445443214573568",
  "text" : "First IE6 sighting in months. Tempted to help this guy install Chrome.",
  "id" : 7445443214573568,
  "created_at" : "2010-11-24 14:48:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 47, 61 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7441953247461376",
  "geo" : { },
  "id_str" : "7442973444804608",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil see the following tweet. and i blame @joshuaclayton for all of this",
  "id" : 7442973444804608,
  "in_reply_to_status_id" : 7441953247461376,
  "created_at" : "2010-11-24 14:38:37 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7441623617110016",
  "text" : "Even with LESS\/SCSS, CSS still feels like a disorganized pile of crap.",
  "id" : 7441623617110016,
  "created_at" : "2010-11-24 14:33:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7441499461517313",
  "text" : "I have such a hard time with organizing\/structuring CSS. It's going to be a mess no matter what, it's hard to see a point to do it.",
  "id" : 7441499461517313,
  "created_at" : "2010-11-24 14:32:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7438315011710977",
  "text" : "I think everyone in Massachusetts is in this Starbucks.",
  "id" : 7438315011710977,
  "created_at" : "2010-11-24 14:20:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latetotheparty",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7290625376395264",
  "text" : "http:\/\/www.youtube.com\/watch?v=sMZwZiU0kKs has a Dune reference. #latetotheparty",
  "id" : 7290625376395264,
  "created_at" : "2010-11-24 04:33:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Sallings",
      "screen_name" : "dlsspy",
      "indices" : [ 0, 7 ],
      "id_str" : "14117412",
      "id" : 14117412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7286669640204288",
  "geo" : { },
  "id_str" : "7287603141279745",
  "in_reply_to_user_id" : 14117412,
  "text" : "@dlsspy same here dude, grooveshark ftw",
  "id" : 7287603141279745,
  "in_reply_to_status_id" : 7286669640204288,
  "created_at" : "2010-11-24 04:21:14 +0000",
  "in_reply_to_screen_name" : "dlsspy",
  "in_reply_to_user_id_str" : "14117412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7281126494179329",
  "text" : "% cucumber setup.feature ...F---UUUUU",
  "id" : 7281126494179329,
  "created_at" : "2010-11-24 03:55:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7277154458927104",
  "geo" : { },
  "id_str" : "7278714274455553",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer too hard to choose. moving pictures, signals, counterparts, grace under pressure",
  "id" : 7278714274455553,
  "in_reply_to_status_id" : 7277154458927104,
  "created_at" : "2010-11-24 03:45:55 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7094913342636032",
  "geo" : { },
  "id_str" : "7098058529574912",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant i actually had to google that",
  "id" : 7098058529574912,
  "in_reply_to_status_id" : 7094913342636032,
  "created_at" : "2010-11-23 15:48:03 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6955077549953024",
  "text" : "I hate nights like this. Brain firing at 200%, not tired at all, but no sleep = not functioning tomorrow. Bagh.",
  "id" : 6955077549953024,
  "created_at" : "2010-11-23 06:19:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6953925173321728",
  "geo" : { },
  "id_str" : "6954393924538368",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan if you're using bundler, make sure you're on the latest. More speedups to come soon.",
  "id" : 6954393924538368,
  "in_reply_to_status_id" : 6953925173321728,
  "created_at" : "2010-11-23 06:17:11 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Andrew Smith",
      "screen_name" : "fullsailor",
      "indices" : [ 14, 25 ],
      "id_str" : "14310973",
      "id" : 14310973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6946771980783616",
  "geo" : { },
  "id_str" : "6951592385318912",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @fullsailor hey there, what's the problem you're seeing?",
  "id" : 6951592385318912,
  "in_reply_to_status_id" : 6946771980783616,
  "created_at" : "2010-11-23 06:06:03 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6893124601253889",
  "geo" : { },
  "id_str" : "6935839208644609",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash thanks :) it needs some help, I haven't touched it in a while. If you have any questions let me know",
  "id" : 6935839208644609,
  "in_reply_to_status_id" : 6893124601253889,
  "created_at" : "2010-11-23 05:03:27 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6823202659504128",
  "geo" : { },
  "id_str" : "6824163947847680",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham gem install jekyll",
  "id" : 6824163947847680,
  "in_reply_to_status_id" : 6823202659504128,
  "created_at" : "2010-11-22 21:39:42 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6806769594531840",
  "geo" : { },
  "id_str" : "6807383892303872",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza ...for what?",
  "id" : 6807383892303872,
  "in_reply_to_status_id" : 6806769594531840,
  "created_at" : "2010-11-22 20:33:01 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6805418286256128",
  "text" : "Thanks! http:\/\/robots.thoughtbot.com\/post\/1650416831\/giving-thanks",
  "id" : 6805418286256128,
  "created_at" : "2010-11-22 20:25:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 46, 55 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 60, 67 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6750312320737280",
  "geo" : { },
  "id_str" : "6805002815275008",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu lots of local improvements thanks to @indirect and @hone02. Big improvements and the new API coming soon!",
  "id" : 6805002815275008,
  "in_reply_to_status_id" : 6750312320737280,
  "created_at" : "2010-11-22 20:23:33 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6533939145478144",
  "text" : "RT @mperham: Real life Angry Birds sketch: http:\/\/bit.ly\/awXIvE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6532337319804929",
    "text" : "Real life Angry Birds sketch: http:\/\/bit.ly\/awXIvE",
    "id" : 6532337319804929,
    "created_at" : "2010-11-22 02:20:05 +0000",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519271188569128960\/i2t9GfcA_normal.jpeg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 6533939145478144,
  "created_at" : "2010-11-22 02:26:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6515072453058560",
  "text" : "ROFLSCALE http:\/\/www.youtube.com\/watch?v=majbJoD6fzo",
  "id" : 6515072453058560,
  "created_at" : "2010-11-22 01:11:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6460416012062721",
  "geo" : { },
  "id_str" : "6478567005229056",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil sounds like you need some OSS to contribute to",
  "id" : 6478567005229056,
  "in_reply_to_status_id" : 6460416012062721,
  "created_at" : "2010-11-21 22:46:25 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 24, 34 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6394789519953920",
  "geo" : { },
  "id_str" : "6409218999451649",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil stay tuned on @confreaks :)",
  "id" : 6409218999451649,
  "in_reply_to_status_id" : 6394789519953920,
  "created_at" : "2010-11-21 18:10:51 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6013304308760576",
  "text" : "Best game review I've seen in a while. http:\/\/www.youtube.com\/watch?v=VFLU-_lzwBU",
  "id" : 6013304308760576,
  "created_at" : "2010-11-20 15:57:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5878369023426561",
  "text" : "JSON params parsing is hella awesome in Rails 3 for APIs.",
  "id" : 5878369023426561,
  "created_at" : "2010-11-20 07:01:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5823471695175681",
  "geo" : { },
  "id_str" : "5824401719169024",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza SNAPE KILLS DUMBLEDORE",
  "id" : 5824401719169024,
  "in_reply_to_status_id" : 5823471695175681,
  "created_at" : "2010-11-20 03:27:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Wiggins",
      "screen_name" : "hirodusk",
      "indices" : [ 0, 9 ],
      "id_str" : "9341072",
      "id" : 9341072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5728554062974976",
  "geo" : { },
  "id_str" : "5729165605076993",
  "in_reply_to_user_id" : 9341072,
  "text" : "@hirodusk the whole GOROOT and GOOS runaround is such a big barrier to messing around with that language, no idea why they don't remove it",
  "id" : 5729165605076993,
  "in_reply_to_status_id" : 5728554062974976,
  "created_at" : "2010-11-19 21:08:34 +0000",
  "in_reply_to_screen_name" : "hirodusk",
  "in_reply_to_user_id_str" : "9341072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5545197723193344",
  "geo" : { },
  "id_str" : "5610867123027968",
  "in_reply_to_user_id" : 86729866,
  "text" : "@k33l0r wtf? Can you open a request at http:\/\/help.rubygems.org please?",
  "id" : 5610867123027968,
  "in_reply_to_status_id" : 5545197723193344,
  "created_at" : "2010-11-19 13:18:29 +0000",
  "in_reply_to_screen_name" : "matiaskorhonen",
  "in_reply_to_user_id_str" : "86729866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5499959445037056",
  "geo" : { },
  "id_str" : "5510665779290112",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits just installed it, this is awesome",
  "id" : 5510665779290112,
  "in_reply_to_status_id" : 5499959445037056,
  "created_at" : "2010-11-19 06:40:19 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5481439575416832",
  "geo" : { },
  "id_str" : "5508980776370176",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek ended up rewriting, going with daemons + redis-rb + net-http-persistent. Haters gonna hate.",
  "id" : 5508980776370176,
  "in_reply_to_status_id" : 5481439575416832,
  "created_at" : "2010-11-19 06:33:38 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5453639388758016",
  "text" : "I did find http:\/\/b2d-f9r.blogspot.com\/2010\/07\/url-encoding-using-sed.html but GOOD LUCK embedding that in a bash script.",
  "id" : 5453639388758016,
  "created_at" : "2010-11-19 02:53:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5453500926402561",
  "text" : "I give up. Escaping URLs with just sed and bash is a fucking nightmare. Going with Ruby.",
  "id" : 5453500926402561,
  "created_at" : "2010-11-19 02:53:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5426431572058113",
  "text" : "Ok, dealing with the bash script for now...I guess :(",
  "id" : 5426431572058113,
  "created_at" : "2010-11-19 01:05:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5425248103043072",
  "text" : "Argh, but it will set me back so much :(",
  "id" : 5425248103043072,
  "created_at" : "2010-11-19 01:00:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5424997057171456",
  "text" : "Giving up on this bash daemon I'm trying to write, and just going to write Ruby instead. Way easier.",
  "id" : 5424997057171456,
  "created_at" : "2010-11-19 00:59:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5412398961790978",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant let's make some kevlar lined ones and sell them. And tweet at someone else you creep.",
  "id" : 5412398961790978,
  "created_at" : "2010-11-19 00:09:51 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5411644968538112",
  "text" : "Like usual, I manage to wreck every pair of earbuds I've ever owned. Getting static from these new ones and it's only been 2 weeks. :(",
  "id" : 5411644968538112,
  "created_at" : "2010-11-19 00:06:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 12, 24 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5365415978995712",
  "geo" : { },
  "id_str" : "5370377190510592",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape @tristandunn http:\/\/img.skitch.com\/20101118-ji9i3pnts7718rn9sidapnq4gp.png",
  "id" : 5370377190510592,
  "in_reply_to_status_id" : 5365415978995712,
  "created_at" : "2010-11-18 21:22:52 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Fedor",
      "screen_name" : "jfedor",
      "indices" : [ 3, 10 ],
      "id_str" : "9135722",
      "id" : 9135722
    }, {
      "name" : "Geeks With Balls",
      "screen_name" : "geekswithballs",
      "indices" : [ 34, 49 ],
      "id_str" : "199074313",
      "id" : 199074313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5320251919048704",
  "text" : "RT @jfedor: Quick Movember links: @geekswithballs: http:\/\/bit.ly\/94R8TC & to make a fast simple donation to our team and our cause: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geeks With Balls",
        "screen_name" : "geekswithballs",
        "indices" : [ 22, 37 ],
        "id_str" : "199074313",
        "id" : 199074313
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5238025332203520",
    "text" : "Quick Movember links: @geekswithballs: http:\/\/bit.ly\/94R8TC & to make a fast simple donation to our team and our cause: http:\/\/bit.ly\/9TYmMu",
    "id" : 5238025332203520,
    "created_at" : "2010-11-18 12:36:57 +0000",
    "user" : {
      "name" : "Jeff Fedor",
      "screen_name" : "jfedor",
      "protected" : false,
      "id_str" : "9135722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571773698589519872\/591LeA0W_normal.jpeg",
      "id" : 9135722,
      "verified" : false
    }
  },
  "id" : 5320251919048704,
  "created_at" : "2010-11-18 18:03:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5125703133569024",
  "text" : "They say if you're not embarrassed, you waited too long to launch. Soon I'll be finding out exactly how bad that can get.",
  "id" : 5125703133569024,
  "created_at" : "2010-11-18 05:10:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake Mizerany",
      "screen_name" : "bmizerany",
      "indices" : [ 0, 10 ],
      "id_str" : "2379441",
      "id" : 2379441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5057288880529408",
  "geo" : { },
  "id_str" : "5081552107077632",
  "in_reply_to_user_id" : 2379441,
  "text" : "@bmizerany seriously dude, I have a hankering for Go as well. Need to dream up some to write in it first.",
  "id" : 5081552107077632,
  "in_reply_to_status_id" : 5057288880529408,
  "created_at" : "2010-11-18 02:15:11 +0000",
  "in_reply_to_screen_name" : "bmizerany",
  "in_reply_to_user_id_str" : "2379441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5007617348861952",
  "text" : "Current status: http:\/\/slightlywarped.com\/crapfactory\/curiosities\/2010\/images\/rare_s110.jpg",
  "id" : 5007617348861952,
  "created_at" : "2010-11-17 21:21:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 66, 74 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 111, 122 ],
      "id_str" : "9238852",
      "id" : 9238852
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 123, 136 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4764036788912128",
  "text" : "http:\/\/bit.ly\/dggYoN is why you use underscores in gem names (via @drbrain) &lt; can we yank the .net gems yet @drusellers @ferventcoder ?",
  "id" : 4764036788912128,
  "created_at" : "2010-11-17 05:13:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4743308676960256",
  "text" : "Ending up writing my own jquery draggable collide extension since the only available one sucks. Strangely satisfying.",
  "id" : 4743308676960256,
  "created_at" : "2010-11-17 03:51:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4649577076490241",
  "geo" : { },
  "id_str" : "4651910502027264",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh aahhahahhahahaa",
  "id" : 4651910502027264,
  "in_reply_to_status_id" : 4649577076490241,
  "created_at" : "2010-11-16 21:47:56 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASSR FC 55",
      "screen_name" : "TNM8",
      "indices" : [ 0, 5 ],
      "id_str" : "1448473316",
      "id" : 1448473316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4597341529051136",
  "geo" : { },
  "id_str" : "4597653069373440",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm8 :( we need to start having these in boston",
  "id" : 4597653069373440,
  "in_reply_to_status_id" : 4597341529051136,
  "created_at" : "2010-11-16 18:12:20 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 0, 12 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4592391193362433",
  "geo" : { },
  "id_str" : "4593942444113921",
  "in_reply_to_user_id" : 6556972,
  "text" : "@techpickles nyoooooo",
  "id" : 4593942444113921,
  "in_reply_to_status_id" : 4592391193362433,
  "created_at" : "2010-11-16 17:57:35 +0000",
  "in_reply_to_screen_name" : "techpickles",
  "in_reply_to_user_id_str" : "6556972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 3, 13 ],
      "id_str" : "10453902",
      "id" : 10453902
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 98, 105 ],
      "id_str" : "10257182",
      "id" : 10257182
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 107, 118 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "Rails Machine",
      "screen_name" : "railsmachine",
      "indices" : [ 120, 133 ],
      "id_str" : "12026592",
      "id" : 12026592
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 139, 140 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4391724239556608",
  "text" : "RT @jbarnette: Time for a RubyGems prerelease testing cabal. RG releases pain you? Ping me. (poke @heroku, @engineyard, @railsmachine, @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heroku",
        "screen_name" : "heroku",
        "indices" : [ 83, 90 ],
        "id_str" : "10257182",
        "id" : 10257182
      }, {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 92, 103 ],
        "id_str" : "7255652",
        "id" : 7255652
      }, {
        "name" : "Rails Machine",
        "screen_name" : "railsmachine",
        "indices" : [ 105, 118 ],
        "id_str" : "12026592",
        "id" : 12026592
      }, {
        "name" : "wayneeseguin",
        "screen_name" : "wayneeseguin",
        "indices" : [ 120, 133 ],
        "id_str" : "11587602",
        "id" : 11587602
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4326505517682688",
    "text" : "Time for a RubyGems prerelease testing cabal. RG releases pain you? Ping me. (poke @heroku, @engineyard, @railsmachine, @wayneeseguin, etc.)",
    "id" : 4326505517682688,
    "created_at" : "2010-11-16 00:14:53 +0000",
    "user" : {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "protected" : false,
      "id_str" : "10453902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482193494002642944\/J3ZE2OBm_normal.jpeg",
      "id" : 10453902,
      "verified" : false
    }
  },
  "id" : 4391724239556608,
  "created_at" : "2010-11-16 04:34:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4342683585744896",
  "geo" : { },
  "id_str" : "4346095178092544",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic https:\/\/github.com\/qrush\/gemwhisperer\/blob\/master\/gemwhisperer.rb#L46-50",
  "id" : 4346095178092544,
  "in_reply_to_status_id" : 4342683585744896,
  "created_at" : "2010-11-16 01:32:44 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 0, 5 ],
      "id_str" : "15591045",
      "id" : 15591045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3916995615526913",
  "geo" : { },
  "id_str" : "3941861416767488",
  "in_reply_to_user_id" : 15591045,
  "text" : "@tmm1 MMMMMMULTICOMMIT",
  "id" : 3941861416767488,
  "in_reply_to_status_id" : 3916995615526913,
  "created_at" : "2010-11-14 22:46:27 +0000",
  "in_reply_to_screen_name" : "tmm1",
  "in_reply_to_user_id_str" : "15591045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3831493197570048",
  "text" : "No ball fondling so far at MSY.",
  "id" : 3831493197570048,
  "created_at" : "2010-11-14 15:27:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "curtHendzell",
      "screen_name" : "curtHendzell",
      "indices" : [ 0, 13 ],
      "id_str" : "14120475",
      "id" : 14120475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3814421864386560",
  "geo" : { },
  "id_str" : "3814754929868802",
  "in_reply_to_user_id" : 14120475,
  "text" : "@curtHendzell just tried. 'Not in my area'",
  "id" : 3814754929868802,
  "in_reply_to_status_id" : 3814421864386560,
  "created_at" : "2010-11-14 14:21:23 +0000",
  "in_reply_to_screen_name" : "curtHendzell",
  "in_reply_to_user_id_str" : "14120475",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "curtHendzell",
      "screen_name" : "curtHendzell",
      "indices" : [ 0, 13 ],
      "id_str" : "14120475",
      "id" : 14120475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3812391024336896",
  "geo" : { },
  "id_str" : "3813456205578240",
  "in_reply_to_user_id" : 14120475,
  "text" : "@curtHendzell thanks, I just can't remember my voicemail pin. Since google voice came out I haven't looked at it",
  "id" : 3813456205578240,
  "in_reply_to_status_id" : 3812391024336896,
  "created_at" : "2010-11-14 14:16:13 +0000",
  "in_reply_to_screen_name" : "curtHendzell",
  "in_reply_to_user_id_str" : "14120475",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3811392855474176",
  "text" : "Voicemail indicator on my Droid won't go away...and I have Google Voice hooked up. Any ideas?",
  "id" : 3811392855474176,
  "created_at" : "2010-11-14 14:08:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Hellberg",
      "screen_name" : "peterhellberg",
      "indices" : [ 3, 17 ],
      "id_str" : "12362552",
      "id" : 12362552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3795807518064640",
  "text" : "RT @peterhellberg: Page not found. It will be mine. Oh yes. It will be mine. #rubygems",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubygems",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "3792792799154176",
    "text" : "Page not found. It will be mine. Oh yes. It will be mine. #rubygems",
    "id" : 3792792799154176,
    "created_at" : "2010-11-14 12:54:06 +0000",
    "user" : {
      "name" : "Peter Hellberg",
      "screen_name" : "peterhellberg",
      "protected" : false,
      "id_str" : "12362552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464500238175064064\/BC_l7Wck_normal.png",
      "id" : 12362552,
      "verified" : false
    }
  },
  "id" : 3795807518064640,
  "created_at" : "2010-11-14 13:06:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "indices" : [ 0, 9 ],
      "id_str" : "6141442",
      "id" : 6141442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3580443349745664",
  "geo" : { },
  "id_str" : "3580859273707520",
  "in_reply_to_user_id" : 6141442,
  "text" : "@rsanheim \"Wow, why is this app still installed on my phone?\"",
  "id" : 3580859273707520,
  "in_reply_to_status_id" : 3580443349745664,
  "created_at" : "2010-11-13 22:51:58 +0000",
  "in_reply_to_screen_name" : "rsanheim",
  "in_reply_to_user_id_str" : "6141442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haris Amin",
      "screen_name" : "harisamin",
      "indices" : [ 0, 10 ],
      "id_str" : "111644108",
      "id" : 111644108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3537245017477121",
  "geo" : { },
  "id_str" : "3559479970889728",
  "in_reply_to_user_id" : 111644108,
  "text" : "@harisamin woot!",
  "id" : 3559479970889728,
  "in_reply_to_status_id" : 3537245017477121,
  "created_at" : "2010-11-13 21:27:00 +0000",
  "in_reply_to_screen_name" : "harisamin",
  "in_reply_to_user_id_str" : "111644108",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "irony",
      "indices" : [ 49, 55 ]
    }, {
      "text" : "owthelasthourmylifewasted",
      "indices" : [ 56, 82 ]
    }, {
      "text" : "rubyconf",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3559209983549440",
  "text" : "Found a capybara bug while in the capybara talk. #irony #owthelasthourmylifewasted #rubyconf",
  "id" : 3559209983549440,
  "created_at" : "2010-11-13 21:25:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hinegardner",
      "screen_name" : "copiousfreetime",
      "indices" : [ 3, 19 ],
      "id_str" : "14601522",
      "id" : 14601522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3559004777218049",
  "text" : "RT @copiousfreetime: My Gemology slides are up #rubyconf http:\/\/www.slideshare.net\/copiousfreetime\/gemology",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 26, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "3549769741901824",
    "text" : "My Gemology slides are up #rubyconf http:\/\/www.slideshare.net\/copiousfreetime\/gemology",
    "id" : 3549769741901824,
    "created_at" : "2010-11-13 20:48:25 +0000",
    "user" : {
      "name" : "Jeremy Hinegardner",
      "screen_name" : "copiousfreetime",
      "protected" : false,
      "id_str" : "14601522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453235782140968960\/UT2bf2xo_normal.jpeg",
      "id" : 14601522,
      "verified" : false
    }
  },
  "id" : 3559004777218049,
  "created_at" : "2010-11-13 21:25:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3515091290947585",
  "geo" : { },
  "id_str" : "3521615849590784",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant tomorrow!",
  "id" : 3521615849590784,
  "in_reply_to_status_id" : 3515091290947585,
  "created_at" : "2010-11-13 18:56:33 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thejish",
      "screen_name" : "thejish",
      "indices" : [ 0, 8 ],
      "id_str" : "14464569",
      "id" : 14464569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3497895865094144",
  "geo" : { },
  "id_str" : "3513359018229760",
  "in_reply_to_user_id" : 14464569,
  "text" : "@thejish congrats!",
  "id" : 3513359018229760,
  "in_reply_to_status_id" : 3497895865094144,
  "created_at" : "2010-11-13 18:23:44 +0000",
  "in_reply_to_screen_name" : "thejish",
  "in_reply_to_user_id_str" : "14464569",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Lupi\u00F3n",
      "screen_name" : "pantulis",
      "indices" : [ 0, 9 ],
      "id_str" : "62703",
      "id" : 62703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3511404770365440",
  "geo" : { },
  "id_str" : "3513316928397312",
  "in_reply_to_user_id" : 62703,
  "text" : "@pantulis those point to the same place!",
  "id" : 3513316928397312,
  "in_reply_to_status_id" : 3511404770365440,
  "created_at" : "2010-11-13 18:23:34 +0000",
  "in_reply_to_screen_name" : "pantulis",
  "in_reply_to_user_id_str" : "62703",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sytycc",
      "screen_name" : "sytycc",
      "indices" : [ 0, 7 ],
      "id_str" : "215092649",
      "id" : 215092649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3511406800412672",
  "in_reply_to_user_id" : 215092649,
  "text" : "@sytycc CAN I HAS LUNCHTIMEZ?",
  "id" : 3511406800412672,
  "created_at" : "2010-11-13 18:15:59 +0000",
  "in_reply_to_screen_name" : "sytycc",
  "in_reply_to_user_id_str" : "215092649",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3491592992194560",
  "text" : "HAHA DISREGARD THAT I SUCK AT HTTP HEADERS",
  "id" : 3491592992194560,
  "created_at" : "2010-11-13 16:57:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3490051132493824",
  "text" : "Anyone with commit rights to rack-test at #rubyconf? Sick of some bugs.",
  "id" : 3490051132493824,
  "created_at" : "2010-11-13 16:51:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geeks With Balls",
      "screen_name" : "geekswithballs",
      "indices" : [ 77, 92 ],
      "id_str" : "199074313",
      "id" : 199074313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3470251698159616",
  "text" : "Prostate cancer: #1 most commonly diagnosed one for men in the US. Donate to @geekswithballs and make a difference! http:\/\/yfrog.com\/85rf9xj",
  "id" : 3470251698159616,
  "created_at" : "2010-11-13 15:32:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3459795092774912",
  "text" : "When you need to tell your computer to SLOOOOOOW DOWN http:\/\/bit.ly\/bdSRkk ENERGY",
  "id" : 3459795092774912,
  "created_at" : "2010-11-13 14:50:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3456357923553280",
  "text" : "Thanks for the birthday wishes, folks. Too tired to come up with a cute Ruby syntax for this.",
  "id" : 3456357923553280,
  "created_at" : "2010-11-13 14:37:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shugo Maeda",
      "screen_name" : "shugomaeda",
      "indices" : [ 0, 11 ],
      "id_str" : "6435642",
      "id" : 6435642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3452447511027712",
  "geo" : { },
  "id_str" : "3455099028381697",
  "in_reply_to_user_id" : 6435642,
  "text" : "@shugomaeda I definitely missed that reference :(",
  "id" : 3455099028381697,
  "in_reply_to_status_id" : 3452447511027712,
  "created_at" : "2010-11-13 14:32:14 +0000",
  "in_reply_to_screen_name" : "shugomaeda",
  "in_reply_to_user_id_str" : "6435642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David A. Black",
      "screen_name" : "david_a_black",
      "indices" : [ 0, 14 ],
      "id_str" : "9929452",
      "id" : 9929452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3426596094480385",
  "geo" : { },
  "id_str" : "3454928815136769",
  "in_reply_to_user_id" : 9929452,
  "text" : "@david_a_black just go for akephalos. Envjs hacks are not worth it.",
  "id" : 3454928815136769,
  "in_reply_to_status_id" : 3426596094480385,
  "created_at" : "2010-11-13 14:31:33 +0000",
  "in_reply_to_screen_name" : "david_a_black",
  "in_reply_to_user_id_str" : "9929452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3314845051002880",
  "text" : "Nick.born_at = 23.years.ago",
  "id" : 3314845051002880,
  "created_at" : "2010-11-13 05:14:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3247101693657088",
  "text" : "RT @drbrain: You can the slides for my talks \u201CHistory of RubyGems and RDoc\u201D and \u201CHow to Name Gems\u201D at http:\/\/segment7.net\/projects\/ruby\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "3234489299894272",
    "text" : "You can the slides for my talks \u201CHistory of RubyGems and RDoc\u201D and \u201CHow to Name Gems\u201D at http:\/\/segment7.net\/projects\/ruby\/RubyConf\/2010\/",
    "id" : 3234489299894272,
    "created_at" : "2010-11-12 23:55:36 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 3247101693657088,
  "created_at" : "2010-11-13 00:45:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zedconf",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3243093365100545",
  "text" : "3 for 3! #zedconf",
  "id" : 3243093365100545,
  "created_at" : "2010-11-13 00:29:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3200811257565184",
  "text" : "Module#refine looks like a great step in the right direction for sane monkeypatching. #rubyconf",
  "id" : 3200811257565184,
  "created_at" : "2010-11-12 21:41:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 18, 28 ],
      "id_str" : "15001533",
      "id" : 15001533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3169972289282048",
  "geo" : { },
  "id_str" : "3197871285338113",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase  @mikeburns got it, thanks!!!!",
  "id" : 3197871285338113,
  "in_reply_to_status_id" : 3169972289282048,
  "created_at" : "2010-11-12 21:30:06 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 11, 17 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 18, 26 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3123048043511808",
  "geo" : { },
  "id_str" : "3136384382537728",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette @raggi @drbrain how about 12:30ish in the main keynote room?",
  "id" : 3136384382537728,
  "in_reply_to_status_id" : 3123048043511808,
  "created_at" : "2010-11-12 17:25:46 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 12, 20 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3110889288892416",
  "text" : "Mentions of @zedshaw in #rubyconf keynotes: 2 for 2!",
  "id" : 3110889288892416,
  "created_at" : "2010-11-12 15:44:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caius Durling",
      "screen_name" : "Caius",
      "indices" : [ 0, 6 ],
      "id_str" : "5857812",
      "id" : 5857812
    }, {
      "name" : "hone",
      "screen_name" : "hone",
      "indices" : [ 17, 22 ],
      "id_str" : "6637242",
      "id" : 6637242
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 27, 36 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3098754827681792",
  "geo" : { },
  "id_str" : "3102942378852352",
  "in_reply_to_user_id" : 5857812,
  "text" : "@caius actually, @hone and @indirect have been working on that here at #rubyconf. hold on tight!",
  "id" : 3102942378852352,
  "in_reply_to_status_id" : 3098754827681792,
  "created_at" : "2010-11-12 15:12:53 +0000",
  "in_reply_to_screen_name" : "Caius",
  "in_reply_to_user_id_str" : "5857812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john crepezzi!",
      "screen_name" : "seejohnrun",
      "indices" : [ 3, 14 ],
      "id_str" : "12332042",
      "id" : 12332042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "rubygems",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2882773618532352",
  "text" : "RT @seejohnrun: New blog post on #rubyconf and #rubygems - http:\/\/blog.johncrepezzi.com\/2010\/11\/rubyconf-rubygems\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 17, 26 ]
      }, {
        "text" : "rubygems",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "2879919944110080",
    "text" : "New blog post on #rubyconf and #rubygems - http:\/\/blog.johncrepezzi.com\/2010\/11\/rubyconf-rubygems\/",
    "id" : 2879919944110080,
    "created_at" : "2010-11-12 00:26:41 +0000",
    "user" : {
      "name" : "john crepezzi!",
      "screen_name" : "seejohnrun",
      "protected" : false,
      "id_str" : "12332042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2994996055\/260a9578ac12c79c4613e4279ed72959_normal.png",
      "id" : 12332042,
      "verified" : false
    }
  },
  "id" : 2882773618532352,
  "created_at" : "2010-11-12 00:38:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2816073808220160",
  "geo" : { },
  "id_str" : "2819222350598145",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton same goes for AR (I think)",
  "id" : 2819222350598145,
  "in_reply_to_status_id" : 2816073808220160,
  "created_at" : "2010-11-11 20:25:29 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 3, 13 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2806056753303552",
  "text" : "RT @igrigorik: 34,033 gems published in first 5 years of rubygems.. 52,466 gems in past year! gemcutter switchover ftw! #rubyconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "2805884858138624",
    "text" : "34,033 gems published in first 5 years of rubygems.. 52,466 gems in past year! gemcutter switchover ftw! #rubyconf",
    "id" : 2805884858138624,
    "created_at" : "2010-11-11 19:32:29 +0000",
    "user" : {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "protected" : false,
      "id_str" : "9980812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458689841186611200\/SMmZLt2Y_normal.jpeg",
      "id" : 9980812,
      "verified" : false
    }
  },
  "id" : 2806056753303552,
  "created_at" : "2010-11-11 19:33:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 25, 31 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2761576536866816",
  "geo" : { },
  "id_str" : "2762564245131264",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i in the back where @drnic just discovered the 'yes' command #rubyconf",
  "id" : 2762564245131264,
  "in_reply_to_status_id" : 2761576536866816,
  "created_at" : "2010-11-11 16:40:21 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2741615512788993",
  "text" : "LET'S GET READY TO RUUUUUUUUUUUUUUUUBYCONF",
  "id" : 2741615512788993,
  "created_at" : "2010-11-11 15:17:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 40, 48 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2740937939746816",
  "geo" : { },
  "id_str" : "2741508776140800",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i 1.4 release, etc. Let's see what @drbrain is going to cover first :)",
  "id" : 2741508776140800,
  "in_reply_to_status_id" : 2740937939746816,
  "created_at" : "2010-11-11 15:16:41 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2726309448908800",
  "geo" : { },
  "id_str" : "2741350374047744",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant yep! It's ridiculously warm out for november.",
  "id" : 2741350374047744,
  "in_reply_to_status_id" : 2726309448908800,
  "created_at" : "2010-11-11 15:16:03 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2621469037174784",
  "geo" : { },
  "id_str" : "2712989404762112",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i no plans, I just want to get folks together... didn't hear much from the ML :(",
  "id" : 2712989404762112,
  "in_reply_to_status_id" : 2621469037174784,
  "created_at" : "2010-11-11 13:23:21 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2596244513890304",
  "geo" : { },
  "id_str" : "2710974633082880",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier hell yes! But get it off amazon, its cheaper there",
  "id" : 2710974633082880,
  "in_reply_to_status_id" : 2596244513890304,
  "created_at" : "2010-11-11 13:15:21 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2553153060872192",
  "text" : "Ahem, Crescent City Brewhouse.",
  "id" : 2553153060872192,
  "created_at" : "2010-11-11 02:48:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2552481926094848",
  "text" : "Starting at Crescent City Brewery. Anyone else thirsty before #rubyconf?",
  "id" : 2552481926094848,
  "created_at" : "2010-11-11 02:45:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2546364076527617",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant dude!! Why aren't you @turbage?",
  "id" : 2546364076527617,
  "created_at" : "2010-11-11 02:21:15 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 3, 10 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2494533581406208",
  "text" : "RT @Croaky: thoughtbot's arrived in NOLA for #rubyconf. we're staying at the embassy suites. anyone else nearby?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 33, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 29.9451404035, -90.0656352982 ]
    },
    "id_str" : "2493990851055616",
    "text" : "thoughtbot's arrived in NOLA for #rubyconf. we're staying at the embassy suites. anyone else nearby?",
    "id" : 2493990851055616,
    "created_at" : "2010-11-10 22:53:08 +0000",
    "user" : {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "protected" : false,
      "id_str" : "787595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568676101967196160\/nP3jFRbr_normal.jpeg",
      "id" : 787595,
      "verified" : false
    }
  },
  "id" : 2494533581406208,
  "created_at" : "2010-11-10 22:55:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federico Soria",
      "screen_name" : "fedesoria",
      "indices" : [ 0, 10 ],
      "id_str" : "14990484",
      "id" : 14990484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2492733973340160",
  "in_reply_to_user_id" : 14990484,
  "text" : "@fedesoria hey dude! Not sure yet. Will post about it.",
  "id" : 2492733973340160,
  "created_at" : "2010-11-10 22:48:08 +0000",
  "in_reply_to_screen_name" : "fedesoria",
  "in_reply_to_user_id_str" : "14990484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2456750779273217",
  "geo" : { },
  "id_str" : "2473499574673408",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler I blame my italian ancestors",
  "id" : 2473499574673408,
  "in_reply_to_status_id" : 2456750779273217,
  "created_at" : "2010-11-10 21:31:42 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2473431878606848",
  "text" : "NAWLINS! #rubyconf",
  "id" : 2473431878606848,
  "created_at" : "2010-11-10 21:31:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2447877204877312",
  "text" : "Anyone else in Houston waiting for a flight to #rubyconf?",
  "id" : 2447877204877312,
  "created_at" : "2010-11-10 19:49:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2367304700530688",
  "text" : "1.8.7: DateTime.parse(\"10\/16\/2010\") gives Oct 16. 1.9.2: ArgumentError.",
  "id" : 2367304700530688,
  "created_at" : "2010-11-10 14:29:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geeks With Balls",
      "screen_name" : "geekswithballs",
      "indices" : [ 49, 64 ],
      "id_str" : "199074313",
      "id" : 199074313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "movember",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2198866480865280",
  "text" : "Finally have something to show for #movember. Go @geekswithballs!",
  "id" : 2198866480865280,
  "created_at" : "2010-11-10 03:20:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2138431358509056",
  "geo" : { },
  "id_str" : "2147000963309568",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella http:\/\/rubygems.org\/opensearch.xml",
  "id" : 2147000963309568,
  "in_reply_to_status_id" : 2138431358509056,
  "created_at" : "2010-11-09 23:54:19 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2127354214227968",
  "geo" : { },
  "id_str" : "2136841180413952",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius even better: in chrome, url bar: rubygems.org &lt;tab&gt; your search",
  "id" : 2136841180413952,
  "in_reply_to_status_id" : 2127354214227968,
  "created_at" : "2010-11-09 23:13:57 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2121087722721280",
  "geo" : { },
  "id_str" : "2128239166234625",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey nokogiri, dude",
  "id" : 2128239166234625,
  "in_reply_to_status_id" : 2121087722721280,
  "created_at" : "2010-11-09 22:39:46 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    }, {
      "name" : "Craig Martek",
      "screen_name" : "cregatron",
      "indices" : [ 10, 20 ],
      "id_str" : "16892522",
      "id" : 16892522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2068212053180416",
  "geo" : { },
  "id_str" : "2069909701918720",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold @cregatron yeah because greasy, slimy, disgusting food isn't anywhere elOH WAIT",
  "id" : 2069909701918720,
  "in_reply_to_status_id" : 2068212053180416,
  "created_at" : "2010-11-09 18:47:59 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 40, 54 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2063060877451264",
  "geo" : { },
  "id_str" : "2063691289731073",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh use your console like a man. @joshuaclayton figured out how to make tmux\/vim's colors play nicely...he should write a blog post",
  "id" : 2063691289731073,
  "in_reply_to_status_id" : 2063060877451264,
  "created_at" : "2010-11-09 18:23:17 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2061658599985152",
  "geo" : { },
  "id_str" : "2061970836553728",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh WEAK. no seriously, why not?",
  "id" : 2061970836553728,
  "in_reply_to_status_id" : 2061658599985152,
  "created_at" : "2010-11-09 18:16:26 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2059933847658497",
  "geo" : { },
  "id_str" : "2060991537881090",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh just use console vim?",
  "id" : 2060991537881090,
  "in_reply_to_status_id" : 2059933847658497,
  "created_at" : "2010-11-09 18:12:33 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppSumo.com",
      "screen_name" : "AppSumo",
      "indices" : [ 66, 74 ],
      "id_str" : "132021364",
      "id" : 132021364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2004573698916352",
  "text" : "Check it OUT! The Bad Ass Developer Bundle http:\/\/appsumo.com via @appsumo",
  "id" : 2004573698916352,
  "created_at" : "2010-11-09 14:28:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1991532064280576",
  "geo" : { },
  "id_str" : "1994795073404928",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams going to be taking the train more often before 9 then...it was always packed with 2 cars.  Yay boston!",
  "id" : 1994795073404928,
  "in_reply_to_status_id" : 1991532064280576,
  "created_at" : "2010-11-09 13:49:30 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1990346389069824",
  "text" : "3 car green line train...this is a first",
  "id" : 1990346389069824,
  "created_at" : "2010-11-09 13:31:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1860171580051456",
  "text" : "Spent 20 minutes sketching in android's MaplePaint. Saved, reopened...totally corrupted. :(",
  "id" : 1860171580051456,
  "created_at" : "2010-11-09 04:54:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1825183610437632",
  "text" : "THE ONLY GOOD BUG IS A DEAD BUG!",
  "id" : 1825183610437632,
  "created_at" : "2010-11-09 02:35:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1779173785862144",
  "text" : "NEWSFLASH: Not coding at 2am yields better results.",
  "id" : 1779173785862144,
  "created_at" : "2010-11-08 23:32:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 0, 14 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1569663465029632",
  "geo" : { },
  "id_str" : "1750617030656000",
  "in_reply_to_user_id" : 8284992,
  "text" : "@jkreeftmeijer i actually prefer the URL version. takes some of the magic away",
  "id" : 1750617030656000,
  "in_reply_to_status_id" : 1569663465029632,
  "created_at" : "2010-11-08 21:39:14 +0000",
  "in_reply_to_screen_name" : "jkreeftmeijer",
  "in_reply_to_user_id_str" : "8284992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1749838039359488",
  "text" : "STAY IN SCHOOl, GI JOOOOOOE http:\/\/robots.thoughtbot.com\/post\/1518329995\/ask-thoughtbot-college-degrees",
  "id" : 1749838039359488,
  "created_at" : "2010-11-08 21:36:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 0, 12 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1710895369555968",
  "geo" : { },
  "id_str" : "1711906163261441",
  "in_reply_to_user_id" : 6556972,
  "text" : "@techpickles BROSELECT *",
  "id" : 1711906163261441,
  "in_reply_to_status_id" : 1710895369555968,
  "created_at" : "2010-11-08 19:05:24 +0000",
  "in_reply_to_screen_name" : "techpickles",
  "in_reply_to_user_id_str" : "6556972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Richards",
      "screen_name" : "noahsmark",
      "indices" : [ 0, 10 ],
      "id_str" : "14198565",
      "id" : 14198565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1706650901676033",
  "geo" : { },
  "id_str" : "1706912282320897",
  "in_reply_to_user_id" : 14198565,
  "text" : "@noahsmark It Bothers Me Immensely",
  "id" : 1706912282320897,
  "in_reply_to_status_id" : 1706650901676033,
  "created_at" : "2010-11-08 18:45:34 +0000",
  "in_reply_to_screen_name" : "noahsmark",
  "in_reply_to_user_id_str" : "14198565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1695647065440256",
  "geo" : { },
  "id_str" : "1696826470174720",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist geez, yeah :( patches welcome!",
  "id" : 1696826470174720,
  "in_reply_to_status_id" : 1695647065440256,
  "created_at" : "2010-11-08 18:05:29 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1684904077168640",
  "geo" : { },
  "id_str" : "1694375763509249",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich they're at the top nearly every day",
  "id" : 1694375763509249,
  "in_reply_to_status_id" : 1684904077168640,
  "created_at" : "2010-11-08 17:55:45 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1448694977134592",
  "text" : "ActiveSupport::Gzip.decompress. NICE. http:\/\/api.rubyonrails.org\/classes\/ActiveSupport\/Gzip.html",
  "id" : 1448694977134592,
  "created_at" : "2010-11-08 01:39:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1426517116592129",
  "geo" : { },
  "id_str" : "1427648404258816",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit you MURDERED THOSE SHIRTS!!11",
  "id" : 1427648404258816,
  "in_reply_to_status_id" : 1426517116592129,
  "created_at" : "2010-11-08 00:15:52 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1381112513298432",
  "text" : "rm -rf spec\/controllers",
  "id" : 1381112513298432,
  "created_at" : "2010-11-07 21:10:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Zygmuntowicz",
      "screen_name" : "ezmobius",
      "indices" : [ 0, 9 ],
      "id_str" : "3560241",
      "id" : 3560241
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 44, 54 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367731509141504",
  "geo" : { },
  "id_str" : "1369653876105216",
  "in_reply_to_user_id" : 3560241,
  "text" : "@ezmobius let me know if you want to set up @gemcutter :)",
  "id" : 1369653876105216,
  "in_reply_to_status_id" : 1367731509141504,
  "created_at" : "2010-11-07 20:25:25 +0000",
  "in_reply_to_screen_name" : "ezmobius",
  "in_reply_to_user_id_str" : "3560241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1045774834077696",
  "text" : "And one of my favorite hark a vagrant comics. SHOO! http:\/\/yfrog.com\/fkrl4j",
  "id" : 1045774834077696,
  "created_at" : "2010-11-06 22:58:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Frost",
      "screen_name" : "jephjacques",
      "indices" : [ 32, 44 ],
      "id_str" : "7670202",
      "id" : 7670202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1045630805876737",
  "text" : "Sweet QC character montage from @jephjacques: http:\/\/yfrog.com\/47up4mj",
  "id" : 1045630805876737,
  "created_at" : "2010-11-06 22:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1045394716889088",
  "text" : "Awesome Mario print picked up. http:\/\/yfrog.com\/0jcfvvj",
  "id" : 1045394716889088,
  "created_at" : "2010-11-06 22:56:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NEWW",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1041840102965248",
  "text" : "Some of @ablissfulgal's #NEWW loot: http:\/\/plixi.com\/p\/55404373",
  "id" : 1041840102965248,
  "created_at" : "2010-11-06 22:42:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timo Zimmermann",
      "screen_name" : "fallenhitokiri",
      "indices" : [ 0, 15 ],
      "id_str" : "9351452",
      "id" : 9351452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1030052229681152",
  "geo" : { },
  "id_str" : "1030598059630592",
  "in_reply_to_user_id" : 9351452,
  "text" : "@fallenhitokiri dude, use http:\/\/rubyinstaller.org",
  "id" : 1030598059630592,
  "in_reply_to_status_id" : 1030052229681152,
  "created_at" : "2010-11-06 21:58:08 +0000",
  "in_reply_to_screen_name" : "fallenhitokiri",
  "in_reply_to_user_id_str" : "9351452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Count Cash",
      "screen_name" : "choadmalma",
      "indices" : [ 0, 11 ],
      "id_str" : "2506698690",
      "id" : 2506698690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1007100410994688",
  "geo" : { },
  "id_str" : "1029501580484609",
  "in_reply_to_user_id" : 16522244,
  "text" : "@choadmalma haha, no worries. just don't forget about the tshirt idea dude!",
  "id" : 1029501580484609,
  "in_reply_to_status_id" : 1007100410994688,
  "created_at" : "2010-11-06 21:53:46 +0000",
  "in_reply_to_screen_name" : "kcgreenn",
  "in_reply_to_user_id_str" : "16522244",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NEWW",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "981848113020929",
  "text" : "#NEWW haul: 3 posters, 3 books, 1 bag. Got to say thanks to a lot of artists that have me laugh over the years.",
  "id" : 981848113020929,
  "created_at" : "2010-11-06 18:44:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NEWW",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936848448815107",
  "text" : "On the road to #NEWW. Kind of scared.",
  "id" : 936848448815107,
  "created_at" : "2010-11-06 15:45:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaTIAS eL HuMiLDE;)",
      "screen_name" : "rubycentral",
      "indices" : [ 26, 38 ],
      "id_str" : "256225697",
      "id" : 256225697
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 68, 78 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781580188516352",
  "text" : "Starting discussions with @rubycentral about how we can improve the @gemcutter \/ rubygems.org situation. Late nights and SPOF's FTL. :(",
  "id" : 781580188516352,
  "created_at" : "2010-11-06 05:28:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grig Gheorghiu",
      "screen_name" : "griggheo",
      "indices" : [ 0, 9 ],
      "id_str" : "105218320",
      "id" : 105218320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774923307982848",
  "geo" : { },
  "id_str" : "775354390159360",
  "in_reply_to_user_id" : 105218320,
  "text" : "@griggheo not at all, apache was having trouble on our end.",
  "id" : 775354390159360,
  "in_reply_to_status_id" : 774923307982848,
  "created_at" : "2010-11-06 05:03:53 +0000",
  "in_reply_to_screen_name" : "griggheo",
  "in_reply_to_user_id_str" : "105218320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 11, 21 ],
      "id_str" : "15031577",
      "id" : 15031577
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769108920500224",
  "text" : "Can't find @tcopeland, if anyone can help debug whats wrong with rubygems.org with sysadmin stuff (on RHEL) please hop on #gemcutter",
  "id" : 769108920500224,
  "created_at" : "2010-11-06 04:39:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 48, 58 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766463979823104",
  "text" : "Looks like newrelic going down has brought down @gemcutter. Trying to resolve.",
  "id" : 766463979823104,
  "created_at" : "2010-11-06 04:28:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Anderson",
      "screen_name" : "swaj",
      "indices" : [ 0, 5 ],
      "id_str" : "15749350",
      "id" : 15749350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752364382330880",
  "geo" : { },
  "id_str" : "755871973900288",
  "in_reply_to_user_id" : 15749350,
  "text" : "@swaj `gem uninstall` isn't working? can you paste the error?",
  "id" : 755871973900288,
  "in_reply_to_status_id" : 752364382330880,
  "created_at" : "2010-11-06 03:46:28 +0000",
  "in_reply_to_screen_name" : "swaj",
  "in_reply_to_user_id_str" : "15749350",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabio Akita",
      "screen_name" : "AkitaOnRails",
      "indices" : [ 0, 13 ],
      "id_str" : "3982931",
      "id" : 3982931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713528365289472",
  "geo" : { },
  "id_str" : "714348469161984",
  "in_reply_to_user_id" : 3982931,
  "text" : "@AkitaOnRails seems fine here...",
  "id" : 714348469161984,
  "in_reply_to_status_id" : 713528365289472,
  "created_at" : "2010-11-06 01:01:28 +0000",
  "in_reply_to_screen_name" : "AkitaOnRails",
  "in_reply_to_user_id_str" : "3982931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659717185605633",
  "geo" : { },
  "id_str" : "660351137882112",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou UPVOTED PLEASE MERGE",
  "id" : 660351137882112,
  "in_reply_to_status_id" : 659717185605633,
  "created_at" : "2010-11-05 21:26:54 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617236570054656",
  "text" : "Flickr encodes images with base64 to prevent you from sharing their URL. So I took a screenshot of it instead.",
  "id" : 617236570054656,
  "created_at" : "2010-11-05 18:35:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557213521285120",
  "geo" : { },
  "id_str" : "558704202096640",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape you're welcome back anytime!",
  "id" : 558704202096640,
  "in_reply_to_status_id" : 557213521285120,
  "created_at" : "2010-11-05 14:43:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoptoadapp",
      "screen_name" : "hoptoadapp",
      "indices" : [ 3, 14 ],
      "id_str" : "15689539",
      "id" : 15689539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546676255236096",
  "text" : "RT @hoptoadapp: Just released!  Track iOS Crashes with Hoptoad: http:\/\/bit.ly\/a30auP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "546536761069569",
    "text" : "Just released!  Track iOS Crashes with Hoptoad: http:\/\/bit.ly\/a30auP",
    "id" : 546536761069569,
    "created_at" : "2010-11-05 13:54:39 +0000",
    "user" : {
      "name" : "hoptoadapp",
      "screen_name" : "hoptoadapp",
      "protected" : false,
      "id_str" : "15689539",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1566676288\/avatar_4fc31dfc8964_128_normal.png",
      "id" : 15689539,
      "verified" : false
    }
  },
  "id" : 546676255236096,
  "created_at" : "2010-11-05 13:55:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NEWW",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543992525619201",
  "text" : "Excited for #NEWW this weekend! http:\/\/webcomicsweekend.com\/",
  "id" : 543992525619201,
  "created_at" : "2010-11-05 13:44:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337233701769216",
  "geo" : { },
  "id_str" : "360885931474944",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr we've discussed gem signing but haven't decided on anything as a cert server...will you be at rubyconf?",
  "id" : 360885931474944,
  "in_reply_to_status_id" : 337233701769216,
  "created_at" : "2010-11-05 01:36:56 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350152317468672",
  "geo" : { },
  "id_str" : "350562331664384",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit are you MURDERING THAT CAKE?!",
  "id" : 350562331664384,
  "in_reply_to_status_id" : 350152317468672,
  "created_at" : "2010-11-05 00:55:55 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343479016235008",
  "text" : "I need version control for dishes. `dish checkout clean`. Done.",
  "id" : 343479016235008,
  "created_at" : "2010-11-05 00:27:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335103347658752",
  "geo" : { },
  "id_str" : "335624234082304",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr dude what? mind posting your thoughts on rubygems-developers?",
  "id" : 335624234082304,
  "in_reply_to_status_id" : 335103347658752,
  "created_at" : "2010-11-04 23:56:33 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304670308302848",
  "geo" : { },
  "id_str" : "334551318528000",
  "in_reply_to_user_id" : 15146670,
  "text" : "@billbrasky66 there's a known bug if you chose a handle that someone else has already...can you try a different one?",
  "id" : 334551318528000,
  "in_reply_to_status_id" : 304670308302848,
  "created_at" : "2010-11-04 23:52:17 +0000",
  "in_reply_to_screen_name" : "jasoncwik",
  "in_reply_to_user_id_str" : "15146670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309369665224704",
  "text" : "Custom methods on Symbol bother me immensely. STOP IT.",
  "id" : 309369665224704,
  "created_at" : "2010-11-04 22:12:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nixon Hugo Davila Cr",
      "screen_name" : "CrNixon",
      "indices" : [ 0, 8 ],
      "id_str" : "2533055086",
      "id" : 2533055086
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 9, 20 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301897848193025",
  "geo" : { },
  "id_str" : "302759307911168",
  "in_reply_to_user_id" : 7905972,
  "text" : "@crnixon @chadfowler how is that better than .find_each ?",
  "id" : 302759307911168,
  "in_reply_to_status_id" : 301897848193025,
  "created_at" : "2010-11-04 21:45:58 +0000",
  "in_reply_to_screen_name" : "cndreisbach",
  "in_reply_to_user_id_str" : "7905972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Humphries",
      "screen_name" : "spicycode",
      "indices" : [ 0, 10 ],
      "id_str" : "278580629",
      "id" : 278580629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29621646990",
  "text" : "@spicycode www.slideshare.net\/rmoriz\/rubygems-behind-the-gems",
  "id" : 29621646990,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29607802420",
  "geo" : { },
  "id_str" : "29622014272",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel SELL SELL SELL (oh wait, the other one)",
  "id" : 29622014272,
  "in_reply_to_status_id" : 29607802420,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29641191389",
  "text" : "Does anyone else's brain want to stay awake, but your body says go to sleep? Daily struggle for me.",
  "id" : 29641191389,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29663564903",
  "text" : "1 week to RubyConf!",
  "id" : 29663564903,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 0, 11 ],
      "id_str" : "9238852",
      "id" : 9238852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29669171524",
  "geo" : { },
  "id_str" : "29669256530",
  "in_reply_to_user_id" : 9238852,
  "text" : "@drusellers JUST USE A WIZARD, DUH!",
  "id" : 29669256530,
  "in_reply_to_status_id" : 29669171524,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "drusellers",
  "in_reply_to_user_id_str" : "9238852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan",
      "screen_name" : "loganj",
      "indices" : [ 0, 7 ],
      "id_str" : "1051251",
      "id" : 1051251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29672393113",
  "geo" : { },
  "id_str" : "29672874578",
  "in_reply_to_user_id" : 1051251,
  "text" : "@loganj trying to avoid that fate...what problems are you experiencing?",
  "id" : 29672874578,
  "in_reply_to_status_id" : 29672393113,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "loganj",
  "in_reply_to_user_id_str" : "1051251",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan",
      "screen_name" : "loganj",
      "indices" : [ 0, 7 ],
      "id_str" : "1051251",
      "id" : 1051251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29673238468",
  "geo" : { },
  "id_str" : "29674465091",
  "in_reply_to_user_id" : 1051251,
  "text" : "@loganj i really recommend rvm, this pain just goes away. http:\/\/rvm.beginrescueend.com\/",
  "id" : 29674465091,
  "in_reply_to_status_id" : 29673238468,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "loganj",
  "in_reply_to_user_id_str" : "1051251",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29685475973",
  "geo" : { },
  "id_str" : "29685633197",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates good idea, patches are more than welcome for that :)",
  "id" : 29685633197,
  "in_reply_to_status_id" : 29685475973,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 3, 11 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29696469205",
  "text" : "RT @jayunit: Seems we've hit upon something! Signups keep coming in for the  thoughtbot Design for Developers course http:\/\/j.mp\/a7T1Zm  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29696345879",
    "text" : "Seems we've hit upon something! Signups keep coming in for the  thoughtbot Design for Developers course http:\/\/j.mp\/a7T1Zm - See you there?",
    "id" : 29696345879,
    "created_at" : "2010-11-04 19:56:54 +0000",
    "user" : {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "protected" : false,
      "id_str" : "14238213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1435351938\/jason2_normal.png",
      "id" : 14238213,
      "verified" : false
    }
  },
  "id" : 29696469205,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29696338120",
  "geo" : { },
  "id_str" : "29696482684",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt do they recommend that you brush twice daily?",
  "id" : 29696482684,
  "in_reply_to_status_id" : 29696338120,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 29, 38 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 66, 76 ],
      "id_str" : "19846068",
      "id" : 19846068
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 88, 98 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29530731651",
  "text" : "Earlier night than usual for @bostonrb, but had a great time with @cldwalker pairing on @gemcutter profiles. Thanks for coming out everyone!",
  "id" : 29530731651,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels Meersschaert ",
      "screen_name" : "nielsmeer",
      "indices" : [ 0, 10 ],
      "id_str" : "133143941",
      "id" : 133143941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29514777219",
  "geo" : { },
  "id_str" : "29532856336",
  "in_reply_to_user_id" : 133143941,
  "text" : "@nielsmeer that doesn't make much sense...does it work now? Why would you let it run for &gt; 1 minute? Are you behind an http proxy?",
  "id" : 29532856336,
  "in_reply_to_status_id" : 29514777219,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "nielsmeer",
  "in_reply_to_user_id_str" : "133143941",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29536887114",
  "text" : "Philsoraptor wins the rally: http:\/\/26.media.tumblr.com\/tumblr_lba6hj3s2j1qzz0iho1_500.jpg",
  "id" : 29536887114,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29538420633",
  "text" : "Photo: ex-genius: http:\/\/tumblr.com\/x17o9w7y2",
  "id" : 29538420633,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 42, 52 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29546648730",
  "text" : "Wrapped up some long running branches for @gemcutter and deployed... Enjoy the changes, more to come!",
  "id" : 29546648730,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29561720211",
  "geo" : { },
  "id_str" : "29566063647",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez oh NICE! Wanted that forever ago, ended up just compiling a patch.",
  "id" : 29566063647,
  "in_reply_to_status_id" : 29561720211,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29551247704",
  "geo" : { },
  "id_str" : "29569987696",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin yeah, I love the retro default ones...so much better than wavatar or monsters",
  "id" : 29569987696,
  "in_reply_to_status_id" : 29551247704,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "See @lindsaar",
      "screen_name" : "raasdnil",
      "indices" : [ 0, 9 ],
      "id_str" : "381961794",
      "id" : 381961794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29551153675",
  "geo" : { },
  "id_str" : "29571895153",
  "in_reply_to_user_id" : 88096243,
  "text" : "@raasdnil that's just the number of times the .gem has been accessed. no way to tell if it's downloaded separately or not.",
  "id" : 29571895153,
  "in_reply_to_status_id" : 29551153675,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "lindsaar",
  "in_reply_to_user_id_str" : "88096243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 33, 43 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29572432127",
  "text" : "Anyone notice the new feature on @gemcutter yet?",
  "id" : 29572432127,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29572590145",
  "geo" : { },
  "id_str" : "29573641420",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish lots of complaints\/support reqs about not being able to figure out who owns a gem to contact them. i don't want to be a middleman",
  "id" : 29573641420,
  "in_reply_to_status_id" : 29572590145,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Grosser",
      "screen_name" : "grosser",
      "indices" : [ 0, 8 ],
      "id_str" : "18628850",
      "id" : 18628850
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 71, 81 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29592629325",
  "in_reply_to_user_id" : 18628850,
  "text" : "@grosser we should talk some time about making `gem dependent` part of @gemcutter. hop in #gemcutter on freenode!",
  "id" : 29592629325,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "grosser",
  "in_reply_to_user_id_str" : "18628850",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29596091053",
  "text" : "Probably the most important work of the decade, nay, century: http:\/\/getbusinessing.com\/",
  "id" : 29596091053,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Humphries",
      "screen_name" : "spicycode",
      "indices" : [ 0, 10 ],
      "id_str" : "278580629",
      "id" : 278580629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29609998210",
  "text" : "@spicycode :( you could help out if you want the uptime to improve.",
  "id" : 29609998210,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29437335874",
  "text" : "Learned tonight that netcat != GNU netcat. Aggggh.",
  "id" : 29437335874,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29415456042",
  "geo" : { },
  "id_str" : "29470796885",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen coming back for the ruby group hackfest tonight?",
  "id" : 29470796885,
  "in_reply_to_status_id" : 29415456042,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A List Apart",
      "screen_name" : "alistapart",
      "indices" : [ 41, 52 ],
      "id_str" : "18776131",
      "id" : 18776131
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 67, 76 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29470974568",
  "text" : "Get started with git, new blog post from @alistapart that mentions @gitready! http:\/\/is.gd\/gCjn1",
  "id" : 29470974568,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29489234652",
  "text" : "Perhaps the future of on-screen keyboards for mobile devices: http:\/\/www.the8pen.com\/",
  "id" : 29489234652,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29491650633",
  "geo" : { },
  "id_str" : "29498973659",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen but what about ruby and PIZZA? and BEER? (or something else, not sure what we're ordering yet)",
  "id" : 29498973659,
  "in_reply_to_status_id" : 29491650633,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 15, 24 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 80, 90 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29514457529",
  "text" : "Looks like the @bostonrb hackfest is off to a great start! Working through some @gemcutter support and issues.",
  "id" : 29514457529,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwin James Lynch",
      "screen_name" : "objectman",
      "indices" : [ 0, 10 ],
      "id_str" : "18321490",
      "id" : 18321490
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Dan DeFelippi",
      "screen_name" : "ExpertDan",
      "indices" : [ 26, 36 ],
      "id_str" : "17566946",
      "id" : 17566946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197123506465546241",
  "geo" : { },
  "id_str" : "197137065173983233",
  "in_reply_to_user_id" : 18321490,
  "text" : "@objectman @coworkbuffalo @expertdan i guess so. mostly meant for info right now. i guess we could have a \"what is coworking\" blurb",
  "id" : 197137065173983233,
  "in_reply_to_status_id" : 197123506465546241,
  "created_at" : "2012-05-01 01:35:13 +0000",
  "in_reply_to_screen_name" : "objectman",
  "in_reply_to_user_id_str" : "18321490",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197132010031038464",
  "geo" : { },
  "id_str" : "197136383507304449",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr yeah seen them! I just lost it at the raccoon\/cougar fight and suddenly FLASH FLOOD",
  "id" : 197136383507304449,
  "in_reply_to_status_id" : 197132010031038464,
  "created_at" : "2012-05-01 01:32:31 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197131598871801856",
  "geo" : { },
  "id_str" : "197131758213410816",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr yes. omg.",
  "id" : 197131758213410816,
  "in_reply_to_status_id" : 197131598871801856,
  "created_at" : "2012-05-01 01:14:08 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197127059967979520",
  "text" : "Movies don't get better than this. \"Charging on 2000 pounds of revenge, Buffalo Jones battles outlaws, cougars, bears and saves a baby.\"",
  "id" : 197127059967979520,
  "created_at" : "2012-05-01 00:55:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197123908632186881",
  "geo" : { },
  "id_str" : "197124767332048897",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik man I miss baseball. Since when is lack of fielders a problem? it's human error mostly in the pros.",
  "id" : 197124767332048897,
  "in_reply_to_status_id" : 197123908632186881,
  "created_at" : "2012-05-01 00:46:21 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197121061878378496",
  "geo" : { },
  "id_str" : "197123061068218368",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik that would be ridiculous. also i'm sure there's rules that the ball always needs to be caught.",
  "id" : 197123061068218368,
  "in_reply_to_status_id" : 197121061878378496,
  "created_at" : "2012-05-01 00:39:34 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197112223712292865",
  "geo" : { },
  "id_str" : "197112814614216705",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes thanks!",
  "id" : 197112814614216705,
  "in_reply_to_status_id" : 197112223712292865,
  "created_at" : "2012-04-30 23:58:51 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/ZCAUpohD",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "197111824146112513",
  "text" : "RT @coworkbuffalo: We have a website! http:\/\/t.co\/ZCAUpohD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http:\/\/t.co\/ZCAUpohD",
        "expanded_url" : "http:\/\/coworkbuffalo.com\/",
        "display_url" : "coworkbuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "197108964842946561",
    "text" : "We have a website! http:\/\/t.co\/ZCAUpohD",
    "id" : 197108964842946561,
    "created_at" : "2012-04-30 23:43:33 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 197111824146112513,
  "created_at" : "2012-04-30 23:54:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/197053351899303936\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/sWOtwF2n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArwS-sICEAIFHEp.jpg",
      "id_str" : "197053351903498242",
      "id" : 197053351903498242,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArwS-sICEAIFHEp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1244,
        "resize" : "fit",
        "w" : 1859
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/sWOtwF2n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197055143886323713",
  "text" : "RT @coworkbuffalo: No joke, the ILLUSTRATED ENCYCLOPEDIA OF KNOWLEDGE. Coming soon to a wall at Coworking near you. http:\/\/t.co\/sWOtwF2n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/197053351899303936\/photo\/1",
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/sWOtwF2n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ArwS-sICEAIFHEp.jpg",
        "id_str" : "197053351903498242",
        "id" : 197053351903498242,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArwS-sICEAIFHEp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1244,
          "resize" : "fit",
          "w" : 1859
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sWOtwF2n"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197053351899303936",
    "text" : "No joke, the ILLUSTRATED ENCYCLOPEDIA OF KNOWLEDGE. Coming soon to a wall at Coworking near you. http:\/\/t.co\/sWOtwF2n",
    "id" : 197053351899303936,
    "created_at" : "2012-04-30 20:02:36 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 197055143886323713,
  "created_at" : "2012-04-30 20:09:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197048570585677825",
  "text" : "Shipping is the best.",
  "id" : 197048570585677825,
  "created_at" : "2012-04-30 19:43:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197033556004962304",
  "text" : "RT @moonpolysoft: Unified theory of HN: it is a community for startup fan fiction.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197031865671094274",
    "text" : "Unified theory of HN: it is a community for startup fan fiction.",
    "id" : 197031865671094274,
    "created_at" : "2012-04-30 18:37:12 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 197033556004962304,
  "created_at" : "2012-04-30 18:43:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Schoolcraft",
      "screen_name" : "jschoolcraft",
      "indices" : [ 0, 13 ],
      "id_str" : "14225666",
      "id" : 14225666
    }, {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 14, 22 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196997622702145538",
  "geo" : { },
  "id_str" : "196997828604739584",
  "in_reply_to_user_id" : 14225666,
  "text" : "@jschoolcraft @bphogan check the readme, you can exclude directories.",
  "id" : 196997828604739584,
  "in_reply_to_status_id" : 196997622702145538,
  "created_at" : "2012-04-30 16:21:57 +0000",
  "in_reply_to_screen_name" : "jschoolcraft",
  "in_reply_to_user_id_str" : "14225666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Schoolcraft",
      "screen_name" : "jschoolcraft",
      "indices" : [ 0, 13 ],
      "id_str" : "14225666",
      "id" : 14225666
    }, {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 14, 22 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196996903857160192",
  "geo" : { },
  "id_str" : "196997270628073472",
  "in_reply_to_user_id" : 14225666,
  "text" : "@jschoolcraft @bphogan find .  | wc -l:  4357 works fine.",
  "id" : 196997270628073472,
  "in_reply_to_status_id" : 196996903857160192,
  "created_at" : "2012-04-30 16:19:44 +0000",
  "in_reply_to_screen_name" : "jschoolcraft",
  "in_reply_to_user_id_str" : "14225666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196995780463173632",
  "geo" : { },
  "id_str" : "196996710206144512",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej Mostly just normal :e, :Tex. NERDTree very very rarely.",
  "id" : 196996710206144512,
  "in_reply_to_status_id" : 196995780463173632,
  "created_at" : "2012-04-30 16:17:30 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 48 ],
      "url" : "https:\/\/t.co\/c1cXRGUB",
      "expanded_url" : "https:\/\/github.com\/kien\/ctrlp.vim",
      "display_url" : "github.com\/kien\/ctrlp.vim"
    } ]
  },
  "geo" : { },
  "id_str" : "196994968093601792",
  "text" : "Just installed CtrlP. WOW. https:\/\/t.co\/c1cXRGUB",
  "id" : 196994968093601792,
  "created_at" : "2012-04-30 16:10:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/5mGU99MG",
      "expanded_url" : "http:\/\/30.media.tumblr.com\/tumblr_m3aqenXxQz1qhmzreo1_500.jpg",
      "display_url" : "30.media.tumblr.com\/tumblr_m3aqenX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "196990496038600704",
  "text" : "Current status: http:\/\/t.co\/5mGU99MG",
  "id" : 196990496038600704,
  "created_at" : "2012-04-30 15:52:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196785335198416897",
  "geo" : { },
  "id_str" : "196787783371722753",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape also, that dog got big!",
  "id" : 196787783371722753,
  "in_reply_to_status_id" : 196785335198416897,
  "created_at" : "2012-04-30 02:27:18 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196785335198416897",
  "geo" : { },
  "id_str" : "196787522544738304",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape slightly better than humping",
  "id" : 196787522544738304,
  "in_reply_to_status_id" : 196785335198416897,
  "created_at" : "2012-04-30 02:26:16 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196745783280795649",
  "geo" : { },
  "id_str" : "196759474948673537",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus hell yes, I have many willing beta testers here.",
  "id" : 196759474948673537,
  "in_reply_to_status_id" : 196745783280795649,
  "created_at" : "2012-04-30 00:34:49 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196723028204331008",
  "geo" : { },
  "id_str" : "196735793446920192",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy deep",
  "id" : 196735793446920192,
  "in_reply_to_status_id" : 196723028204331008,
  "created_at" : "2012-04-29 23:00:42 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196717936210214912",
  "geo" : { },
  "id_str" : "196718909766905857",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez woot! Finally a reason to use these things.",
  "id" : 196718909766905857,
  "in_reply_to_status_id" : 196717936210214912,
  "created_at" : "2012-04-29 21:53:37 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 81, 95 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196716639268507651",
  "text" : "Beyond excited to use some old Buffalo maps from the Library of Congress for the @coworkbuffalo website. Not sure why I'm such a map nerd.",
  "id" : 196716639268507651,
  "created_at" : "2012-04-29 21:44:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196711628681650176",
  "geo" : { },
  "id_str" : "196714176369012736",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg plenty here :)",
  "id" : 196714176369012736,
  "in_reply_to_status_id" : 196711628681650176,
  "created_at" : "2012-04-29 21:34:49 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 31, 45 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/OPuVZSLV",
      "expanded_url" : "http:\/\/instagr.am\/p\/KBIT-WM6if\/",
      "display_url" : "instagr.am\/p\/KBIT-WM6if\/"
    } ]
  },
  "geo" : { },
  "id_str" : "196703619674939392",
  "text" : "Beta testing some wall art for @coworkbuffalo: members get frames for their latest conference badge! http:\/\/t.co\/OPuVZSLV",
  "id" : 196703619674939392,
  "created_at" : "2012-04-29 20:52:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "indices" : [ 0, 9 ],
      "id_str" : "12855662",
      "id" : 12855662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/1Z06i28K",
      "expanded_url" : "http:\/\/github.com\/rubygems\/gemwhisperer",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "196675787041148928",
  "geo" : { },
  "id_str" : "196697829517959168",
  "in_reply_to_user_id" : 12855662,
  "text" : "@adelevie nope. perhaps could be a fork of http:\/\/t.co\/1Z06i28K ?",
  "id" : 196697829517959168,
  "in_reply_to_status_id" : 196675787041148928,
  "created_at" : "2012-04-29 20:29:51 +0000",
  "in_reply_to_screen_name" : "adelevie",
  "in_reply_to_user_id_str" : "12855662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196645900444123138",
  "text" : "RT @rubygems_status: We've worked around the problem Ubuntu 12.04 is having with certain SSL hosts. If you're still having issues, let u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "196643456200876033",
    "text" : "We've worked around the problem Ubuntu 12.04 is having with certain SSL hosts. If you're still having issues, let us know!",
    "id" : 196643456200876033,
    "created_at" : "2012-04-29 16:53:48 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 196645900444123138,
  "created_at" : "2012-04-29 17:03:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/erigmrqF",
      "expanded_url" : "http:\/\/instagr.am\/p\/KAbtqMM6r7\/",
      "display_url" : "instagr.am\/p\/KAbtqMM6r7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "196605582726283265",
  "text" : "Springing! http:\/\/t.co\/erigmrqF",
  "id" : 196605582726283265,
  "created_at" : "2012-04-29 14:23:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/HDUZy2m6",
      "expanded_url" : "http:\/\/instagr.am\/p\/J_cjJDs6rT\/",
      "display_url" : "instagr.am\/p\/J_cjJDs6rT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "196466644049068035",
  "text" : "Alhambra! http:\/\/t.co\/HDUZy2m6",
  "id" : 196466644049068035,
  "created_at" : "2012-04-29 05:11:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 0, 9 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195838781985783808",
  "geo" : { },
  "id_str" : "196445527209025536",
  "in_reply_to_user_id" : 14212405,
  "text" : "@metadave hey wow, congrats! staying in Buffalo? I heard there's a fun place to work remotely opening soon if so :)",
  "id" : 196445527209025536,
  "in_reply_to_status_id" : 195838781985783808,
  "created_at" : "2012-04-29 03:47:18 +0000",
  "in_reply_to_screen_name" : "metadave",
  "in_reply_to_user_id_str" : "14212405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 31, 46 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196445344358334465",
  "text" : "Finally got out to a legendary @1ofyourmeteors game night! Had an awesome time.",
  "id" : 196445344358334465,
  "created_at" : "2012-04-29 03:46:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196441893947719680",
  "geo" : { },
  "id_str" : "196443243116904449",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg oh nice! if you guys want to meet the pup or grab some food give a shout.",
  "id" : 196443243116904449,
  "in_reply_to_status_id" : 196441893947719680,
  "created_at" : "2012-04-29 03:38:13 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/196428851323215872\/photo\/1",
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/5IMAXQBo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Arna_-MCIAAjF2v.jpg",
      "id_str" : "196428851327410176",
      "id" : 196428851327410176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Arna_-MCIAAjF2v.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5IMAXQBo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196428851323215872",
  "text" : "Luigi was planking before anyone else. http:\/\/t.co\/5IMAXQBo",
  "id" : 196428851323215872,
  "created_at" : "2012-04-29 02:41:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/GCknpbdw",
      "expanded_url" : "http:\/\/instagr.am\/p\/J_H3LbM6h-\/",
      "display_url" : "instagr.am\/p\/J_H3LbM6h-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "196421175889510401",
  "text" : "The best dollar. http:\/\/t.co\/GCknpbdw",
  "id" : 196421175889510401,
  "created_at" : "2012-04-29 02:10:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196377015874617344",
  "geo" : { },
  "id_str" : "196406095483375616",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan QuickTime movies too.",
  "id" : 196406095483375616,
  "in_reply_to_status_id" : 196377015874617344,
  "created_at" : "2012-04-29 01:10:36 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196374884056711168",
  "geo" : { },
  "id_str" : "196405763445493760",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety 10.",
  "id" : 196405763445493760,
  "in_reply_to_status_id" : 196374884056711168,
  "created_at" : "2012-04-29 01:09:17 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 3, 16 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 64, 70 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/qOa6dm1t",
      "expanded_url" : "http:\/\/link.olivierlacan.com\/GDAF",
      "display_url" : "link.olivierlacan.com\/GDAF"
    } ]
  },
  "geo" : { },
  "id_str" : "196405755493089281",
  "text" : "RT @olivierlacan: Most important fact learned at RailsConf from @qrush. You can put animated GIFs inside Keynote. http:\/\/t.co\/qOa6dm1t\n\n ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 46, 52 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/qOa6dm1t",
        "expanded_url" : "http:\/\/link.olivierlacan.com\/GDAF",
        "display_url" : "link.olivierlacan.com\/GDAF"
      } ]
    },
    "geo" : { },
    "id_str" : "196377015874617344",
    "text" : "Most important fact learned at RailsConf from @qrush. You can put animated GIFs inside Keynote. http:\/\/t.co\/qOa6dm1t\n\nIt changes everything.",
    "id" : 196377015874617344,
    "created_at" : "2012-04-28 23:15:03 +0000",
    "user" : {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "protected" : false,
      "id_str" : "17035875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554033206677483520\/8mqHp9Kd_normal.jpeg",
      "id" : 17035875,
      "verified" : false
    }
  },
  "id" : 196405755493089281,
  "created_at" : "2012-04-29 01:09:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Ko",
      "screen_name" : "justinko",
      "indices" : [ 0, 9 ],
      "id_str" : "23165791",
      "id" : 23165791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196366697312174081",
  "geo" : { },
  "id_str" : "196367393679876096",
  "in_reply_to_user_id" : 23165791,
  "text" : "@justinko plane? coming back from railsconf.",
  "id" : 196367393679876096,
  "in_reply_to_status_id" : 196366697312174081,
  "created_at" : "2012-04-28 22:36:49 +0000",
  "in_reply_to_screen_name" : "justinko",
  "in_reply_to_user_id_str" : "23165791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196366296521252865",
  "text" : "Apparently it's possible to purchase several iPods\/iPhones and still lose every damn charger.",
  "id" : 196366296521252865,
  "created_at" : "2012-04-28 22:32:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Ko",
      "screen_name" : "justinko",
      "indices" : [ 0, 9 ],
      "id_str" : "23165791",
      "id" : 23165791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196303537884512256",
  "geo" : { },
  "id_str" : "196366164241289218",
  "in_reply_to_user_id" : 23165791,
  "text" : "@justinko saw the mist from a few thousand feet today!",
  "id" : 196366164241289218,
  "in_reply_to_status_id" : 196303537884512256,
  "created_at" : "2012-04-28 22:31:56 +0000",
  "in_reply_to_screen_name" : "justinko",
  "in_reply_to_user_id_str" : "23165791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Moran",
      "screen_name" : "ChadMoran",
      "indices" : [ 0, 10 ],
      "id_str" : "16367850",
      "id" : 16367850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196353178411864064",
  "geo" : { },
  "id_str" : "196353632407519233",
  "in_reply_to_user_id" : 16367850,
  "text" : "@ChadMoran thanks!!",
  "id" : 196353632407519233,
  "in_reply_to_status_id" : 196353178411864064,
  "created_at" : "2012-04-28 21:42:08 +0000",
  "in_reply_to_screen_name" : "ChadMoran",
  "in_reply_to_user_id_str" : "16367850",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196352479863111682",
  "text" : "Back in Buffalo. Glad to be home.",
  "id" : 196352479863111682,
  "created_at" : "2012-04-28 21:37:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 117, 128 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/3cca7Jn6",
      "expanded_url" : "http:\/\/buffalo.craigslist.org\/atq\/2931798908.html",
      "display_url" : "buffalo.craigslist.org\/atq\/2931798908\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "196276246739550208",
  "text" : "\"This thing is seriously classic and creepy...use it for storing stuff--maybe even babies!\" http:\/\/t.co\/3cca7Jn6 \/cc @shellscape",
  "id" : 196276246739550208,
  "created_at" : "2012-04-28 16:34:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196258671141990401",
  "geo" : { },
  "id_str" : "196269713049927680",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude going to grab some once we're home, off airport wifi",
  "id" : 196269713049927680,
  "in_reply_to_status_id" : 196258671141990401,
  "created_at" : "2012-04-28 16:08:40 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196258671141990401",
  "geo" : { },
  "id_str" : "196269011342868480",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude !!!!!!",
  "id" : 196269011342868480,
  "in_reply_to_status_id" : 196258671141990401,
  "created_at" : "2012-04-28 16:05:53 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196210616803930112",
  "text" : "Got a free foot massage this time at the airport! Texas is so friendly.",
  "id" : 196210616803930112,
  "created_at" : "2012-04-28 12:13:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196077417419386882",
  "text" : "Shipping @CoworkBuffalo in 10 days. Time to get cracking.",
  "id" : 196077417419386882,
  "created_at" : "2012-04-28 03:24:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 42, 49 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/2ijjSDHE",
      "expanded_url" : "http:\/\/26.media.tumblr.com\/tumblr_m35fy9a16B1qz5x9po1_400.jpg",
      "display_url" : "26.media.tumblr.com\/tumblr_m35fy9a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "196075810577317888",
  "text" : "Current status: http:\/\/t.co\/2ijjSDHE \/via @croaky",
  "id" : 196075810577317888,
  "created_at" : "2012-04-28 03:18:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196065721070006275",
  "geo" : { },
  "id_str" : "196075095221997568",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton so good!",
  "id" : 196075095221997568,
  "in_reply_to_status_id" : 196065721070006275,
  "created_at" : "2012-04-28 03:15:20 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/B1gYhIvA",
      "expanded_url" : "http:\/\/instagr.am\/p\/J8iK7JM6q8\/",
      "display_url" : "instagr.am\/p\/J8iK7JM6q8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "196056802922729472",
  "text" : "Hidden Ruby! http:\/\/t.co\/B1gYhIvA",
  "id" : 196056802922729472,
  "created_at" : "2012-04-28 02:02:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 3, 10 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196056250868441088",
  "text" : "RT @jayroh: People using Git but are afraid of the command line for things like sass, etc. You're dumb.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "196055735090675715",
    "text" : "People using Git but are afraid of the command line for things like sass, etc. You're dumb.",
    "id" : 196055735090675715,
    "created_at" : "2012-04-28 01:58:24 +0000",
    "user" : {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "protected" : false,
      "id_str" : "14114222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491956337190793217\/jVkBxVJT_normal.jpeg",
      "id" : 14114222,
      "verified" : false
    }
  },
  "id" : 196056250868441088,
  "created_at" : "2012-04-28 02:00:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196033291055403008",
  "geo" : { },
  "id_str" : "196033858393743360",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin oh yes. also the ruby side is a mess. anything to speed up asset compilation will be a huge win.",
  "id" : 196033858393743360,
  "in_reply_to_status_id" : 196033291055403008,
  "created_at" : "2012-04-28 00:31:28 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 50, 58 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 35 ],
      "url" : "https:\/\/t.co\/kuU0TQH9",
      "expanded_url" : "https:\/\/github.com\/hcatlin\/libsass",
      "display_url" : "github.com\/hcatlin\/libsass"
    } ]
  },
  "geo" : { },
  "id_str" : "196032895977144320",
  "text" : "I really wish https:\/\/t.co\/kuU0TQH9 worked today! @hcatlin make it happen cap'n.",
  "id" : 196032895977144320,
  "created_at" : "2012-04-28 00:27:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196017839944110081",
  "geo" : { },
  "id_str" : "196017902174994432",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej What? That's really stupid.",
  "id" : 196017902174994432,
  "in_reply_to_status_id" : 196017839944110081,
  "created_at" : "2012-04-27 23:28:04 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/aK0JAVhE",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3901452",
      "display_url" : "news.ycombinator.com\/item?id=3901452"
    } ]
  },
  "geo" : { },
  "id_str" : "196017705562816512",
  "text" : "Fixed HN link too. UPboats! http:\/\/t.co\/aK0JAVhE",
  "id" : 196017705562816512,
  "created_at" : "2012-04-27 23:27:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    }, {
      "name" : "Fake Josh",
      "screen_name" : "joshkalderimis",
      "indices" : [ 8, 23 ],
      "id_str" : "628398860",
      "id" : 628398860
    }, {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 24, 34 ],
      "id_str" : "9459332",
      "id" : 9459332
    }, {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 35, 51 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "Dan Richert",
      "screen_name" : "drichert",
      "indices" : [ 52, 61 ],
      "id_str" : "19987905",
      "id" : 19987905
    }, {
      "name" : "Fabio Kreusch",
      "screen_name" : "fabiokr",
      "indices" : [ 62, 70 ],
      "id_str" : "18923101",
      "id" : 18923101
    }, {
      "name" : "Graham McMillan",
      "screen_name" : "gmcmillan",
      "indices" : [ 71, 81 ],
      "id_str" : "147439668",
      "id" : 147439668
    }, {
      "name" : "Joshua Priddle",
      "screen_name" : "itspriddle",
      "indices" : [ 82, 93 ],
      "id_str" : "14104108",
      "id" : 14104108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196014783525421056",
  "geo" : { },
  "id_str" : "196015183225831425",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi @joshkalderimis @svenfuchs @konstantinhaase @drichert @fabiokr @gmcmillan @itspriddle oh hey! apparently i am :P",
  "id" : 196015183225831425,
  "in_reply_to_status_id" : 196014783525421056,
  "created_at" : "2012-04-27 23:17:16 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196012847120121857",
  "geo" : { },
  "id_str" : "196013625159323648",
  "in_reply_to_user_id" : 11036982,
  "text" : "@_sbehan thanks!",
  "id" : 196013625159323648,
  "in_reply_to_status_id" : 196012847120121857,
  "created_at" : "2012-04-27 23:11:04 +0000",
  "in_reply_to_screen_name" : "seanpbehan",
  "in_reply_to_user_id_str" : "11036982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/pC7zRpif",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3167-code-spelunking-in-the-all-new-basecamp",
      "display_url" : "37signals.com\/svn\/posts\/3167\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "196011307198193664",
  "text" : "Fixed link! Code spelunking in the all new Basecamp: http:\/\/t.co\/pC7zRpif New patterns, neat gems, and more!",
  "id" : 196011307198193664,
  "created_at" : "2012-04-27 23:01:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keeran",
      "screen_name" : "keeran",
      "indices" : [ 0, 7 ],
      "id_str" : "10075872",
      "id" : 10075872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196010701125464064",
  "geo" : { },
  "id_str" : "196011167343316992",
  "in_reply_to_user_id" : 10075872,
  "text" : "@keeran fixed, thanks!",
  "id" : 196011167343316992,
  "in_reply_to_status_id" : 196010701125464064,
  "created_at" : "2012-04-27 23:01:18 +0000",
  "in_reply_to_screen_name" : "keeran",
  "in_reply_to_user_id_str" : "10075872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chilton",
      "screen_name" : "ichilton",
      "indices" : [ 0, 9 ],
      "id_str" : "20507434",
      "id" : 20507434
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 15, 25 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196009290232905729",
  "geo" : { },
  "id_str" : "196009596198985728",
  "in_reply_to_user_id" : 20507434,
  "text" : "@ichilton yep! @confreaks has #railsconf queued up for sometime in May. I didn't want to wait that long to blog about it :)",
  "id" : 196009596198985728,
  "in_reply_to_status_id" : 196009290232905729,
  "created_at" : "2012-04-27 22:55:04 +0000",
  "in_reply_to_screen_name" : "ichilton",
  "in_reply_to_user_id_str" : "20507434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Majd Taby",
      "screen_name" : "jtaby",
      "indices" : [ 0, 6 ],
      "id_str" : "6827332",
      "id" : 6827332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195987542124929024",
  "in_reply_to_user_id" : 6827332,
  "text" : "@jtaby hey! your site is dead. :(",
  "id" : 195987542124929024,
  "created_at" : "2012-04-27 21:27:25 +0000",
  "in_reply_to_screen_name" : "jtaby",
  "in_reply_to_user_id_str" : "6827332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195981622523338752",
  "geo" : { },
  "id_str" : "195983257488195584",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik yep!",
  "id" : 195983257488195584,
  "in_reply_to_status_id" : 195981622523338752,
  "created_at" : "2012-04-27 21:10:24 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195979907791208451",
  "geo" : { },
  "id_str" : "195980789840756736",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik they played bouncing around the room in a burger place we went to today. unreal!",
  "id" : 195980789840756736,
  "in_reply_to_status_id" : 195979907791208451,
  "created_at" : "2012-04-27 21:00:36 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195881396072488961",
  "geo" : { },
  "id_str" : "195887009498284032",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors whoa, does that work? submit a pull request!",
  "id" : 195887009498284032,
  "in_reply_to_status_id" : 195881396072488961,
  "created_at" : "2012-04-27 14:47:57 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195698682790809601",
  "text" : "Heading to Hickory Street in a few here for some post #railsconf food. If anyone is still in Austin, come on down!",
  "id" : 195698682790809601,
  "created_at" : "2012-04-27 02:19:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/K7B3gE9L",
      "expanded_url" : "http:\/\/instagr.am\/p\/J5n3uDs6oT\/",
      "display_url" : "instagr.am\/p\/J5n3uDs6oT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "195651347641667584",
  "text" : "The sign doesn't lie. http:\/\/t.co\/K7B3gE9L",
  "id" : 195651347641667584,
  "created_at" : "2012-04-26 23:11:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 3, 11 ],
      "id_str" : "15944824",
      "id" : 15944824
    }, {
      "name" : "Buffalo OpenCoffee",
      "screen_name" : "BfloOpenCoffee",
      "indices" : [ 49, 64 ],
      "id_str" : "300394295",
      "id" : 300394295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195610692798255104",
  "text" : "RT @paulehr: Man the level of discussions on the @BfloOpenCoffee mailing list today is epic. very very motivating",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo OpenCoffee",
        "screen_name" : "BfloOpenCoffee",
        "indices" : [ 36, 51 ],
        "id_str" : "300394295",
        "id" : 300394295
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195609973634514944",
    "text" : "Man the level of discussions on the @BfloOpenCoffee mailing list today is epic. very very motivating",
    "id" : 195609973634514944,
    "created_at" : "2012-04-26 20:27:06 +0000",
    "user" : {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "protected" : false,
      "id_str" : "15944824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2656131549\/349200ee787d6cf5f69dd623efd13298_normal.png",
      "id" : 15944824,
      "verified" : false
    }
  },
  "id" : 195610692798255104,
  "created_at" : "2012-04-26 20:29:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195604563435339778",
  "geo" : { },
  "id_str" : "195609270253920258",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k did you expect anything different? :)",
  "id" : 195609270253920258,
  "in_reply_to_status_id" : 195604563435339778,
  "created_at" : "2012-04-26 20:24:18 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Kebinger",
      "screen_name" : "monkeyatlarge",
      "indices" : [ 0, 14 ],
      "id_str" : "5440582",
      "id" : 5440582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195543660186710016",
  "geo" : { },
  "id_str" : "195556807870128129",
  "in_reply_to_user_id" : 5440582,
  "text" : "@monkeyatlarge yeah, it's still pretty brain melting.",
  "id" : 195556807870128129,
  "in_reply_to_status_id" : 195543660186710016,
  "created_at" : "2012-04-26 16:55:50 +0000",
  "in_reply_to_screen_name" : "monkeyatlarge",
  "in_reply_to_user_id_str" : "5440582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 112 ],
      "url" : "https:\/\/t.co\/bnv6k2qy",
      "expanded_url" : "https:\/\/github.com\/jashkenas\/coffee-script\/pull\/2289",
      "display_url" : "github.com\/jashkenas\/coff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195556419108478976",
  "text" : "I've added bang methods to CoffeeScript. Check out the pull request and +1 if you like it! https:\/\/t.co\/bnv6k2qy",
  "id" : 195556419108478976,
  "created_at" : "2012-04-26 16:54:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 102 ],
      "url" : "https:\/\/t.co\/l0Bf2I92",
      "expanded_url" : "https:\/\/github.com\/jashkenas\/coffee-script\/blob\/master\/src\/grammar.coffee",
      "display_url" : "github.com\/jashkenas\/coff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195537077981552641",
  "text" : "The fact that CoffeeScript's grammar is written in Coffeescript is mind-blowing. https:\/\/t.co\/l0Bf2I92",
  "id" : 195537077981552641,
  "created_at" : "2012-04-26 15:37:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195522879591415808",
  "geo" : { },
  "id_str" : "195523069773754368",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson haha thanks!",
  "id" : 195523069773754368,
  "in_reply_to_status_id" : 195522879591415808,
  "created_at" : "2012-04-26 14:41:47 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195501164538765312",
  "geo" : { },
  "id_str" : "195501474380386304",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo HOW DOES YOUR A\/B TESTING FRAMEWORK WORK!!!?",
  "id" : 195501474380386304,
  "in_reply_to_status_id" : 195501164538765312,
  "created_at" : "2012-04-26 13:15:58 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gareth Rees",
      "screen_name" : "_gareth",
      "indices" : [ 0, 8 ],
      "id_str" : "21346504",
      "id" : 21346504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195258953972719618",
  "geo" : { },
  "id_str" : "195492397382242304",
  "in_reply_to_user_id" : 21346504,
  "text" : "@_gareth basecamp next uses wysihtml5, that's where our focus will be. Code base is decent, works well, awesome maintainer",
  "id" : 195492397382242304,
  "in_reply_to_status_id" : 195258953972719618,
  "created_at" : "2012-04-26 12:39:54 +0000",
  "in_reply_to_screen_name" : "_gareth",
  "in_reply_to_user_id_str" : "21346504",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 16, 26 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 27, 38 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195490048668479489",
  "geo" : { },
  "id_str" : "195490453787906048",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @magnachef @paddyforan embed a gist? solved problems.",
  "id" : 195490453787906048,
  "in_reply_to_status_id" : 195490048668479489,
  "created_at" : "2012-04-26 12:32:10 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Johnson",
      "screen_name" : "mellowcoder",
      "indices" : [ 0, 12 ],
      "id_str" : "15535091",
      "id" : 15535091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195396375784071168",
  "geo" : { },
  "id_str" : "195404390327263233",
  "in_reply_to_user_id" : 15535091,
  "text" : "@mellowcoder thanks!  Really glad I was able to show off some code.",
  "id" : 195404390327263233,
  "in_reply_to_status_id" : 195396375784071168,
  "created_at" : "2012-04-26 06:50:11 +0000",
  "in_reply_to_screen_name" : "mellowcoder",
  "in_reply_to_user_id_str" : "15535091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jade Rubick",
      "screen_name" : "JadeRubick",
      "indices" : [ 0, 11 ],
      "id_str" : "202857808",
      "id" : 202857808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195345083623673856",
  "geo" : { },
  "id_str" : "195366068225708032",
  "in_reply_to_user_id" : 202857808,
  "text" : "@JadeRubick it's kind of crazy! Really humbled, always is overwhelming. Thanks!!",
  "id" : 195366068225708032,
  "in_reply_to_status_id" : 195345083623673856,
  "created_at" : "2012-04-26 04:17:55 +0000",
  "in_reply_to_screen_name" : "JadeRubick",
  "in_reply_to_user_id_str" : "202857808",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kareem Kouddous",
      "screen_name" : "kareemk",
      "indices" : [ 0, 8 ],
      "id_str" : "8859412",
      "id" : 8859412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195323132813389824",
  "geo" : { },
  "id_str" : "195339206598463488",
  "in_reply_to_user_id" : 8859412,
  "text" : "@kareemk 1) people want stability 2) nothing stops changing 3) this community is still awesome",
  "id" : 195339206598463488,
  "in_reply_to_status_id" : 195323132813389824,
  "created_at" : "2012-04-26 02:31:10 +0000",
  "in_reply_to_screen_name" : "kareemk",
  "in_reply_to_user_id_str" : "8859412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abarone",
      "screen_name" : "abarone",
      "indices" : [ 0, 8 ],
      "id_str" : "14064164",
      "id" : 14064164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195330361524359168",
  "geo" : { },
  "id_str" : "195338973953003520",
  "in_reply_to_user_id" : 14064164,
  "text" : "@abarone hey! Yes! Check out the WNYRuby group on meetup.",
  "id" : 195338973953003520,
  "in_reply_to_status_id" : 195330361524359168,
  "created_at" : "2012-04-26 02:30:15 +0000",
  "in_reply_to_screen_name" : "abarone",
  "in_reply_to_user_id_str" : "14064164",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/6zRY9YKC",
      "expanded_url" : "http:\/\/railsthemes.com\/?kid=90MY",
      "display_url" : "railsthemes.com\/?kid=90MY"
    } ]
  },
  "geo" : { },
  "id_str" : "195336823734669312",
  "text" : "More of this! http:\/\/t.co\/6zRY9YKC",
  "id" : 195336823734669312,
  "created_at" : "2012-04-26 02:21:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195320211753283585",
  "text" : "Truly awesome #railsconf. Exhausted and excited!",
  "id" : 195320211753283585,
  "created_at" : "2012-04-26 01:15:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan MacDonald",
      "screen_name" : "jmacdonald",
      "indices" : [ 3, 14 ],
      "id_str" : "12427412",
      "id" : 12427412
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jmacdonald\/status\/195184740209401856\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/Ixhk1l5Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArVvfLICIAAMuVM.png",
      "id_str" : "195184740213596160",
      "id" : 195184740213596160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArVvfLICIAAMuVM.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ixhk1l5Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195319947046567937",
  "text" : "RT @jmacdonald: Holy cow...how google drive terms compare to dropbox and Microsoft. ..wow. http:\/\/t.co\/Ixhk1l5Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jmacdonald\/status\/195184740209401856\/photo\/1",
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/Ixhk1l5Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ArVvfLICIAAMuVM.png",
        "id_str" : "195184740213596160",
        "id" : 195184740213596160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArVvfLICIAAMuVM.png",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ixhk1l5Z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195184740209401856",
    "text" : "Holy cow...how google drive terms compare to dropbox and Microsoft. ..wow. http:\/\/t.co\/Ixhk1l5Z",
    "id" : 195184740209401856,
    "created_at" : "2012-04-25 16:17:24 +0000",
    "user" : {
      "name" : "Jonathan MacDonald",
      "screen_name" : "jmacdonald",
      "protected" : false,
      "id_str" : "12427412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552264356470071296\/r40N1-cA_normal.jpeg",
      "id" : 12427412,
      "verified" : false
    }
  },
  "id" : 195319947046567937,
  "created_at" : "2012-04-26 01:14:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 8, 17 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195281140217675776",
  "geo" : { },
  "id_str" : "195291918031273984",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl @sarahmei aww thanks!",
  "id" : 195291918031273984,
  "in_reply_to_status_id" : 195281140217675776,
  "created_at" : "2012-04-25 23:23:16 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195284158942154752",
  "geo" : { },
  "id_str" : "195291855464828931",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr yes. Will fill you in!!",
  "id" : 195291855464828931,
  "in_reply_to_status_id" : 195284158942154752,
  "created_at" : "2012-04-25 23:23:01 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195278814648086530",
  "text" : "Awesome meeting for RubyGems 2.0 plans. Excited to get started on making things easier and better.",
  "id" : 195278814648086530,
  "created_at" : "2012-04-25 22:31:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Anderson",
      "screen_name" : "sudomv",
      "indices" : [ 0, 7 ],
      "id_str" : "1911924188",
      "id" : 1911924188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195260440060764161",
  "geo" : { },
  "id_str" : "195261351449473025",
  "in_reply_to_user_id" : 88489441,
  "text" : "@sudomv mine as well.",
  "id" : 195261351449473025,
  "in_reply_to_status_id" : 195260440060764161,
  "created_at" : "2012-04-25 21:21:48 +0000",
  "in_reply_to_screen_name" : "AdamBFerg",
  "in_reply_to_user_id_str" : "88489441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Staple",
      "screen_name" : "AndyStaple",
      "indices" : [ 0, 11 ],
      "id_str" : "34352961",
      "id" : 34352961
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 12, 27 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195257808629923840",
  "geo" : { },
  "id_str" : "195260206572257282",
  "in_reply_to_user_id" : 34352961,
  "text" : "@andystaple @ChrisVanPatten I'd love to show off Jekyll at this.",
  "id" : 195260206572257282,
  "in_reply_to_status_id" : 195257808629923840,
  "created_at" : "2012-04-25 21:17:15 +0000",
  "in_reply_to_screen_name" : "AndyStaple",
  "in_reply_to_user_id_str" : "34352961",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/NHNLKjmP",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/qrush\/p\/basecamp-next-code-spelunking",
      "display_url" : "speakerdeck.com\/u\/qrush\/p\/base\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195249144821067776",
  "text" : "Here's my slides from #railsconf: Basecamp Next: Code Spelunking! http:\/\/t.co\/NHNLKjmP",
  "id" : 195249144821067776,
  "created_at" : "2012-04-25 20:33:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Wagener",
      "screen_name" : "a_wagener",
      "indices" : [ 0, 10 ],
      "id_str" : "140208068",
      "id" : 140208068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195225212617367552",
  "geo" : { },
  "id_str" : "195234918727565313",
  "in_reply_to_user_id" : 140208068,
  "text" : "@a_wagener the same.",
  "id" : 195234918727565313,
  "in_reply_to_status_id" : 195225212617367552,
  "created_at" : "2012-04-25 19:36:46 +0000",
  "in_reply_to_screen_name" : "a_wagener",
  "in_reply_to_user_id_str" : "140208068",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 8, 18 ],
      "id_str" : "19846068",
      "id" : 19846068
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 19, 25 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195225667808399360",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @cldwalker @cmeik any of you guys in Austin?!",
  "id" : 195225667808399360,
  "created_at" : "2012-04-25 19:00:00 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cantino",
      "screen_name" : "tectonic",
      "indices" : [ 3, 12 ],
      "id_str" : "9813372",
      "id" : 9813372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/NmPpHcp8",
      "expanded_url" : "http:\/\/iwanttolearnruby.com",
      "display_url" : "iwanttolearnruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "195225230074056704",
  "text" : "RT @tectonic: http:\/\/t.co\/NmPpHcp8 #railsconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/NmPpHcp8",
        "expanded_url" : "http:\/\/iwanttolearnruby.com",
        "display_url" : "iwanttolearnruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "195224751222956033",
    "text" : "http:\/\/t.co\/NmPpHcp8 #railsconf",
    "id" : 195224751222956033,
    "created_at" : "2012-04-25 18:56:22 +0000",
    "user" : {
      "name" : "Andrew Cantino",
      "screen_name" : "tectonic",
      "protected" : false,
      "id_str" : "9813372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694984565\/me-right_normal.jpg",
      "id" : 9813372,
      "verified" : false
    }
  },
  "id" : 195225230074056704,
  "created_at" : "2012-04-25 18:58:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195220160737583104",
  "geo" : { },
  "id_str" : "195220941700210689",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight haha yes. Gifs make great water breaks!",
  "id" : 195220941700210689,
  "in_reply_to_status_id" : 195220160737583104,
  "created_at" : "2012-04-25 18:41:14 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Golden",
      "screen_name" : "ben_a_golden",
      "indices" : [ 0, 13 ],
      "id_str" : "247554512",
      "id" : 247554512
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 28, 35 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195201723734822912",
  "geo" : { },
  "id_str" : "195219587611111424",
  "in_reply_to_user_id" : 247554512,
  "text" : "@ben_a_golden I got it from @elight 's feed",
  "id" : 195219587611111424,
  "in_reply_to_status_id" : 195201723734822912,
  "created_at" : "2012-04-25 18:35:51 +0000",
  "in_reply_to_screen_name" : "ben_a_golden",
  "in_reply_to_user_id_str" : "247554512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Mugnolo",
      "screen_name" : "xymbol",
      "indices" : [ 0, 7 ],
      "id_str" : "16528883",
      "id" : 16528883
    }, {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 8, 15 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195212382899945473",
  "geo" : { },
  "id_str" : "195219411873972224",
  "in_reply_to_user_id" : 16528883,
  "text" : "@xymbol @rbates thanks so much!!",
  "id" : 195219411873972224,
  "in_reply_to_status_id" : 195212382899945473,
  "created_at" : "2012-04-25 18:35:09 +0000",
  "in_reply_to_screen_name" : "xymbol",
  "in_reply_to_user_id_str" : "16528883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Kumar",
      "screen_name" : "toamit",
      "indices" : [ 0, 7 ],
      "id_str" : "43259934",
      "id" : 43259934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195210383554908161",
  "geo" : { },
  "id_str" : "195219336703647745",
  "in_reply_to_user_id" : 43259934,
  "text" : "@toamit woot!",
  "id" : 195219336703647745,
  "in_reply_to_status_id" : 195210383554908161,
  "created_at" : "2012-04-25 18:34:51 +0000",
  "in_reply_to_screen_name" : "toamit",
  "in_reply_to_user_id_str" : "43259934",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zachdennis",
      "screen_name" : "zachdennis",
      "indices" : [ 0, 11 ],
      "id_str" : "9572062",
      "id" : 9572062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195217789617836033",
  "geo" : { },
  "id_str" : "195219065806139392",
  "in_reply_to_user_id" : 9572062,
  "text" : "@zachdennis thanks!!",
  "id" : 195219065806139392,
  "in_reply_to_status_id" : 195217789617836033,
  "created_at" : "2012-04-25 18:33:46 +0000",
  "in_reply_to_screen_name" : "zachdennis",
  "in_reply_to_user_id_str" : "9572062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195209758549090304",
  "text" : "Huge thanks to everyone who came to my #railsconf talk! I'll get the slides up on speakerdeck pronto.",
  "id" : 195209758549090304,
  "created_at" : "2012-04-25 17:56:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Priddle",
      "screen_name" : "itspriddle",
      "indices" : [ 0, 11 ],
      "id_str" : "14104108",
      "id" : 14104108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195202751037321217",
  "geo" : { },
  "id_str" : "195209654677147650",
  "in_reply_to_user_id" : 14104108,
  "text" : "@itspriddle thanks!!",
  "id" : 195209654677147650,
  "in_reply_to_status_id" : 195202751037321217,
  "created_at" : "2012-04-25 17:56:23 +0000",
  "in_reply_to_screen_name" : "itspriddle",
  "in_reply_to_user_id_str" : "14104108",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Stirk",
      "screen_name" : "j_stirk",
      "indices" : [ 0, 8 ],
      "id_str" : "9808812",
      "id" : 9808812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195190703888928769",
  "geo" : { },
  "id_str" : "195209420379140096",
  "in_reply_to_user_id" : 9808812,
  "text" : "@j_stirk are you on the latest version? I was having trouble like this, upgrading helped.",
  "id" : 195209420379140096,
  "in_reply_to_status_id" : 195190703888928769,
  "created_at" : "2012-04-25 17:55:27 +0000",
  "in_reply_to_screen_name" : "j_stirk",
  "in_reply_to_user_id_str" : "9808812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Wade Minter",
      "screen_name" : "minter",
      "indices" : [ 0, 7 ],
      "id_str" : "8115722",
      "id" : 8115722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195189042789359617",
  "geo" : { },
  "id_str" : "195209031785254912",
  "in_reply_to_user_id" : 8115722,
  "text" : "@minter yes, I definitely am. Bills too!",
  "id" : 195209031785254912,
  "in_reply_to_status_id" : 195189042789359617,
  "created_at" : "2012-04-25 17:53:54 +0000",
  "in_reply_to_screen_name" : "minter",
  "in_reply_to_user_id_str" : "8115722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 0, 9 ],
      "id_str" : "10647472",
      "id" : 10647472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195175749999788032",
  "geo" : { },
  "id_str" : "195184621552537602",
  "in_reply_to_user_id" : 10647472,
  "text" : "@adambair that's in game time..not real time.",
  "id" : 195184621552537602,
  "in_reply_to_status_id" : 195175749999788032,
  "created_at" : "2012-04-25 16:16:54 +0000",
  "in_reply_to_screen_name" : "adambair",
  "in_reply_to_user_id_str" : "10647472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 0, 9 ],
      "id_str" : "10647472",
      "id" : 10647472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195165278894698498",
  "geo" : { },
  "id_str" : "195166216040628224",
  "in_reply_to_user_id" : 10647472,
  "text" : "@adambair oh hell yes! I've got a 5 year old fort going strong, ~115 dorfs, several FB's down, 2 sieges ended so far. Such an awesome game.",
  "id" : 195166216040628224,
  "in_reply_to_status_id" : 195165278894698498,
  "created_at" : "2012-04-25 15:03:46 +0000",
  "in_reply_to_screen_name" : "adambair",
  "in_reply_to_user_id_str" : "10647472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 67, 80 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195005535651770368",
  "text" : "Hitting up some games in the Hilton bar. Anyone up? #railsconf \/cc @steveklabnik",
  "id" : 195005535651770368,
  "created_at" : "2012-04-25 04:25:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194858929874944000",
  "text" : "The only contributor agreement needed for an OSS project: \"Send Pull Request\".",
  "id" : 194858929874944000,
  "created_at" : "2012-04-24 18:42:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 96, 104 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/RaSiWt7b",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3130-mini-tech-note-mysql-query-comments-in-rails",
      "display_url" : "37signals.com\/svn\/posts\/3130\u2026"
    }, {
      "indices" : [ 67, 88 ],
      "url" : "https:\/\/t.co\/xE66HAcY",
      "expanded_url" : "https:\/\/github.com\/37signals\/marginalia",
      "display_url" : "github.com\/37signals\/marg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194844389082791936",
  "text" : "RT @themcgruff: This is some tasty stuff! http:\/\/t.co\/RaSiWt7b and https:\/\/t.co\/xE66HAcY credit @noahhlo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Noah Lorang",
        "screen_name" : "noahhlo",
        "indices" : [ 80, 88 ],
        "id_str" : "234465384",
        "id" : 234465384
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/RaSiWt7b",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3130-mini-tech-note-mysql-query-comments-in-rails",
        "display_url" : "37signals.com\/svn\/posts\/3130\u2026"
      }, {
        "indices" : [ 51, 72 ],
        "url" : "https:\/\/t.co\/xE66HAcY",
        "expanded_url" : "https:\/\/github.com\/37signals\/marginalia",
        "display_url" : "github.com\/37signals\/marg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "194844084203028480",
    "text" : "This is some tasty stuff! http:\/\/t.co\/RaSiWt7b and https:\/\/t.co\/xE66HAcY credit @noahhlo",
    "id" : 194844084203028480,
    "created_at" : "2012-04-24 17:43:44 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 194844389082791936,
  "created_at" : "2012-04-24 17:44:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194814991323500544",
  "text" : "RT @rubygems_status: Apparently we have fixed the SSL cert problem with `rails new` and the new Ruby version...if you're seeing it, plea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194814906640502784",
    "text" : "Apparently we have fixed the SSL cert problem with `rails new` and the new Ruby version...if you're seeing it, please yell!",
    "id" : 194814906640502784,
    "created_at" : "2012-04-24 15:47:47 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 194814991323500544,
  "created_at" : "2012-04-24 15:48:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194769483896856576",
  "geo" : { },
  "id_str" : "194774985435381760",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn new herps on the hour, every hour. Derpcast 2000.",
  "id" : 194774985435381760,
  "in_reply_to_status_id" : 194769483896856576,
  "created_at" : "2012-04-24 13:09:09 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 31, 39 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194762872558059520",
  "geo" : { },
  "id_str" : "194774200068747264",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum yikes, not sure! Hey @evanphx any ideas?",
  "id" : 194774200068747264,
  "in_reply_to_status_id" : 194762872558059520,
  "created_at" : "2012-04-24 13:06:02 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194660561533935616",
  "text" : "Ok ran out of energy. See you tomorrow #railsconf",
  "id" : 194660561533935616,
  "created_at" : "2012-04-24 05:34:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194652279314448384",
  "text" : "Going to hit the hotel bar at the Hilton. Anyone still up? #railsconf",
  "id" : 194652279314448384,
  "created_at" : "2012-04-24 05:01:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McDowall",
      "screen_name" : "mrmcdowall",
      "indices" : [ 0, 11 ],
      "id_str" : "2959985041",
      "id" : 2959985041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194639507205783552",
  "text" : "@MrMcDowall I guess so! It's really just a pile of executable scripts, setup exactly how rbenv works",
  "id" : 194639507205783552,
  "created_at" : "2012-04-24 04:10:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194639250564718593",
  "text" : "Hi Austin!",
  "id" : 194639250564718593,
  "created_at" : "2012-04-24 04:09:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier Shay",
      "screen_name" : "xshay",
      "indices" : [ 0, 6 ],
      "id_str" : "14592505",
      "id" : 14592505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194600188596322307",
  "geo" : { },
  "id_str" : "194603240170598401",
  "in_reply_to_user_id" : 14592505,
  "text" : "@xshay plenty of issues on rubygems\/RubyGems.org to check out. See the bugs category!",
  "id" : 194603240170598401,
  "in_reply_to_status_id" : 194600188596322307,
  "created_at" : "2012-04-24 01:46:42 +0000",
  "in_reply_to_screen_name" : "xshay",
  "in_reply_to_user_id_str" : "14592505",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 3, 16 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194591662310301697",
  "text" : "RT @Horse_ebooks: You Must Have Customers Or Your Business Will Die.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194588601735065603",
    "text" : "You Must Have Customers Or Your Business Will Die.",
    "id" : 194588601735065603,
    "created_at" : "2012-04-24 00:48:32 +0000",
    "user" : {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "protected" : false,
      "id_str" : "174958347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096005346\/1_normal.jpg",
      "id" : 174958347,
      "verified" : false
    }
  },
  "id" : 194591662310301697,
  "created_at" : "2012-04-24 01:00:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194590873705656320",
  "text" : "Holy crap, epic travel day. Drove from CLT to ATL for a wedding, now almost at our gate to AUS. See ya soon #railsconf!",
  "id" : 194590873705656320,
  "created_at" : "2012-04-24 00:57:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 23 ],
      "url" : "http:\/\/t.co\/aQtIt4MN",
      "expanded_url" : "http:\/\/instagr.am\/p\/Jx3Z6Ms6tV\/",
      "display_url" : "instagr.am\/p\/Jx3Z6Ms6tV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "194555500338229252",
  "text" : "\uD83D\uDC18\uD83D\uDC39 http:\/\/t.co\/aQtIt4MN",
  "id" : 194555500338229252,
  "created_at" : "2012-04-23 22:37:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 42, 58 ],
      "id_str" : "15428948",
      "id" : 15428948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/HRlyGmr3",
      "expanded_url" : "http:\/\/instagr.am\/p\/JxvaSSM6qd\/",
      "display_url" : "instagr.am\/p\/JxvaSSM6qd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "194538062187999232",
  "text" : "Big congrats to Mr. And Mrs. Mongeau! \/cc @halogenandtoast http:\/\/t.co\/HRlyGmr3",
  "id" : 194538062187999232,
  "created_at" : "2012-04-23 21:27:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Highgroove",
      "screen_name" : "highgroove",
      "indices" : [ 15, 26 ],
      "id_str" : "2838403934",
      "id" : 2838403934
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 39, 49 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194517360789553152",
  "text" : "Huge thanks to @highgroove for housing @aquaranto and myself this afternoon! Cool place and folks.",
  "id" : 194517360789553152,
  "created_at" : "2012-04-23 20:05:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Bernier",
      "screen_name" : "danbernier",
      "indices" : [ 0, 11 ],
      "id_str" : "10943592",
      "id" : 10943592
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 12, 17 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/q4lyqDmb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=--OPPqaqx7g",
      "display_url" : "youtube.com\/watch?v=--OPPq\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "194511235180544001",
  "geo" : { },
  "id_str" : "194513796071559169",
  "in_reply_to_user_id" : 10943592,
  "text" : "@danbernier @r00k agreed. http:\/\/t.co\/q4lyqDmb",
  "id" : 194513796071559169,
  "in_reply_to_status_id" : 194511235180544001,
  "created_at" : "2012-04-23 19:51:17 +0000",
  "in_reply_to_screen_name" : "danbernier",
  "in_reply_to_user_id_str" : "10943592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194511087918530560",
  "geo" : { },
  "id_str" : "194513689758535682",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman dammit !:(",
  "id" : 194513689758535682,
  "in_reply_to_status_id" : 194511087918530560,
  "created_at" : "2012-04-23 19:50:52 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194508573122887680",
  "geo" : { },
  "id_str" : "194513661916749824",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene if you want to do analysis like this, just yell. will gladly provide pgdumps.",
  "id" : 194513661916749824,
  "in_reply_to_status_id" : 194508573122887680,
  "created_at" : "2012-04-23 19:50:45 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Highgroove",
      "screen_name" : "highgroove",
      "indices" : [ 12, 23 ],
      "id_str" : "2838403934",
      "id" : 2838403934
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/194513110822961153\/photo\/1",
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/waSxDt03",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArMMpMsCQAESfi3.jpg",
      "id_str" : "194513110827155457",
      "id" : 194513110827155457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArMMpMsCQAESfi3.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/waSxDt03"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194513110822961153",
  "text" : "This is it! @highgroove http:\/\/t.co\/waSxDt03",
  "id" : 194513110822961153,
  "created_at" : "2012-04-23 19:48:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https:\/\/t.co\/dgfsSGx8",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/409",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194506401954004993",
  "text" : "Found out only 23% of all published gems are over version 1.0.0. :( https:\/\/t.co\/dgfsSGx8",
  "id" : 194506401954004993,
  "created_at" : "2012-04-23 19:21:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/I7zbZxQz",
      "expanded_url" : "http:\/\/gunshowcomic.com\/537",
      "display_url" : "gunshowcomic.com\/537"
    } ]
  },
  "geo" : { },
  "id_str" : "194275171136311297",
  "text" : "RT @kcgbooks: Glassie http:\/\/t.co\/I7zbZxQz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 28 ],
        "url" : "http:\/\/t.co\/I7zbZxQz",
        "expanded_url" : "http:\/\/gunshowcomic.com\/537",
        "display_url" : "gunshowcomic.com\/537"
      } ]
    },
    "geo" : { },
    "id_str" : "194274978479345665",
    "text" : "Glassie http:\/\/t.co\/I7zbZxQz",
    "id" : 194274978479345665,
    "created_at" : "2012-04-23 04:02:18 +0000",
    "user" : {
      "name" : "kc gr\u0259\u0259n",
      "screen_name" : "kcgreenn",
      "protected" : false,
      "id_str" : "16522244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573812132753620992\/Hmui3IXO_normal.jpeg",
      "id" : 16522244,
      "verified" : false
    }
  },
  "id" : 194275171136311297,
  "created_at" : "2012-04-23 04:03:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194231030075490304",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich did you get a husky!?",
  "id" : 194231030075490304,
  "created_at" : "2012-04-23 01:07:40 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194229336033865728",
  "geo" : { },
  "id_str" : "194229741811798016",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast excited dude! see you tomorrow!",
  "id" : 194229741811798016,
  "in_reply_to_status_id" : 194229336033865728,
  "created_at" : "2012-04-23 01:02:33 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194160772711067652",
  "geo" : { },
  "id_str" : "194161435348180992",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu nope, getting in late Monday.",
  "id" : 194161435348180992,
  "in_reply_to_status_id" : 194160772711067652,
  "created_at" : "2012-04-22 20:31:08 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 15, 21 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194161189230616576",
  "text" : "Huge thanks to @wfarr for hooking us up!",
  "id" : 194161189230616576,
  "created_at" : "2012-04-22 20:30:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Highgroove",
      "screen_name" : "highgroove",
      "indices" : [ 21, 32 ],
      "id_str" : "2838403934",
      "id" : 2838403934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194160330262319105",
  "text" : "Going to hang out at @highgroove tomorrow, then #railsconf and Austin all week after!",
  "id" : 194160330262319105,
  "created_at" : "2012-04-22 20:26:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 3, 18 ],
      "id_str" : "19735370",
      "id" : 19735370
    }, {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 29, 44 ],
      "id_str" : "19735370",
      "id" : 19735370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QUo0oQoQ",
      "expanded_url" : "http:\/\/www.facebook.com\/events\/215769481869984\/",
      "display_url" : "facebook.com\/events\/2157694\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194156514464907264",
  "text" : "RT @BarCampBuffalo: UPDATED: @BarCampBuffalo #5 announced! Wed May 30 @ Pearl Street Brewery. 5p-7p mixer, 7p-9:30p presentations. RSVP: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BarCamp Buffalo",
        "screen_name" : "BarCampBuffalo",
        "indices" : [ 9, 24 ],
        "id_str" : "19735370",
        "id" : 19735370
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/QUo0oQoQ",
        "expanded_url" : "http:\/\/www.facebook.com\/events\/215769481869984\/",
        "display_url" : "facebook.com\/events\/2157694\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "194155120139845632",
    "text" : "UPDATED: @BarCampBuffalo #5 announced! Wed May 30 @ Pearl Street Brewery. 5p-7p mixer, 7p-9:30p presentations. RSVP: http:\/\/t.co\/QUo0oQoQ",
    "id" : 194155120139845632,
    "created_at" : "2012-04-22 20:06:02 +0000",
    "user" : {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "protected" : false,
      "id_str" : "19735370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444567584692645888\/A81UVOcA_normal.png",
      "id" : 19735370,
      "verified" : false
    }
  },
  "id" : 194156514464907264,
  "created_at" : "2012-04-22 20:11:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 6, 16 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194149869022220289",
  "geo" : { },
  "id_str" : "194151225208487936",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo @aquaranto both have facebook, no public RSVP option. We arent on the invite list",
  "id" : 194151225208487936,
  "in_reply_to_status_id" : 194149869022220289,
  "created_at" : "2012-04-22 19:50:33 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 34, 44 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194149135010631681",
  "geo" : { },
  "id_str" : "194149622707531776",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo can't RSVP...but myself and @aquaranto would love to go",
  "id" : 194149622707531776,
  "in_reply_to_status_id" : 194149135010631681,
  "created_at" : "2012-04-22 19:44:11 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194147160961462272",
  "text" : "Hey, who lives in ATL that's going to be in town tomorrow? Have a small favor to ask!",
  "id" : 194147160961462272,
  "created_at" : "2012-04-22 19:34:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193918104164777984",
  "geo" : { },
  "id_str" : "193918845839355904",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham Great Odin's Raven!",
  "id" : 193918845839355904,
  "in_reply_to_status_id" : 193918104164777984,
  "created_at" : "2012-04-22 04:27:10 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193908949387456512",
  "geo" : { },
  "id_str" : "193913811948937216",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant programming is not magic. You're missing out.",
  "id" : 193913811948937216,
  "in_reply_to_status_id" : 193908949387456512,
  "created_at" : "2012-04-22 04:07:10 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/nVUWNCtQ",
      "expanded_url" : "http:\/\/instagr.am\/p\/JtQHTKs6uk\/",
      "display_url" : "instagr.am\/p\/JtQHTKs6uk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "193906118840426497",
  "text" : "Diners! http:\/\/t.co\/nVUWNCtQ",
  "id" : 193906118840426497,
  "created_at" : "2012-04-22 03:36:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u043E\u043C\u0430\u0445\u0438\u043D \u041C\u0430\u0442\u0432\u0435\u0439",
      "screen_name" : "tastyjeff",
      "indices" : [ 0, 10 ],
      "id_str" : "2814032484",
      "id" : 2814032484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193905367355371520",
  "in_reply_to_user_id" : 21623813,
  "text" : "@tastyjeff you kicked ass tonight in CLT. Keep it up!",
  "id" : 193905367355371520,
  "created_at" : "2012-04-22 03:33:36 +0000",
  "in_reply_to_screen_name" : "TheJeffRichards",
  "in_reply_to_user_id_str" : "21623813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193905057450835969",
  "text" : "Drunk bought a DVD from a hilarious comic who looked sad since fans were taking photos with Chris Kattan. Bucket list?",
  "id" : 193905057450835969,
  "created_at" : "2012-04-22 03:32:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 71, 77 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/193798207111827456\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Wzgv6Dej",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArCCcU2CEAAaKqN.png",
      "id_str" : "193798207120216064",
      "id" : 193798207120216064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArCCcU2CEAAaKqN.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Wzgv6Dej"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193798207111827456",
  "text" : "After 5 years, TF2 is still a lot of fun. Ran out of bubblegum healing @mwn3d, we both died moments before the bomb. http:\/\/t.co\/Wzgv6Dej",
  "id" : 193798207111827456,
  "created_at" : "2012-04-21 20:27:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193763718486700032",
  "geo" : { },
  "id_str" : "193764207437684736",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky awesome, love breeds like that. Met a Norwegian elkhound over Easter, crazier than Ged.",
  "id" : 193764207437684736,
  "in_reply_to_status_id" : 193763718486700032,
  "created_at" : "2012-04-21 18:12:41 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193737902210035713",
  "text" : "Seeing Chris Kattan tonight in Charlotte! Awesome!",
  "id" : 193737902210035713,
  "created_at" : "2012-04-21 16:28:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193443671759261697",
  "text" : "Hotlanta. HAHAHHAHAHAHAHAHAHA SUCH AN ORIGINAL AND UNIQUE JOKE",
  "id" : 193443671759261697,
  "created_at" : "2012-04-20 20:59:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    }, {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 9, 22 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193402218572034048",
  "geo" : { },
  "id_str" : "193405378619392000",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash @stevenharman appreciate the offer, but I'd rather sleep in an airport than go through the TSA checkpoint again",
  "id" : 193405378619392000,
  "in_reply_to_status_id" : 193402218572034048,
  "created_at" : "2012-04-20 18:26:50 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193399766347038721",
  "text" : "That sad moment when you realize you could have driven to your destination for less hassle, time, and ball fondling.",
  "id" : 193399766347038721,
  "created_at" : "2012-04-20 18:04:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193399073053736960",
  "text" : "\"You'll make your connections herp derp\" Plane scheduled to land at 4:22, connection leaves at 4:15. LOL NOPE",
  "id" : 193399073053736960,
  "created_at" : "2012-04-20 18:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193398932875902977",
  "text" : "Fucking hate traveling via plane.",
  "id" : 193398932875902977,
  "created_at" : "2012-04-20 18:01:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193398891348103168",
  "text" : "Seriously, won't be able to make our connection now, no idea where our bags are so worried about picking another flight.",
  "id" : 193398891348103168,
  "created_at" : "2012-04-20 18:01:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193397940490993665",
  "text" : "To whoever clogged the toilet on this airplane, FUCK YOU.",
  "id" : 193397940490993665,
  "created_at" : "2012-04-20 17:57:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193387926141403137",
  "text" : "Awesome, there's a toilet problem on the plane, so might going to miss our connection at ATL. &gt;:|",
  "id" : 193387926141403137,
  "created_at" : "2012-04-20 17:17:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193374401666879491",
  "text" : "Another flight, another free massage! The agent even hummed a little tune while he was in my pants.",
  "id" : 193374401666879491,
  "created_at" : "2012-04-20 16:23:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193368900166090752",
  "text" : "@withloudhands this is it! \uD83C\uDFB6\uD83C\uDFB5",
  "id" : 193368900166090752,
  "created_at" : "2012-04-20 16:01:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193364258711539712",
  "geo" : { },
  "id_str" : "193368491305353218",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic not getting in until Tuesday! Sounds good!",
  "id" : 193368491305353218,
  "in_reply_to_status_id" : 193364258711539712,
  "created_at" : "2012-04-20 16:00:15 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193359913509060608",
  "text" : "RT @aquaranto: I think NPR just rick roll'd us...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "193358425768464384",
    "text" : "I think NPR just rick roll'd us...",
    "id" : 193358425768464384,
    "created_at" : "2012-04-20 15:20:15 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 193359913509060608,
  "created_at" : "2012-04-20 15:26:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193341020644179968",
  "text" : "Rescheduled flight for the same time. Woot!",
  "id" : 193341020644179968,
  "created_at" : "2012-04-20 14:11:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193335583530160128",
  "text" : "Awesome, flight out of Buffalo today canceled by Delta...now what?",
  "id" : 193335583530160128,
  "created_at" : "2012-04-20 13:49:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/sdUiPotQ",
      "expanded_url" : "http:\/\/nodejs.org\/api\/events.html#events_class_events_eventemitter",
      "display_url" : "nodejs.org\/api\/events.htm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193163715493888000",
  "text" : "Noticed that node.js has a stability level in their API docs. Dreaming, but maybe Rails should have something similar? http:\/\/t.co\/sdUiPotQ",
  "id" : 193163715493888000,
  "created_at" : "2012-04-20 02:26:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/hwWu8T9z",
      "expanded_url" : "http:\/\/vimeo.com\/38305542",
      "display_url" : "vimeo.com\/38305542"
    } ]
  },
  "geo" : { },
  "id_str" : "193143735205363712",
  "text" : "Blown away by this Dwarf Fortress animation. Such an epic game. http:\/\/t.co\/hwWu8T9z",
  "id" : 193143735205363712,
  "created_at" : "2012-04-20 01:07:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "Edwrd Ocampo-Gooding",
      "screen_name" : "edwardog",
      "indices" : [ 8, 17 ],
      "id_str" : "14251580",
      "id" : 14251580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193079799470755841",
  "geo" : { },
  "id_str" : "193079923374698499",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal @edwardog LOLOLOLOL GPL",
  "id" : 193079923374698499,
  "in_reply_to_status_id" : 193079799470755841,
  "created_at" : "2012-04-19 20:53:35 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193073185497944064",
  "text" : "Some days you eat the bugs. Some days, the bugs eat you.",
  "id" : 193073185497944064,
  "created_at" : "2012-04-19 20:26:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 42 ],
      "url" : "https:\/\/t.co\/CJFDEf4v",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZcFGrWjOX0E",
      "display_url" : "youtube.com\/watch?v=ZcFGrW\u2026"
    }, {
      "indices" : [ 43, 64 ],
      "url" : "https:\/\/t.co\/Rko11yR6",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=if-WrgfGxeI",
      "display_url" : "youtube.com\/watch?v=if-Wrg\u2026"
    }, {
      "indices" : [ 65, 86 ],
      "url" : "https:\/\/t.co\/EDAUPa4b",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=EYTOZU9rRj8",
      "display_url" : "youtube.com\/watch?v=EYTOZU\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "192978902711410688",
  "geo" : { },
  "id_str" : "192980565052489728",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight 3 songs are: https:\/\/t.co\/CJFDEf4v https:\/\/t.co\/Rko11yR6 https:\/\/t.co\/EDAUPa4b",
  "id" : 192980565052489728,
  "in_reply_to_status_id" : 192978902711410688,
  "created_at" : "2012-04-19 14:18:46 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/A7uZKDPM",
      "expanded_url" : "http:\/\/www1.rollingstone.com\/hearitnow\/player\/rush.html",
      "display_url" : "www1.rollingstone.com\/hearitnow\/play\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192977742172659712",
  "text" : "As usual, the new Rush album will take a bit to grow on me. Excited to hear the rest. http:\/\/t.co\/A7uZKDPM",
  "id" : 192977742172659712,
  "created_at" : "2012-04-19 14:07:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192808323047890944",
  "text" : "From that same article... \"rewrote the entire app, and deployed it live at 3 a.m. that same night\" ...what the fuck?",
  "id" : 192808323047890944,
  "created_at" : "2012-04-19 02:54:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192807644505976833",
  "text" : "valid ruby code: herpderp = -&gt; foo \u007B puts foo \u007D; herpderp.(2)",
  "id" : 192807644505976833,
  "created_at" : "2012-04-19 02:51:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/qMFGTJeZ",
      "expanded_url" : "http:\/\/www.gamasutra.com\/view\/news\/168799\/Scale_Something_How_Draw_Something_rode_its_rocket_ship_of_growth.php",
      "display_url" : "gamasutra.com\/view\/news\/1687\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192805986908647424",
  "text" : "\" at one point we were up for around 60-plus hours straight, never leaving the computer.\" Why is this a badge of honor? http:\/\/t.co\/qMFGTJeZ",
  "id" : 192805986908647424,
  "created_at" : "2012-04-19 02:45:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192799771134664705",
  "text" : "RT @drbrain: I find it incomprehensible how much google can mess up a mailing list archive\/web interface",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192794324302438400",
    "text" : "I find it incomprehensible how much google can mess up a mailing list archive\/web interface",
    "id" : 192794324302438400,
    "created_at" : "2012-04-19 01:58:43 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 192799771134664705,
  "created_at" : "2012-04-19 02:20:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/zIcpecMC",
      "expanded_url" : "http:\/\/fc01.deviantart.net\/fs71\/i\/2010\/237\/9\/0\/Michaelsoft_Binbows_by_goukai.jpg",
      "display_url" : "fc01.deviantart.net\/fs71\/i\/2010\/23\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192789730012839937",
  "text" : "Current status: http:\/\/t.co\/zIcpecMC",
  "id" : 192789730012839937,
  "created_at" : "2012-04-19 01:40:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192772927937200129",
  "text" : "Apparently it's Shit In The House Day at the Quaranto's. What the fuck.",
  "id" : 192772927937200129,
  "created_at" : "2012-04-19 00:33:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/mkx7yTK7",
      "expanded_url" : "http:\/\/gifs.gifbin.com\/1235983886_long_jump_fail.gif",
      "display_url" : "gifs.gifbin.com\/1235983886_lon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192711310180491265",
  "text" : "Current joke status: http:\/\/t.co\/mkx7yTK7",
  "id" : 192711310180491265,
  "created_at" : "2012-04-18 20:28:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Fults",
      "screen_name" : "h3h",
      "indices" : [ 0, 4 ],
      "id_str" : "59503",
      "id" : 59503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192710994181636096",
  "geo" : { },
  "id_str" : "192711166177447936",
  "in_reply_to_user_id" : 59503,
  "text" : "@h3h I fail at jokes",
  "id" : 192711166177447936,
  "in_reply_to_status_id" : 192710994181636096,
  "created_at" : "2012-04-18 20:28:17 +0000",
  "in_reply_to_screen_name" : "h3h",
  "in_reply_to_user_id_str" : "59503",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neb Gib",
      "screen_name" : "kcolc_neb_gib",
      "indices" : [ 27, 41 ],
      "id_str" : "2329510540",
      "id" : 2329510540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192710419440345088",
  "text" : "Twitter bot idea: Register @KCOLC_NEB_GIB, tweet GONB GONB GONB every hour.",
  "id" : 192710419440345088,
  "created_at" : "2012-04-18 20:25:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192709659084333057",
  "text" : ":( ruby -e '\"#$\"'",
  "id" : 192709659084333057,
  "created_at" : "2012-04-18 20:22:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192704600866951169",
  "geo" : { },
  "id_str" : "192706597821218816",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn deep",
  "id" : 192706597821218816,
  "in_reply_to_status_id" : 192704600866951169,
  "created_at" : "2012-04-18 20:10:07 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Neves",
      "screen_name" : "arthurnn",
      "indices" : [ 0, 9 ],
      "id_str" : "213767432",
      "id" : 213767432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192696904839217152",
  "geo" : { },
  "id_str" : "192699854848401408",
  "in_reply_to_user_id" : 213767432,
  "text" : "@arthurnn Worked here. Something sounds wrong with your browser.",
  "id" : 192699854848401408,
  "in_reply_to_status_id" : 192696904839217152,
  "created_at" : "2012-04-18 19:43:20 +0000",
  "in_reply_to_screen_name" : "arthurnn",
  "in_reply_to_user_id_str" : "213767432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 32 ],
      "url" : "https:\/\/t.co\/5BVRg8vu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=xMOcyCLZHBQ",
      "display_url" : "youtube.com\/watch?v=xMOcyC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "192691506816098305",
  "geo" : { },
  "id_str" : "192691743181897728",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh https:\/\/t.co\/5BVRg8vu ;)",
  "id" : 192691743181897728,
  "in_reply_to_status_id" : 192691506816098305,
  "created_at" : "2012-04-18 19:11:06 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192691413639639041",
  "text" : "Correction: Whoever replaces email, do us all a favor and only allow address with the local part as: [A-Za-z0-9\\.]\n\nLove, Nick.",
  "id" : 192691413639639041,
  "created_at" : "2012-04-18 19:09:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192691133057478657",
  "geo" : { },
  "id_str" : "192691280822808577",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh for email addresses. should have clarified.",
  "id" : 192691280822808577,
  "in_reply_to_status_id" : 192691133057478657,
  "created_at" : "2012-04-18 19:09:16 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Neves",
      "screen_name" : "arthurnn",
      "indices" : [ 0, 9 ],
      "id_str" : "213767432",
      "id" : 213767432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 99 ],
      "url" : "https:\/\/t.co\/SAp8fxUK",
      "expanded_url" : "https:\/\/rubygems.org\/sign_up",
      "display_url" : "rubygems.org\/sign_up"
    } ]
  },
  "in_reply_to_status_id_str" : "192676290334162944",
  "geo" : { },
  "id_str" : "192691195569381376",
  "in_reply_to_user_id" : 213767432,
  "text" : "@arthurnn that definitely works for me...are you signed in already? o_O `curl https:\/\/t.co\/SAp8fxUK -I` works too",
  "id" : 192691195569381376,
  "in_reply_to_status_id" : 192676290334162944,
  "created_at" : "2012-04-18 19:08:55 +0000",
  "in_reply_to_screen_name" : "arthurnn",
  "in_reply_to_user_id_str" : "213767432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192690726344208384",
  "text" : "Whoever replaces email, do us all a favor and only allow: [A-Za-z0-9\\.]\n\nLove, Nick.",
  "id" : 192690726344208384,
  "created_at" : "2012-04-18 19:07:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192655704497209344",
  "text" : "What's cooler than a billion dollars? Journalists stopping use of this cliche, worthless, drone of a movie quote.",
  "id" : 192655704497209344,
  "created_at" : "2012-04-18 16:47:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/MUdNKHsY",
      "expanded_url" : "http:\/\/arstechnica.com\/business\/news\/2012\/04\/zuckerberg-closed-instagram-deal-without-facebook-board.ars",
      "display_url" : "arstechnica.com\/business\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192654953704206337",
  "text" : "\"While the Instagram founder initially sought $2 billion...\" What!!? http:\/\/t.co\/MUdNKHsY",
  "id" : 192654953704206337,
  "created_at" : "2012-04-18 16:44:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/GNTGeHCi",
      "expanded_url" : "http:\/\/www.ruby-doc.org\/core-1.9.3\/Module.html#method-i-3C",
      "display_url" : "ruby-doc.org\/core-1.9.3\/Mod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192434760746942464",
  "text" : "Ahh, Ruby: Module#&lt; and Module#&lt;= are a thing. http:\/\/t.co\/GNTGeHCi",
  "id" : 192434760746942464,
  "created_at" : "2012-04-18 02:09:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/GNTGeHCi",
      "expanded_url" : "http:\/\/www.ruby-doc.org\/core-1.9.3\/Module.html#method-i-3C",
      "display_url" : "ruby-doc.org\/core-1.9.3\/Mod\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "192433388135792640",
  "geo" : { },
  "id_str" : "192434629922398208",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham looks like it's on Module. http:\/\/t.co\/GNTGeHCi",
  "id" : 192434629922398208,
  "in_reply_to_status_id" : 192433388135792640,
  "created_at" : "2012-04-18 02:09:25 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192409541940482049",
  "geo" : { },
  "id_str" : "192427135296741376",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude primed over a black set for $90. the other colors were way too ugly.",
  "id" : 192427135296741376,
  "in_reply_to_status_id" : 192409541940482049,
  "created_at" : "2012-04-18 01:39:38 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/M9xi2plL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5hfYJsQAhl0",
      "display_url" : "youtube.com\/watch?v=5hfYJs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192382951017811970",
  "text" : "Current status: http:\/\/t.co\/M9xi2plL",
  "id" : 192382951017811970,
  "created_at" : "2012-04-17 22:44:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/78Ly8emt",
      "expanded_url" : "http:\/\/www.oracle.com\/us\/corporate\/features\/opening-slides-1592541.pdf",
      "display_url" : "oracle.com\/us\/corporate\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192355534500933632",
  "text" : "I don't care who wins or loses this battle, I'm just glad I don't work with Java or Android. http:\/\/t.co\/78Ly8emt",
  "id" : 192355534500933632,
  "created_at" : "2012-04-17 20:55:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/nTDj9YsG",
      "expanded_url" : "http:\/\/railsinstaller.org\/",
      "display_url" : "railsinstaller.org"
    } ]
  },
  "in_reply_to_status_id_str" : "192347232962486273",
  "geo" : { },
  "id_str" : "192351875398516736",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror http:\/\/t.co\/nTDj9YsG",
  "id" : 192351875398516736,
  "in_reply_to_status_id" : 192347232962486273,
  "created_at" : "2012-04-17 20:40:35 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192281910414802944",
  "geo" : { },
  "id_str" : "192282181362655232",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef word, i'll head down. probably going to figure out lunch here, don't wait.",
  "id" : 192282181362655232,
  "in_reply_to_status_id" : 192281910414802944,
  "created_at" : "2012-04-17 16:03:39 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Buryta",
      "screen_name" : "cburyta",
      "indices" : [ 0, 8 ],
      "id_str" : "5875982",
      "id" : 5875982
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 9, 19 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192260752776761344",
  "geo" : { },
  "id_str" : "192281293424304130",
  "in_reply_to_user_id" : 5875982,
  "text" : "@cburyta @magnachef are you guys still there? anyone else?",
  "id" : 192281293424304130,
  "in_reply_to_status_id" : 192260752776761344,
  "created_at" : "2012-04-17 16:00:07 +0000",
  "in_reply_to_screen_name" : "cburyta",
  "in_reply_to_user_id_str" : "5875982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/XrqpIZm9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0Nm7-EuctOs&sns=em",
      "display_url" : "youtube.com\/watch?v=0Nm7-E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192277701170700289",
  "text" : "SHUT UP AND TAKE MY MONEY! http:\/\/t.co\/XrqpIZm9",
  "id" : 192277701170700289,
  "created_at" : "2012-04-17 15:45:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/jwm0W0yO",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/aeamich\/7087473325\/",
      "display_url" : "flickr.com\/photos\/aeamich\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192272734535958528",
  "text" : "Why are we cheering this on? Why is it amazing? This is depressing, not exciting. http:\/\/t.co\/jwm0W0yO",
  "id" : 192272734535958528,
  "created_at" : "2012-04-17 15:26:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Wilk",
      "screen_name" : "josephwilk",
      "indices" : [ 0, 11 ],
      "id_str" : "14321259",
      "id" : 14321259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192245607618973696",
  "geo" : { },
  "id_str" : "192247173742731264",
  "in_reply_to_user_id" : 14321259,
  "text" : "@josephwilk skip and go to the marriott in Kendall (Cambridge). On top of the Red Line and next to Meadhall. :D",
  "id" : 192247173742731264,
  "in_reply_to_status_id" : 192245607618973696,
  "created_at" : "2012-04-17 13:44:32 +0000",
  "in_reply_to_screen_name" : "josephwilk",
  "in_reply_to_user_id_str" : "14321259",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/lZGN3mX6",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3163-making-shit-work-is-everyones-job",
      "display_url" : "37signals.com\/svn\/posts\/3163\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192069739395284992",
  "text" : "RT @dhh: Making shit work is everyone's job, http:\/\/t.co\/lZGN3mX6, departmental hedges grow fast and tall if not trimmed with vigor.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/lZGN3mX6",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3163-making-shit-work-is-everyones-job",
        "display_url" : "37signals.com\/svn\/posts\/3163\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "192068711283310592",
    "text" : "Making shit work is everyone's job, http:\/\/t.co\/lZGN3mX6, departmental hedges grow fast and tall if not trimmed with vigor.",
    "id" : 192068711283310592,
    "created_at" : "2012-04-17 01:55:23 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 192069739395284992,
  "created_at" : "2012-04-17 01:59:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/akjVrhU3",
      "expanded_url" : "http:\/\/i.imgur.com\/OoWh6.jpg",
      "display_url" : "i.imgur.com\/OoWh6.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "192067150498906112",
  "text" : "Lesson of the day: http:\/\/t.co\/akjVrhU3",
  "id" : 192067150498906112,
  "created_at" : "2012-04-17 01:49:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 0, 13 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192038366341107712",
  "geo" : { },
  "id_str" : "192040540584411136",
  "in_reply_to_user_id" : 9887162,
  "text" : "@markimbriaco thanks! Fielded a lot of questions about what on call means from friends lately, figured it would be a good write up",
  "id" : 192040540584411136,
  "in_reply_to_status_id" : 192038366341107712,
  "created_at" : "2012-04-17 00:03:27 +0000",
  "in_reply_to_screen_name" : "markimbriaco",
  "in_reply_to_user_id_str" : "9887162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 0, 13 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192036707057680384",
  "geo" : { },
  "id_str" : "192038249475211264",
  "in_reply_to_user_id" : 9887162,
  "text" : "@markimbriaco seriously. Lots of closed minds.",
  "id" : 192038249475211264,
  "in_reply_to_status_id" : 192036707057680384,
  "created_at" : "2012-04-16 23:54:21 +0000",
  "in_reply_to_screen_name" : "markimbriaco",
  "in_reply_to_user_id_str" : "9887162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 3, 16 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192037957711052800",
  "text" : "RT @markimbriaco: The HN response to the 37signals on-call programmer post is incredibly derogatory toward sysadmins. Hard to read this  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192036707057680384",
    "text" : "The HN response to the 37signals on-call programmer post is incredibly derogatory toward sysadmins. Hard to read this much  ignorance.",
    "id" : 192036707057680384,
    "created_at" : "2012-04-16 23:48:13 +0000",
    "user" : {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "protected" : false,
      "id_str" : "9887162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471493631283441664\/aiwoVRj7_normal.jpeg",
      "id" : 9887162,
      "verified" : false
    }
  },
  "id" : 192037957711052800,
  "created_at" : "2012-04-16 23:53:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/pG6PCWJE",
      "expanded_url" : "http:\/\/blogs.ocweekly.com\/heardmentality\/2012\/04\/the_10_most_awkward_dance_move.php?print=true",
      "display_url" : "blogs.ocweekly.com\/heardmentality\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191998456213155840",
  "text" : "Correction, dumb dancing people gifs on one page: http:\/\/t.co\/pG6PCWJE",
  "id" : 191998456213155840,
  "created_at" : "2012-04-16 21:16:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/2qBRSG31",
      "expanded_url" : "http:\/\/blogs.ocweekly.com\/heardmentality\/2012\/04\/the_10_most_awkward_dance_move.php",
      "display_url" : "blogs.ocweekly.com\/heardmentality\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191998151505346560",
  "text" : "I fully approve of this use of gifs: http:\/\/t.co\/2qBRSG31",
  "id" : 191998151505346560,
  "created_at" : "2012-04-16 21:15:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/Ns6eMQXF",
      "expanded_url" : "http:\/\/gem.version.to",
      "display_url" : "gem.version.to"
    } ]
  },
  "in_reply_to_status_id_str" : "191987953227141122",
  "geo" : { },
  "id_str" : "191988747557027840",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik uhhh.... http:\/\/t.co\/Ns6eMQXF_s.reverse! ?",
  "id" : 191988747557027840,
  "in_reply_to_status_id" : 191987953227141122,
  "created_at" : "2012-04-16 20:37:39 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    }, {
      "name" : "heatherlane",
      "screen_name" : "heatherlane",
      "indices" : [ 8, 20 ],
      "id_str" : "17866369",
      "id" : 17866369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191986078809460736",
  "geo" : { },
  "id_str" : "191986697595142145",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh @heatherlane whoa! congrats!",
  "id" : 191986697595142145,
  "in_reply_to_status_id" : 191986078809460736,
  "created_at" : "2012-04-16 20:29:30 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 54, 64 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/I38wbV4K",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3162-the-on-call-programmer",
      "display_url" : "37signals.com\/svn\/posts\/3162\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191968420751867904",
  "text" : "Wrote about what it means to be an on-call programmer @37signals: http:\/\/t.co\/I38wbV4K",
  "id" : 191968420751867904,
  "created_at" : "2012-04-16 19:16:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191887667607252992",
  "text" : "Looking to Prime some new luggage this week. Any recommendations for sets that don't suck?",
  "id" : 191887667607252992,
  "created_at" : "2012-04-16 13:55:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191883888702914560",
  "text" : "Patio desk, ACTIVATE! (for the first time since the March heat wave, too!)",
  "id" : 191883888702914560,
  "created_at" : "2012-04-16 13:40:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191608050723995648",
  "geo" : { },
  "id_str" : "191608389149798400",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef moving closer to elmwood!!!?",
  "id" : 191608389149798400,
  "in_reply_to_status_id" : 191608050723995648,
  "created_at" : "2012-04-15 19:26:14 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/4WzUXVtW",
      "expanded_url" : "http:\/\/instagr.am\/p\/JbGJyOs6tf\/",
      "display_url" : "instagr.am\/p\/JbGJyOs6tf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "191350922062995457",
  "text" : "Chef friends are the best friends. http:\/\/t.co\/4WzUXVtW",
  "id" : 191350922062995457,
  "created_at" : "2012-04-15 02:23:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH Racing",
      "screen_name" : "dhhracing",
      "indices" : [ 0, 10 ],
      "id_str" : "266523231",
      "id" : 266523231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191338306506735616",
  "geo" : { },
  "id_str" : "191338488740843520",
  "in_reply_to_user_id" : 266523231,
  "text" : "@dhhracing dang! Espn is 12 mins behind. Was fun to watch !",
  "id" : 191338488740843520,
  "in_reply_to_status_id" : 191338306506735616,
  "created_at" : "2012-04-15 01:33:45 +0000",
  "in_reply_to_screen_name" : "dhhracing",
  "in_reply_to_user_id_str" : "266523231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH Racing",
      "screen_name" : "dhhracing",
      "indices" : [ 0, 10 ],
      "id_str" : "266523231",
      "id" : 266523231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191336333439008768",
  "geo" : { },
  "id_str" : "191337954139054080",
  "in_reply_to_user_id" : 266523231,
  "text" : "@dhhracing are you going back out??!",
  "id" : 191337954139054080,
  "in_reply_to_status_id" : 191336333439008768,
  "created_at" : "2012-04-15 01:31:37 +0000",
  "in_reply_to_screen_name" : "dhhracing",
  "in_reply_to_user_id_str" : "266523231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH Racing",
      "screen_name" : "dhhracing",
      "indices" : [ 0, 10 ],
      "id_str" : "266523231",
      "id" : 266523231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191329404499132416",
  "geo" : { },
  "id_str" : "191333332846518272",
  "in_reply_to_user_id" : 266523231,
  "text" : "@dhhracing watching on espn! \/play yeah",
  "id" : 191333332846518272,
  "in_reply_to_status_id" : 191329404499132416,
  "created_at" : "2012-04-15 01:13:16 +0000",
  "in_reply_to_screen_name" : "dhhracing",
  "in_reply_to_user_id_str" : "266523231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 34, 40 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191265031156015105",
  "text" : "I've determined that I'm going to @chorn's fortress when the zombie apocalypse comes.",
  "id" : 191265031156015105,
  "created_at" : "2012-04-14 20:41:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/0XkEVJnY",
      "expanded_url" : "http:\/\/instagr.am\/p\/JaV9lWM6mH\/",
      "display_url" : "instagr.am\/p\/JaV9lWM6mH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "191244950543929344",
  "text" : "Powered by induction. No wires! #barcamproc http:\/\/t.co\/0XkEVJnY",
  "id" : 191244950543929344,
  "created_at" : "2012-04-14 19:22:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STUPID_TEACHER",
      "screen_name" : "stupid_teacher",
      "indices" : [ 11, 26 ],
      "id_str" : "553770186",
      "id" : 553770186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191243557888208897",
  "text" : "Apparently @STUPID_TEACHER is now mega-suspended. womp womp.",
  "id" : 191243557888208897,
  "created_at" : "2012-04-14 19:16:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STUPID_TEACHER",
      "screen_name" : "stupid_teacher",
      "indices" : [ 16, 31 ],
      "id_str" : "553770186",
      "id" : 553770186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191242969741930496",
  "text" : "Oops, hooked up @STUPID_TEACHER to my own account...trying to block the stupid \"CHAMBER OF SECRETS\" replies.",
  "id" : 191242969741930496,
  "created_at" : "2012-04-14 19:14:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Aronoff",
      "screen_name" : "telemachus",
      "indices" : [ 0, 11 ],
      "id_str" : "131991214",
      "id" : 131991214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191239871535394817",
  "geo" : { },
  "id_str" : "191240277514653696",
  "in_reply_to_user_id" : 131991214,
  "text" : "@telemachus yeah, had to shut retweets off. pong!!",
  "id" : 191240277514653696,
  "in_reply_to_status_id" : 191239871535394817,
  "created_at" : "2012-04-14 19:03:29 +0000",
  "in_reply_to_screen_name" : "telemachus",
  "in_reply_to_user_id_str" : "131991214",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STUPID_TEACHER",
      "screen_name" : "stupid_teacher",
      "indices" : [ 42, 57 ],
      "id_str" : "553770186",
      "id" : 553770186
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/191238911740223488\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/NwKHKoRd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqdqxunCIAAw3Ff.png",
      "id_str" : "191238911744417792",
      "id" : 191238911744417792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqdqxunCIAAw3Ff.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 654
      } ],
      "display_url" : "pic.twitter.com\/NwKHKoRd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191238911740223488",
  "text" : "Not used to Emoji showing up in terminal, @STUPID_TEACHER brings out many. http:\/\/t.co\/NwKHKoRd",
  "id" : 191238911740223488,
  "created_at" : "2012-04-14 18:58:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191237048005427200",
  "text" : "Watching the twitter real-time stream for \"bathroom\" is humanity-level-depressing.",
  "id" : 191237048005427200,
  "created_at" : "2012-04-14 18:50:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chilton",
      "screen_name" : "ichilton",
      "indices" : [ 0, 9 ],
      "id_str" : "20507434",
      "id" : 20507434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191233486907121664",
  "geo" : { },
  "id_str" : "191234020590358530",
  "in_reply_to_user_id" : 20507434,
  "text" : "@ichilton i'll do one soon-ish...still working on it making it not be banned",
  "id" : 191234020590358530,
  "in_reply_to_status_id" : 191233486907121664,
  "created_at" : "2012-04-14 18:38:38 +0000",
  "in_reply_to_screen_name" : "ichilton",
  "in_reply_to_user_id_str" : "20507434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STUPID_TEACHER",
      "screen_name" : "stupid_teacher",
      "indices" : [ 8, 23 ],
      "id_str" : "553770186",
      "id" : 553770186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191230367536123904",
  "text" : "Bummer. @STUPID_TEACHER keeps getting suspended.",
  "id" : 191230367536123904,
  "created_at" : "2012-04-14 18:24:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STUPID_TEACHER",
      "screen_name" : "stupid_teacher",
      "indices" : [ 71, 86 ],
      "id_str" : "553770186",
      "id" : 553770186
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191229586137288704",
  "text" : "Whipped together a quick twitter bot for a #barcamproc lightning talk: @STUPID_TEACHER",
  "id" : 191229586137288704,
  "created_at" : "2012-04-14 18:21:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenna Kempie",
      "screen_name" : "JennaKempie",
      "indices" : [ 0, 12 ],
      "id_str" : "198132636",
      "id" : 198132636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191226946150076419",
  "geo" : { },
  "id_str" : "191228903115853825",
  "in_reply_to_user_id" : 198132636,
  "text" : "@JennaKempie hey! been meaning to say hi! :)",
  "id" : 191228903115853825,
  "in_reply_to_status_id" : 191226946150076419,
  "created_at" : "2012-04-14 18:18:18 +0000",
  "in_reply_to_screen_name" : "JennaKempie",
  "in_reply_to_user_id_str" : "198132636",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191228136208343042",
  "text" : "Achievement unlocked: Get your first twitter bot account suspension!",
  "id" : 191228136208343042,
  "created_at" : "2012-04-14 18:15:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/YM5ApH6l",
      "expanded_url" : "http:\/\/30.media.tumblr.com\/tumblr_m2glhx9fj11rrgr1no1_500.jpg",
      "display_url" : "30.media.tumblr.com\/tumblr_m2glhx9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191193660191281153",
  "text" : "Current status: http:\/\/t.co\/YM5ApH6l",
  "id" : 191193660191281153,
  "created_at" : "2012-04-14 15:58:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 37, 47 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 83, 90 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191191906863153152",
  "text" : "Just upgraded Fog from 0.7 to 1.3 on @gemcutter, went 100% smoothly. Huge props to @geemus and crew.",
  "id" : 191191906863153152,
  "created_at" : "2012-04-14 15:51:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191188728956469248",
  "geo" : { },
  "id_str" : "191189227134918656",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky use Divvy.",
  "id" : 191189227134918656,
  "in_reply_to_status_id" : 191188728956469248,
  "created_at" : "2012-04-14 15:40:38 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191164192710070272",
  "text" : "I love git rerere. Merged a branch, resolved conflicts. Decided I wanted to rebase it instead, git brings over the resolution automatically.",
  "id" : 191164192710070272,
  "created_at" : "2012-04-14 14:01:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191149568015089664",
  "text" : "It's 9AM and we're already at operating systems arguments. #barcamproc",
  "id" : 191149568015089664,
  "created_at" : "2012-04-14 13:03:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190996620509319168",
  "text" : "OH \"do women push their nipples into their body to make their boobs look look like bagels?\" \"sometimes\"",
  "id" : 190996620509319168,
  "created_at" : "2012-04-14 02:55:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/BpoTwOFt",
      "expanded_url" : "http:\/\/instagr.am\/p\/JYkNoUM6gm\/",
      "display_url" : "instagr.am\/p\/JYkNoUM6gm\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8787065819, -78.8657026201 ]
  },
  "id_str" : "190994740022476801",
  "text" : "Chefs. Enough said.  @ Chef's Restaurant http:\/\/t.co\/BpoTwOFt",
  "id" : 190994740022476801,
  "created_at" : "2012-04-14 02:47:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tavish",
      "screen_name" : "ntavish",
      "indices" : [ 0, 8 ],
      "id_str" : "16329367",
      "id" : 16329367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190908760091402243",
  "geo" : { },
  "id_str" : "190918007583809536",
  "in_reply_to_user_id" : 16329367,
  "text" : "@ntavish it's MIT, and the content is under CC. Check out the repo for more info.",
  "id" : 190918007583809536,
  "in_reply_to_status_id" : 190908760091402243,
  "created_at" : "2012-04-13 21:42:54 +0000",
  "in_reply_to_screen_name" : "ntavish",
  "in_reply_to_user_id_str" : "16329367",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/a6VY3iRq",
      "expanded_url" : "http:\/\/blog.engineering.kiip.me\/post\/20988881092\/a-year-with-mongodb",
      "display_url" : "blog.engineering.kiip.me\/post\/209888810\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190893520826015744",
  "text" : "\"Over the past 6 months, we\u2019ve \u201Cscaled\u201D MongoDB by moving data off of it.\" http:\/\/t.co\/a6VY3iRq",
  "id" : 190893520826015744,
  "created_at" : "2012-04-13 20:05:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 0, 6 ],
      "id_str" : "44282335",
      "id" : 44282335
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 105, 113 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190891359119474689",
  "geo" : { },
  "id_str" : "190891676124983296",
  "in_reply_to_user_id" : 44282335,
  "text" : "@dozba it's not perfect, nothing is. rvm, rbenv helps immensely. gist some code and we can help out. \/cc @evanphx",
  "id" : 190891676124983296,
  "in_reply_to_status_id" : 190891359119474689,
  "created_at" : "2012-04-13 19:58:16 +0000",
  "in_reply_to_screen_name" : "dozba",
  "in_reply_to_user_id_str" : "44282335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 14, 25 ],
      "id_str" : "20751318",
      "id" : 20751318
    }, {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 75, 82 ],
      "id_str" : "15507545",
      "id" : 15507545
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 83, 89 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190891414429769730",
  "text" : "Just realized @barcamproc starts at 8:30AM? Does that time even exist? \/cc @hiteak @chorn",
  "id" : 190891414429769730,
  "created_at" : "2012-04-13 19:57:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 22, 35 ],
      "id_str" : "19386993",
      "id" : 19386993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190793122027020289",
  "text" : "Bacon cream cheese at @coworkingroc. Would expect no less.",
  "id" : 190793122027020289,
  "created_at" : "2012-04-13 13:26:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 24, 30 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 32, 39 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 45, 53 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/JbQd5ODL",
      "expanded_url" : "http:\/\/groups.google.com\/group\/gemcutter\/browse_thread\/thread\/3524bfea0b7d893d",
      "display_url" : "groups.google.com\/group\/gemcutte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190647088441327617",
  "text" : "Wherein I give props to @cmeik, @sferik, and @evanphx. Thanks for making RubyGems and Ruby awesome! http:\/\/t.co\/JbQd5ODL",
  "id" : 190647088441327617,
  "created_at" : "2012-04-13 03:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/ghM5a1WT",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Buffalo_buffalo_Buffalo_buffalo_buffalo_buffalo_Buffalo_buffalo",
      "display_url" : "en.wikipedia.org\/wiki\/Buffalo_b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "190641878574710784",
  "geo" : { },
  "id_str" : "190642847551209472",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy sorry dude, has nothing on http:\/\/t.co\/ghM5a1WT",
  "id" : 190642847551209472,
  "in_reply_to_status_id" : 190641878574710784,
  "created_at" : "2012-04-13 03:29:31 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 57, 67 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190642373607432193",
  "text" : "RT @rubygems_status: Sounding an all clear! Say hello to @gemcutter, now on Rails 3.2!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gemcutter",
        "screen_name" : "gemcutter",
        "indices" : [ 36, 46 ],
        "id_str" : "42259749",
        "id" : 42259749
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190642326035628033",
    "text" : "Sounding an all clear! Say hello to @gemcutter, now on Rails 3.2!",
    "id" : 190642326035628033,
    "created_at" : "2012-04-13 03:27:27 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 190642373607432193,
  "created_at" : "2012-04-13 03:27:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 66, 82 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/bdjxoR36",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "190640337469976576",
  "text" : "Currently debugging issues on http:\/\/t.co\/bdjxoR36. Please follow @rubygems_status for more info!",
  "id" : 190640337469976576,
  "created_at" : "2012-04-13 03:19:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/MpCzL7hQ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ym-toH7EF1c",
      "display_url" : "youtube.com\/watch?v=ym-toH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190589407181545472",
  "text" : "Current status: http:\/\/t.co\/MpCzL7hQ",
  "id" : 190589407181545472,
  "created_at" : "2012-04-12 23:57:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190589308535717888",
  "text" : "Wow, this sushi is delicious but it is filling.",
  "id" : 190589308535717888,
  "created_at" : "2012-04-12 23:56:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190562498053808128",
  "geo" : { },
  "id_str" : "190562616865849345",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @sferik  bingo bango, yep",
  "id" : 190562616865849345,
  "in_reply_to_status_id" : 190562498053808128,
  "created_at" : "2012-04-12 22:10:43 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 9, 18 ],
      "id_str" : "9267332",
      "id" : 9267332
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 77, 84 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190561802273300481",
  "geo" : { },
  "id_str" : "190562266008129536",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @rtomayko sounds like a good night to deploy as well. thoughts? \/cc @sferik",
  "id" : 190562266008129536,
  "in_reply_to_status_id" : 190561802273300481,
  "created_at" : "2012-04-12 22:09:19 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190554975846408192",
  "geo" : { },
  "id_str" : "190555334421647360",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape you ate the whole wheel of cheese? how'd you do that? i'm not even mad, that's amazing!",
  "id" : 190555334421647360,
  "in_reply_to_status_id" : 190554975846408192,
  "created_at" : "2012-04-12 21:41:46 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RIT SSE",
      "screen_name" : "rit_sse",
      "indices" : [ 35, 43 ],
      "id_str" : "345915846",
      "id" : 345915846
    }, {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 57, 70 ],
      "id_str" : "19386993",
      "id" : 19386993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190555030305251328",
  "text" : "Heading to RIT tomorrow to talk at @rit_sse, dropping by @coworkingroc in the morning! Excited to visit the Roc again.",
  "id" : 190555030305251328,
  "created_at" : "2012-04-12 21:40:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190547767926591488",
  "geo" : { },
  "id_str" : "190548393683206144",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton using rubyracer makes it a little faster, but YMMV",
  "id" : 190548393683206144,
  "in_reply_to_status_id" : 190547767926591488,
  "created_at" : "2012-04-12 21:14:11 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/bdjxoR36",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 82, 103 ],
      "url" : "https:\/\/t.co\/BYDBORnb",
      "expanded_url" : "https:\/\/gist.github.com\/a5e04ea2636d14288638",
      "display_url" : "gist.github.com\/a5e04ea2636d14\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190546893481316352",
  "text" : "300 new gem pushes a day now on http:\/\/t.co\/bdjxoR36, over the past 30 days. Wow. https:\/\/t.co\/BYDBORnb",
  "id" : 190546893481316352,
  "created_at" : "2012-04-12 21:08:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/bdjxoR36",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/QweVtosw",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/qrush\/p\/test-driven-development",
      "display_url" : "speakerdeck.com\/u\/qrush\/p\/test\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190545373864013824",
  "text" : "There's been over 100 million gem downloads on http:\/\/t.co\/bdjxoR36 since I gave this talk in February. Holy crap. http:\/\/t.co\/QweVtosw",
  "id" : 190545373864013824,
  "created_at" : "2012-04-12 21:02:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190509296587513857",
  "geo" : { },
  "id_str" : "190512114211897345",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton i think this is just ruby spoiling us. sometimes you want that function, not just call it.",
  "id" : 190512114211897345,
  "in_reply_to_status_id" : 190509296587513857,
  "created_at" : "2012-04-12 18:50:02 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/O5GnXjzm",
      "expanded_url" : "http:\/\/coffeescript.org\/#loops",
      "display_url" : "coffeescript.org\/#loops"
    } ]
  },
  "geo" : { },
  "id_str" : "190511012187873280",
  "text" : "Check out the `do` keyword here: http:\/\/t.co\/O5GnXjzm",
  "id" : 190511012187873280,
  "created_at" : "2012-04-12 18:45:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 80, 92 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190510873616457728",
  "text" : "Learned about for...in, do -&gt; in CoffeeScript today. Every pull request from @sstephenson has some wild, awesome code in it.",
  "id" : 190510873616457728,
  "created_at" : "2012-04-12 18:45:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190496586533576705",
  "geo" : { },
  "id_str" : "190509079746195456",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton feels gross...whats wrong with parens?",
  "id" : 190509079746195456,
  "in_reply_to_status_id" : 190496586533576705,
  "created_at" : "2012-04-12 18:37:58 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 28, 39 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190449101907836928",
  "text" : "W\u029C\u1D07\u0274 I\uA731 S\u1D0D\u1D00\u029F\u029F C\u1D00\u1D18\uA731 D\u1D00\u028F? \/cc @CHADFOWLER",
  "id" : 190449101907836928,
  "created_at" : "2012-04-12 14:39:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mehul Kar",
      "screen_name" : "mehulkar",
      "indices" : [ 0, 9 ],
      "id_str" : "19824931",
      "id" : 19824931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190276518239404033",
  "geo" : { },
  "id_str" : "190280064783486976",
  "in_reply_to_user_id" : 19824931,
  "text" : "@mehulkar feel free to email me any questions! :)",
  "id" : 190280064783486976,
  "in_reply_to_status_id" : 190276518239404033,
  "created_at" : "2012-04-12 03:27:57 +0000",
  "in_reply_to_screen_name" : "mehulkar",
  "in_reply_to_user_id_str" : "19824931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190234424967835648",
  "geo" : { },
  "id_str" : "190236368218238976",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik maybe so, maybe not!",
  "id" : 190236368218238976,
  "in_reply_to_status_id" : 190234424967835648,
  "created_at" : "2012-04-12 00:34:19 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190228989049176065",
  "text" : "Has this law been defined yet? \"As an online discussion grows longer, the probability of declaring the argument a strawman approaches 1.\"",
  "id" : 190228989049176065,
  "created_at" : "2012-04-12 00:04:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/nBuD2V3I",
      "expanded_url" : "http:\/\/dewith.com\/2012\/this-is-the-mail-system\/",
      "display_url" : "dewith.com\/2012\/this-is-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190227450834333697",
  "text" : "Definitely have felt this way for years. Email needs to get better. http:\/\/t.co\/nBuD2V3I",
  "id" : 190227450834333697,
  "created_at" : "2012-04-11 23:58:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Lab",
      "screen_name" : "buffalolab",
      "indices" : [ 3, 14 ],
      "id_str" : "69088210",
      "id" : 69088210
    }, {
      "name" : "Buffalo Lab",
      "screen_name" : "buffalolab",
      "indices" : [ 42, 53 ],
      "id_str" : "69088210",
      "id" : 69088210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/12nM8E8A",
      "expanded_url" : "http:\/\/www.buffalolab.org\/blog\/2012\/04\/buffalo-php-wny-ruby-meetup-great-success\/",
      "display_url" : "buffalolab.org\/blog\/2012\/04\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190156364507656194",
  "text" : "RT @buffalolab: BuffaloPHP meets WNY Ruby @buffalolab http:\/\/t.co\/12nM8E8A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo Lab",
        "screen_name" : "buffalolab",
        "indices" : [ 26, 37 ],
        "id_str" : "69088210",
        "id" : 69088210
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/12nM8E8A",
        "expanded_url" : "http:\/\/www.buffalolab.org\/blog\/2012\/04\/buffalo-php-wny-ruby-meetup-great-success\/",
        "display_url" : "buffalolab.org\/blog\/2012\/04\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "190155975834079232",
    "text" : "BuffaloPHP meets WNY Ruby @buffalolab http:\/\/t.co\/12nM8E8A",
    "id" : 190155975834079232,
    "created_at" : "2012-04-11 19:14:52 +0000",
    "user" : {
      "name" : "Buffalo Lab",
      "screen_name" : "buffalolab",
      "protected" : false,
      "id_str" : "69088210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543297016734826496\/vGAKugYY_normal.png",
      "id" : 69088210,
      "verified" : false
    }
  },
  "id" : 190156364507656194,
  "created_at" : "2012-04-11 19:16:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190137834856906753",
  "geo" : { },
  "id_str" : "190140793003065344",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton what are you trying to prove here?",
  "id" : 190140793003065344,
  "in_reply_to_status_id" : 190137834856906753,
  "created_at" : "2012-04-11 18:14:32 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190124992082620417",
  "text" : "Grateful for the testing discussions the Ruby community has. Enforces the fact that it's ingrained in the culture, unlike other languages.",
  "id" : 190124992082620417,
  "created_at" : "2012-04-11 17:11:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 11, 22 ],
      "id_str" : "20751318",
      "id" : 20751318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/PuHI2SLC",
      "expanded_url" : "http:\/\/blogs.democratandchronicle.com\/youngprofessionalsstaff\/",
      "display_url" : "blogs.democratandchronicle.com\/youngprofessio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190121656344256513",
  "text" : "Pumped for @barcamproc this weekend! http:\/\/t.co\/PuHI2SLC",
  "id" : 190121656344256513,
  "created_at" : "2012-04-11 16:58:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190107341767712771",
  "geo" : { },
  "id_str" : "190109084995948544",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius how many apps do you maintain older than 6 months - 1 year? or is this just a blanket statement about the state of things?",
  "id" : 190109084995948544,
  "in_reply_to_status_id" : 190107341767712771,
  "created_at" : "2012-04-11 16:08:32 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190103342289133568",
  "geo" : { },
  "id_str" : "190106859213041665",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius why does this matter? Ruby isn't Java. If you want Java, just use Java.",
  "id" : 190106859213041665,
  "in_reply_to_status_id" : 190103342289133568,
  "created_at" : "2012-04-11 15:59:41 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 38, 47 ],
      "id_str" : "16891384",
      "id" : 16891384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/0hvgdCdQ",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/153234\/how-deep-are-your-unit-tests\/153565#153565",
      "display_url" : "stackoverflow.com\/questions\/1532\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190090486906757123",
  "text" : "RT @dhh: Wise words on the subject by @KentBeck: http:\/\/t.co\/0hvgdCdQ -- wish there were more examples of \"what not to test\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kent Beck",
        "screen_name" : "KentBeck",
        "indices" : [ 29, 38 ],
        "id_str" : "16891384",
        "id" : 16891384
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/0hvgdCdQ",
        "expanded_url" : "http:\/\/stackoverflow.com\/questions\/153234\/how-deep-are-your-unit-tests\/153565#153565",
        "display_url" : "stackoverflow.com\/questions\/1532\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "190088520172453889",
    "text" : "Wise words on the subject by @KentBeck: http:\/\/t.co\/0hvgdCdQ -- wish there were more examples of \"what not to test\".",
    "id" : 190088520172453889,
    "created_at" : "2012-04-11 14:46:49 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 190090486906757123,
  "created_at" : "2012-04-11 14:54:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/bb5OsuVa",
      "expanded_url" : "http:\/\/www.rush.com\/rush\/index.php",
      "display_url" : "rush.com\/rush\/index.php"
    } ]
  },
  "geo" : { },
  "id_str" : "190073351459442689",
  "text" : "New RUSH album on June 12th! Woot!!! http:\/\/t.co\/bb5OsuVa",
  "id" : 190073351459442689,
  "created_at" : "2012-04-11 13:46:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 21, 29 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/UUcr0DCy",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/qrush\/p\/m-a-better-ruby-testunit-runner",
      "display_url" : "speakerdeck.com\/u\/qrush\/p\/m-a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189933398373052416",
  "text" : "Slides from my quick @wnyruby talk today: http:\/\/t.co\/UUcr0DCy thanks for coming out, folks!",
  "id" : 189933398373052416,
  "created_at" : "2012-04-11 04:30:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 95 ],
      "url" : "https:\/\/t.co\/6CkY0RIu",
      "expanded_url" : "https:\/\/vimeo.com\/40000072",
      "display_url" : "vimeo.com\/40000072"
    } ]
  },
  "geo" : { },
  "id_str" : "189930405347065856",
  "text" : "RT @jhsu: this is amazing, props to the kid and the people who helped out https:\/\/t.co\/6CkY0RIu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 85 ],
        "url" : "https:\/\/t.co\/6CkY0RIu",
        "expanded_url" : "https:\/\/vimeo.com\/40000072",
        "display_url" : "vimeo.com\/40000072"
      } ]
    },
    "geo" : { },
    "id_str" : "189918822482980865",
    "text" : "this is amazing, props to the kid and the people who helped out https:\/\/t.co\/6CkY0RIu",
    "id" : 189918822482980865,
    "created_at" : "2012-04-11 03:32:30 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 189930405347065856,
  "created_at" : "2012-04-11 04:18:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 23, 30 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 47, 53 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189888709276082177",
  "text" : "RT @steveklabnik: Man, @github is so powerful. @qrush mentions something about a library during a talk, I Fork and Edit, he merges on hi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 5, 12 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 29, 35 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189886161177677827",
    "text" : "Man, @github is so powerful. @qrush mentions something about a library during a talk, I Fork and Edit, he merges on his phone. So silly.",
    "id" : 189886161177677827,
    "created_at" : "2012-04-11 01:22:43 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 189888709276082177,
  "created_at" : "2012-04-11 01:32:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 18, 30 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189822425641394176",
  "geo" : { },
  "id_str" : "189822663923998720",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin blame @rocketslide.",
  "id" : 189822663923998720,
  "in_reply_to_status_id" : 189822425641394176,
  "created_at" : "2012-04-10 21:10:24 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Kleppmann",
      "screen_name" : "martinkl",
      "indices" : [ 0, 9 ],
      "id_str" : "17055506",
      "id" : 17055506
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 10, 18 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Bryce",
      "screen_name" : "brycemcd",
      "indices" : [ 19, 28 ],
      "id_str" : "14849666",
      "id" : 14849666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 96 ],
      "url" : "https:\/\/t.co\/4t0wz8YY",
      "expanded_url" : "https:\/\/github.com\/antirez\/redis-tools",
      "display_url" : "github.com\/antirez\/redis-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "189817840923189249",
  "geo" : { },
  "id_str" : "189820383027937280",
  "in_reply_to_user_id" : 17055506,
  "text" : "@martinkl @mperham @brycemcd not by me, sorry. redis-tools has some stuff: https:\/\/t.co\/4t0wz8YY",
  "id" : 189820383027937280,
  "in_reply_to_status_id" : 189817840923189249,
  "created_at" : "2012-04-10 21:01:20 +0000",
  "in_reply_to_screen_name" : "martinkl",
  "in_reply_to_user_id_str" : "17055506",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https:\/\/t.co\/LMPev8E5",
      "expanded_url" : "https:\/\/github.com\/lowe\/zxcvbn",
      "display_url" : "github.com\/lowe\/zxcvbn"
    } ]
  },
  "geo" : { },
  "id_str" : "189807034366033921",
  "text" : "Today's winner of \"Worst Named Library\" goes to: https:\/\/t.co\/LMPev8E5",
  "id" : 189807034366033921,
  "created_at" : "2012-04-10 20:08:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189796626104197120",
  "text" : "Blows my mind that Instagram got a BILLION DOLLARS yet I have to use some shitty third-party site to find any photo I've taken using them.",
  "id" : 189796626104197120,
  "created_at" : "2012-04-10 19:26:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 0, 5 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/BbaoGdwG",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ie5LvkM6ga\/",
      "display_url" : "instagr.am\/p\/Ie5LvkM6ga\/"
    } ]
  },
  "in_reply_to_status_id_str" : "189795866167619584",
  "geo" : { },
  "id_str" : "189796303281209346",
  "in_reply_to_user_id" : 637533,
  "text" : "@coda no way! that matches this photo from our vet's office: http:\/\/t.co\/BbaoGdwG",
  "id" : 189796303281209346,
  "in_reply_to_status_id" : 189795866167619584,
  "created_at" : "2012-04-10 19:25:39 +0000",
  "in_reply_to_screen_name" : "coda",
  "in_reply_to_user_id_str" : "637533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 45, 54 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 105 ],
      "url" : "https:\/\/t.co\/5OLgHQtU",
      "expanded_url" : "https:\/\/github.com\/rubygems\/gemwhisperer\/issues\/1",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189795901399773184",
  "text" : "Seems like we're getting truncated tweets on @rubygems! Anyone want to investigate? https:\/\/t.co\/5OLgHQtU",
  "id" : 189795901399773184,
  "created_at" : "2012-04-10 19:24:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/cv1sviSd",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/life\/walking\/2012\/04\/why_don_t_americans_walk_more_the_crisis_of_pedestrianism_.single.html",
      "display_url" : "slate.com\/articles\/life\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189783727856037889",
  "text" : "Another reason I'm proud to live in Buffalo's Elmwood Village: walking. Every day, every where. http:\/\/t.co\/cv1sviSd",
  "id" : 189783727856037889,
  "created_at" : "2012-04-10 18:35:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189720551865065472",
  "text" : "Finally found a use for ruby -n: print a command then run it. cat some_file | ruby -n -e 'puts $_; system($_)'",
  "id" : 189720551865065472,
  "created_at" : "2012-04-10 14:24:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189693279695147008",
  "geo" : { },
  "id_str" : "189693914008125440",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann thanks :)",
  "id" : 189693914008125440,
  "in_reply_to_status_id" : 189693279695147008,
  "created_at" : "2012-04-10 12:38:48 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/hJkTumn2",
      "expanded_url" : "http:\/\/me.veekun.com\/blog\/2012\/04\/09\/php-a-fractal-of-bad-design\/",
      "display_url" : "me.veekun.com\/blog\/2012\/04\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189569108222812161",
  "text" : "Can someone who uses PHP explain why they put up with all of this bullshit? http:\/\/t.co\/hJkTumn2",
  "id" : 189569108222812161,
  "created_at" : "2012-04-10 04:22:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189543006901256192",
  "text" : "Maybe not, looks like install through homebrew failed. :(",
  "id" : 189543006901256192,
  "created_at" : "2012-04-10 02:39:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/Zj6MV5ht",
      "expanded_url" : "http:\/\/mosh.mit.edu\/",
      "display_url" : "mosh.mit.edu"
    } ]
  },
  "geo" : { },
  "id_str" : "189540239260401665",
  "text" : "Going to give Mosh a try: http:\/\/t.co\/Zj6MV5ht",
  "id" : 189540239260401665,
  "created_at" : "2012-04-10 02:28:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 52, 65 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/OYHqTQMu",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189449735625641985",
  "text" : "Pumped for http:\/\/t.co\/OYHqTQMu tomorrow night with @steveklabnik !",
  "id" : 189449735625641985,
  "created_at" : "2012-04-09 20:28:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189431144998117376",
  "text" : "Obligatory flabbergasted tweet about recent  tech company buyout.",
  "id" : 189431144998117376,
  "created_at" : "2012-04-09 19:14:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188993216371097600",
  "text" : "Dog tried to run away this morning, he thought it was hilarious. I didn't. This isn't funny, I'm just out of breath.",
  "id" : 188993216371097600,
  "created_at" : "2012-04-08 14:14:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188776072622505984",
  "geo" : { },
  "id_str" : "188783009128923136",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt love that place, we're a 5 minute walk away. Let me know next time you visit!",
  "id" : 188783009128923136,
  "in_reply_to_status_id" : 188776072622505984,
  "created_at" : "2012-04-08 00:19:11 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/gYdKsfAX",
      "expanded_url" : "http:\/\/instagr.am\/p\/JIrPJLs6g2\/",
      "display_url" : "instagr.am\/p\/JIrPJLs6g2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188758445191725057",
  "text" : "Did a Basecamp egg as well! http:\/\/t.co\/gYdKsfAX",
  "id" : 188758445191725057,
  "created_at" : "2012-04-07 22:41:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/QSs3lMuh",
      "expanded_url" : "http:\/\/instagr.am\/p\/JIq2v_M6gn\/",
      "display_url" : "instagr.am\/p\/JIq2v_M6gn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188757585728507905",
  "text" : "After! SSSSSSsssssssssss http:\/\/t.co\/QSs3lMuh",
  "id" : 188757585728507905,
  "created_at" : "2012-04-07 22:38:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/jmh8Ozgf",
      "expanded_url" : "http:\/\/instagr.am\/p\/JIpl12M6gL\/",
      "display_url" : "instagr.am\/p\/JIpl12M6gL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188754804116434944",
  "text" : "Before... http:\/\/t.co\/jmh8Ozgf",
  "id" : 188754804116434944,
  "created_at" : "2012-04-07 22:27:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 0, 4 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188738371126956032",
  "geo" : { },
  "id_str" : "188743296439427072",
  "in_reply_to_user_id" : 5961382,
  "text" : "@rit daaang dude. Crispy dorfs?",
  "id" : 188743296439427072,
  "in_reply_to_status_id" : 188738371126956032,
  "created_at" : "2012-04-07 21:41:23 +0000",
  "in_reply_to_screen_name" : "rit",
  "in_reply_to_user_id_str" : "5961382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/mu0rLrao",
      "expanded_url" : "http:\/\/instagr.am\/p\/JIRMWYM6lC\/",
      "display_url" : "instagr.am\/p\/JIRMWYM6lC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188701301784326144",
  "text" : "Serious pasta time. http:\/\/t.co\/mu0rLrao",
  "id" : 188701301784326144,
  "created_at" : "2012-04-07 18:54:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188682134402244608",
  "geo" : { },
  "id_str" : "188686534579458050",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler humility",
  "id" : 188686534579458050,
  "in_reply_to_status_id" : 188682134402244608,
  "created_at" : "2012-04-07 17:55:50 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 0, 10 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188667770991423488",
  "geo" : { },
  "id_str" : "188673421570342912",
  "in_reply_to_user_id" : 19846068,
  "text" : "@cldwalker thanks man! Also huge +1 for the debugger",
  "id" : 188673421570342912,
  "in_reply_to_status_id" : 188667770991423488,
  "created_at" : "2012-04-07 17:03:43 +0000",
  "in_reply_to_screen_name" : "cldwalker",
  "in_reply_to_user_id_str" : "19846068",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/hc4ZQzAM",
      "expanded_url" : "http:\/\/quaran.to\/m\/",
      "display_url" : "quaran.to\/m\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188653687625891841",
  "text" : "Updated m to run MiniTest::Unit tests. :metal: http:\/\/t.co\/hc4ZQzAM",
  "id" : 188653687625891841,
  "created_at" : "2012-04-07 15:45:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188427229125021697",
  "geo" : { },
  "id_str" : "188448816171716608",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson nice work! i need a similar upgrade for mine.",
  "id" : 188448816171716608,
  "in_reply_to_status_id" : 188427229125021697,
  "created_at" : "2012-04-07 02:11:13 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    }, {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 8, 15 ],
      "id_str" : "14381877",
      "id" : 14381877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188437946599354369",
  "geo" : { },
  "id_str" : "188443126736760833",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh @gustin would love to hear what's affecting you most. Feel free to bug nick@37. Lots to fix!",
  "id" : 188443126736760833,
  "in_reply_to_status_id" : 188437946599354369,
  "created_at" : "2012-04-07 01:48:37 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188353189534371840",
  "text" : "Passed the wreck, guy inside seemed really shaken... sports gear and more spread out everywhere.",
  "id" : 188353189534371840,
  "created_at" : "2012-04-06 19:51:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188352416213766144",
  "geo" : { },
  "id_str" : "188352916594237440",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape visiting in laws...not exactly commuting",
  "id" : 188352916594237440,
  "in_reply_to_status_id" : 188352416213766144,
  "created_at" : "2012-04-06 19:50:09 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188352248307388416",
  "text" : "Apparently SUV rolled over... Saw him weaving in and out prior.",
  "id" : 188352248307388416,
  "created_at" : "2012-04-06 19:47:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/188351599561818112\/photo\/1",
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/hNWhb0Dk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ap0oyCkCQAAiUIm.jpg",
      "id_str" : "188351599566012416",
      "id" : 188351599566012416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ap0oyCkCQAAiUIm.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hNWhb0Dk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188351599561818112",
  "text" : "Dead stopped on I79...not sure why yet. Apparently big accident. http:\/\/t.co\/hNWhb0Dk",
  "id" : 188351599561818112,
  "created_at" : "2012-04-06 19:44:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188054243071107072",
  "geo" : { },
  "id_str" : "188086782070505476",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike I think it's part of OSS going mainstream. I don't see the wide selection as a bad thing",
  "id" : 188086782070505476,
  "in_reply_to_status_id" : 188054243071107072,
  "created_at" : "2012-04-06 02:12:37 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 0, 10 ],
      "id_str" : "15847711",
      "id" : 15847711
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 11, 24 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 25, 38 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/T75j9j5O",
      "expanded_url" : "http:\/\/www.codinghorror.com\/blog\/2007\/04\/pick-a-license-any-license.html",
      "display_url" : "codinghorror.com\/blog\/2007\/04\/p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "188019281315889153",
  "geo" : { },
  "id_str" : "188019670056574978",
  "in_reply_to_user_id" : 15847711,
  "text" : "@benhamill @steveklabnik @isaacsanders a good primer: http:\/\/t.co\/T75j9j5O",
  "id" : 188019670056574978,
  "in_reply_to_status_id" : 188019281315889153,
  "created_at" : "2012-04-05 21:45:57 +0000",
  "in_reply_to_screen_name" : "benhamill",
  "in_reply_to_user_id_str" : "15847711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 0, 10 ],
      "id_str" : "15847711",
      "id" : 15847711
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 11, 24 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188019281315889153",
  "geo" : { },
  "id_str" : "188019571695951873",
  "in_reply_to_user_id" : 15847711,
  "text" : "@benhamill @steveklabnik nope, definitely not. unlicensed code is RESTRICTED by default.",
  "id" : 188019571695951873,
  "in_reply_to_status_id" : 188019281315889153,
  "created_at" : "2012-04-05 21:45:33 +0000",
  "in_reply_to_screen_name" : "benhamill",
  "in_reply_to_user_id_str" : "15847711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Matthew Bergman",
      "screen_name" : "FotoVerite",
      "indices" : [ 12, 23 ],
      "id_str" : "15252015",
      "id" : 15252015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188013035623956482",
  "geo" : { },
  "id_str" : "188018481080446977",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser @FotoVerite this is the \"php\" syndrome, and the web will never be over it.",
  "id" : 188018481080446977,
  "in_reply_to_status_id" : 188013035623956482,
  "created_at" : "2012-04-05 21:41:13 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/NoPsnqoa",
      "expanded_url" : "http:\/\/mir.aculo.us\/2012\/04\/05\/why-id-like-a-license-type-setting-for-github-projects\/",
      "display_url" : "mir.aculo.us\/2012\/04\/05\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188017929462353920",
  "text" : "Totally disagree with http:\/\/t.co\/NoPsnqoa. When devs don't care enough to add a LICENSE, huge signal to not use their code.",
  "id" : 188017929462353920,
  "created_at" : "2012-04-05 21:39:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    }, {
      "name" : "Thomas Fuchs",
      "screen_name" : "madrobby",
      "indices" : [ 14, 23 ],
      "id_str" : "10503202",
      "id" : 10503202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188016431957426176",
  "geo" : { },
  "id_str" : "188017523059470337",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror @madrobby yeah, and someone should approve the projects too! and it's more important to see downloads first. and..and...",
  "id" : 188017523059470337,
  "in_reply_to_status_id" : 188016431957426176,
  "created_at" : "2012-04-05 21:37:25 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Seifer",
      "screen_name" : "jseifer",
      "indices" : [ 3, 11 ],
      "id_str" : "1714531",
      "id" : 1714531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/GZZwp8V9",
      "expanded_url" : "https:\/\/gist.github.com\/2314204",
      "display_url" : "gist.github.com\/2314204"
    } ]
  },
  "geo" : { },
  "id_str" : "188014631376261121",
  "text" : "RT @jseifer: This is what the culture of exclusion blog post looks like with alcohol references changed to meat references: https:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 132 ],
        "url" : "https:\/\/t.co\/GZZwp8V9",
        "expanded_url" : "https:\/\/gist.github.com\/2314204",
        "display_url" : "gist.github.com\/2314204"
      } ]
    },
    "geo" : { },
    "id_str" : "188012900428951552",
    "text" : "This is what the culture of exclusion blog post looks like with alcohol references changed to meat references: https:\/\/t.co\/GZZwp8V9",
    "id" : 188012900428951552,
    "created_at" : "2012-04-05 21:19:03 +0000",
    "user" : {
      "name" : "Jason Seifer",
      "screen_name" : "jseifer",
      "protected" : false,
      "id_str" : "1714531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478561676615118848\/3B6UDZQl_normal.jpeg",
      "id" : 1714531,
      "verified" : false
    }
  },
  "id" : 188014631376261121,
  "created_at" : "2012-04-05 21:25:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188006777542029313",
  "geo" : { },
  "id_str" : "188007195030466561",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta i am without words.",
  "id" : 188007195030466561,
  "in_reply_to_status_id" : 188006777542029313,
  "created_at" : "2012-04-05 20:56:22 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188004462940532736",
  "text" : "HEY BRO LET'S GO NODE.JS CLUBBIN. WHERE ALL THE SELECT(2) CALLS AT? YO DOG THEY GOT A HOT TUB AT THIS CONF!",
  "id" : 188004462940532736,
  "created_at" : "2012-04-05 20:45:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188004291141828609",
  "text" : "Looking forward to the upcoming developer reality TV show\/docudrama: PALO ALTO BROGRAMMERS",
  "id" : 188004291141828609,
  "created_at" : "2012-04-05 20:44:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/XUC0l77b",
      "expanded_url" : "http:\/\/instawahhhh.tumblr.com\/",
      "display_url" : "instawahhhh.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "188004096438046720",
  "text" : "RT @SteveStreza: http:\/\/t.co\/XUC0l77b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/XUC0l77b",
        "expanded_url" : "http:\/\/instawahhhh.tumblr.com\/",
        "display_url" : "instawahhhh.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "188003095278657536",
    "text" : "http:\/\/t.co\/XUC0l77b",
    "id" : 188003095278657536,
    "created_at" : "2012-04-05 20:40:05 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 188004096438046720,
  "created_at" : "2012-04-05 20:44:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "indices" : [ 0, 8 ],
      "id_str" : "3382151",
      "id" : 3382151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187996042258690049",
  "geo" : { },
  "id_str" : "187996252498169857",
  "in_reply_to_user_id" : 3382151,
  "text" : "@dmosher timing issues? what?",
  "id" : 187996252498169857,
  "in_reply_to_status_id" : 187996042258690049,
  "created_at" : "2012-04-05 20:12:54 +0000",
  "in_reply_to_screen_name" : "dmosher",
  "in_reply_to_user_id_str" : "3382151",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 3, 10 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187991424648757248",
  "text" : "RT @MikeG1: Trying to think of any profession that DOESN'T get drunk at conferences. I don't think this is a developer issue.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187991296391122944",
    "text" : "Trying to think of any profession that DOESN'T get drunk at conferences. I don't think this is a developer issue.",
    "id" : 187991296391122944,
    "created_at" : "2012-04-05 19:53:12 +0000",
    "user" : {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "protected" : true,
      "id_str" : "728173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57930155\/Photo1Small_normal.png",
      "id" : 728173,
      "verified" : false
    }
  },
  "id" : 187991424648757248,
  "created_at" : "2012-04-05 19:53:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo DiNardi",
      "screen_name" : "adinardi",
      "indices" : [ 0, 9 ],
      "id_str" : "781929",
      "id" : 781929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187988319609696256",
  "geo" : { },
  "id_str" : "187989183602761728",
  "in_reply_to_user_id" : 781929,
  "text" : "@adinardi definitely had the same experience in Italy.",
  "id" : 187989183602761728,
  "in_reply_to_status_id" : 187988319609696256,
  "created_at" : "2012-04-05 19:44:48 +0000",
  "in_reply_to_screen_name" : "adinardi",
  "in_reply_to_user_id_str" : "781929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187987910656655361",
  "text" : "git checkout -p, or, git checkout --remove-every-curse-word-from-debugging-statements",
  "id" : 187987910656655361,
  "created_at" : "2012-04-05 19:39:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187926783641923584",
  "geo" : { },
  "id_str" : "187928806063996928",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw i lost it at the four hands on one guitar part.",
  "id" : 187928806063996928,
  "in_reply_to_status_id" : 187926783641923584,
  "created_at" : "2012-04-05 15:44:53 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/rq5Zuwyy",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gkfVdrtLcRs",
      "display_url" : "youtube.com\/watch?v=gkfVdr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187921747675324416",
  "text" : "Current status: http:\/\/t.co\/rq5Zuwyy",
  "id" : 187921747675324416,
  "created_at" : "2012-04-05 15:16:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187905136029470721",
  "text" : "Slept so long last night, my body literally woke up for halftime.",
  "id" : 187905136029470721,
  "created_at" : "2012-04-05 14:10:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187714098690134019",
  "geo" : { },
  "id_str" : "187719304970633216",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius @Zaius_ebooks ?",
  "id" : 187719304970633216,
  "in_reply_to_status_id" : 187714098690134019,
  "created_at" : "2012-04-05 01:52:24 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187593727173341184",
  "text" : "Completely missing the boat today.",
  "id" : 187593727173341184,
  "created_at" : "2012-04-04 17:33:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 23, 29 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187588512873320449",
  "text" : "RT @tenderlove: I wish @tpope would write a book or blog about vimscript and extending vim. I want to get better at vimscript, but resou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Pope",
        "screen_name" : "tpope",
        "indices" : [ 7, 13 ],
        "id_str" : "8000842",
        "id" : 8000842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187587991772995584",
    "text" : "I wish @tpope would write a book or blog about vimscript and extending vim. I want to get better at vimscript, but resources seem scarce.",
    "id" : 187587991772995584,
    "created_at" : "2012-04-04 17:10:37 +0000",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325798111\/ca48276f8ebbbbac9c6ce83aac3c8548_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 187588512873320449,
  "created_at" : "2012-04-04 17:12:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187563897040027649",
  "geo" : { },
  "id_str" : "187564029173174272",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich the only notification badge i have now is for Messages. too many numbers.",
  "id" : 187564029173174272,
  "in_reply_to_status_id" : 187563897040027649,
  "created_at" : "2012-04-04 15:35:23 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/DYIHh0iF",
      "expanded_url" : "http:\/\/www.billcasselman.com\/trepanning3.jpg",
      "display_url" : "billcasselman.com\/trepanning3.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "187561242410487809",
  "text" : "Current allergy status: http:\/\/t.co\/DYIHh0iF",
  "id" : 187561242410487809,
  "created_at" : "2012-04-04 15:24:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 0, 4 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187371682305028096",
  "geo" : { },
  "id_str" : "187372259445440514",
  "in_reply_to_user_id" : 5961382,
  "text" : "@rit ah, good call. but yes...that's one fucked up world gen. i don't care go near evil\/haunted stuff yet. just did a scorching map!",
  "id" : 187372259445440514,
  "in_reply_to_status_id" : 187371682305028096,
  "created_at" : "2012-04-04 02:53:22 +0000",
  "in_reply_to_screen_name" : "rit",
  "in_reply_to_user_id_str" : "5961382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 0, 4 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187367076766298113",
  "geo" : { },
  "id_str" : "187371295158181888",
  "in_reply_to_user_id" : 5961382,
  "text" : "@rit also, tiles? cmon :)",
  "id" : 187371295158181888,
  "in_reply_to_status_id" : 187367076766298113,
  "created_at" : "2012-04-04 02:49:32 +0000",
  "in_reply_to_screen_name" : "rit",
  "in_reply_to_user_id_str" : "5961382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 0, 4 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187367076766298113",
  "geo" : { },
  "id_str" : "187370869859958784",
  "in_reply_to_user_id" : 5961382,
  "text" : "@rit why is there even a question?",
  "id" : 187370869859958784,
  "in_reply_to_status_id" : 187367076766298113,
  "created_at" : "2012-04-04 02:47:51 +0000",
  "in_reply_to_screen_name" : "rit",
  "in_reply_to_user_id_str" : "5961382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187353162968080384",
  "text" : "Whelp, that's a new one on me, Ruby: \"warning: else without rescue is useless\"",
  "id" : 187353162968080384,
  "created_at" : "2012-04-04 01:37:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/8lOICkZa",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WRR2ifpoVFY",
      "display_url" : "youtube.com\/watch?v=WRR2if\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187341398813581312",
  "text" : "Current status: http:\/\/t.co\/8lOICkZa",
  "id" : 187341398813581312,
  "created_at" : "2012-04-04 00:50:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 0, 9 ],
      "id_str" : "18545770",
      "id" : 18545770
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 10, 22 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/rFzPpCFJ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=T67AewxhBaQ",
      "display_url" : "youtube.com\/watch?v=T67Aew\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "187339082941210624",
  "geo" : { },
  "id_str" : "187340752664272896",
  "in_reply_to_user_id" : 18545770,
  "text" : "@DockYard @bcardarella http:\/\/t.co\/rFzPpCFJ ?",
  "id" : 187340752664272896,
  "in_reply_to_status_id" : 187339082941210624,
  "created_at" : "2012-04-04 00:48:10 +0000",
  "in_reply_to_screen_name" : "DockYard",
  "in_reply_to_user_id_str" : "18545770",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Persson",
      "screen_name" : "notch",
      "indices" : [ 46, 52 ],
      "id_str" : "63485337",
      "id" : 63485337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/ZaKUuj52",
      "expanded_url" : "http:\/\/0x10c.com\/",
      "display_url" : "0x10c.com"
    }, {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/fiBweQqc",
      "expanded_url" : "http:\/\/i.imgur.com\/DhmFp.png",
      "display_url" : "i.imgur.com\/DhmFp.png"
    } ]
  },
  "geo" : { },
  "id_str" : "187331475794968577",
  "text" : "Genuinely excited about http:\/\/t.co\/ZaKUuj52. @notch is building a SPACEPUTER. http:\/\/t.co\/fiBweQqc",
  "id" : 187331475794968577,
  "created_at" : "2012-04-04 00:11:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187282790319005696",
  "text" : "# Running tests:\n\n\"ROFL?\"\n\"FUCK?\"\n\"ROFL?\"\n\"FUCK?\"\n\"ROFL?\"\n\"FUCK?\"\n.",
  "id" : 187282790319005696,
  "created_at" : "2012-04-03 20:57:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187267210807488512",
  "geo" : { },
  "id_str" : "187271085551665152",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda have you tried emailing the author?",
  "id" : 187271085551665152,
  "in_reply_to_status_id" : 187267210807488512,
  "created_at" : "2012-04-03 20:11:20 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/mSMgAdZA",
      "expanded_url" : "http:\/\/httpstatus.es\/402",
      "display_url" : "httpstatus.es\/402"
    } ]
  },
  "geo" : { },
  "id_str" : "187257210424918017",
  "text" : "REQUEST: Someone make a web service that returns \"Fuck you, pay me\" for http:\/\/t.co\/mSMgAdZA",
  "id" : 187257210424918017,
  "created_at" : "2012-04-03 19:16:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 43 ],
      "url" : "https:\/\/t.co\/KpSJNsER",
      "expanded_url" : "https:\/\/img.skitch.com\/20120403-pc2iy4dhffwaesngk3ngiu7j3k.png",
      "display_url" : "img.skitch.com\/20120403-pc2iy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187250428331827201",
  "text" : "JAPANESE GOBLIN. WAT? https:\/\/t.co\/KpSJNsER",
  "id" : 187250428331827201,
  "created_at" : "2012-04-03 18:49:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187249842584690688",
  "text" : "\uD83D\uDE4D",
  "id" : 187249842584690688,
  "created_at" : "2012-04-03 18:46:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Celis",
      "screen_name" : "stephencelis",
      "indices" : [ 0, 13 ],
      "id_str" : "6523632",
      "id" : 6523632
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 14, 25 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187248446527373312",
  "geo" : { },
  "id_str" : "187249362919890945",
  "in_reply_to_user_id" : 6523632,
  "text" : "@stephencelis @trevorturk WATER BUFFALO !!!!",
  "id" : 187249362919890945,
  "in_reply_to_status_id" : 187248446527373312,
  "created_at" : "2012-04-03 18:45:01 +0000",
  "in_reply_to_screen_name" : "stephencelis",
  "in_reply_to_user_id_str" : "6523632",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Winkler",
      "screen_name" : "mcmire",
      "indices" : [ 0, 7 ],
      "id_str" : "14453888",
      "id" : 14453888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187238374816493574",
  "geo" : { },
  "id_str" : "187244155938947072",
  "in_reply_to_user_id" : 14453888,
  "text" : "@mcmire would love to, yes!",
  "id" : 187244155938947072,
  "in_reply_to_status_id" : 187238374816493574,
  "created_at" : "2012-04-03 18:24:20 +0000",
  "in_reply_to_screen_name" : "mcmire",
  "in_reply_to_user_id_str" : "14453888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187229864028413952",
  "text" : "RT @vrunt: man from 3 years ago frozen in time and wakes up to discover everyone gave up on using ogg vorbis, screams himself into a coma",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187229550239940609",
    "text" : "man from 3 years ago frozen in time and wakes up to discover everyone gave up on using ogg vorbis, screams himself into a coma",
    "id" : 187229550239940609,
    "created_at" : "2012-04-03 17:26:17 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 187229864028413952,
  "created_at" : "2012-04-03 17:27:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/hc4ZQzAM",
      "expanded_url" : "http:\/\/quaran.to\/m\/",
      "display_url" : "quaran.to\/m\/"
    } ]
  },
  "geo" : { },
  "id_str" : "187225667845357568",
  "text" : "Still using m daily, after several months. http:\/\/t.co\/hc4ZQzAM",
  "id" : 187225667845357568,
  "created_at" : "2012-04-03 17:10:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 7, 13 ],
      "id_str" : "8000842",
      "id" : 8000842
    }, {
      "name" : "Michal Papis",
      "screen_name" : "mpapis",
      "indices" : [ 14, 21 ],
      "id_str" : "108799541",
      "id" : 108799541
    }, {
      "name" : "Andrew White",
      "screen_name" : "pixeltrix",
      "indices" : [ 22, 32 ],
      "id_str" : "12617962",
      "id" : 12617962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187219964455948288",
  "geo" : { },
  "id_str" : "187221658954760192",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @tpope @mpapis @pixeltrix wat? i'm checking schema.rb's daily.",
  "id" : 187221658954760192,
  "in_reply_to_status_id" : 187219964455948288,
  "created_at" : "2012-04-03 16:54:56 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew White",
      "screen_name" : "pixeltrix",
      "indices" : [ 0, 10 ],
      "id_str" : "12617962",
      "id" : 12617962
    }, {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 11, 17 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187214320139120640",
  "geo" : { },
  "id_str" : "187214522359091203",
  "in_reply_to_user_id" : 12617962,
  "text" : "@pixeltrix @tpope ah ha! perhaps time for a schema.rb change in rails 4?",
  "id" : 187214522359091203,
  "in_reply_to_status_id" : 187214320139120640,
  "created_at" : "2012-04-03 16:26:35 +0000",
  "in_reply_to_screen_name" : "pixeltrix",
  "in_reply_to_user_id_str" : "12617962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187211521170997248",
  "geo" : { },
  "id_str" : "187213280933195776",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope what?",
  "id" : 187213280933195776,
  "in_reply_to_status_id" : 187211521170997248,
  "created_at" : "2012-04-03 16:21:39 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187207838240739328",
  "geo" : { },
  "id_str" : "187208536848220161",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef negative",
  "id" : 187208536848220161,
  "in_reply_to_status_id" : 187207838240739328,
  "created_at" : "2012-04-03 16:02:48 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "BrendanEich",
      "screen_name" : "BrendanEich",
      "indices" : [ 44, 56 ],
      "id_str" : "9533042",
      "id" : 9533042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrongsideofhistory",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/f95wELC7",
      "expanded_url" : "http:\/\/projects.latimes.com\/prop8\/donation\/8930\/",
      "display_url" : "projects.latimes.com\/prop8\/donation\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187196545832189952",
  "text" : "RT @sstephenson: The creator of JavaScript, @BrendanEich, paid money to keep people like me from getting married. http:\/\/t.co\/f95wELC7 # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BrendanEich",
        "screen_name" : "BrendanEich",
        "indices" : [ 27, 39 ],
        "id_str" : "9533042",
        "id" : 9533042
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrongsideofhistory",
        "indices" : [ 118, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/f95wELC7",
        "expanded_url" : "http:\/\/projects.latimes.com\/prop8\/donation\/8930\/",
        "display_url" : "projects.latimes.com\/prop8\/donation\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "187196342639140864",
    "text" : "The creator of JavaScript, @BrendanEich, paid money to keep people like me from getting married. http:\/\/t.co\/f95wELC7 #wrongsideofhistory",
    "id" : 187196342639140864,
    "created_at" : "2012-04-03 15:14:20 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 187196545832189952,
  "created_at" : "2012-04-03 15:15:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myron Marston",
      "screen_name" : "myronmarston",
      "indices" : [ 3, 16 ],
      "id_str" : "89517808",
      "id" : 89517808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/tIPqlO9v",
      "expanded_url" : "http:\/\/www.fileformat.info\/info\/unicode\/char\/1f4a9\/index.htm",
      "display_url" : "fileformat.info\/info\/unicode\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187193133824606208",
  "text" : "RT @myronmarston: My new favorite unicode code point is U+1F4A9 http:\/\/t.co\/tIPqlO9v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/tIPqlO9v",
        "expanded_url" : "http:\/\/www.fileformat.info\/info\/unicode\/char\/1f4a9\/index.htm",
        "display_url" : "fileformat.info\/info\/unicode\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "187192408054824961",
    "text" : "My new favorite unicode code point is U+1F4A9 http:\/\/t.co\/tIPqlO9v",
    "id" : 187192408054824961,
    "created_at" : "2012-04-03 14:58:42 +0000",
    "user" : {
      "name" : "Myron Marston",
      "screen_name" : "myronmarston",
      "protected" : false,
      "id_str" : "89517808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740326138\/gravatar_normal.jpeg",
      "id" : 89517808,
      "verified" : false
    }
  },
  "id" : 187193133824606208,
  "created_at" : "2012-04-03 15:01:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 25, 33 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/Xi89Ebi7",
      "expanded_url" : "http:\/\/i.imgur.com\/bsFJn.jpg",
      "display_url" : "i.imgur.com\/bsFJn.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "187187036229345280",
  "text" : "An important message for @rubiety: http:\/\/t.co\/Xi89Ebi7",
  "id" : 187187036229345280,
  "created_at" : "2012-04-03 14:37:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/hsIWWDn3",
      "expanded_url" : "http:\/\/subtlepatterns.com\/",
      "display_url" : "subtlepatterns.com"
    }, {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/6ZANBKZp",
      "expanded_url" : "http:\/\/www.subtlepatterns.com\/subtlesans\/",
      "display_url" : "subtlepatterns.com\/subtlesans\/"
    } ]
  },
  "geo" : { },
  "id_str" : "187007304544157697",
  "text" : "Seriously enjoying http:\/\/t.co\/hsIWWDn3 today. http:\/\/t.co\/6ZANBKZp rocks too.",
  "id" : 187007304544157697,
  "created_at" : "2012-04-03 02:43:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187005608740921344",
  "geo" : { },
  "id_str" : "187006346556739585",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams the keytar makes this video",
  "id" : 187006346556739585,
  "in_reply_to_status_id" : 187005608740921344,
  "created_at" : "2012-04-03 02:39:22 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187002417487937537",
  "geo" : { },
  "id_str" : "187002603543080960",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton you have bigger problems if people complain about an .rbenv-version file.",
  "id" : 187002603543080960,
  "in_reply_to_status_id" : 187002417487937537,
  "created_at" : "2012-04-03 02:24:29 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 13, 25 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186999063487582211",
  "geo" : { },
  "id_str" : "187002135785902081",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @doctorzaius fuck.",
  "id" : 187002135785902081,
  "in_reply_to_status_id" : 186999063487582211,
  "created_at" : "2012-04-03 02:22:38 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186996979979653120",
  "geo" : { },
  "id_str" : "186997337363722241",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius aww! considering hitting up backboneconf, might be back soon!",
  "id" : 186997337363722241,
  "in_reply_to_status_id" : 186996979979653120,
  "created_at" : "2012-04-03 02:03:34 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 13, 27 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186996824912048128",
  "geo" : { },
  "id_str" : "186997039404552193",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius @joshuaclayton it's stupidly simple, and works well. i use both, but mostly rbenv.",
  "id" : 186997039404552193,
  "in_reply_to_status_id" : 186996824912048128,
  "created_at" : "2012-04-03 02:02:23 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 60 ],
      "url" : "https:\/\/t.co\/DCswu9tb",
      "expanded_url" : "https:\/\/github.com\/37signals\/pow\/issues\/22",
      "display_url" : "github.com\/37signals\/pow\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "186989765491556353",
  "geo" : { },
  "id_str" : "186993694082211840",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton looks like upgrade RVM? https:\/\/t.co\/DCswu9tb (or use rbenv!)",
  "id" : 186993694082211840,
  "in_reply_to_status_id" : 186989765491556353,
  "created_at" : "2012-04-03 01:49:05 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/9PRcibba",
      "expanded_url" : "http:\/\/topiat.com\/system\/images\/3733\/originals\/012020120259\/VhlQK.gif",
      "display_url" : "topiat.com\/system\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186933531526701056",
  "text" : "Current status: http:\/\/t.co\/9PRcibba",
  "id" : 186933531526701056,
  "created_at" : "2012-04-02 21:50:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186898292318289920",
  "geo" : { },
  "id_str" : "186898572413911040",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg i need to buy those tickets! will do so tonight!",
  "id" : 186898572413911040,
  "in_reply_to_status_id" : 186898292318289920,
  "created_at" : "2012-04-02 19:31:06 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186896168322740224",
  "geo" : { },
  "id_str" : "186897836535844864",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave definitely felt that way. did not enjoy the level reuse.",
  "id" : 186897836535844864,
  "in_reply_to_status_id" : 186896168322740224,
  "created_at" : "2012-04-02 19:28:11 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 65 ],
      "url" : "https:\/\/t.co\/UU81gFQ8",
      "expanded_url" : "https:\/\/github.com\/blog\/1081-instantly-beautiful-project-pages",
      "display_url" : "github.com\/blog\/1081-inst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186864494243348480",
  "text" : "Excited to see Jekyll continue to dominate. https:\/\/t.co\/UU81gFQ8",
  "id" : 186864494243348480,
  "created_at" : "2012-04-02 17:15:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186832595072450560",
  "geo" : { },
  "id_str" : "186835444628066304",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase nice calendar :)",
  "id" : 186835444628066304,
  "in_reply_to_status_id" : 186832595072450560,
  "created_at" : "2012-04-02 15:20:15 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/cfaziw66",
      "expanded_url" : "http:\/\/www.businessinsider.com\/how-hudson-whiskey-started-2012-3",
      "display_url" : "businessinsider.com\/how-hudson-whi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186827172307144704",
  "text" : "Absolutely inspiring story of a whisky distillery that started from ground zero, to top shelf: http:\/\/t.co\/cfaziw66",
  "id" : 186827172307144704,
  "created_at" : "2012-04-02 14:47:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 0, 7 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186806474947837953",
  "geo" : { },
  "id_str" : "186825851659235328",
  "in_reply_to_user_id" : 7516242,
  "text" : "@mislav awesome idea. i love how flexible Jekyll is for this kind of thing.",
  "id" : 186825851659235328,
  "in_reply_to_status_id" : 186806474947837953,
  "created_at" : "2012-04-02 14:42:08 +0000",
  "in_reply_to_screen_name" : "mislav",
  "in_reply_to_user_id_str" : "7516242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/6c3VYl5A",
      "expanded_url" : "http:\/\/watbutton.com",
      "display_url" : "watbutton.com"
    }, {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/pn5UNgcH",
      "expanded_url" : "http:\/\/techland.time.com\/2012\/04\/02\/25-years-of-ibms-os2-the-birth-death-and-afterlife-of-a-legendary-operating-system\/3\/",
      "display_url" : "techland.time.com\/2012\/04\/02\/25-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186824988001714176",
  "text" : "OS\/2 WARP runs the MTA MetroCard system?! http:\/\/t.co\/6c3VYl5A http:\/\/t.co\/pn5UNgcH",
  "id" : 186824988001714176,
  "created_at" : "2012-04-02 14:38:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186819394020708353",
  "geo" : { },
  "id_str" : "186823843086741504",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo yep, only on classic. sorry dude :\/",
  "id" : 186823843086741504,
  "in_reply_to_status_id" : 186819394020708353,
  "created_at" : "2012-04-02 14:34:09 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/S3eNdEQI",
      "expanded_url" : "http:\/\/cdn2.mixrmedia.com\/wp-uploads\/ningin\/blog\/2009\/11\/hay-fever-hat.jpg",
      "display_url" : "cdn2.mixrmedia.com\/wp-uploads\/nin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186810409083351040",
  "text" : "Current allergy status: http:\/\/t.co\/S3eNdEQI",
  "id" : 186810409083351040,
  "created_at" : "2012-04-02 13:40:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/186663948030971905\/photo\/1",
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/HyP5HQvl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Apcp3ysCEAElY27.png",
      "id_str" : "186663948035166209",
      "id" : 186663948035166209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Apcp3ysCEAElY27.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/HyP5HQvl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186663948030971905",
  "text" : "WORKCOMBAT has crumbled to its end. Basically how the end went down... http:\/\/t.co\/HyP5HQvl",
  "id" : 186663948030971905,
  "created_at" : "2012-04-02 03:58:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186629967482855425",
  "geo" : { },
  "id_str" : "186632658145652737",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic SHAI'HULUD!",
  "id" : 186632658145652737,
  "in_reply_to_status_id" : 186629967482855425,
  "created_at" : "2012-04-02 01:54:27 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186562411191476224",
  "text" : "@stevenhaddox check the date dude. cmon.",
  "id" : 186562411191476224,
  "created_at" : "2012-04-01 21:15:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/jpXey3bc",
      "expanded_url" : "http:\/\/seb.ly\/demos\/MMOsteroids.html",
      "display_url" : "seb.ly\/demos\/MMOstero\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186559235138666496",
  "text" : "Wow: http:\/\/t.co\/jpXey3bc It's more fun just to dodge things.",
  "id" : 186559235138666496,
  "created_at" : "2012-04-01 21:02:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Conway",
      "screen_name" : "mattonrails",
      "indices" : [ 0, 12 ],
      "id_str" : "419811835",
      "id" : 419811835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186477363725484033",
  "geo" : { },
  "id_str" : "186478787138031617",
  "in_reply_to_user_id" : 33829595,
  "text" : "@mattonrails thanks! glad i get to finally prep for it :)",
  "id" : 186478787138031617,
  "in_reply_to_status_id" : 186477363725484033,
  "created_at" : "2012-04-01 15:43:02 +0000",
  "in_reply_to_screen_name" : "mattreduce",
  "in_reply_to_user_id_str" : "33829595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186465155205443585",
  "text" : "Google's April Fool's Day videos are so well produced, I wonder if they literally spend the whole year on them. What a colossal waste.",
  "id" : 186465155205443585,
  "created_at" : "2012-04-01 14:48:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/hkvSGS76",
      "expanded_url" : "http:\/\/railsconf2012.com\/sessions",
      "display_url" : "railsconf2012.com\/sessions"
    } ]
  },
  "geo" : { },
  "id_str" : "186462756298432512",
  "text" : "I'm talking at #railsconf! Woot! http:\/\/t.co\/hkvSGS76",
  "id" : 186462756298432512,
  "created_at" : "2012-04-01 14:39:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186325259601985536",
  "text" : "See you on Monday, internet.",
  "id" : 186325259601985536,
  "created_at" : "2012-04-01 05:32:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186319652035629057",
  "text" : "Starting on a scorching hot volcano on an island isolated from other civilizations has helped immensely.",
  "id" : 186319652035629057,
  "created_at" : "2012-04-01 05:10:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/186319524155494400\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/s3rIvWW4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApXwnryCEAAJgJi.png",
      "id_str" : "186319524163883008",
      "id" : 186319524163883008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApXwnryCEAAJgJi.png",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 843
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 843
      } ],
      "display_url" : "pic.twitter.com\/s3rIvWW4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186319524155494400",
  "text" : "Dwarf Fortress continues to astound me. WORKCOMBAT is thriving. 5 megabeasts down, Metal industry FTW. http:\/\/t.co\/s3rIvWW4",
  "id" : 186319524155494400,
  "created_at" : "2012-04-01 05:10:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252558638730850304",
  "geo" : { },
  "id_str" : "252612763157929984",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape s\/apple\/any",
  "id" : 252612763157929984,
  "in_reply_to_status_id" : 252558638730850304,
  "created_at" : "2012-10-01 03:35:50 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin",
      "screen_name" : "mannkind",
      "indices" : [ 0, 9 ],
      "id_str" : "7785882",
      "id" : 7785882
    }, {
      "name" : "Marco.org",
      "screen_name" : "marco_org",
      "indices" : [ 10, 20 ],
      "id_str" : "477898117",
      "id" : 477898117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252598654878228480",
  "geo" : { },
  "id_str" : "252612710662029312",
  "in_reply_to_user_id" : 7785882,
  "text" : "@mannkind @marco_org I hope so.",
  "id" : 252612710662029312,
  "in_reply_to_status_id" : 252598654878228480,
  "created_at" : "2012-10-01 03:35:38 +0000",
  "in_reply_to_screen_name" : "mannkind",
  "in_reply_to_user_id_str" : "7785882",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/Kj2bKjlT",
      "expanded_url" : "http:\/\/www.marco.org\/2012\/09\/30\/ipad-1",
      "display_url" : "marco.org\/2012\/09\/30\/ipa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "252555217248337920",
  "text" : "Very unhappy about my iPad 1 being obsoleted. :( http:\/\/t.co\/Kj2bKjlT",
  "id" : 252555217248337920,
  "created_at" : "2012-09-30 23:47:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252488903385313280",
  "text" : "FTL is hellishly hard even on easy. This game is evil.",
  "id" : 252488903385313280,
  "created_at" : "2012-09-30 19:23:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 22, 32 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252486781340119040",
  "geo" : { },
  "id_str" : "252487252767297537",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante very sure @aquaranto saw him say this.",
  "id" : 252487252767297537,
  "in_reply_to_status_id" : 252486781340119040,
  "created_at" : "2012-09-30 19:17:06 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Jarvis",
      "screen_name" : "lee_jarvis",
      "indices" : [ 0, 11 ],
      "id_str" : "137640366",
      "id" : 137640366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252458039666413568",
  "geo" : { },
  "id_str" : "252462743809048576",
  "in_reply_to_user_id" : 137640366,
  "text" : "@lee_jarvis don\u2019t click it! I did the same thing and that\u2019s how it started",
  "id" : 252462743809048576,
  "in_reply_to_status_id" : 252458039666413568,
  "created_at" : "2012-09-30 17:39:43 +0000",
  "in_reply_to_screen_name" : "lee_jarvis",
  "in_reply_to_user_id_str" : "137640366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 114 ],
      "url" : "https:\/\/t.co\/O2xTJW5w",
      "expanded_url" : "https:\/\/twitter.com\/settings\/applications",
      "display_url" : "twitter.com\/settings\/appli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "252457698447216640",
  "text" : "Revoked access to all apps, changed password. I hate everything. Daily reminder to clear out https:\/\/t.co\/O2xTJW5w.",
  "id" : 252457698447216640,
  "created_at" : "2012-09-30 17:19:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252455931735068674",
  "geo" : { },
  "id_str" : "252456301781737472",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss yeah going to do it just to be safe. I recently audited the list down...but time to do it again.",
  "id" : 252456301781737472,
  "in_reply_to_status_id" : 252455931735068674,
  "created_at" : "2012-09-30 17:14:07 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252454433022177280",
  "text" : "My account has been sending shitloads of DMs and I have no idea why...changed my password. Nothing fishy in app usage...WTF",
  "id" : 252454433022177280,
  "created_at" : "2012-09-30 17:06:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Priit",
      "screen_name" : "priithaamer",
      "indices" : [ 3, 15 ],
      "id_str" : "14387643",
      "id" : 14387643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 100 ],
      "url" : "https:\/\/t.co\/xsbDehkp",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "252422264342077440",
  "text" : "RT @priithaamer: Converting edicy maintenance scripts to use sub by 37signals: https:\/\/t.co\/xsbDehkp That's pretty cool.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 83 ],
        "url" : "https:\/\/t.co\/xsbDehkp",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "252362972813467649",
    "text" : "Converting edicy maintenance scripts to use sub by 37signals: https:\/\/t.co\/xsbDehkp That's pretty cool.",
    "id" : 252362972813467649,
    "created_at" : "2012-09-30 11:03:16 +0000",
    "user" : {
      "name" : "Priit",
      "screen_name" : "priithaamer",
      "protected" : false,
      "id_str" : "14387643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3318698094\/91e4c7be0f76807e8df9160a35c6c09d_normal.jpeg",
      "id" : 14387643,
      "verified" : false
    }
  },
  "id" : 252422264342077440,
  "created_at" : "2012-09-30 14:58:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/N9HWHB5o",
      "expanded_url" : "http:\/\/instagr.am\/p\/QLnz81M6lj\/",
      "display_url" : "instagr.am\/p\/QLnz81M6lj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "252223465816469504",
  "text" : "AQ 2.0! http:\/\/t.co\/N9HWHB5o",
  "id" : 252223465816469504,
  "created_at" : "2012-09-30 01:48:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Von Fange",
      "screen_name" : "danielvf",
      "indices" : [ 3, 12 ],
      "id_str" : "5678",
      "id" : 5678
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 139, 140 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/aP4WqEp1",
      "expanded_url" : "http:\/\/client.com",
      "display_url" : "client.com"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qhYPNwfh",
      "expanded_url" : "http:\/\/bit.ly\/Qdj4VV",
      "display_url" : "bit.ly\/Qdj4VV"
    } ]
  },
  "geo" : { },
  "id_str" : "252221409659588608",
  "text" : "RT @danielvf: I type \"work on http:\/\/t.co\/aP4WqEp1 'feature whatever'\" and I'm clocked in from the command line. Thanks http:\/\/t.co\/qhYP ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 131, 137 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http:\/\/t.co\/aP4WqEp1",
        "expanded_url" : "http:\/\/client.com",
        "display_url" : "client.com"
      }, {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/qhYPNwfh",
        "expanded_url" : "http:\/\/bit.ly\/Qdj4VV",
        "display_url" : "bit.ly\/Qdj4VV"
      } ]
    },
    "geo" : { },
    "id_str" : "252211787833958400",
    "text" : "I type \"work on http:\/\/t.co\/aP4WqEp1 'feature whatever'\" and I'm clocked in from the command line. Thanks http:\/\/t.co\/qhYPNwfh and @qrush",
    "id" : 252211787833958400,
    "created_at" : "2012-09-30 01:02:30 +0000",
    "user" : {
      "name" : "Daniel Von Fange",
      "screen_name" : "danielvf",
      "protected" : false,
      "id_str" : "5678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/149618640\/daniel_face_normal.jpg",
      "id" : 5678,
      "verified" : false
    }
  },
  "id" : 252221409659588608,
  "created_at" : "2012-09-30 01:40:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Von Fange",
      "screen_name" : "danielvf",
      "indices" : [ 0, 9 ],
      "id_str" : "5678",
      "id" : 5678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252211787833958400",
  "geo" : { },
  "id_str" : "252221375887077376",
  "in_reply_to_user_id" : 5678,
  "text" : "@danielvf woot!!",
  "id" : 252221375887077376,
  "in_reply_to_status_id" : 252211787833958400,
  "created_at" : "2012-09-30 01:40:36 +0000",
  "in_reply_to_screen_name" : "danielvf",
  "in_reply_to_user_id_str" : "5678",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252166722285600769",
  "text" : "RT @steveklabnik: Riding your bike in a city is basically accepting that death's sweet embrace may come at any moment.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252165545087098881",
    "text" : "Riding your bike in a city is basically accepting that death's sweet embrace may come at any moment.",
    "id" : 252165545087098881,
    "created_at" : "2012-09-29 21:58:45 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 252166722285600769,
  "created_at" : "2012-09-29 22:03:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252148370745995264",
  "text" : "Had my first Apple Maps Navigation experience today. Design is great, integration into the OS is the real win.",
  "id" : 252148370745995264,
  "created_at" : "2012-09-29 20:50:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Cherevko",
      "screen_name" : "ichrvk",
      "indices" : [ 3, 10 ],
      "id_str" : "133460644",
      "id" : 133460644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Th7BBIsQ",
      "expanded_url" : "http:\/\/buff.ly\/OtOxq5",
      "display_url" : "buff.ly\/OtOxq5"
    } ]
  },
  "geo" : { },
  "id_str" : "252134397891981313",
  "text" : "RT @ichrvk: That's the proper way to run devops \u21D2 Automating with convention: Introducing sub - (37signals) http:\/\/t.co\/Th7BBIsQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/Th7BBIsQ",
        "expanded_url" : "http:\/\/buff.ly\/OtOxq5",
        "display_url" : "buff.ly\/OtOxq5"
      } ]
    },
    "geo" : { },
    "id_str" : "252118064450117632",
    "text" : "That's the proper way to run devops \u21D2 Automating with convention: Introducing sub - (37signals) http:\/\/t.co\/Th7BBIsQ",
    "id" : 252118064450117632,
    "created_at" : "2012-09-29 18:50:05 +0000",
    "user" : {
      "name" : "Ivan Cherevko",
      "screen_name" : "ichrvk",
      "protected" : false,
      "id_str" : "133460644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511163776880496640\/FcUUf3ED_normal.jpeg",
      "id" : 133460644,
      "verified" : false
    }
  },
  "id" : 252134397891981313,
  "created_at" : "2012-09-29 19:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sam :",
      "screen_name" : "Lenary",
      "indices" : [ 3, 10 ],
      "id_str" : "14466962",
      "id" : 14466962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/WCGQfzZC",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
      "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "252134364966707200",
  "text" : "RT @Lenary: So I've been working on my own toolbelt using http:\/\/t.co\/WCGQfzZC - it's so easy to work with!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/WCGQfzZC",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
        "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "252130338409693184",
    "text" : "So I've been working on my own toolbelt using http:\/\/t.co\/WCGQfzZC - it's so easy to work with!",
    "id" : 252130338409693184,
    "created_at" : "2012-09-29 19:38:51 +0000",
    "user" : {
      "name" : "sam :",
      "screen_name" : "Lenary",
      "protected" : false,
      "id_str" : "14466962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539353854198833152\/QPch1gGe_normal.jpeg",
      "id" : 14466962,
      "verified" : false
    }
  },
  "id" : 252134364966707200,
  "created_at" : "2012-09-29 19:54:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sam :",
      "screen_name" : "Lenary",
      "indices" : [ 0, 7 ],
      "id_str" : "14466962",
      "id" : 14466962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252130338409693184",
  "geo" : { },
  "id_str" : "252134351293259776",
  "in_reply_to_user_id" : 14466962,
  "text" : "@Lenary yay!",
  "id" : 252134351293259776,
  "in_reply_to_status_id" : 252130338409693184,
  "created_at" : "2012-09-29 19:54:48 +0000",
  "in_reply_to_screen_name" : "Lenary",
  "in_reply_to_user_id_str" : "14466962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Buffalogal in NYC",
      "screen_name" : "Buffalogal",
      "indices" : [ 0, 11 ],
      "id_str" : "14500105",
      "id" : 14500105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/4zEalyXL",
      "expanded_url" : "http:\/\/lmgtfy.com\/?q=Blackman+farm",
      "display_url" : "lmgtfy.com\/?q=Blackman+fa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "252123669923504128",
  "geo" : { },
  "id_str" : "252133988867637248",
  "in_reply_to_user_id" : 14500105,
  "text" : "@Buffalogal http:\/\/t.co\/4zEalyXL",
  "id" : 252133988867637248,
  "in_reply_to_status_id" : 252123669923504128,
  "created_at" : "2012-09-29 19:53:22 +0000",
  "in_reply_to_screen_name" : "Buffalogal",
  "in_reply_to_user_id_str" : "14500105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/ynH4KkWJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/QK8_JKs6pX\/",
      "display_url" : "instagr.am\/p\/QK8_JKs6pX\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.1843545696, -78.7583899498 ]
  },
  "id_str" : "252129321395834880",
  "text" : "Donkey Kong?  @ Freedom Run Winery http:\/\/t.co\/ynH4KkWJ",
  "id" : 252129321395834880,
  "created_at" : "2012-09-29 19:34:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/9FJlamGI",
      "expanded_url" : "http:\/\/instagr.am\/p\/QK8OCfM6oq\/",
      "display_url" : "instagr.am\/p\/QK8OCfM6oq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.1843545696, -78.7583899498 ]
  },
  "id_str" : "252127597562052608",
  "text" : "Just posted a photo  @ Freedom Run Winery http:\/\/t.co\/9FJlamGI",
  "id" : 252127597562052608,
  "created_at" : "2012-09-29 19:27:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Buffalogal in NYC",
      "screen_name" : "Buffalogal",
      "indices" : [ 0, 11 ],
      "id_str" : "14500105",
      "id" : 14500105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252115271744102402",
  "geo" : { },
  "id_str" : "252123393669857280",
  "in_reply_to_user_id" : 14500105,
  "text" : "@Buffalogal Blackman farms.",
  "id" : 252123393669857280,
  "in_reply_to_status_id" : 252115271744102402,
  "created_at" : "2012-09-29 19:11:15 +0000",
  "in_reply_to_screen_name" : "Buffalogal",
  "in_reply_to_user_id_str" : "14500105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/X0LzMDXp",
      "expanded_url" : "http:\/\/instagr.am\/p\/QK1-83s6iT\/",
      "display_url" : "instagr.am\/p\/QK1-83s6iT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.1763446331, -78.80021909 ]
  },
  "id_str" : "252114107069763584",
  "text" : "\uD83C\uDF4E  @ Blackman Homestead Farm http:\/\/t.co\/X0LzMDXp",
  "id" : 252114107069763584,
  "created_at" : "2012-09-29 18:34:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/og1WsVfW",
      "expanded_url" : "http:\/\/instagr.am\/p\/QK15Pds6iN\/",
      "display_url" : "instagr.am\/p\/QK15Pds6iN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.1763446331, -78.80021909 ]
  },
  "id_str" : "252113692886450176",
  "text" : "Apple time.  @ Blackman Homestead Farm http:\/\/t.co\/og1WsVfW",
  "id" : 252113692886450176,
  "created_at" : "2012-09-29 18:32:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252052470119923712",
  "text" : "Oh snap, Castle Crashers on Steam...",
  "id" : 252052470119923712,
  "created_at" : "2012-09-29 14:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Pearson",
      "screen_name" : "josephpearson",
      "indices" : [ 0, 14 ],
      "id_str" : "5737112",
      "id" : 5737112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251895088278564864",
  "geo" : { },
  "id_str" : "251899530730168320",
  "in_reply_to_user_id" : 5737112,
  "text" : "@josephpearson I bet the S3 upload failed. :( just yank for now\u2026",
  "id" : 251899530730168320,
  "in_reply_to_status_id" : 251895088278564864,
  "created_at" : "2012-09-29 04:21:42 +0000",
  "in_reply_to_screen_name" : "josephpearson",
  "in_reply_to_user_id_str" : "5737112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251882089698443265",
  "text" : "Daily reminder that apple cider + Kraken rum + cinnamon sticks = crazy delicious!",
  "id" : 251882089698443265,
  "created_at" : "2012-09-29 03:12:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/0JsuLLia",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sFacWGBJ_cs",
      "display_url" : "youtube.com\/watch?v=sFacWG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251870382322221056",
  "text" : "Current status: http:\/\/t.co\/0JsuLLia",
  "id" : 251870382322221056,
  "created_at" : "2012-09-29 02:25:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251862515405975552",
  "geo" : { },
  "id_str" : "251862763197067264",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss we\u2019re starting Power Struggle. Your move.",
  "id" : 251862763197067264,
  "in_reply_to_status_id" : 251862515405975552,
  "created_at" : "2012-09-29 01:55:36 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251862515405975552",
  "geo" : { },
  "id_str" : "251862667877285888",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss nice!!",
  "id" : 251862667877285888,
  "in_reply_to_status_id" : 251862515405975552,
  "created_at" : "2012-09-29 01:55:14 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251842594793979904",
  "geo" : { },
  "id_str" : "251855486721335296",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney yeah, we have the big box.",
  "id" : 251855486721335296,
  "in_reply_to_status_id" : 251842594793979904,
  "created_at" : "2012-09-29 01:26:41 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/bWQTy4Ka",
      "expanded_url" : "http:\/\/instagr.am\/p\/QI28FIM6vc\/",
      "display_url" : "instagr.am\/p\/QI28FIM6vc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "251834551956017152",
  "text" : "Bridges! http:\/\/t.co\/bWQTy4Ka",
  "id" : 251834551956017152,
  "created_at" : "2012-09-29 00:03:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251805278343950336",
  "text" : "Last episode on Dumb Shit People Bring Inside The Dog Park: Paper towel roll. Today\u2019s episode: Open bag of chips and a 2-liter.",
  "id" : 251805278343950336,
  "created_at" : "2012-09-28 22:07:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 0, 8 ],
      "id_str" : "9395832",
      "id" : 9395832
    }, {
      "name" : "Justin French",
      "screen_name" : "justinfrench",
      "indices" : [ 9, 22 ],
      "id_str" : "9254052",
      "id" : 9254052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251758225823760384",
  "geo" : { },
  "id_str" : "251804308214009856",
  "in_reply_to_user_id" : 9395832,
  "text" : "@dcurtis @justinfrench two people is a mass exodus?",
  "id" : 251804308214009856,
  "in_reply_to_status_id" : 251758225823760384,
  "created_at" : "2012-09-28 22:03:20 +0000",
  "in_reply_to_screen_name" : "dcurtis",
  "in_reply_to_user_id_str" : "9395832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/hFUA4znD",
      "expanded_url" : "http:\/\/instagr.am\/p\/QIh186M6tn\/",
      "display_url" : "instagr.am\/p\/QIh186M6tn\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8905151946, -78.8764491357 ]
  },
  "id_str" : "251788208575242241",
  "text" : "There's a blimp over downtown Buffalo right now.  @ CoworkBuffalo http:\/\/t.co\/hFUA4znD",
  "id" : 251788208575242241,
  "created_at" : "2012-09-28 20:59:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251781298622984192",
  "geo" : { },
  "id_str" : "251781478676054016",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt there's a board game version of puzzle quest? My life, I can see the end.",
  "id" : 251781478676054016,
  "in_reply_to_status_id" : 251781298622984192,
  "created_at" : "2012-09-28 20:32:37 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/cokBwkY9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=O3syQV7WDAU",
      "display_url" : "youtube.com\/watch?v=O3syQV\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "251779980537765888",
  "geo" : { },
  "id_str" : "251780693582036993",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt his chest exploding was even worse http:\/\/t.co\/cokBwkY9",
  "id" : 251780693582036993,
  "in_reply_to_status_id" : 251779980537765888,
  "created_at" : "2012-09-28 20:29:29 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 9, 19 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251772625322405888",
  "geo" : { },
  "id_str" : "251779370979581953",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending @magnachef i love this idea too",
  "id" : 251779370979581953,
  "in_reply_to_status_id" : 251772625322405888,
  "created_at" : "2012-09-28 20:24:14 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Tutty",
      "screen_name" : "mtutty",
      "indices" : [ 0, 7 ],
      "id_str" : "13699472",
      "id" : 13699472
    }, {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 35, 48 ],
      "id_str" : "19386993",
      "id" : 19386993
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 56, 70 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251763932363120640",
  "geo" : { },
  "id_str" : "251764474414002176",
  "in_reply_to_user_id" : 13699472,
  "text" : "@mtutty cool! you should check out @coworkingroc and\/or @coworkbuffalo :)",
  "id" : 251764474414002176,
  "in_reply_to_status_id" : 251763932363120640,
  "created_at" : "2012-09-28 19:25:02 +0000",
  "in_reply_to_screen_name" : "mtutty",
  "in_reply_to_user_id_str" : "13699472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Tutty",
      "screen_name" : "mtutty",
      "indices" : [ 0, 7 ],
      "id_str" : "13699472",
      "id" : 13699472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251761778189553664",
  "geo" : { },
  "id_str" : "251763191720333312",
  "in_reply_to_user_id" : 13699472,
  "text" : "@mtutty not sure what you mean? sysadmins wouldn't use it?",
  "id" : 251763191720333312,
  "in_reply_to_status_id" : 251761778189553664,
  "created_at" : "2012-09-28 19:19:57 +0000",
  "in_reply_to_screen_name" : "mtutty",
  "in_reply_to_user_id_str" : "13699472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Gardner",
      "screen_name" : "Lucas_Gardner",
      "indices" : [ 0, 14 ],
      "id_str" : "127359951",
      "id" : 127359951
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 15, 30 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251760131996516352",
  "geo" : { },
  "id_str" : "251760403690967040",
  "in_reply_to_user_id" : 127359951,
  "text" : "@Lucas_Gardner @ChrisVanPatten aww, lame.",
  "id" : 251760403690967040,
  "in_reply_to_status_id" : 251760131996516352,
  "created_at" : "2012-09-28 19:08:52 +0000",
  "in_reply_to_screen_name" : "Lucas_Gardner",
  "in_reply_to_user_id_str" : "127359951",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 11, 19 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251754820891971586",
  "geo" : { },
  "id_str" : "251755265056206849",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @fending i love this idea",
  "id" : 251755265056206849,
  "in_reply_to_status_id" : 251754820891971586,
  "created_at" : "2012-09-28 18:48:27 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251753471966064640",
  "geo" : { },
  "id_str" : "251753876879978496",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik yeah no idea what will happen...leaving it as an open problem :)",
  "id" : 251753876879978496,
  "in_reply_to_status_id" : 251753471966064640,
  "created_at" : "2012-09-28 18:42:56 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/Xfl5qttF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=768h3Tz4Qik",
      "display_url" : "youtube.com\/watch?v=768h3T\u2026"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/JXC89wWY",
      "expanded_url" : "http:\/\/thehill.com\/blogs\/hillicon-valley\/technology\/258985-microsoft-lack-of-tech-workers-approaching-genuine-crisis",
      "display_url" : "thehill.com\/blogs\/hillicon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251753432808054784",
  "text" : "RT @dhh: In http:\/\/t.co\/Xfl5qttF, South Park summarizes the comment sentiments on 'MSFT seeking more H1Bs': http:\/\/t.co\/JXC89wWY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 3, 23 ],
        "url" : "http:\/\/t.co\/Xfl5qttF",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=768h3Tz4Qik",
        "display_url" : "youtube.com\/watch?v=768h3T\u2026"
      }, {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/JXC89wWY",
        "expanded_url" : "http:\/\/thehill.com\/blogs\/hillicon-valley\/technology\/258985-microsoft-lack-of-tech-workers-approaching-genuine-crisis",
        "display_url" : "thehill.com\/blogs\/hillicon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "251753155585531905",
    "text" : "In http:\/\/t.co\/Xfl5qttF, South Park summarizes the comment sentiments on 'MSFT seeking more H1Bs': http:\/\/t.co\/JXC89wWY",
    "id" : 251753155585531905,
    "created_at" : "2012-09-28 18:40:04 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 251753432808054784,
  "created_at" : "2012-09-28 18:41:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/2LWRUWbA",
      "expanded_url" : "https:\/\/github.com\/qrush\/q\/blob\/master\/libexec\/q-findhog",
      "display_url" : "github.com\/qrush\/q\/blob\/m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "251752225309872128",
  "geo" : { },
  "id_str" : "251753250632646657",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik All I have so far in my personal one is: https:\/\/t.co\/2LWRUWbA Going to pile more stuff in as I run across them.",
  "id" : 251753250632646657,
  "in_reply_to_status_id" : 251752225309872128,
  "created_at" : "2012-09-28 18:40:26 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251751746592993280",
  "text" : "About time the most illest scientist got back on the tweeters. @bill_nye_tho_II",
  "id" : 251751746592993280,
  "created_at" : "2012-09-28 18:34:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/wdGZUZuY",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub\/pull\/4",
      "display_url" : "github.com\/37signals\/sub\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251749538191257600",
  "text" : "Two pull requests for sub already. I love open source. https:\/\/t.co\/wdGZUZuY",
  "id" : 251749538191257600,
  "created_at" : "2012-09-28 18:25:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251741534184165376",
  "geo" : { },
  "id_str" : "251741626521747457",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi oh totally",
  "id" : 251741626521747457,
  "in_reply_to_status_id" : 251741534184165376,
  "created_at" : "2012-09-28 17:54:15 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/cVKKtIGp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=2Ggsatysy4M",
      "display_url" : "youtube.com\/watch?v=2Ggsat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251740916518363136",
  "text" : "People like this exist: http:\/\/t.co\/cVKKtIGp",
  "id" : 251740916518363136,
  "created_at" : "2012-09-28 17:51:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251735439327760384",
  "geo" : { },
  "id_str" : "251735774016462849",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham thanks! took me far too long to realize how nice it was.",
  "id" : 251735774016462849,
  "in_reply_to_status_id" : 251735439327760384,
  "created_at" : "2012-09-28 17:31:00 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 0, 7 ],
      "id_str" : "7516242",
      "id" : 7516242
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 8, 20 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251732520570347520",
  "geo" : { },
  "id_str" : "251733798230822913",
  "in_reply_to_user_id" : 7516242,
  "text" : "@mislav @sstephenson oh, awesome! You should be able to just dump the libexec\/ dir into a prepared sub. or just copy stuff over.",
  "id" : 251733798230822913,
  "in_reply_to_status_id" : 251732520570347520,
  "created_at" : "2012-09-28 17:23:09 +0000",
  "in_reply_to_screen_name" : "mislav",
  "in_reply_to_user_id_str" : "7516242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uF8FF Mario A Chavez",
      "screen_name" : "mario_chavez",
      "indices" : [ 3, 16 ],
      "id_str" : "5785532",
      "id" : 5785532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 79 ],
      "url" : "https:\/\/t.co\/XEIwfYJK",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "251731253978611712",
  "text" : "RT @mario_chavez: Run and share your commands like a boss https:\/\/t.co\/XEIwfYJK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 61 ],
        "url" : "https:\/\/t.co\/XEIwfYJK",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "251730825731776513",
    "text" : "Run and share your commands like a boss https:\/\/t.co\/XEIwfYJK",
    "id" : 251730825731776513,
    "created_at" : "2012-09-28 17:11:20 +0000",
    "user" : {
      "name" : "\uF8FF Mario A Chavez",
      "screen_name" : "mario_chavez",
      "protected" : false,
      "id_str" : "5785532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543843339066691584\/chLa2AVI_normal.jpeg",
      "id" : 5785532,
      "verified" : false
    }
  },
  "id" : 251731253978611712,
  "created_at" : "2012-09-28 17:13:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Sheehan",
      "screen_name" : "johnsheehan",
      "indices" : [ 0, 12 ],
      "id_str" : "11381522",
      "id" : 11381522
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 13, 26 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251729465229586434",
  "geo" : { },
  "id_str" : "251731047174270977",
  "in_reply_to_user_id" : 11381522,
  "text" : "@johnsheehan @steveklabnik check out Excon.",
  "id" : 251731047174270977,
  "in_reply_to_status_id" : 251729465229586434,
  "created_at" : "2012-09-28 17:12:13 +0000",
  "in_reply_to_screen_name" : "johnsheehan",
  "in_reply_to_user_id_str" : "11381522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 0, 11 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/CXkaWEeD",
      "expanded_url" : "http:\/\/www.vice.com\/the-vice-guide-to-travel\/vice-guide-to-north-korea-1-of-3",
      "display_url" : "vice.com\/the-vice-guide\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "251727782059589633",
  "geo" : { },
  "id_str" : "251728232397811712",
  "in_reply_to_user_id" : 25678101,
  "text" : "@natebenson set aside some time for this: http:\/\/t.co\/CXkaWEeD",
  "id" : 251728232397811712,
  "in_reply_to_status_id" : 251727782059589633,
  "created_at" : "2012-09-28 17:01:02 +0000",
  "in_reply_to_screen_name" : "natebenson",
  "in_reply_to_user_id_str" : "25678101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251717991161544705",
  "geo" : { },
  "id_str" : "251723772556627968",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman interesting, i'd think Hubot would know everything ;) I'd love to see GH have their own sub.",
  "id" : 251723772556627968,
  "in_reply_to_status_id" : 251717991161544705,
  "created_at" : "2012-09-28 16:43:18 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251718798334386176",
  "geo" : { },
  "id_str" : "251721138168799232",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris yeah i'm not sure if forking is the best way to continue here. I'd imagine it's cool for personal stuff.",
  "id" : 251721138168799232,
  "in_reply_to_status_id" : 251718798334386176,
  "created_at" : "2012-09-28 16:32:50 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251718798334386176",
  "geo" : { },
  "id_str" : "251719802392018944",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris tasty!",
  "id" : 251719802392018944,
  "in_reply_to_status_id" : 251718798334386176,
  "created_at" : "2012-09-28 16:27:32 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251706818441650177",
  "geo" : { },
  "id_str" : "251716037983223808",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k thanks! and hell yes. It's Around the World time.",
  "id" : 251716037983223808,
  "in_reply_to_status_id" : 251706818441650177,
  "created_at" : "2012-09-28 16:12:34 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251697967533273089",
  "geo" : { },
  "id_str" : "251698458988273664",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I started a personal one called \"q\"",
  "id" : 251698458988273664,
  "in_reply_to_status_id" : 251697967533273089,
  "created_at" : "2012-09-28 15:02:43 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251696989262184450",
  "geo" : { },
  "id_str" : "251697096351154176",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr thanks!",
  "id" : 251697096351154176,
  "in_reply_to_status_id" : 251696989262184450,
  "created_at" : "2012-09-28 14:57:18 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Szmajda",
      "screen_name" : "jszmajda",
      "indices" : [ 0, 9 ],
      "id_str" : "2049811",
      "id" : 2049811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251660282009645057",
  "geo" : { },
  "id_str" : "251696642795896832",
  "in_reply_to_user_id" : 2049811,
  "text" : "@jszmajda I can get you a list of the top 100, 1000, 10000 gems by download? would that help?",
  "id" : 251696642795896832,
  "in_reply_to_status_id" : 251660282009645057,
  "created_at" : "2012-09-28 14:55:30 +0000",
  "in_reply_to_screen_name" : "jszmajda",
  "in_reply_to_user_id_str" : "2049811",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 71, 83 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Y8tKNFNf",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
      "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251696410632794114",
  "text" : "Very happy to introduce Sub: http:\/\/t.co\/Y8tKNFNf (and a big thanks to @sstephenson for helping me extract it!)",
  "id" : 251696410632794114,
  "created_at" : "2012-09-28 14:54:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 17, 23 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 24, 32 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251533334226804737",
  "geo" : { },
  "id_str" : "251547043603038209",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @sferik @cmeik @drbrain I am in bed, about to pass out. Sorry gents.",
  "id" : 251547043603038209,
  "in_reply_to_status_id" : 251533334226804737,
  "created_at" : "2012-09-28 05:01:03 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251546882478850049",
  "text" : "I ship, therefore I am.",
  "id" : 251546882478850049,
  "created_at" : "2012-09-28 05:00:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/H5iJICoG",
      "expanded_url" : "http:\/\/blog.steveklabnik.com\/posts\/2012-09-27-seriously--numbers--use-them-",
      "display_url" : "blog.steveklabnik.com\/posts\/2012-09-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251490833017221121",
  "text" : "RT @steveklabnik: Seriously. Numbers. Use them. http:\/\/t.co\/H5iJICoG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/H5iJICoG",
        "expanded_url" : "http:\/\/blog.steveklabnik.com\/posts\/2012-09-27-seriously--numbers--use-them-",
        "display_url" : "blog.steveklabnik.com\/posts\/2012-09-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "251490407765118976",
    "text" : "Seriously. Numbers. Use them. http:\/\/t.co\/H5iJICoG",
    "id" : 251490407765118976,
    "created_at" : "2012-09-28 01:16:00 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 251490833017221121,
  "created_at" : "2012-09-28 01:17:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/PWlxECcJ",
      "expanded_url" : "http:\/\/bukk.it\/delish.gif",
      "display_url" : "bukk.it\/delish.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "251483765841473536",
  "text" : "Also just realized that apple cider + Kraken + cinnamon sticks = http:\/\/t.co\/PWlxECcJ",
  "id" : 251483765841473536,
  "created_at" : "2012-09-28 00:49:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 27, 38 ],
      "id_str" : "20751318",
      "id" : 20751318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251482873457176576",
  "text" : "Just realized I can't make @barcamproc. :(",
  "id" : 251482873457176576,
  "created_at" : "2012-09-28 00:46:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 10, 23 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251440359605927936",
  "geo" : { },
  "id_str" : "251441757601021952",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage @steveklabnik it needs much help. GL HF!",
  "id" : 251441757601021952,
  "in_reply_to_status_id" : 251440359605927936,
  "created_at" : "2012-09-27 22:02:41 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 17, 23 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 24, 32 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 67 ],
      "url" : "https:\/\/t.co\/aYcTwTZf",
      "expanded_url" : "https:\/\/gist.github.com\/3796698",
      "display_url" : "gist.github.com\/3796698"
    } ]
  },
  "in_reply_to_status_id_str" : "251440045448364033",
  "geo" : { },
  "id_str" : "251440621376638976",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @sferik @cmeik @drbrain seems happy! https:\/\/t.co\/aYcTwTZf",
  "id" : 251440621376638976,
  "in_reply_to_status_id" : 251440045448364033,
  "created_at" : "2012-09-27 21:58:10 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251440045448364033",
  "geo" : { },
  "id_str" : "251440178143580160",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx this feels mega fast...",
  "id" : 251440178143580160,
  "in_reply_to_status_id" : 251440045448364033,
  "created_at" : "2012-09-27 21:56:24 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251420596011954176",
  "geo" : { },
  "id_str" : "251439473722793985",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik Jekyll next?",
  "id" : 251439473722793985,
  "in_reply_to_status_id" : 251420596011954176,
  "created_at" : "2012-09-27 21:53:36 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 3, 11 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/umRfVmjf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=f4u7WmA5n4Q",
      "display_url" : "youtube.com\/watch?v=f4u7Wm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251417945404735489",
  "text" : "RT @jayunit: every time i git rebase successfully, in my head it's like R-R-R-REEEE-BAASE!! plus this: http:\/\/t.co\/umRfVmjf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/umRfVmjf",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=f4u7WmA5n4Q",
        "display_url" : "youtube.com\/watch?v=f4u7Wm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "251417448958554112",
    "text" : "every time i git rebase successfully, in my head it's like R-R-R-REEEE-BAASE!! plus this: http:\/\/t.co\/umRfVmjf",
    "id" : 251417448958554112,
    "created_at" : "2012-09-27 20:26:05 +0000",
    "user" : {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "protected" : false,
      "id_str" : "14238213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1435351938\/jason2_normal.png",
      "id" : 14238213,
      "verified" : false
    }
  },
  "id" : 251417945404735489,
  "created_at" : "2012-09-27 20:28:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/TV60qmjy",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=IYEsmlzkQtM&feature=plcp",
      "display_url" : "youtube.com\/watch?v=IYEsml\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251360363805806594",
  "text" : "\"Jokingly requested a bar band to play Through The Fire and the Flames by Dragonforce. Then this happened... \" http:\/\/t.co\/TV60qmjy",
  "id" : 251360363805806594,
  "created_at" : "2012-09-27 16:39:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251291408982495233",
  "text" : "RT @neiltyson: As retired Shuttles majestically grace our cityscapes, we shed a silent tear, not for the end of an era but for the absen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "251082947699023872",
    "text" : "As retired Shuttles majestically grace our cityscapes, we shed a silent tear, not for the end of an era but for the absence of a new one.",
    "id" : 251082947699023872,
    "created_at" : "2012-09-26 22:16:54 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 251291408982495233,
  "created_at" : "2012-09-27 12:05:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 0, 6 ],
      "id_str" : "14701738",
      "id" : 14701738
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "largecitycoworkingproblems",
      "indices" : [ 7, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251126909897949184",
  "geo" : { },
  "id_str" : "251133578728071168",
  "in_reply_to_user_id" : 14701738,
  "text" : "@troyd #largecitycoworkingproblems. Seriously.",
  "id" : 251133578728071168,
  "in_reply_to_status_id" : 251126909897949184,
  "created_at" : "2012-09-27 01:38:05 +0000",
  "in_reply_to_screen_name" : "troyd",
  "in_reply_to_user_id_str" : "14701738",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Z4NfQFSR",
      "expanded_url" : "http:\/\/www.sonatype.com\/people\/2012\/09\/upcoming-release-of-nexus-to-add-full-support-for-rubygem-repositories\/",
      "display_url" : "sonatype.com\/people\/2012\/09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251087841285787648",
  "text" : "Neat! Some Java love for http:\/\/t.co\/t7WATcFT. http:\/\/t.co\/Z4NfQFSR",
  "id" : 251087841285787648,
  "created_at" : "2012-09-26 22:36:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 13, 24 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251086139631497216",
  "geo" : { },
  "id_str" : "251086239510446081",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench @Jonplussed Affirmative!",
  "id" : 251086239510446081,
  "in_reply_to_status_id" : 251086139631497216,
  "created_at" : "2012-09-26 22:29:59 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "indices" : [ 3, 9 ],
      "id_str" : "15477591",
      "id" : 15477591
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Braxo\/status\/251052766003339264\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/z4ldg0OY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3vrKRnCIAET0ax.png",
      "id_str" : "251052766007533569",
      "id" : 251052766007533569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3vrKRnCIAET0ax.png",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/z4ldg0OY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251053096883601408",
  "text" : "RT @Braxo: I chuckled at this iOS maps of Niagara Falls. http:\/\/t.co\/z4ldg0OY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Braxo\/status\/251052766003339264\/photo\/1",
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/z4ldg0OY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A3vrKRnCIAET0ax.png",
        "id_str" : "251052766007533569",
        "id" : 251052766007533569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3vrKRnCIAET0ax.png",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/z4ldg0OY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "251052766003339264",
    "text" : "I chuckled at this iOS maps of Niagara Falls. http:\/\/t.co\/z4ldg0OY",
    "id" : 251052766003339264,
    "created_at" : "2012-09-26 20:16:59 +0000",
    "user" : {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "protected" : false,
      "id_str" : "15477591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2929946571\/9ff8217b64a06a9ce2e6ea3373ed1f0a_normal.jpeg",
      "id" : 15477591,
      "verified" : false
    }
  },
  "id" : 251053096883601408,
  "created_at" : "2012-09-26 20:18:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 12, 20 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 111 ],
      "url" : "https:\/\/t.co\/bnv1MspE",
      "expanded_url" : "https:\/\/github.com\/jashkenas\/coffee-script\/pull\/2289",
      "display_url" : "github.com\/jashkenas\/coff\u2026"
    }, {
      "indices" : [ 117, 138 ],
      "url" : "https:\/\/t.co\/0Fsco7tZ",
      "expanded_url" : "https:\/\/github.com\/jashkenas\/coffee-script\/issues\/514",
      "display_url" : "github.com\/jashkenas\/coff\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "251039265788669952",
  "geo" : { },
  "id_str" : "251040083191410689",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser @bascule I proposed, and even implemented a bang method but it was shot down. https:\/\/t.co\/bnv1MspE also https:\/\/t.co\/0Fsco7tZ",
  "id" : 251040083191410689,
  "in_reply_to_status_id" : 251039265788669952,
  "created_at" : "2012-09-26 19:26:34 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 3, 13 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251038759599108097",
  "text" : "RT @samsoffes: Ikea: adult legos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "251037832112635904",
    "text" : "Ikea: adult legos",
    "id" : 251037832112635904,
    "created_at" : "2012-09-26 19:17:37 +0000",
    "user" : {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "protected" : false,
      "id_str" : "6154602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545995221914230785\/N9a6vr0W_normal.jpeg",
      "id" : 6154602,
      "verified" : false
    }
  },
  "id" : 251038759599108097,
  "created_at" : "2012-09-26 19:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "251029160120705024",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Aqueous: Triangle \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 251029160120705024,
  "created_at" : "2012-09-26 18:43:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 0, 10 ],
      "id_str" : "123323498",
      "id" : 123323498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251023101373063169",
  "in_reply_to_user_id" : 123323498,
  "text" : "@jashkenas nevermind, I'm slow and dumb today :)",
  "id" : 251023101373063169,
  "created_at" : "2012-09-26 18:19:05 +0000",
  "in_reply_to_screen_name" : "jashkenas",
  "in_reply_to_user_id_str" : "123323498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 0, 10 ],
      "id_str" : "123323498",
      "id" : 123323498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251006360110641153",
  "geo" : { },
  "id_str" : "251022836175630336",
  "in_reply_to_user_id" : 123323498,
  "text" : "@jashkenas \"ReferenceError: I is not defined\" on run?",
  "id" : 251022836175630336,
  "in_reply_to_status_id" : 251006360110641153,
  "created_at" : "2012-09-26 18:18:02 +0000",
  "in_reply_to_screen_name" : "jashkenas",
  "in_reply_to_user_id_str" : "123323498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251015627802828801",
  "geo" : { },
  "id_str" : "251017096845217792",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss thanks!",
  "id" : 251017096845217792,
  "in_reply_to_status_id" : 251015627802828801,
  "created_at" : "2012-09-26 17:55:14 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 13, 27 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/22VwE1Mq",
      "expanded_url" : "http:\/\/instagr.am\/p\/QDCb3Zs6jm\/",
      "display_url" : "instagr.am\/p\/QDCb3Zs6jm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "251015421485006850",
  "text" : "Oh yes, it's @coworkbuffalo sticker time! http:\/\/t.co\/22VwE1Mq",
  "id" : 251015421485006850,
  "created_at" : "2012-09-26 17:48:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 0, 6 ],
      "id_str" : "14701738",
      "id" : 14701738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250994773920468992",
  "geo" : { },
  "id_str" : "251000810664755200",
  "in_reply_to_user_id" : 14701738,
  "text" : "@troyd application process? Wtf?",
  "id" : 251000810664755200,
  "in_reply_to_status_id" : 250994773920468992,
  "created_at" : "2012-09-26 16:50:31 +0000",
  "in_reply_to_screen_name" : "troyd",
  "in_reply_to_user_id_str" : "14701738",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250986802876395522",
  "text" : "Wow, imgur doesn't allow gifs larger than 2MB?",
  "id" : 250986802876395522,
  "created_at" : "2012-09-26 15:54:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/ioxTJjSV",
      "expanded_url" : "http:\/\/tribalinsight.files.wordpress.com\/2010\/06\/i-want-to-believe.jpg",
      "display_url" : "tribalinsight.files.wordpress.com\/2010\/06\/i-want\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "250971730137477121",
  "text" : "Current status: http:\/\/t.co\/ioxTJjSV",
  "id" : 250971730137477121,
  "created_at" : "2012-09-26 14:54:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250971690752933888",
  "text" : "Apparently I'm a sucker for satire.",
  "id" : 250971690752933888,
  "created_at" : "2012-09-26 14:54:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/zxxHVyeU",
      "expanded_url" : "http:\/\/typicalprogrammer.com\/?p=143",
      "display_url" : "typicalprogrammer.com\/?p=143"
    } ]
  },
  "geo" : { },
  "id_str" : "250970956732964864",
  "text" : "Do want! \"I have a text editor I\u2019ve been using myself that is so complicated it makes VIM look like Notepad\" http:\/\/t.co\/zxxHVyeU",
  "id" : 250970956732964864,
  "created_at" : "2012-09-26 14:51:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Siegel",
      "screen_name" : "jdsiegel",
      "indices" : [ 0, 9 ],
      "id_str" : "16503291",
      "id" : 16503291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250796193960054785",
  "geo" : { },
  "id_str" : "250797242372485120",
  "in_reply_to_user_id" : 16503291,
  "text" : "@jdsiegel nope, haven\u2019t tried easy yet. Some friends of mine have and report its not as soul crushing",
  "id" : 250797242372485120,
  "in_reply_to_status_id" : 250796193960054785,
  "created_at" : "2012-09-26 03:21:36 +0000",
  "in_reply_to_screen_name" : "jdsiegel",
  "in_reply_to_user_id_str" : "16503291",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250794779988877312",
  "geo" : { },
  "id_str" : "250795641872199681",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham engy ship, 4 crew, 2 missiles, ion cannon, pegasus, halberd beam, def 2 droid, cloaking. game requires such crazy perfection.",
  "id" : 250795641872199681,
  "in_reply_to_status_id" : 250794779988877312,
  "created_at" : "2012-09-26 03:15:15 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250793615650086912",
  "text" : "Finally made it to the second phase of FTL's final boss...and seriously, fuck this game, it's so hard.",
  "id" : 250793615650086912,
  "created_at" : "2012-09-26 03:07:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 79, 93 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/250782003769782272\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/vLBMApil",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3r051sCMAA36dv.jpg",
      "id_str" : "250782003773976576",
      "id" : 250782003773976576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3r051sCMAA36dv.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vLBMApil"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250793466190262272",
  "text" : "RT @kevinpurdy: What has four legs, two horns, and almost too much DIY spirit? @coworkbuffalo stickers: http:\/\/t.co\/vLBMApil",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 63, 77 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/250782003769782272\/photo\/1",
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/vLBMApil",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A3r051sCMAA36dv.jpg",
        "id_str" : "250782003773976576",
        "id" : 250782003773976576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3r051sCMAA36dv.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vLBMApil"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250782003769782272",
    "text" : "What has four legs, two horns, and almost too much DIY spirit? @coworkbuffalo stickers: http:\/\/t.co\/vLBMApil",
    "id" : 250782003769782272,
    "created_at" : "2012-09-26 02:21:04 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 250793466190262272,
  "created_at" : "2012-09-26 03:06:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250746214335778816",
  "text" : "Dom on Instagram. I hope this continues.",
  "id" : 250746214335778816,
  "created_at" : "2012-09-25 23:58:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 3, 10 ],
      "id_str" : "158371168",
      "id" : 158371168
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 72, 80 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/IuPhOXN7",
      "expanded_url" : "http:\/\/youtu.be\/bQ1M1_B_wrM",
      "display_url" : "youtu.be\/bQ1M1_B_wrM"
    } ]
  },
  "geo" : { },
  "id_str" : "250745846713434112",
  "text" : "RT @mkdevo: YES!!! Dom Mazzetti vs. Instagram: http:\/\/t.co\/IuPhOXN7 via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 60, 68 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/IuPhOXN7",
        "expanded_url" : "http:\/\/youtu.be\/bQ1M1_B_wrM",
        "display_url" : "youtu.be\/bQ1M1_B_wrM"
      } ]
    },
    "geo" : { },
    "id_str" : "250744376333041665",
    "text" : "YES!!! Dom Mazzetti vs. Instagram: http:\/\/t.co\/IuPhOXN7 via @youtube",
    "id" : 250744376333041665,
    "created_at" : "2012-09-25 23:51:32 +0000",
    "user" : {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "protected" : false,
      "id_str" : "158371168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564127014987120640\/dkdEJyOf_normal.jpeg",
      "id" : 158371168,
      "verified" : false
    }
  },
  "id" : 250745846713434112,
  "created_at" : "2012-09-25 23:57:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250738316679462912",
  "geo" : { },
  "id_str" : "250738509202223104",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape this happens :(",
  "id" : 250738509202223104,
  "in_reply_to_status_id" : 250738316679462912,
  "created_at" : "2012-09-25 23:28:13 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 8, 23 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 64, 75 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 76, 86 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 87, 95 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250729169036656641",
  "geo" : { },
  "id_str" : "250729794113765376",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 @ChrisVanPatten I have never seen this happen. WTF. \/cc @kevinpurdy @magnachef @fending",
  "id" : 250729794113765376,
  "in_reply_to_status_id" : 250729169036656641,
  "created_at" : "2012-09-25 22:53:35 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 8, 23 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250727669895950337",
  "geo" : { },
  "id_str" : "250728607687798784",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 @ChrisVanPatten wtf?",
  "id" : 250728607687798784,
  "in_reply_to_status_id" : 250727669895950337,
  "created_at" : "2012-09-25 22:48:53 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/HcCTFQ7A",
      "expanded_url" : "http:\/\/www.asciiartfarts.com\/20000410.html",
      "display_url" : "asciiartfarts.com\/20000410.html"
    } ]
  },
  "geo" : { },
  "id_str" : "250707031198138368",
  "text" : "I've stumbled upon a veritable gold mine of ASCII art: http:\/\/t.co\/HcCTFQ7A",
  "id" : 250707031198138368,
  "created_at" : "2012-09-25 21:23:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "250675409614667777",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing White Noise Mashups: Broke Phi Broke \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 250675409614667777,
  "created_at" : "2012-09-25 19:17:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "indices" : [ 0, 12 ],
      "id_str" : "198661893",
      "id" : 198661893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250638256608251905",
  "geo" : { },
  "id_str" : "250648914779324417",
  "in_reply_to_user_id" : 198661893,
  "text" : "@eliseworthy woot! always blown away by how often people find it :)",
  "id" : 250648914779324417,
  "in_reply_to_status_id" : 250638256608251905,
  "created_at" : "2012-09-25 17:32:12 +0000",
  "in_reply_to_screen_name" : "eliseworthy",
  "in_reply_to_user_id_str" : "198661893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250599136209022979",
  "text" : "RT @dhh: Maybe your millennials are quitting all the time because your work place sucks and you treat them like fucking aliens?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250598918239444992",
    "text" : "Maybe your millennials are quitting all the time because your work place sucks and you treat them like fucking aliens?",
    "id" : 250598918239444992,
    "created_at" : "2012-09-25 14:13:32 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 250599136209022979,
  "created_at" : "2012-09-25 14:14:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alexander rakoczy",
      "screen_name" : "scissorjammer",
      "indices" : [ 5, 19 ],
      "id_str" : "1413246176",
      "id" : 1413246176
    }, {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 24, 39 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/250595845928529920\/photo\/1",
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/E3vkuGnU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3pLmBsCMAA9aNB.jpg",
      "id_str" : "250595845932724224",
      "id" : 250595845932724224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3pLmBsCMAA9aNB.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E3vkuGnU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250595845928529920",
  "text" : "Yes, @scissorjammer and @gabrielgironda are making my morning right now. http:\/\/t.co\/E3vkuGnU",
  "id" : 250595845928529920,
  "created_at" : "2012-09-25 14:01:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250445160339607552",
  "geo" : { },
  "id_str" : "250453569625538561",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape oh geez\u2026I think so",
  "id" : 250453569625538561,
  "in_reply_to_status_id" : 250445160339607552,
  "created_at" : "2012-09-25 04:35:58 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 14, 22 ],
      "id_str" : "6083342",
      "id" : 6083342
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 23, 32 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250406400809910273",
  "geo" : { },
  "id_str" : "250407409846190082",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @bascule @bitsweat sounds good! Just making sure ;)",
  "id" : 250407409846190082,
  "in_reply_to_status_id" : 250406400809910273,
  "created_at" : "2012-09-25 01:32:33 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250402808464035842",
  "geo" : { },
  "id_str" : "250405911460446208",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik are you running Resque anywhere in production ? Or just fixing stuff?",
  "id" : 250405911460446208,
  "in_reply_to_status_id" : 250402808464035842,
  "created_at" : "2012-09-25 01:26:36 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 8, 18 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/250404696366399489\/photo\/1",
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/fC6RWxaO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3mdvqFCQAEUcav.png",
      "id_str" : "250404696370593793",
      "id" : 250404696370593793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3mdvqFCQAEUcav.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/fC6RWxaO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250404696366399489",
  "text" : "I THINK @asianmack LIKES ME http:\/\/t.co\/fC6RWxaO",
  "id" : 250404696366399489,
  "created_at" : "2012-09-25 01:21:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/250376428183506944\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dde2zW40",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3mECO6CUAAxc7o.jpg",
      "id_str" : "250376428191895552",
      "id" : 250376428191895552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3mECO6CUAAxc7o.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dde2zW40"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/exQpXIeM",
      "expanded_url" : "http:\/\/pine.fm\/learntoprogram",
      "display_url" : "pine.fm\/learntoprogram"
    } ]
  },
  "geo" : { },
  "id_str" : "250376473037385728",
  "text" : "RT @coworkbuffalo: Running through Learn to Program ( http:\/\/t.co\/exQpXIeM ) and coding up Battleship for Buffalo Learning to Code! http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/250376428183506944\/photo\/1",
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/dde2zW40",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A3mECO6CUAAxc7o.jpg",
        "id_str" : "250376428191895552",
        "id" : 250376428191895552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3mECO6CUAAxc7o.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dde2zW40"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/exQpXIeM",
        "expanded_url" : "http:\/\/pine.fm\/learntoprogram",
        "display_url" : "pine.fm\/learntoprogram"
      } ]
    },
    "geo" : { },
    "id_str" : "250376428183506944",
    "text" : "Running through Learn to Program ( http:\/\/t.co\/exQpXIeM ) and coding up Battleship for Buffalo Learning to Code! http:\/\/t.co\/dde2zW40",
    "id" : 250376428183506944,
    "created_at" : "2012-09-24 23:29:27 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 250376473037385728,
  "created_at" : "2012-09-24 23:29:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/ofhdnDdt",
      "expanded_url" : "http:\/\/www.buffalobeerweek.com\/",
      "display_url" : "buffalobeerweek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "250344192130285568",
  "text" : "RT @aquaranto: @qrush: Buffalo. Beer. WEEK. http:\/\/t.co\/ofhdnDdt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/ofhdnDdt",
        "expanded_url" : "http:\/\/www.buffalobeerweek.com\/",
        "display_url" : "buffalobeerweek.com"
      } ]
    },
    "geo" : { },
    "id_str" : "250343071504539648",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush: Buffalo. Beer. WEEK. http:\/\/t.co\/ofhdnDdt",
    "id" : 250343071504539648,
    "created_at" : "2012-09-24 21:16:54 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 250344192130285568,
  "created_at" : "2012-09-24 21:21:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250323775403474945",
  "geo" : { },
  "id_str" : "250324004018196480",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo pretty sure apt and yum can't compile that",
  "id" : 250324004018196480,
  "in_reply_to_status_id" : 250323775403474945,
  "created_at" : "2012-09-24 20:01:08 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/IQVYmQGW",
      "expanded_url" : "http:\/\/blogs.adobe.com\/typblography\/2012\/09\/source-code-pro.html",
      "display_url" : "blogs.adobe.com\/typblography\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "250322242062405634",
  "text" : "Going to try out some Source Code Pro: http:\/\/t.co\/IQVYmQGW",
  "id" : 250322242062405634,
  "created_at" : "2012-09-24 19:54:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250308372111450112",
  "geo" : { },
  "id_str" : "250310942901014528",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella i solved it by moving far, far away :)",
  "id" : 250310942901014528,
  "in_reply_to_status_id" : 250308372111450112,
  "created_at" : "2012-09-24 19:09:13 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250309579504754688",
  "geo" : { },
  "id_str" : "250310769701449728",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger Don't generate the legacy index. gem generate_index --no-legacy",
  "id" : 250310769701449728,
  "in_reply_to_status_id" : 250309579504754688,
  "created_at" : "2012-09-24 19:08:32 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250309893670711296",
  "geo" : { },
  "id_str" : "250310299645771777",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @NYWineWench pretty sure we made a great Science\/Comms team this weekend on the Artemis. quite a small universe.",
  "id" : 250310299645771777,
  "in_reply_to_status_id" : 250309893670711296,
  "created_at" : "2012-09-24 19:06:40 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/FYyOvM01",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=XeNKhm09Q88",
      "display_url" : "youtube.com\/watch?v=XeNKhm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "250301826015047680",
  "geo" : { },
  "id_str" : "250302804554547200",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda YES! http:\/\/t.co\/FYyOvM01",
  "id" : 250302804554547200,
  "in_reply_to_status_id" : 250301826015047680,
  "created_at" : "2012-09-24 18:36:53 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Savage",
      "screen_name" : "davidsavagejr",
      "indices" : [ 0, 14 ],
      "id_str" : "97732590",
      "id" : 97732590
    }, {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 21, 34 ],
      "id_str" : "19386993",
      "id" : 19386993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250301241182277633",
  "geo" : { },
  "id_str" : "250302072489140224",
  "in_reply_to_user_id" : 97732590,
  "text" : "@davidsavagejr Oops: @coworkingroc",
  "id" : 250302072489140224,
  "in_reply_to_status_id" : 250301241182277633,
  "created_at" : "2012-09-24 18:33:59 +0000",
  "in_reply_to_screen_name" : "davidsavagejr",
  "in_reply_to_user_id_str" : "97732590",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Savage",
      "screen_name" : "davidsavagejr",
      "indices" : [ 0, 14 ],
      "id_str" : "97732590",
      "id" : 97732590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250300667334365185",
  "geo" : { },
  "id_str" : "250300823773528064",
  "in_reply_to_user_id" : 97732590,
  "text" : "@davidsavagejr there is: @CoworkingRochester",
  "id" : 250300823773528064,
  "in_reply_to_status_id" : 250300667334365185,
  "created_at" : "2012-09-24 18:29:01 +0000",
  "in_reply_to_screen_name" : "davidsavagejr",
  "in_reply_to_user_id_str" : "97732590",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 52, 63 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 68, 74 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250299632872194048",
  "text" : "RT @aquaranto: Buffalo Learning to Code is tonight. @Jonplussed and @qrush are going to be helping out. Come on down to CoworkBuffalo @  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monads and Strife",
        "screen_name" : "Jonplussed",
        "indices" : [ 37, 48 ],
        "id_str" : "38408851",
        "id" : 38408851
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 53, 59 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250296236106731521",
    "text" : "Buffalo Learning to Code is tonight. @Jonplussed and @qrush are going to be helping out. Come on down to CoworkBuffalo @ 630 tonight!",
    "id" : 250296236106731521,
    "created_at" : "2012-09-24 18:10:47 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 250299632872194048,
  "created_at" : "2012-09-24 18:24:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 13, 24 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250285859528638464",
  "geo" : { },
  "id_str" : "250287324569673728",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench @Jonplussed Engage!",
  "id" : 250287324569673728,
  "in_reply_to_status_id" : 250285859528638464,
  "created_at" : "2012-09-24 17:35:22 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 13, 23 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 79, 93 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250285964629520384",
  "geo" : { },
  "id_str" : "250287283700383744",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd @theediguy i hope this means more trucks (and tacos) downtown for @coworkbuffalo!",
  "id" : 250287283700383744,
  "in_reply_to_status_id" : 250285964629520384,
  "created_at" : "2012-09-24 17:35:13 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 3, 13 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 33, 45 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250284171736526850",
  "text" : "RT @theediguy: It begins again.  @whereslloyd shut down in Amherst. No love for food trucks in this area.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lloyd Taco Trucks",
        "screen_name" : "whereslloyd",
        "indices" : [ 18, 30 ],
        "id_str" : "156689065",
        "id" : 156689065
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250283633024311296",
    "text" : "It begins again.  @whereslloyd shut down in Amherst. No love for food trucks in this area.",
    "id" : 250283633024311296,
    "created_at" : "2012-09-24 17:20:42 +0000",
    "user" : {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "protected" : false,
      "id_str" : "14122207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571262181624418304\/X5WyW-TQ_normal.jpeg",
      "id" : 14122207,
      "verified" : false
    }
  },
  "id" : 250284171736526850,
  "created_at" : "2012-09-24 17:22:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Higgins",
      "screen_name" : "RepBrianHiggins",
      "indices" : [ 3, 19 ],
      "id_str" : "33576489",
      "id" : 33576489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aebQquIO",
      "expanded_url" : "http:\/\/go.usa.gov\/rSgH",
      "display_url" : "go.usa.gov\/rSgH"
    } ]
  },
  "geo" : { },
  "id_str" : "250282916041588738",
  "text" : "RT @RepBrianHiggins: Spending more than $100M to rebuild Bflo Skyway over next 20 yrs would be a transportation &amp; land-use policy di ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/aebQquIO",
        "expanded_url" : "http:\/\/go.usa.gov\/rSgH",
        "display_url" : "go.usa.gov\/rSgH"
      } ]
    },
    "geo" : { },
    "id_str" : "250280154222440450",
    "text" : "Spending more than $100M to rebuild Bflo Skyway over next 20 yrs would be a transportation &amp; land-use policy disaster http:\/\/t.co\/aebQquIO",
    "id" : 250280154222440450,
    "created_at" : "2012-09-24 17:06:53 +0000",
    "user" : {
      "name" : "Brian Higgins",
      "screen_name" : "RepBrianHiggins",
      "protected" : false,
      "id_str" : "33576489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523096705030320129\/55nJtODk_normal.jpeg",
      "id" : 33576489,
      "verified" : true
    }
  },
  "id" : 250282916041588738,
  "created_at" : "2012-09-24 17:17:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/AQka6aqH",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3263-some-of-my-most-beloved-products-are-those",
      "display_url" : "37signals.com\/svn\/posts\/3263\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "250247080755462144",
  "text" : "Found a wonderful comment from Kathy Sierra: http:\/\/t.co\/AQka6aqH",
  "id" : 250247080755462144,
  "created_at" : "2012-09-24 14:55:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Garner",
      "screen_name" : "AlanHungover",
      "indices" : [ 3, 16 ],
      "id_str" : "490982935",
      "id" : 490982935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250083644465631232",
  "text" : "RT @AlanHungover: When you scroll fast it's purple!\n\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "249594822174846978",
    "text" : "When you scroll fast it's purple!\n\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99\n\uD83D\uDC99\u2764\n\u2764\uD83D\uDC99",
    "id" : 249594822174846978,
    "created_at" : "2012-09-22 19:43:37 +0000",
    "user" : {
      "name" : "Alan Garner",
      "screen_name" : "AlanHungover",
      "protected" : false,
      "id_str" : "490982935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1825288290\/gifsmall_normal.gif",
      "id" : 490982935,
      "verified" : false
    }
  },
  "id" : 250083644465631232,
  "created_at" : "2012-09-24 04:06:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250066688916221952",
  "geo" : { },
  "id_str" : "250072066626314240",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 it\u2019s great. His standup is amazing too.",
  "id" : 250072066626314240,
  "in_reply_to_status_id" : 250066688916221952,
  "created_at" : "2012-09-24 03:20:01 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249949509868716032",
  "geo" : { },
  "id_str" : "249952893174697984",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten ok, that might be why ;)",
  "id" : 249952893174697984,
  "in_reply_to_status_id" : 249949509868716032,
  "created_at" : "2012-09-23 19:26:28 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249949509868716032",
  "geo" : { },
  "id_str" : "249952700807135233",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten \u201Chow I switched off Wordpress, generated static HTML, and never had to worry about PHP security problems ever again\u201D",
  "id" : 249952700807135233,
  "in_reply_to_status_id" : 249949509868716032,
  "created_at" : "2012-09-23 19:25:42 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249949509868716032",
  "geo" : { },
  "id_str" : "249952209767387137",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten wtf? Why?",
  "id" : 249952209767387137,
  "in_reply_to_status_id" : 249949509868716032,
  "created_at" : "2012-09-23 19:23:45 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249946125660987392",
  "geo" : { },
  "id_str" : "249947072424460288",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten urge to explain Jekyll\u2026rising\u2026",
  "id" : 249947072424460288,
  "in_reply_to_status_id" : 249946125660987392,
  "created_at" : "2012-09-23 19:03:20 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/yZ5y7sHd",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/09\/linwood-avenue---the-bigger-picture.html",
      "display_url" : "buffalorising.com\/2012\/09\/linwoo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249929120656539648",
  "text" : "RT @BuffaloRising: Big changes coming to Linwood Avenue: http:\/\/t.co\/yZ5y7sHd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/yZ5y7sHd",
        "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/09\/linwood-avenue---the-bigger-picture.html",
        "display_url" : "buffalorising.com\/2012\/09\/linwoo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "249861045416513537",
    "text" : "Big changes coming to Linwood Avenue: http:\/\/t.co\/yZ5y7sHd",
    "id" : 249861045416513537,
    "created_at" : "2012-09-23 13:21:30 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 249929120656539648,
  "created_at" : "2012-09-23 17:52:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeke Sikelianos",
      "screen_name" : "zeke",
      "indices" : [ 0, 5 ],
      "id_str" : "2157621",
      "id" : 2157621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248278468092112897",
  "geo" : { },
  "id_str" : "249926684059516928",
  "in_reply_to_user_id" : 2157621,
  "text" : "@zeke we used to have more Wayne\u2019s World videos on those pages but YouTube banned them all :(",
  "id" : 249926684059516928,
  "in_reply_to_status_id" : 248278468092112897,
  "created_at" : "2012-09-23 17:42:19 +0000",
  "in_reply_to_screen_name" : "zeke",
  "in_reply_to_user_id_str" : "2157621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enric Lluelles",
      "screen_name" : "enriclluelles",
      "indices" : [ 0, 14 ],
      "id_str" : "57446166",
      "id" : 57446166
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 15, 23 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249156484917764096",
  "geo" : { },
  "id_str" : "249926483563380736",
  "in_reply_to_user_id" : 57446166,
  "text" : "@enriclluelles @mperham they were temporarily disabled due to lots of system overload pain. Hoping to return soon.",
  "id" : 249926483563380736,
  "in_reply_to_status_id" : 249156484917764096,
  "created_at" : "2012-09-23 17:41:31 +0000",
  "in_reply_to_screen_name" : "enriclluelles",
  "in_reply_to_user_id_str" : "57446166",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabio Akita",
      "screen_name" : "AkitaOnRails",
      "indices" : [ 3, 16 ],
      "id_str" : "3982931",
      "id" : 3982931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/tiDVHcGB",
      "expanded_url" : "http:\/\/www.paulgraham.com\/javacover.html",
      "display_url" : "paulgraham.com\/javacover.html"
    } ]
  },
  "geo" : { },
  "id_str" : "249924407148044288",
  "text" : "RT @AkitaOnRails: It's interesting to re-read Paul Graham's take on Java back in 2001 http:\/\/t.co\/tiDVHcGB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/tiDVHcGB",
        "expanded_url" : "http:\/\/www.paulgraham.com\/javacover.html",
        "display_url" : "paulgraham.com\/javacover.html"
      } ]
    },
    "geo" : { },
    "id_str" : "249923770230398976",
    "text" : "It's interesting to re-read Paul Graham's take on Java back in 2001 http:\/\/t.co\/tiDVHcGB",
    "id" : 249923770230398976,
    "created_at" : "2012-09-23 17:30:44 +0000",
    "user" : {
      "name" : "Fabio Akita",
      "screen_name" : "AkitaOnRails",
      "protected" : false,
      "id_str" : "3982931",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507388793364574208\/2GveS96q_normal.jpeg",
      "id" : 3982931,
      "verified" : false
    }
  },
  "id" : 249924407148044288,
  "created_at" : "2012-09-23 17:33:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/5mClx5ru",
      "expanded_url" : "http:\/\/instagr.am\/p\/P58s1Ns6jj\/",
      "display_url" : "instagr.am\/p\/P58s1Ns6jj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "249736225425063936",
  "text" : "Meeplin' ain't easy. http:\/\/t.co\/5mClx5ru",
  "id" : 249736225425063936,
  "created_at" : "2012-09-23 05:05:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    }, {
      "name" : "Michael Bleigh",
      "screen_name" : "mbleigh",
      "indices" : [ 9, 17 ],
      "id_str" : "12025282",
      "id" : 12025282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249674047347118081",
  "geo" : { },
  "id_str" : "249705890498895872",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle @mbleigh Artemis. So much fun. Now if only I had more Windows boxes with touchscreens\u2026",
  "id" : 249705890498895872,
  "in_reply_to_status_id" : 249674047347118081,
  "created_at" : "2012-09-23 03:04:58 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/4aXtqu26",
      "expanded_url" : "http:\/\/instagr.am\/p\/P5eFghs6n9\/",
      "display_url" : "instagr.am\/p\/P5eFghs6n9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "249668861870358528",
  "text" : "Comms officer reporting! Got a big ship to surrender to us. http:\/\/t.co\/4aXtqu26",
  "id" : 249668861870358528,
  "created_at" : "2012-09-23 00:37:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/FVUfIXRB",
      "expanded_url" : "http:\/\/instagr.am\/p\/P5auX7M6ka\/",
      "display_url" : "instagr.am\/p\/P5auX7M6ka\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.887077331, -78.876609802 ]
  },
  "id_str" : "249661649961775104",
  "text" : "Trying out Artemis, a spaceship bridge simulator! 5 big touchscreens and a main scree  @ Queen City Conquest http:\/\/t.co\/FVUfIXRB",
  "id" : 249661649961775104,
  "created_at" : "2012-09-23 00:09:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/6JAaiarP",
      "expanded_url" : "http:\/\/instagr.am\/p\/P47BwVM6jN\/",
      "display_url" : "instagr.am\/p\/P47BwVM6jN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.887077331, -78.876609802 ]
  },
  "id_str" : "249591851907162112",
  "text" : "Le Havre! Shippin' it.  @ Queen City Conquest http:\/\/t.co\/6JAaiarP",
  "id" : 249591851907162112,
  "created_at" : "2012-09-22 19:31:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 12, 23 ],
      "id_str" : "7144422",
      "id" : 7144422
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 30, 41 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249578220029083649",
  "geo" : { },
  "id_str" : "249580593443135488",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape @lifehacker I bet @kevinpurdy will know how",
  "id" : 249580593443135488,
  "in_reply_to_status_id" : 249578220029083649,
  "created_at" : "2012-09-22 18:47:05 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249577189689942016",
  "geo" : { },
  "id_str" : "249579980479148032",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit you know it!",
  "id" : 249579980479148032,
  "in_reply_to_status_id" : 249577189689942016,
  "created_at" : "2012-09-22 18:44:38 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/V3fSVEIC",
      "expanded_url" : "http:\/\/instagr.am\/p\/P4pk-yM6h9\/",
      "display_url" : "instagr.am\/p\/P4pk-yM6h9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.887077331, -78.876609802 ]
  },
  "id_str" : "249553473023135744",
  "text" : "The Good, the Bad, and the Munchkin.  @ Queen City Conquest http:\/\/t.co\/V3fSVEIC",
  "id" : 249553473023135744,
  "created_at" : "2012-09-22 16:59:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249553049532653568",
  "text" : "RT @dhh: If gold-rush odds are not appealing, please don't do a YC-style startup. Just start a business. Don't worry about virus growth  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "249552480260739073",
    "text" : "If gold-rush odds are not appealing, please don't do a YC-style startup. Just start a business. Don't worry about virus growth rates.",
    "id" : 249552480260739073,
    "created_at" : "2012-09-22 16:55:22 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 249553049532653568,
  "created_at" : "2012-09-22 16:57:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249527093485006850",
  "text" : "Lasted less than 48 hours with a complex passcode. Way too obnoxious.",
  "id" : 249527093485006850,
  "created_at" : "2012-09-22 15:14:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 12, 20 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249520120458797057",
  "geo" : { },
  "id_str" : "249521920150749185",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff @noahhlo holy crap, nice workspace.",
  "id" : 249521920150749185,
  "in_reply_to_status_id" : 249520120458797057,
  "created_at" : "2012-09-22 14:53:56 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249415134143995904",
  "text" : "Also, Flying Sorcerers are completely OP for Smallworld.",
  "id" : 249415134143995904,
  "created_at" : "2012-09-22 07:49:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249401378307461120",
  "geo" : { },
  "id_str" : "249412754056835072",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz nope, never gonna happen. I wish there was a rubyfmt.",
  "id" : 249412754056835072,
  "in_reply_to_status_id" : 249401378307461120,
  "created_at" : "2012-09-22 07:40:09 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249412245346451456",
  "text" : "Board games and even some Tetris Attack until almost 4am? Just an average Friday evening here.",
  "id" : 249412245346451456,
  "created_at" : "2012-09-22 07:38:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/SEsvsdQJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/P22wzSs6uF\/",
      "display_url" : "instagr.am\/p\/P22wzSs6uF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8871516029, -78.876399386 ]
  },
  "id_str" : "249301044989923329",
  "text" : "Perhaps the only photo worthy of a vintage filter.  @ Buffalo Niagara Convention Center http:\/\/t.co\/SEsvsdQJ",
  "id" : 249301044989923329,
  "created_at" : "2012-09-22 00:16:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/3ziDep1G",
      "expanded_url" : "http:\/\/instagr.am\/p\/P22vhGs6uE\/",
      "display_url" : "instagr.am\/p\/P22vhGs6uE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "249300844548337664",
  "text" : "Intense D&amp;D Essentials game going on. 3 ships, dude on the dice is on the mast. http:\/\/t.co\/3ziDep1G",
  "id" : 249300844548337664,
  "created_at" : "2012-09-22 00:15:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/Wx6nogWK",
      "expanded_url" : "http:\/\/instagr.am\/p\/P20M1CM6ru\/",
      "display_url" : "instagr.am\/p\/P20M1CM6ru\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8871516029, -78.876399386 ]
  },
  "id_str" : "249295243038584832",
  "text" : "At Queen City Conquest!  @ Buffalo Niagara Convention Center http:\/\/t.co\/Wx6nogWK",
  "id" : 249295243038584832,
  "created_at" : "2012-09-21 23:53:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Murphy",
      "screen_name" : "wfm",
      "indices" : [ 0, 4 ],
      "id_str" : "6655452",
      "id" : 6655452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249259617526358016",
  "geo" : { },
  "id_str" : "249259938386423808",
  "in_reply_to_user_id" : 6655452,
  "text" : "@wfm woot! thanks for coming in!",
  "id" : 249259938386423808,
  "in_reply_to_status_id" : 249259617526358016,
  "created_at" : "2012-09-21 21:32:54 +0000",
  "in_reply_to_screen_name" : "wfm",
  "in_reply_to_user_id_str" : "6655452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/yBf2JgKM",
      "expanded_url" : "http:\/\/livelymorgue.tumblr.com\/post\/31983413048\/dec-21-1933-from-the-mid-week-pictorial",
      "display_url" : "livelymorgue.tumblr.com\/post\/319834130\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249258349177225216",
  "text" : "Current friday status: http:\/\/t.co\/yBf2JgKM",
  "id" : 249258349177225216,
  "created_at" : "2012-09-21 21:26:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 3, 18 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/iVK6FlS2",
      "expanded_url" : "http:\/\/i.imgur.com\/OHdYg.png",
      "display_url" : "i.imgur.com\/OHdYg.png"
    } ]
  },
  "geo" : { },
  "id_str" : "249257715057172480",
  "text" : "RT @gabrielgironda: huh. never seen this message from iTunes before http:\/\/t.co\/iVK6FlS2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/iVK6FlS2",
        "expanded_url" : "http:\/\/i.imgur.com\/OHdYg.png",
        "display_url" : "i.imgur.com\/OHdYg.png"
      } ]
    },
    "geo" : { },
    "id_str" : "249257169390813184",
    "text" : "huh. never seen this message from iTunes before http:\/\/t.co\/iVK6FlS2",
    "id" : 249257169390813184,
    "created_at" : "2012-09-21 21:21:54 +0000",
    "user" : {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "protected" : true,
      "id_str" : "267895957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560982536772259840\/0R0rl2ao_normal.jpeg",
      "id" : 267895957,
      "verified" : false
    }
  },
  "id" : 249257715057172480,
  "created_at" : "2012-09-21 21:24:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249253689519378432",
  "geo" : { },
  "id_str" : "249255003565469696",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y no, remotes are entirely local. origin is just where you cloned from. (clone a git directory locally and do git remote -v)",
  "id" : 249255003565469696,
  "in_reply_to_status_id" : 249253689519378432,
  "created_at" : "2012-09-21 21:13:18 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/mzqaLkzB",
      "expanded_url" : "http:\/\/arstechnica.com\/apple\/2009\/08\/ipod-repair-scammer-hit-with-restitution-jail-time\/",
      "display_url" : "arstechnica.com\/apple\/2009\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249235331847700480",
  "text" : "The iPhone unboxing moron is a former scam artist. http:\/\/t.co\/mzqaLkzB",
  "id" : 249235331847700480,
  "created_at" : "2012-09-21 19:55:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bison bison",
      "screen_name" : "infinitebuffalo",
      "indices" : [ 3, 19 ],
      "id_str" : "112826457",
      "id" : 112826457
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 21, 27 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/YUCFGmer",
      "expanded_url" : "http:\/\/arstechnica.com\/apple\/2009\/08\/ipod-repair-scammer-hit-with-restitution-jail-time\/",
      "display_url" : "arstechnica.com\/apple\/2009\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249235132303671296",
  "text" : "RT @infinitebuffalo: @qrush you mean this guy http:\/\/t.co\/YUCFGmer ? Kinda surprised they let him near an Apple box at all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/YUCFGmer",
        "expanded_url" : "http:\/\/arstechnica.com\/apple\/2009\/08\/ipod-repair-scammer-hit-with-restitution-jail-time\/",
        "display_url" : "arstechnica.com\/apple\/2009\/08\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "249209992652140544",
    "geo" : { },
    "id_str" : "249234372467765248",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush you mean this guy http:\/\/t.co\/YUCFGmer ? Kinda surprised they let him near an Apple box at all.",
    "id" : 249234372467765248,
    "in_reply_to_status_id" : 249209992652140544,
    "created_at" : "2012-09-21 19:51:19 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Bison bison",
      "screen_name" : "infinitebuffalo",
      "protected" : false,
      "id_str" : "112826457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2217649279\/BUFFO_normal.jpg",
      "id" : 112826457,
      "verified" : false
    }
  },
  "id" : 249235132303671296,
  "created_at" : "2012-09-21 19:54:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 3, 7 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/u2QdsEwX",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/List_of_sandwiches",
      "display_url" : "en.m.wikipedia.org\/wiki\/List_of_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249216686547423232",
  "text" : "RT @rit: There's an entire Wikipedia page  that just lists sandwiches... http:\/\/t.co\/u2QdsEwX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/u2QdsEwX",
        "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/List_of_sandwiches",
        "display_url" : "en.m.wikipedia.org\/wiki\/List_of_s\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.2130683, -1.5434224 ]
    },
    "id_str" : "249215759924994048",
    "text" : "There's an entire Wikipedia page  that just lists sandwiches... http:\/\/t.co\/u2QdsEwX",
    "id" : 249215759924994048,
    "created_at" : "2012-09-21 18:37:22 +0000",
    "user" : {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "protected" : false,
      "id_str" : "5961382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509510333723975681\/Sm8WnmdE_normal.jpeg",
      "id" : 5961382,
      "verified" : false
    }
  },
  "id" : 249216686547423232,
  "created_at" : "2012-09-21 18:41:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel Rodriguez",
      "screen_name" : "gabrielrdz",
      "indices" : [ 0, 11 ],
      "id_str" : "16594744",
      "id" : 16594744
    }, {
      "name" : "Barry Dorrans",
      "screen_name" : "blowdart",
      "indices" : [ 12, 21 ],
      "id_str" : "1847381",
      "id" : 1847381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249214030420520960",
  "geo" : { },
  "id_str" : "249214993432727552",
  "in_reply_to_user_id" : 16594744,
  "text" : "@gabrielrdz @blowdart honestly? did you read the article?",
  "id" : 249214993432727552,
  "in_reply_to_status_id" : 249214030420520960,
  "created_at" : "2012-09-21 18:34:19 +0000",
  "in_reply_to_screen_name" : "gabrielrdz",
  "in_reply_to_user_id_str" : "16594744",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/taAcfkdm",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MBHOL1PcPR8",
      "display_url" : "youtube.com\/watch?v=MBHOL1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249213896618024962",
  "text" : "I want to film a dramatic re-enactment of this iPhone 5 unboxing debacle, in the style of http:\/\/t.co\/taAcfkdm",
  "id" : 249213896618024962,
  "created_at" : "2012-09-21 18:29:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/BkKlTq0r",
      "expanded_url" : "http:\/\/www.nickwoodhams.com\/post\/31988005655",
      "display_url" : "nickwoodhams.com\/post\/319880056\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249209992652140544",
  "text" : "This is a disgusting example of entitlement, lack of humility, and the most first world problem I've seen today. http:\/\/t.co\/BkKlTq0r \u2026",
  "id" : 249209992652140544,
  "created_at" : "2012-09-21 18:14:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249200394184556546",
  "geo" : { },
  "id_str" : "249203109824446464",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws this is the biggest first world problem post i've ever read.",
  "id" : 249203109824446464,
  "in_reply_to_status_id" : 249200394184556546,
  "created_at" : "2012-09-21 17:47:06 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Abdulla",
      "screen_name" : "tabdulla",
      "indices" : [ 0, 9 ],
      "id_str" : "33273807",
      "id" : 33273807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249008497369444353",
  "geo" : { },
  "id_str" : "249009580082872320",
  "in_reply_to_user_id" : 33273807,
  "text" : "@tabdulla ah, derp.",
  "id" : 249009580082872320,
  "in_reply_to_status_id" : 249008497369444353,
  "created_at" : "2012-09-21 04:58:04 +0000",
  "in_reply_to_screen_name" : "tabdulla",
  "in_reply_to_user_id_str" : "33273807",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/249007876872486914\/photo\/1",
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/FQGEsFny",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3SnWD_CQAAnzcT.png",
      "id_str" : "249007876880875520",
      "id" : 249007876880875520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3SnWD_CQAAnzcT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/FQGEsFny"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249007876872486914",
  "text" : "Fun iOS6 feature: complex passcode (more than 4 digits!). Let\u2019s see how obnoxious this gets. http:\/\/t.co\/FQGEsFny",
  "id" : 249007876872486914,
  "created_at" : "2012-09-21 04:51:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 0, 8 ],
      "id_str" : "14408469",
      "id" : 14408469
    }, {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 9, 22 ],
      "id_str" : "16159121",
      "id" : 16159121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248947680401838080",
  "geo" : { },
  "id_str" : "248975471994355712",
  "in_reply_to_user_id" : 14408469,
  "text" : "@uptonic @chaseclemons so worth the drive\/ride out there.",
  "id" : 248975471994355712,
  "in_reply_to_status_id" : 248947680401838080,
  "created_at" : "2012-09-21 02:42:32 +0000",
  "in_reply_to_screen_name" : "uptonic",
  "in_reply_to_user_id_str" : "14408469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/sVaGfTAn",
      "expanded_url" : "http:\/\/instagram.com\/p\/PDlkcMs6gw",
      "display_url" : "instagram.com\/p\/PDlkcMs6gw"
    } ]
  },
  "in_reply_to_status_id_str" : "248902752703488000",
  "geo" : { },
  "id_str" : "248903602687574016",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden he gives out hugs sometimes http:\/\/t.co\/sVaGfTAn",
  "id" : 248903602687574016,
  "in_reply_to_status_id" : 248902752703488000,
  "created_at" : "2012-09-20 21:56:57 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/1A406arw",
      "expanded_url" : "http:\/\/www.fastcompany.com\/3001481\/apple-maps-switchover-survival-guide",
      "display_url" : "fastcompany.com\/3001481\/apple-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248901902094454784",
  "text" : "And Geddy's nose is now on FastCompany: http:\/\/t.co\/1A406arw",
  "id" : 248901902094454784,
  "created_at" : "2012-09-20 21:50:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248896507711987713",
  "text" : "RT @SteveStreza: Twitter as a developer platform has been dead for years. A great tragedy in the history of tech. But at least brands ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "248895530502074368",
    "text" : "Twitter as a developer platform has been dead for years. A great tragedy in the history of tech. But at least brands can post ads to it!",
    "id" : 248895530502074368,
    "created_at" : "2012-09-20 21:24:53 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 248896507711987713,
  "created_at" : "2012-09-20 21:28:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248891424953729024",
  "geo" : { },
  "id_str" : "248892183430721537",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef heh, won't be there until 7. ...maybe I need to catch up?",
  "id" : 248892183430721537,
  "in_reply_to_status_id" : 248891424953729024,
  "created_at" : "2012-09-20 21:11:35 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 38, 52 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/1A406arw",
      "expanded_url" : "http:\/\/www.fastcompany.com\/3001481\/apple-maps-switchover-survival-guide",
      "display_url" : "fastcompany.com\/3001481\/apple-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248891003711389696",
  "text" : "Looks like our iOS6 map troubles with @coworkbuffalo have made an appearance on FastCompany: http:\/\/t.co\/1A406arw",
  "id" : 248891003711389696,
  "created_at" : "2012-09-20 21:06:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248890849570729984",
  "geo" : { },
  "id_str" : "248890945129570304",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 fixing...",
  "id" : 248890945129570304,
  "in_reply_to_status_id" : 248890849570729984,
  "created_at" : "2012-09-20 21:06:40 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/1yg2FY7X",
      "expanded_url" : "http:\/\/www.boston.com\/bigpicture\/",
      "display_url" : "boston.com\/bigpicture\/"
    } ]
  },
  "in_reply_to_status_id_str" : "248886628398030848",
  "geo" : { },
  "id_str" : "248887066811850754",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski why doesn't the News publish more stuff like this, even in a Big Picture like format? http:\/\/t.co\/1yg2FY7X",
  "id" : 248887066811850754,
  "in_reply_to_status_id" : 248886628398030848,
  "created_at" : "2012-09-20 20:51:15 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winfield",
      "screen_name" : "wpeterson",
      "indices" : [ 0, 10 ],
      "id_str" : "13268512",
      "id" : 13268512
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 62, 70 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248858470445629440",
  "geo" : { },
  "id_str" : "248859171708096512",
  "in_reply_to_user_id" : 13268512,
  "text" : "@wpeterson jump and stay in #rubygems on freenode, bug evan \/ @evanphx.",
  "id" : 248859171708096512,
  "in_reply_to_status_id" : 248858470445629440,
  "created_at" : "2012-09-20 19:00:24 +0000",
  "in_reply_to_screen_name" : "wpeterson",
  "in_reply_to_user_id_str" : "13268512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/tFO0xPlW",
      "expanded_url" : "http:\/\/emojicons.com\/table-flipping",
      "display_url" : "emojicons.com\/table-flipping"
    } ]
  },
  "geo" : { },
  "id_str" : "248854722809839616",
  "text" : "Possibly the best slider ever: http:\/\/t.co\/tFO0xPlW",
  "id" : 248854722809839616,
  "created_at" : "2012-09-20 18:42:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248851101577801730",
  "text" : "It's been a 1\/\u0CA0_\u0CA0 per day kind of week.",
  "id" : 248851101577801730,
  "created_at" : "2012-09-20 18:28:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/wN6NPPZI",
      "expanded_url" : "http:\/\/zachholman.com\/posts\/abusing-emoji\/",
      "display_url" : "zachholman.com\/posts\/abusing-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248848979331252225",
  "text" : "RT @holman: Here\u2019s 9 ways to abuse emoji in OS X and iOS. There\u2019s no way this could go wrong.\n\nhttp:\/\/t.co\/wN6NPPZI\n\n\uD83C\uDF49 \uD83C\uDF55 \uD83D\uDC13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/wN6NPPZI",
        "expanded_url" : "http:\/\/zachholman.com\/posts\/abusing-emoji\/",
        "display_url" : "zachholman.com\/posts\/abusing-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "248848708005920768",
    "text" : "Here\u2019s 9 ways to abuse emoji in OS X and iOS. There\u2019s no way this could go wrong.\n\nhttp:\/\/t.co\/wN6NPPZI\n\n\uD83C\uDF49 \uD83C\uDF55 \uD83D\uDC13",
    "id" : 248848708005920768,
    "created_at" : "2012-09-20 18:18:50 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550019686230794240\/gWlpdYw2_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 248848979331252225,
  "created_at" : "2012-09-20 18:19:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248845272904507393",
  "geo" : { },
  "id_str" : "248846005871734785",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly yeah that's not \"open\"",
  "id" : 248846005871734785,
  "in_reply_to_status_id" : 248845272904507393,
  "created_at" : "2012-09-20 18:08:05 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "248843150037241856",
  "geo" : { },
  "id_str" : "248843507261915136",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly disagree. i've got a lot crap code in http:\/\/t.co\/bdjsRgTW i've merged in, didn't fully review\/think about, and now is painful.",
  "id" : 248843507261915136,
  "in_reply_to_status_id" : 248843150037241856,
  "created_at" : "2012-09-20 17:58:10 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/CvLfm7bU",
      "expanded_url" : "https:\/\/groups.google.com\/group\/buffalo-opencoffee-club\/browse_thread\/thread\/21980f9e805aae24",
      "display_url" : "groups.google.com\/group\/buffalo-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248836876679643136",
  "text" : "RT @coworkbuffalo: Hey, we\u2019re not going to have a mixer\/drinkup here tonight and instead hit up ThirdThursday. See you there! https:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 128 ],
        "url" : "https:\/\/t.co\/CvLfm7bU",
        "expanded_url" : "https:\/\/groups.google.com\/group\/buffalo-opencoffee-club\/browse_thread\/thread\/21980f9e805aae24",
        "display_url" : "groups.google.com\/group\/buffalo-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "248836667476152321",
    "text" : "Hey, we\u2019re not going to have a mixer\/drinkup here tonight and instead hit up ThirdThursday. See you there! https:\/\/t.co\/CvLfm7bU",
    "id" : 248836667476152321,
    "created_at" : "2012-09-20 17:30:59 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 248836876679643136,
  "created_at" : "2012-09-20 17:31:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Castleman",
      "screen_name" : "manofthecastle",
      "indices" : [ 0, 15 ],
      "id_str" : "718515127",
      "id" : 718515127
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https:\/\/t.co\/dnU36Zr8",
      "expanded_url" : "https:\/\/groups.google.com\/group\/buffalo-opencoffee-club\/browse_thread\/thread\/21980f9e805aae24",
      "display_url" : "groups.google.com\/group\/buffalo-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "248526914334121984",
  "geo" : { },
  "id_str" : "248836144391938048",
  "in_reply_to_user_id" : 718515127,
  "text" : "@manofthecastle @coworkbuffalo hey! drop by anytime 10-6, M-F...we're going to head to ThirdThursday instead tonight: https:\/\/t.co\/dnU36Zr8",
  "id" : 248836144391938048,
  "in_reply_to_status_id" : 248526914334121984,
  "created_at" : "2012-09-20 17:28:54 +0000",
  "in_reply_to_screen_name" : "manofthecastle",
  "in_reply_to_user_id_str" : "718515127",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/0fROEFb0",
      "expanded_url" : "http:\/\/instagr.am\/p\/Pze2-ws6n5\/",
      "display_url" : "instagr.am\/p\/Pze2-ws6n5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8866485937, -78.8777370904 ]
  },
  "id_str" : "248826600697761792",
  "text" : "\uD83D\uDDFD\uD83C\uDDFA\uD83C\uDDF8  @ Niagara Square http:\/\/t.co\/0fROEFb0",
  "id" : 248826600697761792,
  "created_at" : "2012-09-20 16:50:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/BukMkiy7",
      "expanded_url" : "http:\/\/instagr.am\/p\/PzeelOs6nl\/",
      "display_url" : "instagr.am\/p\/PzeelOs6nl\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8866485937, -78.8777370904 ]
  },
  "id_str" : "248825249368522752",
  "text" : "Just posted a photo  @ Niagara Square http:\/\/t.co\/BukMkiy7",
  "id" : 248825249368522752,
  "created_at" : "2012-09-20 16:45:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248807198233346048",
  "text" : "Today Nick learned about grep -v, and his neckbeard grew 3 scraggly hairs that day.",
  "id" : 248807198233346048,
  "created_at" : "2012-09-20 15:33:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Singleton",
      "screen_name" : "MicahSingleton",
      "indices" : [ 0, 15 ],
      "id_str" : "337801323",
      "id" : 337801323
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 105, 109 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Alexander Levine",
      "screen_name" : "avlevine",
      "indices" : [ 110, 119 ],
      "id_str" : "404206595",
      "id" : 404206595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248794100550225920",
  "geo" : { },
  "id_str" : "248794760448446465",
  "in_reply_to_user_id" : 337801323,
  "text" : "@MicahSingleton @coworkbuffalo ah ha ! We're listed as \"Cowork Buffalo\" there so that didn't pop up. \/cc @lrz @avlevine",
  "id" : 248794760448446465,
  "in_reply_to_status_id" : 248794100550225920,
  "created_at" : "2012-09-20 14:44:27 +0000",
  "in_reply_to_screen_name" : "MicahSingleton",
  "in_reply_to_user_id_str" : "337801323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 67, 81 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248793670600495104",
  "text" : "Does anyone know how to submit listings to iOS6 Maps? Unhappy that @CoworkBuffalo can't be searched for and doesn't appear at its location.",
  "id" : 248793670600495104,
  "created_at" : "2012-09-20 14:40:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248636867036209152",
  "text" : "Whoa, open your Passbook app in a dark room. Jumps the brightness up to the max!",
  "id" : 248636867036209152,
  "created_at" : "2012-09-20 04:17:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/248635638772035584\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/RDKqqVCf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3NUy8_CcAAdPPn.png",
      "id_str" : "248635638776229888",
      "id" : 248635638776229888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3NUy8_CcAAdPPn.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/RDKqqVCf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248635638772035584",
  "text" : "GOVERNMENT and AMBER alerts on your notification center? http:\/\/t.co\/RDKqqVCf",
  "id" : 248635638772035584,
  "created_at" : "2012-09-20 04:12:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/248631934673104896\/photo\/1",
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/k2fR6Ca7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3NRbWJCMAE4vXB.png",
      "id_str" : "248631934677299201",
      "id" : 248631934677299201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3NRbWJCMAE4vXB.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/k2fR6Ca7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248631934673104896",
  "text" : "This new App Store is AWESOME \uD83D\uDCAF http:\/\/t.co\/k2fR6Ca7",
  "id" : 248631934673104896,
  "created_at" : "2012-09-20 03:57:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 57 ],
      "url" : "https:\/\/t.co\/DM7vnY7S",
      "expanded_url" : "https:\/\/github.com\/qrush",
      "display_url" : "github.com\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "248629662115311616",
  "text" : "RIP Nick \u201CChronic Rebaser\u201D Quaranto https:\/\/t.co\/DM7vnY7S",
  "id" : 248629662115311616,
  "created_at" : "2012-09-20 03:48:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248605259851767808",
  "text" : "@ChrisVanPatte NTHOOOOOOO",
  "id" : 248605259851767808,
  "created_at" : "2012-09-20 02:11:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 40 ],
      "url" : "https:\/\/t.co\/wva3oSmW",
      "expanded_url" : "https:\/\/basecamp.com\/humans.txt",
      "display_url" : "basecamp.com\/humans.txt"
    } ]
  },
  "in_reply_to_status_id_str" : "248592420223213568",
  "geo" : { },
  "id_str" : "248598117790912512",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette woot :) https:\/\/t.co\/wva3oSmW",
  "id" : 248598117790912512,
  "in_reply_to_status_id" : 248592420223213568,
  "created_at" : "2012-09-20 01:43:04 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248578820259590144",
  "text" : "TAP TO TWEET!!!!",
  "id" : 248578820259590144,
  "created_at" : "2012-09-20 00:26:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248563703178481664",
  "text" : "The main problem is he wants to literally explode with energy when the ride begins...channeling that into 30-40 minute ride is better.",
  "id" : 248563703178481664,
  "created_at" : "2012-09-19 23:26:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248563529639133184",
  "text" : "Starting to learn the secret behind biking with the husky: don't sprint at the start, just go steady throughout. Otherwise, he drags.",
  "id" : 248563529639133184,
  "created_at" : "2012-09-19 23:25:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/I1UXWPZ2",
      "expanded_url" : "http:\/\/instagr.am\/p\/PxjF1IM6l3\/",
      "display_url" : "instagr.am\/p\/PxjF1IM6l3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9323842564, -78.8735912528 ]
  },
  "id_str" : "248554003980500992",
  "text" : "\u2601  @ Hoyt Lake http:\/\/t.co\/I1UXWPZ2",
  "id" : 248554003980500992,
  "created_at" : "2012-09-19 22:47:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 3, 12 ],
      "id_str" : "13643732",
      "id" : 13643732
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248521147656851456",
  "text" : "RT @cmaggard: @qrush Look at all that 'data'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "248520681464135680",
    "geo" : { },
    "id_str" : "248520781074677760",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Look at all that 'data'",
    "id" : 248520781074677760,
    "in_reply_to_status_id" : 248520681464135680,
    "created_at" : "2012-09-19 20:35:46 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "protected" : false,
      "id_str" : "13643732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2476028353\/rgmt3vaz6m7d0lehk3ey_normal.jpeg",
      "id" : 13643732,
      "verified" : false
    }
  },
  "id" : 248521147656851456,
  "created_at" : "2012-09-19 20:37:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 21 ],
      "url" : "https:\/\/t.co\/x3OIEpFz",
      "expanded_url" : "https:\/\/twitter.com\/i\/#!\/search\/realtime\/%22tap%20to%20tweet%22",
      "display_url" : "twitter.com\/i\/#!\/search\/re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248520681464135680",
  "text" : "https:\/\/t.co\/x3OIEpFz",
  "id" : 248520681464135680,
  "created_at" : "2012-09-19 20:35:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 15, 29 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248507006376361984",
  "geo" : { },
  "id_str" : "248508431374360577",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit @BuffaloRising I don't find this surprising at all. it's pathetic, embarrassing for our city, and completely incompetent.",
  "id" : 248508431374360577,
  "in_reply_to_status_id" : 248507006376361984,
  "created_at" : "2012-09-19 19:46:41 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/RlgjkaZ8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WGOohBytKTU",
      "display_url" : "youtube.com\/watch?v=WGOohB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248503775445262336",
  "text" : "Current status: http:\/\/t.co\/RlgjkaZ8",
  "id" : 248503775445262336,
  "created_at" : "2012-09-19 19:28:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 14, 20 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248483712512172032",
  "geo" : { },
  "id_str" : "248484315732770816",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @hgmnz yea, but going to the length of an Eclipse plugin signals a very different approach\/market than straight CLI",
  "id" : 248484315732770816,
  "in_reply_to_status_id" : 248483712512172032,
  "created_at" : "2012-09-19 18:10:52 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Steinberger",
      "screen_name" : "steipete",
      "indices" : [ 0, 9 ],
      "id_str" : "25401953",
      "id" : 25401953
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 10, 22 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248479525913100288",
  "geo" : { },
  "id_str" : "248483302837731329",
  "in_reply_to_user_id" : 25401953,
  "text" : "@steipete @SteveStreza what does this have over UITableViewController? So confused.",
  "id" : 248483302837731329,
  "in_reply_to_status_id" : 248479525913100288,
  "created_at" : "2012-09-19 18:06:50 +0000",
  "in_reply_to_screen_name" : "steipete",
  "in_reply_to_user_id_str" : "25401953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/8QLWUdbF",
      "expanded_url" : "http:\/\/blog.heroku.com\/archives\/2012\/9\/19\/announcing_heroku_enterprise_for_java\/",
      "display_url" : "blog.heroku.com\/archives\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248482719930130433",
  "text" : "\"Heroku\" \"Enterprise\"? Looks like Salesforce is finally getting to them. http:\/\/t.co\/8QLWUdbF",
  "id" : 248482719930130433,
  "created_at" : "2012-09-19 18:04:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david yell",
      "screen_name" : "DavidYell",
      "indices" : [ 0, 10 ],
      "id_str" : "915030193",
      "id" : 915030193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248471747664429056",
  "text" : "@davidyell haha thanks dude.",
  "id" : 248471747664429056,
  "created_at" : "2012-09-19 17:20:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Daigle",
      "screen_name" : "camerondaigle",
      "indices" : [ 3, 17 ],
      "id_str" : "14496815",
      "id" : 14496815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248430928848908288",
  "text" : "RT @camerondaigle: Rdio says there are new releases from Pink, The Killers, Ben Folds Five, Hoobastank &amp; No Doubt which means I'm pr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "248430113883033600",
    "text" : "Rdio says there are new releases from Pink, The Killers, Ben Folds Five, Hoobastank &amp; No Doubt which means I'm probably late for math class.",
    "id" : 248430113883033600,
    "created_at" : "2012-09-19 14:35:29 +0000",
    "user" : {
      "name" : "Cameron Daigle",
      "screen_name" : "camerondaigle",
      "protected" : false,
      "id_str" : "14496815",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1264936777\/Cameron_Daigle_normal.jpeg",
      "id" : 14496815,
      "verified" : false
    }
  },
  "id" : 248430928848908288,
  "created_at" : "2012-09-19 14:38:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248404825866387456",
  "geo" : { },
  "id_str" : "248411274432618497",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark thunderpups are go!!!",
  "id" : 248411274432618497,
  "in_reply_to_status_id" : 248404825866387456,
  "created_at" : "2012-09-19 13:20:37 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 9, 23 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "Brian",
      "screen_name" : "brixen",
      "indices" : [ 24, 31 ],
      "id_str" : "2897551",
      "id" : 2897551
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 32, 40 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248297902798155776",
  "geo" : { },
  "id_str" : "248298124525830144",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule @garybernhardt @brixen @mperham this 9.0 douchequake needs to stop.",
  "id" : 248298124525830144,
  "in_reply_to_status_id" : 248297902798155776,
  "created_at" : "2012-09-19 05:51:00 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 3, 16 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 77 ],
      "url" : "https:\/\/t.co\/i8uY3Ib7",
      "expanded_url" : "https:\/\/twitter.com\/settings\/applications",
      "display_url" : "twitter.com\/settings\/appli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248150270146654208",
  "text" : "RT @jeremiahfelt: Public Service Announcement: Go here (https:\/\/t.co\/i8uY3Ib7) and audit what has access to your Twitter profile; revoke ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 59 ],
        "url" : "https:\/\/t.co\/i8uY3Ib7",
        "expanded_url" : "https:\/\/twitter.com\/settings\/applications",
        "display_url" : "twitter.com\/settings\/appli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "248149954063917056",
    "text" : "Public Service Announcement: Go here (https:\/\/t.co\/i8uY3Ib7) and audit what has access to your Twitter profile; revoke those you don't use.",
    "id" : 248149954063917056,
    "created_at" : "2012-09-18 20:02:14 +0000",
    "user" : {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "protected" : false,
      "id_str" : "9154112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530186011444535296\/UYLAc-sB_normal.jpeg",
      "id" : 9154112,
      "verified" : false
    }
  },
  "id" : 248150270146654208,
  "created_at" : "2012-09-18 20:03:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 37 ],
      "url" : "https:\/\/t.co\/AUypEe5M",
      "expanded_url" : "https:\/\/github.com\/Howtoovercome\/How-To-Overcome-Anxiety",
      "display_url" : "github.com\/Howtoovercome\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248146297729724417",
  "text" : "Spam commits!!? https:\/\/t.co\/AUypEe5M",
  "id" : 248146297729724417,
  "created_at" : "2012-09-18 19:47:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/hRAPQh1T",
      "expanded_url" : "http:\/\/visual.ly\/sevens-sets-venn-diagram?view=true",
      "display_url" : "visual.ly\/sevens-sets-ve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248133867276484608",
  "text" : "Brain...exploding... (make sure to drag it too) http:\/\/t.co\/hRAPQh1T",
  "id" : 248133867276484608,
  "created_at" : "2012-09-18 18:58:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/1qzu0qD5",
      "expanded_url" : "http:\/\/github.com\/launch",
      "display_url" : "github.com\/launch"
    }, {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/PurVUqPf",
      "expanded_url" : "http:\/\/github.com",
      "display_url" : "github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "248131181122572288",
  "text" : "I feel like http:\/\/t.co\/1qzu0qD5 should just be what's at http:\/\/t.co\/PurVUqPf when you sign in. Like Google.",
  "id" : 248131181122572288,
  "created_at" : "2012-09-18 18:47:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Erie.rb",
      "screen_name" : "erierb",
      "indices" : [ 59, 66 ],
      "id_str" : "776151728",
      "id" : 776151728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248127426947846144",
  "text" : "RT @aquaranto: Any Buffalo rubyists interested in going to @erierb with me on Thursday?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erie.rb",
        "screen_name" : "erierb",
        "indices" : [ 44, 51 ],
        "id_str" : "776151728",
        "id" : 776151728
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "248127145602330624",
    "text" : "Any Buffalo rubyists interested in going to @erierb with me on Thursday?",
    "id" : 248127145602330624,
    "created_at" : "2012-09-18 18:31:36 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 248127426947846144,
  "created_at" : "2012-09-18 18:32:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "forza",
      "screen_name" : "rubiii",
      "indices" : [ 0, 7 ],
      "id_str" : "18100029",
      "id" : 18100029
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 8, 16 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248121798816849920",
  "geo" : { },
  "id_str" : "248123558419648512",
  "in_reply_to_user_id" : 18100029,
  "text" : "@rubiii @evanphx has been doing a lot of work with them lately making it less...terrible. hopefully they will go on a separate site, soon",
  "id" : 248123558419648512,
  "in_reply_to_status_id" : 248121798816849920,
  "created_at" : "2012-09-18 18:17:20 +0000",
  "in_reply_to_screen_name" : "rubiii",
  "in_reply_to_user_id_str" : "18100029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "forza",
      "screen_name" : "rubiii",
      "indices" : [ 0, 7 ],
      "id_str" : "18100029",
      "id" : 18100029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248121798816849920",
  "geo" : { },
  "id_str" : "248122977231716352",
  "in_reply_to_user_id" : 18100029,
  "text" : "@rubiii we were getting DoS'd from sites\/spiders scraping them...also putting them in Redis finally caught up to us.",
  "id" : 248122977231716352,
  "in_reply_to_status_id" : 248121798816849920,
  "created_at" : "2012-09-18 18:15:02 +0000",
  "in_reply_to_screen_name" : "rubiii",
  "in_reply_to_user_id_str" : "18100029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/mSUo81AT",
      "expanded_url" : "http:\/\/queencityconquest.com",
      "display_url" : "queencityconquest.com"
    } ]
  },
  "geo" : { },
  "id_str" : "248104330136268800",
  "text" : "Hey Rochester, Erie, Toronto folks: Come to Buffalo for some board games this weekend! http:\/\/t.co\/mSUo81AT",
  "id" : 248104330136268800,
  "created_at" : "2012-09-18 17:00:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/k1JNr87X",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=-tBM2ZfncoU",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248102108203720704",
  "text" : "Pew! PEW PEW PEW PEW PEW http:\/\/t.co\/k1JNr87X",
  "id" : 248102108203720704,
  "created_at" : "2012-09-18 16:52:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248090232384266240",
  "geo" : { },
  "id_str" : "248090556037738496",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack absolutely love old Disney stuff like this.",
  "id" : 248090556037738496,
  "in_reply_to_status_id" : 248090232384266240,
  "created_at" : "2012-09-18 16:06:12 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248066984519024640",
  "text" : "I don't understand what to use as my Twitter header image. Feels like it should be a lot different than Facebook.",
  "id" : 248066984519024640,
  "created_at" : "2012-09-18 14:32:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/YziBqzjX",
      "expanded_url" : "http:\/\/instagram.com\/p\/Psvy_8EME6\/",
      "display_url" : "instagram.com\/p\/Psvy_8EME6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "247913684721090561",
  "text" : "Stunned that Yahoo had an \u00AE on their logo ON A WALL. http:\/\/t.co\/YziBqzjX",
  "id" : 247913684721090561,
  "created_at" : "2012-09-18 04:23:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.screenr.com\" rel=\"nofollow\"\u003EScreenr.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https:\/\/t.co\/2KUxp8YT",
      "expanded_url" : "https:\/\/github.com\/qrush\/snake",
      "display_url" : "github.com\/qrush\/snake"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/YwK3zTyw",
      "expanded_url" : "http:\/\/screenr.com\/KZo8",
      "display_url" : "screenr.com\/KZo8"
    } ]
  },
  "geo" : { },
  "id_str" : "247870757730918400",
  "text" : "Rediscovering a shoes.rb Snake game I wrote 4 years ago. Snake#eat! https:\/\/t.co\/2KUxp8YT http:\/\/t.co\/YwK3zTyw",
  "id" : 247870757730918400,
  "created_at" : "2012-09-18 01:32:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 7, 16 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247861482602250243",
  "geo" : { },
  "id_str" : "247862643187130369",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos @indirect ...do want",
  "id" : 247862643187130369,
  "in_reply_to_status_id" : 247861482602250243,
  "created_at" : "2012-09-18 01:00:33 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "indices" : [ 0, 11 ],
      "id_str" : "5539522",
      "id" : 5539522
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 30, 40 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 63, 71 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247860438807764993",
  "geo" : { },
  "id_str" : "247862064352219136",
  "in_reply_to_user_id" : 5539522,
  "text" : "@AskedRelic haha yes. made by @asianmack mostly to :trollface: @noahhlo :)",
  "id" : 247862064352219136,
  "in_reply_to_status_id" : 247860438807764993,
  "created_at" : "2012-09-18 00:58:15 +0000",
  "in_reply_to_screen_name" : "AskedRelic",
  "in_reply_to_user_id_str" : "5539522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 0, 9 ],
      "id_str" : "16515870",
      "id" : 16515870
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 10, 21 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https:\/\/t.co\/acIQ8uK3",
      "expanded_url" : "https:\/\/github.com\/coworkbuffalo\/coworkbuffalo.github.com",
      "display_url" : "github.com\/coworkbuffalo\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "247707896698249217",
  "geo" : { },
  "id_str" : "247709043530022912",
  "in_reply_to_user_id" : 16515870,
  "text" : "@aardrian @kevinpurdy pull requests are welcome! https:\/\/t.co\/acIQ8uK3",
  "id" : 247709043530022912,
  "in_reply_to_status_id" : 247707896698249217,
  "created_at" : "2012-09-17 14:50:12 +0000",
  "in_reply_to_screen_name" : "aardrian",
  "in_reply_to_user_id_str" : "16515870",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 3, 16 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 116 ],
      "url" : "https:\/\/t.co\/H3vTsPqx",
      "expanded_url" : "https:\/\/docs.google.com\/document\/pub?id=1GWTMLjqQsQS45FWwqNG9ztQTdGF48hQYpjQHR_d1WsI",
      "display_url" : "docs.google.com\/document\/pub?i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "247552284895109120",
  "text" : "RT @codinghorror: Atwood's Law again: Apple implements manual video compression in Javascript. https:\/\/t.co\/H3vTsPqx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 98 ],
        "url" : "https:\/\/t.co\/H3vTsPqx",
        "expanded_url" : "https:\/\/docs.google.com\/document\/pub?id=1GWTMLjqQsQS45FWwqNG9ztQTdGF48hQYpjQHR_d1WsI",
        "display_url" : "docs.google.com\/document\/pub?i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "247551780781690881",
    "text" : "Atwood's Law again: Apple implements manual video compression in Javascript. https:\/\/t.co\/H3vTsPqx",
    "id" : 247551780781690881,
    "created_at" : "2012-09-17 04:25:18 +0000",
    "user" : {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "protected" : false,
      "id_str" : "5637652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2052442590\/coding-horror-official-logo-medium_normal.png",
      "id" : 5637652,
      "verified" : true
    }
  },
  "id" : 247552284895109120,
  "created_at" : "2012-09-17 04:27:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247379038589562880",
  "geo" : { },
  "id_str" : "247509817835520000",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison how'd that go?",
  "id" : 247509817835520000,
  "in_reply_to_status_id" : 247379038589562880,
  "created_at" : "2012-09-17 01:38:33 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert W",
      "screen_name" : "robert_winslow",
      "indices" : [ 0, 15 ],
      "id_str" : "14541280",
      "id" : 14541280
    }, {
      "name" : "paul smith",
      "screen_name" : "paulsmith",
      "indices" : [ 16, 26 ],
      "id_str" : "4578",
      "id" : 4578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247040005942431744",
  "geo" : { },
  "id_str" : "247061415712681984",
  "in_reply_to_user_id" : 14541280,
  "text" : "@robert_winslow @paulsmith how does it handle retries? Failures? Checking status? Spreading load across boxes?",
  "id" : 247061415712681984,
  "in_reply_to_status_id" : 247040005942431744,
  "created_at" : "2012-09-15 19:56:46 +0000",
  "in_reply_to_screen_name" : "robert_winslow",
  "in_reply_to_user_id_str" : "14541280",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246837783707127808",
  "geo" : { },
  "id_str" : "246838460730720257",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh just got it gifted from a friend. Did a tutorial and the first level. Not sure how it\u2019s compared to nethack.",
  "id" : 246838460730720257,
  "in_reply_to_status_id" : 246837783707127808,
  "created_at" : "2012-09-15 05:10:49 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246800776494723072",
  "geo" : { },
  "id_str" : "246800932493484034",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx wow fun. Using that memory hard.",
  "id" : 246800932493484034,
  "in_reply_to_status_id" : 246800776494723072,
  "created_at" : "2012-09-15 02:41:42 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 0, 16 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 17, 25 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246796011203342336",
  "geo" : { },
  "id_str" : "246800738955714560",
  "in_reply_to_user_id" : 529540581,
  "text" : "@rubygems_status @evanphx also no time zone on that tweet",
  "id" : 246800738955714560,
  "in_reply_to_status_id" : 246796011203342336,
  "created_at" : "2012-09-15 02:40:56 +0000",
  "in_reply_to_screen_name" : "rubygems_status",
  "in_reply_to_user_id_str" : "529540581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 0, 16 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 17, 25 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246796011203342336",
  "geo" : { },
  "id_str" : "246800650690785280",
  "in_reply_to_user_id" : 529540581,
  "text" : "@rubygems_status @evanphx just saw this\u2026not going to be around. What\u2019s up?",
  "id" : 246800650690785280,
  "in_reply_to_status_id" : 246796011203342336,
  "created_at" : "2012-09-15 02:40:35 +0000",
  "in_reply_to_screen_name" : "rubygems_status",
  "in_reply_to_user_id_str" : "529540581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia West",
      "screen_name" : "juliamae",
      "indices" : [ 0, 9 ],
      "id_str" : "6354852",
      "id" : 6354852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246764712975560704",
  "geo" : { },
  "id_str" : "246766093740437504",
  "in_reply_to_user_id" : 6354852,
  "text" : "@juliamae oh awesome! If you visit Buffalo give a shout",
  "id" : 246766093740437504,
  "in_reply_to_status_id" : 246764712975560704,
  "created_at" : "2012-09-15 00:23:16 +0000",
  "in_reply_to_screen_name" : "juliamae",
  "in_reply_to_user_id_str" : "6354852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia West",
      "screen_name" : "juliamae",
      "indices" : [ 0, 9 ],
      "id_str" : "6354852",
      "id" : 6354852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246748047890067458",
  "geo" : { },
  "id_str" : "246748341130649600",
  "in_reply_to_user_id" : 6354852,
  "text" : "@juliamae you\u2019re in Rochester?! Also I fear for your insides.",
  "id" : 246748341130649600,
  "in_reply_to_status_id" : 246748047890067458,
  "created_at" : "2012-09-14 23:12:43 +0000",
  "in_reply_to_screen_name" : "juliamae",
  "in_reply_to_user_id_str" : "6354852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/p8HbUUBM",
      "expanded_url" : "http:\/\/imgur.com\/a\/PlSqd",
      "display_url" : "imgur.com\/a\/PlSqd"
    } ]
  },
  "geo" : { },
  "id_str" : "246724776251510784",
  "text" : "Removing the text and backgrounds from the new Buffalo News site shows how flawed the design is. No hierarchy. http:\/\/t.co\/p8HbUUBM",
  "id" : 246724776251510784,
  "created_at" : "2012-09-14 21:39:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246694289600557057",
  "text" : "Get rained on.",
  "id" : 246694289600557057,
  "created_at" : "2012-09-14 19:37:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 0, 9 ],
      "id_str" : "717973",
      "id" : 717973
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 22, 35 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246681599016566784",
  "geo" : { },
  "id_str" : "246682062923395074",
  "in_reply_to_user_id" : 717973,
  "text" : "@ceejayoz urge to use @herpderpedia ...rising",
  "id" : 246682062923395074,
  "in_reply_to_status_id" : 246681599016566784,
  "created_at" : "2012-09-14 18:49:21 +0000",
  "in_reply_to_screen_name" : "ceejayoz",
  "in_reply_to_user_id_str" : "717973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Andy Staple",
      "screen_name" : "AndyStaple",
      "indices" : [ 12, 23 ],
      "id_str" : "34352961",
      "id" : 34352961
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 24, 39 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 40, 53 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246681106785660929",
  "geo" : { },
  "id_str" : "246681648102531073",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @andystaple @ChrisVanPatten @ChrisSmithAV my problem: it stinks of absolute incompetency, and makes the entire region look bad.",
  "id" : 246681648102531073,
  "in_reply_to_status_id" : 246681106785660929,
  "created_at" : "2012-09-14 18:47:42 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 16, 27 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 28, 41 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246679658408591360",
  "geo" : { },
  "id_str" : "246679999560708096",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @kevinpurdy @ChrisSmithAV Yes, yes, yes. This is definitely it.",
  "id" : 246679999560708096,
  "in_reply_to_status_id" : 246679658408591360,
  "created_at" : "2012-09-14 18:41:09 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/246678248988221440\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/qObclRjo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2xgj35CIAAKwMX.png",
      "id_str" : "246678249013387264",
      "id" : 246678249013387264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2xgj35CIAAKwMX.png",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/qObclRjo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246678248988221440",
  "text" : "My favorite part of the LinkedIN profile (besides the part where they ASK FOR YOUR EMAIL PASSWORD): http:\/\/t.co\/qObclRjo",
  "id" : 246678248988221440,
  "created_at" : "2012-09-14 18:34:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246677124935733248",
  "geo" : { },
  "id_str" : "246677382096904192",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV people read the buffalo news?",
  "id" : 246677382096904192,
  "in_reply_to_status_id" : 246677124935733248,
  "created_at" : "2012-09-14 18:30:45 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/iuRrWI3J",
      "expanded_url" : "http:\/\/nl.linkedin.com\/pub\/rofl-copter\/58\/503\/825",
      "display_url" : "nl.linkedin.com\/pub\/rofl-copte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246676838175358976",
  "text" : "Am I using LinkedIN right? http:\/\/t.co\/iuRrWI3J",
  "id" : 246676838175358976,
  "created_at" : "2012-09-14 18:28:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 3, 13 ],
      "id_str" : "817437266",
      "id" : 817437266
    }, {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 26, 36 ],
      "id_str" : "817437266",
      "id" : 817437266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/gzYGQZCE",
      "expanded_url" : "http:\/\/buffalojavascript.org\/",
      "display_url" : "buffalojavascript.org"
    } ]
  },
  "geo" : { },
  "id_str" : "246639017142136833",
  "text" : "RT @BuffaloJS: Announcing @BuffaloJS -- JavaScript meetups coming very soon to Western New York! http:\/\/t.co\/gzYGQZCE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo JavaScript",
        "screen_name" : "BuffaloJS",
        "indices" : [ 11, 21 ],
        "id_str" : "817437266",
        "id" : 817437266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/gzYGQZCE",
        "expanded_url" : "http:\/\/buffalojavascript.org\/",
        "display_url" : "buffalojavascript.org"
      } ]
    },
    "geo" : { },
    "id_str" : "246633774903869440",
    "text" : "Announcing @BuffaloJS -- JavaScript meetups coming very soon to Western New York! http:\/\/t.co\/gzYGQZCE",
    "id" : 246633774903869440,
    "created_at" : "2012-09-14 15:37:28 +0000",
    "user" : {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "protected" : false,
      "id_str" : "817437266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2610143091\/l6yzj9lm8dkcmc3qdqed_normal.png",
      "id" : 817437266,
      "verified" : false
    }
  },
  "id" : 246639017142136833,
  "created_at" : "2012-09-14 15:58:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sports Geeks",
      "screen_name" : "thesportsgeeks",
      "indices" : [ 3, 18 ],
      "id_str" : "34531568",
      "id" : 34531568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/uzbsELgv",
      "expanded_url" : "http:\/\/thesportsgeeks.com\/2012\/09\/13\/infographic-2012-nfl-week-one\/",
      "display_url" : "thesportsgeeks.com\/2012\/09\/13\/inf\u2026"
    }, {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/lweJXt78",
      "expanded_url" : "http:\/\/twitpic.com\/auaeyl",
      "display_url" : "twitpic.com\/auaeyl"
    } ]
  },
  "geo" : { },
  "id_str" : "246630411348869120",
  "text" : "RT @thesportsgeeks: COOL NEW THING. Infographic: 2012 NFL Week One: http:\/\/t.co\/uzbsELgv http:\/\/t.co\/lweJXt78",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/uzbsELgv",
        "expanded_url" : "http:\/\/thesportsgeeks.com\/2012\/09\/13\/infographic-2012-nfl-week-one\/",
        "display_url" : "thesportsgeeks.com\/2012\/09\/13\/inf\u2026"
      }, {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/lweJXt78",
        "expanded_url" : "http:\/\/twitpic.com\/auaeyl",
        "display_url" : "twitpic.com\/auaeyl"
      } ]
    },
    "geo" : { },
    "id_str" : "246398808966197248",
    "text" : "COOL NEW THING. Infographic: 2012 NFL Week One: http:\/\/t.co\/uzbsELgv http:\/\/t.co\/lweJXt78",
    "id" : 246398808966197248,
    "created_at" : "2012-09-14 00:03:48 +0000",
    "user" : {
      "name" : "The Sports Geeks",
      "screen_name" : "thesportsgeeks",
      "protected" : false,
      "id_str" : "34531568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422472281219026944\/Cvq4WEoN_normal.jpeg",
      "id" : 34531568,
      "verified" : false
    }
  },
  "id" : 246630411348869120,
  "created_at" : "2012-09-14 15:24:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sports Geeks",
      "screen_name" : "thesportsgeeks",
      "indices" : [ 29, 44 ],
      "id_str" : "34531568",
      "id" : 34531568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/fQlwvjIZ",
      "expanded_url" : "http:\/\/thesportsgeeks.com\/wp-content\/uploads\/2012\/09\/WeekOne.jpg",
      "display_url" : "thesportsgeeks.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246630335620739072",
  "text" : "Loving this infographic from @thesportsgeeks. No checking of sports sites, instantly updated about the NFL. http:\/\/t.co\/fQlwvjIZ",
  "id" : 246630335620739072,
  "created_at" : "2012-09-14 15:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246611128640208897",
  "geo" : { },
  "id_str" : "246613791423479808",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder yeah, not going to happen anytime soon.",
  "id" : 246613791423479808,
  "in_reply_to_status_id" : 246611128640208897,
  "created_at" : "2012-09-14 14:18:04 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246601782581686272",
  "geo" : { },
  "id_str" : "246603888210354176",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder I think it boils down to lack of creativity and no central package manager to guide naming",
  "id" : 246603888210354176,
  "in_reply_to_status_id" : 246601782581686272,
  "created_at" : "2012-09-14 13:38:43 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246595884912107520",
  "geo" : { },
  "id_str" : "246596234792546305",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 yes. I can be on IRC by 10 EST.",
  "id" : 246596234792546305,
  "in_reply_to_status_id" : 246595884912107520,
  "created_at" : "2012-09-14 13:08:18 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mose",
      "screen_name" : "mo5e",
      "indices" : [ 0, 5 ],
      "id_str" : "68781770",
      "id" : 68781770
    }, {
      "name" : "Evan",
      "screen_name" : "evan",
      "indices" : [ 69, 74 ],
      "id_str" : "761613",
      "id" : 761613
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 75, 82 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/UitOynj9",
      "expanded_url" : "http:\/\/github.com\/RubyGems\/gemwhisperer",
      "display_url" : "github.com\/RubyGems\/gemwh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "246270441159786496",
  "geo" : { },
  "id_str" : "246457958647595009",
  "in_reply_to_user_id" : 68781770,
  "text" : "@mo5e ugh! Had no idea. Maybe patch it at http:\/\/t.co\/UitOynj9 ? \/cc @evan @sferik",
  "id" : 246457958647595009,
  "in_reply_to_status_id" : 246270441159786496,
  "created_at" : "2012-09-14 03:58:50 +0000",
  "in_reply_to_screen_name" : "mo5e",
  "in_reply_to_user_id_str" : "68781770",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 12, 20 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246426451258245120",
  "geo" : { },
  "id_str" : "246426551766380546",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @fending seriously! brew on.",
  "id" : 246426551766380546,
  "in_reply_to_status_id" : 246426451258245120,
  "created_at" : "2012-09-14 01:54:02 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/DnldKone",
      "expanded_url" : "http:\/\/instagr.am\/p\/PiH1a6s6tp\/",
      "display_url" : "instagr.am\/p\/PiH1a6s6tp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "246383002643476483",
  "text" : "Lump charcoal is very sparky.  http:\/\/t.co\/DnldKone",
  "id" : 246383002643476483,
  "created_at" : "2012-09-13 23:01:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246336274418507777",
  "geo" : { },
  "id_str" : "246336844088897536",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh You should have taken the ferry instead of fording the river.",
  "id" : 246336844088897536,
  "in_reply_to_status_id" : 246336274418507777,
  "created_at" : "2012-09-13 19:57:35 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246326833518366720",
  "geo" : { },
  "id_str" : "246329416219762689",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton consume the apprentices first",
  "id" : 246329416219762689,
  "in_reply_to_status_id" : 246326833518366720,
  "created_at" : "2012-09-13 19:28:04 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 26, 32 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/8rpQs0Qq",
      "expanded_url" : "http:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/innovationist.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246320442560884736",
  "text" : "RT @kevinpurdy: Thanks to @qrush, I can't unhear this: http:\/\/t.co\/8rpQs0Qq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 10, 16 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/8rpQs0Qq",
        "expanded_url" : "http:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/innovationist.mp3",
        "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "246320027161219072",
    "text" : "Thanks to @qrush, I can't unhear this: http:\/\/t.co\/8rpQs0Qq",
    "id" : 246320027161219072,
    "created_at" : "2012-09-13 18:50:45 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 246320442560884736,
  "created_at" : "2012-09-13 18:52:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 3, 8 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246313207545876481",
  "text" : "RT @beep: \u201CWhat harm could a fifth cup of coffee do,\u201D he thought immediately before time and space began kaleidoscoping before his very eyes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "246312141018263552",
    "text" : "\u201CWhat harm could a fifth cup of coffee do,\u201D he thought immediately before time and space began kaleidoscoping before his very eyes",
    "id" : 246312141018263552,
    "created_at" : "2012-09-13 18:19:25 +0000",
    "user" : {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "protected" : false,
      "id_str" : "12534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561270834401382400\/AJ669BlB_normal.png",
      "id" : 12534,
      "verified" : false
    }
  },
  "id" : 246313207545876481,
  "created_at" : "2012-09-13 18:23:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Irish",
      "screen_name" : "paul_irish",
      "indices" : [ 0, 11 ],
      "id_str" : "1671811",
      "id" : 1671811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246268203234390016",
  "geo" : { },
  "id_str" : "246268335187165184",
  "in_reply_to_user_id" : 1671811,
  "text" : "@paul_irish until...you realize you need to use emacs",
  "id" : 246268335187165184,
  "in_reply_to_status_id" : 246268203234390016,
  "created_at" : "2012-09-13 15:25:21 +0000",
  "in_reply_to_screen_name" : "paul_irish",
  "in_reply_to_user_id_str" : "1671811",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246265145481916417",
  "text" : "And... xiki requires emacs. \/play trombone",
  "id" : 246265145481916417,
  "created_at" : "2012-09-13 15:12:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 0, 8 ],
      "id_str" : "270917610",
      "id" : 270917610
    }, {
      "name" : "Brent LaRowe",
      "screen_name" : "Blarowe",
      "indices" : [ 9, 17 ],
      "id_str" : "15080463",
      "id" : 15080463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246096392991424515",
  "geo" : { },
  "id_str" : "246263879733227520",
  "in_reply_to_user_id" : 270917610,
  "text" : "@alarowe @Blarowe yay! congrats!",
  "id" : 246263879733227520,
  "in_reply_to_status_id" : 246096392991424515,
  "created_at" : "2012-09-13 15:07:38 +0000",
  "in_reply_to_screen_name" : "alarowe",
  "in_reply_to_user_id_str" : "270917610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Barrett",
      "screen_name" : "thoughtpunch",
      "indices" : [ 0, 13 ],
      "id_str" : "202236256",
      "id" : 202236256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/qOetnNUg",
      "expanded_url" : "http:\/\/rdoc.info",
      "display_url" : "rdoc.info"
    } ]
  },
  "in_reply_to_status_id_str" : "245974343501357056",
  "geo" : { },
  "id_str" : "246231289257160706",
  "in_reply_to_user_id" : 202236256,
  "text" : "@thoughtpunch this is why there\u2019s an http:\/\/t.co\/qOetnNUg link on each gem page.",
  "id" : 246231289257160706,
  "in_reply_to_status_id" : 245974343501357056,
  "created_at" : "2012-09-13 12:58:08 +0000",
  "in_reply_to_screen_name" : "thoughtpunch",
  "in_reply_to_user_id_str" : "202236256",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246090128311865344",
  "geo" : { },
  "id_str" : "246090534647627777",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan had a similar moment. I hope it\u2019s not slow.",
  "id" : 246090534647627777,
  "in_reply_to_status_id" : 246090128311865344,
  "created_at" : "2012-09-13 03:38:50 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Hosey",
      "screen_name" : "boredzo",
      "indices" : [ 0, 8 ],
      "id_str" : "12995622",
      "id" : 12995622
    }, {
      "name" : "John Gruber",
      "screen_name" : "gruber",
      "indices" : [ 9, 16 ],
      "id_str" : "33423",
      "id" : 33423
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 99, 112 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243925330908291072",
  "geo" : { },
  "id_str" : "246089896928886784",
  "in_reply_to_user_id" : 12995622,
  "text" : "@boredzo @gruber no, they certainly do not understand twitter is public. Exposing stupidity is now @herpderpedia\u2019s mission.",
  "id" : 246089896928886784,
  "in_reply_to_status_id" : 243925330908291072,
  "created_at" : "2012-09-13 03:36:18 +0000",
  "in_reply_to_screen_name" : "boredzo",
  "in_reply_to_user_id_str" : "12995622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/YZ8aFvQh",
      "expanded_url" : "http:\/\/youtu.be\/bUR_eUVcABg",
      "display_url" : "youtu.be\/bUR_eUVcABg"
    } ]
  },
  "geo" : { },
  "id_str" : "246088597692874753",
  "text" : "Blown away by the xiki demo. Going to try it out tomorrow. http:\/\/t.co\/YZ8aFvQh",
  "id" : 246088597692874753,
  "created_at" : "2012-09-13 03:31:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 57, 68 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245994528786505728",
  "text" : "gsay \"what hath i wrought\" ...just got gsay installed on @kevinpurdy's chromebook.",
  "id" : 245994528786505728,
  "created_at" : "2012-09-12 21:17:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245969592017633281",
  "geo" : { },
  "id_str" : "245974787271303168",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy Congrats dude! Now you have another genre of DVDs to rip.",
  "id" : 245974787271303168,
  "in_reply_to_status_id" : 245969592017633281,
  "created_at" : "2012-09-12 19:58:53 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 3, 13 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245960136080912385",
  "text" : "RT @zachwaugh: \u201CNow announcing all new Foo Fighters. Lighter, thinner, available in October. Best Foo Fighters we ever made, think you\u2019r ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245956207674793984",
    "text" : "\u201CNow announcing all new Foo Fighters. Lighter, thinner, available in October. Best Foo Fighters we ever made, think you\u2019re gonna love it.\u201D",
    "id" : 245956207674793984,
    "created_at" : "2012-09-12 18:45:04 +0000",
    "user" : {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "protected" : false,
      "id_str" : "14620798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549681852332535809\/TzOXTBNx_normal.jpeg",
      "id" : 14620798,
      "verified" : false
    }
  },
  "id" : 245960136080912385,
  "created_at" : "2012-09-12 19:00:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 3, 7 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245957948243865601",
  "text" : "RT @lrz: Okay Apple event seems to be finished, let's go straight to hacker news for expert commentary.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245957038985838592",
    "text" : "Okay Apple event seems to be finished, let's go straight to hacker news for expert commentary.",
    "id" : 245957038985838592,
    "created_at" : "2012-09-12 18:48:22 +0000",
    "user" : {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "protected" : false,
      "id_str" : "10452222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459499652228714497\/EiSPykkq_normal.png",
      "id" : 10452222,
      "verified" : false
    }
  },
  "id" : 245957948243865601,
  "created_at" : "2012-09-12 18:51:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael J Nelson",
      "screen_name" : "michaeljnelson",
      "indices" : [ 3, 18 ],
      "id_str" : "30090568",
      "id" : 30090568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245952747772461056",
  "text" : "RT @michaeljnelson: Apple just unveiled the iPhone and -- oh, God, no! It snapped its chains, its rampaging in the crowd! Blood everywhe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245951222677401601",
    "text" : "Apple just unveiled the iPhone and -- oh, God, no! It snapped its chains, its rampaging in the crowd! Blood everywhere, hundreds dead!",
    "id" : 245951222677401601,
    "created_at" : "2012-09-12 18:25:15 +0000",
    "user" : {
      "name" : "Michael J Nelson",
      "screen_name" : "michaeljnelson",
      "protected" : false,
      "id_str" : "30090568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454929538\/Michael_J_Nelsontwit_5_normal.jpg",
      "id" : 30090568,
      "verified" : false
    }
  },
  "id" : 245952747772461056,
  "created_at" : "2012-09-12 18:31:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence Curtis",
      "screen_name" : "lawrencecurtis",
      "indices" : [ 0, 15 ],
      "id_str" : "14472196",
      "id" : 14472196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245944440739487744",
  "geo" : { },
  "id_str" : "245944771904937984",
  "in_reply_to_user_id" : 14472196,
  "text" : "@lawrencecurtis got a link for docs?",
  "id" : 245944771904937984,
  "in_reply_to_status_id" : 245944440739487744,
  "created_at" : "2012-09-12 17:59:37 +0000",
  "in_reply_to_screen_name" : "lawrencecurtis",
  "in_reply_to_user_id_str" : "14472196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 38, 52 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245944180059279361",
  "text" : "Kind of want Passbook integration for @CoworkBuffalo ...",
  "id" : 245944180059279361,
  "created_at" : "2012-09-12 17:57:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 3, 14 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245940009532792833",
  "text" : "RT @jaytennier: \u201CThunderbolt and Lightning\u201D\n\nVery, very, frightening me!\n\nGALILEO galileo GALILEO galileo GALILEO FIGARO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245939858504290304",
    "text" : "\u201CThunderbolt and Lightning\u201D\n\nVery, very, frightening me!\n\nGALILEO galileo GALILEO galileo GALILEO FIGARO",
    "id" : 245939858504290304,
    "created_at" : "2012-09-12 17:40:06 +0000",
    "user" : {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "protected" : false,
      "id_str" : "15020118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428887276228067329\/L0TrLGr5_normal.jpeg",
      "id" : 15020118,
      "verified" : false
    }
  },
  "id" : 245940009532792833,
  "created_at" : "2012-09-12 17:40:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/6t9WRIrR",
      "expanded_url" : "http:\/\/www.unitedpixelworkers.com\/products\/buffalo",
      "display_url" : "unitedpixelworkers.com\/products\/buffa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245899440890712064",
  "text" : "Looks like the Buffalo Pixelworkers shirts are back in stock! http:\/\/t.co\/6t9WRIrR",
  "id" : 245899440890712064,
  "created_at" : "2012-09-12 14:59:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 41, 55 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/245898851326758913\/photo\/1",
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/fOxa6pYX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2mbs9RCEAA_nol.jpg",
      "id_str" : "245898851330953216",
      "id" : 245898851330953216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2mbs9RCEAA_nol.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fOxa6pYX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245898851326758913",
  "text" : "All set up for the iPhone 5 announcement @coworkbuffalo ! http:\/\/t.co\/fOxa6pYX",
  "id" : 245898851326758913,
  "created_at" : "2012-09-12 14:57:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 43 ],
      "url" : "https:\/\/t.co\/3ZoLrdUc",
      "expanded_url" : "https:\/\/www.gittip.com\/qrush\/",
      "display_url" : "gittip.com\/qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "245893887045038080",
  "text" : "Hey! I have a gittip! https:\/\/t.co\/3ZoLrdUc (This morning's rush ended up with a parking ticket. Thanks City of Buffalo!)",
  "id" : 245893887045038080,
  "created_at" : "2012-09-12 14:37:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku Status",
      "screen_name" : "herokustatus",
      "indices" : [ 0, 13 ],
      "id_str" : "101876272",
      "id" : 101876272
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 14, 21 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245877594606682113",
  "geo" : { },
  "id_str" : "245878242052034560",
  "in_reply_to_user_id" : 101876272,
  "text" : "@herokustatus @hone02 shouldn't Bundler fall back to the legacy API?",
  "id" : 245878242052034560,
  "in_reply_to_status_id" : 245877594606682113,
  "created_at" : "2012-09-12 13:35:15 +0000",
  "in_reply_to_screen_name" : "herokustatus",
  "in_reply_to_user_id_str" : "101876272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "245877890305114114",
  "text" : "It seems that http:\/\/t.co\/bdjsRgTW has come back on its own...when I SSH'd in: \"load average: 32.71, 20.89, 13.96\" :( Not sure why.",
  "id" : 245877890305114114,
  "created_at" : "2012-09-12 13:33:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graeme Mathieson",
      "screen_name" : "mathie",
      "indices" : [ 0, 7 ],
      "id_str" : "12501",
      "id" : 12501
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 63, 71 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245877464075739137",
  "geo" : { },
  "id_str" : "245877680770273280",
  "in_reply_to_user_id" : 12501,
  "text" : "@mathie i can barely do so, i'm really not a sysadmin. i'd bug @evanphx on #rubygems \/ freenode if you want to help.",
  "id" : 245877680770273280,
  "in_reply_to_status_id" : 245877464075739137,
  "created_at" : "2012-09-12 13:33:01 +0000",
  "in_reply_to_screen_name" : "mathie",
  "in_reply_to_user_id_str" : "12501",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 68, 82 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "245873860556247040",
  "text" : "http:\/\/t.co\/t7WATcFT is DOA and so is my home Internets. Heading to @coworkbuffalo posthaste\u2026",
  "id" : 245873860556247040,
  "created_at" : "2012-09-12 13:17:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha\u0142 Szajbe",
      "screen_name" : "szajbus",
      "indices" : [ 0, 8 ],
      "id_str" : "14422323",
      "id" : 14422323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245671252507914240",
  "geo" : { },
  "id_str" : "245671750199803904",
  "in_reply_to_user_id" : 14422323,
  "text" : "@szajbus yeah clearly &gt; 1 or 2 variables are bad. but i really liked this about rails. :[",
  "id" : 245671750199803904,
  "in_reply_to_status_id" : 245671252507914240,
  "created_at" : "2012-09-11 23:54:44 +0000",
  "in_reply_to_screen_name" : "szajbus",
  "in_reply_to_user_id_str" : "14422323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rails4",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 110 ],
      "url" : "https:\/\/t.co\/hqYWhBIK",
      "expanded_url" : "https:\/\/github.com\/search?langOverride=&language=Ruby&q=find_all_by&repo=&start_value=1&type=Code",
      "display_url" : "github.com\/search?langOve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245669838410878976",
  "text" : "Not a fan of the find_all_by, etc finders removed from #rails4. Why is this a good idea? https:\/\/t.co\/hqYWhBIK",
  "id" : 245669838410878976,
  "created_at" : "2012-09-11 23:47:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 9, 18 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 23, 31 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/245662887400595457\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/dk4hYMrr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2jFGDJCYAAAqq0.jpg",
      "id_str" : "245662887404789760",
      "id" : 245662887404789760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2jFGDJCYAAAqq0.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dk4hYMrr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245662887400595457",
  "text" : "Watching @bostonrb and @sikachu porch side from Buffalo! http:\/\/t.co\/dk4hYMrr",
  "id" : 245662887400595457,
  "created_at" : "2012-09-11 23:19:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245649377035698177",
  "text" : "Programming: where you constantly are proving yourself that you know less and less every day.",
  "id" : 245649377035698177,
  "created_at" : "2012-09-11 22:25:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 0, 11 ],
      "id_str" : "56423575",
      "id" : 56423575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/t77t0sdA",
      "expanded_url" : "http:\/\/www.designsponge.com\/2012\/09\/buffalo-ny-city-guide.html#more-147732",
      "display_url" : "designsponge.com\/2012\/09\/buffal\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "245406576914083840",
  "geo" : { },
  "id_str" : "245647636374380545",
  "in_reply_to_user_id" : 56423575,
  "text" : "@luisjoseve http:\/\/t.co\/t77t0sdA",
  "id" : 245647636374380545,
  "in_reply_to_status_id" : 245406576914083840,
  "created_at" : "2012-09-11 22:18:55 +0000",
  "in_reply_to_screen_name" : "luisjoseve",
  "in_reply_to_user_id_str" : "56423575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245645210103717891",
  "geo" : { },
  "id_str" : "245645309080924160",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal Passenger works well.",
  "id" : 245645309080924160,
  "in_reply_to_status_id" : 245645210103717891,
  "created_at" : "2012-09-11 22:09:40 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245642099456897024",
  "geo" : { },
  "id_str" : "245644648603873280",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal use Heroku.",
  "id" : 245644648603873280,
  "in_reply_to_status_id" : 245642099456897024,
  "created_at" : "2012-09-11 22:07:02 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent LaRowe",
      "screen_name" : "Blarowe",
      "indices" : [ 0, 8 ],
      "id_str" : "15080463",
      "id" : 15080463
    }, {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 9, 17 ],
      "id_str" : "270917610",
      "id" : 270917610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245605947953803264",
  "geo" : { },
  "id_str" : "245609151470915584",
  "in_reply_to_user_id" : 15080463,
  "text" : "@Blarowe @alarowe thundercats are go!!!! good luck!",
  "id" : 245609151470915584,
  "in_reply_to_status_id" : 245605947953803264,
  "created_at" : "2012-09-11 19:45:59 +0000",
  "in_reply_to_screen_name" : "Blarowe",
  "in_reply_to_user_id_str" : "15080463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245545245926907906",
  "text" : "And suddenly, a hundred GitHub employees cried out \"DISTRIBUTED VERSION CONTROL SYSTEM!\"",
  "id" : 245545245926907906,
  "created_at" : "2012-09-11 15:32:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 3, 14 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wnyruby",
      "indices" : [ 25, 33 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245528633014382592",
  "text" : "RT @Jonplussed: Wow, has #wnyruby grown. Easily my favorite community in #Buffalo.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wnyruby",
        "indices" : [ 9, 17 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245514836367273984",
    "text" : "Wow, has #wnyruby grown. Easily my favorite community in #Buffalo.",
    "id" : 245514836367273984,
    "created_at" : "2012-09-11 13:31:13 +0000",
    "user" : {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "protected" : false,
      "id_str" : "38408851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471328341526462464\/hNg5dFGn_normal.jpeg",
      "id" : 38408851,
      "verified" : false
    }
  },
  "id" : 245528633014382592,
  "created_at" : "2012-09-11 14:26:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245523491653312513",
  "geo" : { },
  "id_str" : "245528548117454852",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan lolmentation",
  "id" : 245528548117454852,
  "in_reply_to_status_id" : 245523491653312513,
  "created_at" : "2012-09-11 14:25:42 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    }, {
      "name" : "Casey Rosenthal",
      "screen_name" : "caseyrosenthal",
      "indices" : [ 11, 26 ],
      "id_str" : "17850415",
      "id" : 17850415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/9q1vXDQR",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dogs\/comments\/znvkb\/bad_6_mo_old_husky\/c66ich5",
      "display_url" : "reddit.com\/r\/dogs\/comment\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "245415062796378112",
  "geo" : { },
  "id_str" : "245415380913385472",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox @caseyrosenthal tried to be as positive as possible here: http:\/\/t.co\/9q1vXDQR",
  "id" : 245415380913385472,
  "in_reply_to_status_id" : 245415062796378112,
  "created_at" : "2012-09-11 06:56:01 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Rosenthal",
      "screen_name" : "caseyrosenthal",
      "indices" : [ 0, 15 ],
      "id_str" : "17850415",
      "id" : 17850415
    }, {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 16, 26 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245411000751362050",
  "geo" : { },
  "id_str" : "245411260689174528",
  "in_reply_to_user_id" : 17850415,
  "text" : "@caseyrosenthal @patmaddox awesome, thanks. also, dog park is the best here. It's huge, only 10 mins away, and he can run it all out.",
  "id" : 245411260689174528,
  "in_reply_to_status_id" : 245411000751362050,
  "created_at" : "2012-09-11 06:39:38 +0000",
  "in_reply_to_screen_name" : "caseyrosenthal",
  "in_reply_to_user_id_str" : "17850415",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 0, 11 ],
      "id_str" : "56423575",
      "id" : 56423575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/XTyK8Gf4",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/buffalo",
      "display_url" : "reddit.com\/r\/buffalo"
    } ]
  },
  "in_reply_to_status_id_str" : "245406576914083840",
  "geo" : { },
  "id_str" : "245409977873874944",
  "in_reply_to_user_id" : 56423575,
  "text" : "@luisjoseve at least to see the Falls! Lots of \"things to do\" on the sidebar here: http:\/\/t.co\/XTyK8Gf4",
  "id" : 245409977873874944,
  "in_reply_to_status_id" : 245406576914083840,
  "created_at" : "2012-09-11 06:34:32 +0000",
  "in_reply_to_screen_name" : "luisjoseve",
  "in_reply_to_user_id_str" : "56423575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245409662692913153",
  "text" : "Apparently brain decided sleep is not a thing tonight.",
  "id" : 245409662692913153,
  "created_at" : "2012-09-11 06:33:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245399504768094208",
  "geo" : { },
  "id_str" : "245400301371281408",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark puppins!?",
  "id" : 245400301371281408,
  "in_reply_to_status_id" : 245399504768094208,
  "created_at" : "2012-09-11 05:56:05 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/dVR5hJte",
      "expanded_url" : "http:\/\/i.imgur.com\/RBm8Lh.jpg",
      "display_url" : "i.imgur.com\/RBm8Lh.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "245398405881397249",
  "geo" : { },
  "id_str" : "245400219624296448",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox http:\/\/t.co\/dVR5hJte (almost a year ago! Hasn\u2019t destroyed much since. Besides a lot of tennis balls and frisbees.)",
  "id" : 245400219624296448,
  "in_reply_to_status_id" : 245398405881397249,
  "created_at" : "2012-09-11 05:55:46 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245398342849413120",
  "geo" : { },
  "id_str" : "245399369543725057",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox hell yes, we bike too. Dog park is easier though. Do you get foot pads or anything? Found that his feet get torn up :(",
  "id" : 245399369543725057,
  "in_reply_to_status_id" : 245398342849413120,
  "created_at" : "2012-09-11 05:52:23 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245397337533472768",
  "geo" : { },
  "id_str" : "245397872491765760",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox haha seriously. Although we had similar issues (small apt, 8-9 hrs away) we made it work and had a walker sometimes.",
  "id" : 245397872491765760,
  "in_reply_to_status_id" : 245397337533472768,
  "created_at" : "2012-09-11 05:46:26 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245397025212993536",
  "geo" : { },
  "id_str" : "245397239797780480",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck ha, let\u2019s trade for a day ;) definitely understand though.",
  "id" : 245397239797780480,
  "in_reply_to_status_id" : 245397025212993536,
  "created_at" : "2012-09-11 05:43:55 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245396570487521280",
  "geo" : { },
  "id_str" : "245396810603048960",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck I mean I get it\u2026but in no way can that be compared to a dog.",
  "id" : 245396810603048960,
  "in_reply_to_status_id" : 245396570487521280,
  "created_at" : "2012-09-11 05:42:13 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/ikmH7yM5",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dogs\/comments\/znvkb\/bad_6_mo_old_husky\/",
      "display_url" : "reddit.com\/r\/dogs\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245395522804936705",
  "text" : "Husky posts on Reddit like this one are almost on a weekly basis. Don\u2019t people research this? Holy crap. http:\/\/t.co\/ikmH7yM5",
  "id" : 245395522804936705,
  "created_at" : "2012-09-11 05:37:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/rdehGgyC",
      "expanded_url" : "https:\/\/github.com\/glucero\/zelda\/blob\/master\/zelda_overworld_theme.rb#L343-484",
      "display_url" : "github.com\/glucero\/zelda\/\u2026"
    }, {
      "indices" : [ 77, 98 ],
      "url" : "https:\/\/t.co\/4vpNhkri",
      "expanded_url" : "https:\/\/github.com\/glucero\/zelda\/raw\/master\/zelda_overworld_theme.mp3",
      "display_url" : "github.com\/glucero\/zelda\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245383820096983040",
  "text" : "Really neat, Zelda overworld theme generated via Ruby: https:\/\/t.co\/rdehGgyC https:\/\/t.co\/4vpNhkri",
  "id" : 245383820096983040,
  "created_at" : "2012-09-11 04:50:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James \u26F5\uFE0F Harton",
      "screen_name" : "jamesotron",
      "indices" : [ 0, 11 ],
      "id_str" : "5978432",
      "id" : 5978432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245381011746213888",
  "geo" : { },
  "id_str" : "245381696499896320",
  "in_reply_to_user_id" : 5978432,
  "text" : "@jamesotron yeah, total rage here. my husky is only 50 lbs. it's terrifying and sad that the dog is 77 lbs.",
  "id" : 245381696499896320,
  "in_reply_to_status_id" : 245381011746213888,
  "created_at" : "2012-09-11 04:42:10 +0000",
  "in_reply_to_screen_name" : "jamesotron",
  "in_reply_to_user_id_str" : "5978432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245379300096884736",
  "geo" : { },
  "id_str" : "245380417878892544",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft holy shit. I hate those dog owners &gt;:[",
  "id" : 245380417878892544,
  "in_reply_to_status_id" : 245379300096884736,
  "created_at" : "2012-09-11 04:37:05 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 0, 11 ],
      "id_str" : "56423575",
      "id" : 56423575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245375728693153792",
  "geo" : { },
  "id_str" : "245379927430545410",
  "in_reply_to_user_id" : 56423575,
  "text" : "@luisjoseve geez\u2026why not fly or Amtrak it?",
  "id" : 245379927430545410,
  "in_reply_to_status_id" : 245375728693153792,
  "created_at" : "2012-09-11 04:35:08 +0000",
  "in_reply_to_screen_name" : "luisjoseve",
  "in_reply_to_user_id_str" : "56423575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 11, 21 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245372492481433600",
  "text" : "Looks like @aquaranto just discovered Sgt. Frog on Netflix. She's dying of cuteness already and the opening credits aren't even over.",
  "id" : 245372492481433600,
  "created_at" : "2012-09-11 04:05:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    }, {
      "name" : "Garrett Murphey",
      "screen_name" : "gmurphey",
      "indices" : [ 117, 126 ],
      "id_str" : "822220",
      "id" : 822220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245358524572504065",
  "geo" : { },
  "id_str" : "245358763853357056",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal yeah, i think the @javascriptclub should be revived! perhaps a rebrand to buffalo.js would be in order. \/cc @gmurphey @billyist",
  "id" : 245358763853357056,
  "in_reply_to_status_id" : 245358524572504065,
  "created_at" : "2012-09-11 03:11:02 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NextPlex",
      "screen_name" : "nplex",
      "indices" : [ 3, 9 ],
      "id_str" : "534757903",
      "id" : 534757903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 35, 43 ]
    }, {
      "text" : "tech",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/1YvZ2iyo",
      "expanded_url" : "http:\/\/bit.ly\/P8TBg0",
      "display_url" : "bit.ly\/P8TBg0"
    } ]
  },
  "geo" : { },
  "id_str" : "245357910585135104",
  "text" : "RT @nplex: So impressed by all the #buffalo #tech scene has going on http:\/\/t.co\/1YvZ2iyo Their calendar looks like it belongs to a much ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 24, 32 ]
      }, {
        "text" : "tech",
        "indices" : [ 33, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/1YvZ2iyo",
        "expanded_url" : "http:\/\/bit.ly\/P8TBg0",
        "display_url" : "bit.ly\/P8TBg0"
      } ]
    },
    "geo" : { },
    "id_str" : "245348526681370625",
    "text" : "So impressed by all the #buffalo #tech scene has going on http:\/\/t.co\/1YvZ2iyo Their calendar looks like it belongs to a much bigger city",
    "id" : 245348526681370625,
    "created_at" : "2012-09-11 02:30:21 +0000",
    "user" : {
      "name" : "NextPlex",
      "screen_name" : "nplex",
      "protected" : false,
      "id_str" : "534757903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1940808786\/np_twit_normal.png",
      "id" : 534757903,
      "verified" : false
    }
  },
  "id" : 245357910585135104,
  "created_at" : "2012-09-11 03:07:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245355577633554432",
  "geo" : { },
  "id_str" : "245357482355085312",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal ha, thanks dude! Also, nice handle.",
  "id" : 245357482355085312,
  "in_reply_to_status_id" : 245355577633554432,
  "created_at" : "2012-09-11 03:05:56 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245355280601341953",
  "geo" : { },
  "id_str" : "245357120915136513",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel :(",
  "id" : 245357120915136513,
  "in_reply_to_status_id" : 245355280601341953,
  "created_at" : "2012-09-11 03:04:30 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245341929112485888",
  "geo" : { },
  "id_str" : "245343372326359042",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda better than no VCS\u2026net gains either way",
  "id" : 245343372326359042,
  "in_reply_to_status_id" : 245341929112485888,
  "created_at" : "2012-09-11 02:09:52 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245328005629616128",
  "geo" : { },
  "id_str" : "245330480306733058",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel \u2026why?",
  "id" : 245330480306733058,
  "in_reply_to_status_id" : 245328005629616128,
  "created_at" : "2012-09-11 01:18:39 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 3, 15 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245330330377154560",
  "text" : "RT @therealadam: Wake me up when I can play World of Warcraft as a French Bulldog.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245329164431921152",
    "text" : "Wake me up when I can play World of Warcraft as a French Bulldog.",
    "id" : 245329164431921152,
    "created_at" : "2012-09-11 01:13:25 +0000",
    "user" : {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "protected" : false,
      "id_str" : "12661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1411347027\/jeff_casimir_headshot_normal.jpeg",
      "id" : 12661,
      "verified" : false
    }
  },
  "id" : 245330330377154560,
  "created_at" : "2012-09-11 01:18:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245327814121897985",
  "text" : "Learned the hard way Ctrl Option Cmd 8 doesn\u2019t work on Mountain Lion :(",
  "id" : 245327814121897985,
  "created_at" : "2012-09-11 01:08:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245316164765487104",
  "text" : "RT @moonpolysoft: Full Stalk Enveloper",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245314483420008448",
    "text" : "Full Stalk Enveloper",
    "id" : 245314483420008448,
    "created_at" : "2012-09-11 00:15:05 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 245316164765487104,
  "created_at" : "2012-09-11 00:21:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 3, 13 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 40, 48 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/k91Tgcbx",
      "expanded_url" : "http:\/\/yfrog.com\/eskj4vwj",
      "display_url" : "yfrog.com\/eskj4vwj"
    } ]
  },
  "geo" : { },
  "id_str" : "245316052848889856",
  "text" : "RT @magnachef: Great turnout tonight at @WNYRuby http:\/\/t.co\/k91Tgcbx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 25, 33 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/k91Tgcbx",
        "expanded_url" : "http:\/\/yfrog.com\/eskj4vwj",
        "display_url" : "yfrog.com\/eskj4vwj"
      } ]
    },
    "geo" : { },
    "id_str" : "245313847613853698",
    "text" : "Great turnout tonight at @WNYRuby http:\/\/t.co\/k91Tgcbx",
    "id" : 245313847613853698,
    "created_at" : "2012-09-11 00:12:33 +0000",
    "user" : {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "protected" : false,
      "id_str" : "23703410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557740024620261376\/4Td91096_normal.jpeg",
      "id" : 23703410,
      "verified" : false
    }
  },
  "id" : 245316052848889856,
  "created_at" : "2012-09-11 00:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 15, 25 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/245312615604178944\/photo\/1",
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/ee39TgxU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2eGhjCCUAAYebY.jpg",
      "id_str" : "245312615612567552",
      "id" : 245312615612567552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2eGhjCCUAAYebY.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ee39TgxU"
    } ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245312615604178944",
  "text" : "#WNYRuby time! @aquaranto is up first! http:\/\/t.co\/ee39TgxU",
  "id" : 245312615604178944,
  "created_at" : "2012-09-11 00:07:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245282541144260608",
  "geo" : { },
  "id_str" : "245282600623693825",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle bicycler.",
  "id" : 245282600623693825,
  "in_reply_to_status_id" : 245282541144260608,
  "created_at" : "2012-09-10 22:08:23 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245281900963430402",
  "text" : "Saw a biker literally trapped under a front wheel of a car in the West Ferry\/Richmond circle. #Buffalo drivers please be aware of us :(",
  "id" : 245281900963430402,
  "created_at" : "2012-09-10 22:05:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Iry",
      "screen_name" : "jamesiry",
      "indices" : [ 3, 12 ],
      "id_str" : "19044984",
      "id" : 19044984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245223468919033856",
  "text" : "RT @jamesiry: Wanted: full stack developer. Must know JS, CSS, HTML, HTTP, SQL, Ruby, DNS, BGP, TCP\/IP, 802.11, C, x86 asm, Intel microc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245187954027409408",
    "text" : "Wanted: full stack developer. Must know JS, CSS, HTML, HTTP, SQL, Ruby, DNS, BGP, TCP\/IP, 802.11, C, x86 asm, Intel microcode, and Verilog.",
    "id" : 245187954027409408,
    "created_at" : "2012-09-10 15:52:18 +0000",
    "user" : {
      "name" : "James Iry",
      "screen_name" : "jamesiry",
      "protected" : false,
      "id_str" : "19044984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/82407426\/Teotihuacan_62AF_normal.jpg",
      "id" : 19044984,
      "verified" : false
    }
  },
  "id" : 245223468919033856,
  "created_at" : "2012-09-10 18:13:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 136 ],
      "url" : "https:\/\/t.co\/AZNcaaAH",
      "expanded_url" : "https:\/\/github.com\/qrush\/motion-settings-bundle",
      "display_url" : "github.com\/qrush\/motion-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245209535013326849",
  "text" : "Very rough cut! Announcing motion-settings-bundle, create a Settings.bundle for your RubyMotion app without XCode. https:\/\/t.co\/AZNcaaAH",
  "id" : 245209535013326849,
  "created_at" : "2012-09-10 17:18:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/LGstzVPm",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3249-the-unix-system-making-computers",
      "display_url" : "37signals.com\/svn\/posts\/3249\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245180839049166848",
  "text" : "Watch some of the fathers of UNIX talk about what UNIX is from Bell Labs: http:\/\/t.co\/LGstzVPm",
  "id" : 245180839049166848,
  "created_at" : "2012-09-10 15:24:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 0, 13 ],
      "id_str" : "101859945",
      "id" : 101859945
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 14, 22 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 39, 49 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245175508881530881",
  "geo" : { },
  "id_str" : "245175691082100736",
  "in_reply_to_user_id" : 101859945,
  "text" : "@nickdirienzo @wnyruby Great! heads up @aspleenic ...",
  "id" : 245175691082100736,
  "in_reply_to_status_id" : 245175508881530881,
  "created_at" : "2012-09-10 15:03:34 +0000",
  "in_reply_to_screen_name" : "nickdirienzo",
  "in_reply_to_user_id_str" : "101859945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 17, 27 ],
      "id_str" : "18047782",
      "id" : 18047782
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 39, 50 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/245174915563663361\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/UTFgeeys",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2cJSWcCMAABJw3.png",
      "id_str" : "245174915580440576",
      "id" : 245174915580440576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2cJSWcCMAABJw3.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UTFgeeys"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245174915563663361",
  "text" : "Kind of surreal, @p_elliott's face and @kevinpurdy's article on ITWorld at the same time today. http:\/\/t.co\/UTFgeeys",
  "id" : 245174915563663361,
  "created_at" : "2012-09-10 15:00:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244930067820584960",
  "text" : "Homemade bacon BBQ sauce, a huge pork shoulder slow cooking for under $10, and soon some more board games. Awesome weekend is awesome.",
  "id" : 244930067820584960,
  "created_at" : "2012-09-09 22:47:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 3, 14 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244898291857367040",
  "text" : "RT @joshsusser: I know we developers like to think of programming as art, but drawing a picture just feels so different from writing code.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "244894529075961856",
    "text" : "I know we developers like to think of programming as art, but drawing a picture just feels so different from writing code.",
    "id" : 244894529075961856,
    "created_at" : "2012-09-09 20:26:20 +0000",
    "user" : {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "protected" : false,
      "id_str" : "35954885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502547892230316032\/njGJleCw_normal.png",
      "id" : 35954885,
      "verified" : false
    }
  },
  "id" : 244898291857367040,
  "created_at" : "2012-09-09 20:41:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244894529075961856",
  "geo" : { },
  "id_str" : "244898250635763712",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser i really dislike the \u201Ccode is art\u201D mentality. Art doesn\u2019t have maintenance costs, constant erosion, or communication woes",
  "id" : 244898250635763712,
  "in_reply_to_status_id" : 244894529075961856,
  "created_at" : "2012-09-09 20:41:07 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/AU7qExT6",
      "expanded_url" : "http:\/\/instagr.am\/p\/PXgR6js6m5\/",
      "display_url" : "instagr.am\/p\/PXgR6js6m5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8921506518, -78.894828558 ]
  },
  "id_str" : "244888658203779072",
  "text" : "Another crazy cloud day over the lake.  @ The Barkyard http:\/\/t.co\/AU7qExT6",
  "id" : 244888658203779072,
  "created_at" : "2012-09-09 20:03:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244856040838021121",
  "text" : "When does the NHL season start?",
  "id" : 244856040838021121,
  "created_at" : "2012-09-09 17:53:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 3, 10 ],
      "id_str" : "750823",
      "id" : 750823
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244846480244998144",
  "text" : "RT @maddox: @qrush oh so you already heard about mobile phones and light beer?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "244819880023584769",
    "geo" : { },
    "id_str" : "244836561429098496",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush oh so you already heard about mobile phones and light beer?",
    "id" : 244836561429098496,
    "in_reply_to_status_id" : 244819880023584769,
    "created_at" : "2012-09-09 16:35:59 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "protected" : false,
      "id_str" : "750823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554645994860584960\/dL3zfZ8C_normal.png",
      "id" : 750823,
      "verified" : false
    }
  },
  "id" : 244846480244998144,
  "created_at" : "2012-09-09 17:15:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244819880023584769",
  "text" : "Haven\u2019t watched broadcast TV since the Buffalo sports season ended. No surprise: commercials still suck.",
  "id" : 244819880023584769,
  "created_at" : "2012-09-09 15:29:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244689225432301568",
  "text" : "I miss the responsiveness and just pure simplicity of 8\/16 bit games. Sad that we can\u2019t do better with current technology.",
  "id" : 244689225432301568,
  "created_at" : "2012-09-09 06:50:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 87, 94 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244688788658454528",
  "text" : "Hooked up the SNES again tonight for some Tetris Attack. Actually won some games since @jyurek wasn\u2019t playing!",
  "id" : 244688788658454528,
  "created_at" : "2012-09-09 06:48:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244638479642943488",
  "geo" : { },
  "id_str" : "244688200092774400",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc we are actually making this tomorrow! Stupid cheap and makes a ton of food.",
  "id" : 244688200092774400,
  "in_reply_to_status_id" : 244638479642943488,
  "created_at" : "2012-09-09 06:46:27 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/q83BCiIk",
      "expanded_url" : "http:\/\/instagr.am\/p\/PV3nlhs6js\/",
      "display_url" : "instagr.am\/p\/PV3nlhs6js\/"
    } ]
  },
  "geo" : { },
  "id_str" : "244658529913421824",
  "text" : "Elementals, deceased. http:\/\/t.co\/q83BCiIk",
  "id" : 244658529913421824,
  "created_at" : "2012-09-09 04:48:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/oeA7ke4l",
      "expanded_url" : "http:\/\/instagr.am\/p\/PV0TLPM6hB\/",
      "display_url" : "instagr.am\/p\/PV0TLPM6hB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "244651139751112704",
  "text" : "Descent. Lots of big monsters! http:\/\/t.co\/oeA7ke4l",
  "id" : 244651139751112704,
  "created_at" : "2012-09-09 04:19:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/yc38yMpK",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "244556344173150208",
  "geo" : { },
  "id_str" : "244556916695629824",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer lots of info at http:\/\/t.co\/yc38yMpK feel free to shoot me an email!",
  "id" : 244556916695629824,
  "in_reply_to_status_id" : 244556344173150208,
  "created_at" : "2012-09-08 22:04:47 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Nyman",
      "screen_name" : "tnm",
      "indices" : [ 0, 4 ],
      "id_str" : "77009486",
      "id" : 77009486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244553963297443840",
  "geo" : { },
  "id_str" : "244554349995511808",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm Lake Erie has its moments :)",
  "id" : 244554349995511808,
  "in_reply_to_status_id" : 244553963297443840,
  "created_at" : "2012-09-08 21:54:35 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244554199747145729",
  "text" : "RT @rjs: The decisions you make about \"what matters\" in a product, a feature, a team,  a company, are the most important decisions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "244552613486534656",
    "text" : "The decisions you make about \"what matters\" in a product, a feature, a team,  a company, are the most important decisions.",
    "id" : 244552613486534656,
    "created_at" : "2012-09-08 21:47:41 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 244554199747145729,
  "created_at" : "2012-09-08 21:53:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/qD65EsSN",
      "expanded_url" : "http:\/\/instagr.am\/p\/PVH8vbM6o0\/",
      "display_url" : "instagr.am\/p\/PVH8vbM6o0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "244553689099018241",
  "text" : "Incoming! http:\/\/t.co\/qD65EsSN",
  "id" : 244553689099018241,
  "created_at" : "2012-09-08 21:51:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/R1IXRp8H",
      "expanded_url" : "http:\/\/instagr.am\/p\/PVHXOWs6oK\/",
      "display_url" : "instagr.am\/p\/PVHXOWs6oK\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8921506518, -78.894828558 ]
  },
  "id_str" : "244552279003369472",
  "text" : "Deke!  @ The Barkyard http:\/\/t.co\/R1IXRp8H",
  "id" : 244552279003369472,
  "created_at" : "2012-09-08 21:46:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244524748212678656",
  "geo" : { },
  "id_str" : "244536356783665152",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule Watching K live code and explaining pipes is fantastic.",
  "id" : 244536356783665152,
  "in_reply_to_status_id" : 244524748212678656,
  "created_at" : "2012-09-08 20:43:05 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 3, 11 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/rYG7iNAv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tc4ROCJYbm0",
      "display_url" : "youtube.com\/watch?v=tc4ROC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "244534214345752577",
  "text" : "RT @bascule: The Unix Operating System: http:\/\/t.co\/rYG7iNAv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/rYG7iNAv",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tc4ROCJYbm0",
        "display_url" : "youtube.com\/watch?v=tc4ROC\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "244524748212678656",
    "text" : "The Unix Operating System: http:\/\/t.co\/rYG7iNAv",
    "id" : 244524748212678656,
    "created_at" : "2012-09-08 19:56:57 +0000",
    "user" : {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "protected" : false,
      "id_str" : "6083342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450061818606522368\/pjDTHFB9_normal.jpeg",
      "id" : 6083342,
      "verified" : false
    }
  },
  "id" : 244534214345752577,
  "created_at" : "2012-09-08 20:34:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/sdRgVX7W",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/obama-help-us-destroy-jesus-and-start-a-new-age-of,29478\/",
      "display_url" : "theonion.com\/articles\/obama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "244517442481684480",
  "text" : "\"as thousands in attendance moaned in compliance and gyrated their hips and groins in a lascivious dance\" http:\/\/t.co\/sdRgVX7W",
  "id" : 244517442481684480,
  "created_at" : "2012-09-08 19:27:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/CAtG2IOt",
      "expanded_url" : "http:\/\/blogs.ocweekly.com\/stickaforkinit\/candy-corn-oreo.jpeg",
      "display_url" : "blogs.ocweekly.com\/stickaforkinit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "244449269199810561",
  "text" : "Candy Corn Oreo: This is a real thing. http:\/\/t.co\/CAtG2IOt",
  "id" : 244449269199810561,
  "created_at" : "2012-09-08 14:57:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Newland",
      "screen_name" : "onewland",
      "indices" : [ 3, 12 ],
      "id_str" : "22040390",
      "id" : 22040390
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/q4VEWm4z",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/mensrights",
      "display_url" : "reddit.com\/r\/mensrights"
    } ]
  },
  "geo" : { },
  "id_str" : "244447658201206785",
  "text" : "RT @onewland: @qrush This is still a thing http:\/\/t.co\/q4VEWm4z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/q4VEWm4z",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/mensrights",
        "display_url" : "reddit.com\/r\/mensrights"
      } ]
    },
    "in_reply_to_status_id_str" : "244446387956219904",
    "geo" : { },
    "id_str" : "244447259369013248",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush This is still a thing http:\/\/t.co\/q4VEWm4z",
    "id" : 244447259369013248,
    "in_reply_to_status_id" : 244446387956219904,
    "created_at" : "2012-09-08 14:49:02 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Oliver Newland",
      "screen_name" : "onewland",
      "protected" : false,
      "id_str" : "22040390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381083562\/a2fb7a836995a86932f5ce41190da640_normal.jpeg",
      "id" : 22040390,
      "verified" : false
    }
  },
  "id" : 244447658201206785,
  "created_at" : "2012-09-08 14:50:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/IbvLzbSk",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/popping",
      "display_url" : "reddit.com\/r\/popping"
    } ]
  },
  "geo" : { },
  "id_str" : "244447274674049024",
  "text" : "NOPE NOPE NOPE NOPE http:\/\/t.co\/IbvLzbSk \"Pictures, videos, and stories about cysts and pimples.\"",
  "id" : 244447274674049024,
  "created_at" : "2012-09-08 14:49:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/u4zXCZTP",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/SquaredCircle\/",
      "display_url" : "reddit.com\/r\/SquaredCircl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "244446387956219904",
  "text" : "This is still a thing? http:\/\/t.co\/u4zXCZTP",
  "id" : 244446387956219904,
  "created_at" : "2012-09-08 14:45:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 3, 10 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244439584920985600",
  "text" : "RT @jayroh: I have this weird sense of guilt for working in an industry, in this day and age, where there are more jobs than people. We' ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "244427316875378689",
    "text" : "I have this weird sense of guilt for working in an industry, in this day and age, where there are more jobs than people. We're lucky.",
    "id" : 244427316875378689,
    "created_at" : "2012-09-08 13:29:48 +0000",
    "user" : {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "protected" : false,
      "id_str" : "14114222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491956337190793217\/jVkBxVJT_normal.jpeg",
      "id" : 14114222,
      "verified" : false
    }
  },
  "id" : 244439584920985600,
  "created_at" : "2012-09-08 14:18:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/GdalKcxG",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/needadvice\/comments\/xywy9\/23year_old_genius_seeks_advice_on_forced_social",
      "display_url" : "reddit.com\/r\/needadvice\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "244333901437353984",
  "text" : "RT @moonpolysoft: Welp. http:\/\/t.co\/GdalKcxG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 26 ],
        "url" : "http:\/\/t.co\/GdalKcxG",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/needadvice\/comments\/xywy9\/23year_old_genius_seeks_advice_on_forced_social",
        "display_url" : "reddit.com\/r\/needadvice\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "244329086774804480",
    "text" : "Welp. http:\/\/t.co\/GdalKcxG",
    "id" : 244329086774804480,
    "created_at" : "2012-09-08 06:59:28 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 244333901437353984,
  "created_at" : "2012-09-08 07:18:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244269939278622720",
  "geo" : { },
  "id_str" : "244270826894000128",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm terrible reason. Let it run over the weekend?",
  "id" : 244270826894000128,
  "in_reply_to_status_id" : 244269939278622720,
  "created_at" : "2012-09-08 03:07:58 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244266272227987456",
  "geo" : { },
  "id_str" : "244269852653674496",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm just use it now. Seriously.",
  "id" : 244269852653674496,
  "in_reply_to_status_id" : 244266272227987456,
  "created_at" : "2012-09-08 03:04:05 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244265700275920898",
  "geo" : { },
  "id_str" : "244266221426581505",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm git is wonderful. Just stop using svn, use git-svn.",
  "id" : 244266221426581505,
  "in_reply_to_status_id" : 244265700275920898,
  "created_at" : "2012-09-08 02:49:40 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Kpp3RvtJ",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Daniel_Weinreb",
      "display_url" : "en.m.wikipedia.org\/wiki\/Daniel_We\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "244169306924011520",
  "text" : "Heard that Dan Weinreb passed away. CS is a field where those that have shaped history are still around. Cherish them. http:\/\/t.co\/Kpp3RvtJ",
  "id" : 244169306924011520,
  "created_at" : "2012-09-07 20:24:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knight Slider",
      "screen_name" : "TheKnightSlider",
      "indices" : [ 36, 52 ],
      "id_str" : "599824167",
      "id" : 599824167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/EYaWwERQ",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "geo" : { },
  "id_str" : "244152979010236418",
  "text" : "Another new food truck in Buffalo:  @TheKnightSlider Time to update http:\/\/t.co\/EYaWwERQ !",
  "id" : 244152979010236418,
  "created_at" : "2012-09-07 19:19:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i aint even Bill Nye",
      "screen_name" : "Bill_Nye_tho",
      "indices" : [ 3, 16 ],
      "id_str" : "700374013",
      "id" : 700374013
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Bill_Nye_tho\/status\/225294572824166400\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/zvF7Xnzc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyBoOGdCAAA0PCT.jpg",
      "id_str" : "225294572828360704",
      "id" : 225294572828360704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyBoOGdCAAA0PCT.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zvF7Xnzc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244146471174279168",
  "text" : "RT @Bill_Nye_tho: it is goddamn bananas how much bullshit there is in the ocean look at this fish. lmao god damn http:\/\/t.co\/zvF7Xnzc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Bill_Nye_tho\/status\/225294572824166400\/photo\/1",
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/zvF7Xnzc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AyBoOGdCAAA0PCT.jpg",
        "id_str" : "225294572828360704",
        "id" : 225294572828360704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyBoOGdCAAA0PCT.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zvF7Xnzc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225294572824166400",
    "text" : "it is goddamn bananas how much bullshit there is in the ocean look at this fish. lmao god damn http:\/\/t.co\/zvF7Xnzc",
    "id" : 225294572824166400,
    "created_at" : "2012-07-17 18:23:07 +0000",
    "user" : {
      "name" : "i aint even Bill Nye",
      "screen_name" : "Bill_Nye_tho",
      "protected" : false,
      "id_str" : "700374013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2404907709\/lonbhslatqgxk1p9z26p_normal.png",
      "id" : 700374013,
      "verified" : false
    }
  },
  "id" : 244146471174279168,
  "created_at" : "2012-09-07 18:53:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244144344825741313",
  "geo" : { },
  "id_str" : "244144810963910656",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden with great gifs comes great responsibility",
  "id" : 244144810963910656,
  "in_reply_to_status_id" : 244144344825741313,
  "created_at" : "2012-09-07 18:47:13 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 43, 49 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244144584152735744",
  "text" : "RT @ashedryden: Anyone else convinced that @qrush walks down all of those dirty dark alleys on the internet that none of the rest of us  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 27, 33 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "244144344825741313",
    "text" : "Anyone else convinced that @qrush walks down all of those dirty dark alleys on the internet that none of the rest of us are brave enough to?",
    "id" : 244144344825741313,
    "created_at" : "2012-09-07 18:45:22 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 244144584152735744,
  "created_at" : "2012-09-07 18:46:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/G7HU68xO",
      "expanded_url" : "http:\/\/www.fiftyshadesgenerator.com\/",
      "display_url" : "fiftyshadesgenerator.com"
    } ]
  },
  "geo" : { },
  "id_str" : "244143552815312896",
  "text" : "Exactly what you think it is: http:\/\/t.co\/G7HU68xO",
  "id" : 244143552815312896,
  "created_at" : "2012-09-07 18:42:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig C. Chapman",
      "screen_name" : "craigcchapman",
      "indices" : [ 0, 14 ],
      "id_str" : "16787318",
      "id" : 16787318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244122917741412353",
  "geo" : { },
  "id_str" : "244123906649247744",
  "in_reply_to_user_id" : 16787318,
  "text" : "@craigcchapman we're still exploring it. not happy with anything so far.",
  "id" : 244123906649247744,
  "in_reply_to_status_id" : 244122917741412353,
  "created_at" : "2012-09-07 17:24:09 +0000",
  "in_reply_to_screen_name" : "craigcchapman",
  "in_reply_to_user_id_str" : "16787318",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 0, 8 ],
      "id_str" : "270917610",
      "id" : 270917610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244058710886998016",
  "geo" : { },
  "id_str" : "244063520361172993",
  "in_reply_to_user_id" : 270917610,
  "text" : "@alarowe merry Christmas!",
  "id" : 244063520361172993,
  "in_reply_to_status_id" : 244058710886998016,
  "created_at" : "2012-09-07 13:24:12 +0000",
  "in_reply_to_screen_name" : "alarowe",
  "in_reply_to_user_id_str" : "270917610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/LXmU2JHo",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_lhq893s8c11qhixryo1_500.jpg",
      "display_url" : "25.media.tumblr.com\/tumblr_lhq893s\u2026"
    }, {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/scZYdmgz",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_lhq8ayhkwV1qhixryo1_500.jpg",
      "display_url" : "25.media.tumblr.com\/tumblr_lhq8ayh\u2026"
    }, {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/2IKVOMUA",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/tumblr_lhq8crk0K11qhixryo1_500.png",
      "display_url" : "24.media.tumblr.com\/tumblr_lhq8crk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243925766952321024",
  "text" : "Current status: http:\/\/t.co\/LXmU2JHo http:\/\/t.co\/scZYdmgz http:\/\/t.co\/2IKVOMUA",
  "id" : 243925766952321024,
  "created_at" : "2012-09-07 04:16:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/lZDNYpWE",
      "expanded_url" : "http:\/\/i.imgur.com\/BRRI8.png",
      "display_url" : "i.imgur.com\/BRRI8.png"
    } ]
  },
  "geo" : { },
  "id_str" : "243920321097371648",
  "text" : "Somehow, I didn't make this ragetoon. http:\/\/t.co\/lZDNYpWE",
  "id" : 243920321097371648,
  "created_at" : "2012-09-07 03:55:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 26, 35 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/243905304511803392\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/U4gM6qxG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2KGlQqCcAAcLKa.png",
      "id_str" : "243905304515997696",
      "id" : 243905304515997696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2KGlQqCcAAcLKa.png",
      "sizes" : [ {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 860,
        "resize" : "fit",
        "w" : 1266
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/U4gM6qxG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243905304511803392",
  "text" : "Glorious hangout with the @rubygems team was glorious! Glad to hash some stuff out and see everyone. http:\/\/t.co\/U4gM6qxG",
  "id" : 243905304511803392,
  "created_at" : "2012-09-07 02:55:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/OWid4LcA",
      "expanded_url" : "http:\/\/www.people.com\/people\/article\/0,,20625962,00.html",
      "display_url" : "people.com\/people\/article\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243871446164713472",
  "text" : "He's made a huge mistake. http:\/\/t.co\/OWid4LcA",
  "id" : 243871446164713472,
  "created_at" : "2012-09-07 00:40:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/1H0e8mrV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nkskuSXqUD0",
      "display_url" : "youtube.com\/watch?v=nkskuS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243768913945579520",
  "text" : "Current status: http:\/\/t.co\/1H0e8mrV",
  "id" : 243768913945579520,
  "created_at" : "2012-09-06 17:53:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243766691346137088",
  "text" : "I guess this is my punishment for reading TechCrunch.",
  "id" : 243766691346137088,
  "created_at" : "2012-09-06 17:44:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243766368569266176",
  "text" : "\"...Y Combinator backed company Bushido\u2019s pivot is less drastic than Siddh\u0101rtha\u2019s...\" Really, TechCrunch?",
  "id" : 243766368569266176,
  "created_at" : "2012-09-06 17:43:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Crocker",
      "screen_name" : "railsjedi",
      "indices" : [ 0, 10 ],
      "id_str" : "1453071312",
      "id" : 1453071312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243744698844471298",
  "geo" : { },
  "id_str" : "243744900699521024",
  "in_reply_to_user_id" : 18008485,
  "text" : "@railsjedi definitely!",
  "id" : 243744900699521024,
  "in_reply_to_status_id" : 243744698844471298,
  "created_at" : "2012-09-06 16:18:07 +0000",
  "in_reply_to_screen_name" : "jacquescrocker",
  "in_reply_to_user_id_str" : "18008485",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243741534451814400",
  "text" : "Absolutely love seeing a full house @CoworkBuffalo. Really excited that we've come this far, and hoping we can keep it going!",
  "id" : 243741534451814400,
  "created_at" : "2012-09-06 16:04:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243734847477145600",
  "geo" : { },
  "id_str" : "243737255204761600",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky Mythical Man Month is a great book.",
  "id" : 243737255204761600,
  "in_reply_to_status_id" : 243734847477145600,
  "created_at" : "2012-09-06 15:47:44 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243735370016124928",
  "text" : "Really? You named your app Tampon? That little voice in your head just kept saying \"Nah, that will be fine. Let's get a logo for it too!\"",
  "id" : 243735370016124928,
  "created_at" : "2012-09-06 15:40:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WindyCityRails",
      "screen_name" : "WindyCityRails",
      "indices" : [ 4, 19 ],
      "id_str" : "16104710",
      "id" : 16104710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "windycityrails",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243723806013796352",
  "text" : "Hey @windycityrails is there any streaming of the talks? #windycityrails",
  "id" : 243723806013796352,
  "created_at" : "2012-09-06 14:54:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243718317746032640",
  "text" : "My Ballmer peak project last night: brew install mpg123; gem install gsay; gsay \"Speak like a robot\"",
  "id" : 243718317746032640,
  "created_at" : "2012-09-06 14:32:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian del vecchio",
      "screen_name" : "Hybernaut",
      "indices" : [ 0, 10 ],
      "id_str" : "4678",
      "id" : 4678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243702306686767104",
  "geo" : { },
  "id_str" : "243703664630435841",
  "in_reply_to_user_id" : 4678,
  "text" : "@Hybernaut RHOMBUS!",
  "id" : 243703664630435841,
  "in_reply_to_status_id" : 243702306686767104,
  "created_at" : "2012-09-06 13:34:16 +0000",
  "in_reply_to_screen_name" : "Hybernaut",
  "in_reply_to_user_id_str" : "4678",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Woodcox",
      "screen_name" : "cwoodcox",
      "indices" : [ 0, 9 ],
      "id_str" : "15893003",
      "id" : 15893003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243596148093374464",
  "geo" : { },
  "id_str" : "243597589612740608",
  "in_reply_to_user_id" : 15893003,
  "text" : "@cwoodcox there is no json in this gem. Bad gemset on your end?",
  "id" : 243597589612740608,
  "in_reply_to_status_id" : 243596148093374464,
  "created_at" : "2012-09-06 06:32:45 +0000",
  "in_reply_to_screen_name" : "cwoodcox",
  "in_reply_to_user_id_str" : "15893003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/LJ2XjRUw",
      "expanded_url" : "http:\/\/rubygems.org\/gems\/gsay",
      "display_url" : "rubygems.org\/gems\/gsay"
    } ]
  },
  "geo" : { },
  "id_str" : "243595994854473728",
  "text" : "gsay \"install me again for a big speed improvement\" http:\/\/t.co\/LJ2XjRUw",
  "id" : 243595994854473728,
  "created_at" : "2012-09-06 06:26:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 65 ],
      "url" : "https:\/\/t.co\/fcVqHFaa",
      "expanded_url" : "https:\/\/github.com\/qrush\/gsay#some-good-ones-to-try",
      "display_url" : "github.com\/qrush\/gsay#som\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243594199998533632",
  "text" : "Last one! Rocket man. Too long for a tweet. https:\/\/t.co\/fcVqHFaa",
  "id" : 243594199998533632,
  "created_at" : "2012-09-06 06:19:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243592688392343552",
  "text" : "gsay \"i just wanna tell you how i am feeling gotta make you understand never gonna give you up never gonna let you down\"",
  "id" : 243592688392343552,
  "created_at" : "2012-09-06 06:13:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/O7AkyMgD",
      "expanded_url" : "http:\/\/pics.blameitonthevoices.com\/032010\/trololo_lyrics.jpg",
      "display_url" : "pics.blameitonthevoices.com\/032010\/trololo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243592099939885058",
  "text" : "Current status: http:\/\/t.co\/O7AkyMgD",
  "id" : 243592099939885058,
  "created_at" : "2012-09-06 06:10:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243591228623581184",
  "text" : "gsay \"party rock is in the house tonight everybody just have a good time and we gonna make you lose your mind\"",
  "id" : 243591228623581184,
  "created_at" : "2012-09-06 06:07:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243590308569423872",
  "geo" : { },
  "id_str" : "243590538090131456",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen gsay \"poop robot\"",
  "id" : 243590538090131456,
  "in_reply_to_status_id" : 243590308569423872,
  "created_at" : "2012-09-06 06:04:44 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243590485128646656",
  "text" : "gsay \"irony is wasted on the stupid\"",
  "id" : 243590485128646656,
  "created_at" : "2012-09-06 06:04:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243589061355380736",
  "geo" : { },
  "id_str" : "243589290989350912",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen PULL REQUESTS ACCEPTED",
  "id" : 243589290989350912,
  "in_reply_to_status_id" : 243589061355380736,
  "created_at" : "2012-09-06 05:59:47 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 63 ],
      "url" : "https:\/\/t.co\/hsKEwxJh",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/robot.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243588466816983040",
  "text" : "Related: GOOGLE SAYS ROBOT LIKE ZOIDBERG. https:\/\/t.co\/hsKEwxJh",
  "id" : 243588466816983040,
  "created_at" : "2012-09-06 05:56:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243588279562272768",
  "text" : "brew install mpg123; gem install gsay; gsay \"Speak like a fancy robot\"",
  "id" : 243588279562272768,
  "created_at" : "2012-09-06 05:55:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 21 ],
      "url" : "https:\/\/t.co\/2t7YJkj3",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/i.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    }, {
      "indices" : [ 22, 43 ],
      "url" : "https:\/\/t.co\/R9IrzBfb",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/need.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    }, {
      "indices" : [ 44, 65 ],
      "url" : "https:\/\/t.co\/IrbZs8NK",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/an.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    }, {
      "indices" : [ 66, 87 ],
      "url" : "https:\/\/t.co\/ymacXSx1",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/adult.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243580895666262016",
  "text" : "https:\/\/t.co\/2t7YJkj3 https:\/\/t.co\/R9IrzBfb https:\/\/t.co\/IrbZs8NK https:\/\/t.co\/ymacXSx1",
  "id" : 243580895666262016,
  "created_at" : "2012-09-06 05:26:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 21 ],
      "url" : "https:\/\/t.co\/zUvt2FVA",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/laughter.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243580764321619968",
  "text" : "https:\/\/t.co\/zUvt2FVA",
  "id" : 243580764321619968,
  "created_at" : "2012-09-06 05:25:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt culpepper",
      "screen_name" : "_mculp",
      "indices" : [ 0, 7 ],
      "id_str" : "21530821",
      "id" : 21530821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 29 ],
      "url" : "https:\/\/t.co\/IMcHZadi",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/hilarity.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "243579920389902336",
  "geo" : { },
  "id_str" : "243580670423732224",
  "in_reply_to_user_id" : 21530821,
  "text" : "@_mculp https:\/\/t.co\/IMcHZadi",
  "id" : 243580670423732224,
  "in_reply_to_status_id" : 243579920389902336,
  "created_at" : "2012-09-06 05:25:31 +0000",
  "in_reply_to_screen_name" : "_mculp",
  "in_reply_to_user_id_str" : "21530821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 37 ],
      "url" : "https:\/\/t.co\/ZIXXt42r",
      "expanded_url" : "https:\/\/ssl.gstatic.com\/dictionary\/static\/sounds\/de\/0\/nincompoop.mp3",
      "display_url" : "ssl.gstatic.com\/dictionary\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243579660330483712",
  "text" : "Current status: https:\/\/t.co\/ZIXXt42r",
  "id" : 243579660330483712,
  "created_at" : "2012-09-06 05:21:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243533253443723264",
  "geo" : { },
  "id_str" : "243533681048813569",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Hardcore Forking Action",
  "id" : 243533681048813569,
  "in_reply_to_status_id" : 243533253443723264,
  "created_at" : "2012-09-06 02:18:48 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243533621410004992",
  "text" : "RT @bquarant: The best reason to learn to program: Your own DNA is code; everything you are and have been are functions of the biologica ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "243533253443723264",
    "text" : "The best reason to learn to program: Your own DNA is code; everything you are and have been are functions of the biological kernel",
    "id" : 243533253443723264,
    "created_at" : "2012-09-06 02:17:06 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 243533621410004992,
  "created_at" : "2012-09-06 02:18:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hoskings",
      "screen_name" : "ben_h",
      "indices" : [ 0, 6 ],
      "id_str" : "8046732",
      "id" : 8046732
    }, {
      "name" : "babushka",
      "screen_name" : "babushka_app",
      "indices" : [ 7, 20 ],
      "id_str" : "77913677",
      "id" : 77913677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243509875336962049",
  "geo" : { },
  "id_str" : "243533202340315136",
  "in_reply_to_user_id" : 8046732,
  "text" : "@ben_h @babushka_app thanks...mostly a problem of free time to work on stuff",
  "id" : 243533202340315136,
  "in_reply_to_status_id" : 243509875336962049,
  "created_at" : "2012-09-06 02:16:54 +0000",
  "in_reply_to_screen_name" : "ben_h",
  "in_reply_to_user_id_str" : "8046732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Rg7muPWd",
      "expanded_url" : "http:\/\/instagr.am\/p\/PNoUZBs6v7\/",
      "display_url" : "instagr.am\/p\/PNoUZBs6v7\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8760072969, -78.8497520388 ]
  },
  "id_str" : "243498895752187904",
  "text" : "These guys are killing it.  @ Larkin Square http:\/\/t.co\/Rg7muPWd",
  "id" : 243498895752187904,
  "created_at" : "2012-09-06 00:00:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/cZovh4Ds",
      "expanded_url" : "http:\/\/instagr.am\/p\/PNhnnbM6r7\/",
      "display_url" : "instagr.am\/p\/PNhnnbM6r7\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8760072969, -78.8497520388 ]
  },
  "id_str" : "243484242678525954",
  "text" : "Aqueous has groupies and tapers already.  @ Larkin Square http:\/\/t.co\/cZovh4Ds",
  "id" : 243484242678525954,
  "created_at" : "2012-09-05 23:02:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 66, 78 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243471656750837761",
  "text" : "Pretty sure that several mic trees at a gig predicts awesomeness. @AqueousBand is up next!!",
  "id" : 243471656750837761,
  "created_at" : "2012-09-05 22:12:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243443941201047553",
  "geo" : { },
  "id_str" : "243456706036789249",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting the problem is more getting time free to work on stuff :(",
  "id" : 243456706036789249,
  "in_reply_to_status_id" : 243443941201047553,
  "created_at" : "2012-09-05 21:12:56 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/XljTOapl",
      "expanded_url" : "http:\/\/instagr.am\/p\/PNU_C_M6kB\/",
      "display_url" : "instagr.am\/p\/PNU_C_M6kB\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8760072969, -78.8497520388 ]
  },
  "id_str" : "243456430227730434",
  "text" : "Finally crossing @TheRoamingBuffalo1 off my food truck list!  @ Larkin Square http:\/\/t.co\/XljTOapl",
  "id" : 243456430227730434,
  "created_at" : "2012-09-05 21:11:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243442758185000960",
  "geo" : { },
  "id_str" : "243443805750185984",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik 10pm EST",
  "id" : 243443805750185984,
  "in_reply_to_status_id" : 243442758185000960,
  "created_at" : "2012-09-05 20:21:40 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "243442573958586368",
  "text" : "http:\/\/t.co\/bdjsRgTW is having issues again :( we've got a team meeting tonight to figure these problems out.",
  "id" : 243442573958586368,
  "created_at" : "2012-09-05 20:16:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Woodcox",
      "screen_name" : "cwoodcox",
      "indices" : [ 0, 9 ],
      "id_str" : "15893003",
      "id" : 15893003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/bAcuzEVf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WrE-AhX-qtk",
      "display_url" : "youtube.com\/watch?v=WrE-Ah\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "243422244183887872",
  "geo" : { },
  "id_str" : "243423274174926849",
  "in_reply_to_user_id" : 15893003,
  "text" : "@cwoodcox TERRY CREWS! BUILDING KICK! http:\/\/t.co\/bAcuzEVf",
  "id" : 243423274174926849,
  "in_reply_to_status_id" : 243422244183887872,
  "created_at" : "2012-09-05 19:00:05 +0000",
  "in_reply_to_screen_name" : "cwoodcox",
  "in_reply_to_user_id_str" : "15893003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "indices" : [ 11, 16 ],
      "id_str" : "15308015",
      "id" : 15308015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Js7YxDcV",
      "expanded_url" : "http:\/\/i.imgur.com\/w5isZ.jpg",
      "display_url" : "i.imgur.com\/w5isZ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "243419961324863488",
  "text" : "Quite glad @wgrz isn't the only news station that messed this up: http:\/\/t.co\/Js7YxDcV",
  "id" : 243419961324863488,
  "created_at" : "2012-09-05 18:46:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/lUXzpnMh",
      "expanded_url" : "http:\/\/i.imgur.com\/w5isZ.jpg",
      "display_url" : "i.imgur.com\/w5isZ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "243419738326302720",
  "text" : "RT @moonpolysoft: http:\/\/t.co\/lUXzpnMh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/lUXzpnMh",
        "expanded_url" : "http:\/\/i.imgur.com\/w5isZ.jpg",
        "display_url" : "i.imgur.com\/w5isZ.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "243419116495597568",
    "text" : "http:\/\/t.co\/lUXzpnMh",
    "id" : 243419116495597568,
    "created_at" : "2012-09-05 18:43:34 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 243419738326302720,
  "created_at" : "2012-09-05 18:46:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243416923314991104",
  "text" : "Current status: undefined local variable or method `\u221A\u00EE\u221A\u220F\u00AC\u00A9\u221A\u00EE\u221A\u00B6\u221A\u00F1\u221A\u00EE\u221A\u00B6\u221A\u00F1\u221A\u00EE\u221A\u220F\u221A\u00FC\u221A\u00EE\u221A\u00B6\u221A\u00E1\u221A\u00EE\u221A\u00B6\u00AC\u00A9p' for main:TopLevel (NameError)",
  "id" : 243416923314991104,
  "created_at" : "2012-09-05 18:34:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 71 ],
      "url" : "https:\/\/t.co\/5qCUgx09",
      "expanded_url" : "https:\/\/angel.co\/docs",
      "display_url" : "angel.co\/docs"
    } ]
  },
  "geo" : { },
  "id_str" : "243414523653005312",
  "text" : "Automate giving part of your company away, today! https:\/\/t.co\/5qCUgx09 Why does this just seem unhealthy?",
  "id" : 243414523653005312,
  "created_at" : "2012-09-05 18:25:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 3, 14 ],
      "id_str" : "9994542",
      "id" : 9994542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243358736683507714",
  "text" : "RT @brianmario: Give your partner a huge tight hug today. Don't sweat the little things, please. Appreciate this short life down to a si ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 35.5555228765, -120.7225969361 ]
    },
    "id_str" : "243357011004243968",
    "text" : "Give your partner a huge tight hug today. Don't sweat the little things, please. Appreciate this short life down to a single blade of grass.",
    "id" : 243357011004243968,
    "created_at" : "2012-09-05 14:36:47 +0000",
    "user" : {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "protected" : false,
      "id_str" : "9994542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2652691577\/bd48803c47ac69ea051cc8e2085640ec_normal.jpeg",
      "id" : 9994542,
      "verified" : false
    }
  },
  "id" : 243358736683507714,
  "created_at" : "2012-09-05 14:43:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 47, 53 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/5xEYeXmP",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1VuMdLm0ccU",
      "display_url" : "youtube.com\/watch?v=1VuMdL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243356553535705089",
  "text" : "2 Hamsters, 1 Wheel. http:\/\/t.co\/5xEYeXmP (via @atmos)",
  "id" : 243356553535705089,
  "created_at" : "2012-09-05 14:34:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 14, 26 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243349638009217025",
  "text" : "Pumped to see @AqueousBand tonight!",
  "id" : 243349638009217025,
  "created_at" : "2012-09-05 14:07:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Dever",
      "screen_name" : "clarkdever",
      "indices" : [ 0, 11 ],
      "id_str" : "11081432",
      "id" : 11081432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243330685098655744",
  "geo" : { },
  "id_str" : "243333383869042688",
  "in_reply_to_user_id" : 11081432,
  "text" : "@clarkdever I love how this is a surprise to some.",
  "id" : 243333383869042688,
  "in_reply_to_status_id" : 243330685098655744,
  "created_at" : "2012-09-05 13:02:54 +0000",
  "in_reply_to_screen_name" : "clarkdever",
  "in_reply_to_user_id_str" : "11081432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/7NVVDaZF",
      "expanded_url" : "http:\/\/pandodaily.com\/2012\/09\/04\/pandofigures\/",
      "display_url" : "pandodaily.com\/2012\/09\/04\/pan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243185901545607168",
  "text" : "Nope, totally not hero worship: http:\/\/t.co\/7NVVDaZF",
  "id" : 243185901545607168,
  "created_at" : "2012-09-05 03:16:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    }, {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 13, 25 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243167174200528896",
  "geo" : { },
  "id_str" : "243167475334795266",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen @techpickles i thought your username was 11...and then...oh wait :)",
  "id" : 243167475334795266,
  "in_reply_to_status_id" : 243167174200528896,
  "created_at" : "2012-09-05 02:03:38 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 10, 17 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/jE5qLpVz",
      "expanded_url" : "http:\/\/tmblr.co\/ZrU0yvShoah4",
      "display_url" : "tmblr.co\/ZrU0yvShoah4"
    } ]
  },
  "in_reply_to_status_id_str" : "243165232300711936",
  "geo" : { },
  "id_str" : "243167294795153408",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @lsegal yes, it's called my bike. http:\/\/t.co\/jE5qLpVz",
  "id" : 243167294795153408,
  "in_reply_to_status_id" : 243165232300711936,
  "created_at" : "2012-09-05 02:02:55 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243158331508797442",
  "text" : "Walking for an hour really does nothing to tire this husky out. Just as crazy, bouncy, and playful on return to home. I hate rainy days.",
  "id" : 243158331508797442,
  "created_at" : "2012-09-05 01:27:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/SPdH6Kae",
      "expanded_url" : "http:\/\/boston.craigslist.org\/gbs\/sha\/3247777775.html",
      "display_url" : "boston.craigslist.org\/gbs\/sha\/324777\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243151244212989952",
  "text" : "Oh look, what a well educated roommate. I wonder what he looks likWHAT THE FUCK http:\/\/t.co\/SPdH6Kae",
  "id" : 243151244212989952,
  "created_at" : "2012-09-05 00:59:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    }, {
      "name" : "Patrick Donnelly",
      "screen_name" : "dunalar",
      "indices" : [ 13, 21 ],
      "id_str" : "32317282",
      "id" : 32317282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243146463343960064",
  "geo" : { },
  "id_str" : "243146561218019328",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 @dunalar holy crap! Congrats!",
  "id" : 243146561218019328,
  "in_reply_to_status_id" : 243146463343960064,
  "created_at" : "2012-09-05 00:40:32 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/pE7ZiDN7",
      "expanded_url" : "http:\/\/instagr.am\/p\/PLBm__s6p0\/",
      "display_url" : "instagr.am\/p\/PLBm__s6p0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "243132252320591872",
  "text" : "All the way across the sky! http:\/\/t.co\/pE7ZiDN7",
  "id" : 243132252320591872,
  "created_at" : "2012-09-04 23:43:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 3, 11 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243112718456999936",
  "text" : "RT @fending: Thinking about a Sabres MiniPak this season, mostly to make playoff tickets easier. Anybody interested in splitting some?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "243112371835514880",
    "text" : "Thinking about a Sabres MiniPak this season, mostly to make playoff tickets easier. Anybody interested in splitting some?",
    "id" : 243112371835514880,
    "created_at" : "2012-09-04 22:24:40 +0000",
    "user" : {
      "name" : "fending",
      "screen_name" : "fending",
      "protected" : false,
      "id_str" : "14672651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468101796\/ed9f5bca1aff3f91233b2986acb0fd4e_normal.jpeg",
      "id" : 14672651,
      "verified" : false
    }
  },
  "id" : 243112718456999936,
  "created_at" : "2012-09-04 22:26:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243112371835514880",
  "geo" : { },
  "id_str" : "243112592611086338",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending I'm in!",
  "id" : 243112592611086338,
  "in_reply_to_status_id" : 243112371835514880,
  "created_at" : "2012-09-04 22:25:33 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243109644241874944",
  "geo" : { },
  "id_str" : "243111467354820609",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh clearly you don't have a WOWser.",
  "id" : 243111467354820609,
  "in_reply_to_status_id" : 243109644241874944,
  "created_at" : "2012-09-04 22:21:05 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/94JgWdc4",
      "expanded_url" : "http:\/\/www.aqueousband.com\/tour.php",
      "display_url" : "aqueousband.com\/tour.php"
    } ]
  },
  "geo" : { },
  "id_str" : "243101847135600640",
  "text" : "Definitely going to see Aqueous tomorrow! Very pumped. http:\/\/t.co\/94JgWdc4",
  "id" : 243101847135600640,
  "created_at" : "2012-09-04 21:42:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/erurSrcb",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3244-join-our-trans-atlantic-support-team",
      "display_url" : "37signals.com\/svn\/posts\/3244\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243098790012260353",
  "text" : "RT @37signals: We're adding a new person to our support team! Wanna come work with us? http:\/\/t.co\/erurSrcb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.desk.com\" rel=\"nofollow\"\u003EDesk.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/erurSrcb",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3244-join-our-trans-atlantic-support-team",
        "display_url" : "37signals.com\/svn\/posts\/3244\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "243098200196648960",
    "text" : "We're adding a new person to our support team! Wanna come work with us? http:\/\/t.co\/erurSrcb",
    "id" : 243098200196648960,
    "created_at" : "2012-09-04 21:28:22 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 243098790012260353,
  "created_at" : "2012-09-04 21:30:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airbrakeapp",
      "screen_name" : "Airbrakeapp",
      "indices" : [ 0, 12 ],
      "id_str" : "1246877592",
      "id" : 1246877592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243084189942042625",
  "geo" : { },
  "id_str" : "243084800825622528",
  "in_reply_to_user_id" : 298023205,
  "text" : "@airbrakeapp thanks.",
  "id" : 243084800825622528,
  "in_reply_to_status_id" : 243084189942042625,
  "created_at" : "2012-09-04 20:35:07 +0000",
  "in_reply_to_screen_name" : "airbrake",
  "in_reply_to_user_id_str" : "298023205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/hasfkDJb",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dogs\/comments\/zcg90\/if_you_get_a_small_dog_please_for_the_love_of_god\/",
      "display_url" : "reddit.com\/r\/dogs\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243081983859765248",
  "text" : "Very glad I'm not the only dog owner that has noticed most small dog owners don't give a flying fuck. &gt;:[ http:\/\/t.co\/hasfkDJb",
  "id" : 243081983859765248,
  "created_at" : "2012-09-04 20:23:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "243081402806046720",
  "text" : "Reality: we need to fix how people claim gems on http:\/\/t.co\/bdjsRgTW so accidental pushes happen less often. :(",
  "id" : 243081402806046720,
  "created_at" : "2012-09-04 20:21:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/NJdqWZAL",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "243081091680964608",
  "text" : "Lesson learned: Including my personal email in http:\/\/t.co\/NJdqWZAL's autoresponder as \"emergency\" use means every email is an emergency.",
  "id" : 243081091680964608,
  "created_at" : "2012-09-04 20:20:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/dJs5zPYw",
      "expanded_url" : "http:\/\/status.rubygems.org",
      "display_url" : "status.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "243056736729169920",
  "text" : "RT @rubygems_status: Our backend box is having issues. Gem serving should be unaffected. Check out: http:\/\/t.co\/dJs5zPYw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/dJs5zPYw",
        "expanded_url" : "http:\/\/status.rubygems.org",
        "display_url" : "status.rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "243056120485249024",
    "text" : "Our backend box is having issues. Gem serving should be unaffected. Check out: http:\/\/t.co\/dJs5zPYw",
    "id" : 243056120485249024,
    "created_at" : "2012-09-04 18:41:09 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 243056736729169920,
  "created_at" : "2012-09-04 18:43:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243055517356937218",
  "text" : "RT @rjs: To do big things you have to be excited about small steps.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "243018591463677952",
    "text" : "To do big things you have to be excited about small steps.",
    "id" : 243018591463677952,
    "created_at" : "2012-09-04 16:12:01 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 243055517356937218,
  "created_at" : "2012-09-04 18:38:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 111, 115 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243042939914289152",
  "text" : "\"Fixed the build system to no longer re-build all .rb files in case the project's Rakefile changed.\" THANK YOU @lrz!!!",
  "id" : 243042939914289152,
  "created_at" : "2012-09-04 17:48:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "indices" : [ 0, 14 ],
      "id_str" : "5889062",
      "id" : 5889062
    }, {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 15, 24 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243035210877370369",
  "geo" : { },
  "id_str" : "243035368474169344",
  "in_reply_to_user_id" : 5889062,
  "text" : "@thetorpedodog @Marigold sounds like someone's been writing java too long.",
  "id" : 243035368474169344,
  "in_reply_to_status_id" : 243035210877370369,
  "created_at" : "2012-09-04 17:18:41 +0000",
  "in_reply_to_screen_name" : "thetorpedodog",
  "in_reply_to_user_id_str" : "5889062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243029321311219712",
  "geo" : { },
  "id_str" : "243029459668725760",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove YOLO~",
  "id" : 243029459668725760,
  "in_reply_to_status_id" : 243029321311219712,
  "created_at" : "2012-09-04 16:55:13 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241308143555076096",
  "geo" : { },
  "id_str" : "243029252402982913",
  "in_reply_to_user_id" : 20476487,
  "text" : "@mrmikebradford should be around that...was it longer?",
  "id" : 243029252402982913,
  "in_reply_to_status_id" : 241308143555076096,
  "created_at" : "2012-09-04 16:54:23 +0000",
  "in_reply_to_screen_name" : "pfifltrigg",
  "in_reply_to_user_id_str" : "20476487",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/359PlDbg",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=4474784",
      "display_url" : "news.ycombinator.com\/item?id=4474784"
    } ]
  },
  "geo" : { },
  "id_str" : "243027818211065856",
  "text" : "HN in a nutshell: http:\/\/t.co\/359PlDbg",
  "id" : 243027818211065856,
  "created_at" : "2012-09-04 16:48:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243016753565818880",
  "geo" : { },
  "id_str" : "243018478167138304",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant or announce my own funeral\/wake.",
  "id" : 243018478167138304,
  "in_reply_to_status_id" : 243016753565818880,
  "created_at" : "2012-09-04 16:11:34 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/V5s7TO2a",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Timothy_Dexter",
      "display_url" : "en.wikipedia.org\/wiki\/Timothy_D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243016163444023296",
  "text" : "The actual most interesting man in the world? http:\/\/t.co\/V5s7TO2a",
  "id" : 243016163444023296,
  "created_at" : "2012-09-04 16:02:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243002758570074112",
  "geo" : { },
  "id_str" : "243002899309936641",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr ....",
  "id" : 243002899309936641,
  "in_reply_to_status_id" : 243002758570074112,
  "created_at" : "2012-09-04 15:09:40 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/zC26ReiH",
      "expanded_url" : "http:\/\/bukk.it\/facepalm-sisko.gif",
      "display_url" : "bukk.it\/facepalm-sisko\u2026"
    }, {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/NlGS5VtP",
      "expanded_url" : "http:\/\/deadspin.com\/5940163\/buffalo-nbc-station-uses-photos-of-singer-seal-to-report-on-actor-michael-clarke-duncans-death",
      "display_url" : "deadspin.com\/5940163\/buffal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243002324291821568",
  "text" : "http:\/\/t.co\/zC26ReiH http:\/\/t.co\/NlGS5VtP",
  "id" : 243002324291821568,
  "created_at" : "2012-09-04 15:07:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 0, 9 ],
      "id_str" : "787975",
      "id" : 787975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242997496287215616",
  "in_reply_to_user_id" : 787975,
  "text" : "@mathiasx where'd you go!!?",
  "id" : 242997496287215616,
  "created_at" : "2012-09-04 14:48:12 +0000",
  "in_reply_to_screen_name" : "mathiasx",
  "in_reply_to_user_id_str" : "787975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "242996170111205376",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Bone Thugs-N-Harmony: 1st Of Tha Month \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 242996170111205376,
  "created_at" : "2012-09-04 14:42:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/bsgxL26S",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3241-37signals-invests-in-the-starter-league",
      "display_url" : "37signals.com\/svn\/posts\/3241\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "242989172552499200",
  "text" : "RT @jasonfried: 37signals invests in The Starter League:\nhttp:\/\/t.co\/bsgxL26S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/bsgxL26S",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3241-37signals-invests-in-the-starter-league",
        "display_url" : "37signals.com\/svn\/posts\/3241\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "242988635404779520",
    "text" : "37signals invests in The Starter League:\nhttp:\/\/t.co\/bsgxL26S",
    "id" : 242988635404779520,
    "created_at" : "2012-09-04 14:12:59 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 242989172552499200,
  "created_at" : "2012-09-04 14:15:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/wEk50JMq",
      "expanded_url" : "http:\/\/phish.net\/setlists\/?d=2011-09-02",
      "display_url" : "phish.net\/setlists\/?d=20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "242842982653505536",
  "geo" : { },
  "id_str" : "242843291719188480",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik definitely. Not sure if this beats the S show: http:\/\/t.co\/wEk50JMq",
  "id" : 242843291719188480,
  "in_reply_to_status_id" : 242842982653505536,
  "created_at" : "2012-09-04 04:35:27 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/6da7N8zs",
      "expanded_url" : "http:\/\/phish.net\/setlists\/?d=2012-08-31",
      "display_url" : "phish.net\/setlists\/?d=20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "242840859089977344",
  "text" : "Phish's first setlist at Dick's in Denver spelled out F-U-C-K-Y-O-U-R-F-A-C-E, sang it, encored with Meatstick. http:\/\/t.co\/6da7N8zs",
  "id" : 242840859089977344,
  "created_at" : "2012-09-04 04:25:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/MlgEs5Ht",
      "expanded_url" : "http:\/\/www.miscupload.com\/upload\/596452886734362585970458.gif",
      "display_url" : "miscupload.com\/upload\/5964528\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "242837598354153472",
  "geo" : { },
  "id_str" : "242839862477205504",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten http:\/\/t.co\/MlgEs5Ht",
  "id" : 242839862477205504,
  "in_reply_to_status_id" : 242837598354153472,
  "created_at" : "2012-09-04 04:21:49 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242834719316787200",
  "geo" : { },
  "id_str" : "242835085525647361",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi def hello?; anyone =  in?(here); end",
  "id" : 242835085525647361,
  "in_reply_to_status_id" : 242834719316787200,
  "created_at" : "2012-09-04 04:02:50 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242834414495727617",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten :( yeah manual is pretty easy.",
  "id" : 242834414495727617,
  "created_at" : "2012-09-04 04:00:10 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242830836708294656",
  "geo" : { },
  "id_str" : "242832375103500291",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten :( responded best I could. if you can paste the gemspec, i can try to help more.",
  "id" : 242832375103500291,
  "in_reply_to_status_id" : 242830836708294656,
  "created_at" : "2012-09-04 03:52:04 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/2NhXUkhd",
      "expanded_url" : "http:\/\/instagr.am\/p\/PI1NhKM6ll\/",
      "display_url" : "instagr.am\/p\/PI1NhKM6ll\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242824548377034752",
  "text" : "Kingdom Builders. I broke irb trying to figure out the combinations possible here. http:\/\/t.co\/2NhXUkhd",
  "id" : 242824548377034752,
  "created_at" : "2012-09-04 03:20:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Tanner",
      "screen_name" : "adamtanner",
      "indices" : [ 0, 11 ],
      "id_str" : "6367402",
      "id" : 6367402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242818160145883136",
  "geo" : { },
  "id_str" : "242824265341206528",
  "in_reply_to_user_id" : 6367402,
  "text" : "@adamtanner actually was talking about that tonight! thinking of making better\/simpler instructions too for most of them.",
  "id" : 242824265341206528,
  "in_reply_to_status_id" : 242818160145883136,
  "created_at" : "2012-09-04 03:19:50 +0000",
  "in_reply_to_screen_name" : "adamtanner",
  "in_reply_to_user_id_str" : "6367402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/O8oBhJeB",
      "expanded_url" : "http:\/\/instagr.am\/p\/PIuivAs6gb\/",
      "display_url" : "instagr.am\/p\/PIuivAs6gb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242808905145667585",
  "text" : "Forbidden Island. Won, but not much of an island left! http:\/\/t.co\/O8oBhJeB",
  "id" : 242808905145667585,
  "created_at" : "2012-09-04 02:18:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merissa",
      "screen_name" : "merissie",
      "indices" : [ 0, 9 ],
      "id_str" : "15338379",
      "id" : 15338379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242793142074617857",
  "geo" : { },
  "id_str" : "242793368353124352",
  "in_reply_to_user_id" : 15338379,
  "text" : "@merissie congrats!",
  "id" : 242793368353124352,
  "in_reply_to_status_id" : 242793142074617857,
  "created_at" : "2012-09-04 01:17:04 +0000",
  "in_reply_to_screen_name" : "merissie",
  "in_reply_to_user_id_str" : "15338379",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 33 ],
      "url" : "https:\/\/t.co\/RLAGxLVG",
      "expanded_url" : "https:\/\/img.skitch.com\/20120904-rx3i7gudykx2u5cp3tg15si6uc.png",
      "display_url" : "img.skitch.com\/20120904-rx3i7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "242792533925711872",
  "geo" : { },
  "id_str" : "242793240036790273",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove https:\/\/t.co\/RLAGxLVG",
  "id" : 242793240036790273,
  "in_reply_to_status_id" : 242792533925711872,
  "created_at" : "2012-09-04 01:16:33 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/EmRmnAWz",
      "expanded_url" : "http:\/\/instagr.am\/p\/PIKIglM6gI\/",
      "display_url" : "instagr.am\/p\/PIKIglM6gI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242728780198735872",
  "text" : "Beware of cuteness! http:\/\/t.co\/EmRmnAWz",
  "id" : 242728780198735872,
  "created_at" : "2012-09-03 21:00:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/9pOY9VcL",
      "expanded_url" : "http:\/\/instagr.am\/p\/PIKH2xs6gH\/",
      "display_url" : "instagr.am\/p\/PIKH2xs6gH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242728757906001920",
  "text" : "Niagara on the Lake! http:\/\/t.co\/9pOY9VcL",
  "id" : 242728757906001920,
  "created_at" : "2012-09-03 21:00:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/1qC4BhJ4",
      "expanded_url" : "http:\/\/instagr.am\/p\/PIIfQnM6uW\/",
      "display_url" : "instagr.am\/p\/PIIfQnM6uW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242728733956530176",
  "text" : "Niagara River, looking towards Lewiston http:\/\/t.co\/1qC4BhJ4",
  "id" : 242728733956530176,
  "created_at" : "2012-09-03 21:00:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bentivenga",
      "screen_name" : "ChrisBenti",
      "indices" : [ 0, 11 ],
      "id_str" : "71867239",
      "id" : 71867239
    }, {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "indices" : [ 12, 26 ],
      "id_str" : "5889062",
      "id" : 5889062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242653486225960960",
  "geo" : { },
  "id_str" : "242666228152422400",
  "in_reply_to_user_id" : 71867239,
  "text" : "@ChrisBenti @thetorpedodog run arch Linux, write your own emacs plugins, debate Freedom 0 on slashdot?",
  "id" : 242666228152422400,
  "in_reply_to_status_id" : 242653486225960960,
  "created_at" : "2012-09-03 16:51:51 +0000",
  "in_reply_to_screen_name" : "ChrisBenti",
  "in_reply_to_user_id_str" : "71867239",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeb Brovsky",
      "screen_name" : "JebBrovsky",
      "indices" : [ 3, 14 ],
      "id_str" : "219194428",
      "id" : 219194428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242660594036129794",
  "text" : "RT @JebBrovsky: You can tell Monopoly is an old game because there is a \"Luxury Tax\", \"Community Chest\" and the Banker can still get thr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "242640049030721536",
    "text" : "You can tell Monopoly is an old game because there is a \"Luxury Tax\", \"Community Chest\" and the Banker can still get thrown in jail.",
    "id" : 242640049030721536,
    "created_at" : "2012-09-03 15:07:50 +0000",
    "user" : {
      "name" : "Jeb Brovsky",
      "screen_name" : "JebBrovsky",
      "protected" : false,
      "id_str" : "219194428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550552363505696768\/nYjP7SNP_normal.jpeg",
      "id" : 219194428,
      "verified" : true
    }
  },
  "id" : 242660594036129794,
  "created_at" : "2012-09-03 16:29:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242308209283592192",
  "geo" : { },
  "id_str" : "242647707280371713",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment The RIT plate explains it all here :)",
  "id" : 242647707280371713,
  "in_reply_to_status_id" : 242308209283592192,
  "created_at" : "2012-09-03 15:38:16 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242644541050593280",
  "text" : "Also, holy crap that year went fast.",
  "id" : 242644541050593280,
  "created_at" : "2012-09-03 15:25:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 34, 44 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/d2Xk68OT",
      "expanded_url" : "http:\/\/us.quaran.to\/",
      "display_url" : "us.quaran.to"
    } ]
  },
  "geo" : { },
  "id_str" : "242643677883797506",
  "text" : "Celebrating one year married with @aquaranto today! Filled out http:\/\/t.co\/d2Xk68OT with our spring\/summer adventures too!",
  "id" : 242643677883797506,
  "created_at" : "2012-09-03 15:22:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    }, {
      "name" : "Cassandra Moffitt",
      "screen_name" : "cassandrarife",
      "indices" : [ 14, 28 ],
      "id_str" : "2585986136",
      "id" : 2585986136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242606283734274048",
  "geo" : { },
  "id_str" : "242635907499454464",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt @cassandrarife congrats ! hope you had a fun day :)",
  "id" : 242635907499454464,
  "in_reply_to_status_id" : 242606283734274048,
  "created_at" : "2012-09-03 14:51:22 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242494646838755328",
  "geo" : { },
  "id_str" : "242496706489491456",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant wat",
  "id" : 242496706489491456,
  "in_reply_to_status_id" : 242494646838755328,
  "created_at" : "2012-09-03 05:38:14 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 3, 12 ],
      "id_str" : "16891384",
      "id" : 16891384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242466133054214146",
  "text" : "RT @KentBeck: re: SO answer. \"Should I feel bad If I code w\/o tests?\" Should have said \"No, feel bad if you code without value\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "242423677868716032",
    "text" : "re: SO answer. \"Should I feel bad If I code w\/o tests?\" Should have said \"No, feel bad if you code without value\"",
    "id" : 242423677868716032,
    "created_at" : "2012-09-03 00:48:03 +0000",
    "user" : {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "protected" : false,
      "id_str" : "16891384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2550670043\/xq10bqclqpsezgerjxhi_normal.jpeg",
      "id" : 16891384,
      "verified" : false
    }
  },
  "id" : 242466133054214146,
  "created_at" : "2012-09-03 03:36:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 14, 20 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/242452126540914688\/photo\/1",
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/3O1P072W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A11c7K4CYAAzRRU.jpg",
      "id_str" : "242452126549303296",
      "id" : 242452126549303296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A11c7K4CYAAzRRU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3O1P072W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242452126540914688",
  "text" : "Couch tour on @phish's last gig until NYE. Love the HD feed! http:\/\/t.co\/3O1P072W",
  "id" : 242452126540914688,
  "created_at" : "2012-09-03 02:41:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242432487844896769",
  "geo" : { },
  "id_str" : "242433348658688002",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca 7 Wonders is so good.",
  "id" : 242433348658688002,
  "in_reply_to_status_id" : 242432487844896769,
  "created_at" : "2012-09-03 01:26:29 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 52, 61 ],
      "id_str" : "16891384",
      "id" : 16891384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/0hvbG24G",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/153234\/how-deep-are-your-unit-tests\/153565#153565",
      "display_url" : "stackoverflow.com\/questions\/1532\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "242424926030663680",
  "text" : "RT @dhh: Love this answer to \"how much to test?\" by @KentBeck: http:\/\/t.co\/0hvbG24G. Articulates my thoughts on the matter very well.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kent Beck",
        "screen_name" : "KentBeck",
        "indices" : [ 43, 52 ],
        "id_str" : "16891384",
        "id" : 16891384
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/0hvbG24G",
        "expanded_url" : "http:\/\/stackoverflow.com\/questions\/153234\/how-deep-are-your-unit-tests\/153565#153565",
        "display_url" : "stackoverflow.com\/questions\/1532\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "242415788676501505",
    "text" : "Love this answer to \"how much to test?\" by @KentBeck: http:\/\/t.co\/0hvbG24G. Articulates my thoughts on the matter very well.",
    "id" : 242415788676501505,
    "created_at" : "2012-09-03 00:16:42 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 242424926030663680,
  "created_at" : "2012-09-03 00:53:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 48, 58 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/iMSjsqRA",
      "expanded_url" : "http:\/\/instagr.am\/p\/PF6E_Os6mR\/",
      "display_url" : "instagr.am\/p\/PF6E_Os6mR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242412058040205313",
  "text" : "Fancy one year homemade anniversary dinner with @aquaranto! http:\/\/t.co\/iMSjsqRA",
  "id" : 242412058040205313,
  "created_at" : "2012-09-03 00:01:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/Cwzmi0hP",
      "expanded_url" : "http:\/\/instagr.am\/p\/PF3abVs6jr\/",
      "display_url" : "instagr.am\/p\/PF3abVs6jr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242406177592471552",
  "text" : "It's Grilling Time. http:\/\/t.co\/Cwzmi0hP",
  "id" : 242406177592471552,
  "created_at" : "2012-09-02 23:38:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/EXMicRSh",
      "expanded_url" : "http:\/\/www.newyorker.com\/reporting\/2012\/08\/06\/120806fa_fact_singer?currentPage=all",
      "display_url" : "newyorker.com\/reporting\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "242285943887912960",
  "text" : "Set aside an hour and soak in this masterpiece. Why are frauds so fun to read about? http:\/\/t.co\/EXMicRSh",
  "id" : 242285943887912960,
  "created_at" : "2012-09-02 15:40:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/3f6KTK1R",
      "expanded_url" : "http:\/\/resume.github.com\/?qrush",
      "display_url" : "resume.github.com\/?qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "242273436498538497",
  "text" : "Ok, that's kind of neat: http:\/\/t.co\/3f6KTK1R",
  "id" : 242273436498538497,
  "created_at" : "2012-09-02 14:51:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242148373031972864",
  "geo" : { },
  "id_str" : "242149871770034176",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh my worst is just forcing them to eat raw grain, not baked. So desperate.",
  "id" : 242149871770034176,
  "in_reply_to_status_id" : 242148373031972864,
  "created_at" : "2012-09-02 06:40:03 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242143418908819456",
  "geo" : { },
  "id_str" : "242148130596990976",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh haha it's so stressful. I think it's  because the weight of your family starving is over your head.",
  "id" : 242148130596990976,
  "in_reply_to_status_id" : 242143418908819456,
  "created_at" : "2012-09-02 06:33:07 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/TWH1BPwJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/PD_NQws6jx\/",
      "display_url" : "instagr.am\/p\/PD_NQws6jx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242142718049005568",
  "text" : "Agricola, everyone deck. 38 points! http:\/\/t.co\/TWH1BPwJ",
  "id" : 242142718049005568,
  "created_at" : "2012-09-02 06:11:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/a21uxNba",
      "expanded_url" : "http:\/\/instagr.am\/p\/PDlkcMs6gw\/",
      "display_url" : "instagr.am\/p\/PDlkcMs6gw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242085447726141440",
  "text" : "Apparently it's cuddle time. http:\/\/t.co\/a21uxNba",
  "id" : 242085447726141440,
  "created_at" : "2012-09-02 02:24:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "indices" : [ 0, 6 ],
      "id_str" : "15477591",
      "id" : 15477591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242080964254265344",
  "geo" : { },
  "id_str" : "242084085873393664",
  "in_reply_to_user_id" : 15477591,
  "text" : "@Braxo nope, just my friends play a lot!",
  "id" : 242084085873393664,
  "in_reply_to_status_id" : 242080964254265344,
  "created_at" : "2012-09-02 02:18:38 +0000",
  "in_reply_to_screen_name" : "Braxo",
  "in_reply_to_user_id_str" : "15477591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/S79bqkmF",
      "expanded_url" : "http:\/\/instagr.am\/p\/PDhi1PM6tO\/",
      "display_url" : "instagr.am\/p\/PDhi1PM6tO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242076883938865152",
  "text" : "7 Wonders + Leaders! http:\/\/t.co\/S79bqkmF",
  "id" : 242076883938865152,
  "created_at" : "2012-09-02 01:50:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242058455274369024",
  "geo" : { },
  "id_str" : "242063959228825600",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky love it.",
  "id" : 242063959228825600,
  "in_reply_to_status_id" : 242058455274369024,
  "created_at" : "2012-09-02 00:58:39 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/BIX0HER7",
      "expanded_url" : "http:\/\/instagr.am\/p\/PC91fss6sm\/",
      "display_url" : "instagr.am\/p\/PC91fss6sm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "241998366270160897",
  "text" : "Carcassone + Abbey &amp; Mayor http:\/\/t.co\/BIX0HER7",
  "id" : 241998366270160897,
  "created_at" : "2012-09-01 20:38:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Barnes",
      "screen_name" : "vinbarnes",
      "indices" : [ 0, 10 ],
      "id_str" : "9922972",
      "id" : 9922972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241935248563261441",
  "geo" : { },
  "id_str" : "241940271057756160",
  "in_reply_to_user_id" : 9922972,
  "text" : "@vinbarnes I think that makes me more sad",
  "id" : 241940271057756160,
  "in_reply_to_status_id" : 241935248563261441,
  "created_at" : "2012-09-01 16:47:10 +0000",
  "in_reply_to_screen_name" : "vinbarnes",
  "in_reply_to_user_id_str" : "9922972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241764772025102338",
  "geo" : { },
  "id_str" : "241764892988829696",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen I see what you did there",
  "id" : 241764892988829696,
  "in_reply_to_status_id" : 241764772025102338,
  "created_at" : "2012-09-01 05:10:16 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Dunck",
      "screen_name" : "jdunck",
      "indices" : [ 0, 7 ],
      "id_str" : "837641",
      "id" : 837641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241760315832926208",
  "geo" : { },
  "id_str" : "241761449351995392",
  "in_reply_to_user_id" : 837641,
  "text" : "@jdunck nope. I have a limited time to exploit the derposity. The amount of derptitude cant be contained.",
  "id" : 241761449351995392,
  "in_reply_to_status_id" : 241760315832926208,
  "created_at" : "2012-09-01 04:56:35 +0000",
  "in_reply_to_screen_name" : "jdunck",
  "in_reply_to_user_id_str" : "837641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Patrick Crowley",
      "screen_name" : "mokolabs",
      "indices" : [ 9, 18 ],
      "id_str" : "630103",
      "id" : 630103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241757032955408384",
  "geo" : { },
  "id_str" : "241759863003287553",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety @mokolabs the derpness stares back you.",
  "id" : 241759863003287553,
  "in_reply_to_status_id" : 241757032955408384,
  "created_at" : "2012-09-01 04:50:17 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Dunck",
      "screen_name" : "jdunck",
      "indices" : [ 0, 7 ],
      "id_str" : "837641",
      "id" : 837641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241752052106153984",
  "geo" : { },
  "id_str" : "241756042923483137",
  "in_reply_to_user_id" : 837641,
  "text" : "@jdunck I think you're missing the point here.",
  "id" : 241756042923483137,
  "in_reply_to_status_id" : 241752052106153984,
  "created_at" : "2012-09-01 04:35:06 +0000",
  "in_reply_to_screen_name" : "jdunck",
  "in_reply_to_user_id_str" : "837641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 26, 39 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241747552863649792",
  "text" : "The derpness is strong on @herpderpedia. Yes, yes! Let the derp flow through you!",
  "id" : 241747552863649792,
  "created_at" : "2012-09-01 04:01:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
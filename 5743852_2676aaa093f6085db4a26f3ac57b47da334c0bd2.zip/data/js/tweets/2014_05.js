Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9444375309, -78.9094840643 ]
  },
  "id_str" : "472823863131131904",
  "text" : "One of those days where you find a new dog park in your city with a gorgeous waterfront view\u2026and there\u2019s no dogs there.",
  "id" : 472823863131131904,
  "created_at" : "2014-05-31 19:36:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugene V. Dabs",
      "screen_name" : "red_mercer",
      "indices" : [ 3, 14 ],
      "id_str" : "294848568",
      "id" : 294848568
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/red_mercer\/status\/472812439902232576\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/OxGRuZQhLv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo_EaGMIUAIYlPq.jpg",
      "id_str" : "472812438514323458",
      "id" : 472812438514323458,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo_EaGMIUAIYlPq.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OxGRuZQhLv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472814614564982784",
  "text" : "RT @red_mercer: aaah this owns, fuck flying http:\/\/t.co\/OxGRuZQhLv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/red_mercer\/status\/472812439902232576\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/OxGRuZQhLv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo_EaGMIUAIYlPq.jpg",
        "id_str" : "472812438514323458",
        "id" : 472812438514323458,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo_EaGMIUAIYlPq.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OxGRuZQhLv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472812439902232576",
    "text" : "aaah this owns, fuck flying http:\/\/t.co\/OxGRuZQhLv",
    "id" : 472812439902232576,
    "created_at" : "2014-05-31 18:50:44 +0000",
    "user" : {
      "name" : "Eugene V. Dabs",
      "screen_name" : "red_mercer",
      "protected" : false,
      "id_str" : "294848568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2508311413\/6limdqgecdya9la4syau_normal.jpeg",
      "id" : 294848568,
      "verified" : false
    }
  },
  "id" : 472814614564982784,
  "created_at" : "2014-05-31 18:59:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "indices" : [ 3, 9 ],
      "id_str" : "9632752",
      "id" : 9632752
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 67, 72 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 96, 103 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Moore\/status\/472412571199217664\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/9EoDaAnIWg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo5YuklIEAEDKyu.jpg",
      "id_str" : "472412568037101569",
      "id" : 472412568037101569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo5YuklIEAEDKyu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1198,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1998,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1998,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/9EoDaAnIWg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472770117646823424",
  "text" : "RT @Moore: The 45 year evolution of spacecraft cockpit design from @NASA Apollo to Discovery to @SpaceX Dragon v2 http:\/\/t.co\/9EoDaAnIWg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 56, 61 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 85, 92 ],
        "id_str" : "34743251",
        "id" : 34743251
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Moore\/status\/472412571199217664\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/9EoDaAnIWg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo5YuklIEAEDKyu.jpg",
        "id_str" : "472412568037101569",
        "id" : 472412568037101569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo5YuklIEAEDKyu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1198,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1998,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1998,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/9EoDaAnIWg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472412571199217664",
    "text" : "The 45 year evolution of spacecraft cockpit design from @NASA Apollo to Discovery to @SpaceX Dragon v2 http:\/\/t.co\/9EoDaAnIWg",
    "id" : 472412571199217664,
    "created_at" : "2014-05-30 16:21:48 +0000",
    "user" : {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "protected" : false,
      "id_str" : "9632752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515558007841632256\/TInyfMw0_normal.jpeg",
      "id" : 9632752,
      "verified" : false
    }
  },
  "id" : 472770117646823424,
  "created_at" : "2014-05-31 16:02:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EB Farmers Market",
      "screen_name" : "EBFarmersMarket",
      "indices" : [ 40, 56 ],
      "id_str" : "135015214",
      "id" : 135015214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/J39o8d7sBD",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/5389dc44498ef1b26d63eef3?s=H-PO39Erj3PTNlWs_XNk_Ouvdak&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9232461469, -78.8773727417 ]
  },
  "id_str" : "472734898378539008",
  "text" : "I'm at Elmwood Bidwell Farmers Market - @ebfarmersmarket (Buffalo, NY) https:\/\/t.co\/J39o8d7sBD",
  "id" : 472734898378539008,
  "created_at" : "2014-05-31 13:42:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/472577461306134528\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/J3ogc9X3pr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo7usmVCUAEYnrO.jpg",
      "id_str" : "472577460890914817",
      "id" : 472577460890914817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo7usmVCUAEYnrO.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/J3ogc9X3pr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472577461306134528",
  "text" : "Holy crap, from a terrible 2 win arena run. http:\/\/t.co\/J3ogc9X3pr",
  "id" : 472577461306134528,
  "created_at" : "2014-05-31 03:17:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472527300719042560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243967725, -78.8792457046 ]
  },
  "id_str" : "472560364798758913",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines huh, not sure!",
  "id" : 472560364798758913,
  "in_reply_to_status_id" : 472527300719042560,
  "created_at" : "2014-05-31 02:09:05 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 0, 7 ],
      "id_str" : "7979212",
      "id" : 7979212
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 22, 30 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472517485896273920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242034461, -78.8771012633 ]
  },
  "id_str" : "472518763426762752",
  "in_reply_to_user_id" : 7979212,
  "text" : "@dankim awesome!! \/cc @dmansen",
  "id" : 472518763426762752,
  "in_reply_to_status_id" : 472517485896273920,
  "created_at" : "2014-05-30 23:23:46 +0000",
  "in_reply_to_screen_name" : "dankim",
  "in_reply_to_user_id_str" : "7979212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 3, 12 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ak0LdxTZbn",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/starting-and-stopping-background-services-with-homebrew",
      "display_url" : "robots.thoughtbot.com\/starting-and-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472476634251923456",
  "text" : "RT @borncamp: Oh my: Brew just got that much better. Stop and Start services with brew. http:\/\/t.co\/ak0LdxTZbn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/ak0LdxTZbn",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/starting-and-stopping-background-services-with-homebrew",
        "display_url" : "robots.thoughtbot.com\/starting-and-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "472239382993186816",
    "text" : "Oh my: Brew just got that much better. Stop and Start services with brew. http:\/\/t.co\/ak0LdxTZbn",
    "id" : 472239382993186816,
    "created_at" : "2014-05-30 04:53:37 +0000",
    "user" : {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "protected" : false,
      "id_str" : "1002573926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425741462311952384\/lPAjNC1C_normal.jpeg",
      "id" : 1002573926,
      "verified" : false
    }
  },
  "id" : 472476634251923456,
  "created_at" : "2014-05-30 20:36:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/52wu1xSTfn",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=BbgyppGqBgg",
      "display_url" : "youtube.com\/watch?v=Bbgypp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472469574885969920",
  "text" : "What testing on iOS is like: https:\/\/t.co\/52wu1xSTfn \"I've just sucked one year of your life away. [...] How do you feel?\" *sobbing*",
  "id" : 472469574885969920,
  "created_at" : "2014-05-30 20:08:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472455943524188160",
  "geo" : { },
  "id_str" : "472456708153806848",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense oh man!",
  "id" : 472456708153806848,
  "in_reply_to_status_id" : 472455943524188160,
  "created_at" : "2014-05-30 19:17:11 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472442432534355968",
  "geo" : { },
  "id_str" : "472442594119540736",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Just using place XCTest for now.",
  "id" : 472442594119540736,
  "in_reply_to_status_id" : 472442432534355968,
  "created_at" : "2014-05-30 18:21:06 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472441853342539776",
  "text" : "Before setting up testing on iOS: \"This is impossible\" After: \"Now it works...How can I test this?\" Much better.",
  "id" : 472441853342539776,
  "created_at" : "2014-05-30 18:18:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472411211003592704",
  "geo" : { },
  "id_str" : "472412647971774465",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Had no idea that was a thing. I just dislike the Apple developer culture in general compared to any OSS community's. Too insular.",
  "id" : 472412647971774465,
  "in_reply_to_status_id" : 472411211003592704,
  "created_at" : "2014-05-30 16:22:06 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472409971339300865",
  "geo" : { },
  "id_str" : "472410503440908288",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss obviously value the first. i despise that the latter is the only way to communicate with the company promotes a terrible culture.",
  "id" : 472410503440908288,
  "in_reply_to_status_id" : 472409971339300865,
  "created_at" : "2014-05-30 16:13:35 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472408944892444672",
  "geo" : { },
  "id_str" : "472409405292412928",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss nope, not convinced standing in lines across the country for a week is worth it when the videos come out next day.",
  "id" : 472409405292412928,
  "in_reply_to_status_id" : 472408944892444672,
  "created_at" : "2014-05-30 16:09:13 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472407853157056512",
  "geo" : { },
  "id_str" : "472408354598318081",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss been considering it, but who knows what will change in the next few weeks. The secret is just checking all the Pods in.",
  "id" : 472408354598318081,
  "in_reply_to_status_id" : 472407853157056512,
  "created_at" : "2014-05-30 16:05:03 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472407210887098368",
  "text" : "Finally got XCode CI bots happy with both KIF and Cocoapods. Not easy, but worth it.",
  "id" : 472407210887098368,
  "created_at" : "2014-05-30 16:00:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0435\u043F\u0435\u043B\u0435\u0432a \u0415\u043B\u0435\u043D\u0430",
      "screen_name" : "angelinamagnum",
      "indices" : [ 0, 15 ],
      "id_str" : "2833368891",
      "id" : 2833368891
    }, {
      "name" : "Kate Hudson",
      "screen_name" : "k88hudson",
      "indices" : [ 16, 26 ],
      "id_str" : "46156776",
      "id" : 46156776
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/J5iXSz478K",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "in_reply_to_status_id_str" : "472403711356960769",
  "geo" : { },
  "id_str" : "472404206347771905",
  "in_reply_to_user_id" : 58708498,
  "text" : "@angelinamagnum @k88hudson well, @nickelcityruby's CFP is still open (and it's close by!) http:\/\/t.co\/J5iXSz478K",
  "id" : 472404206347771905,
  "in_reply_to_status_id" : 472403711356960769,
  "created_at" : "2014-05-30 15:48:34 +0000",
  "in_reply_to_screen_name" : "hopefulcyborg",
  "in_reply_to_user_id_str" : "58708498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Alcorn",
      "screen_name" : "dougalcorn",
      "indices" : [ 0, 11 ],
      "id_str" : "7018192",
      "id" : 7018192
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 12, 19 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472376971910217728",
  "geo" : { },
  "id_str" : "472402597802831872",
  "in_reply_to_user_id" : 7018192,
  "text" : "@dougalcorn @Searls sorry, I maybe get time once a month to check the help site out. I'll see what I can do.",
  "id" : 472402597802831872,
  "in_reply_to_status_id" : 472376971910217728,
  "created_at" : "2014-05-30 15:42:10 +0000",
  "in_reply_to_screen_name" : "dougalcorn",
  "in_reply_to_user_id_str" : "7018192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/472127773533024257\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1Fte64C18T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo1VtV1IQAAR2eM.jpg",
      "id_str" : "472127773386227712",
      "id" : 472127773386227712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo1VtV1IQAAR2eM.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1Fte64C18T"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/PqFGGLvg6d",
      "expanded_url" : "http:\/\/gizmo.do\/nxsMU6c",
      "display_url" : "gizmo.do\/nxsMU6c"
    } ]
  },
  "geo" : { },
  "id_str" : "472211567035949056",
  "text" : "RT @Gizmodo: The death of film is felt hardest in the city built on Kodak's reign http:\/\/t.co\/PqFGGLvg6d http:\/\/t.co\/1Fte64C18T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/472127773533024257\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/1Fte64C18T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo1VtV1IQAAR2eM.jpg",
        "id_str" : "472127773386227712",
        "id" : 472127773386227712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo1VtV1IQAAR2eM.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1Fte64C18T"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/PqFGGLvg6d",
        "expanded_url" : "http:\/\/gizmo.do\/nxsMU6c",
        "display_url" : "gizmo.do\/nxsMU6c"
      } ]
    },
    "geo" : { },
    "id_str" : "472127773533024257",
    "text" : "The death of film is felt hardest in the city built on Kodak's reign http:\/\/t.co\/PqFGGLvg6d http:\/\/t.co\/1Fte64C18T",
    "id" : 472127773533024257,
    "created_at" : "2014-05-29 21:30:07 +0000",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1860214036\/Gizmodo-Twitter-Avatar_normal.jpeg",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 472211567035949056,
  "created_at" : "2014-05-30 03:03:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CleRb",
      "screen_name" : "clerb",
      "indices" : [ 3, 9 ],
      "id_str" : "87196389",
      "id" : 87196389
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472177137349165056",
  "text" : "RT @clerb: FYI, just a reminder that @nickelcityruby call for proposals is open till July 3rd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 26, 41 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472096349224456192",
    "text" : "FYI, just a reminder that @nickelcityruby call for proposals is open till July 3rd",
    "id" : 472096349224456192,
    "created_at" : "2014-05-29 19:25:15 +0000",
    "user" : {
      "name" : "CleRb",
      "screen_name" : "clerb",
      "protected" : false,
      "id_str" : "87196389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785671792\/clerb_avatar_normal.png",
      "id" : 87196389,
      "verified" : false
    }
  },
  "id" : 472177137349165056,
  "created_at" : "2014-05-30 00:46:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "United Pixelworkers",
      "screen_name" : "pixelworkers",
      "indices" : [ 14, 27 ],
      "id_str" : "135201019",
      "id" : 135201019
    }, {
      "name" : "Treehouse",
      "screen_name" : "treehouse",
      "indices" : [ 28, 38 ],
      "id_str" : "14843763",
      "id" : 14843763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472073411536375810",
  "geo" : { },
  "id_str" : "472073508994813953",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @pixelworkers @treehouse Is that Space Mountain? :P",
  "id" : 472073508994813953,
  "in_reply_to_status_id" : 472073411536375810,
  "created_at" : "2014-05-29 17:54:29 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 33, 43 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472067507260387328",
  "geo" : { },
  "id_str" : "472071869625946112",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu I have a strong feeling @aquaranto will!",
  "id" : 472071869625946112,
  "in_reply_to_status_id" : 472067507260387328,
  "created_at" : "2014-05-29 17:47:59 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471788273472655360",
  "geo" : { },
  "id_str" : "471809645078528000",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik Parents of college kids. Bam!",
  "id" : 471809645078528000,
  "in_reply_to_status_id" : 471788273472655360,
  "created_at" : "2014-05-29 00:25:59 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471798565724250112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243158856, -78.8793269152 ]
  },
  "id_str" : "471800042051735552",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc congrats and welcome!",
  "id" : 471800042051735552,
  "in_reply_to_status_id" : 471798565724250112,
  "created_at" : "2014-05-28 23:47:50 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 3, 18 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "Will T",
      "screen_name" : "WillTTaylor",
      "indices" : [ 71, 83 ],
      "id_str" : "35742109",
      "id" : 35742109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471799968907292672",
  "text" : "RT @ChristineLSloc: It only took three months of living in Buffalo for @WillTTaylor and I to get good, professional jobs in our fields. Tel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Will T",
        "screen_name" : "WillTTaylor",
        "indices" : [ 51, 63 ],
        "id_str" : "35742109",
        "id" : 35742109
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471798565724250112",
    "text" : "It only took three months of living in Buffalo for @WillTTaylor and I to get good, professional jobs in our fields. Tell your friends.",
    "id" : 471798565724250112,
    "created_at" : "2014-05-28 23:41:58 +0000",
    "user" : {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "protected" : false,
      "id_str" : "73221502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569953927438024704\/y_kM5xtD_normal.jpeg",
      "id" : 73221502,
      "verified" : false
    }
  },
  "id" : 471799968907292672,
  "created_at" : "2014-05-28 23:47:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471780770147614721",
  "geo" : { },
  "id_str" : "471781269320105984",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik CareBox. Send underwear and cookies to college kids.",
  "id" : 471781269320105984,
  "in_reply_to_status_id" : 471780770147614721,
  "created_at" : "2014-05-28 22:33:14 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/j6OL1DlTI0",
      "expanded_url" : "http:\/\/gifsound.com\/?gif=i.imgur.com\/mOtJQlW.gif&v=zFOvHmFDQuk&s=15",
      "display_url" : "gifsound.com\/?gif=i.imgur.c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471739801394102272",
  "text" : "Current status: http:\/\/t.co\/j6OL1DlTI0",
  "id" : 471739801394102272,
  "created_at" : "2014-05-28 19:48:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/t1aUMdQ8Sg",
      "expanded_url" : "http:\/\/www.audiomack.com\/album\/dj-drastic-x\/phish-vs-hip-hop-phish-hop",
      "display_url" : "audiomack.com\/album\/dj-drast\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471659358174982144",
  "text" : "Phish vs Hiphop. It's about time. http:\/\/t.co\/t1aUMdQ8Sg",
  "id" : 471659358174982144,
  "created_at" : "2014-05-28 14:28:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Book Arts Center",
      "screen_name" : "WNYBAC",
      "indices" : [ 17, 24 ],
      "id_str" : "76130567",
      "id" : 76130567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/HZaALsB865",
      "expanded_url" : "http:\/\/kck.st\/1jpuNSE",
      "display_url" : "kck.st\/1jpuNSE"
    } ]
  },
  "geo" : { },
  "id_str" : "471375615652683776",
  "text" : "Happy to support @WNYBAC and get an awesome Helvetica poster to boot: http:\/\/t.co\/HZaALsB865",
  "id" : 471375615652683776,
  "created_at" : "2014-05-27 19:41:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471327510253166592",
  "geo" : { },
  "id_str" : "471328110814564352",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 \"What's your name, scumbag?\" \"Private Brown, Sir!\" \"Bullshit! For now on you're Private Snoball!\" \"Sir, you meant 'Private Snowball'\"",
  "id" : 471328110814564352,
  "in_reply_to_status_id" : 471327510253166592,
  "created_at" : "2014-05-27 16:32:33 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 4, 18 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 51, 65 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/471324417520189440\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/IvsohLoJdP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bop7D2yCIAE3151.jpg",
      "id_str" : "471324417188831233",
      "id" : 471324417188831233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bop7D2yCIAE3151.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IvsohLoJdP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471324417520189440",
  "text" : "The @coworkbuffalo fridge is now trying to predict @BuffaloRising headlines. http:\/\/t.co\/IvsohLoJdP",
  "id" : 471324417520189440,
  "created_at" : "2014-05-27 16:17:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471306177683267584",
  "text" : "1) Go to your local Craigslist\n2) Search for \"sign\"\n3) Sit back and enjoy the weird",
  "id" : 471306177683267584,
  "created_at" : "2014-05-27 15:05:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 23, 38 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/oqeMuKWGFi",
      "expanded_url" : "https:\/\/twitter.com\/nickelcityruby\/status\/471299167286214656",
      "display_url" : "twitter.com\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471300720528855041",
  "text" : "Would love to hear how @nickelcityruby went for folks last year. Get free tickets for this year by telling us! https:\/\/t.co\/oqeMuKWGFi",
  "id" : 471300720528855041,
  "created_at" : "2014-05-27 14:43:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCR14",
      "indices" : [ 52, 58 ]
    }, {
      "text" : "NCRFreeTix",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471299415747985408",
  "text" : "RT @nickelcityruby: We're giving away 2 free tix to #NCR14! Tweet about the fun last year or what you want this year w\/ #NCRFreeTix b4 6\/10\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCR14",
        "indices" : [ 32, 38 ]
      }, {
        "text" : "NCRFreeTix",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471299167286214656",
    "text" : "We're giving away 2 free tix to #NCR14! Tweet about the fun last year or what you want this year w\/ #NCRFreeTix b4 6\/10 for a chance to win!",
    "id" : 471299167286214656,
    "created_at" : "2014-05-27 14:37:32 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 471299415747985408,
  "created_at" : "2014-05-27 14:38:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0438\u0445\u043E\u0440\u0435\u0432a \u041F\u0435\u043B\u0430\u0433\u0435\u044F",
      "screen_name" : "Cooltendo",
      "indices" : [ 3, 13 ],
      "id_str" : "2833504365",
      "id" : 2833504365
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SuperCooltendo\/status\/471296010174873600\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/tmwIZjUyhg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BophOVcIQAASLyY.jpg",
      "id_str" : "471296009914826752",
      "id" : 471296009914826752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BophOVcIQAASLyY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/tmwIZjUyhg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471296192714772481",
  "text" : "RT @Cooltendo: I like Original Gen Watch Dogs better. http:\/\/t.co\/tmwIZjUyhg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SuperCooltendo\/status\/471296010174873600\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/tmwIZjUyhg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BophOVcIQAASLyY.jpg",
        "id_str" : "471296009914826752",
        "id" : 471296009914826752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BophOVcIQAASLyY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/tmwIZjUyhg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471296010174873600",
    "text" : "I like Original Gen Watch Dogs better. http:\/\/t.co\/tmwIZjUyhg",
    "id" : 471296010174873600,
    "created_at" : "2014-05-27 14:24:59 +0000",
    "user" : {
      "name" : "Philip Armstrong",
      "screen_name" : "SuperCooltendo",
      "protected" : false,
      "id_str" : "36224668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564017970003734528\/5_ZiKOzF_normal.png",
      "id" : 36224668,
      "verified" : false
    }
  },
  "id" : 471296192714772481,
  "created_at" : "2014-05-27 14:25:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/KMQ7pX6XHf",
      "expanded_url" : "http:\/\/i.kinja-img.com\/gawker-media\/image\/upload\/s--Gwlhw4RX--\/qtr9wvgsujidg5zri4im.gif",
      "display_url" : "i.kinja-img.com\/gawker-media\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "470695143763214337",
  "text" : "First few invites out for @nickelcityruby 2014. http:\/\/t.co\/KMQ7pX6XHf",
  "id" : 470695143763214337,
  "created_at" : "2014-05-25 22:37:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Summary Bug",
      "screen_name" : "SummaryBug",
      "indices" : [ 3, 14 ],
      "id_str" : "2500805586",
      "id" : 2500805586
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SummaryBug\/status\/469480969943392256\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ARb03BKdjI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoPudFsIEAE5UBh.jpg",
      "id_str" : "469480969687535617",
      "id" : 469480969687535617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoPudFsIEAE5UBh.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ARb03BKdjI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469952124340555776",
  "text" : "RT @SummaryBug: http:\/\/t.co\/ARb03BKdjI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SummaryBug\/status\/469480969943392256\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/ARb03BKdjI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoPudFsIEAE5UBh.jpg",
        "id_str" : "469480969687535617",
        "id" : 469480969687535617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoPudFsIEAE5UBh.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ARb03BKdjI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469480969943392256",
    "text" : "http:\/\/t.co\/ARb03BKdjI",
    "id" : 469480969943392256,
    "created_at" : "2014-05-22 14:12:40 +0000",
    "user" : {
      "name" : "Summary Bug",
      "screen_name" : "SummaryBug",
      "protected" : false,
      "id_str" : "2500805586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467854682870673408\/5rR5yTfh_normal.jpeg",
      "id" : 2500805586,
      "verified" : false
    }
  },
  "id" : 469952124340555776,
  "created_at" : "2014-05-23 21:24:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 12, 21 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469916361163280384",
  "geo" : { },
  "id_str" : "469916836956344320",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @openhack awesome!",
  "id" : 469916836956344320,
  "in_reply_to_status_id" : 469916361163280384,
  "created_at" : "2014-05-23 19:04:39 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Schulp",
      "screen_name" : "marktimemedia",
      "indices" : [ 3, 17 ],
      "id_str" : "140183551",
      "id" : 140183551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469916121005846528",
  "text" : "RT @marktimemedia: Two branches diverged on Git, and I\u2014 \nI pulled the one less traveled by,  \nAnd now there are several merge conflicts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469462640314421248",
    "text" : "Two branches diverged on Git, and I\u2014 \nI pulled the one less traveled by,  \nAnd now there are several merge conflicts.",
    "id" : 469462640314421248,
    "created_at" : "2014-05-22 12:59:50 +0000",
    "user" : {
      "name" : "Michelle Schulp",
      "screen_name" : "marktimemedia",
      "protected" : false,
      "id_str" : "140183551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446753966752145408\/z1VJ92EH_normal.jpeg",
      "id" : 140183551,
      "verified" : false
    }
  },
  "id" : 469916121005846528,
  "created_at" : "2014-05-23 19:01:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469915067517902848",
  "geo" : { },
  "id_str" : "469915195197124608",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit BUT WHERE WILL I PARK FOR TAILGATING!!?",
  "id" : 469915195197124608,
  "in_reply_to_status_id" : 469915067517902848,
  "created_at" : "2014-05-23 18:58:07 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 3, 9 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 67, 79 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/javan\/status\/469878505761554432\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/owOmJiCB8k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoVYAq_IEAAJMBG.png",
      "id_str" : "469878504692387840",
      "id" : 469878504692387840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoVYAq_IEAAJMBG.png",
      "sizes" : [ {
        "h" : 223,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 95,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/owOmJiCB8k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469879115814670336",
  "text" : "RT @javan: I'm super excited about the project I'm working on with @sstephenson and hope we can share it soon. Here's a teaser: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Stephenson",
        "screen_name" : "sstephenson",
        "indices" : [ 56, 68 ],
        "id_str" : "6707392",
        "id" : 6707392
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/javan\/status\/469878505761554432\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/owOmJiCB8k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoVYAq_IEAAJMBG.png",
        "id_str" : "469878504692387840",
        "id" : 469878504692387840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoVYAq_IEAAJMBG.png",
        "sizes" : [ {
          "h" : 223,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 168,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 95,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 792
        } ],
        "display_url" : "pic.twitter.com\/owOmJiCB8k"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469878505761554432",
    "text" : "I'm super excited about the project I'm working on with @sstephenson and hope we can share it soon. Here's a teaser: http:\/\/t.co\/owOmJiCB8k",
    "id" : 469878505761554432,
    "created_at" : "2014-05-23 16:32:20 +0000",
    "user" : {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "protected" : false,
      "id_str" : "1679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526722729123143680\/0-ppDKP__normal.jpeg",
      "id" : 1679,
      "verified" : false
    }
  },
  "id" : 469879115814670336,
  "created_at" : "2014-05-23 16:34:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/RSj0noKwOW",
      "expanded_url" : "http:\/\/vimeo.com\/96018006",
      "display_url" : "vimeo.com\/96018006"
    } ]
  },
  "geo" : { },
  "id_str" : "469799312419860480",
  "text" : "Some amazing drone photography of Buffalo: http:\/\/t.co\/RSj0noKwOW",
  "id" : 469799312419860480,
  "created_at" : "2014-05-23 11:17:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Sears",
      "screen_name" : "mattsears",
      "indices" : [ 3, 13 ],
      "id_str" : "14579367",
      "id" : 14579367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/3mConHuI5q",
      "expanded_url" : "http:\/\/bit.ly\/1jDa3qR",
      "display_url" : "bit.ly\/1jDa3qR"
    } ]
  },
  "geo" : { },
  "id_str" : "469648361092419584",
  "text" : "RT @mattsears: Heard a lot of buzz about Nickel City Ruby last year. I'm definitely going to try to make it this year - http:\/\/t.co\/3mConHu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/3mConHuI5q",
        "expanded_url" : "http:\/\/bit.ly\/1jDa3qR",
        "display_url" : "bit.ly\/1jDa3qR"
      } ]
    },
    "geo" : { },
    "id_str" : "469218326779273216",
    "text" : "Heard a lot of buzz about Nickel City Ruby last year. I'm definitely going to try to make it this year - http:\/\/t.co\/3mConHuI5q",
    "id" : 469218326779273216,
    "created_at" : "2014-05-21 20:49:01 +0000",
    "user" : {
      "name" : "Matt Sears",
      "screen_name" : "mattsears",
      "protected" : false,
      "id_str" : "14579367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474933129623252992\/qqCE6auG_normal.jpeg",
      "id" : 14579367,
      "verified" : false
    }
  },
  "id" : 469648361092419584,
  "created_at" : "2014-05-23 01:17:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Buffalo Niagara 360",
      "screen_name" : "BN360",
      "indices" : [ 47, 53 ],
      "id_str" : "52472674",
      "id" : 52472674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "entrepreneurs",
      "indices" : [ 80, 94 ]
    }, {
      "text" : "blog",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/FrDVPU9ub3",
      "expanded_url" : "http:\/\/ow.ly\/x73RH",
      "display_url" : "ow.ly\/x73RH"
    } ]
  },
  "geo" : { },
  "id_str" : "469648318960640000",
  "text" : "RT @coworkbuffalo: Glad to be part of this. MT @BN360: #Buffalo as a hotbed for #entrepreneurs - #blog:  http:\/\/t.co\/FrDVPU9ub3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo Niagara 360",
        "screen_name" : "BN360",
        "indices" : [ 28, 34 ],
        "id_str" : "52472674",
        "id" : 52472674
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 36, 44 ]
      }, {
        "text" : "entrepreneurs",
        "indices" : [ 61, 75 ]
      }, {
        "text" : "blog",
        "indices" : [ 78, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/FrDVPU9ub3",
        "expanded_url" : "http:\/\/ow.ly\/x73RH",
        "display_url" : "ow.ly\/x73RH"
      } ]
    },
    "geo" : { },
    "id_str" : "469640272922820608",
    "text" : "Glad to be part of this. MT @BN360: #Buffalo as a hotbed for #entrepreneurs - #blog:  http:\/\/t.co\/FrDVPU9ub3",
    "id" : 469640272922820608,
    "created_at" : "2014-05-23 00:45:41 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 469648318960640000,
  "created_at" : "2014-05-23 01:17:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8917326266, -78.8726393134 ]
  },
  "id_str" : "469102807362985984",
  "text" : "HAPPY BIRTHDAY TO @coworkbuffalo!!",
  "id" : 469102807362985984,
  "created_at" : "2014-05-21 13:09:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469102754502168579",
  "text" : "RT @coworkbuffalo: We turned 2 today! In the last two years we\u2019ve launched, Kickstarted, and moved to Main Street. Excited for the next 2!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469102722323460096",
    "text" : "We turned 2 today! In the last two years we\u2019ve launched, Kickstarted, and moved to Main Street. Excited for the next 2!",
    "id" : 469102722323460096,
    "created_at" : "2014-05-21 13:09:39 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 469102754502168579,
  "created_at" : "2014-05-21 13:09:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468937211405430784",
  "geo" : { },
  "id_str" : "468937378602942464",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik sweet! thanks man.",
  "id" : 468937378602942464,
  "in_reply_to_status_id" : 468937211405430784,
  "created_at" : "2014-05-21 02:12:38 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468907635795054592",
  "geo" : { },
  "id_str" : "468910010014392320",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski thanks for being a part of this wonderful journey with us.",
  "id" : 468910010014392320,
  "in_reply_to_status_id" : 468907635795054592,
  "created_at" : "2014-05-21 00:23:52 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468877064700178434",
  "geo" : { },
  "id_str" : "468888142540705792",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik ha! Didn\u2019t expect to see that tweet. Good luck and let me know if you\u2019re passing through!",
  "id" : 468888142540705792,
  "in_reply_to_status_id" : 468877064700178434,
  "created_at" : "2014-05-20 22:56:59 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468856874117644288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924341706, -78.8792814191 ]
  },
  "id_str" : "468880596794900480",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik awesome! Will merge and ship later.",
  "id" : 468880596794900480,
  "in_reply_to_status_id" : 468856874117644288,
  "created_at" : "2014-05-20 22:27:00 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/6eXip03gv6",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=uXZlJGoK78A",
      "display_url" : "youtube.com\/watch?v=uXZlJG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468850488654319616",
  "text" : "Programming arguments: https:\/\/t.co\/6eXip03gv6",
  "id" : 468850488654319616,
  "created_at" : "2014-05-20 20:27:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCR2014",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/eXldmt291A",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "468838815017099264",
  "text" : "RT @nickelcityruby: The CFP for #NCR2014 is still open! Submit here: http:\/\/t.co\/eXldmt291A before July 3rd!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCR2014",
        "indices" : [ 12, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/eXldmt291A",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "468838396182667264",
    "text" : "The CFP for #NCR2014 is still open! Submit here: http:\/\/t.co\/eXldmt291A before July 3rd!",
    "id" : 468838396182667264,
    "created_at" : "2014-05-20 19:39:18 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 468838815017099264,
  "created_at" : "2014-05-20 19:40:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468786800618520578",
  "geo" : { },
  "id_str" : "468787525683646464",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule why is that even there?",
  "id" : 468787525683646464,
  "in_reply_to_status_id" : 468786800618520578,
  "created_at" : "2014-05-20 16:17:10 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/3aIOdWryMX",
      "expanded_url" : "http:\/\/github.com\/rubygems\/gemwhisperer",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "468640082874757121",
  "geo" : { },
  "id_str" : "468697278127943680",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik http:\/\/t.co\/3aIOdWryMX",
  "id" : 468697278127943680,
  "in_reply_to_status_id" : 468640082874757121,
  "created_at" : "2014-05-20 10:18:33 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 4, 11 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 61, 70 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/XdGFMVJDG5",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/f27c095c85f68c23a55d",
      "display_url" : "gist.github.com\/qrush\/f27c095c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468592906161225728",
  "text" : "Hey @sferik any ideas on how we can make this better for the @rubygems feed? https:\/\/t.co\/XdGFMVJDG5",
  "id" : 468592906161225728,
  "created_at" : "2014-05-20 03:23:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 21, 30 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468576698280075264",
  "text" : "Alright, I think the @rubygems feed is alive again. Push some gems and let's see if it works!",
  "id" : 468576698280075264,
  "created_at" : "2014-05-20 02:19:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468572080938569728",
  "text" : "Ah ha, it's because is.gd is down.",
  "id" : 468572080938569728,
  "created_at" : "2014-05-20 02:01:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/Oaut0YaiV9",
      "expanded_url" : "https:\/\/github.com\/rubygems\/gemwhisperer",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468571578733576192",
  "text" : "Code for that, btw: https:\/\/t.co\/Oaut0YaiV9",
  "id" : 468571578733576192,
  "created_at" : "2014-05-20 01:59:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 3, 12 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/4cN7iG4Tsf",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/c501d569a31a77555652",
      "display_url" : "gist.github.com\/qrush\/c501d569\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468571551378309120",
  "text" : "So @rubygems isn't tweeting because of this: https:\/\/t.co\/4cN7iG4Tsf wtf?",
  "id" : 468571551378309120,
  "created_at" : "2014-05-20 01:58:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 3, 12 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468567808339476480",
  "text" : "RT @rubygems: Is this thing on?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/rubygems.org\" rel=\"nofollow\"\u003ERubyGems.org\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468567725678530560",
    "text" : "Is this thing on?",
    "id" : 468567725678530560,
    "created_at" : "2014-05-20 01:43:46 +0000",
    "user" : {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "protected" : false,
      "id_str" : "14881835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651086638\/rubygems-125x125t_normal.png",
      "id" : 14881835,
      "verified" : false
    }
  },
  "id" : 468567808339476480,
  "created_at" : "2014-05-20 01:44:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468566556792729601",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown hey! still interested in hearing rambling about jam bands and rails?",
  "id" : 468566556792729601,
  "created_at" : "2014-05-20 01:39:07 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468566481978937344",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope did the vim deal with skyway ever work out?",
  "id" : 468566481978937344,
  "created_at" : "2014-05-20 01:38:49 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468443644538544128",
  "text" : "__weak is weak.",
  "id" : 468443644538544128,
  "created_at" : "2014-05-19 17:30:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/AlCrUZlXF3",
      "expanded_url" : "https:\/\/github.com\/kanzure\/pokecrystal\/blob\/master\/text\/sweethoney.asm",
      "display_url" : "github.com\/kanzure\/pokecr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468437871842443264",
  "text" : "Pokemon Crystal disassembly is fascinating. Pretty readable and even some unimplemented features: https:\/\/t.co\/AlCrUZlXF3",
  "id" : 468437871842443264,
  "created_at" : "2014-05-19 17:07:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Pride Center",
      "screen_name" : "ThePrideCenter",
      "indices" : [ 0, 15 ],
      "id_str" : "113651520",
      "id" : 113651520
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468131370233892864",
  "geo" : { },
  "id_str" : "468414267478126592",
  "in_reply_to_user_id" : 113651520,
  "text" : "@ThePrideCenter @coworkbuffalo ah we missed this!! Sorry!",
  "id" : 468414267478126592,
  "in_reply_to_status_id" : 468131370233892864,
  "created_at" : "2014-05-19 15:33:58 +0000",
  "in_reply_to_screen_name" : "ThePrideCenter",
  "in_reply_to_user_id_str" : "113651520",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468391893710430208",
  "geo" : { },
  "id_str" : "468401245456060417",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy Looks legit.",
  "id" : 468401245456060417,
  "in_reply_to_status_id" : 468391893710430208,
  "created_at" : "2014-05-19 14:42:14 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 61, 70 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ZdSEE6aH8B",
      "expanded_url" : "http:\/\/gitready.com\/advanced\/2009\/01\/17\/restoring-lost-commits.html",
      "display_url" : "gitready.com\/advanced\/2009\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468392146454597632",
  "text" : "\"yep 5 years on, this blog post is still doing the business\" @gitready's long tail continues to be long. http:\/\/t.co\/ZdSEE6aH8B",
  "id" : 468392146454597632,
  "created_at" : "2014-05-19 14:06:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/zSVlxk2AZX",
      "expanded_url" : "http:\/\/building.gittip.com",
      "display_url" : "building.gittip.com"
    } ]
  },
  "in_reply_to_status_id_str" : "468354216340520961",
  "geo" : { },
  "id_str" : "468362786800545793",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy I\u2019d like to get a site like http:\/\/t.co\/zSVlxk2AZX going too someday.",
  "id" : 468362786800545793,
  "in_reply_to_status_id" : 468354216340520961,
  "created_at" : "2014-05-19 12:09:24 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 102, 110 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 111, 122 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 123, 135 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/HsNhGmbnN9",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "468354216340520961",
  "geo" : { },
  "id_str" : "468362649042829312",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy cool. Lately my role has been answering Q\u2019s off http:\/\/t.co\/HsNhGmbnN9 when I get time. Ops is @evanphx @samkottler @dwradcliffe",
  "id" : 468362649042829312,
  "in_reply_to_status_id" : 468354216340520961,
  "created_at" : "2014-05-19 12:08:51 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slovenia RUG",
      "screen_name" : "RubySlovenia",
      "indices" : [ 3, 16 ],
      "id_str" : "2473942423",
      "id" : 2473942423
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RubySlovenia\/status\/468120800076500992\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/HjhPVBeYli",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bn8ZYxrIMAIBMG3.png",
      "id_str" : "468120799711604738",
      "id" : 468120799711604738,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bn8ZYxrIMAIBMG3.png",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 983
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 983
      } ],
      "display_url" : "pic.twitter.com\/HjhPVBeYli"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468362349607260160",
  "text" : "RT @RubySlovenia: Rails or Django? This one settles it: http:\/\/t.co\/HjhPVBeYli",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RubySlovenia\/status\/468120800076500992\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/HjhPVBeYli",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bn8ZYxrIMAIBMG3.png",
        "id_str" : "468120799711604738",
        "id" : 468120799711604738,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bn8ZYxrIMAIBMG3.png",
        "sizes" : [ {
          "h" : 275,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 983
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 983
        } ],
        "display_url" : "pic.twitter.com\/HjhPVBeYli"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468120800076500992",
    "text" : "Rails or Django? This one settles it: http:\/\/t.co\/HjhPVBeYli",
    "id" : 468120800076500992,
    "created_at" : "2014-05-18 20:07:50 +0000",
    "user" : {
      "name" : "Slovenia RUG",
      "screen_name" : "RubySlovenia",
      "protected" : false,
      "id_str" : "2473942423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462211603522256897\/22jz3bqx_normal.png",
      "id" : 2473942423,
      "verified" : false
    }
  },
  "id" : 468362349607260160,
  "created_at" : "2014-05-19 12:07:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468349050295947264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241353165, -78.879138896 ]
  },
  "id_str" : "468352470544941056",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy nope. What are you curious about? Seems a little vague",
  "id" : 468352470544941056,
  "in_reply_to_status_id" : 468349050295947264,
  "created_at" : "2014-05-19 11:28:25 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 11, 20 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241283719, -78.8789653197 ]
  },
  "id_str" : "468247303338221570",
  "text" : "Looks like @rubygems (tweet stream) is borked but gem pushes don\u2019t seem to be or more yelling would occur. Will investigate in the morning.",
  "id" : 468247303338221570,
  "created_at" : "2014-05-19 04:30:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468131381621833728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242213255, -78.8790539557 ]
  },
  "id_str" : "468244817126756352",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety buy a google fiber house!",
  "id" : 468244817126756352,
  "in_reply_to_status_id" : 468131381621833728,
  "created_at" : "2014-05-19 04:20:38 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468240999286706177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240916059, -78.8791884665 ]
  },
  "id_str" : "468241207093518336",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren yes.",
  "id" : 468241207093518336,
  "in_reply_to_status_id" : 468240999286706177,
  "created_at" : "2014-05-19 04:06:17 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dadops",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242266733, -78.8790986845 ]
  },
  "id_str" : "468239025048805376",
  "text" : "Don\u2019t know why, but it took me 6 months to try on earplugs during night changes. No ringing ears or headache immediately. \uD83D\uDE49\uD83D\uDC76\uD83D\uDCA4 #dadops",
  "id" : 468239025048805376,
  "created_at" : "2014-05-19 03:57:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/468186129812824064\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/di6taV1g49",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bn9UzdSCcAAxl7H.jpg",
      "id_str" : "468186129280167936",
      "id" : 468186129280167936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bn9UzdSCcAAxl7H.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/di6taV1g49"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243894853, -78.8791838196 ]
  },
  "id_str" : "468186129812824064",
  "text" : "Latest addition to the house: mentions. http:\/\/t.co\/di6taV1g49",
  "id" : 468186129812824064,
  "created_at" : "2014-05-19 00:27:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/QzSEgd5tIx",
      "expanded_url" : "http:\/\/4sq.com\/1iZyZCS",
      "display_url" : "4sq.com\/1iZyZCS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.909979, -78.877312 ]
  },
  "id_str" : "468088237979107328",
  "text" : "SALAD (@ Newbury Street) http:\/\/t.co\/QzSEgd5tIx",
  "id" : 468088237979107328,
  "created_at" : "2014-05-18 17:58:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "James \u26F5\uFE0F Harton",
      "screen_name" : "jamesotron",
      "indices" : [ 9, 20 ],
      "id_str" : "5978432",
      "id" : 5978432
    }, {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 21, 29 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467434144314560512",
  "geo" : { },
  "id_str" : "467615668473307136",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @jamesotron @jcoglan we've shut down gem squatters before that are grabbing tons of gem names with empty gems.",
  "id" : 467615668473307136,
  "in_reply_to_status_id" : 467434144314560512,
  "created_at" : "2014-05-17 10:40:37 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/3sEGq8y5Fz",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=DzBvBFBhpjk",
      "display_url" : "youtube.com\/watch?v=DzBvBF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467041860599296000",
  "text" : "TURNT UP https:\/\/t.co\/3sEGq8y5Fz",
  "id" : 467041860599296000,
  "created_at" : "2014-05-15 20:40:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 71, 77 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/n2hhNVTq1b",
      "expanded_url" : "http:\/\/bl.ocks.org\/mbostock\/061b3929ba0f3964d335",
      "display_url" : "bl.ocks.org\/mbostock\/061b3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466740408504963072",
  "text" : "I think this would knock Basil's socks off. http:\/\/t.co\/n2hhNVTq1b \/cc @jamis",
  "id" : 466740408504963072,
  "created_at" : "2014-05-15 00:42:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Buffalove Music Fest",
      "screen_name" : "BuffaloveFest",
      "indices" : [ 42, 56 ],
      "id_str" : "976207790",
      "id" : 976207790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQnet",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "PinkFloyd",
      "indices" : [ 82, 92 ]
    }, {
      "text" : "DaftPunk",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "AQband",
      "indices" : [ 103, 110 ]
    }, {
      "text" : "livemusic",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "soundcloud",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/wpGI0Cj7FX",
      "expanded_url" : "http:\/\/aqueousband.net\/shows\/2013-06-21",
      "display_url" : "aqueousband.net\/shows\/2013-06-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466686339123916800",
  "text" : "RT @UnclePhilsBlog: @AqueousBand set from @BuffaloveFest 2013 now live on #AQnet. #PinkFloyd #DaftPunk #AQband http:\/\/t.co\/wpGI0Cj7FX #live\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "Buffalove Music Fest",
        "screen_name" : "BuffaloveFest",
        "indices" : [ 22, 36 ],
        "id_str" : "976207790",
        "id" : 976207790
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQnet",
        "indices" : [ 54, 60 ]
      }, {
        "text" : "PinkFloyd",
        "indices" : [ 62, 72 ]
      }, {
        "text" : "DaftPunk",
        "indices" : [ 73, 82 ]
      }, {
        "text" : "AQband",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "livemusic",
        "indices" : [ 114, 124 ]
      }, {
        "text" : "soundcloud",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/wpGI0Cj7FX",
        "expanded_url" : "http:\/\/aqueousband.net\/shows\/2013-06-21",
        "display_url" : "aqueousband.net\/shows\/2013-06-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466685907710779392",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand set from @BuffaloveFest 2013 now live on #AQnet. #PinkFloyd #DaftPunk #AQband http:\/\/t.co\/wpGI0Cj7FX #livemusic #soundcloud",
    "id" : 466685907710779392,
    "created_at" : "2014-05-14 21:06:05 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 466686339123916800,
  "created_at" : "2014-05-14 21:07:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/w9nTXN8v1j",
      "expanded_url" : "http:\/\/glenngreenwald.net\/pdf\/NoPlaceToHide-Documents-Compressed.pdf",
      "display_url" : "glenngreenwald.net\/pdf\/NoPlaceToH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466623720027873280",
  "text" : "Holy shit - http:\/\/t.co\/w9nTXN8v1j",
  "id" : 466623720027873280,
  "created_at" : "2014-05-14 16:58:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466585179445014528",
  "geo" : { },
  "id_str" : "466586218138857472",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog might be a cache wonk.",
  "id" : 466586218138857472,
  "in_reply_to_status_id" : 466585179445014528,
  "created_at" : "2014-05-14 14:29:57 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466581247452790785",
  "geo" : { },
  "id_str" : "466581853160615936",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog yeah, no idea why. o_O",
  "id" : 466581853160615936,
  "in_reply_to_status_id" : 466581247452790785,
  "created_at" : "2014-05-14 14:12:37 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466573250458181632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242231549, -78.8795407789 ]
  },
  "id_str" : "466574571433635840",
  "in_reply_to_user_id" : 896641,
  "text" : "@JZ not getting my hopes up for a trend.",
  "id" : 466574571433635840,
  "in_reply_to_status_id" : 466573250458181632,
  "created_at" : "2014-05-14 13:43:41 +0000",
  "in_reply_to_screen_name" : "jasonzimdars",
  "in_reply_to_user_id_str" : "896641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242000121, -78.8788233988 ]
  },
  "id_str" : "466550523320348672",
  "text" : "First uninterrupted night of sleep in over 4 months. \uD83D\uDE02",
  "id" : 466550523320348672,
  "created_at" : "2014-05-14 12:08:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Symbolia",
      "screen_name" : "symboliamag",
      "indices" : [ 45, 57 ],
      "id_str" : "2864891283",
      "id" : 2864891283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/2tkYFagCX7",
      "expanded_url" : "https:\/\/medium.com\/the-nib\/fa1d5cf42512?source=tw-b2f87f46f24b-1400018090938&utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com\/the-nib\/fa1d5c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466395202849349633",
  "text" : "RT @Medium: \u201CWhat Happened to Lake Erie?\u201D by @SymboliaMag https:\/\/t.co\/2tkYFagCX7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Symbolia",
        "screen_name" : "symboliamag",
        "indices" : [ 33, 45 ],
        "id_str" : "2864891283",
        "id" : 2864891283
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/2tkYFagCX7",
        "expanded_url" : "https:\/\/medium.com\/the-nib\/fa1d5cf42512?source=tw-b2f87f46f24b-1400018090938&utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com\/the-nib\/fa1d5c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466352440590471169",
    "text" : "\u201CWhat Happened to Lake Erie?\u201D by @SymboliaMag https:\/\/t.co\/2tkYFagCX7",
    "id" : 466352440590471169,
    "created_at" : "2014-05-13 23:01:00 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/498896933360898049\/Io6eZONw_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 466395202849349633,
  "created_at" : "2014-05-14 01:50:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Ward",
      "screen_name" : "eviltrout",
      "indices" : [ 0, 10 ],
      "id_str" : "16712921",
      "id" : 16712921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466322234022563840",
  "geo" : { },
  "id_str" : "466381209376133123",
  "in_reply_to_user_id" : 16712921,
  "text" : "@eviltrout well, it's an old\/abandoned building on the East Side, facing a highway, that probably needs a lot of work\/$$$.",
  "id" : 466381209376133123,
  "in_reply_to_status_id" : 466322234022563840,
  "created_at" : "2014-05-14 00:55:19 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466322456274563074",
  "geo" : { },
  "id_str" : "466377594913697795",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams way too big! (right now)",
  "id" : 466377594913697795,
  "in_reply_to_status_id" : 466322456274563074,
  "created_at" : "2014-05-14 00:40:58 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/7DrrB14G2v",
      "expanded_url" : "http:\/\/viewsofbuffalo.blogspot.com\/2014\/05\/st-francis-de-sales-church-gets.html",
      "display_url" : "viewsofbuffalo.blogspot.com\/2014\/05\/st-fra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466321444709089280",
  "text" : "Beautiful church. Renowned architect. Only $150K. http:\/\/t.co\/7DrrB14G2v",
  "id" : 466321444709089280,
  "created_at" : "2014-05-13 20:57:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Walsh",
      "screen_name" : "joshwalsh",
      "indices" : [ 0, 10 ],
      "id_str" : "12449232",
      "id" : 12449232
    }, {
      "name" : "Lucas Andi\u00F3n",
      "screen_name" : "bugyou",
      "indices" : [ 11, 18 ],
      "id_str" : "17335510",
      "id" : 17335510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/JPuhnhtxsP",
      "expanded_url" : "https:\/\/ifttt.com\/p\/qrush",
      "display_url" : "ifttt.com\/p\/qrush"
    } ]
  },
  "in_reply_to_status_id_str" : "466320297218801665",
  "geo" : { },
  "id_str" : "466320486830735360",
  "in_reply_to_user_id" : 12449232,
  "text" : "@joshwalsh @bugyou https:\/\/t.co\/JPuhnhtxsP",
  "id" : 466320486830735360,
  "in_reply_to_status_id" : 466320297218801665,
  "created_at" : "2014-05-13 20:54:02 +0000",
  "in_reply_to_screen_name" : "joshwalsh",
  "in_reply_to_user_id_str" : "12449232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 24, 36 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/DxUTNaBiOz",
      "expanded_url" : "http:\/\/aqueousband.net\/shows\/2014-02-26",
      "display_url" : "aqueousband.net\/shows\/2014-02-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466305004890890240",
  "text" : "Wrap up today with some @AqueousBand jams blended with the Beatles: http:\/\/t.co\/DxUTNaBiOz",
  "id" : 466305004890890240,
  "created_at" : "2014-05-13 19:52:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/uH5RhFiG55",
      "expanded_url" : "https:\/\/developers.google.com\/chrome-developer-tools\/docs\/mobile-emulation",
      "display_url" : "developers.google.com\/chrome-develop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466301461970694145",
  "text" : "How have I not seen the Emulation panel for Chrome's inspector before? Wow: https:\/\/t.co\/uH5RhFiG55",
  "id" : 466301461970694145,
  "created_at" : "2014-05-13 19:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/hm7aCgJfTi",
      "expanded_url" : "http:\/\/vimeo.com\/95066828",
      "display_url" : "vimeo.com\/95066828"
    } ]
  },
  "geo" : { },
  "id_str" : "466286397247074304",
  "text" : "This talk is the best I've seen in a while: http:\/\/t.co\/hm7aCgJfTi",
  "id" : 466286397247074304,
  "created_at" : "2014-05-13 18:38:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466269747299250178",
  "geo" : { },
  "id_str" : "466270739469856769",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope Sure!",
  "id" : 466270739469856769,
  "in_reply_to_status_id" : 466269747299250178,
  "created_at" : "2014-05-13 17:36:21 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/466264470893772801\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/NzNFW4JkSj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BniBEJaCQAIK0sU.png",
      "id_str" : "466264469677424642",
      "id" : 466264469677424642,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BniBEJaCQAIK0sU.png",
      "sizes" : [ {
        "h" : 890,
        "resize" : "fit",
        "w" : 1448
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NzNFW4JkSj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466264470893772801",
  "text" : "Oops. http:\/\/t.co\/NzNFW4JkSj",
  "id" : 466264470893772801,
  "created_at" : "2014-05-13 17:11:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466258579746742272",
  "geo" : { },
  "id_str" : "466258828451794944",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope just haven't included it. Also, there's not a lot of tests.",
  "id" : 466258828451794944,
  "in_reply_to_status_id" : 466258579746742272,
  "created_at" : "2014-05-13 16:49:02 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 143, 144 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebeatles",
      "indices" : [ 90, 101 ]
    }, {
      "text" : "AQband",
      "indices" : [ 137, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ri4fWka370",
      "expanded_url" : "http:\/\/AQ.NET",
      "display_url" : "AQ.NET"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/5Brjr17Q59",
      "expanded_url" : "http:\/\/aqueousband.net\/shows\/2014-02-26",
      "display_url" : "aqueousband.net\/shows\/2014-02-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466229463810727936",
  "text" : "RT @UnclePhilsBlog: A&amp;V for some shows now enabled on http:\/\/t.co\/ri4fWka370  Sample: #thebeatles night here: http:\/\/t.co\/5Brjr17Q59 #AQban\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 129, 135 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thebeatles",
        "indices" : [ 70, 81 ]
      }, {
        "text" : "AQband",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/ri4fWka370",
        "expanded_url" : "http:\/\/AQ.NET",
        "display_url" : "AQ.NET"
      }, {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/5Brjr17Q59",
        "expanded_url" : "http:\/\/aqueousband.net\/shows\/2014-02-26",
        "display_url" : "aqueousband.net\/shows\/2014-02-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466221866395660288",
    "text" : "A&amp;V for some shows now enabled on http:\/\/t.co\/ri4fWka370  Sample: #thebeatles night here: http:\/\/t.co\/5Brjr17Q59 #AQband cc: @qrush TY!",
    "id" : 466221866395660288,
    "created_at" : "2014-05-13 14:22:09 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 466229463810727936,
  "created_at" : "2014-05-13 14:52:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayrton De Craene",
      "screen_name" : "ayrtonbe",
      "indices" : [ 0, 9 ],
      "id_str" : "77175491",
      "id" : 77175491
    }, {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 10, 16 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466124157710000128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9276800186, -78.8776774304 ]
  },
  "id_str" : "466170935498637312",
  "in_reply_to_user_id" : 77175491,
  "text" : "@ayrtonbe @tpope thanks! Would love to answer any questions if you have them.",
  "id" : 466170935498637312,
  "in_reply_to_status_id" : 466124157710000128,
  "created_at" : "2014-05-13 10:59:46 +0000",
  "in_reply_to_screen_name" : "ayrtonbe",
  "in_reply_to_user_id_str" : "77175491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timbuk2",
      "screen_name" : "timbuk2",
      "indices" : [ 0, 8 ],
      "id_str" : "14995801",
      "id" : 14995801
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 9, 18 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465950516275466241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924241968, -78.8790313649 ]
  },
  "id_str" : "466009760001576961",
  "in_reply_to_user_id" : 14995801,
  "text" : "@timbuk2 @bquarant what about biking medical professionals?",
  "id" : 466009760001576961,
  "in_reply_to_status_id" : 465950516275466241,
  "created_at" : "2014-05-13 00:19:19 +0000",
  "in_reply_to_screen_name" : "timbuk2",
  "in_reply_to_user_id_str" : "14995801",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465941580570824704",
  "geo" : { },
  "id_str" : "465942590156599296",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems Yow Mama, you better call SCRAPPY",
  "id" : 465942590156599296,
  "in_reply_to_status_id" : 465941580570824704,
  "created_at" : "2014-05-12 19:52:24 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/Qh94HQzl1M",
      "expanded_url" : "http:\/\/toronto.en.craigslist.ca\/tor\/app\/4453897971.html",
      "display_url" : "toronto.en.craigslist.ca\/tor\/app\/445389\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465941082237173760",
  "text" : "OMG, I better call Scrappy!! http:\/\/t.co\/Qh94HQzl1M",
  "id" : 465941082237173760,
  "created_at" : "2014-05-12 19:46:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James \u26F5\uFE0F Harton",
      "screen_name" : "jamesotron",
      "indices" : [ 0, 11 ],
      "id_str" : "5978432",
      "id" : 5978432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/OZ3ksR9Gnl",
      "expanded_url" : "http:\/\/guides.rubygems.org\/run-your-own-gem-server\/",
      "display_url" : "guides.rubygems.org\/run-your-own-g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "465937619902160897",
  "geo" : { },
  "id_str" : "465938818420318209",
  "in_reply_to_user_id" : 5978432,
  "text" : "@jamesotron check out `gem mirror --help` and have plenty of disk space. http:\/\/t.co\/OZ3ksR9Gnl could use some help here.",
  "id" : 465938818420318209,
  "in_reply_to_status_id" : 465937619902160897,
  "created_at" : "2014-05-12 19:37:25 +0000",
  "in_reply_to_screen_name" : "jamesotron",
  "in_reply_to_user_id_str" : "5978432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 110, 125 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/RPlIy1WIgq",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/182659662\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465938606062710785",
  "text" : "RT @wnyruby: May Meetup: Tomorrow! We're meeting at 7pm on May 13th at Cowork Buffalo: http:\/\/t.co\/RPlIy1WIgq @1ofyourmeteors is talking ab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Josef",
        "screen_name" : "1ofyourmeteors",
        "indices" : [ 97, 112 ],
        "id_str" : "155998525",
        "id" : 155998525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/RPlIy1WIgq",
        "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/182659662\/",
        "display_url" : "meetup.com\/Western-New-Yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "465938402341163008",
    "text" : "May Meetup: Tomorrow! We're meeting at 7pm on May 13th at Cowork Buffalo: http:\/\/t.co\/RPlIy1WIgq @1ofyourmeteors is talking about Enumerator",
    "id" : 465938402341163008,
    "created_at" : "2014-05-12 19:35:46 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 465938606062710785,
  "created_at" : "2014-05-12 19:36:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ara T. Howard",
      "screen_name" : "drawohara",
      "indices" : [ 0, 10 ],
      "id_str" : "17058191",
      "id" : 17058191
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 31, 39 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 40, 50 ],
      "id_str" : "15031577",
      "id" : 15031577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465921255460192257",
  "geo" : { },
  "id_str" : "465921427816738816",
  "in_reply_to_user_id" : 17058191,
  "text" : "@drawohara yipes, no idea. \/cc @evanphx @tcopeland (sounds like users weren't emailed about this?)",
  "id" : 465921427816738816,
  "in_reply_to_status_id" : 465921255460192257,
  "created_at" : "2014-05-12 18:28:19 +0000",
  "in_reply_to_screen_name" : "drawohara",
  "in_reply_to_user_id_str" : "17058191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 0, 10 ],
      "id_str" : "15031577",
      "id" : 15031577
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 11, 19 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465915058615513089",
  "geo" : { },
  "id_str" : "465915747168833536",
  "in_reply_to_user_id" : 15031577,
  "text" : "@tcopeland @evanphx hoping the plans include a little static site on github pages explaining where things went, maybe a little dedication...",
  "id" : 465915747168833536,
  "in_reply_to_status_id" : 465915058615513089,
  "created_at" : "2014-05-12 18:05:45 +0000",
  "in_reply_to_screen_name" : "tcopeland",
  "in_reply_to_user_id_str" : "15031577",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aedAxxvGEu",
      "expanded_url" : "http:\/\/RubyForge.org",
      "display_url" : "RubyForge.org"
    } ]
  },
  "geo" : { },
  "id_str" : "465915514661789696",
  "text" : "http:\/\/t.co\/aedAxxvGEu is getting shut down this week, wow.",
  "id" : 465915514661789696,
  "created_at" : "2014-05-12 18:04:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 21, 35 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/465864090561150976\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/VFzawMpF50",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BncU6_fCcAExxBD.jpg",
      "id_str" : "465864090162720769",
      "id" : 465864090162720769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BncU6_fCcAExxBD.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VFzawMpF50"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8916608775, -78.8726548199 ]
  },
  "id_str" : "465864090561150976",
  "text" : "20 dudes in front of @coworkbuffalo wondering when the first BMW from the suburbs will crash into the railroad gate http:\/\/t.co\/VFzawMpF50",
  "id" : 465864090561150976,
  "created_at" : "2014-05-12 14:40:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465848642231107585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245287506, -78.8791937941 ]
  },
  "id_str" : "465851004014301184",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt @coworkbuffalo wat?",
  "id" : 465851004014301184,
  "in_reply_to_status_id" : 465848642231107585,
  "created_at" : "2014-05-12 13:48:29 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Ws6nuL8IuA",
      "expanded_url" : "https:\/\/twitter.com\/BfloTheatreDis\/status\/465846829587120129",
      "display_url" : "twitter.com\/BfloTheatreDis\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924580006, -78.8791569975 ]
  },
  "id_str" : "465847670146629632",
  "text" : "I think @coworkbuffalo is getting trees today! https:\/\/t.co\/Ws6nuL8IuA",
  "id" : 465847670146629632,
  "created_at" : "2014-05-12 13:35:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 27, 36 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/465690353819856896\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/O8Ad90UNk8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnZ26MhCUAIee5A.jpg",
      "id_str" : "465690353643704322",
      "id" : 465690353643704322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnZ26MhCUAIee5A.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O8Ad90UNk8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465690353819856896",
  "text" : "I'll take one of each. \/cc @shildner http:\/\/t.co\/O8Ad90UNk8",
  "id" : 465690353819856896,
  "created_at" : "2014-05-12 03:10:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465543410732912642",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9389740231, -78.8826972581 ]
  },
  "id_str" : "465547847510011904",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y John Adams wrote a lot of letters.",
  "id" : 465547847510011904,
  "in_reply_to_status_id" : 465543410732912642,
  "created_at" : "2014-05-11 17:43:50 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465521582077521922",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243254476, -78.8790785429 ]
  },
  "id_str" : "465524408316993536",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald dago is another good one.",
  "id" : 465524408316993536,
  "in_reply_to_status_id" : 465521582077521922,
  "created_at" : "2014-05-11 16:10:42 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465523281466896384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242205125, -78.8788903525 ]
  },
  "id_str" : "465524177936863233",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis dump a box of tea in the president\u2019s pool",
  "id" : 465524177936863233,
  "in_reply_to_status_id" : 465523281466896384,
  "created_at" : "2014-05-11 16:09:47 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243220356, -78.8787123753 ]
  },
  "id_str" : "465500162354204674",
  "text" : "FaceTime couldn\u2019t connect\u2026 needs some surge pricing.",
  "id" : 465500162354204674,
  "created_at" : "2014-05-11 14:34:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465294400411930624",
  "geo" : { },
  "id_str" : "465305493863297024",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc listening to some Phish? :)",
  "id" : 465305493863297024,
  "in_reply_to_status_id" : 465294400411930624,
  "created_at" : "2014-05-11 01:40:49 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465251047204610048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243331843, -78.8792745541 ]
  },
  "id_str" : "465290112515833856",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr nothing wrong with this. It\u2019s ok to treat software as \u201Cdone\u201D (especially with MIT) there\u2019s always &gt; 1 use case.",
  "id" : 465290112515833856,
  "in_reply_to_status_id" : 465251047204610048,
  "created_at" : "2014-05-11 00:39:42 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465248071061098496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242750745, -78.8792639044 ]
  },
  "id_str" : "465250646052970496",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr or turn issues off? Also, because it\u2019s free and can store tons of stuff for nothing.",
  "id" : 465250646052970496,
  "in_reply_to_status_id" : 465248071061098496,
  "created_at" : "2014-05-10 22:02:52 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EB Farmers Market",
      "screen_name" : "EBFarmersMarket",
      "indices" : [ 40, 56 ],
      "id_str" : "135015214",
      "id" : 135015214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/j4sfSFfcn8",
      "expanded_url" : "http:\/\/4sq.com\/1sdxlmi",
      "display_url" : "4sq.com\/1sdxlmi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9232461469, -78.8773727417 ]
  },
  "id_str" : "465130026791604225",
  "text" : "I'm at Elmwood Bidwell Farmers Market - @ebfarmersmarket (Buffalo, NY) w\/ 2 others http:\/\/t.co\/j4sfSFfcn8",
  "id" : 465130026791604225,
  "created_at" : "2014-05-10 14:03:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464943645888892928",
  "geo" : { },
  "id_str" : "465124610850054144",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer daannng",
  "id" : 465124610850054144,
  "in_reply_to_status_id" : 464943645888892928,
  "created_at" : "2014-05-10 13:42:03 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9246032937, -78.8793389743 ]
  },
  "id_str" : "464916779962101761",
  "text" : "Finally ran out of cards in a Hearthstone match\u2026and won somehow! (You lose a health each turn instead of drawing)",
  "id" : 464916779962101761,
  "created_at" : "2014-05-09 23:56:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/NOVhiYuM1L",
      "expanded_url" : "http:\/\/www.bay12games.com\/dwarves\/",
      "display_url" : "bay12games.com\/dwarves\/"
    } ]
  },
  "geo" : { },
  "id_str" : "464839580219236352",
  "text" : "Almost 2 years without a dwarf fortress release. :( http:\/\/t.co\/NOVhiYuM1L",
  "id" : 464839580219236352,
  "created_at" : "2014-05-09 18:49:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 21, 32 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/464824413146583040\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/zE3q9QL68L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnNjVzCIMAAoHV2.jpg",
      "id_str" : "464824412676829184",
      "id" : 464824412676829184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnNjVzCIMAAoHV2.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zE3q9QL68L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8916938603, -78.8727582526 ]
  },
  "id_str" : "464824413146583040",
  "text" : "I found a way to get @kevinpurdy to more baseball games. http:\/\/t.co\/zE3q9QL68L",
  "id" : 464824413146583040,
  "created_at" : "2014-05-09 17:49:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canalside Buffalo",
      "screen_name" : "CanalsideBflo",
      "indices" : [ 52, 66 ],
      "id_str" : "54994502",
      "id" : 54994502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/XtZhyU4qpq",
      "expanded_url" : "http:\/\/4sq.com\/1kYjDQn",
      "display_url" : "4sq.com\/1kYjDQn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8764672937, -78.8786387444 ]
  },
  "id_str" : "464815321824907265",
  "text" : "Best place to sit down and have lunch downtown. (at @CanalsideBflo) http:\/\/t.co\/XtZhyU4qpq",
  "id" : 464815321824907265,
  "created_at" : "2014-05-09 17:13:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/464805080525713408\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/rKkPoDtWUY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnNRwbsCMAAYm2Q.png",
      "id_str" : "464805079057313792",
      "id" : 464805079057313792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnNRwbsCMAAYm2Q.png",
      "sizes" : [ {
        "h" : 41,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 72,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 1348
      } ],
      "display_url" : "pic.twitter.com\/rKkPoDtWUY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464805080525713408",
  "text" : "Some say Apple isn't good at web services. Well some $localizedApplePundits are probably $localizedAppleOpinion. http:\/\/t.co\/rKkPoDtWUY",
  "id" : 464805080525713408,
  "created_at" : "2014-05-09 16:32:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommitStrip",
      "screen_name" : "commit_strip",
      "indices" : [ 3, 16 ],
      "id_str" : "2488240298",
      "id" : 2488240298
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CommitStrip\/status\/464045477840044032\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/M51I5Doo1C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnCe5z7IUAAMpon.jpg",
      "id_str" : "464045477647110144",
      "id" : 464045477647110144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnCe5z7IUAAMpon.jpg",
      "sizes" : [ {
        "h" : 933,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 861,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/M51I5Doo1C"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/HAUPs7pJcu",
      "expanded_url" : "http:\/\/www.commitstrip.com\/en\/2014\/05\/07\/the-truth-behind-open-source-apps\/?utm_source=rss&utm_medium=rss&utm_campaign=the-truth-behind-open-source-apps",
      "display_url" : "commitstrip.com\/en\/2014\/05\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464794385427996672",
  "text" : "RT @commit_strip: The truth behind Open Source apps http:\/\/t.co\/HAUPs7pJcu http:\/\/t.co\/M51I5Doo1C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CommitStrip\/status\/464045477840044032\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/M51I5Doo1C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnCe5z7IUAAMpon.jpg",
        "id_str" : "464045477647110144",
        "id" : 464045477647110144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnCe5z7IUAAMpon.jpg",
        "sizes" : [ {
          "h" : 933,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 933,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 861,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/M51I5Doo1C"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/HAUPs7pJcu",
        "expanded_url" : "http:\/\/www.commitstrip.com\/en\/2014\/05\/07\/the-truth-behind-open-source-apps\/?utm_source=rss&utm_medium=rss&utm_campaign=the-truth-behind-open-source-apps",
        "display_url" : "commitstrip.com\/en\/2014\/05\/07\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "464045477840044032",
    "text" : "The truth behind Open Source apps http:\/\/t.co\/HAUPs7pJcu http:\/\/t.co\/M51I5Doo1C",
    "id" : 464045477840044032,
    "created_at" : "2014-05-07 14:13:58 +0000",
    "user" : {
      "name" : "CommitStrip",
      "screen_name" : "CommitStrip",
      "protected" : false,
      "id_str" : "2414205444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465132577582370816\/dQoNAWLr_normal.jpeg",
      "id" : 2414205444,
      "verified" : false
    }
  },
  "id" : 464794385427996672,
  "created_at" : "2014-05-09 15:49:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 9, 21 ],
      "id_str" : "5716862",
      "id" : 5716862
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 22, 29 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464599007055335425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924190216, -78.8791500557 ]
  },
  "id_str" : "464734748229652480",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @tristandunn @jayroh already planning a trip to Boston for week of 7\/1!",
  "id" : 464734748229652480,
  "in_reply_to_status_id" : 464599007055335425,
  "created_at" : "2014-05-09 11:52:52 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 0, 8 ],
      "id_str" : "33588043",
      "id" : 33588043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464559002823974915",
  "geo" : { },
  "id_str" : "464564302020874242",
  "in_reply_to_user_id" : 33588043,
  "text" : "@Pete716 how?",
  "id" : 464564302020874242,
  "in_reply_to_status_id" : 464559002823974915,
  "created_at" : "2014-05-09 00:35:35 +0000",
  "in_reply_to_screen_name" : "Pete716",
  "in_reply_to_user_id_str" : "33588043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 20, 29 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/464532184456777729\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/m6fqQonEhi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnJZj3XIUAA9Jru.png",
      "id_str" : "464532184263839744",
      "id" : 464532184263839744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnJZj3XIUAA9Jru.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/m6fqQonEhi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9261835511, -78.8768201359 ]
  },
  "id_str" : "464532184456777729",
  "text" : "I am going to blame @mittense for all of these. http:\/\/t.co\/m6fqQonEhi",
  "id" : 464532184456777729,
  "created_at" : "2014-05-08 22:27:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CanalsideBflo\/status\/464527181876850688\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/4pvIRRs0g1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnJVAocCcAAUWtK.jpg",
      "id_str" : "464527180915961856",
      "id" : 464527180915961856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnJVAocCcAAUWtK.jpg",
      "sizes" : [ {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1118
      } ],
      "display_url" : "pic.twitter.com\/4pvIRRs0g1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.926448731, -78.8769487869 ]
  },
  "id_str" : "464531261810544640",
  "text" : "moe. and TTB at Canalside in June?! YES! http:\/\/t.co\/4pvIRRs0g1",
  "id" : 464531261810544640,
  "created_at" : "2014-05-08 22:24:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeseph Meyers",
      "screen_name" : "jesephm",
      "indices" : [ 0, 8 ],
      "id_str" : "277334498",
      "id" : 277334498
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464417387240902657",
  "geo" : { },
  "id_str" : "464512752090746881",
  "in_reply_to_user_id" : 277334498,
  "text" : "@jesephm @coworkbuffalo I'd happily fill in more spots if you can tell me where!",
  "id" : 464512752090746881,
  "in_reply_to_status_id" : 464417387240902657,
  "created_at" : "2014-05-08 21:10:44 +0000",
  "in_reply_to_screen_name" : "jesephm",
  "in_reply_to_user_id_str" : "277334498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464510288352792576",
  "geo" : { },
  "id_str" : "464511011186159616",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi what app is that?",
  "id" : 464511011186159616,
  "in_reply_to_status_id" : 464510288352792576,
  "created_at" : "2014-05-08 21:03:49 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464461172029546496",
  "geo" : { },
  "id_str" : "464461419552194560",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik awwww",
  "id" : 464461419552194560,
  "in_reply_to_status_id" : 464461172029546496,
  "created_at" : "2014-05-08 17:46:46 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464447925016592384",
  "geo" : { },
  "id_str" : "464448072127234048",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella I think I just disabled them - Settings &gt; Web Notifications",
  "id" : 464448072127234048,
  "in_reply_to_status_id" : 464447925016592384,
  "created_at" : "2014-05-08 16:53:44 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464429040192200704",
  "geo" : { },
  "id_str" : "464429806952521728",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Not even using jQuery on mobile. Don't need it yet!",
  "id" : 464429806952521728,
  "in_reply_to_status_id" : 464429040192200704,
  "created_at" : "2014-05-08 15:41:09 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464427015156678656",
  "geo" : { },
  "id_str" : "464427347110666240",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael that's also a huge concern for me - not being instantly breakable. have dropped it many times without fear",
  "id" : 464427347110666240,
  "in_reply_to_status_id" : 464427015156678656,
  "created_at" : "2014-05-08 15:31:22 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason",
      "screen_name" : "peregrine",
      "indices" : [ 0, 10 ],
      "id_str" : "896131",
      "id" : 896131
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 104, 114 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464426861334761472",
  "geo" : { },
  "id_str" : "464427252336181249",
  "in_reply_to_user_id" : 896131,
  "text" : "@peregrine our next gen is pure ObjC. We decided to dig in and learn the platform as a team. And having @zachwaugh has been a huge help!",
  "id" : 464427252336181249,
  "in_reply_to_status_id" : 464426861334761472,
  "created_at" : "2014-05-08 15:31:00 +0000",
  "in_reply_to_screen_name" : "peregrine",
  "in_reply_to_user_id_str" : "896131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/hQWbx3TBMA",
      "expanded_url" : "http:\/\/37svn.com\/3743",
      "display_url" : "37svn.com\/3743"
    } ]
  },
  "geo" : { },
  "id_str" : "464426367874895872",
  "text" : "Our hybrid approach to building native Basecamp apps: http:\/\/t.co\/hQWbx3TBMA (HTML5 is not dead!)",
  "id" : 464426367874895872,
  "created_at" : "2014-05-08 15:27:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464425838633439233",
  "geo" : { },
  "id_str" : "464426141520900096",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael I've got a blue one and love it. Don't trust Apple with my fingerprint.",
  "id" : 464426141520900096,
  "in_reply_to_status_id" : 464425838633439233,
  "created_at" : "2014-05-08 15:26:35 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464422719757357056",
  "geo" : { },
  "id_str" : "464423747634487296",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh yep, read the thread!",
  "id" : 464423747634487296,
  "in_reply_to_status_id" : 464422719757357056,
  "created_at" : "2014-05-08 15:17:04 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie A. Young",
      "screen_name" : "jessieay",
      "indices" : [ 0, 9 ],
      "id_str" : "20801787",
      "id" : 20801787
    }, {
      "name" : "Rails Girls",
      "screen_name" : "railsgirls",
      "indices" : [ 10, 21 ],
      "id_str" : "213280469",
      "id" : 213280469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464422431126327296",
  "geo" : { },
  "id_str" : "464423626393923584",
  "in_reply_to_user_id" : 20801787,
  "text" : "@jessieay @railsgirls I bet it's doable. It's a pretty standard rails site - simple list with contact info for each. Feature set is small.",
  "id" : 464423626393923584,
  "in_reply_to_status_id" : 464422431126327296,
  "created_at" : "2014-05-08 15:16:35 +0000",
  "in_reply_to_screen_name" : "jessieay",
  "in_reply_to_user_id_str" : "20801787",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rails Girls",
      "screen_name" : "railsgirls",
      "indices" : [ 109, 120 ],
      "id_str" : "213280469",
      "id" : 213280469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/E4ptuMPDMy",
      "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/rubygems-org\/niS5ZO9DNgk\/SHUzS-8Qx68J",
      "display_url" : "groups.google.com\/d\/msg\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464420057284476928",
  "text" : "Ideas are brewing for a RubyGems Adoption Center: https:\/\/t.co\/E4ptuMPDMy Anyone interested? Could this be a @railsgirls project?",
  "id" : 464420057284476928,
  "created_at" : "2014-05-08 15:02:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/niWAcjXVPA",
      "expanded_url" : "https:\/\/mapsengine.google.com\/map\/u\/0\/edit?hl=en&authuser=0&mid=zfY0mqLBFK98.ks2vFLFWhaeQ",
      "display_url" : "mapsengine.google.com\/map\/u\/0\/edit?h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464417132327870464",
  "text" : "RT @coworkbuffalo: Co-founder Nick is working on a map that details nearby parking options. Some little- know long-term spots. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/niWAcjXVPA",
        "expanded_url" : "https:\/\/mapsengine.google.com\/map\/u\/0\/edit?hl=en&authuser=0&mid=zfY0mqLBFK98.ks2vFLFWhaeQ",
        "display_url" : "mapsengine.google.com\/map\/u\/0\/edit?h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "464417099088007168",
    "text" : "Co-founder Nick is working on a map that details nearby parking options. Some little- know long-term spots. https:\/\/t.co\/niWAcjXVPA",
    "id" : 464417099088007168,
    "created_at" : "2014-05-08 14:50:39 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 464417132327870464,
  "created_at" : "2014-05-08 14:50:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/DgUM59gc2K",
      "expanded_url" : "http:\/\/media.tumblr.com\/tumblr_lgvclrH0Q41qacvq1.gif",
      "display_url" : "media.tumblr.com\/tumblr_lgvclrH\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464258776657170433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242814136, -78.8793541218 ]
  },
  "id_str" : "464259252119289856",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit toast is OVER http:\/\/t.co\/DgUM59gc2K",
  "id" : 464259252119289856,
  "in_reply_to_status_id" : 464258776657170433,
  "created_at" : "2014-05-08 04:23:25 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/464258322208542720\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/cEv5LzeMUp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnFge-ICcAAqPYi.jpg",
      "id_str" : "464258321784926208",
      "id" : 464258321784926208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnFge-ICcAAqPYi.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/cEv5LzeMUp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239611192, -78.8789855834 ]
  },
  "id_str" : "464258322208542720",
  "text" : "I need this sticker for all of my projects. http:\/\/t.co\/cEv5LzeMUp",
  "id" : 464258322208542720,
  "created_at" : "2014-05-08 04:19:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/464256992614158336\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/bT4OA9KJub",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnFfRjLCAAAXsre.png",
      "id_str" : "464256991699795968",
      "id" : 464256991699795968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnFfRjLCAAAXsre.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 810
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 810
      } ],
      "display_url" : "pic.twitter.com\/bT4OA9KJub"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464256992614158336",
  "text" : "So apparently Twitter has inline reply toast windows now? This is stupid. http:\/\/t.co\/bT4OA9KJub",
  "id" : 464256992614158336,
  "created_at" : "2014-05-08 04:14:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/DbMiNh9umx",
      "expanded_url" : "http:\/\/moby.to\/97576w",
      "display_url" : "moby.to\/97576w"
    } ]
  },
  "in_reply_to_status_id_str" : "464254381592821760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243663513, -78.8790770341 ]
  },
  "id_str" : "464256155129106432",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove lmgtfy.MOV http:\/\/t.co\/DbMiNh9umx",
  "id" : 464256155129106432,
  "in_reply_to_status_id" : 464254381592821760,
  "created_at" : "2014-05-08 04:11:07 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/VxAe29KCuS",
      "expanded_url" : "http:\/\/lmgtfy.com\/?q=champagne+ice+cream+float",
      "display_url" : "lmgtfy.com\/?q=champagne+i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464253373579919361",
  "geo" : { },
  "id_str" : "464253590098284544",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove http:\/\/t.co\/VxAe29KCuS",
  "id" : 464253590098284544,
  "in_reply_to_status_id" : 464253373579919361,
  "created_at" : "2014-05-08 04:00:55 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 9, 20 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/YITVpvCg3K",
      "expanded_url" : "http:\/\/www.foodbeast.com\/2011\/05\/20\/a-closer-look-at-nabiscos-triple-double-oreo\/",
      "display_url" : "foodbeast.com\/2011\/05\/20\/a-c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464217333351727104",
  "geo" : { },
  "id_str" : "464217788039450624",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @tenderlove http:\/\/t.co\/YITVpvCg3K",
  "id" : 464217788039450624,
  "in_reply_to_status_id" : 464217333351727104,
  "created_at" : "2014-05-08 01:38:40 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 9, 20 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464216660295950336",
  "geo" : { },
  "id_str" : "464217198420959232",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @tenderlove had the triple stuffed oreos last weekend. 100 calories EACH.",
  "id" : 464217198420959232,
  "in_reply_to_status_id" : 464216660295950336,
  "created_at" : "2014-05-08 01:36:19 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464211933327925248",
  "text" : "I love pingdom and all, but why do they have to be more than just SMS when things go down? Isn't that enough?",
  "id" : 464211933327925248,
  "created_at" : "2014-05-08 01:15:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/6bqIEO6JHO",
      "expanded_url" : "http:\/\/pad3.whstatic.com\/images\/thumb\/a\/a3\/Appear-Intelligent-Step-11-Version-2.jpg\/670px-Appear-Intelligent-Step-11-Version-2.jpg",
      "display_url" : "pad3.whstatic.com\/images\/thumb\/a\u2026"
    }, {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/lq1qyWU2DI",
      "expanded_url" : "http:\/\/www.wikihow.com\/Appear-Intelligent",
      "display_url" : "wikihow.com\/Appear-Intelli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464210658662166528",
  "text" : "Current status, forever: http:\/\/t.co\/6bqIEO6JHO from http:\/\/t.co\/lq1qyWU2DI",
  "id" : 464210658662166528,
  "created_at" : "2014-05-08 01:10:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqui Maher",
      "screen_name" : "jacqui",
      "indices" : [ 0, 7 ],
      "id_str" : "355203",
      "id" : 355203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/6bqIEO6JHO",
      "expanded_url" : "http:\/\/pad3.whstatic.com\/images\/thumb\/a\/a3\/Appear-Intelligent-Step-11-Version-2.jpg\/670px-Appear-Intelligent-Step-11-Version-2.jpg",
      "display_url" : "pad3.whstatic.com\/images\/thumb\/a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464210064312504320",
  "geo" : { },
  "id_str" : "464210564411969536",
  "in_reply_to_user_id" : 355203,
  "text" : "@jacqui this guy - http:\/\/t.co\/6bqIEO6JHO",
  "id" : 464210564411969536,
  "in_reply_to_status_id" : 464210064312504320,
  "created_at" : "2014-05-08 01:09:57 +0000",
  "in_reply_to_screen_name" : "jacqui",
  "in_reply_to_user_id_str" : "355203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464167029990121473",
  "geo" : { },
  "id_str" : "464167803394605057",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda apparently they withhold Alzheimer's info unless you really, really, really, really want to see it.",
  "id" : 464167803394605057,
  "in_reply_to_status_id" : 464167029990121473,
  "created_at" : "2014-05-07 22:20:02 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464099003534028801",
  "geo" : { },
  "id_str" : "464125876011933696",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald Thanks for joining us on our incredible journey. We're so excited about the next steps.",
  "id" : 464125876011933696,
  "in_reply_to_status_id" : 464099003534028801,
  "created_at" : "2014-05-07 19:33:26 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464110663686565888",
  "geo" : { },
  "id_str" : "464113666820816897",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo buckle up!",
  "id" : 464113666820816897,
  "in_reply_to_status_id" : 464110663686565888,
  "created_at" : "2014-05-07 18:44:55 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464101037519798273",
  "geo" : { },
  "id_str" : "464101215547047937",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik oh yes, and bones. it's great.",
  "id" : 464101215547047937,
  "in_reply_to_status_id" : 464101037519798273,
  "created_at" : "2014-05-07 17:55:27 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Vd3VdOGw17",
      "expanded_url" : "http:\/\/alt.org\/nethack\/plr.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/plr.ph\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464100526016049154",
  "geo" : { },
  "id_str" : "464100714294153216",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik this was my original motivation too. 7 years later... http:\/\/t.co\/Vd3VdOGw17",
  "id" : 464100714294153216,
  "in_reply_to_status_id" : 464100526016049154,
  "created_at" : "2014-05-07 17:53:27 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464095652876914689",
  "geo" : { },
  "id_str" : "464096052795043840",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt UGH.",
  "id" : 464096052795043840,
  "in_reply_to_status_id" : 464095652876914689,
  "created_at" : "2014-05-07 17:34:56 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/9rdAByEJJM",
      "expanded_url" : "http:\/\/vim.wikia.com\/wiki\/Delete_all_lines_containing_a_pattern",
      "display_url" : "vim.wikia.com\/wiki\/Delete_al\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464094653210324992",
  "text" : "How did I not know about :g in vim before!? http:\/\/t.co\/9rdAByEJJM",
  "id" : 464094653210324992,
  "created_at" : "2014-05-07 17:29:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "indices" : [ 0, 12 ],
      "id_str" : "6927562",
      "id" : 6927562
    }, {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 13, 21 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464076786394230784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8908766796, -78.8767553581 ]
  },
  "id_str" : "464078873580167168",
  "in_reply_to_user_id" : 6927562,
  "text" : "@thomasfuchs @patio11 fun\u2026",
  "id" : 464078873580167168,
  "in_reply_to_status_id" : 464076786394230784,
  "created_at" : "2014-05-07 16:26:40 +0000",
  "in_reply_to_screen_name" : "thomasfuchs",
  "in_reply_to_user_id_str" : "6927562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 0, 11 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464075650794393600",
  "geo" : { },
  "id_str" : "464075853148606464",
  "in_reply_to_user_id" : 25678101,
  "text" : "@natebenson In the city?",
  "id" : 464075853148606464,
  "in_reply_to_status_id" : 464075650794393600,
  "created_at" : "2014-05-07 16:14:40 +0000",
  "in_reply_to_screen_name" : "natebenson",
  "in_reply_to_user_id_str" : "25678101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464074697311670275",
  "geo" : { },
  "id_str" : "464075608561963009",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 the vulns were for very specific route use cases. if your app isn't using them, no problem (right?)",
  "id" : 464075608561963009,
  "in_reply_to_status_id" : 464074697311670275,
  "created_at" : "2014-05-07 16:13:41 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liana Leahy",
      "screen_name" : "lleahy",
      "indices" : [ 1, 8 ],
      "id_str" : "10710622",
      "id" : 10710622
    }, {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 24, 34 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/kUSnZUCiGb",
      "expanded_url" : "http:\/\/www.confreaks.com\/videos\/3461-railsconf-let-me-code",
      "display_url" : "confreaks.com\/videos\/3461-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464073515247747076",
  "text" : ".@lleahy rocked this at @railsconf, bummed I missed it: http:\/\/t.co\/kUSnZUCiGb (What other community has this?!)",
  "id" : 464073515247747076,
  "created_at" : "2014-05-07 16:05:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hooks",
      "screen_name" : "cd_hooks",
      "indices" : [ 3, 12 ],
      "id_str" : "349817494",
      "id" : 349817494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/V0S6Wr2hsa",
      "expanded_url" : "http:\/\/www.wikihow.com\/Stop-a-Wedding",
      "display_url" : "wikihow.com\/Stop-a-Wedding"
    } ]
  },
  "geo" : { },
  "id_str" : "464027558527242242",
  "text" : "RT @cd_hooks: This is without a doubt the most insane, deranged thing I've ever seen on the Internet, and it's not even NSFW http:\/\/t.co\/V0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/V0S6Wr2hsa",
        "expanded_url" : "http:\/\/www.wikihow.com\/Stop-a-Wedding",
        "display_url" : "wikihow.com\/Stop-a-Wedding"
      } ]
    },
    "geo" : { },
    "id_str" : "463851964254547969",
    "text" : "This is without a doubt the most insane, deranged thing I've ever seen on the Internet, and it's not even NSFW http:\/\/t.co\/V0S6Wr2hsa",
    "id" : 463851964254547969,
    "created_at" : "2014-05-07 01:25:00 +0000",
    "user" : {
      "name" : "Christopher Hooks",
      "screen_name" : "cd_hooks",
      "protected" : false,
      "id_str" : "349817494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562488852292448256\/4IE75UQ__normal.jpeg",
      "id" : 349817494,
      "verified" : false
    }
  },
  "id" : 464027558527242242,
  "created_at" : "2014-05-07 13:02:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/463810985967374336\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Z6lg5C4u8c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_Jok0CEAAK8is.jpg",
      "id_str" : "463810985556316160",
      "id" : 463810985556316160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_Jok0CEAAK8is.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/Z6lg5C4u8c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245601828, -78.8795340155 ]
  },
  "id_str" : "463810985967374336",
  "text" : "GIMME MEATZA!! M EA T Z Z A GIMME MEATZA! http:\/\/t.co\/Z6lg5C4u8c",
  "id" : 463810985967374336,
  "created_at" : "2014-05-06 22:42:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/hkyTAkBZY7",
      "expanded_url" : "https:\/\/mapsengine.google.com\/map\/edit?mid=zfY0mqLBFK98.ks2vFLFWhaeQ",
      "display_url" : "mapsengine.google.com\/map\/edit?mid=z\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463780171191824384",
  "geo" : { },
  "id_str" : "463780675904995328",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 anywhere on Washington works, it's all free after 5. https:\/\/t.co\/hkyTAkBZY7",
  "id" : 463780675904995328,
  "in_reply_to_status_id" : 463780171191824384,
  "created_at" : "2014-05-06 20:41:44 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/463775518995652612\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/1Jh0lDN0Ol",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm-pYGjCUAEn78I.png",
      "id_str" : "463775518181969921",
      "id" : 463775518181969921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm-pYGjCUAEn78I.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 588
      } ],
      "display_url" : "pic.twitter.com\/1Jh0lDN0Ol"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463775518995652612",
  "text" : "Noo!!!!! http:\/\/t.co\/1Jh0lDN0Ol",
  "id" : 463775518995652612,
  "created_at" : "2014-05-06 20:21:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Brethorst",
      "screen_name" : "aaronbrethorst",
      "indices" : [ 0, 15 ],
      "id_str" : "1335131",
      "id" : 1335131
    }, {
      "name" : "Grant Goodale",
      "screen_name" : "ggoodale",
      "indices" : [ 16, 25 ],
      "id_str" : "4270261",
      "id" : 4270261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463763246865190912",
  "geo" : { },
  "id_str" : "463763993757118465",
  "in_reply_to_user_id" : 1335131,
  "text" : "@aaronbrethorst @ggoodale I don't believe the author for one second. Came out over a month after.",
  "id" : 463763993757118465,
  "in_reply_to_status_id" : 463763246865190912,
  "created_at" : "2014-05-06 19:35:27 +0000",
  "in_reply_to_screen_name" : "aaronbrethorst",
  "in_reply_to_user_id_str" : "1335131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Fleischer",
      "screen_name" : "hazula",
      "indices" : [ 0, 7 ],
      "id_str" : "16745228",
      "id" : 16745228
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 8, 15 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Doug Alcorn",
      "screen_name" : "dougalcorn",
      "indices" : [ 16, 27 ],
      "id_str" : "7018192",
      "id" : 7018192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/8uETQk0bNF",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!forum\/rubygems-org",
      "display_url" : "groups.google.com\/forum\/#!forum\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463761096147337219",
  "geo" : { },
  "id_str" : "463761602475335680",
  "in_reply_to_user_id" : 16745228,
  "text" : "@hazula @searls @dougalcorn kick off a thread here, I have some ideas. https:\/\/t.co\/8uETQk0bNF",
  "id" : 463761602475335680,
  "in_reply_to_status_id" : 463761096147337219,
  "created_at" : "2014-05-06 19:25:56 +0000",
  "in_reply_to_screen_name" : "hazula",
  "in_reply_to_user_id_str" : "16745228",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Fleischer",
      "screen_name" : "hazula",
      "indices" : [ 0, 7 ],
      "id_str" : "16745228",
      "id" : 16745228
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 8, 15 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Doug Alcorn",
      "screen_name" : "dougalcorn",
      "indices" : [ 16, 27 ],
      "id_str" : "7018192",
      "id" : 7018192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463752835935776769",
  "geo" : { },
  "id_str" : "463754298258509824",
  "in_reply_to_user_id" : 16745228,
  "text" : "@hazula @searls @dougalcorn agreed. maybe we need a rubygems adoption center.",
  "id" : 463754298258509824,
  "in_reply_to_status_id" : 463752835935776769,
  "created_at" : "2014-05-06 18:56:55 +0000",
  "in_reply_to_screen_name" : "hazula",
  "in_reply_to_user_id_str" : "16745228",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Alcorn",
      "screen_name" : "dougalcorn",
      "indices" : [ 0, 11 ],
      "id_str" : "7018192",
      "id" : 7018192
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 12, 19 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463732938752811008",
  "geo" : { },
  "id_str" : "463735570632409088",
  "in_reply_to_user_id" : 7018192,
  "text" : "@dougalcorn @searls Huh? I don't think we've dealt with this before (maybe except _why), so need to figure it out for all of his gems.",
  "id" : 463735570632409088,
  "in_reply_to_status_id" : 463732938752811008,
  "created_at" : "2014-05-06 17:42:30 +0000",
  "in_reply_to_screen_name" : "dougalcorn",
  "in_reply_to_user_id_str" : "7018192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 14, 21 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 22, 27 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Noel Rappin",
      "screen_name" : "noelrap",
      "indices" : [ 28, 36 ],
      "id_str" : "1515231",
      "id" : 1515231
    }, {
      "name" : "Doug Alcorn",
      "screen_name" : "dougalcorn",
      "indices" : [ 37, 48 ],
      "id_str" : "7018192",
      "id" : 7018192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/HsNhGmbnN9",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "463727939511910401",
  "geo" : { },
  "id_str" : "463730253899112448",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman @searls @avdi @noelrap @dougalcorn please open a ticket on http:\/\/t.co\/HsNhGmbnN9 about this.",
  "id" : 463730253899112448,
  "in_reply_to_status_id" : 463727939511910401,
  "created_at" : "2014-05-06 17:21:22 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Distance",
      "screen_name" : "distancemag",
      "indices" : [ 3, 15 ],
      "id_str" : "2432346013",
      "id" : 2432346013
    }, {
      "name" : "Horween Leather Co.",
      "screen_name" : "HorweenLeather",
      "indices" : [ 89, 104 ],
      "id_str" : "36641236",
      "id" : 36641236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4x5ZxGkJXM",
      "expanded_url" : "http:\/\/thedistance.com\/horween",
      "display_url" : "thedistance.com\/horween"
    } ]
  },
  "geo" : { },
  "id_str" : "463715113695215616",
  "text" : "RT @distancemag: The Distance is here! Our first issue features Horween Leather Company (@HorweenLeather), Chicago's last tannery: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Horween Leather Co.",
        "screen_name" : "HorweenLeather",
        "indices" : [ 72, 87 ],
        "id_str" : "36641236",
        "id" : 36641236
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/4x5ZxGkJXM",
        "expanded_url" : "http:\/\/thedistance.com\/horween",
        "display_url" : "thedistance.com\/horween"
      } ]
    },
    "geo" : { },
    "id_str" : "463712907562598402",
    "text" : "The Distance is here! Our first issue features Horween Leather Company (@HorweenLeather), Chicago's last tannery: http:\/\/t.co\/4x5ZxGkJXM",
    "id" : 463712907562598402,
    "created_at" : "2014-05-06 16:12:27 +0000",
    "user" : {
      "name" : "The Distance",
      "screen_name" : "distancemag",
      "protected" : false,
      "id_str" : "2432346013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562666640223911936\/zYGY1Zjf_normal.jpeg",
      "id" : 2432346013,
      "verified" : false
    }
  },
  "id" : 463715113695215616,
  "created_at" : "2014-05-06 16:21:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 3, 10 ],
      "id_str" : "158371168",
      "id" : 158371168
    }, {
      "name" : "Dopapod",
      "screen_name" : "Dopapod",
      "indices" : [ 20, 28 ],
      "id_str" : "44571170",
      "id" : 44571170
    }, {
      "name" : "Music Hall of WB",
      "screen_name" : "MusicHallofWB",
      "indices" : [ 37, 51 ],
      "id_str" : "20573003",
      "id" : 20573003
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 80, 92 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mkdevo\/status\/463699179546894336\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/3oVnVPmBnn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm9j8iWCMAAgtW8.jpg",
      "id_str" : "463699178304974848",
      "id" : 463699178304974848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm9j8iWCMAAgtW8.jpg",
      "sizes" : [ {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 837,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3oVnVPmBnn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/cA3wJ0qh0F",
      "expanded_url" : "https:\/\/www.facebook.com\/media\/set\/?set=a.575546919210354.1073741831.552912888140424&type=1",
      "display_url" : "facebook.com\/media\/set\/?set\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463700922376261634",
  "text" : "RT @mkdevo: PHOTOS: @Dopapod live at @MusicHallofWB this past Saturday night (w\/@AqueousBand sit-in): \nhttps:\/\/t.co\/cA3wJ0qh0F http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dopapod",
        "screen_name" : "Dopapod",
        "indices" : [ 8, 16 ],
        "id_str" : "44571170",
        "id" : 44571170
      }, {
        "name" : "Music Hall of WB",
        "screen_name" : "MusicHallofWB",
        "indices" : [ 25, 39 ],
        "id_str" : "20573003",
        "id" : 20573003
      }, {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 68, 80 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mkdevo\/status\/463699179546894336\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/3oVnVPmBnn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm9j8iWCMAAgtW8.jpg",
        "id_str" : "463699178304974848",
        "id" : 463699178304974848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm9j8iWCMAAgtW8.jpg",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 837,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/3oVnVPmBnn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/cA3wJ0qh0F",
        "expanded_url" : "https:\/\/www.facebook.com\/media\/set\/?set=a.575546919210354.1073741831.552912888140424&type=1",
        "display_url" : "facebook.com\/media\/set\/?set\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463699179546894336",
    "text" : "PHOTOS: @Dopapod live at @MusicHallofWB this past Saturday night (w\/@AqueousBand sit-in): \nhttps:\/\/t.co\/cA3wJ0qh0F http:\/\/t.co\/3oVnVPmBnn",
    "id" : 463699179546894336,
    "created_at" : "2014-05-06 15:17:54 +0000",
    "user" : {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "protected" : false,
      "id_str" : "158371168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564127014987120640\/dkdEJyOf_normal.jpeg",
      "id" : 158371168,
      "verified" : false
    }
  },
  "id" : 463700922376261634,
  "created_at" : "2014-05-06 15:24:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/RiiX9WsktZ",
      "expanded_url" : "http:\/\/gabrielecirulli.com\/articles\/2048-success-and-me",
      "display_url" : "gabrielecirulli.com\/articles\/2048-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463697935973089281",
  "text" : "\"I did not know about Threes\" - most bullshit I've heard so far today http:\/\/t.co\/RiiX9WsktZ",
  "id" : 463697935973089281,
  "created_at" : "2014-05-06 15:12:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 93, 102 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/fNl4arCPjQ",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/16084-openhack-may-1-0",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463685818477854722",
  "text" : "RT @zobar2: Hey, it's the first Tuesday of the month! And y'all know what that means by now. @openhack RSVP: http:\/\/t.co\/fNl4arCPjQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 81, 90 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/fNl4arCPjQ",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/16084-openhack-may-1-0",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463684898579283969",
    "text" : "Hey, it's the first Tuesday of the month! And y'all know what that means by now. @openhack RSVP: http:\/\/t.co\/fNl4arCPjQ",
    "id" : 463684898579283969,
    "created_at" : "2014-05-06 14:21:09 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 463685818477854722,
  "created_at" : "2014-05-06 14:24:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J & L Boulevard BBQ",
      "screen_name" : "buffalosbestbbq",
      "indices" : [ 70, 86 ],
      "id_str" : "390820130",
      "id" : 390820130
    }, {
      "name" : "Wine Not?",
      "screen_name" : "WineNotWNY",
      "indices" : [ 87, 98 ],
      "id_str" : "1576004389",
      "id" : 1576004389
    }, {
      "name" : "Betty Crockski ",
      "screen_name" : "BettyCrockski",
      "indices" : [ 99, 113 ],
      "id_str" : "1486650266",
      "id" : 1486650266
    }, {
      "name" : "Macarollin'",
      "screen_name" : "Macarollin",
      "indices" : [ 114, 125 ],
      "id_str" : "1223036810",
      "id" : 1223036810
    }, {
      "name" : "The Great Foodini",
      "screen_name" : "Gr8Foodini",
      "indices" : [ 126, 137 ],
      "id_str" : "1696845847",
      "id" : 1696845847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/RRguAXFMtA",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "463679888877035520",
  "text" : "Updated http:\/\/t.co\/RRguAXFMtA with a ton of trucks: @daBlueFoodTruck @buffalosbestbbq @WineNotWNY @BettyCrockski @Macarollin @Gr8Foodini",
  "id" : 463679888877035520,
  "created_at" : "2014-05-06 14:01:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463677900810510336",
  "text" : "RT @coworkbuffalo: Two years ago, we took a trip to Canada, bought a phone both off Craigslist, and wondered who would join us. Thanks to t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463339546050977794",
    "text" : "Two years ago, we took a trip to Canada, bought a phone both off Craigslist, and wondered who would join us. Thanks to those who have.",
    "id" : 463339546050977794,
    "created_at" : "2014-05-05 15:28:50 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 463677900810510336,
  "created_at" : "2014-05-06 13:53:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gittip",
      "screen_name" : "Gittip",
      "indices" : [ 60, 67 ],
      "id_str" : "2595663126",
      "id" : 2595663126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/JIxUz6yTTA",
      "expanded_url" : "http:\/\/building.gittip.com\/",
      "display_url" : "building.gittip.com"
    } ]
  },
  "geo" : { },
  "id_str" : "463659155102777344",
  "text" : "We need one of these for http:\/\/t.co\/EmUiG90kOd. Great work @gittip! http:\/\/t.co\/JIxUz6yTTA",
  "id" : 463659155102777344,
  "created_at" : "2014-05-06 12:38:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/zY329zphYI",
      "expanded_url" : "http:\/\/battle.net",
      "display_url" : "battle.net"
    } ]
  },
  "in_reply_to_status_id_str" : "463508333047971840",
  "geo" : { },
  "id_str" : "463509156029149185",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts dang! whats your http:\/\/t.co\/zY329zphYI?",
  "id" : 463509156029149185,
  "in_reply_to_status_id" : 463508333047971840,
  "created_at" : "2014-05-06 02:42:49 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/4v398Mepx0",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=5MwS-WXbig0",
      "display_url" : "youtube.com\/watch?v=5MwS-W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463502082096381952",
  "text" : "kill -HUP `cat tmp\/pids\/unicorn.pid` https:\/\/t.co\/4v398Mepx0",
  "id" : 463502082096381952,
  "created_at" : "2014-05-06 02:14:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/u9NTwbzalD",
      "expanded_url" : "http:\/\/boardingarea.com\/onemileatatime\/2014\/05\/04\/etihad-airways-a380-routes-residences-apartments\/",
      "display_url" : "boardingarea.com\/onemileatatime\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463483714060578816",
  "text" : "The next time you're crammed into coach, remember some fly like this: http:\/\/t.co\/u9NTwbzalD",
  "id" : 463483714060578816,
  "created_at" : "2014-05-06 01:01:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/epOpoy3gAb",
      "expanded_url" : "http:\/\/animalnewyork.com\/2014\/artists-notebook-ramsey-nasser\/",
      "display_url" : "animalnewyork.com\/2014\/artists-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463480300257828864",
  "text" : "Coding in anything but English is impossible: http:\/\/t.co\/epOpoy3gAb",
  "id" : 463480300257828864,
  "created_at" : "2014-05-06 00:48:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 3, 10 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/T1SGCco6lH",
      "expanded_url" : "https:\/\/github.com\/thoughtbot\/apprenticeship",
      "display_url" : "github.com\/thoughtbot\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463423826437480449",
  "text" : "RT @cpytel: I\u2019ve just opened up some of our internal documentation about running apprenticeships https:\/\/t.co\/T1SGCco6lH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/T1SGCco6lH",
        "expanded_url" : "https:\/\/github.com\/thoughtbot\/apprenticeship",
        "display_url" : "github.com\/thoughtbot\/app\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463422649969152000",
    "text" : "I\u2019ve just opened up some of our internal documentation about running apprenticeships https:\/\/t.co\/T1SGCco6lH",
    "id" : 463422649969152000,
    "created_at" : "2014-05-05 20:59:04 +0000",
    "user" : {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "protected" : false,
      "id_str" : "9488922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1617210225\/headshot_normal.png",
      "id" : 9488922,
      "verified" : false
    }
  },
  "id" : 463423826437480449,
  "created_at" : "2014-05-05 21:03:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 24, 33 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463418621088120832",
  "geo" : { },
  "id_str" : "463419178230112256",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej this should be @bquarant's speciality. i bet you could put this on a resume.",
  "id" : 463419178230112256,
  "in_reply_to_status_id" : 463418621088120832,
  "created_at" : "2014-05-05 20:45:16 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9hr7ypqr1X",
      "expanded_url" : "https:\/\/rubygems.org\/",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "463412088530935809",
  "text" : "A billion gem downloads isn't cool. You know what's cool? 3 BILLION GEM DOWNLOADS. https:\/\/t.co\/9hr7ypqr1X",
  "id" : 463412088530935809,
  "created_at" : "2014-05-05 20:17:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/NlFJQjtx2n",
      "expanded_url" : "https:\/\/bugs.launchpad.net\/ubuntu\/+source\/ruby2.0\/+bug\/1310292",
      "display_url" : "bugs.launchpad.net\/ubuntu\/+source\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463404080350498816",
  "text" : "\"From the Debian POV, this is working as designed\" https:\/\/t.co\/NlFJQjtx2n",
  "id" : 463404080350498816,
  "created_at" : "2014-05-05 19:45:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/thXUqOroes",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463127731207548930",
  "text" : "I miss Red. This feels like CNN or some cable news channel now. http:\/\/t.co\/thXUqOroes",
  "id" : 463127731207548930,
  "created_at" : "2014-05-05 01:27:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Natalie",
      "screen_name" : "ntljk",
      "indices" : [ 7, 13 ],
      "id_str" : "21778760",
      "id" : 21778760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463113164406546432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239029852, -78.8790679844 ]
  },
  "id_str" : "463118152117669888",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan @ntljk genius",
  "id" : 463118152117669888,
  "in_reply_to_status_id" : 463113164406546432,
  "created_at" : "2014-05-05 00:49:06 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462968820303286274",
  "geo" : { },
  "id_str" : "463045788470218752",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain qrush#1208 or nick@quaran.to",
  "id" : 463045788470218752,
  "in_reply_to_status_id" : 462968820303286274,
  "created_at" : "2014-05-04 20:01:33 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Richards",
      "screen_name" : "noahsmark",
      "indices" : [ 0, 10 ],
      "id_str" : "14198565",
      "id" : 14198565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/zY329zphYI",
      "expanded_url" : "http:\/\/battle.net",
      "display_url" : "battle.net"
    } ]
  },
  "in_reply_to_status_id_str" : "463012850017902592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242714681, -78.8790804707 ]
  },
  "id_str" : "463013500701270016",
  "in_reply_to_user_id" : 14198565,
  "text" : "@noahsmark hey man! Sadly, I can\u2019t stand to watch anything on Twitch but Pokemon. What\u2019s your http:\/\/t.co\/zY329zphYI?",
  "id" : 463013500701270016,
  "in_reply_to_status_id" : 463012850017902592,
  "created_at" : "2014-05-04 17:53:15 +0000",
  "in_reply_to_screen_name" : "noahsmark",
  "in_reply_to_user_id_str" : "14198565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Pochron",
      "screen_name" : "garypochron",
      "indices" : [ 0, 12 ],
      "id_str" : "36580514",
      "id" : 36580514
    }, {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 13, 21 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462964483896655872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242350068, -78.8800678589 ]
  },
  "id_str" : "463013162535510016",
  "in_reply_to_user_id" : 36580514,
  "text" : "@garypochron @zakkain thanks for the advice, but doesn\u2019t help bad draws.",
  "id" : 463013162535510016,
  "in_reply_to_status_id" : 462964483896655872,
  "created_at" : "2014-05-04 17:51:54 +0000",
  "in_reply_to_screen_name" : "garypochron",
  "in_reply_to_user_id_str" : "36580514",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462971022581706752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242767864, -78.8792024627 ]
  },
  "id_str" : "462972287520493568",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 you are a consumer whore",
  "id" : 462972287520493568,
  "in_reply_to_status_id" : 462971022581706752,
  "created_at" : "2014-05-04 15:09:29 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462949089769193472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240692161, -78.8791216066 ]
  },
  "id_str" : "462950698179506176",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain I\u2019d like to start with winning one match if you have a legendary. Small steps.",
  "id" : 462950698179506176,
  "in_reply_to_status_id" : 462949089769193472,
  "created_at" : "2014-05-04 13:43:42 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241047163, -78.8789945586 ]
  },
  "id_str" : "462947473493729281",
  "text" : "And lost 3 arena matches in a row without even seeing Rag in my hand. :(",
  "id" : 462947473493729281,
  "created_at" : "2014-05-04 13:30:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/462938019033403392\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/cNTZHmASyp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmyvrOaCQAAP1D8.jpg",
      "id_str" : "462938018848849920",
      "id" : 462938018848849920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmyvrOaCQAAP1D8.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cNTZHmASyp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462938019033403392",
  "text" : "Can I keep it? Please?! http:\/\/t.co\/cNTZHmASyp",
  "id" : 462938019033403392,
  "created_at" : "2014-05-04 12:53:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/9fMmYsuYGm",
      "expanded_url" : "http:\/\/4sq.com\/SmDNwQ",
      "display_url" : "4sq.com\/SmDNwQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9116250018, -78.8769687418 ]
  },
  "id_str" : "462797763189960704",
  "text" : "Back in Buffalo after 2 weeks, first order of business (@ Lloyd Dos Taco Truck) http:\/\/t.co\/9fMmYsuYGm",
  "id" : 462797763189960704,
  "created_at" : "2014-05-04 03:35:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/2pnwsp52Bg",
      "expanded_url" : "http:\/\/4sq.com\/1kGxEVt",
      "display_url" : "4sq.com\/1kGxEVt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1066767, -80.6552476333 ]
  },
  "id_str" : "462686187850043393",
  "text" : "I'm at Charlie Staples Bar-B-Q (Youngstown, OH) http:\/\/t.co\/2pnwsp52Bg",
  "id" : 462686187850043393,
  "created_at" : "2014-05-03 20:12:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462572304438796288",
  "text" : "Have to be honest\u2026 Hearthstone is easier from 6-8am. Less players online?",
  "id" : 462572304438796288,
  "created_at" : "2014-05-03 12:40:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462360689345306625",
  "geo" : { },
  "id_str" : "462385988229414912",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden haha, thought the same for a long time. Living in the City of Good Neighbors helps too ;)",
  "id" : 462385988229414912,
  "in_reply_to_status_id" : 462360689345306625,
  "created_at" : "2014-05-03 00:19:44 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Hische",
      "screen_name" : "jessicahische",
      "indices" : [ 3, 17 ],
      "id_str" : "18638800",
      "id" : 18638800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462372032756207616",
  "text" : "RT @jessicahische: Small US cities trying to build up a start-up scene should really just put up billboards in SF showcasing amazing sub-50\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462342889042108416",
    "text" : "Small US cities trying to build up a start-up scene should really just put up billboards in SF showcasing amazing sub-500k house listings.",
    "id" : 462342889042108416,
    "created_at" : "2014-05-02 21:28:29 +0000",
    "user" : {
      "name" : "Jessica Hische",
      "screen_name" : "jessicahische",
      "protected" : false,
      "id_str" : "18638800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3774752762\/2934249cdd3a23fa0f8e326732079a8e_normal.jpeg",
      "id" : 18638800,
      "verified" : false
    }
  },
  "id" : 462372032756207616,
  "created_at" : "2014-05-02 23:24:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462356425004429312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1930014553, -80.5592795757 ]
  },
  "id_str" : "462360444900892672",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden this changes drastically with owning a dog. Basically forces you to see\/introduce to the neighborhood",
  "id" : 462360444900892672,
  "in_reply_to_status_id" : 462356425004429312,
  "created_at" : "2014-05-02 22:38:14 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 sdo\u0279\u0259\u0259q",
      "screen_name" : "beerops",
      "indices" : [ 0, 8 ],
      "id_str" : "260044118",
      "id" : 260044118
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 14, 22 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 23, 31 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462316270638350336",
  "geo" : { },
  "id_str" : "462319801411862528",
  "in_reply_to_user_id" : 260044118,
  "text" : "@beerops ugh. @evanphx @drbrain any suggestions on this? you've turned off the legacy index right?",
  "id" : 462319801411862528,
  "in_reply_to_status_id" : 462316270638350336,
  "created_at" : "2014-05-02 19:56:44 +0000",
  "in_reply_to_screen_name" : "beerops",
  "in_reply_to_user_id_str" : "260044118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 sdo\u0279\u0259\u0259q",
      "screen_name" : "beerops",
      "indices" : [ 0, 8 ],
      "id_str" : "260044118",
      "id" : 260044118
    }, {
      "name" : "sam :",
      "screen_name" : "Lenary",
      "indices" : [ 9, 16 ],
      "id_str" : "14466962",
      "id" : 14466962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462315424496234498",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1930514676, -80.5592774747 ]
  },
  "id_str" : "462315812414439424",
  "in_reply_to_user_id" : 260044118,
  "text" : "@beerops @Lenary running a mirror? Anything I can help with?",
  "id" : 462315812414439424,
  "in_reply_to_status_id" : 462315424496234498,
  "created_at" : "2014-05-02 19:40:53 +0000",
  "in_reply_to_screen_name" : "beerops",
  "in_reply_to_user_id_str" : "260044118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 89, 101 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/bYqXfu0re1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=fWqK_LsKxK4",
      "display_url" : "youtube.com\/watch?v=fWqK_L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462271884441436160",
  "text" : "In case you need some coding jams today: https:\/\/t.co\/bYqXfu0re1 Can't wait to hear what @AqueousBand does this weekend at the Farm again.",
  "id" : 462271884441436160,
  "created_at" : "2014-05-02 16:46:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462258629698416640",
  "geo" : { },
  "id_str" : "462259450012004352",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik Submit some anyway.",
  "id" : 462259450012004352,
  "in_reply_to_status_id" : 462258629698416640,
  "created_at" : "2014-05-02 15:56:55 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461878058241495041",
  "text" : "Ended up just upgrading the Heroku DB and transferring over. Even if you're on free, run: `heroku addons:upgrade pgbackups:auto-week`",
  "id" : 461878058241495041,
  "created_at" : "2014-05-01 14:41:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 0, 4 ],
      "id_str" : "49923",
      "id" : 49923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461862268095836160",
  "geo" : { },
  "id_str" : "461873019552403456",
  "in_reply_to_user_id" : 49923,
  "text" : "@nz_ it's just the free, but this does not look good :(",
  "id" : 461873019552403456,
  "in_reply_to_status_id" : 461862268095836160,
  "created_at" : "2014-05-01 14:21:23 +0000",
  "in_reply_to_screen_name" : "nz_",
  "in_reply_to_user_id_str" : "49923",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461860959791755264",
  "text" : "Heroku DB mysteriously went offline, no emails\/alerts about it, can't reconnect. Support response within a business day. :(",
  "id" : 461860959791755264,
  "created_at" : "2014-05-01 13:33:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
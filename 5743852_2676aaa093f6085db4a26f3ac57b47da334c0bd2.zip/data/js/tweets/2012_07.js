Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 64, 73 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 112, 126 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 132, 140 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230462751267495937",
  "geo" : { },
  "id_str" : "230507064525484033",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard sorry dude. working through the backlog. hoping to be @rubygems support inbox zero by this weekend at @SteelCityRuby. \/cc @evanphx",
  "id" : 230507064525484033,
  "in_reply_to_status_id" : 230462751267495937,
  "created_at" : "2012-08-01 03:35:41 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 9, 19 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 20, 31 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230436355111518208",
  "geo" : { },
  "id_str" : "230437820962070529",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending @magnachef @kevinpurdy @coworkbuffalo hell yes!",
  "id" : 230437820962070529,
  "in_reply_to_status_id" : 230436355111518208,
  "created_at" : "2012-07-31 23:00:32 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/pG8pNsDj",
      "expanded_url" : "http:\/\/cat.news.ycombinator.com.meowbify.com\/item?id=4317999",
      "display_url" : "cat.news.ycombinator.com.meowbify.com\/item?id=4317999"
    } ]
  },
  "geo" : { },
  "id_str" : "230385445928833025",
  "text" : "The comments are just as good: http:\/\/t.co\/pG8pNsDj",
  "id" : 230385445928833025,
  "created_at" : "2012-07-31 19:32:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/nkBshTrw",
      "expanded_url" : "http:\/\/cat.news.ycombinator.com.meowbify.com\/",
      "display_url" : "cat.news.ycombinator.com.meowbify.com"
    } ]
  },
  "geo" : { },
  "id_str" : "230384910014238720",
  "text" : "The best way to read Hacker News: http:\/\/t.co\/nkBshTrw",
  "id" : 230384910014238720,
  "created_at" : "2012-07-31 19:30:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/ChMnyHtH",
      "expanded_url" : "http:\/\/Outlook.com",
      "display_url" : "Outlook.com"
    } ]
  },
  "geo" : { },
  "id_str" : "230349249798344704",
  "text" : "http:\/\/t.co\/ChMnyHtH feels a lot like the Win8 UI...including clicking the wrong thing sends you to a different (and ugly) UI.",
  "id" : 230349249798344704,
  "created_at" : "2012-07-31 17:08:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/VdSHeL0W",
      "expanded_url" : "http:\/\/outlook.com",
      "display_url" : "outlook.com"
    } ]
  },
  "geo" : { },
  "id_str" : "230347607707381762",
  "text" : "Trying to sign up for http:\/\/t.co\/VdSHeL0W, but I can't correctly figure out their CAPTCHA. Tried over a dozen so far. I'm not human?",
  "id" : 230347607707381762,
  "created_at" : "2012-07-31 17:02:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "indices" : [ 0, 8 ],
      "id_str" : "3382151",
      "id" : 3382151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230330657774137344",
  "geo" : { },
  "id_str" : "230331039678083072",
  "in_reply_to_user_id" : 3382151,
  "text" : "@dmosher Way too clever. no idea how to get back.",
  "id" : 230331039678083072,
  "in_reply_to_status_id" : 230330657774137344,
  "created_at" : "2012-07-31 15:56:13 +0000",
  "in_reply_to_screen_name" : "dmosher",
  "in_reply_to_user_id_str" : "3382151",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streeting",
      "screen_name" : "stevestreeting",
      "indices" : [ 0, 15 ],
      "id_str" : "138065190",
      "id" : 138065190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230273545647833088",
  "geo" : { },
  "id_str" : "230276517765206016",
  "in_reply_to_user_id" : 138065190,
  "text" : "@stevestreeting didn\u2019t you mean, .IsNullOrEmpty ? *shudder* *dry heave*",
  "id" : 230276517765206016,
  "in_reply_to_status_id" : 230273545647833088,
  "created_at" : "2012-07-31 12:19:34 +0000",
  "in_reply_to_screen_name" : "stevestreeting",
  "in_reply_to_user_id_str" : "138065190",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SkillBonsai",
      "screen_name" : "skillbonsai",
      "indices" : [ 3, 15 ],
      "id_str" : "274021679",
      "id" : 274021679
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 43, 57 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc12",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230132887402455041",
  "text" : "RT @skillbonsai: Giving away 2 tickets for @SteelCityRuby for the best answer to: What do you want to learn\/improve and why? (tweet or b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 26, 40 ],
        "id_str" : "404851600",
        "id" : 404851600
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scrc12",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230131148381106176",
    "text" : "Giving away 2 tickets for @SteelCityRuby for the best answer to: What do you want to learn\/improve and why? (tweet or blog) #scrc12",
    "id" : 230131148381106176,
    "created_at" : "2012-07-31 02:41:56 +0000",
    "user" : {
      "name" : "SkillBonsai",
      "screen_name" : "skillbonsai",
      "protected" : false,
      "id_str" : "274021679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292794105\/logo-twitter_normal.png",
      "id" : 274021679,
      "verified" : false
    }
  },
  "id" : 230132887402455041,
  "created_at" : "2012-07-31 02:48:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "indices" : [ 0, 13 ],
      "id_str" : "3479601",
      "id" : 3479601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230129367244759041",
  "geo" : { },
  "id_str" : "230132342256173056",
  "in_reply_to_user_id" : 3479601,
  "text" : "@justingoboom UPGRADDDYYED",
  "id" : 230132342256173056,
  "in_reply_to_status_id" : 230129367244759041,
  "created_at" : "2012-07-31 02:46:40 +0000",
  "in_reply_to_screen_name" : "justingoboom",
  "in_reply_to_user_id_str" : "3479601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230131870283739137",
  "text" : "Resque::DirtyExit is the only exception that applies to my job and laundry. \n\nGET IT?\n\nHHA HA",
  "id" : 230131870283739137,
  "created_at" : "2012-07-31 02:44:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Hinze",
      "screen_name" : "phinze",
      "indices" : [ 0, 7 ],
      "id_str" : "37412405",
      "id" : 37412405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230129961439219712",
  "geo" : { },
  "id_str" : "230131316933414913",
  "in_reply_to_user_id" : 37412405,
  "text" : "@phinze phew!",
  "id" : 230131316933414913,
  "in_reply_to_status_id" : 230129961439219712,
  "created_at" : "2012-07-31 02:42:36 +0000",
  "in_reply_to_screen_name" : "phinze",
  "in_reply_to_user_id_str" : "37412405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eddie cianci \u2602",
      "screen_name" : "defeated",
      "indices" : [ 0, 9 ],
      "id_str" : "784974",
      "id" : 784974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230123486083969024",
  "geo" : { },
  "id_str" : "230127798805737473",
  "in_reply_to_user_id" : 784974,
  "text" : "@defeated thanks! I\u2019m not sure if it\u2019s worth adding more deps into Rails though.",
  "id" : 230127798805737473,
  "in_reply_to_status_id" : 230123486083969024,
  "created_at" : "2012-07-31 02:28:37 +0000",
  "in_reply_to_screen_name" : "defeated",
  "in_reply_to_user_id_str" : "784974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 10, 18 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 44, 58 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/AR2ox6vD",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/74599322\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230120437647028225",
  "text" : "Reminder! @WNYRuby is hosting a hackfest at @coworkbuffalo tomorrow night. Come on down, get some coding done! http:\/\/t.co\/AR2ox6vD",
  "id" : 230120437647028225,
  "created_at" : "2012-07-31 01:59:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230118233489936384",
  "geo" : { },
  "id_str" : "230118455960031233",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH well aware.",
  "id" : 230118455960031233,
  "in_reply_to_status_id" : 230118233489936384,
  "created_at" : "2012-07-31 01:51:29 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230117199661133825",
  "text" : "How to tell your husky is not tired yet: Runs full speed around the house between you and spouse for no other reason than just to run.",
  "id" : 230117199661133825,
  "created_at" : "2012-07-31 01:46:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jtoy",
      "screen_name" : "jtoy",
      "indices" : [ 0, 5 ],
      "id_str" : "14914457",
      "id" : 14914457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230098953474043904",
  "geo" : { },
  "id_str" : "230104691021844480",
  "in_reply_to_user_id" : 14914457,
  "text" : "@jtoy did Tony Stark just kick off Burning Man?",
  "id" : 230104691021844480,
  "in_reply_to_status_id" : 230098953474043904,
  "created_at" : "2012-07-31 00:56:48 +0000",
  "in_reply_to_screen_name" : "jtoy",
  "in_reply_to_user_id_str" : "14914457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Starsi",
      "screen_name" : "klevo",
      "indices" : [ 51, 57 ],
      "id_str" : "14957664",
      "id" : 14957664
    }, {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 58, 69 ],
      "id_str" : "9887102",
      "id" : 9887102
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 70, 80 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/hc4ViZzS",
      "expanded_url" : "http:\/\/quaran.to\/m\/",
      "display_url" : "quaran.to\/m\/"
    } ]
  },
  "geo" : { },
  "id_str" : "230102177211891713",
  "text" : "Just cut m 1.2.0 with some fixes\/improvements from @klevo @metaskills @cldwalker. Thanks! http:\/\/t.co\/hc4ViZzS",
  "id" : 230102177211891713,
  "created_at" : "2012-07-31 00:46:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230096950173790209",
  "text" : "Hey, I just initialized you, and this is crazy \/ but I yielded to my &amp;block \/ so .call me maybe?",
  "id" : 230096950173790209,
  "created_at" : "2012-07-31 00:26:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230096887414419459",
  "text" : "I only get one of these, so here goes:",
  "id" : 230096887414419459,
  "created_at" : "2012-07-31 00:25:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230074819050369024",
  "text" : "How many people only interact with Google+ because it makes an obnoxious, eye grabbing animation and not because it's actually useful?",
  "id" : 230074819050369024,
  "created_at" : "2012-07-30 22:58:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230073304696889344",
  "geo" : { },
  "id_str" : "230073435869573120",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden whaaaat!!?",
  "id" : 230073435869573120,
  "in_reply_to_status_id" : 230073304696889344,
  "created_at" : "2012-07-30 22:52:36 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "LordLobo",
      "screen_name" : "LordLobo",
      "indices" : [ 12, 21 ],
      "id_str" : "14355579",
      "id" : 14355579
    }, {
      "name" : "Aki the Conqueror",
      "screen_name" : "gesa",
      "indices" : [ 22, 27 ],
      "id_str" : "9321562",
      "id" : 9321562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230072766819352576",
  "geo" : { },
  "id_str" : "230073111293329410",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @LordLobo @gesa does it still make a loud, annoying blast of TOOOT TOOOOOOOOT every time it's your turn?",
  "id" : 230073111293329410,
  "in_reply_to_status_id" : 230072766819352576,
  "created_at" : "2012-07-30 22:51:18 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230071011729625088",
  "geo" : { },
  "id_str" : "230072443979575296",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 :(",
  "id" : 230072443979575296,
  "in_reply_to_status_id" : 230071011729625088,
  "created_at" : "2012-07-30 22:48:39 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The AV Club",
      "screen_name" : "TheAVClub",
      "indices" : [ 0, 10 ],
      "id_str" : "16027904",
      "id" : 16027904
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/FaDat3kI",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v5Lmkm5EF5E",
      "display_url" : "youtube.com\/watch?v=v5Lmkm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "230069016650199040",
  "geo" : { },
  "id_str" : "230071634533437441",
  "in_reply_to_user_id" : 16027904,
  "text" : "@TheAVClub @kevinpurdy there are way better Buffalo buffalo buffalo Buffalo videos. http:\/\/t.co\/FaDat3kI",
  "id" : 230071634533437441,
  "in_reply_to_status_id" : 230069016650199040,
  "created_at" : "2012-07-30 22:45:26 +0000",
  "in_reply_to_screen_name" : "TheAVClub",
  "in_reply_to_user_id_str" : "16027904",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 24, 33 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 34, 42 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/230045379855527936\/photo\/1",
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/QU3IR2Yn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzFJDdzCMAAouXO.png",
      "id_str" : "230045379859722240",
      "id" : 230045379859722240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzFJDdzCMAAouXO.png",
      "sizes" : [ {
        "h" : 93,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 93,
        "resize" : "fit",
        "w" : 724
      }, {
        "h" : 43,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 93,
        "resize" : "fit",
        "w" : 724
      } ],
      "display_url" : "pic.twitter.com\/QU3IR2Yn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230045379855527936",
  "text" : "Uh...what the fuck? \/cc @marcweil @dmansen http:\/\/t.co\/QU3IR2Yn",
  "id" : 230045379855527936,
  "created_at" : "2012-07-30 21:01:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230038191376326656",
  "geo" : { },
  "id_str" : "230042486301679616",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave\n\nCongratulations, that's it\nHave a chocolate!",
  "id" : 230042486301679616,
  "in_reply_to_status_id" : 230038191376326656,
  "created_at" : "2012-07-30 20:49:37 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit.txt",
      "screen_name" : "Reddit_txt",
      "indices" : [ 40, 51 ],
      "id_str" : "489467009",
      "id" : 489467009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230038444531920896",
  "text" : "I feel for the poor human's soul behind @Reddit_txt. Oh how it must ache and weigh heavy with lack of faith in humanity.",
  "id" : 230038444531920896,
  "created_at" : "2012-07-30 20:33:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230037921984548864",
  "geo" : { },
  "id_str" : "230038038695260160",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten i hope you didn't go to Henrietta just for that.",
  "id" : 230038038695260160,
  "in_reply_to_status_id" : 230037921984548864,
  "created_at" : "2012-07-30 20:31:56 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230028089340616705",
  "geo" : { },
  "id_str" : "230029735357448193",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella \/play greatjob",
  "id" : 230029735357448193,
  "in_reply_to_status_id" : 230028089340616705,
  "created_at" : "2012-07-30 19:58:57 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230024981818507265",
  "text" : "I need a \"run the currently running command in screen without interrupting the command since I'm stupid and forget every time\" command.",
  "id" : 230024981818507265,
  "created_at" : "2012-07-30 19:40:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230015903251705856",
  "geo" : { },
  "id_str" : "230018400552882176",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes also you can straight up link stuff into RM...I linked up SSPullToRefresh and it works great.",
  "id" : 230018400552882176,
  "in_reply_to_status_id" : 230015903251705856,
  "created_at" : "2012-07-30 19:13:54 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230015997157994496",
  "geo" : { },
  "id_str" : "230017627177750528",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes cool, i just can't get into hunting through XCode. Going to read through Cheddar, got it building. Thanks for opening it up.",
  "id" : 230017627177750528,
  "in_reply_to_status_id" : 230015997157994496,
  "created_at" : "2012-07-30 19:10:50 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheddar",
      "screen_name" : "cheddar",
      "indices" : [ 0, 8 ],
      "id_str" : "255281668",
      "id" : 255281668
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 9, 19 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230009517121871872",
  "geo" : { },
  "id_str" : "230015656282685440",
  "in_reply_to_user_id" : 255281668,
  "text" : "@cheddar @samsoffes this is neat. going to get it building. do you think it would have been any easier to build w\/ RubyMotion?",
  "id" : 230015656282685440,
  "in_reply_to_status_id" : 230009517121871872,
  "created_at" : "2012-07-30 19:03:00 +0000",
  "in_reply_to_screen_name" : "cheddar",
  "in_reply_to_user_id_str" : "255281668",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 60, 70 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/aLfoWlTD",
      "expanded_url" : "http:\/\/j.mp\/Ouvquu",
      "display_url" : "j.mp\/Ouvquu"
    }, {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/RmGVDQa3",
      "expanded_url" : "http:\/\/j.mp\/LZ60nL",
      "display_url" : "j.mp\/LZ60nL"
    } ]
  },
  "geo" : { },
  "id_str" : "230003283736027136",
  "text" : "RT @wnyruby: Next monthly meetup - http:\/\/t.co\/aLfoWlTD ft. @aspleenic and another speaker TBA |  Also hackfest - http:\/\/t.co\/RmGVDQa3 - ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PJ Hagerty",
        "screen_name" : "aspleenic",
        "indices" : [ 47, 57 ],
        "id_str" : "31435721",
        "id" : 31435721
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/aLfoWlTD",
        "expanded_url" : "http:\/\/j.mp\/Ouvquu",
        "display_url" : "j.mp\/Ouvquu"
      }, {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/RmGVDQa3",
        "expanded_url" : "http:\/\/j.mp\/LZ60nL",
        "display_url" : "j.mp\/LZ60nL"
      } ]
    },
    "geo" : { },
    "id_str" : "230000355604312064",
    "text" : "Next monthly meetup - http:\/\/t.co\/aLfoWlTD ft. @aspleenic and another speaker TBA |  Also hackfest - http:\/\/t.co\/RmGVDQa3 - GET YO' RUBY ON!",
    "id" : 230000355604312064,
    "created_at" : "2012-07-30 18:02:12 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 230003283736027136,
  "created_at" : "2012-07-30 18:13:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 17, 27 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Ruby off Rails",
      "screen_name" : "RubyOffRails",
      "indices" : [ 53, 66 ],
      "id_str" : "509181827",
      "id" : 509181827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/VIqUv7OL",
      "expanded_url" : "http:\/\/jessewolgamott.com\/blog\/2012\/07\/30\/rubyoffrails-scholarship-for-women\/",
      "display_url" : "jessewolgamott.com\/blog\/2012\/07\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "229983318937059328",
  "text" : "Big good luck to @aquaranto who just applied for the @rubyoffrails scholarship! http:\/\/t.co\/VIqUv7OL",
  "id" : 229983318937059328,
  "created_at" : "2012-07-30 16:54:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229973093798518786",
  "text" : "OH \"i can replace all of my superiors with spreadsheets\"",
  "id" : 229973093798518786,
  "created_at" : "2012-07-30 16:13:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229967641043935233",
  "geo" : { },
  "id_str" : "229968070905577472",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef iPhone.",
  "id" : 229968070905577472,
  "in_reply_to_status_id" : 229967641043935233,
  "created_at" : "2012-07-30 15:53:55 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 0, 10 ],
      "id_str" : "1942",
      "id" : 1942
    }, {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 11, 20 ],
      "id_str" : "787975",
      "id" : 787975
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 21, 32 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 42, 52 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 76, 84 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229964060500828161",
  "geo" : { },
  "id_str" : "229964897209962496",
  "in_reply_to_user_id" : 1942,
  "text" : "@jremsikjr @mathiasx @ashedryden will do! @aquaranto, myself, and plenty of @WNYRuby folks will be there",
  "id" : 229964897209962496,
  "in_reply_to_status_id" : 229964060500828161,
  "created_at" : "2012-07-30 15:41:18 +0000",
  "in_reply_to_screen_name" : "jremsikjr",
  "in_reply_to_user_id_str" : "1942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229942536570023936",
  "geo" : { },
  "id_str" : "229942729688350720",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy your doppleganger should handle this from now on.",
  "id" : 229942729688350720,
  "in_reply_to_status_id" : 229942536570023936,
  "created_at" : "2012-07-30 14:13:13 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229799891143102464",
  "geo" : { },
  "id_str" : "229802578119127040",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh I\u2026need to try this.",
  "id" : 229802578119127040,
  "in_reply_to_status_id" : 229799891143102464,
  "created_at" : "2012-07-30 04:56:18 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/2QLAjJTo",
      "expanded_url" : "http:\/\/instagr.am\/p\/NsTklZs6g-\/",
      "display_url" : "instagr.am\/p\/NsTklZs6g-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "229801715002646528",
  "text" : "Must be comfortable. http:\/\/t.co\/2QLAjJTo",
  "id" : 229801715002646528,
  "created_at" : "2012-07-30 04:52:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229757539141689344",
  "text" : "YouTube has been absolutely failing lately at its core job: PLAYING VIDEOS.",
  "id" : 229757539141689344,
  "created_at" : "2012-07-30 01:57:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Swerwer",
      "screen_name" : "simonswerwer",
      "indices" : [ 0, 13 ],
      "id_str" : "277656331",
      "id" : 277656331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229753646978564096",
  "geo" : { },
  "id_str" : "229755727298826241",
  "in_reply_to_user_id" : 277656331,
  "text" : "@simonswerwer damn, I love this stuff. Was trying to get some stuff done tonight, might devolve into some DF now.",
  "id" : 229755727298826241,
  "in_reply_to_status_id" : 229753646978564096,
  "created_at" : "2012-07-30 01:50:08 +0000",
  "in_reply_to_screen_name" : "simonswerwer",
  "in_reply_to_user_id_str" : "277656331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229753677093675008",
  "geo" : { },
  "id_str" : "229754093206388737",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney ??",
  "id" : 229754093206388737,
  "in_reply_to_status_id" : 229753677093675008,
  "created_at" : "2012-07-30 01:43:39 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/YNFmO1qm",
      "expanded_url" : "http:\/\/olympicmoments.tumblr.com\/",
      "display_url" : "olympicmoments.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "229752038823718913",
  "text" : "http:\/\/t.co\/YNFmO1qm is the only Olympics coverage I care about.",
  "id" : 229752038823718913,
  "created_at" : "2012-07-30 01:35:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 24, 33 ],
      "id_str" : "19297751",
      "id" : 19297751
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 65, 74 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229718802198298624",
  "text" : "Officially caught up on @gitready issues\/pulls...now the endless @rubygems support tarpit.",
  "id" : 229718802198298624,
  "created_at" : "2012-07-29 23:23:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/BkFQyXwt",
      "expanded_url" : "http:\/\/www.teamusa.org\/Athletes\/RH\/Kimberly-Rhode.aspx",
      "display_url" : "teamusa.org\/Athletes\/RH\/Ki\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "229714892360388608",
  "geo" : { },
  "id_str" : "229718518814347265",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic Dude, 150 lbs is overweight for you? Cmon dude, she's taking home a gold. http:\/\/t.co\/BkFQyXwt",
  "id" : 229718518814347265,
  "in_reply_to_status_id" : 229714892360388608,
  "created_at" : "2012-07-29 23:22:17 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 3, 12 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/ttQVksE3",
      "expanded_url" : "http:\/\/ja.gitready.com",
      "display_url" : "ja.gitready.com"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7A1zADgf",
      "expanded_url" : "http:\/\/he.gitready.com",
      "display_url" : "he.gitready.com"
    } ]
  },
  "geo" : { },
  "id_str" : "229717883788328960",
  "text" : "RT @gitready: Welcome to our newest translation: Japanese! http:\/\/t.co\/ttQVksE3 Also, if you know Hebrew, please help translate! http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/ttQVksE3",
        "expanded_url" : "http:\/\/ja.gitready.com",
        "display_url" : "ja.gitready.com"
      }, {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/7A1zADgf",
        "expanded_url" : "http:\/\/he.gitready.com",
        "display_url" : "he.gitready.com"
      } ]
    },
    "geo" : { },
    "id_str" : "229717834584956929",
    "text" : "Welcome to our newest translation: Japanese! http:\/\/t.co\/ttQVksE3 Also, if you know Hebrew, please help translate! http:\/\/t.co\/7A1zADgf",
    "id" : 229717834584956929,
    "created_at" : "2012-07-29 23:19:34 +0000",
    "user" : {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "protected" : false,
      "id_str" : "19297751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/72335082\/2776359417_fa33869cd0_o_normal.png",
      "id" : 19297751,
      "verified" : false
    }
  },
  "id" : 229717883788328960,
  "created_at" : "2012-07-29 23:19:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229707157363372034",
  "text" : "Achievement unlocked: merge mostly Korean commit!",
  "id" : 229707157363372034,
  "created_at" : "2012-07-29 22:37:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/229658153673961472\/photo\/1",
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/XWp149kP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay_o373CMAEHxtb.png",
      "id_str" : "229658153678155777",
      "id" : 229658153678155777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay_o373CMAEHxtb.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 944
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 944
      } ],
      "display_url" : "pic.twitter.com\/XWp149kP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229658153673961472",
  "text" : "Watching a video while preparing to fix my bike with a friend, and... http:\/\/t.co\/XWp149kP",
  "id" : 229658153673961472,
  "created_at" : "2012-07-29 19:22:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/FoRfNZrt",
      "expanded_url" : "http:\/\/vimeo.com\/m\/46304267",
      "display_url" : "vimeo.com\/m\/46304267"
    } ]
  },
  "geo" : { },
  "id_str" : "229649744786489344",
  "text" : "Haunting futuristic look at UI and gamification. Glad I don't work I'm software to push us in this direction. http:\/\/t.co\/FoRfNZrt",
  "id" : 229649744786489344,
  "created_at" : "2012-07-29 18:49:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229644389717250050",
  "text" : "RT @aquaranto: Another Reminder! Buffalo Learning to Code is meeting *tomorrow night*! No prerequisites! Come on down and we'll help you ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229633165638115328",
    "text" : "Another Reminder! Buffalo Learning to Code is meeting *tomorrow night*! No prerequisites! Come on down and we'll help you get started!",
    "id" : 229633165638115328,
    "created_at" : "2012-07-29 17:43:07 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 229644389717250050,
  "created_at" : "2012-07-29 18:27:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/0LmxvZpu",
      "expanded_url" : "http:\/\/instagr.am\/p\/NrDGX6s6qR\/",
      "display_url" : "instagr.am\/p\/NrDGX6s6qR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "229624965530521601",
  "text" : "The most ridiculous array of paintings I've seen at a yard sale.  http:\/\/t.co\/0LmxvZpu",
  "id" : 229624965530521601,
  "created_at" : "2012-07-29 17:10:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229621686755012609",
  "text" : "Wonderful day to stroll on Elmwood. So many shops are dog friendly.",
  "id" : 229621686755012609,
  "created_at" : "2012-07-29 16:57:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neckbeard Hacker",
      "screen_name" : "NeckbeardHacker",
      "indices" : [ 3, 19 ],
      "id_str" : "278523798",
      "id" : 278523798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229594020022714368",
  "text" : "RT @NeckbeardHacker: Is playing Dwarf Fortress in your underwear 12 hours straight while swigging Diet Coke an olympic sport? Cause if s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229584800871239681",
    "text" : "Is playing Dwarf Fortress in your underwear 12 hours straight while swigging Diet Coke an olympic sport? Cause if so, I'm getting a medal.",
    "id" : 229584800871239681,
    "created_at" : "2012-07-29 14:30:56 +0000",
    "user" : {
      "name" : "Neckbeard Hacker",
      "screen_name" : "NeckbeardHacker",
      "protected" : false,
      "id_str" : "278523798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303125542\/neckbeard_normal.jpg",
      "id" : 278523798,
      "verified" : false
    }
  },
  "id" : 229594020022714368,
  "created_at" : "2012-07-29 15:07:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229323716272738304",
  "geo" : { },
  "id_str" : "229324418592157699",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt Go\u2019s exception handling is kind of like that. Very neat.",
  "id" : 229324418592157699,
  "in_reply_to_status_id" : 229323716272738304,
  "created_at" : "2012-07-28 21:16:16 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229235722924740609",
  "geo" : { },
  "id_str" : "229236862185787393",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 basecamp? No approval but at least would be able to collaborate on one calendar and move\/comment. Might be biased here.",
  "id" : 229236862185787393,
  "in_reply_to_status_id" : 229235722924740609,
  "created_at" : "2012-07-28 15:28:21 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229215905274527745",
  "geo" : { },
  "id_str" : "229231621902045185",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten nothing surprising in that article. What a massive disgrace and waste of good engineering minds.",
  "id" : 229231621902045185,
  "in_reply_to_status_id" : 229215905274527745,
  "created_at" : "2012-07-28 15:07:32 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/F3NVtGbj",
      "expanded_url" : "http:\/\/instagr.am\/p\/NnOvGfM6lE\/",
      "display_url" : "instagr.am\/p\/NnOvGfM6lE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "229087459626074113",
  "text" : "Finally won against the local Agricola master. Woot! http:\/\/t.co\/F3NVtGbj",
  "id" : 229087459626074113,
  "created_at" : "2012-07-28 05:34:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229004628170248192",
  "geo" : { },
  "id_str" : "229006196248567808",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton haha what?! Haven\u2019t been watching but we\u2019re gonna play tonight",
  "id" : 229006196248567808,
  "in_reply_to_status_id" : 229004628170248192,
  "created_at" : "2012-07-28 00:11:46 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/ExrQ430G",
      "expanded_url" : "http:\/\/instagr.am\/p\/NmcFcus6h3\/",
      "display_url" : "instagr.am\/p\/NmcFcus6h3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "228976008487895044",
  "text" : "Grillin' helper http:\/\/t.co\/ExrQ430G",
  "id" : 228976008487895044,
  "created_at" : "2012-07-27 22:11:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/AjIuVAgZ",
      "expanded_url" : "http:\/\/instagr.am\/p\/NmH_PFM6kP\/",
      "display_url" : "instagr.am\/p\/NmH_PFM6kP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "228932025086799872",
  "text" : "Absolute fail on my first RoboRally turn. (started at 3) http:\/\/t.co\/AjIuVAgZ",
  "id" : 228932025086799872,
  "created_at" : "2012-07-27 19:17:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228899184466604032",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik: not sure about staging...i do know slicehost has bounced the server, perhaps needs a reboot?",
  "id" : 228899184466604032,
  "created_at" : "2012-07-27 17:06:32 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228844982868537344",
  "text" : "Really enjoying YouTube's \"Refresh 3 times to watch one video\" feature. Boy it's great!",
  "id" : 228844982868537344,
  "created_at" : "2012-07-27 13:31:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228793836527296512",
  "geo" : { },
  "id_str" : "228839850546184192",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle any local game shops?",
  "id" : 228839850546184192,
  "in_reply_to_status_id" : 228793836527296512,
  "created_at" : "2012-07-27 13:10:46 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Smithee",
      "screen_name" : "barfcaptain",
      "indices" : [ 3, 15 ],
      "id_str" : "1226873053",
      "id" : 1226873053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/hcd7pBix",
      "expanded_url" : "http:\/\/gunshowcomic.com\/578",
      "display_url" : "gunshowcomic.com\/578"
    } ]
  },
  "geo" : { },
  "id_str" : "228706393572659201",
  "text" : "RT @barfcaptain: charlie brown seeks advice http:\/\/t.co\/hcd7pBix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/hcd7pBix",
        "expanded_url" : "http:\/\/gunshowcomic.com\/578",
        "display_url" : "gunshowcomic.com\/578"
      } ]
    },
    "geo" : { },
    "id_str" : "228701677967011841",
    "text" : "charlie brown seeks advice http:\/\/t.co\/hcd7pBix",
    "id" : 228701677967011841,
    "created_at" : "2012-07-27 04:01:43 +0000",
    "user" : {
      "name" : "kc gr\u0259\u0259n",
      "screen_name" : "kcgreenn",
      "protected" : false,
      "id_str" : "16522244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573812132753620992\/Hmui3IXO_normal.jpeg",
      "id" : 16522244,
      "verified" : false
    }
  },
  "id" : 228706393572659201,
  "created_at" : "2012-07-27 04:20:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228686084119343104",
  "text" : "Finally tried Dungeon Defenders...you can tell it's a PC game, completely obsessed with menus popping up over gameplay on Xbox.",
  "id" : 228686084119343104,
  "created_at" : "2012-07-27 02:59:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R Murphy",
      "screen_name" : "michaelmurphy",
      "indices" : [ 0, 14 ],
      "id_str" : "11092742",
      "id" : 11092742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228654445725102081",
  "geo" : { },
  "id_str" : "228654751032696832",
  "in_reply_to_user_id" : 11092742,
  "text" : "@michaelmurphy nope, just come on by!",
  "id" : 228654751032696832,
  "in_reply_to_status_id" : 228654445725102081,
  "created_at" : "2012-07-27 00:55:15 +0000",
  "in_reply_to_screen_name" : "michaelmurphy",
  "in_reply_to_user_id_str" : "11092742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228654265508446208",
  "geo" : { },
  "id_str" : "228654503858171904",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit that was trolling. dear god no.",
  "id" : 228654503858171904,
  "in_reply_to_status_id" : 228654265508446208,
  "created_at" : "2012-07-27 00:54:16 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228653625809965056",
  "geo" : { },
  "id_str" : "228653981285642240",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit post to craigslist, offer equity and no cash. I heard this works well.",
  "id" : 228653981285642240,
  "in_reply_to_status_id" : 228653625809965056,
  "created_at" : "2012-07-27 00:52:11 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robison",
      "screen_name" : "robisonrobison",
      "indices" : [ 0, 15 ],
      "id_str" : "47352570",
      "id" : 47352570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228526838228582400",
  "geo" : { },
  "id_str" : "228643733229412352",
  "in_reply_to_user_id" : 47352570,
  "text" : "@robisonrobison thanks for coming in! Pumped to hear it.",
  "id" : 228643733229412352,
  "in_reply_to_status_id" : 228526838228582400,
  "created_at" : "2012-07-27 00:11:28 +0000",
  "in_reply_to_screen_name" : "robisonrobison",
  "in_reply_to_user_id_str" : "47352570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R Murphy",
      "screen_name" : "michaelmurphy",
      "indices" : [ 0, 14 ],
      "id_str" : "11092742",
      "id" : 11092742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228609320642830337",
  "geo" : { },
  "id_str" : "228643553180524544",
  "in_reply_to_user_id" : 11092742,
  "text" : "@michaelmurphy we do have a separate meeting space that would work for this. Going to come down next week to check it out?",
  "id" : 228643553180524544,
  "in_reply_to_status_id" : 228609320642830337,
  "created_at" : "2012-07-27 00:10:45 +0000",
  "in_reply_to_screen_name" : "michaelmurphy",
  "in_reply_to_user_id_str" : "11092742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228627920497823744",
  "geo" : { },
  "id_str" : "228629226847346688",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh Just spent over $50 on new tires and tubes literally last week. FFS :[",
  "id" : 228629226847346688,
  "in_reply_to_status_id" : 228627920497823744,
  "created_at" : "2012-07-26 23:13:50 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228622811684560896",
  "geo" : { },
  "id_str" : "228623604483502080",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh pretty sure I hit a curb at semi-full speed and that blew them. :\/",
  "id" : 228623604483502080,
  "in_reply_to_status_id" : 228622811684560896,
  "created_at" : "2012-07-26 22:51:29 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228612017089544192",
  "text" : "Second time in two weeks my bike tires have gone flat. WTF.",
  "id" : 228612017089544192,
  "created_at" : "2012-07-26 22:05:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 42, 53 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/dx9jWw0l",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-w-58hQ9dLk",
      "display_url" : "youtube.com\/watch?v=-w-58h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228593648156168192",
  "text" : "Current status: http:\/\/t.co\/dx9jWw0l (via @trevorturk)",
  "id" : 228593648156168192,
  "created_at" : "2012-07-26 20:52:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/9VZq7i4u",
      "expanded_url" : "http:\/\/clubhaus.tumblr.com\/post\/28066056569\/buffalo-foodies-take-note-theres-a-new-food",
      "display_url" : "clubhaus.tumblr.com\/post\/280660565\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228554323649511424",
  "text" : "Hell yes, *another* food truck in Buffalo. http:\/\/t.co\/9VZq7i4u",
  "id" : 228554323649511424,
  "created_at" : "2012-07-26 18:16:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228552391740506112",
  "geo" : { },
  "id_str" : "228552651305021441",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape paypal?",
  "id" : 228552651305021441,
  "in_reply_to_status_id" : 228552391740506112,
  "created_at" : "2012-07-26 18:09:33 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228545410497658880",
  "text" : "\"The operation couldn\u2019-t -b-e -c-o-m-p-l-e-t-e-d-. -(-A-S-H-T-T-P-C-o-n-n-e-c-t-i-o-n-E-r-r-o-r-D-o-m-a-i-n -e-r-r-o-r -4-0-0-.-)-\"",
  "id" : 228545410497658880,
  "created_at" : "2012-07-26 17:40:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/nyHULfZD",
      "expanded_url" : "http:\/\/brontecapital.blogspot.com\/2012\/07\/changing-my-mind-on-microsoft.html",
      "display_url" : "brontecapital.blogspot.com\/2012\/07\/changi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228540466788982784",
  "text" : "\"Nowadays nobody under thirty writes anything on Microsoft developer tools unless they are demented or brain-dead.\" http:\/\/t.co\/nyHULfZD",
  "id" : 228540466788982784,
  "created_at" : "2012-07-26 17:21:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arnout Kazemier",
      "screen_name" : "3rdEden",
      "indices" : [ 0, 8 ],
      "id_str" : "14350255",
      "id" : 14350255
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 9, 21 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228506682928533504",
  "geo" : { },
  "id_str" : "228507825909948416",
  "in_reply_to_user_id" : 14350255,
  "text" : "@3rdEden @SaraJChipps emoji works in Terminal in Lion as well...did this change in ML?",
  "id" : 228507825909948416,
  "in_reply_to_status_id" : 228506682928533504,
  "created_at" : "2012-07-26 15:11:25 +0000",
  "in_reply_to_screen_name" : "3rdEden",
  "in_reply_to_user_id_str" : "14350255",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/oYCC7WUd",
      "expanded_url" : "http:\/\/www.codeofhonor.com\/blog\/the-making-of-warcraft-part-1",
      "display_url" : "codeofhonor.com\/blog\/the-makin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228340219282337792",
  "text" : "I love stories like this: The Making of Warcraft 1: Origin of the series &amp; creation of multi-unit select\u2026 http:\/\/t.co\/oYCC7WUd",
  "id" : 228340219282337792,
  "created_at" : "2012-07-26 04:05:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228338074147512320",
  "geo" : { },
  "id_str" : "228339090255405056",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda this continues to baffle me.",
  "id" : 228339090255405056,
  "in_reply_to_status_id" : 228338074147512320,
  "created_at" : "2012-07-26 04:00:56 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "indices" : [ 3, 16 ],
      "id_str" : "3479601",
      "id" : 3479601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/ipuCEFWA",
      "expanded_url" : "http:\/\/kottke.org\/12\/07\/what-cricket-looks-like-to-americans",
      "display_url" : "kottke.org\/12\/07\/what-cri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228338717163663361",
  "text" : "RT @justingoboom: What cricket looks like to Americans: http:\/\/t.co\/ipuCEFWA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/ipuCEFWA",
        "expanded_url" : "http:\/\/kottke.org\/12\/07\/what-cricket-looks-like-to-americans",
        "display_url" : "kottke.org\/12\/07\/what-cri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "228327230349119489",
    "text" : "What cricket looks like to Americans: http:\/\/t.co\/ipuCEFWA",
    "id" : 228327230349119489,
    "created_at" : "2012-07-26 03:13:48 +0000",
    "user" : {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "protected" : false,
      "id_str" : "3479601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1477957942\/74E164F3-C522-4E41-98D1-C7A780056F92_normal",
      "id" : 3479601,
      "verified" : false
    }
  },
  "id" : 228338717163663361,
  "created_at" : "2012-07-26 03:59:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 3, 14 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228333132380766208",
  "text" : "RT @dangigante: There's never been a better time to be a geek in buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228328069960699905",
    "text" : "There's never been a better time to be a geek in buffalo",
    "id" : 228328069960699905,
    "created_at" : "2012-07-26 03:17:08 +0000",
    "user" : {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "protected" : false,
      "id_str" : "43151378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482218130996232192\/bISq7rRg_normal.jpeg",
      "id" : 43151378,
      "verified" : false
    }
  },
  "id" : 228333132380766208,
  "created_at" : "2012-07-26 03:37:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/F3RPOweE",
      "expanded_url" : "http:\/\/instagr.am\/p\/NhxlHqs6kL\/",
      "display_url" : "instagr.am\/p\/NhxlHqs6kL\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.92746025, -78.877081 ]
  },
  "id_str" : "228319576495104000",
  "text" : "THRID PLACE CHAMPS  @ Mister Goodbar http:\/\/t.co\/F3RPOweE",
  "id" : 228319576495104000,
  "created_at" : "2012-07-26 02:43:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/bGb1a2uf",
      "expanded_url" : "http:\/\/instagr.am\/p\/Nhxj_is6kJ\/",
      "display_url" : "instagr.am\/p\/Nhxj_is6kJ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.92746025, -78.877081 ]
  },
  "id_str" : "228319572636356608",
  "text" : "THRID PLACE CHAMPS  @ Mister Goodbar http:\/\/t.co\/bGb1a2uf",
  "id" : 228319572636356608,
  "created_at" : "2012-07-26 02:43:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228308992718422017",
  "text" : "Comic\u2019s mom is in the audience\u2026this is turrible.",
  "id" : 228308992718422017,
  "created_at" : "2012-07-26 02:01:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228306673343803392",
  "text" : "Apparently OpenBeer turned into crappy OpenComedy?",
  "id" : 228306673343803392,
  "created_at" : "2012-07-26 01:52:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228270570222022656",
  "geo" : { },
  "id_str" : "228276095055716353",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes +1",
  "id" : 228276095055716353,
  "in_reply_to_status_id" : 228270570222022656,
  "created_at" : "2012-07-25 23:50:36 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/cwdvbtt4",
      "expanded_url" : "http:\/\/4sq.com\/OnD5Hy",
      "display_url" : "4sq.com\/OnD5Hy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9170300112, -78.8769742695 ]
  },
  "id_str" : "228262171312791552",
  "text" : "OpenBeer! Buffalo tech folks, you need to be here. (@ The Blue Monk w\/ 5 others) http:\/\/t.co\/cwdvbtt4",
  "id" : 228262171312791552,
  "created_at" : "2012-07-25 22:55:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    }, {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 11, 24 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/Gn1eIWCF",
      "expanded_url" : "http:\/\/www.terravivos.com\/images\/vivosrockiesplans.pdf",
      "display_url" : "terravivos.com\/images\/vivosro\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "228218632398839809",
  "geo" : { },
  "id_str" : "228218920933392384",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato @moonpolysoft http:\/\/t.co\/Gn1eIWCF",
  "id" : 228218920933392384,
  "in_reply_to_status_id" : 228218632398839809,
  "created_at" : "2012-07-25 20:03:25 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228218129933815809",
  "geo" : { },
  "id_str" : "228218448268886016",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft THREATSUPERVOLCANO.HTM",
  "id" : 228218448268886016,
  "in_reply_to_status_id" : 228218129933815809,
  "created_at" : "2012-07-25 20:01:32 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/udSjg5J6",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dogs\/comments\/x3lxa\/lets_ask_reddit_what_kind_of_dog_is_this\/c5ixmzx",
      "display_url" : "reddit.com\/r\/dogs\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228204065392295936",
  "text" : "Reddit in a nutshell: http:\/\/t.co\/udSjg5J6",
  "id" : 228204065392295936,
  "created_at" : "2012-07-25 19:04:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pizza Amore-WoodFire",
      "screen_name" : "MobileWoodFire",
      "indices" : [ 0, 15 ],
      "id_str" : "313074936",
      "id" : 313074936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/Dzu6QagV",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ngz9zjM6rc\/",
      "display_url" : "instagr.am\/p\/Ngz9zjM6rc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "228184167240843264",
  "in_reply_to_user_id" : 313074936,
  "text" : "@MobileWoodFire + canalside = awesome lunch! http:\/\/t.co\/Dzu6QagV",
  "id" : 228184167240843264,
  "created_at" : "2012-07-25 17:45:19 +0000",
  "in_reply_to_screen_name" : "MobileWoodFire",
  "in_reply_to_user_id_str" : "313074936",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228162324945584128",
  "text" : "It's 2012 and I still can't fucking center vertically in HTML.",
  "id" : 228162324945584128,
  "created_at" : "2012-07-25 16:18:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "228141004698566657",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Stevie Wonder: Boogie On Reggae Woman \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 228141004698566657,
  "created_at" : "2012-07-25 14:53:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pizza Amore-WoodFire",
      "screen_name" : "MobileWoodFire",
      "indices" : [ 0, 15 ],
      "id_str" : "313074936",
      "id" : 313074936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228113865332895744",
  "geo" : { },
  "id_str" : "228134021660557314",
  "in_reply_to_user_id" : 313074936,
  "text" : "@MobileWoodFire *when* ?",
  "id" : 228134021660557314,
  "in_reply_to_status_id" : 228113865332895744,
  "created_at" : "2012-07-25 14:26:03 +0000",
  "in_reply_to_screen_name" : "MobileWoodFire",
  "in_reply_to_user_id_str" : "313074936",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/bGYICsok",
      "expanded_url" : "http:\/\/phpjs.org\/",
      "display_url" : "phpjs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "228133391554457600",
  "text" : "WHYYYYYYYYYYYYYY http:\/\/t.co\/bGYICsok",
  "id" : 228133391554457600,
  "created_at" : "2012-07-25 14:23:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "indices" : [ 3, 9 ],
      "id_str" : "12602932",
      "id" : 12602932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/wwOEZwq8",
      "expanded_url" : "http:\/\/twitpic.com\/ablgga",
      "display_url" : "twitpic.com\/ablgga"
    } ]
  },
  "geo" : { },
  "id_str" : "228131475571228673",
  "text" : "RT @wilto: \u2019Atta boy, Mumbles. \u2019Atta boy.\nhttp:\/\/t.co\/wwOEZwq8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/wwOEZwq8",
        "expanded_url" : "http:\/\/twitpic.com\/ablgga",
        "display_url" : "twitpic.com\/ablgga"
      } ]
    },
    "geo" : { },
    "id_str" : "228127420484567040",
    "text" : "\u2019Atta boy, Mumbles. \u2019Atta boy.\nhttp:\/\/t.co\/wwOEZwq8",
    "id" : 228127420484567040,
    "created_at" : "2012-07-25 13:59:50 +0000",
    "user" : {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "protected" : false,
      "id_str" : "12602932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477441227986444289\/KHCUqTis_normal.png",
      "id" : 12602932,
      "verified" : false
    }
  },
  "id" : 228131475571228673,
  "created_at" : "2012-07-25 14:15:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228130298062323715",
  "text" : "Also, made this stupid account last night: @rererepeat. Thinking I need to tape little  videos of going through the timeline for each song.",
  "id" : 228130298062323715,
  "created_at" : "2012-07-25 14:11:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Z66myHJ1",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5K1RcKJVbHA",
      "display_url" : "youtube.com\/watch?v=5K1RcK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228129775980531712",
  "text" : "Good morning internet. Here's something funny: http:\/\/t.co\/Z66myHJ1",
  "id" : 228129775980531712,
  "created_at" : "2012-07-25 14:09:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228123571476652034",
  "text" : "I can\u2019t stress enough how awesome TestFlight is. Why on earth can\u2019t I pay for this?",
  "id" : 228123571476652034,
  "created_at" : "2012-07-25 13:44:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227988587562561536",
  "text" : "Related: if this idea has been done or is stupid, feel free to yell!",
  "id" : 227988587562561536,
  "created_at" : "2012-07-25 04:48:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227988039262150656",
  "text" : "Concept proven, I\u2019ll look into some more songs tomorrow\u2026thanks for the suggestions so far!",
  "id" : 227988039262150656,
  "created_at" : "2012-07-25 04:45:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/10UAxTfs",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=lwS_YDzxH3M",
      "display_url" : "youtube.com\/watch?v=lwS_YD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227987735741353984",
  "text" : "I\u2019ve run out of steam, but here it goes: @rererepeat. Retweeting songs! First up, Yesterday. http:\/\/t.co\/10UAxTfs",
  "id" : 227987735741353984,
  "created_at" : "2012-07-25 04:44:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Andy Staple",
      "screen_name" : "AndyStaple",
      "indices" : [ 48, 59 ],
      "id_str" : "34352961",
      "id" : 34352961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227985475061817344",
  "geo" : { },
  "id_str" : "227986402195951616",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie whoa simmer! That might work. \/cc @andystaple",
  "id" : 227986402195951616,
  "in_reply_to_status_id" : 227985475061817344,
  "created_at" : "2012-07-25 04:39:28 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Buffalogal in NYC",
      "screen_name" : "Buffalogal",
      "indices" : [ 0, 11 ],
      "id_str" : "14500105",
      "id" : 14500105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227980085490233344",
  "geo" : { },
  "id_str" : "227981196292915201",
  "in_reply_to_user_id" : 14500105,
  "text" : "@Buffalogal oh it\u2019s perfect.",
  "id" : 227981196292915201,
  "in_reply_to_status_id" : 227980085490233344,
  "created_at" : "2012-07-25 04:18:47 +0000",
  "in_reply_to_screen_name" : "Buffalogal",
  "in_reply_to_user_id_str" : "14500105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Buffalogal in NYC",
      "screen_name" : "Buffalogal",
      "indices" : [ 0, 11 ],
      "id_str" : "14500105",
      "id" : 14500105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227979496224092160",
  "geo" : { },
  "id_str" : "227979970021052416",
  "in_reply_to_user_id" : 14500105,
  "text" : "@Buffalogal that might work!",
  "id" : 227979970021052416,
  "in_reply_to_status_id" : 227979496224092160,
  "created_at" : "2012-07-25 04:13:55 +0000",
  "in_reply_to_screen_name" : "Buffalogal",
  "in_reply_to_user_id_str" : "14500105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227979079813570561",
  "text" : "Literally have heard of zero bands so far.",
  "id" : 227979079813570561,
  "created_at" : "2012-07-25 04:10:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227978958203932673",
  "text" : "Old songs, you ridiculous indie hipsters.",
  "id" : 227978958203932673,
  "created_at" : "2012-07-25 04:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227977769395580928",
  "text" : "Crazy, stupid twitter idea brewing\u2026what\u2019s your favorite song?",
  "id" : 227977769395580928,
  "created_at" : "2012-07-25 04:05:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/jvA9x9Pq",
      "expanded_url" : "http:\/\/www.jpl.nasa.gov\/news\/news.cfm?release=2012-217",
      "display_url" : "jpl.nasa.gov\/news\/news.cfm?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227938211123572737",
  "text" : "When you know you've played too much Dwarf Fortress: http:\/\/t.co\/jvA9x9Pq seems like a good place for an embark.",
  "id" : 227938211123572737,
  "created_at" : "2012-07-25 01:27:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 12, 26 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227926213476372480",
  "geo" : { },
  "id_str" : "227927046507073537",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @coworkbuffalo sounds awesome! love the name. Huge +1",
  "id" : 227927046507073537,
  "in_reply_to_status_id" : 227926213476372480,
  "created_at" : "2012-07-25 00:43:37 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227920822797492224",
  "geo" : { },
  "id_str" : "227922963444428801",
  "in_reply_to_user_id" : 324160285,
  "text" : "@DuglasYun Totally going to be there.",
  "id" : 227922963444428801,
  "in_reply_to_status_id" : 227920822797492224,
  "created_at" : "2012-07-25 00:27:23 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227921478346223616",
  "text" : "Can totally hear the concert from our porch as well. Hell yes.",
  "id" : 227921478346223616,
  "created_at" : "2012-07-25 00:21:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227918387374874624",
  "geo" : { },
  "id_str" : "227920265437401088",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik dude, really? This is a ridiculous statement.",
  "id" : 227920265437401088,
  "in_reply_to_status_id" : 227918387374874624,
  "created_at" : "2012-07-25 00:16:40 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227915496127877120",
  "geo" : { },
  "id_str" : "227916592179195904",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan CoffeeScript is not that bad. It writes better JS than any sane person can.",
  "id" : 227916592179195904,
  "in_reply_to_status_id" : 227915496127877120,
  "created_at" : "2012-07-25 00:02:04 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/wvT5Zf0v",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ne57nMs6kP\/",
      "display_url" : "instagr.am\/p\/Ne57nMs6kP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "227915721328431104",
  "text" : "I can get used to concerts on my street every Tuesday. http:\/\/t.co\/wvT5Zf0v",
  "id" : 227915721328431104,
  "created_at" : "2012-07-24 23:58:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/HmS1FR1O",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/nasamarshall\/7637356614\/in\/photostream\/",
      "display_url" : "flickr.com\/photos\/nasamar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227882312514297858",
  "text" : "WNY from the ISS. Proud to live here. http:\/\/t.co\/HmS1FR1O",
  "id" : 227882312514297858,
  "created_at" : "2012-07-24 21:45:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Van Patten Media",
      "screen_name" : "vanpattenmedia",
      "indices" : [ 16, 31 ],
      "id_str" : "250462373",
      "id" : 250462373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227875071061024768",
  "geo" : { },
  "id_str" : "227875359222288384",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @vanpattenmedia Fuck yeah!",
  "id" : 227875359222288384,
  "in_reply_to_status_id" : 227875071061024768,
  "created_at" : "2012-07-24 21:18:14 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227831083167805441",
  "geo" : { },
  "id_str" : "227842223008542720",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv Hartford.",
  "id" : 227842223008542720,
  "in_reply_to_status_id" : 227831083167805441,
  "created_at" : "2012-07-24 19:06:33 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mattwynne",
      "screen_name" : "mattwynne",
      "indices" : [ 0, 10 ],
      "id_str" : "15994184",
      "id" : 15994184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227841881126621184",
  "geo" : { },
  "id_str" : "227842027088400384",
  "in_reply_to_user_id" : 15994184,
  "text" : "@mattwynne I do this all the time...you can ask for a new one!",
  "id" : 227842027088400384,
  "in_reply_to_status_id" : 227841881126621184,
  "created_at" : "2012-07-24 19:05:47 +0000",
  "in_reply_to_screen_name" : "mattwynne",
  "in_reply_to_user_id_str" : "15994184",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/9c8I1q1C",
      "expanded_url" : "http:\/\/i.imgur.com\/X6O2K.png",
      "display_url" : "i.imgur.com\/X6O2K.png"
    } ]
  },
  "geo" : { },
  "id_str" : "227819646177386497",
  "text" : "Best amazon review ever? http:\/\/t.co\/9c8I1q1C",
  "id" : 227819646177386497,
  "created_at" : "2012-07-24 17:36:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227814154281558017",
  "text" : "\/play deeper",
  "id" : 227814154281558017,
  "created_at" : "2012-07-24 17:15:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227813855168978944",
  "geo" : { },
  "id_str" : "227814044558561280",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette can't use define_method :[",
  "id" : 227814044558561280,
  "in_reply_to_status_id" : 227813855168978944,
  "created_at" : "2012-07-24 17:14:35 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227806978888581120",
  "geo" : { },
  "id_str" : "227807137227739136",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante pretty sure there's no defined end to it...and it's not a class, it's self-learning\/taught.",
  "id" : 227807137227739136,
  "in_reply_to_status_id" : 227806978888581120,
  "created_at" : "2012-07-24 16:47:08 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227806172571381760",
  "geo" : { },
  "id_str" : "227806373994434560",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante ??",
  "id" : 227806373994434560,
  "in_reply_to_status_id" : 227806172571381760,
  "created_at" : "2012-07-24 16:44:06 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227806206360686593",
  "text" : "Correction: workflow comes with ActiveRecord integration. Couldn't find a simpler pure ruby state machine implementation.",
  "id" : 227806206360686593,
  "created_at" : "2012-07-24 16:43:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 137 ],
      "url" : "https:\/\/t.co\/Pzx3ufig",
      "expanded_url" : "https:\/\/github.com\/geekq\/workflow",
      "display_url" : "github.com\/geekq\/workflow"
    } ]
  },
  "geo" : { },
  "id_str" : "227805517970538496",
  "text" : "Amazed that workflow is the only state gem I can find so far that is one file, and doesn't have any SQL junk in it. https:\/\/t.co\/Pzx3ufig",
  "id" : 227805517970538496,
  "created_at" : "2012-07-24 16:40:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 38, 48 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227804958332968960",
  "geo" : { },
  "id_str" : "227805352719167488",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef I'm at @coworkbuffalo, and @theediguy has now been trained in the art of doors",
  "id" : 227805352719167488,
  "in_reply_to_status_id" : 227804958332968960,
  "created_at" : "2012-07-24 16:40:03 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 0, 13 ],
      "id_str" : "16159121",
      "id" : 16159121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227798063257907200",
  "geo" : { },
  "id_str" : "227804234165391360",
  "in_reply_to_user_id" : 16159121,
  "text" : "@chaseclemons I walked from the office to Whole Foods on the south side for a bag to take home after my first visit to Chicago.",
  "id" : 227804234165391360,
  "in_reply_to_status_id" : 227798063257907200,
  "created_at" : "2012-07-24 16:35:36 +0000",
  "in_reply_to_screen_name" : "chaseclemons",
  "in_reply_to_user_id_str" : "16159121",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airbnb",
      "screen_name" : "Airbnb",
      "indices" : [ 19, 26 ],
      "id_str" : "17416571",
      "id" : 17416571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/LxWu0NPf",
      "expanded_url" : "https:\/\/img.skitch.com\/20120724-cbphebkf2i4we47bbtcuwu2bcs.png",
      "display_url" : "img.skitch.com\/20120724-cbphe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227782205974401025",
  "text" : "Oof, bad deploy at @airbnb? Seeing some admin links... https:\/\/t.co\/LxWu0NPf",
  "id" : 227782205974401025,
  "created_at" : "2012-07-24 15:08:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/zDrneqsc",
      "expanded_url" : "http:\/\/3.bp.blogspot.com\/_9Qcuj1qVI20\/THPtYdIYPuI\/AAAAAAAABIY\/rPU180WKlEc\/s1600\/Moscow+Traffic+Jams.jpg",
      "display_url" : "3.bp.blogspot.com\/_9Qcuj1qVI20\/T\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "227765319232520192",
  "geo" : { },
  "id_str" : "227766466550837248",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek current merge status: http:\/\/t.co\/zDrneqsc",
  "id" : 227766466550837248,
  "in_reply_to_status_id" : 227765319232520192,
  "created_at" : "2012-07-24 14:05:31 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227739165012398080",
  "text" : "RT @bquarant: All praise be to Git, master of the cloud, knower of all changes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227737690181881857",
    "text" : "All praise be to Git, master of the cloud, knower of all changes",
    "id" : 227737690181881857,
    "created_at" : "2012-07-24 12:11:11 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 227739165012398080,
  "created_at" : "2012-07-24 12:17:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/XyxbfSuB",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ndlyeis6nI\/",
      "display_url" : "instagr.am\/p\/Ndlyeis6nI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "227730697891221504",
  "text" : "Are you up yet? How about now? http:\/\/t.co\/XyxbfSuB",
  "id" : 227730697891221504,
  "created_at" : "2012-07-24 11:43:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227615007519698945",
  "geo" : { },
  "id_str" : "227615834409938944",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten same. If I need code to stick around, it\u2019s in Git.",
  "id" : 227615834409938944,
  "in_reply_to_status_id" : 227615007519698945,
  "created_at" : "2012-07-24 04:06:58 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227614529448714241",
  "text" : "Started on the kind of refactor that won\u2019t stop rolling around my brain. Gemcutter\u2019s indexer was similar\u2026days of thought, plotting.",
  "id" : 227614529448714241,
  "created_at" : "2012-07-24 04:01:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/227584671893049344\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/Tj0Yp08x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyiLDaTCUAE0zYJ.png",
      "id_str" : "227584671897243649",
      "id" : 227584671897243649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyiLDaTCUAE0zYJ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Tj0Yp08x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227584671893049344",
  "text" : "Just discovered the zoomed out conversation view in Sparrow iOS. Le sigh. http:\/\/t.co\/Tj0Yp08x",
  "id" : 227584671893049344,
  "created_at" : "2012-07-24 02:03:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnnie Manzari",
      "screen_name" : "johnnie",
      "indices" : [ 3, 11 ],
      "id_str" : "36768736",
      "id" : 36768736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227581594528018432",
  "text" : "RT @johnnie: My favorite productivity tip: sit down and do a bunch of work.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227548592439697409",
    "text" : "My favorite productivity tip: sit down and do a bunch of work.",
    "id" : 227548592439697409,
    "created_at" : "2012-07-23 23:39:46 +0000",
    "user" : {
      "name" : "Johnnie Manzari",
      "screen_name" : "johnnie",
      "protected" : false,
      "id_str" : "36768736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1765733918\/Johnnie_3_normal.png",
      "id" : 36768736,
      "verified" : false
    }
  },
  "id" : 227581594528018432,
  "created_at" : "2012-07-24 01:50:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 55, 63 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/ZceJzxVT",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/74599322\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227551064600244225",
  "text" : "RT @aquaranto: I just added a new Hack Fest meetup for @wnyruby: http:\/\/t.co\/ZceJzxVT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 40, 48 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/ZceJzxVT",
        "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/74599322\/",
        "display_url" : "meetup.com\/Western-New-Yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "227526063499124736",
    "text" : "I just added a new Hack Fest meetup for @wnyruby: http:\/\/t.co\/ZceJzxVT",
    "id" : 227526063499124736,
    "created_at" : "2012-07-23 22:10:15 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 227551064600244225,
  "created_at" : "2012-07-23 23:49:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227550593315639296",
  "geo" : { },
  "id_str" : "227550768226512898",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten s\/(web|on tablets)\/\/g",
  "id" : 227550768226512898,
  "in_reply_to_status_id" : 227550593315639296,
  "created_at" : "2012-07-23 23:48:25 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227543666934304768",
  "geo" : { },
  "id_str" : "227544125325586432",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark is...is this actually the name?",
  "id" : 227544125325586432,
  "in_reply_to_status_id" : 227543666934304768,
  "created_at" : "2012-07-23 23:22:01 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227509407813074944",
  "geo" : { },
  "id_str" : "227519048651522048",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu boog? :[",
  "id" : 227519048651522048,
  "in_reply_to_status_id" : 227509407813074944,
  "created_at" : "2012-07-23 21:42:22 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u277A\u27A0 David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227482066055491584",
  "geo" : { },
  "id_str" : "227486658730266624",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 ...What? What language are you writing?",
  "id" : 227486658730266624,
  "in_reply_to_status_id" : 227482066055491584,
  "created_at" : "2012-07-23 19:33:40 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227481494686416896",
  "geo" : { },
  "id_str" : "227483592480141313",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 Square and Stripe are making awesome inroads. (Stripe is funded by one of the Paypal founders!)",
  "id" : 227483592480141313,
  "in_reply_to_status_id" : 227481494686416896,
  "created_at" : "2012-07-23 19:21:29 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 42, 50 ],
      "id_str" : "632391390",
      "id" : 632391390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227466112915361792",
  "text" : "On that note, I'd like to say I'm all for @z80labs. I just hope it creates businesses that make money and jobs for Buffalo.",
  "id" : 227466112915361792,
  "created_at" : "2012-07-23 18:12:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227460567147892736",
  "text" : "And there's a picture of wings and an Anchor Bar mention. For fuck's sake.",
  "id" : 227460567147892736,
  "created_at" : "2012-07-23 17:49:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/tggOqThP",
      "expanded_url" : "http:\/\/allthingsd.com\/20120723\/silicon-snowbank-a-new-incubator-for-buffalo-to-give-local-start-ups-a-different-set-of-wings\/",
      "display_url" : "allthingsd.com\/20120723\/silic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227460407365861376",
  "text" : "Does every FUCKING place have to be a SILICON SOMETHING? http:\/\/t.co\/tggOqThP",
  "id" : 227460407365861376,
  "created_at" : "2012-07-23 17:49:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "227419503078825985",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Common: The 6th Sense \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 227419503078825985,
  "created_at" : "2012-07-23 15:06:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227408788494356481",
  "geo" : { },
  "id_str" : "227409082439569409",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda this is accurate. i still feel they shit all over their customers.",
  "id" : 227409082439569409,
  "in_reply_to_status_id" : 227408788494356481,
  "created_at" : "2012-07-23 14:25:24 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227408357668044802",
  "text" : "Every Sparrow \"chirp\" when I get new mail now is a sad one. Man, what fucking sellouts.",
  "id" : 227408357668044802,
  "created_at" : "2012-07-23 14:22:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 59, 73 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodingBuffalos",
      "indices" : [ 32, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227406293420363778",
  "text" : "RT @aquaranto: Just a reminder! #CodingBuffalos is tonight @coworkbuffalo! No prerequisites to attend! Just show up and we'll help you g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 44, 58 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CodingBuffalos",
        "indices" : [ 17, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227405674471124992",
    "text" : "Just a reminder! #CodingBuffalos is tonight @coworkbuffalo! No prerequisites to attend! Just show up and we'll help you get started!!",
    "id" : 227405674471124992,
    "created_at" : "2012-07-23 14:11:52 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 227406293420363778,
  "created_at" : "2012-07-23 14:14:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227217165982498819",
  "geo" : { },
  "id_str" : "227230995487809536",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton Kenmore, NY. Suburb directly north of Buffalo.",
  "id" : 227230995487809536,
  "in_reply_to_status_id" : 227217165982498819,
  "created_at" : "2012-07-23 02:37:45 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 37, 49 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227198919355035648",
  "text" : "Hoping there\u2019s a speedy recovery for @whereslloyd Uno. Maybe time for Tres?!",
  "id" : 227198919355035648,
  "created_at" : "2012-07-23 00:30:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227106475070341120",
  "text" : "Saw an older gent with a green Tesla in Kenmore. Said he would sell it to me. Should have made an offer.",
  "id" : 227106475070341120,
  "created_at" : "2012-07-22 18:22:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226867804475887616",
  "text" : "OH \u201CWe should get two cats and name them Herp and Derp\u201D",
  "id" : 226867804475887616,
  "created_at" : "2012-07-22 02:34:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226864143980957698",
  "geo" : { },
  "id_str" : "226864530498658304",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene Smallworld!",
  "id" : 226864530498658304,
  "in_reply_to_status_id" : 226864143980957698,
  "created_at" : "2012-07-22 02:21:33 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/rsBWhlYE",
      "expanded_url" : "http:\/\/instagr.am\/p\/NXaOMIs6ha\/",
      "display_url" : "instagr.am\/p\/NXaOMIs6ha\/"
    } ]
  },
  "geo" : { },
  "id_str" : "226860882569863168",
  "text" : "Smallworld again! Mounted giants are a scary awesome combination. http:\/\/t.co\/rsBWhlYE",
  "id" : 226860882569863168,
  "created_at" : "2012-07-22 02:07:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226808087611338752",
  "geo" : { },
  "id_str" : "226808352930426881",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox \/play horn",
  "id" : 226808352930426881,
  "in_reply_to_status_id" : 226808087611338752,
  "created_at" : "2012-07-21 22:38:19 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 87 ],
      "url" : "https:\/\/t.co\/kn8vq7jy",
      "expanded_url" : "https:\/\/groups.google.com\/group\/buffalo-opencoffee-club",
      "display_url" : "groups.google.com\/group\/buffalo-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "225962641871482882",
  "geo" : { },
  "id_str" : "226807653492486145",
  "in_reply_to_user_id" : 14308987,
  "text" : "@deryldoucette welcome! We\u2019ll be open Monday as normal. Check out https:\/\/t.co\/kn8vq7jy too",
  "id" : 226807653492486145,
  "in_reply_to_status_id" : 225962641871482882,
  "created_at" : "2012-07-21 22:35:33 +0000",
  "in_reply_to_screen_name" : "daviddwdowney",
  "in_reply_to_user_id_str" : "14308987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 3, 13 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226568704031326208",
  "text" : "RT @joeferris: I like to imagine that Smalltalk Beck and guitar Beck are one person who plays face-melting solos about tiny objects with ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225650617815810048",
    "text" : "I like to imagine that Smalltalk Beck and guitar Beck are one person who plays face-melting solos about tiny objects with perfect interfaces",
    "id" : 225650617815810048,
    "created_at" : "2012-07-18 17:57:54 +0000",
    "user" : {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "protected" : false,
      "id_str" : "14575143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518019567\/jferris-square_normal.jpg",
      "id" : 14575143,
      "verified" : false
    }
  },
  "id" : 226568704031326208,
  "created_at" : "2012-07-21 06:46:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226567224171831296",
  "geo" : { },
  "id_str" : "226567784602161152",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella yep. Move to a doc for then. Value of wikis I think is more go anyone to update (gemcutter\u2019s for example)",
  "id" : 226567784602161152,
  "in_reply_to_status_id" : 226567224171831296,
  "created_at" : "2012-07-21 06:42:23 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "throneofjs",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226567585909587968",
  "text" : "Hey folks at #throneofjs, if anyone is headed to Niagara Falls or flying out of BUF give a shout, would love to grab a beer!",
  "id" : 226567585909587968,
  "created_at" : "2012-07-21 06:41:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 72, 84 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226566562130313216",
  "text" : "Another (lost) game of Agricola with friends\/family, another late night @whereslloyd run. Absolutely love being in Buffalo.",
  "id" : 226566562130313216,
  "created_at" : "2012-07-21 06:37:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226543271244079105",
  "geo" : { },
  "id_str" : "226564994324647936",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella github wikis can be cloned and updated via push too.",
  "id" : 226564994324647936,
  "in_reply_to_status_id" : 226543271244079105,
  "created_at" : "2012-07-21 06:31:18 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226536912234631168",
  "geo" : { },
  "id_str" : "226564434544435200",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies dedication!",
  "id" : 226564434544435200,
  "in_reply_to_status_id" : 226536912234631168,
  "created_at" : "2012-07-21 06:29:05 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 11, 23 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226470680533807105",
  "geo" : { },
  "id_str" : "226520043331125248",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes @bcardarella thanks for the love guys.",
  "id" : 226520043331125248,
  "in_reply_to_status_id" : 226470680533807105,
  "created_at" : "2012-07-21 03:32:41 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226469693173661696",
  "geo" : { },
  "id_str" : "226470477323960320",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k TMI",
  "id" : 226470477323960320,
  "in_reply_to_status_id" : 226469693173661696,
  "created_at" : "2012-07-21 00:15:44 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/GODSrvMP",
      "expanded_url" : "http:\/\/instagr.am\/p\/NUOMsFs6sr\/",
      "display_url" : "instagr.am\/p\/NUOMsFs6sr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "226412241111613440",
  "text" : "N+1 redundancy. http:\/\/t.co\/GODSrvMP",
  "id" : 226412241111613440,
  "created_at" : "2012-07-20 20:24:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chan",
      "screen_name" : "jtcchan",
      "indices" : [ 0, 8 ],
      "id_str" : "12653762",
      "id" : 12653762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226368246041952256",
  "geo" : { },
  "id_str" : "226404626398842880",
  "in_reply_to_user_id" : 12653762,
  "text" : "@jtcchan RIP Wikipedia.",
  "id" : 226404626398842880,
  "in_reply_to_status_id" : 226368246041952256,
  "created_at" : "2012-07-20 19:54:03 +0000",
  "in_reply_to_screen_name" : "jtcchan",
  "in_reply_to_user_id_str" : "12653762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 27, 40 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226358867649515520",
  "text" : "Very tempted to register a @herpderpedia esque @selloutsparrow and just retweet \"Fuck you sparrow\" tweets all day.",
  "id" : 226358867649515520,
  "created_at" : "2012-07-20 16:52:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stevens",
      "screen_name" : "kevdog",
      "indices" : [ 0, 7 ],
      "id_str" : "10696812",
      "id" : 10696812
    }, {
      "name" : "Throne of .JS ",
      "screen_name" : "ThroneofJS",
      "indices" : [ 8, 19 ],
      "id_str" : "499394799",
      "id" : 499394799
    }, {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 60, 67 ],
      "id_str" : "14381877",
      "id" : 14381877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226354328334630912",
  "geo" : { },
  "id_str" : "226355445835640834",
  "in_reply_to_user_id" : 10696812,
  "text" : "@kevdog @ThroneofJS Agh! Forgot about this. so that's where @gustin is :)",
  "id" : 226355445835640834,
  "in_reply_to_status_id" : 226354328334630912,
  "created_at" : "2012-07-20 16:38:38 +0000",
  "in_reply_to_screen_name" : "kevdog",
  "in_reply_to_user_id_str" : "10696812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 0, 7 ],
      "id_str" : "14381877",
      "id" : 14381877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226353016507363328",
  "geo" : { },
  "id_str" : "226355007417638914",
  "in_reply_to_user_id" : 14381877,
  "text" : "@gustin are you near Toronto\/Buffalo!?",
  "id" : 226355007417638914,
  "in_reply_to_status_id" : 226353016507363328,
  "created_at" : "2012-07-20 16:36:53 +0000",
  "in_reply_to_screen_name" : "gustin",
  "in_reply_to_user_id_str" : "14381877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 3, 10 ],
      "id_str" : "14381877",
      "id" : 14381877
    }, {
      "name" : "SparrowMail",
      "screen_name" : "sparrow",
      "indices" : [ 18, 26 ],
      "id_str" : "163449492",
      "id" : 163449492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/iNrsdj0K",
      "expanded_url" : "https:\/\/twitter.com\/lifehacker\/statuses\/223750237490126849",
      "display_url" : "twitter.com\/lifehacker\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "226354550850850816",
  "text" : "RT @gustin: Lame, @sparrow had a half-off sale last week raking in some extra doe and screwing new customers before they sold-out: https ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SparrowMail",
        "screen_name" : "sparrow",
        "indices" : [ 6, 14 ],
        "id_str" : "163449492",
        "id" : 163449492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 140 ],
        "url" : "https:\/\/t.co\/iNrsdj0K",
        "expanded_url" : "https:\/\/twitter.com\/lifehacker\/statuses\/223750237490126849",
        "display_url" : "twitter.com\/lifehacker\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "226353016507363328",
    "text" : "Lame, @sparrow had a half-off sale last week raking in some extra doe and screwing new customers before they sold-out: https:\/\/t.co\/iNrsdj0K",
    "id" : 226353016507363328,
    "created_at" : "2012-07-20 16:28:59 +0000",
    "user" : {
      "name" : "gustin",
      "screen_name" : "gustin",
      "protected" : false,
      "id_str" : "14381877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2623045577\/dtaqgp4wa2ufajkpdt69_normal.jpeg",
      "id" : 14381877,
      "verified" : false
    }
  },
  "id" : 226354550850850816,
  "created_at" : "2012-07-20 16:35:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodingBuffalos",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/TlVzlxs3",
      "expanded_url" : "http:\/\/www.meetup.com\/Buffalo-Learning-to-Code\/events\/74179692\/",
      "display_url" : "meetup.com\/Buffalo-Learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "226352291886821376",
  "text" : "RT @aquaranto: Just scheduled the week 6 meetup of the #CodingBuffalos! http:\/\/t.co\/TlVzlxs3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CodingBuffalos",
        "indices" : [ 40, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/TlVzlxs3",
        "expanded_url" : "http:\/\/www.meetup.com\/Buffalo-Learning-to-Code\/events\/74179692\/",
        "display_url" : "meetup.com\/Buffalo-Learni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "226351993680171008",
    "text" : "Just scheduled the week 6 meetup of the #CodingBuffalos! http:\/\/t.co\/TlVzlxs3",
    "id" : 226351993680171008,
    "created_at" : "2012-07-20 16:24:55 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 226352291886821376,
  "created_at" : "2012-07-20 16:26:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 3, 13 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "SparrowMail",
      "screen_name" : "sparrow",
      "indices" : [ 19, 27 ],
      "id_str" : "163449492",
      "id" : 163449492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226350797875720192",
  "text" : "RT @stevelosh: RIP @sparrow, stung by dollars.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SparrowMail",
        "screen_name" : "sparrow",
        "indices" : [ 4, 12 ],
        "id_str" : "163449492",
        "id" : 163449492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226350110244737024",
    "text" : "RIP @sparrow, stung by dollars.",
    "id" : 226350110244737024,
    "created_at" : "2012-07-20 16:17:26 +0000",
    "user" : {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "protected" : false,
      "id_str" : "727813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430207936774696960\/iAyNTOdO_normal.jpeg",
      "id" : 727813,
      "verified" : false
    }
  },
  "id" : 226350797875720192,
  "created_at" : "2012-07-20 16:20:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/rOJkFmzK",
      "expanded_url" : "http:\/\/sprw.me\/",
      "display_url" : "sprw.me"
    } ]
  },
  "geo" : { },
  "id_str" : "226349843558322176",
  "text" : "What. The. Fuck!? http:\/\/t.co\/rOJkFmzK Just switched to Sparrow on both phone and desktop, now this? Fuck.",
  "id" : 226349843558322176,
  "created_at" : "2012-07-20 16:16:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunshow & Friends",
      "screen_name" : "gunshowcomic",
      "indices" : [ 0, 13 ],
      "id_str" : "62739421",
      "id" : 62739421
    }, {
      "name" : "Alan Smithee",
      "screen_name" : "barfcaptain",
      "indices" : [ 14, 26 ],
      "id_str" : "1226873053",
      "id" : 1226873053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226167140745637888",
  "geo" : { },
  "id_str" : "226168460454019072",
  "in_reply_to_user_id" : 62739421,
  "text" : "@gunshowcomic @barfcaptain you are the virus, coo coo ca choo",
  "id" : 226168460454019072,
  "in_reply_to_status_id" : 226167140745637888,
  "created_at" : "2012-07-20 04:15:37 +0000",
  "in_reply_to_screen_name" : "gunshowcomic",
  "in_reply_to_user_id_str" : "62739421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/FiTcdDg1",
      "expanded_url" : "http:\/\/instagr.am\/p\/NSaQXNM6rC\/",
      "display_url" : "instagr.am\/p\/NSaQXNM6rC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "226157240833413121",
  "text" : "Someone's on a Keto diet for 30 points! http:\/\/t.co\/FiTcdDg1",
  "id" : 226157240833413121,
  "created_at" : "2012-07-20 03:31:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/xth0T7CJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/NSZulvs6qs\/",
      "display_url" : "instagr.am\/p\/NSZulvs6qs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "226157013858668544",
  "text" : "Agricola, family mode. 36 points to win! http:\/\/t.co\/xth0T7CJ",
  "id" : 226157013858668544,
  "created_at" : "2012-07-20 03:30:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 31 ],
      "url" : "https:\/\/t.co\/zJYuGVJd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=z_SQO3vv3p8",
      "display_url" : "youtube.com\/watch?v=z_SQO3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "226000816811671552",
  "geo" : { },
  "id_str" : "226001269314179073",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage https:\/\/t.co\/zJYuGVJd  ?",
  "id" : 226001269314179073,
  "in_reply_to_status_id" : 226000816811671552,
  "created_at" : "2012-07-19 17:11:16 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 55, 63 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225766715001303040",
  "geo" : { },
  "id_str" : "225805414766374914",
  "in_reply_to_user_id" : 372479872,
  "text" : "@richoffrails yes! If you return, be sure to check out @wnyruby !",
  "id" : 225805414766374914,
  "in_reply_to_status_id" : 225766715001303040,
  "created_at" : "2012-07-19 04:13:00 +0000",
  "in_reply_to_screen_name" : "rbondev",
  "in_reply_to_user_id_str" : "372479872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Anner",
      "screen_name" : "Zachanner",
      "indices" : [ 48, 58 ],
      "id_str" : "155178817",
      "id" : 155178817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/v10ShXdE",
      "expanded_url" : "http:\/\/therealzachanner.com\/post\/27478415830\/announcing-riding-shotgun-riding-shotgun-is-a",
      "display_url" : "therealzachanner.com\/post\/274784158\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225697140867989506",
  "text" : "Lots of awesome Buffalo references and shots in @ZachAnner's Riding Shotgun intro. Good luck dude! http:\/\/t.co\/v10ShXdE",
  "id" : 225697140867989506,
  "created_at" : "2012-07-18 21:02:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/BqWG8YXV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1dCXR06fVwg",
      "display_url" : "youtube.com\/watch?v=1dCXR0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225695825215500290",
  "text" : "Prison Architect, inspired by Dwarf Fortress. http:\/\/t.co\/BqWG8YXV do want!",
  "id" : 225695825215500290,
  "created_at" : "2012-07-18 20:57:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "225622806430363649",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Dragonforce: Through The Fire And Flames \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 225622806430363649,
  "created_at" : "2012-07-18 16:07:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Huard",
      "screen_name" : "elise_huard",
      "indices" : [ 0, 12 ],
      "id_str" : "3629961",
      "id" : 3629961
    }, {
      "name" : "Rebecca Murphey",
      "screen_name" : "rmurphey",
      "indices" : [ 13, 22 ],
      "id_str" : "6490602",
      "id" : 6490602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225507495551053824",
  "geo" : { },
  "id_str" : "225580353019064321",
  "in_reply_to_user_id" : 3629961,
  "text" : "@elise_huard @rmurphey they\u2019re doing java\/.net (or worse) and not giving a crap about anything else",
  "id" : 225580353019064321,
  "in_reply_to_status_id" : 225507495551053824,
  "created_at" : "2012-07-18 13:18:41 +0000",
  "in_reply_to_screen_name" : "elise_huard",
  "in_reply_to_user_id_str" : "3629961",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "indices" : [ 0, 8 ],
      "id_str" : "3382151",
      "id" : 3382151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/FaDat3kI",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v5Lmkm5EF5E",
      "display_url" : "youtube.com\/watch?v=v5Lmkm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "225436861206757376",
  "geo" : { },
  "id_str" : "225440893212172289",
  "in_reply_to_user_id" : 3382151,
  "text" : "@dmosher also, http:\/\/t.co\/FaDat3kI",
  "id" : 225440893212172289,
  "in_reply_to_status_id" : 225436861206757376,
  "created_at" : "2012-07-18 04:04:32 +0000",
  "in_reply_to_screen_name" : "dmosher",
  "in_reply_to_user_id_str" : "3382151",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "indices" : [ 0, 13 ],
      "id_str" : "3479601",
      "id" : 3479601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225344269119000577",
  "geo" : { },
  "id_str" : "225430268415184896",
  "in_reply_to_user_id" : 3479601,
  "text" : "@justingoboom congrats, and welcome!",
  "id" : 225430268415184896,
  "in_reply_to_status_id" : 225344269119000577,
  "created_at" : "2012-07-18 03:22:18 +0000",
  "in_reply_to_screen_name" : "justingoboom",
  "in_reply_to_user_id_str" : "3479601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 0, 11 ],
      "id_str" : "12304192",
      "id" : 12304192
    }, {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 12, 24 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/EYaWwERQ",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "in_reply_to_status_id_str" : "225418607641903104",
  "geo" : { },
  "id_str" : "225425213490348032",
  "in_reply_to_user_id" : 12304192,
  "text" : "@thenickguy @BuffaloEats we keep a nice list at http:\/\/t.co\/EYaWwERQ as well. Need to add some more. (hides retweets and replies)",
  "id" : 225425213490348032,
  "in_reply_to_status_id" : 225418607641903104,
  "created_at" : "2012-07-18 03:02:13 +0000",
  "in_reply_to_screen_name" : "thenickguy",
  "in_reply_to_user_id_str" : "12304192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225370415877472256",
  "geo" : { },
  "id_str" : "225416197586436096",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson you should frame these.",
  "id" : 225416197586436096,
  "in_reply_to_status_id" : 225370415877472256,
  "created_at" : "2012-07-18 02:26:24 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225416036462247938",
  "text" : "Played a DBZ game with bro-in-law. Loading screen had a few Dragon Balls bouncing around, he thought they were marbles. Kids these days.",
  "id" : 225416036462247938,
  "created_at" : "2012-07-18 02:25:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225393153040064513",
  "geo" : { },
  "id_str" : "225399252237549568",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl creating a tile based RPG?",
  "id" : 225399252237549568,
  "in_reply_to_status_id" : 225393153040064513,
  "created_at" : "2012-07-18 01:19:04 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225397063456800768",
  "geo" : { },
  "id_str" : "225397435021795330",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam haha, couldn\u2019t think of a wittier name. Finally found a good and redundant setup with a harness for him.",
  "id" : 225397435021795330,
  "in_reply_to_status_id" : 225397063456800768,
  "created_at" : "2012-07-18 01:11:50 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/gmTjvUZK",
      "expanded_url" : "http:\/\/instagr.am\/p\/NNAWHZM6hU\/",
      "display_url" : "instagr.am\/p\/NNAWHZM6hU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "225396744765190144",
  "text" : "Most Excellent and Glorious Husky Bike Harness Setup Post 3+ Mile Bike Ride Photo! http:\/\/t.co\/gmTjvUZK",
  "id" : 225396744765190144,
  "created_at" : "2012-07-18 01:09:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/ERBemtkH",
      "expanded_url" : "http:\/\/instagr.am\/p\/NNAF8oM6hL\/",
      "display_url" : "instagr.am\/p\/NNAF8oM6hL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "225395993825390592",
  "text" : "Awesome homemade Cobb salad is going to be awesome! http:\/\/t.co\/ERBemtkH",
  "id" : 225395993825390592,
  "created_at" : "2012-07-18 01:06:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225358117792268290",
  "text" : "RT @bquarant: Whoever designed the keyboard had things figured out. ! comes first, followed later by $",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225357793958445057",
    "text" : "Whoever designed the keyboard had things figured out. ! comes first, followed later by $",
    "id" : 225357793958445057,
    "created_at" : "2012-07-17 22:34:19 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 225358117792268290,
  "created_at" : "2012-07-17 22:35:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225331163059855360",
  "geo" : { },
  "id_str" : "225331498407034881",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs there's definitely not enough focus on data\/ink ratio online.",
  "id" : 225331498407034881,
  "in_reply_to_status_id" : 225331163059855360,
  "created_at" : "2012-07-17 20:49:50 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 43, 52 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/8nQsz1RP",
      "expanded_url" : "http:\/\/beedogs.com\/",
      "display_url" : "beedogs.com"
    } ]
  },
  "geo" : { },
  "id_str" : "225303844060532736",
  "text" : "So, this exists: http:\/\/t.co\/8nQsz1RP (via @shildner)",
  "id" : 225303844060532736,
  "created_at" : "2012-07-17 18:59:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225289840214806528",
  "geo" : { },
  "id_str" : "225290531389980673",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm OFF DA RAILZ",
  "id" : 225290531389980673,
  "in_reply_to_status_id" : 225289840214806528,
  "created_at" : "2012-07-17 18:07:03 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225282442351755265",
  "geo" : { },
  "id_str" : "225282943927582721",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx yeah, definitely works. takes a while to load via DOSBox. need a mouse too, trackpad sucks.",
  "id" : 225282943927582721,
  "in_reply_to_status_id" : 225282442351755265,
  "created_at" : "2012-07-17 17:36:54 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/dGBfXv95",
      "expanded_url" : "http:\/\/www.classicdosgames.com\/online\/dforces1.html",
      "display_url" : "classicdosgames.com\/online\/dforces\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225280965113675777",
  "text" : "Dark Forces. Remember this one? http:\/\/t.co\/dGBfXv95",
  "id" : 225280965113675777,
  "created_at" : "2012-07-17 17:29:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225270084560625665",
  "geo" : { },
  "id_str" : "225274499183026176",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt how about vending machines in the cafeteria?",
  "id" : 225274499183026176,
  "in_reply_to_status_id" : 225270084560625665,
  "created_at" : "2012-07-17 17:03:20 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225268931521298432",
  "geo" : { },
  "id_str" : "225271252867235840",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety Hell yes! We have winter here though, remember?",
  "id" : 225271252867235840,
  "in_reply_to_status_id" : 225268931521298432,
  "created_at" : "2012-07-17 16:50:26 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R&R BBQ",
      "screen_name" : "RnRBBQTruck",
      "indices" : [ 32, 44 ],
      "id_str" : "214261325",
      "id" : 214261325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/YufeM7TD",
      "expanded_url" : "http:\/\/instagr.am\/p\/NMF64IM6ha\/",
      "display_url" : "instagr.am\/p\/NMF64IM6ha\/"
    } ]
  },
  "geo" : { },
  "id_str" : "225268175216967680",
  "text" : "It's a food truck kind of week! @RNRBBQTruck time! http:\/\/t.co\/YufeM7TD",
  "id" : 225268175216967680,
  "created_at" : "2012-07-17 16:38:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 70, 78 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "MaTIAS eL HuMiLDE;)",
      "screen_name" : "rubycentral",
      "indices" : [ 81, 93 ],
      "id_str" : "256225697",
      "id" : 256225697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/8gR4QqN0",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/131647\/history",
      "display_url" : "uptime.rubygems.org\/131647\/history"
    } ]
  },
  "geo" : { },
  "id_str" : "225256118375550976",
  "text" : "Wow, http:\/\/t.co\/bdjsRgTW has had awesome uptime stats. Big thanks to @evanphx \/ @rubycentral for helping out here! http:\/\/t.co\/8gR4QqN0",
  "id" : 225256118375550976,
  "created_at" : "2012-07-17 15:50:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney a. crispell",
      "screen_name" : "whitneyarlene",
      "indices" : [ 124, 138 ],
      "id_str" : "213939016",
      "id" : 213939016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/bOYBPcOc",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/thetwo-way\/2012\/07\/17\/156903711\/boy-scouts-reaffirm-ban-on-open-gays-calls-it-absolutely-the-best-policy",
      "display_url" : "npr.org\/blogs\/thetwo-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225249225896755200",
  "text" : "Disgusted by this news, as usual. A little glitter on your pine car derby cars won't hurt anyone. http:\/\/t.co\/bOYBPcOc (via @whitneyarlene)",
  "id" : 225249225896755200,
  "created_at" : "2012-07-17 15:22:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/VJxLOMbV",
      "expanded_url" : "http:\/\/37signals.com\/git",
      "display_url" : "37signals.com\/git"
    } ]
  },
  "in_reply_to_status_id_str" : "225242186395037697",
  "geo" : { },
  "id_str" : "225242339520692224",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 maybe we need to move to http:\/\/t.co\/VJxLOMbV",
  "id" : 225242339520692224,
  "in_reply_to_status_id" : 225242186395037697,
  "created_at" : "2012-07-17 14:55:33 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 13, 27 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "225242233820037121",
  "text" : "DJing in the @CoworkBuffalo room. Come hang out! \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 225242233820037121,
  "created_at" : "2012-07-17 14:55:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225241633594146816",
  "text" : "Some companies argue about what exact hex color of blue to use. Some companies add more buttons, padding, and set the background to white.",
  "id" : 225241633594146816,
  "created_at" : "2012-07-17 14:52:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 59, 71 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/djxNQboO",
      "expanded_url" : "http:\/\/cdn.arstechnica.net\/\/wp-content\/uploads\/2012\/07\/install-office-15-1-e1342147462855-640x364.png",
      "display_url" : "cdn.arstechnica.net\/\/wp-content\/up\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225241263681703936",
  "text" : "I'd like my Office to look None. http:\/\/t.co\/djxNQboO (via @sstephenson)",
  "id" : 225241263681703936,
  "created_at" : "2012-07-17 14:51:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/HfjnNnpQ",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3207-the-office-2013-ui-as-captured-by-peter",
      "display_url" : "37signals.com\/svn\/posts\/3207\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225240466222878720",
  "text" : "How can anyone at Microsoft be proud of this? How are they this blind? http:\/\/t.co\/HfjnNnpQ",
  "id" : 225240466222878720,
  "created_at" : "2012-07-17 14:48:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Cruz",
      "screen_name" : "mraaroncruz",
      "indices" : [ 0, 12 ],
      "id_str" : "66482772",
      "id" : 66482772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225238764652466176",
  "geo" : { },
  "id_str" : "225239824024600576",
  "in_reply_to_user_id" : 66482772,
  "text" : "@mraaroncruz Yep, you'll have to. :[ Not sure how we can improve this, but it needs help.",
  "id" : 225239824024600576,
  "in_reply_to_status_id" : 225238764652466176,
  "created_at" : "2012-07-17 14:45:33 +0000",
  "in_reply_to_screen_name" : "mraaroncruz",
  "in_reply_to_user_id_str" : "66482772",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225237973061484545",
  "geo" : { },
  "id_str" : "225239547963908096",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn MISS AMERICA?",
  "id" : 225239547963908096,
  "in_reply_to_status_id" : 225237973061484545,
  "created_at" : "2012-07-17 14:44:27 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Cruz",
      "screen_name" : "mraaroncruz",
      "indices" : [ 0, 12 ],
      "id_str" : "66482772",
      "id" : 66482772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/JCkCrfmZ",
      "expanded_url" : "http:\/\/github.com\/rubygems\/rubygems-mirror",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "225237791179673600",
  "geo" : { },
  "id_str" : "225238130184306688",
  "in_reply_to_user_id" : 66482772,
  "text" : "@mraaroncruz There's no rsync, but you can use http:\/\/t.co\/JCkCrfmZ",
  "id" : 225238130184306688,
  "in_reply_to_status_id" : 225237791179673600,
  "created_at" : "2012-07-17 14:38:49 +0000",
  "in_reply_to_screen_name" : "mraaroncruz",
  "in_reply_to_user_id_str" : "66482772",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/ddDG9UVL",
      "expanded_url" : "http:\/\/boxcar2d.com\/",
      "display_url" : "boxcar2d.com"
    } ]
  },
  "in_reply_to_status_id_str" : "225048762895183873",
  "geo" : { },
  "id_str" : "225051002213117952",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson wow, spooky as hell. not as funny as http:\/\/t.co\/ddDG9UVL",
  "id" : 225051002213117952,
  "in_reply_to_status_id" : 225048762895183873,
  "created_at" : "2012-07-17 02:15:14 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/wryYWMZs",
      "expanded_url" : "http:\/\/lists.w3.org\/Archives\/Public\/ietf-http-wg\/2012JulSep\/0172.html",
      "display_url" : "lists.w3.org\/Archives\/Publi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225050670875688960",
  "text" : "Varnish author lays the fucking smackdown on the W3C. http:\/\/t.co\/wryYWMZs",
  "id" : 225050670875688960,
  "created_at" : "2012-07-17 02:13:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225020807406039041",
  "geo" : { },
  "id_str" : "225020991913463810",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle try this: start a new gemset\/env and try to get your app working. write down every command and toss that into script\/setup.",
  "id" : 225020991913463810,
  "in_reply_to_status_id" : 225020807406039041,
  "created_at" : "2012-07-17 00:15:59 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225019892661878784",
  "geo" : { },
  "id_str" : "225020682424168451",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle what I posted in the slides is really it. just a bunch of those strung together.",
  "id" : 225020682424168451,
  "in_reply_to_status_id" : 225019892661878784,
  "created_at" : "2012-07-17 00:14:46 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Garcia",
      "screen_name" : "geekgirlweb",
      "indices" : [ 0, 12 ],
      "id_str" : "99571194",
      "id" : 99571194
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225010641788874752",
  "geo" : { },
  "id_str" : "225011050486046720",
  "in_reply_to_user_id" : 99571194,
  "text" : "@geekgirlweb @aquaranto much thanks!",
  "id" : 225011050486046720,
  "in_reply_to_status_id" : 225010641788874752,
  "created_at" : "2012-07-16 23:36:29 +0000",
  "in_reply_to_screen_name" : "geekgirlweb",
  "in_reply_to_user_id_str" : "99571194",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Garcia",
      "screen_name" : "geekgirlweb",
      "indices" : [ 0, 12 ],
      "id_str" : "99571194",
      "id" : 99571194
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 18, 28 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225006748711395330",
  "geo" : { },
  "id_str" : "225007532945584128",
  "in_reply_to_user_id" : 99571194,
  "text" : "@geekgirlweb hey! @aquaranto knows someone who wants to go. can you email amanda@quaran.to ?",
  "id" : 225007532945584128,
  "in_reply_to_status_id" : 225006748711395330,
  "created_at" : "2012-07-16 23:22:30 +0000",
  "in_reply_to_screen_name" : "geekgirlweb",
  "in_reply_to_user_id_str" : "99571194",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 61, 71 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 76, 89 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224994915657060353",
  "text" : "\"Don't just google Shoes. It does not bring you to Shoes.\" - @aquaranto \/cc @steveklabnik",
  "id" : 224994915657060353,
  "created_at" : "2012-07-16 22:32:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 35, 49 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224970419709550592",
  "geo" : { },
  "id_str" : "224971374685462528",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant FUCK yes, one block from @coworkbuffalo !",
  "id" : 224971374685462528,
  "in_reply_to_status_id" : 224970419709550592,
  "created_at" : "2012-07-16 20:58:50 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/FpSZfxQ2",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/07\/dino-bbq-picks-franklin-street-location.html",
      "display_url" : "buffalorising.com\/2012\/07\/dino-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224971216530841601",
  "text" : "RT @BuffaloRising: Yep, it's official. Dinosaur BBQ will be opening in downtown Buffalo at 301 Franklin: http:\/\/t.co\/FpSZfxQ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/FpSZfxQ2",
        "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/07\/dino-bbq-picks-franklin-street-location.html",
        "display_url" : "buffalorising.com\/2012\/07\/dino-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224971026600173568",
    "text" : "Yep, it's official. Dinosaur BBQ will be opening in downtown Buffalo at 301 Franklin: http:\/\/t.co\/FpSZfxQ2",
    "id" : 224971026600173568,
    "created_at" : "2012-07-16 20:57:27 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 224971216530841601,
  "created_at" : "2012-07-16 20:58:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Hartman",
      "screen_name" : "devth",
      "indices" : [ 0, 6 ],
      "id_str" : "14084548",
      "id" : 14084548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224965010374393856",
  "geo" : { },
  "id_str" : "224965441888587776",
  "in_reply_to_user_id" : 14084548,
  "text" : "@devth doubtful, we dont keep track of these currently. why do you need it?",
  "id" : 224965441888587776,
  "in_reply_to_status_id" : 224965010374393856,
  "created_at" : "2012-07-16 20:35:15 +0000",
  "in_reply_to_screen_name" : "devth",
  "in_reply_to_user_id_str" : "14084548",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224963080789032960",
  "geo" : { },
  "id_str" : "224965322573221888",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright thanks dude!",
  "id" : 224965322573221888,
  "in_reply_to_status_id" : 224963080789032960,
  "created_at" : "2012-07-16 20:34:47 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 3, 11 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 49, 55 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/o5Vk0LTG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=oXTzFCXE66M&feature=player_embedded&utm_source=buffer&buffer_share=9e4e4",
      "display_url" : "youtube.com\/watch?v=oXTzFC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224965305196220417",
  "text" : "RT @jwright: This presentation at RailsConf from @qrush is full of great gems. Literally.\n\nhttp:\/\/t.co\/o5Vk0LTG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 36, 42 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/o5Vk0LTG",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=oXTzFCXE66M&feature=player_embedded&utm_source=buffer&buffer_share=9e4e4",
        "display_url" : "youtube.com\/watch?v=oXTzFC\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224963080789032960",
    "text" : "This presentation at RailsConf from @qrush is full of great gems. Literally.\n\nhttp:\/\/t.co\/o5Vk0LTG",
    "id" : 224963080789032960,
    "created_at" : "2012-07-16 20:25:52 +0000",
    "user" : {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "protected" : false,
      "id_str" : "77673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530926764155879424\/jWjU45VR_normal.jpeg",
      "id" : 77673,
      "verified" : false
    }
  },
  "id" : 224965305196220417,
  "created_at" : "2012-07-16 20:34:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 0, 9 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224935083772084224",
  "geo" : { },
  "id_str" : "224935178789863425",
  "in_reply_to_user_id" : 15494948,
  "text" : "@coderjoe forgot headphones today :(",
  "id" : 224935178789863425,
  "in_reply_to_status_id" : 224935083772084224,
  "created_at" : "2012-07-16 18:35:00 +0000",
  "in_reply_to_screen_name" : "coderjoe",
  "in_reply_to_user_id_str" : "15494948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224899191682510851",
  "geo" : { },
  "id_str" : "224899481030758401",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen thanks!!",
  "id" : 224899481030758401,
  "in_reply_to_status_id" : 224899191682510851,
  "created_at" : "2012-07-16 16:13:09 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224215450521841664",
  "geo" : { },
  "id_str" : "224893078614441984",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y finally looked this up. it rescues ActionView::MissingTemplate and redirects back (instead of an error page)",
  "id" : 224893078614441984,
  "in_reply_to_status_id" : 224215450521841664,
  "created_at" : "2012-07-16 15:47:42 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/sbqoLW7E",
      "expanded_url" : "http:\/\/ijailbreakcydia.com\/now-you-can-access-tweetbots-super-secret-setting-on-iphone",
      "display_url" : "ijailbreakcydia.com\/now-you-can-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224891708888977409",
  "text" : "TweetBot has super secret settings!!!? http:\/\/t.co\/sbqoLW7E",
  "id" : 224891708888977409,
  "created_at" : "2012-07-16 15:42:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224880722714951681",
  "geo" : { },
  "id_str" : "224887720911192064",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital Thanks!!",
  "id" : 224887720911192064,
  "in_reply_to_status_id" : 224880722714951681,
  "created_at" : "2012-07-16 15:26:25 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hunty",
      "screen_name" : "HunterBridges",
      "indices" : [ 0, 14 ],
      "id_str" : "142796579",
      "id" : 142796579
    }, {
      "name" : "Jeff Rafter",
      "screen_name" : "jeffrafter",
      "indices" : [ 15, 26 ],
      "id_str" : "4176991",
      "id" : 4176991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224594448196182016",
  "geo" : { },
  "id_str" : "224887644407087106",
  "in_reply_to_user_id" : 142796579,
  "text" : "@HunterBridges @jeffrafter honestly, I don't think most people understand what retina is, and they don't care.",
  "id" : 224887644407087106,
  "in_reply_to_status_id" : 224594448196182016,
  "created_at" : "2012-07-16 15:26:07 +0000",
  "in_reply_to_screen_name" : "HunterBridges",
  "in_reply_to_user_id_str" : "142796579",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 3, 11 ],
      "id_str" : "632391390",
      "id" : 632391390
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 45, 55 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 59, 67 ],
      "id_str" : "632391390",
      "id" : 632391390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/ZDg6GinY",
      "expanded_url" : "http:\/\/www.prweb.com\/releases\/2012\/7\/prweb9700048.htm",
      "display_url" : "prweb.com\/releases\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224878610367004673",
  "text" : "RT @Z80Labs: We'd like to officially welcome @magnachef to @Z80labs, as our Chief Principal Innovationist! http:\/\/t.co\/ZDg6GinY #Buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Magnuszewski",
        "screen_name" : "magnachef",
        "indices" : [ 32, 42 ],
        "id_str" : "23703410",
        "id" : 23703410
      }, {
        "name" : "Z80 Labs",
        "screen_name" : "Z80Labs",
        "indices" : [ 46, 54 ],
        "id_str" : "632391390",
        "id" : 632391390
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/ZDg6GinY",
        "expanded_url" : "http:\/\/www.prweb.com\/releases\/2012\/7\/prweb9700048.htm",
        "display_url" : "prweb.com\/releases\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224874092023648256",
    "text" : "We'd like to officially welcome @magnachef to @Z80labs, as our Chief Principal Innovationist! http:\/\/t.co\/ZDg6GinY #Buffalo",
    "id" : 224874092023648256,
    "created_at" : "2012-07-16 14:32:16 +0000",
    "user" : {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "protected" : false,
      "id_str" : "632391390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2392404739\/mq56yhjfsi7ht1pfwckx_normal.png",
      "id" : 632391390,
      "verified" : false
    }
  },
  "id" : 224878610367004673,
  "created_at" : "2012-07-16 14:50:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 0, 8 ],
      "id_str" : "9664212",
      "id" : 9664212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224877056251543553",
  "geo" : { },
  "id_str" : "224877288121049088",
  "in_reply_to_user_id" : 9664212,
  "text" : "@joealba haha yes!",
  "id" : 224877288121049088,
  "in_reply_to_status_id" : 224877056251543553,
  "created_at" : "2012-07-16 14:44:58 +0000",
  "in_reply_to_screen_name" : "joealba",
  "in_reply_to_user_id_str" : "9664212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224874854359371779",
  "geo" : { },
  "id_str" : "224875701520711680",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff Keynote &gt; Export As HTML",
  "id" : 224875701520711680,
  "in_reply_to_status_id" : 224874854359371779,
  "created_at" : "2012-07-16 14:38:39 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224874115662749696",
  "text" : "Finally, my own hater! \"I can\u2019t recall ever witnessing someone so unsure of himself speaking in my life.\" HATE HATE HATE HATE",
  "id" : 224874115662749696,
  "created_at" : "2012-07-16 14:32:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Wright",
      "screen_name" : "larrywright",
      "indices" : [ 3, 15 ],
      "id_str" : "10286",
      "id" : 10286
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 84, 90 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Es18iZ0f",
      "expanded_url" : "http:\/\/bit.ly\/MqzD2w",
      "display_url" : "bit.ly\/MqzD2w"
    } ]
  },
  "geo" : { },
  "id_str" : "224865798727008256",
  "text" : "RT @larrywright: Rails devs: there's a lot of awesome stuff in this presentation by @qrush: Code spelunking in the All New Basecamp: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 67, 73 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/Es18iZ0f",
        "expanded_url" : "http:\/\/bit.ly\/MqzD2w",
        "display_url" : "bit.ly\/MqzD2w"
      } ]
    },
    "geo" : { },
    "id_str" : "224852205449134080",
    "text" : "Rails devs: there's a lot of awesome stuff in this presentation by @qrush: Code spelunking in the All New Basecamp: http:\/\/t.co\/Es18iZ0f",
    "id" : 224852205449134080,
    "created_at" : "2012-07-16 13:05:17 +0000",
    "user" : {
      "name" : "Larry Wright",
      "screen_name" : "larrywright",
      "protected" : false,
      "id_str" : "10286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417465160299581440\/9Kv-Wcb9_normal.jpeg",
      "id" : 10286,
      "verified" : false
    }
  },
  "id" : 224865798727008256,
  "created_at" : "2012-07-16 13:59:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Avery",
      "screen_name" : "averyj",
      "indices" : [ 0, 7 ],
      "id_str" : "6967822",
      "id" : 6967822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224716180731076610",
  "geo" : { },
  "id_str" : "224716770534113280",
  "in_reply_to_user_id" : 6967822,
  "text" : "@averyj please tell me this is a fact",
  "id" : 224716770534113280,
  "in_reply_to_status_id" : 224716180731076610,
  "created_at" : "2012-07-16 04:07:07 +0000",
  "in_reply_to_screen_name" : "averyj",
  "in_reply_to_user_id_str" : "6967822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224708175805419520",
  "text" : "Tweet not about new TV show on a Sunday night.",
  "id" : 224708175805419520,
  "created_at" : "2012-07-16 03:32:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/sCUFtSLx",
      "expanded_url" : "http:\/\/www.meetup.com\/Buffalo-Learning-to-Code\/",
      "display_url" : "meetup.com\/Buffalo-Learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224704236032770048",
  "text" : "RT @coworkbuffalo: Buffalo Learning to Code is tomorrow night in your friendly neighborhood coworking space at 6:30!  http:\/\/t.co\/sCUFtSLx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/sCUFtSLx",
        "expanded_url" : "http:\/\/www.meetup.com\/Buffalo-Learning-to-Code\/",
        "display_url" : "meetup.com\/Buffalo-Learni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224704185013256192",
    "text" : "Buffalo Learning to Code is tomorrow night in your friendly neighborhood coworking space at 6:30!  http:\/\/t.co\/sCUFtSLx",
    "id" : 224704185013256192,
    "created_at" : "2012-07-16 03:17:07 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 224704236032770048,
  "created_at" : "2012-07-16 03:17:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Dorrans",
      "screen_name" : "blowdart",
      "indices" : [ 0, 9 ],
      "id_str" : "1847381",
      "id" : 1847381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224702886876151811",
  "geo" : { },
  "id_str" : "224703617905590272",
  "in_reply_to_user_id" : 1847381,
  "text" : "@blowdart 3.14:1",
  "id" : 224703617905590272,
  "in_reply_to_status_id" : 224702886876151811,
  "created_at" : "2012-07-16 03:14:51 +0000",
  "in_reply_to_screen_name" : "blowdart",
  "in_reply_to_user_id_str" : "1847381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224701197888651264",
  "geo" : { },
  "id_str" : "224703583797526528",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr bring a Baggie to coworking next time",
  "id" : 224703583797526528,
  "in_reply_to_status_id" : 224701197888651264,
  "created_at" : "2012-07-16 03:14:43 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224703234529435648",
  "text" : "First dog kong peanut butter experiment: success! Hopefully will be cheaper\/faster than a big jar. Need a name still. Stuff.new ?",
  "id" : 224703234529435648,
  "created_at" : "2012-07-16 03:13:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224702031938600960",
  "geo" : { },
  "id_str" : "224702919973421056",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt go apple pie.",
  "id" : 224702919973421056,
  "in_reply_to_status_id" : 224702031938600960,
  "created_at" : "2012-07-16 03:12:05 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224702801916334080",
  "text" : "First experiment making dog peanut butter: complete! Not as creamy as I wanted. Hoping this is more cost effective than 2 64 oz jars either.",
  "id" : 224702801916334080,
  "created_at" : "2012-07-16 03:11:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/jNRESEJM",
      "expanded_url" : "http:\/\/instagr.am\/p\/NIEAbbs6r3\/",
      "display_url" : "instagr.am\/p\/NIEAbbs6r3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "224701212606480385",
  "text" : "One pound of product! Peanut butter and carrots ready to squeeze for instant Kongin' http:\/\/t.co\/jNRESEJM",
  "id" : 224701212606480385,
  "created_at" : "2012-07-16 03:05:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/4p5sPEvq",
      "expanded_url" : "http:\/\/instagr.am\/p\/NIDkULs6rh\/",
      "display_url" : "instagr.am\/p\/NIDkULs6rh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "224699975072878593",
  "text" : "Homemade Kong treat time. Need a snappy name for this concoction. http:\/\/t.co\/4p5sPEvq",
  "id" : 224699975072878593,
  "created_at" : "2012-07-16 03:00:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224687753856679936",
  "geo" : { },
  "id_str" : "224688639316201472",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy why isn't there a map easily findable on this page!?",
  "id" : 224688639316201472,
  "in_reply_to_status_id" : 224687753856679936,
  "created_at" : "2012-07-16 02:15:20 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Anderson",
      "screen_name" : "sudomv",
      "indices" : [ 0, 7 ],
      "id_str" : "1911924188",
      "id" : 1911924188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224688204182323201",
  "geo" : { },
  "id_str" : "224688333706633216",
  "in_reply_to_user_id" : 88489441,
  "text" : "@sudomv Never. Leave it behind and stop wasting time on it.",
  "id" : 224688333706633216,
  "in_reply_to_status_id" : 224688204182323201,
  "created_at" : "2012-07-16 02:14:07 +0000",
  "in_reply_to_screen_name" : "AdamBFerg",
  "in_reply_to_user_id_str" : "88489441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Avery",
      "screen_name" : "averyj",
      "indices" : [ 0, 7 ],
      "id_str" : "6967822",
      "id" : 6967822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 88 ],
      "url" : "https:\/\/t.co\/3NXglqjP",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/statuses\/32557403161497600",
      "display_url" : "twitter.com\/qrush\/statuses\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "224686379563614209",
  "geo" : { },
  "id_str" : "224686646405246976",
  "in_reply_to_user_id" : 6967822,
  "text" : "@averyj it's been fucking terrible like that for MUCH MUCH longer. https:\/\/t.co\/3NXglqjP",
  "id" : 224686646405246976,
  "in_reply_to_status_id" : 224686379563614209,
  "created_at" : "2012-07-16 02:07:25 +0000",
  "in_reply_to_screen_name" : "averyj",
  "in_reply_to_user_id_str" : "6967822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/URrey1Sd",
      "expanded_url" : "http:\/\/pastebin.com\/q0hTkwFh",
      "display_url" : "pastebin.com\/q0hTkwFh"
    } ]
  },
  "geo" : { },
  "id_str" : "224686463898501120",
  "text" : "Such an inspiring testimony, especially that he's my age as well. http:\/\/t.co\/URrey1Sd",
  "id" : 224686463898501120,
  "created_at" : "2012-07-16 02:06:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/nOOENSlY",
      "expanded_url" : "http:\/\/0xfe.blogspot.com\/2006\/03\/using-spotlight-from-os-x-commandline.html",
      "display_url" : "0xfe.blogspot.com\/2006\/03\/using-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224681408554205187",
  "text" : "Access Spotflight via the command line...wow. http:\/\/t.co\/nOOENSlY",
  "id" : 224681408554205187,
  "created_at" : "2012-07-16 01:46:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Smithee",
      "screen_name" : "barfcaptain",
      "indices" : [ 0, 12 ],
      "id_str" : "1226873053",
      "id" : 1226873053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224519847160184832",
  "geo" : { },
  "id_str" : "224520720225550337",
  "in_reply_to_user_id" : 16522244,
  "text" : "@barfcaptain The Angry Pisses",
  "id" : 224520720225550337,
  "in_reply_to_status_id" : 224519847160184832,
  "created_at" : "2012-07-15 15:08:05 +0000",
  "in_reply_to_screen_name" : "kcgreenn",
  "in_reply_to_user_id_str" : "16522244",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Smithee",
      "screen_name" : "barfcaptain",
      "indices" : [ 0, 12 ],
      "id_str" : "1226873053",
      "id" : 1226873053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224519847160184832",
  "geo" : { },
  "id_str" : "224520592920031233",
  "in_reply_to_user_id" : 16522244,
  "text" : "@barfcaptain Piss\u2019s Modern Life",
  "id" : 224520592920031233,
  "in_reply_to_status_id" : 224519847160184832,
  "created_at" : "2012-07-15 15:07:35 +0000",
  "in_reply_to_screen_name" : "kcgreenn",
  "in_reply_to_user_id_str" : "16522244",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/65uzsA9Q",
      "expanded_url" : "http:\/\/instagr.am\/p\/NFPbrhs6k_\/",
      "display_url" : "instagr.am\/p\/NFPbrhs6k_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "224303966077456385",
  "text" : "Geddy snuggled down after we picked him up from Camp Bow Wow. http:\/\/t.co\/65uzsA9Q",
  "id" : 224303966077456385,
  "created_at" : "2012-07-15 00:46:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 3, 16 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/TEy57D1t",
      "expanded_url" : "http:\/\/www.python.org\/",
      "display_url" : "python.org"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/fwcylb2B",
      "expanded_url" : "http:\/\/www.ruby-lang.org",
      "display_url" : "ruby-lang.org"
    } ]
  },
  "geo" : { },
  "id_str" : "224303130702131201",
  "text" : "RT @codinghorror: Filing a bug on PHP The Right Way because it fails to redirect to http:\/\/t.co\/TEy57D1t or http:\/\/t.co\/fwcylb2B as expe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/TEy57D1t",
        "expanded_url" : "http:\/\/www.python.org\/",
        "display_url" : "python.org"
      }, {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/fwcylb2B",
        "expanded_url" : "http:\/\/www.ruby-lang.org",
        "display_url" : "ruby-lang.org"
      } ]
    },
    "geo" : { },
    "id_str" : "224243133578346496",
    "text" : "Filing a bug on PHP The Right Way because it fails to redirect to http:\/\/t.co\/TEy57D1t or http:\/\/t.co\/fwcylb2B as expected.",
    "id" : 224243133578346496,
    "created_at" : "2012-07-14 20:45:03 +0000",
    "user" : {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "protected" : false,
      "id_str" : "5637652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2052442590\/coding-horror-official-logo-medium_normal.png",
      "id" : 5637652,
      "verified" : true
    }
  },
  "id" : 224303130702131201,
  "created_at" : "2012-07-15 00:43:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224301993135575040",
  "geo" : { },
  "id_str" : "224303052386086913",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt does that work?! The grease was making it worse.",
  "id" : 224303052386086913,
  "in_reply_to_status_id" : 224301993135575040,
  "created_at" : "2012-07-15 00:43:09 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224298229230075904",
  "text" : "And today, Nick learns that grilling chicken on an extremely hot grill turns it into very, very blackened chicken.",
  "id" : 224298229230075904,
  "created_at" : "2012-07-15 00:23:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223991649360031744",
  "geo" : { },
  "id_str" : "223992497678979072",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel You kick the parking booth! You hear a thunderous roar as the parking gate slams your car! Your insurance rate dies\u2026",
  "id" : 223992497678979072,
  "in_reply_to_status_id" : 223991649360031744,
  "created_at" : "2012-07-14 04:09:07 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223990729507209217",
  "geo" : { },
  "id_str" : "223990996936036352",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel did you ascend ?!",
  "id" : 223990996936036352,
  "in_reply_to_status_id" : 223990729507209217,
  "created_at" : "2012-07-14 04:03:09 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223972085800771586",
  "geo" : { },
  "id_str" : "223981649531117570",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 you must\u2026go deeper!",
  "id" : 223981649531117570,
  "in_reply_to_status_id" : 223972085800771586,
  "created_at" : "2012-07-14 03:26:01 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will",
      "screen_name" : "im_a_muppet",
      "indices" : [ 0, 12 ],
      "id_str" : "14982980",
      "id" : 14982980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223854533544132608",
  "geo" : { },
  "id_str" : "223980742261227521",
  "in_reply_to_user_id" : 14982980,
  "text" : "@im_a_muppet thanks dude! Really appreciate it.",
  "id" : 223980742261227521,
  "in_reply_to_status_id" : 223854533544132608,
  "created_at" : "2012-07-14 03:22:24 +0000",
  "in_reply_to_screen_name" : "im_a_muppet",
  "in_reply_to_user_id_str" : "14982980",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223927867405377537",
  "geo" : { },
  "id_str" : "223980483334250496",
  "in_reply_to_user_id" : 156708162,
  "text" : "@seandevineinc I was pretty skeptical of them, but they rock for clarity, quick sharing, and organization without hiding",
  "id" : 223980483334250496,
  "in_reply_to_status_id" : 223927867405377537,
  "created_at" : "2012-07-14 03:21:23 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Starkman",
      "screen_name" : "MarkStarkman",
      "indices" : [ 0, 13 ],
      "id_str" : "139263008",
      "id" : 139263008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223956618579152896",
  "geo" : { },
  "id_str" : "223980176692875265",
  "in_reply_to_user_id" : 139263008,
  "text" : "@MarkStarkman thanks!",
  "id" : 223980176692875265,
  "in_reply_to_status_id" : 223956618579152896,
  "created_at" : "2012-07-14 03:20:10 +0000",
  "in_reply_to_screen_name" : "MarkStarkman",
  "in_reply_to_user_id_str" : "139263008",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rolling Joe Cafe",
      "screen_name" : "RollingJoeCafe",
      "indices" : [ 14, 29 ],
      "id_str" : "308682529",
      "id" : 308682529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/EYaWwERQ",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "geo" : { },
  "id_str" : "223952698578448386",
  "text" : "Finally found @RollingJoeCafe, and it is great! Updating http:\/\/t.co\/EYaWwERQ posthaste.",
  "id" : 223952698578448386,
  "created_at" : "2012-07-14 01:30:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/FwkP4lwq",
      "expanded_url" : "http:\/\/4sq.com\/P5dxS0",
      "display_url" : "4sq.com\/P5dxS0"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9317697174, -78.8719654083 ]
  },
  "id_str" : "223902372768911360",
  "text" : "Pumped! Haven't been to Shakespeare in the Park in Buffalo in a long time. (@ Shakespeare in Delaware Park) [pic]: http:\/\/t.co\/FwkP4lwq",
  "id" : 223902372768911360,
  "created_at" : "2012-07-13 22:11:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223894294547808256",
  "geo" : { },
  "id_str" : "223896901135769600",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon you cannot overwrite versions, that goes for any gem.",
  "id" : 223896901135769600,
  "in_reply_to_status_id" : 223894294547808256,
  "created_at" : "2012-07-13 21:49:15 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223883475772653568",
  "geo" : { },
  "id_str" : "223893549840736257",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon if the owner consents, they can just gem owner you in.",
  "id" : 223893549840736257,
  "in_reply_to_status_id" : 223883475772653568,
  "created_at" : "2012-07-13 21:35:56 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223882656922865664",
  "text" : "Always love source diving to find a tiny, small class that does one thing well.",
  "id" : 223882656922865664,
  "created_at" : "2012-07-13 20:52:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Mutwin Kraus",
      "screen_name" : "mutle",
      "indices" : [ 8, 14 ],
      "id_str" : "14088961",
      "id" : 14088961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223871207781564418",
  "geo" : { },
  "id_str" : "223873981554491392",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @mutle yes, it's pretty bad to use any Obj-C\/iOS native API in RM. I can't wait until it's all abstracted away.",
  "id" : 223873981554491392,
  "in_reply_to_status_id" : 223871207781564418,
  "created_at" : "2012-07-13 20:18:11 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/kcmMFPo3",
      "expanded_url" : "http:\/\/fendingo.com\/",
      "display_url" : "fendingo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "223863869574103041",
  "geo" : { },
  "id_str" : "223865139978452992",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending http:\/\/t.co\/kcmMFPo3 is available.",
  "id" : 223865139978452992,
  "in_reply_to_status_id" : 223863869574103041,
  "created_at" : "2012-07-13 19:43:03 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 3, 12 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223863632839184384",
  "text" : "RT @marcweil: @qrush Who needs documentation when you have paragraphs for method names?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "223857628936273920",
    "geo" : { },
    "id_str" : "223863354740056066",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Who needs documentation when you have paragraphs for method names?",
    "id" : 223863354740056066,
    "in_reply_to_status_id" : 223857628936273920,
    "created_at" : "2012-07-13 19:35:57 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "protected" : false,
      "id_str" : "18230025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/347813659\/6211_589544810555_24408236_34577289_5557426_n_normal.jpg",
      "id" : 18230025,
      "verified" : false
    }
  },
  "id" : 223863632839184384,
  "created_at" : "2012-07-13 19:37:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223861805682925568",
  "geo" : { },
  "id_str" : "223863167636348931",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza i've been bitten by pretty normal\/standard stuff already, but I definitely dont feel like I have control over this stuff yet",
  "id" : 223863167636348931,
  "in_reply_to_status_id" : 223861805682925568,
  "created_at" : "2012-07-13 19:35:13 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 0, 10 ],
      "id_str" : "14437070",
      "id" : 14437070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223859565899431938",
  "geo" : { },
  "id_str" : "223860391875313664",
  "in_reply_to_user_id" : 14437070,
  "text" : "@marksands alright, \"hate\" is a strong word. how about \"strongly disagree with choice of using verbose names to describe obvious things\"",
  "id" : 223860391875313664,
  "in_reply_to_status_id" : 223859565899431938,
  "created_at" : "2012-07-13 19:24:11 +0000",
  "in_reply_to_screen_name" : "marksands",
  "in_reply_to_user_id_str" : "14437070",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223858274750046208",
  "geo" : { },
  "id_str" : "223859146234150912",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza i'd love to pick your brain on this kind of stuff. I haven't noticed anything too bad yet. any docs you recommend?",
  "id" : 223859146234150912,
  "in_reply_to_status_id" : 223858274750046208,
  "created_at" : "2012-07-13 19:19:14 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Adam Pumm",
      "screen_name" : "pummer",
      "indices" : [ 13, 20 ],
      "id_str" : "45489027",
      "id" : 45489027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223858270262132736",
  "geo" : { },
  "id_str" : "223859052566941696",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @pummer Buffalo folks are everywhere.",
  "id" : 223859052566941696,
  "in_reply_to_status_id" : 223858270262132736,
  "created_at" : "2012-07-13 19:18:51 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223857737832996864",
  "geo" : { },
  "id_str" : "223858090842390528",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza on that note, have you checked out RubyMotion?",
  "id" : 223858090842390528,
  "in_reply_to_status_id" : 223857737832996864,
  "created_at" : "2012-07-13 19:15:02 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 138 ],
      "url" : "https:\/\/t.co\/RHmXFRD0",
      "expanded_url" : "https:\/\/github.com\/AFNetworking\/AFIncrementalStore",
      "display_url" : "github.com\/AFNetworking\/A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223857628936273920",
  "text" : "I hate that the Obj-C community goes nuts for methods like: representationOrArrayOfRepresentationsFromResponseObject https:\/\/t.co\/RHmXFRD0",
  "id" : 223857628936273920,
  "created_at" : "2012-07-13 19:13:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Adam Pumm",
      "screen_name" : "pummer",
      "indices" : [ 13, 20 ],
      "id_str" : "45489027",
      "id" : 45489027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223856632159944704",
  "geo" : { },
  "id_str" : "223857353861234690",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @pummer wow, small world in this tweet!",
  "id" : 223857353861234690,
  "in_reply_to_status_id" : 223856632159944704,
  "created_at" : "2012-07-13 19:12:06 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223856212645642242",
  "text" : "I might need to add a line into my bio \"Has a dubious history with pastries\"",
  "id" : 223856212645642242,
  "created_at" : "2012-07-13 19:07:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 18, 28 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 45, 55 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/IlWrPfwL",
      "expanded_url" : "http:\/\/instagr.am\/p\/NCDouuM6gV\/",
      "display_url" : "instagr.am\/p\/NCDouuM6gV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "223855758528352258",
  "text" : "Mystery solved by @aquaranto. I love working @37signals! http:\/\/t.co\/IlWrPfwL",
  "id" : 223855758528352258,
  "created_at" : "2012-07-13 19:05:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/Oek3j0oN",
      "expanded_url" : "http:\/\/pumpernick.com\/item--Raisin-Scones--raisin_scones.html",
      "display_url" : "pumpernick.com\/item--Raisin-S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223855317358886915",
  "text" : "Correction, it's a raisin scone? Called the company to try to find out more. http:\/\/t.co\/Oek3j0oN",
  "id" : 223855317358886915,
  "created_at" : "2012-07-13 19:04:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/OITFST0Q",
      "expanded_url" : "http:\/\/instagr.am\/p\/NCCaeeM6vd\/",
      "display_url" : "instagr.am\/p\/NCCaeeM6vd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "223853091844407296",
  "text" : "Pumpernick n Pastry just sent me biscuits? No card or anything. Who sent me biscuits?! http:\/\/t.co\/OITFST0Q",
  "id" : 223853091844407296,
  "created_at" : "2012-07-13 18:55:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223838461306744836",
  "geo" : { },
  "id_str" : "223850827490656257",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef go RM. If you don\u2019t want to go native, just write a mobile web app. Titanium, etc feel like half assing it.",
  "id" : 223850827490656257,
  "in_reply_to_status_id" : 223838461306744836,
  "created_at" : "2012-07-13 18:46:10 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223836912413196289",
  "geo" : { },
  "id_str" : "223837443739238401",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors ROFL. I seriously hope this is your announcement!",
  "id" : 223837443739238401,
  "in_reply_to_status_id" : 223836912413196289,
  "created_at" : "2012-07-13 17:52:59 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 6, 16 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 17, 32 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 106, 116 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223828108086747136",
  "geo" : { },
  "id_str" : "223830541475119104",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu @aspleenic @1ofyourmeteors oh wow! that's one way to find more people to play board games with. \/cc @aquaranto",
  "id" : 223830541475119104,
  "in_reply_to_status_id" : 223828108086747136,
  "created_at" : "2012-07-13 17:25:34 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223829691176456192",
  "geo" : { },
  "id_str" : "223830073550176256",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh wat? i dont understand.",
  "id" : 223830073550176256,
  "in_reply_to_status_id" : 223829691176456192,
  "created_at" : "2012-07-13 17:23:42 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223828289561706496",
  "geo" : { },
  "id_str" : "223828737815363586",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi thanks!!",
  "id" : 223828737815363586,
  "in_reply_to_status_id" : 223828289561706496,
  "created_at" : "2012-07-13 17:18:24 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 3, 10 ],
      "id_str" : "15395778",
      "id" : 15395778
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223828661764243459",
  "text" : "RT @jmazzi: @qrush Must have written down 15 different gems\/projects during your talk. We have already integrated a number of them into  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "223826830749216768",
    "geo" : { },
    "id_str" : "223828289561706496",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Must have written down 15 different gems\/projects during your talk. We have already integrated a number of them into our projects :)",
    "id" : 223828289561706496,
    "in_reply_to_status_id" : 223826830749216768,
    "created_at" : "2012-07-13 17:16:37 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "protected" : false,
      "id_str" : "15395778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413712456620322816\/Ki1bebJu_normal.jpeg",
      "id" : 15395778,
      "verified" : false
    }
  },
  "id" : 223828661764243459,
  "created_at" : "2012-07-13 17:18:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Moran",
      "screen_name" : "ChadMoran",
      "indices" : [ 0, 10 ],
      "id_str" : "16367850",
      "id" : 16367850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223822546854887426",
  "geo" : { },
  "id_str" : "223827951408513025",
  "in_reply_to_user_id" : 16367850,
  "text" : "@ChadMoran Woot! i think thats the best freeze frame ever.",
  "id" : 223827951408513025,
  "in_reply_to_status_id" : 223822546854887426,
  "created_at" : "2012-07-13 17:15:16 +0000",
  "in_reply_to_screen_name" : "ChadMoran",
  "in_reply_to_user_id_str" : "16367850",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/FZkr7z66",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3205-go-code-spelunking-with-me-in-the-all-new",
      "display_url" : "37signals.com\/svn\/posts\/3205\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223826830749216768",
  "text" : "Go code spelunking in the all new Basecamp: http:\/\/t.co\/FZkr7z66",
  "id" : 223826830749216768,
  "created_at" : "2012-07-13 17:10:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 3, 13 ],
      "id_str" : "14182110",
      "id" : 14182110
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 91, 97 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf2012",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/6cOC7eel",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/910-railsconf2012-basecamp-next-code-spelunking",
      "display_url" : "confreaks.com\/videos\/910-rai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223810949365243905",
  "text" : "RT @confreaks: New Video! #railsconf2012 - Basecamp Next: Code Spelunking by Nick Quaranto @qrush http:\/\/t.co\/6cOC7eel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 76, 82 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf2012",
        "indices" : [ 11, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/6cOC7eel",
        "expanded_url" : "http:\/\/confreaks.com\/videos\/910-railsconf2012-basecamp-next-code-spelunking",
        "display_url" : "confreaks.com\/videos\/910-rai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "223809984247500801",
    "text" : "New Video! #railsconf2012 - Basecamp Next: Code Spelunking by Nick Quaranto @qrush http:\/\/t.co\/6cOC7eel",
    "id" : 223809984247500801,
    "created_at" : "2012-07-13 16:03:53 +0000",
    "user" : {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "protected" : false,
      "id_str" : "14182110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508193987417485312\/4FaFrBga_normal.png",
      "id" : 14182110,
      "verified" : false
    }
  },
  "id" : 223810949365243905,
  "created_at" : "2012-07-13 16:07:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "223801127634866176",
  "text" : "This time, with an actual internet connection: Now playing The Notorious B.I.G.: Hypnotize \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 223801127634866176,
  "created_at" : "2012-07-13 15:28:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "223794274104381441",
  "text" : "DJing in the CoworkBuffalo room. Now playing Richard 'Popcorn' Wylie #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 223794274104381441,
  "created_at" : "2012-07-13 15:01:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett Murphey",
      "screen_name" : "gmurphey",
      "indices" : [ 0, 9 ],
      "id_str" : "822220",
      "id" : 822220
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 10, 24 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223789650463043586",
  "geo" : { },
  "id_str" : "223792891456270336",
  "in_reply_to_user_id" : 822220,
  "text" : "@gmurphey @coworkbuffalo Awesome!",
  "id" : 223792891456270336,
  "in_reply_to_status_id" : 223789650463043586,
  "created_at" : "2012-07-13 14:55:57 +0000",
  "in_reply_to_screen_name" : "gmurphey",
  "in_reply_to_user_id_str" : "822220",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duncan Mac-Vicar P.",
      "screen_name" : "dmacvicar",
      "indices" : [ 0, 10 ],
      "id_str" : "10855542",
      "id" : 10855542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223769149501997057",
  "geo" : { },
  "id_str" : "223781043910619136",
  "in_reply_to_user_id" : 10855542,
  "text" : "@dmacvicar missed your ping on freenode. on now. there are alternatives.",
  "id" : 223781043910619136,
  "in_reply_to_status_id" : 223769149501997057,
  "created_at" : "2012-07-13 14:08:53 +0000",
  "in_reply_to_screen_name" : "dmacvicar",
  "in_reply_to_user_id_str" : "10855542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duncan Mac-Vicar P.",
      "screen_name" : "dmacvicar",
      "indices" : [ 0, 10 ],
      "id_str" : "10855542",
      "id" : 10855542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223710018325852160",
  "geo" : { },
  "id_str" : "223759477155962882",
  "in_reply_to_user_id" : 10855542,
  "text" : "@dmacvicar That files\u2019 use is deprecated entirely and is very out of date",
  "id" : 223759477155962882,
  "in_reply_to_status_id" : 223710018325852160,
  "created_at" : "2012-07-13 12:43:11 +0000",
  "in_reply_to_screen_name" : "dmacvicar",
  "in_reply_to_user_id_str" : "10855542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 5, 18 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 19, 26 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223672015951892480",
  "geo" : { },
  "id_str" : "223758523933261824",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat @steveklabnik @peterc then it shouldn\u2019t be called \u201Copen\u201D",
  "id" : 223758523933261824,
  "in_reply_to_status_id" : 223672015951892480,
  "created_at" : "2012-07-13 12:39:23 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223756534180610048",
  "geo" : { },
  "id_str" : "223758364511977472",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy yes, and I just woke up too.",
  "id" : 223758364511977472,
  "in_reply_to_status_id" : 223756534180610048,
  "created_at" : "2012-07-13 12:38:45 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223662836063289344",
  "text" : "Instagram the app gets away with so much because it\u2019s temporary by default.",
  "id" : 223662836063289344,
  "created_at" : "2012-07-13 06:19:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223651615587049472",
  "geo" : { },
  "id_str" : "223651715633778688",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage such douchebaggery.",
  "id" : 223651715633778688,
  "in_reply_to_status_id" : 223651615587049472,
  "created_at" : "2012-07-13 05:34:58 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223633528808677377",
  "geo" : { },
  "id_str" : "223651609148796929",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg hell yeah! Happy 21!",
  "id" : 223651609148796929,
  "in_reply_to_status_id" : 223633528808677377,
  "created_at" : "2012-07-13 05:34:33 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 14, 21 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223649030486507522",
  "geo" : { },
  "id_str" : "223649313853673473",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @peterc err, shields. You get it.",
  "id" : 223649313853673473,
  "in_reply_to_status_id" : 223649030486507522,
  "created_at" : "2012-07-13 05:25:26 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 14, 21 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223649030486507522",
  "geo" : { },
  "id_str" : "223649235634098176",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @peterc our guns can\u2019t handle ego of this magnitude!",
  "id" : 223649235634098176,
  "in_reply_to_status_id" : 223649030486507522,
  "created_at" : "2012-07-13 05:25:07 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 131 ],
      "url" : "https:\/\/t.co\/UB0HcgDo",
      "expanded_url" : "https:\/\/gist.github.com\/3098860",
      "display_url" : "gist.github.com\/3098860"
    } ]
  },
  "geo" : { },
  "id_str" : "223648636083507200",
  "text" : "Even the title \u201COpen Conference Expectations\u201D reeks of self importance and lacks humility. Get over yourself. https:\/\/t.co\/UB0HcgDo",
  "id" : 223648636083507200,
  "created_at" : "2012-07-13 05:22:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223639061125009409",
  "geo" : { },
  "id_str" : "223640337023897600",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg this is a joke right?",
  "id" : 223640337023897600,
  "in_reply_to_status_id" : 223639061125009409,
  "created_at" : "2012-07-13 04:49:46 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gisi",
      "screen_name" : "gisikw",
      "indices" : [ 0, 7 ],
      "id_str" : "14308739",
      "id" : 14308739
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 8, 15 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223633139711479808",
  "geo" : { },
  "id_str" : "223635062720176128",
  "in_reply_to_user_id" : 14308739,
  "text" : "@gisikw @peterc that\u2019s the most whiny, prima-donna thing I\u2019ve read in a long time.",
  "id" : 223635062720176128,
  "in_reply_to_status_id" : 223633139711479808,
  "created_at" : "2012-07-13 04:28:48 +0000",
  "in_reply_to_screen_name" : "gisikw",
  "in_reply_to_user_id_str" : "14308739",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 0, 14 ],
      "id_str" : "679103",
      "id" : 679103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223633516045418497",
  "geo" : { },
  "id_str" : "223634042459918339",
  "in_reply_to_user_id" : 679103,
  "text" : "@travisjeffery did you read the post?",
  "id" : 223634042459918339,
  "in_reply_to_status_id" : 223633516045418497,
  "created_at" : "2012-07-13 04:24:45 +0000",
  "in_reply_to_screen_name" : "travisjeffery",
  "in_reply_to_user_id_str" : "679103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223630648273932290",
  "text" : "RT @r00k: I look forward to the end of the \"Java as the least common denominator for general programming books\" era.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223494843089952770",
    "text" : "I look forward to the end of the \"Java as the least common denominator for general programming books\" era.",
    "id" : 223494843089952770,
    "created_at" : "2012-07-12 19:11:37 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 223630648273932290,
  "created_at" : "2012-07-13 04:11:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223619850881335297",
  "geo" : { },
  "id_str" : "223620495885615107",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef and\u2026zero tweets. Why don\u2019t they get this twitter thing?",
  "id" : 223620495885615107,
  "in_reply_to_status_id" : 223619850881335297,
  "created_at" : "2012-07-13 03:30:55 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 3, 9 ],
      "id_str" : "183749519",
      "id" : 183749519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223620336904699906",
  "text" : "RT @paulg: Uber is so obviously a good thing that you can measure how corrupt cities are by how hard they try to suppress it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222462460978937856",
    "text" : "Uber is so obviously a good thing that you can measure how corrupt cities are by how hard they try to suppress it.",
    "id" : 222462460978937856,
    "created_at" : "2012-07-09 22:49:18 +0000",
    "user" : {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "protected" : false,
      "id_str" : "183749519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1824002576\/pg-railsconf_normal.jpg",
      "id" : 183749519,
      "verified" : true
    }
  },
  "id" : 223620336904699906,
  "created_at" : "2012-07-13 03:30:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/qReOmZmf",
      "expanded_url" : "http:\/\/oncoding.posterous.com\/so-you-want-to-learn-to-code",
      "display_url" : "oncoding.posterous.com\/so-you-want-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223614426400563200",
  "text" : "\"The ones who don't move for about 4 or 5 hours are probably real programmers\" very accurately describes how I work. http:\/\/t.co\/qReOmZmf",
  "id" : 223614426400563200,
  "created_at" : "2012-07-13 03:06:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223610658770526208",
  "geo" : { },
  "id_str" : "223612957374943234",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt yes!",
  "id" : 223612957374943234,
  "in_reply_to_status_id" : 223610658770526208,
  "created_at" : "2012-07-13 03:00:58 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/K7oErCyb",
      "expanded_url" : "http:\/\/instagr.am\/p\/NAGiQdM6po\/",
      "display_url" : "instagr.am\/p\/NAGiQdM6po\/"
    } ]
  },
  "geo" : { },
  "id_str" : "223580938104352768",
  "text" : "Tired husky is tired. http:\/\/t.co\/K7oErCyb",
  "id" : 223580938104352768,
  "created_at" : "2012-07-13 00:53:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223566500697620481",
  "geo" : { },
  "id_str" : "223566709284552704",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes they stopped caring.",
  "id" : 223566709284552704,
  "in_reply_to_status_id" : 223566500697620481,
  "created_at" : "2012-07-12 23:57:11 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223565728819851264",
  "geo" : { },
  "id_str" : "223566411686100993",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes and the ad... \"Wanna see the filthiest show ever animated?  Then you simply must check out Panty and Stocking with Garter Belt!\"",
  "id" : 223566411686100993,
  "in_reply_to_status_id" : 223565728819851264,
  "created_at" : "2012-07-12 23:56:00 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/vNfiOcl9",
      "expanded_url" : "http:\/\/penny-arcade.com\/comic\/2012\/05\/25",
      "display_url" : "penny-arcade.com\/comic\/2012\/05\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "223563811846750213",
  "geo" : { },
  "id_str" : "223564486823518208",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh http:\/\/t.co\/vNfiOcl9",
  "id" : 223564486823518208,
  "in_reply_to_status_id" : 223563811846750213,
  "created_at" : "2012-07-12 23:48:21 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/gUdWILg4",
      "expanded_url" : "http:\/\/Digg.com",
      "display_url" : "Digg.com"
    }, {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/lDSWjW0f",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MK6TXMsvgQg",
      "display_url" : "youtube.com\/watch?v=MK6TXM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223519178722775043",
  "text" : "Current http:\/\/t.co\/gUdWILg4 status: http:\/\/t.co\/lDSWjW0f",
  "id" : 223519178722775043,
  "created_at" : "2012-07-12 20:48:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turntable",
      "screen_name" : "turntablefm",
      "indices" : [ 53, 65 ],
      "id_str" : "1934900918",
      "id" : 1934900918
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 81, 95 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/223453382856278016\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/usAPbJuA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxndqvVCAAE0d2z.png",
      "id_str" : "223453382860472321",
      "id" : 223453382860472321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxndqvVCAAE0d2z.png",
      "sizes" : [ {
        "h" : 507,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 866,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/usAPbJuA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223453382856278016",
  "text" : "Is this the first example of lead generation through @turntablefm? (At least for @coworkbuffalo) http:\/\/t.co\/usAPbJuA",
  "id" : 223453382856278016,
  "created_at" : "2012-07-12 16:26:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 14, 29 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223446884327505921",
  "geo" : { },
  "id_str" : "223452732252622849",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson @ChrisVanPatten it's pretty easy to include ActiveSupport outside of Rails. As for routing, view helpers, etc...GL HF!",
  "id" : 223452732252622849,
  "in_reply_to_status_id" : 223446884327505921,
  "created_at" : "2012-07-12 16:24:17 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 16, 29 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223445854508421121",
  "geo" : { },
  "id_str" : "223445980253663232",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @IanCAnderson Sinatra is wonderful too. Just don't rewrite Rails in it ;)",
  "id" : 223445980253663232,
  "in_reply_to_status_id" : 223445854508421121,
  "created_at" : "2012-07-12 15:57:27 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223444921737162755",
  "geo" : { },
  "id_str" : "223445299253882881",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier double backflip with bob burnquist!!!?",
  "id" : 223445299253882881,
  "in_reply_to_status_id" : 223444921737162755,
  "created_at" : "2012-07-12 15:54:45 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "223443018789830656",
  "text" : "Totally in Tony Hawk 64 mode right now. Now playing: Goldfinger: Superman \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 223443018789830656,
  "created_at" : "2012-07-12 15:45:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/NngBdjkC",
      "expanded_url" : "http:\/\/tf2chan.net\/offtopic\/src\/129689446266.jpg",
      "display_url" : "tf2chan.net\/offtopic\/src\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "223440099789115393",
  "geo" : { },
  "id_str" : "223442680766664704",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten http:\/\/t.co\/NngBdjkC",
  "id" : 223442680766664704,
  "in_reply_to_status_id" : 223440099789115393,
  "created_at" : "2012-07-12 15:44:21 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "223435164628426753",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Gotye: Somebody That I Used To Know \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 223435164628426753,
  "created_at" : "2012-07-12 15:14:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 20, 30 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223428311685140480",
  "text" : "Very exhausted from @37signals Pitchday. What a crazy experience.",
  "id" : 223428311685140480,
  "created_at" : "2012-07-12 14:47:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abbey",
      "screen_name" : "Just_Abbey",
      "indices" : [ 0, 11 ],
      "id_str" : "15588815",
      "id" : 15588815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223307483886788608",
  "geo" : { },
  "id_str" : "223426974381645824",
  "in_reply_to_user_id" : 15588815,
  "text" : "@Just_Abbey you get ridiculous bonuses\/prizes every few days",
  "id" : 223426974381645824,
  "in_reply_to_status_id" : 223307483886788608,
  "created_at" : "2012-07-12 14:41:56 +0000",
  "in_reply_to_screen_name" : "Just_Abbey",
  "in_reply_to_user_id_str" : "15588815",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223426591403941889",
  "geo" : { },
  "id_str" : "223426862527950849",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety I think I need one.",
  "id" : 223426862527950849,
  "in_reply_to_status_id" : 223426591403941889,
  "created_at" : "2012-07-12 14:41:29 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223284287540174848",
  "geo" : { },
  "id_str" : "223285142750380032",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems 22. Mystery parts abound thanks to the global event. Set your flight crew to reddit",
  "id" : 223285142750380032,
  "in_reply_to_status_id" : 223284287540174848,
  "created_at" : "2012-07-12 05:18:21 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223278177357799424",
  "geo" : { },
  "id_str" : "223281013621665793",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt I used to put the cereal in the fridge and the milk on the shelf during some very tired mornings",
  "id" : 223281013621665793,
  "in_reply_to_status_id" : 223278177357799424,
  "created_at" : "2012-07-12 05:01:56 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/223280079596306432\/photo\/1",
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/QyjJ4PjZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxlADKYCQAEUvAQ.png",
      "id_str" : "223280079600500737",
      "id" : 223280079600500737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxlADKYCQAEUvAQ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/QyjJ4PjZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223280079596306432",
  "text" : "Got a starship in Pocket Planes. Too costly to run at a profit so far\u2026irony? http:\/\/t.co\/QyjJ4PjZ",
  "id" : 223280079596306432,
  "created_at" : "2012-07-12 04:58:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223240170751803394",
  "geo" : { },
  "id_str" : "223241271458791424",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide Hocus Pocus Focus. Coked up yodeling?",
  "id" : 223241271458791424,
  "in_reply_to_status_id" : 223240170751803394,
  "created_at" : "2012-07-12 02:24:01 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223239900235960320",
  "geo" : { },
  "id_str" : "223241053816373249",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky seriously, the worst! So much not fun.",
  "id" : 223241053816373249,
  "in_reply_to_status_id" : 223239900235960320,
  "created_at" : "2012-07-12 02:23:09 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223237657629696000",
  "geo" : { },
  "id_str" : "223239444348674048",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide sadly none! Usually there is. Pretend I had a montage.",
  "id" : 223239444348674048,
  "in_reply_to_status_id" : 223237657629696000,
  "created_at" : "2012-07-12 02:16:45 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223237005704826880",
  "text" : "Got completely lost at ORD. Sprinted 2 terminals and outside twice. Said fuck to a TSA officer. Boarded now\u2026what a day.",
  "id" : 223237005704826880,
  "created_at" : "2012-07-12 02:07:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223168479656804352",
  "geo" : { },
  "id_str" : "223169226091921411",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant cool dude, congrats!",
  "id" : 223169226091921411,
  "in_reply_to_status_id" : 223168479656804352,
  "created_at" : "2012-07-11 21:37:44 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223167499401838593",
  "geo" : { },
  "id_str" : "223167994975629315",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant you wrote a book?",
  "id" : 223167994975629315,
  "in_reply_to_status_id" : 223167499401838593,
  "created_at" : "2012-07-11 21:32:50 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Nicklas",
      "screen_name" : "jonicklas",
      "indices" : [ 0, 10 ],
      "id_str" : "7807502",
      "id" : 7807502
    }, {
      "name" : "Henrik Nyh",
      "screen_name" : "henrik",
      "indices" : [ 11, 18 ],
      "id_str" : "14208392",
      "id" : 14208392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223121972102565888",
  "geo" : { },
  "id_str" : "223161193353854977",
  "in_reply_to_user_id" : 7807502,
  "text" : "@jonicklas @henrik agreed, but why don't these articles never suggest to use CoffeeScript? so many folks missing out.",
  "id" : 223161193353854977,
  "in_reply_to_status_id" : 223121972102565888,
  "created_at" : "2012-07-11 21:05:49 +0000",
  "in_reply_to_screen_name" : "jonicklas",
  "in_reply_to_user_id_str" : "7807502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetbot by Tapbots",
      "screen_name" : "tweetbot",
      "indices" : [ 4, 13 ],
      "id_str" : "274626857",
      "id" : 274626857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223124448235110403",
  "text" : "Hey @tweetbot , TweetBot for Mac is awesome. Can we get vim\/gmail j\/k shortcuts for navigating up\/down in the timeline?",
  "id" : 223124448235110403,
  "created_at" : "2012-07-11 18:39:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 13, 25 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223082219428790272",
  "text" : "Learned that @sstephenson is so serious about defaults, he hasn't even changed his desktop wallpaper.",
  "id" : 223082219428790272,
  "created_at" : "2012-07-11 15:52:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/k0lo7L3i",
      "expanded_url" : "http:\/\/youoffendmeyouoffendmyfamily.com\/wordpress\/wp-content\/uploads\/2010\/03\/Monster-Truck-City-Show.jpg",
      "display_url" : "youoffendmeyouoffendmyfamily.com\/wordpress\/wp-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223061721550553088",
  "text" : "PITCHDAY PITCHDAY PITCHDAY!!!!! http:\/\/t.co\/k0lo7L3i",
  "id" : 223061721550553088,
  "created_at" : "2012-07-11 14:30:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223059409104945152",
  "text" : "CHICAGO!",
  "id" : 223059409104945152,
  "created_at" : "2012-07-11 14:21:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223059384127852544",
  "text" : "Crazy lady blocked traffic in front of our taxi, threw a danish at me (through the window!), then got out her car to yell at the cabbie.",
  "id" : 223059384127852544,
  "created_at" : "2012-07-11 14:21:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222995353287405568",
  "geo" : { },
  "id_str" : "222998150175145984",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff same here, no free massage even for the first flight in months from BUF.",
  "id" : 222998150175145984,
  "in_reply_to_status_id" : 222995353287405568,
  "created_at" : "2012-07-11 10:17:56 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222983270999130113",
  "geo" : { },
  "id_str" : "222997887280353280",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca I wish I would have from the start. I have most of my schoolwork in a private repo but not all.",
  "id" : 222997887280353280,
  "in_reply_to_status_id" : 222983270999130113,
  "created_at" : "2012-07-11 10:16:54 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 8, 23 ],
      "id_str" : "267895957",
      "id" : 267895957
    }, {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 24, 37 ],
      "id_str" : "14204623",
      "id" : 14204623
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 84, 95 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 78 ],
      "url" : "https:\/\/t.co\/dKs9xvE5",
      "expanded_url" : "https:\/\/twitter.com\/#!\/search\/realtime\/bob%20segar",
      "display_url" : "twitter.com\/#!\/search\/real\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222894547905150976",
  "text" : "Oh man. @gabrielgironda @moonpolysoft here's a goldmine: https:\/\/t.co\/dKs9xvE5 (via @shellscape)",
  "id" : 222894547905150976,
  "created_at" : "2012-07-11 03:26:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/H8pzvAg2",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3186-workplace-experiments-a-month-to-yourself",
      "display_url" : "37signals.com\/svn\/posts\/3186\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222874686671958018",
  "text" : "Crazy excited for Pitchday in Chicago tomorrow. http:\/\/t.co\/H8pzvAg2",
  "id" : 222874686671958018,
  "created_at" : "2012-07-11 02:07:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 0, 9 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222844509728411648",
  "geo" : { },
  "id_str" : "222848213596639232",
  "in_reply_to_user_id" : 21431343,
  "text" : "@bostonrb getting feedback a bit\u2026also PLZ 2 FULLSCREEN PREVIEW",
  "id" : 222848213596639232,
  "in_reply_to_status_id" : 222844509728411648,
  "created_at" : "2012-07-11 00:22:09 +0000",
  "in_reply_to_screen_name" : "bostonrb",
  "in_reply_to_user_id_str" : "21431343",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David A. Black",
      "screen_name" : "david_a_black",
      "indices" : [ 13, 27 ],
      "id_str" : "9929452",
      "id" : 9929452
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 46, 55 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 65, 73 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/222847061425520642\/photo\/1",
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/sVBVRZk4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Axe2OMACAAArpix.jpg",
      "id_str" : "222847061433909248",
      "id" : 222847061433909248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Axe2OMACAAArpix.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sVBVRZk4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222847061425520642",
  "text" : "Listening to @david_a_black on a hangout from @bostonrb while at @wnyruby ! BAWWWWWW http:\/\/t.co\/sVBVRZk4",
  "id" : 222847061425520642,
  "created_at" : "2012-07-11 00:17:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222841745875013633",
  "geo" : { },
  "id_str" : "222842280871071746",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit HI",
  "id" : 222842280871071746,
  "in_reply_to_status_id" : 222841745875013633,
  "created_at" : "2012-07-10 23:58:34 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222839942383009793",
  "geo" : { },
  "id_str" : "222840215641931776",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff gotta get up at 5 here...it's gonna be great!",
  "id" : 222840215641931776,
  "in_reply_to_status_id" : 222839942383009793,
  "created_at" : "2012-07-10 23:50:22 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 17, 29 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222832080135000064",
  "geo" : { },
  "id_str" : "222835063308562433",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts @bcardarella we just muted. Too much discussion and can\u2019t hear it on our end.",
  "id" : 222835063308562433,
  "in_reply_to_status_id" : 222832080135000064,
  "created_at" : "2012-07-10 23:29:53 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 14, 23 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 77, 85 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222834383583850496",
  "text" : "Big thanks to @bostonrb for streaming tonight\u2019s talks! We have it live on at @wnyruby.",
  "id" : 222834383583850496,
  "created_at" : "2012-07-10 23:27:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 17, 29 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222832080135000064",
  "geo" : { },
  "id_str" : "222834067467534337",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts @bcardarella we have it rolling here but too much talk going on. :[",
  "id" : 222834067467534337,
  "in_reply_to_status_id" : 222832080135000064,
  "created_at" : "2012-07-10 23:25:56 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222825000686718976",
  "geo" : { },
  "id_str" : "222825328089903105",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan are you going to Chicago?",
  "id" : 222825328089903105,
  "in_reply_to_status_id" : 222825000686718976,
  "created_at" : "2012-07-10 22:51:12 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222779371100966913",
  "geo" : { },
  "id_str" : "222779732033417217",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson been in that mode the past week or two and loving it.",
  "id" : 222779732033417217,
  "in_reply_to_status_id" : 222779371100966913,
  "created_at" : "2012-07-10 19:50:01 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222770051080654849",
  "geo" : { },
  "id_str" : "222771833139761152",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden you're clearly not drunk enough.",
  "id" : 222771833139761152,
  "in_reply_to_status_id" : 222770051080654849,
  "created_at" : "2012-07-10 19:18:38 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 3, 14 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "New Relic",
      "screen_name" : "newrelic",
      "indices" : [ 45, 54 ],
      "id_str" : "15527007",
      "id" : 15527007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/TUGNuG0m",
      "expanded_url" : "http:\/\/dataporn.com",
      "display_url" : "dataporn.com"
    } ]
  },
  "geo" : { },
  "id_str" : "222767131085897729",
  "text" : "RT @paddyforan: I think my favourite part of @NewRelic is that they own http:\/\/t.co\/TUGNuG0m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Relic",
        "screen_name" : "newrelic",
        "indices" : [ 29, 38 ],
        "id_str" : "15527007",
        "id" : 15527007
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/TUGNuG0m",
        "expanded_url" : "http:\/\/dataporn.com",
        "display_url" : "dataporn.com"
      } ]
    },
    "geo" : { },
    "id_str" : "222766525092868099",
    "text" : "I think my favourite part of @NewRelic is that they own http:\/\/t.co\/TUGNuG0m",
    "id" : 222766525092868099,
    "created_at" : "2012-07-10 18:57:33 +0000",
    "user" : {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "protected" : false,
      "id_str" : "15445975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433766988179963904\/MjnoKMzP_normal.jpeg",
      "id" : 15445975,
      "verified" : false
    }
  },
  "id" : 222767131085897729,
  "created_at" : "2012-07-10 18:59:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/Eo4E68fu",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=3gOR91oentQ",
      "display_url" : "youtube.com\/watch?v=3gOR91\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222759987926147076",
  "text" : "Tesla is my hero. http:\/\/t.co\/Eo4E68fu",
  "id" : 222759987926147076,
  "created_at" : "2012-07-10 18:31:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 25, 39 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 45, 52 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/222750504550273025\/photo\/1",
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/dMcIaVpF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxdeZ1mCEAA-imm.png",
      "id_str" : "222750504554467328",
      "id" : 222750504554467328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxdeZ1mCEAA-imm.png",
      "sizes" : [ {
        "h" : 103,
        "resize" : "fit",
        "w" : 268
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 268
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 268
      }, {
        "h" : 103,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 268
      } ],
      "display_url" : "pic.twitter.com\/dMcIaVpF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222750504550273025",
  "text" : "And this is what happens @coworkbuffalo when @holman's ideas get loose. http:\/\/t.co\/dMcIaVpF",
  "id" : 222750504550273025,
  "created_at" : "2012-07-10 17:53:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/VD0WWzP1",
      "expanded_url" : "http:\/\/cl.ly\/HyWR\/emoji.png",
      "display_url" : "cl.ly\/HyWR\/emoji.png"
    } ]
  },
  "geo" : { },
  "id_str" : "222749791174668288",
  "text" : "RT @holman: Let me blow your mind today.\n\nEmoji hostnames on OS X: http:\/\/t.co\/VD0WWzP1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/VD0WWzP1",
        "expanded_url" : "http:\/\/cl.ly\/HyWR\/emoji.png",
        "display_url" : "cl.ly\/HyWR\/emoji.png"
      } ]
    },
    "geo" : { },
    "id_str" : "222748886396182528",
    "text" : "Let me blow your mind today.\n\nEmoji hostnames on OS X: http:\/\/t.co\/VD0WWzP1",
    "id" : 222748886396182528,
    "created_at" : "2012-07-10 17:47:27 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550019686230794240\/gWlpdYw2_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 222749791174668288,
  "created_at" : "2012-07-10 17:51:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/5KBTSXyO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Qp1nrhJAX3I",
      "display_url" : "youtube.com\/watch?v=Qp1nrh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222733721915236352",
  "text" : "Current status: http:\/\/t.co\/5KBTSXyO",
  "id" : 222733721915236352,
  "created_at" : "2012-07-10 16:47:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/gY9iWwDV",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3200-levels-of-aspiration",
      "display_url" : "37signals.com\/svn\/posts\/3200\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222719486611030016",
  "text" : "I love that Wordpress is on the bottom of this pyramid: http:\/\/t.co\/gY9iWwDV",
  "id" : 222719486611030016,
  "created_at" : "2012-07-10 15:50:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tilo Sloboda",
      "screen_name" : "tilosloboda",
      "indices" : [ 0, 12 ],
      "id_str" : "578304269",
      "id" : 578304269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222691234127413250",
  "geo" : { },
  "id_str" : "222698239000969217",
  "in_reply_to_user_id" : 578304269,
  "text" : "@tilosloboda I want no support issues, that fixes the problem :)",
  "id" : 222698239000969217,
  "in_reply_to_status_id" : 222691234127413250,
  "created_at" : "2012-07-10 14:26:12 +0000",
  "in_reply_to_screen_name" : "tilosloboda",
  "in_reply_to_user_id_str" : "578304269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niagara Falls USA",
      "screen_name" : "NiagaraFallsUSA",
      "indices" : [ 0, 16 ],
      "id_str" : "33558720",
      "id" : 33558720
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 17, 27 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222695870594940928",
  "geo" : { },
  "id_str" : "222698111422840834",
  "in_reply_to_user_id" : 33558720,
  "text" : "@NiagaraFallsUSA @magnachef it's snowing in July at the Falls?",
  "id" : 222698111422840834,
  "in_reply_to_status_id" : 222695870594940928,
  "created_at" : "2012-07-10 14:25:41 +0000",
  "in_reply_to_screen_name" : "NiagaraFallsUSA",
  "in_reply_to_user_id_str" : "33558720",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tilo Sloboda",
      "screen_name" : "tilosloboda",
      "indices" : [ 0, 12 ],
      "id_str" : "578304269",
      "id" : 578304269
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 13, 21 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 22, 30 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222677444774203392",
  "geo" : { },
  "id_str" : "222690143268646912",
  "in_reply_to_user_id" : 578304269,
  "text" : "@tilosloboda @evanphx @drbrain sorry, been ridiculously busy...havent been able to look at the queue. i'll try to today.",
  "id" : 222690143268646912,
  "in_reply_to_status_id" : 222677444774203392,
  "created_at" : "2012-07-10 13:54:02 +0000",
  "in_reply_to_screen_name" : "tilosloboda",
  "in_reply_to_user_id_str" : "578304269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Moazeni",
      "screen_name" : "zmoazeni",
      "indices" : [ 0, 9 ],
      "id_str" : "3576061",
      "id" : 3576061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222663762023428096",
  "geo" : { },
  "id_str" : "222669204640378880",
  "in_reply_to_user_id" : 3576061,
  "text" : "@zmoazeni did that\u2026woo!",
  "id" : 222669204640378880,
  "in_reply_to_status_id" : 222663762023428096,
  "created_at" : "2012-07-10 12:30:50 +0000",
  "in_reply_to_screen_name" : "zmoazeni",
  "in_reply_to_user_id_str" : "3576061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222542214981632003",
  "geo" : { },
  "id_str" : "222543722330603520",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza i find the lack of decent options here with sane defaults very disturbing. Too much dev going on in secret, not enough shared.",
  "id" : 222543722330603520,
  "in_reply_to_status_id" : 222542214981632003,
  "created_at" : "2012-07-10 04:12:12 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/Dh0SQZaf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wusGIl3v044",
      "display_url" : "youtube.com\/watch?v=wusGIl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "222543188014022656",
  "geo" : { },
  "id_str" : "222543450933956609",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes http:\/\/t.co\/Dh0SQZaf ?",
  "id" : 222543450933956609,
  "in_reply_to_status_id" : 222543188014022656,
  "created_at" : "2012-07-10 04:11:08 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222539782218203138",
  "geo" : { },
  "id_str" : "222540731896692738",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza it's just such a different mode of thinking. I have the basics down but I still feel like i'm missing something important.",
  "id" : 222540731896692738,
  "in_reply_to_status_id" : 222539782218203138,
  "created_at" : "2012-07-10 04:00:19 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222539715700736000",
  "text" : "CoreData is...hard.",
  "id" : 222539715700736000,
  "created_at" : "2012-07-10 03:56:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222437892021174274",
  "text" : "YOU GET A GITHUB! YOU GET A GITHUB! YOU GET A GITHUB! YOU GET A GITHUB!  EVERY BODY GETS GITHUBBBBS!",
  "id" : 222437892021174274,
  "created_at" : "2012-07-09 21:11:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 11, 17 ],
      "id_str" : "34287352",
      "id" : 34287352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222426736128819201",
  "geo" : { },
  "id_str" : "222427268700581889",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @byllc Not for future months!",
  "id" : 222427268700581889,
  "in_reply_to_status_id" : 222426736128819201,
  "created_at" : "2012-07-09 20:29:28 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 0, 6 ],
      "id_str" : "34287352",
      "id" : 34287352
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 7, 17 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 30, 44 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222426024481259520",
  "geo" : { },
  "id_str" : "222426324369817602",
  "in_reply_to_user_id" : 34287352,
  "text" : "@byllc @aspleenic could do it @coworkbuffalo!  it'll be cozy but we can rearrange desks for it. we have a projector screen too.",
  "id" : 222426324369817602,
  "in_reply_to_status_id" : 222426024481259520,
  "created_at" : "2012-07-09 20:25:42 +0000",
  "in_reply_to_screen_name" : "byllc",
  "in_reply_to_user_id_str" : "34287352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 17, 27 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 28, 34 ],
      "id_str" : "34287352",
      "id" : 34287352
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 35, 50 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 51, 64 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222393493878870016",
  "geo" : { },
  "id_str" : "222393942908481536",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts @aspleenic @byllc @1ofyourmeteors @wayneeseguin we should have a remote BOS\/BUF night, stream talks from both locations!",
  "id" : 222393942908481536,
  "in_reply_to_status_id" : 222393493878870016,
  "created_at" : "2012-07-09 18:17:02 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222392614576594945",
  "geo" : { },
  "id_str" : "222392911386521600",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic I think just speakers and the projector as normal",
  "id" : 222392911386521600,
  "in_reply_to_status_id" : 222392614576594945,
  "created_at" : "2012-07-09 18:12:56 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 27, 37 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 38, 44 ],
      "id_str" : "34287352",
      "id" : 34287352
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 45, 60 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 61, 74 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222391429383720960",
  "geo" : { },
  "id_str" : "222392276402454528",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts heck yes! @aspleenic @byllc @1ofyourmeteors @wayneeseguin let's get this set up!",
  "id" : 222392276402454528,
  "in_reply_to_status_id" : 222391429383720960,
  "created_at" : "2012-07-09 18:10:25 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 3, 15 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 39, 48 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 79, 87 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 93, 103 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222391098562191360",
  "text" : "Yo @bcardarella is there a livecast of @BostonRB tomorrow? We could watch from @WNYRuby! \/cc @aspleenic",
  "id" : 222391098562191360,
  "created_at" : "2012-07-09 18:05:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/xe00lDRC",
      "expanded_url" : "http:\/\/sstephenson.us\/posts\/on-configuration",
      "display_url" : "sstephenson.us\/posts\/on-confi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222386718265974785",
  "text" : "Quite glad I'm not the only one sick of endless configuration and tweaking: http:\/\/t.co\/xe00lDRC",
  "id" : 222386718265974785,
  "created_at" : "2012-07-09 17:48:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 27, 39 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/duxA5BZq",
      "expanded_url" : "http:\/\/jamesgolick.com\/2012\/7\/7\/how-to-lose-100-pounds.html",
      "display_url" : "jamesgolick.com\/2012\/7\/7\/how-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222382935628726274",
  "text" : "Stupid happy and proud for @jamesgolick. Keep being awesome! http:\/\/t.co\/duxA5BZq",
  "id" : 222382935628726274,
  "created_at" : "2012-07-09 17:33:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222375704577318913",
  "geo" : { },
  "id_str" : "222375954243268608",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens I'm well aware, but still not a fan.",
  "id" : 222375954243268608,
  "in_reply_to_status_id" : 222375704577318913,
  "created_at" : "2012-07-09 17:05:33 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/DZTJhcNC",
      "expanded_url" : "http:\/\/blog.trello.com\/trello-is-now-500000-strong\/",
      "display_url" : "blog.trello.com\/trello-is-now-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222375017286082561",
  "text" : "500K users, no paying customers. Why is this celebrated? http:\/\/t.co\/DZTJhcNC",
  "id" : 222375017286082561,
  "created_at" : "2012-07-09 17:01:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 3, 15 ],
      "id_str" : "10687942",
      "id" : 10687942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222364662673580033",
  "text" : "RT @hotgazpacho: Once you go Async, back go never you",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222363148932485121",
    "text" : "Once you go Async, back go never you",
    "id" : 222363148932485121,
    "created_at" : "2012-07-09 16:14:40 +0000",
    "user" : {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "protected" : false,
      "id_str" : "10687942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459528086514851840\/nIDyJKgy_normal.jpeg",
      "id" : 10687942,
      "verified" : false
    }
  },
  "id" : 222364662673580033,
  "created_at" : "2012-07-09 16:20:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney a. crispell",
      "screen_name" : "whitneyarlene",
      "indices" : [ 0, 14 ],
      "id_str" : "213939016",
      "id" : 213939016
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 15, 29 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222355695767535616",
  "geo" : { },
  "id_str" : "222363822181187585",
  "in_reply_to_user_id" : 213939016,
  "text" : "@whitneyarlene @buffalopundit just walked by and it\u2019s packed. Love seeing activity downtown. Haters gonna hate.",
  "id" : 222363822181187585,
  "in_reply_to_status_id" : 222355695767535616,
  "created_at" : "2012-07-09 16:17:21 +0000",
  "in_reply_to_screen_name" : "whitneyarlene",
  "in_reply_to_user_id_str" : "213939016",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222354974607278080",
  "geo" : { },
  "id_str" : "222355315927154688",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt POG LIFE",
  "id" : 222355315927154688,
  "in_reply_to_status_id" : 222354974607278080,
  "created_at" : "2012-07-09 15:43:33 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222346359146156032",
  "geo" : { },
  "id_str" : "222353482814996480",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape nope!",
  "id" : 222353482814996480,
  "in_reply_to_status_id" : 222346359146156032,
  "created_at" : "2012-07-09 15:36:16 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Gw2kOTDW",
      "expanded_url" : "http:\/\/content.ytmnd.com\/content\/5\/0\/8\/508d9123504b614d0460bbe90f9b24f8.jpg",
      "display_url" : "content.ytmnd.com\/content\/5\/0\/8\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222349927685177344",
  "text" : "Current status: http:\/\/t.co\/Gw2kOTDW",
  "id" : 222349927685177344,
  "created_at" : "2012-07-09 15:22:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222337244013400064",
  "geo" : { },
  "id_str" : "222337475962609664",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV not sure if I prefer those or the scientology flyers. they're almost the same copy!",
  "id" : 222337475962609664,
  "in_reply_to_status_id" : 222337244013400064,
  "created_at" : "2012-07-09 14:32:39 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/cWEIdK5e",
      "expanded_url" : "http:\/\/www.indiegogo.com\/zworlddetroit?c=home",
      "display_url" : "indiegogo.com\/zworlddetroit?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222335669991772160",
  "text" : "3 words: ZOMBIE. THEME. PARK. http:\/\/t.co\/cWEIdK5e",
  "id" : 222335669991772160,
  "created_at" : "2012-07-09 14:25:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222329023798321152",
  "text" : "Someone out there has no friends on Facebook, writes on his own wall, and likes all of his own pictures.",
  "id" : 222329023798321152,
  "created_at" : "2012-07-09 13:59:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222148307273785346",
  "geo" : { },
  "id_str" : "222161302976593920",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove can I buy this? WTB. Is there a meat etsy?",
  "id" : 222161302976593920,
  "in_reply_to_status_id" : 222148307273785346,
  "created_at" : "2012-07-09 02:52:36 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/d9XZ2kCn",
      "expanded_url" : "http:\/\/clayallsopp.com\/posts\/the-ruby-motion-way\/",
      "display_url" : "clayallsopp.com\/posts\/the-ruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222161001049624577",
  "text" : "Feeling very bullish on RubyMotion and its future. This post definitely echoes what I\u2019m feeling. http:\/\/t.co\/d9XZ2kCn",
  "id" : 222161001049624577,
  "created_at" : "2012-07-09 02:51:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/BLI0tmV8",
      "expanded_url" : "http:\/\/instagr.am\/p\/M1aVtYM6r8\/",
      "display_url" : "instagr.am\/p\/M1aVtYM6r8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "222076153282826240",
  "text" : "Kayaked on the harbor today...totally exhausted.  http:\/\/t.co\/BLI0tmV8",
  "id" : 222076153282826240,
  "created_at" : "2012-07-08 21:14:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221995429838077953",
  "geo" : { },
  "id_str" : "221997525245231104",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt this should be on shark tank.",
  "id" : 221997525245231104,
  "in_reply_to_status_id" : 221995429838077953,
  "created_at" : "2012-07-08 16:01:49 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 46, 53 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221986200049815552",
  "text" : "Geddy met a 13 week old Corgi in the parkway. @gabebw\u2019s brain would have exploded with cuteness. Mine did.",
  "id" : 221986200049815552,
  "created_at" : "2012-07-08 15:16:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221845607306899458",
  "geo" : { },
  "id_str" : "221857973725700097",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten woot!",
  "id" : 221857973725700097,
  "in_reply_to_status_id" : 221845607306899458,
  "created_at" : "2012-07-08 06:47:17 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221837701685587968",
  "text" : "The best characters show up at Jim\u2019s Steakout at 1:30.",
  "id" : 221837701685587968,
  "created_at" : "2012-07-08 05:26:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Miller",
      "screen_name" : "jqr",
      "indices" : [ 0, 4 ],
      "id_str" : "14351457",
      "id" : 14351457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221794158560542721",
  "geo" : { },
  "id_str" : "221836881401360384",
  "in_reply_to_user_id" : 14351457,
  "text" : "@jqr THREE! Three!!!",
  "id" : 221836881401360384,
  "in_reply_to_status_id" : 221794158560542721,
  "created_at" : "2012-07-08 05:23:28 +0000",
  "in_reply_to_screen_name" : "jqr",
  "in_reply_to_user_id_str" : "14351457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221805674923954176",
  "geo" : { },
  "id_str" : "221836795187437568",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr risk is the worst.",
  "id" : 221836795187437568,
  "in_reply_to_status_id" : 221805674923954176,
  "created_at" : "2012-07-08 05:23:08 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221814683433304064",
  "geo" : { },
  "id_str" : "221836735875792896",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi very good",
  "id" : 221836735875792896,
  "in_reply_to_status_id" : 221814683433304064,
  "created_at" : "2012-07-08 05:22:54 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tilo Sloboda",
      "screen_name" : "tilosloboda",
      "indices" : [ 0, 12 ],
      "id_str" : "578304269",
      "id" : 578304269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/NJdqWZAL",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "221728336831979521",
  "geo" : { },
  "id_str" : "221793066632216576",
  "in_reply_to_user_id" : 578304269,
  "text" : "@tilosloboda send to http:\/\/t.co\/NJdqWZAL",
  "id" : 221793066632216576,
  "in_reply_to_status_id" : 221728336831979521,
  "created_at" : "2012-07-08 02:29:22 +0000",
  "in_reply_to_screen_name" : "tilosloboda",
  "in_reply_to_user_id_str" : "578304269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221792391970037761",
  "geo" : { },
  "id_str" : "221792647784828928",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten ha! This crowd is loud.",
  "id" : 221792647784828928,
  "in_reply_to_status_id" : 221792391970037761,
  "created_at" : "2012-07-08 02:27:42 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221791702246113281",
  "text" : "I can\u2019t even express how crazy Pit is. Most yelling in a board game ever.",
  "id" : 221791702246113281,
  "created_at" : "2012-07-08 02:23:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/bWrZ71lv",
      "expanded_url" : "http:\/\/instagr.am\/p\/MyVlIJs6pd\/",
      "display_url" : "instagr.am\/p\/MyVlIJs6pd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "221643423646621697",
  "text" : "Possibly the best measurement ever. http:\/\/t.co\/bWrZ71lv",
  "id" : 221643423646621697,
  "created_at" : "2012-07-07 16:34:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Liz Fox-Solomon",
      "screen_name" : "efoxsolomon",
      "indices" : [ 57, 69 ],
      "id_str" : "234873497",
      "id" : 234873497
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 86, 92 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/221451520305152000\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/7xjoZLei",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxLA_AMCQAACtC_.png",
      "id_str" : "221451520309346304",
      "id" : 221451520309346304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxLA_AMCQAACtC_.png",
      "sizes" : [ {
        "h" : 548,
        "resize" : "fit",
        "w" : 799
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7xjoZLei"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221458880117473280",
  "text" : "RT @kevinpurdy: Herp Derp Audiobook Reviews. Captured by @efoxsolomon, with thanks to @qrush: http:\/\/t.co\/7xjoZLei",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Liz Fox-Solomon",
        "screen_name" : "efoxsolomon",
        "indices" : [ 41, 53 ],
        "id_str" : "234873497",
        "id" : 234873497
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 70, 76 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/221451520305152000\/photo\/1",
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/7xjoZLei",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AxLA_AMCQAACtC_.png",
        "id_str" : "221451520309346304",
        "id" : 221451520309346304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxLA_AMCQAACtC_.png",
        "sizes" : [ {
          "h" : 548,
          "resize" : "fit",
          "w" : 799
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7xjoZLei"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221451520305152000",
    "text" : "Herp Derp Audiobook Reviews. Captured by @efoxsolomon, with thanks to @qrush: http:\/\/t.co\/7xjoZLei",
    "id" : 221451520305152000,
    "created_at" : "2012-07-07 03:52:11 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 221458880117473280,
  "created_at" : "2012-07-07 04:21:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ZGcmS7q9",
      "expanded_url" : "http:\/\/instagr.am\/p\/Mw5_QDM6kL\/",
      "display_url" : "instagr.am\/p\/Mw5_QDM6kL\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.2313635947, -80.507683754 ]
  },
  "id_str" : "221441944226766848",
  "text" : "Sorry, but La Nova still has the best.  @ Quaker Steak &amp; Lube http:\/\/t.co\/ZGcmS7q9",
  "id" : 221441944226766848,
  "created_at" : "2012-07-07 03:14:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/d2oL3NZY",
      "expanded_url" : "http:\/\/instagr.am\/p\/MwxtkKM6ux\/",
      "display_url" : "instagr.am\/p\/MwxtkKM6ux\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.2313635947, -80.507683754 ]
  },
  "id_str" : "221423732026126337",
  "text" : "A pun so bad, someone made a plaque for it.  @ Quaker Steak &amp; Lube http:\/\/t.co\/d2oL3NZY",
  "id" : 221423732026126337,
  "created_at" : "2012-07-07 02:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 85, 95 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/mRj4BgoL",
      "expanded_url" : "http:\/\/www.ebay.com\/itm\/BIGGEST-COLLECTION-EVER-22-SEGA-NINTENDO-PC-ENGINE-FULLSETS-FACTORY-SEALED-\/300736846867?pt=FR_Jeux_Vid%C3%A9o&hash=item4605501c13#ht_170646wt_805",
      "display_url" : "ebay.com\/itm\/BIGGEST-CO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "221406263429439488",
  "text" : "Why I shouldn't be entrusted with a million dollars, ever: http:\/\/t.co\/mRj4BgoL (via @stevelosh)",
  "id" : 221406263429439488,
  "created_at" : "2012-07-07 00:52:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/K5Qgb8dW",
      "expanded_url" : "http:\/\/instagr.am\/p\/MwpBwjM6pd\/",
      "display_url" : "instagr.am\/p\/MwpBwjM6pd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "221404644667162625",
  "text" : "Sunset husky. http:\/\/t.co\/K5Qgb8dW",
  "id" : 221404644667162625,
  "created_at" : "2012-07-07 00:45:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221389387555020800",
  "geo" : { },
  "id_str" : "221398239298064384",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz I just couldn\u2019t get some buried Keychain code to work. Had no idea why until I decided to look at the guide as a last resort",
  "id" : 221398239298064384,
  "in_reply_to_status_id" : 221389387555020800,
  "created_at" : "2012-07-07 00:20:28 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221371034547400704",
  "geo" : { },
  "id_str" : "221376415923314690",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus crap ! I have many notebook pages waiting for you.",
  "id" : 221376415923314690,
  "in_reply_to_status_id" : 221371034547400704,
  "created_at" : "2012-07-06 22:53:45 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/G22Df54c",
      "expanded_url" : "http:\/\/www.rubymotion.com\/developer-center\/guides\/project-management\/#_entitlements",
      "display_url" : "rubymotion.com\/developer-cent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "221343572346142720",
  "text" : "PROTIP: if you're new to iOS development and using RubyMotion, please read this. ALL of it. http:\/\/t.co\/G22Df54c",
  "id" : 221343572346142720,
  "created_at" : "2012-07-06 20:43:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221305866903764993",
  "geo" : { },
  "id_str" : "221306207355416577",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle oh man! pictures?",
  "id" : 221306207355416577,
  "in_reply_to_status_id" : 221305866903764993,
  "created_at" : "2012-07-06 18:14:46 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221287888988536832",
  "geo" : { },
  "id_str" : "221304151362121728",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr by purpose!",
  "id" : 221304151362121728,
  "in_reply_to_status_id" : 221287888988536832,
  "created_at" : "2012-07-06 18:06:35 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/Ykj1Sun2",
      "expanded_url" : "http:\/\/instagr.am\/p\/Mv1D78M6pP\/",
      "display_url" : "instagr.am\/p\/Mv1D78M6pP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "221290566573502464",
  "text" : "Escaped 3 times, luckily this pug got his attention back. http:\/\/t.co\/Ykj1Sun2",
  "id" : 221290566573502464,
  "created_at" : "2012-07-06 17:12:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/AVwsNJLn",
      "expanded_url" : "http:\/\/instagr.am\/p\/MvzsOPs6os\/",
      "display_url" : "instagr.am\/p\/MvzsOPs6os\/"
    } ]
  },
  "geo" : { },
  "id_str" : "221287393217622018",
  "text" : "Geddy swimming around! http:\/\/t.co\/AVwsNJLn",
  "id" : 221287393217622018,
  "created_at" : "2012-07-06 17:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 8, 12 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221059359969521666",
  "geo" : { },
  "id_str" : "221060450505334785",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates @dhh I don\u2019t see this as a single guide\u2026really deserves more attention than that",
  "id" : 221060450505334785,
  "in_reply_to_status_id" : 221059359969521666,
  "created_at" : "2012-07-06 01:58:13 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220997944227274753",
  "geo" : { },
  "id_str" : "221058217902477312",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh let\u2019s make one then! I absolutely love writing introductory material like this.",
  "id" : 221058217902477312,
  "in_reply_to_status_id" : 220997944227274753,
  "created_at" : "2012-07-06 01:49:20 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221002372443414530",
  "geo" : { },
  "id_str" : "221007638836682753",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh HERP DERP GRAPHICS BLEEGH OMGGERS",
  "id" : 221007638836682753,
  "in_reply_to_status_id" : 221002372443414530,
  "created_at" : "2012-07-05 22:28:21 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220878014467153920",
  "geo" : { },
  "id_str" : "220878160403775488",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek 'MURICA",
  "id" : 220878160403775488,
  "in_reply_to_status_id" : 220878014467153920,
  "created_at" : "2012-07-05 13:53:51 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/XmgL5edY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wVY7qDjrPZk",
      "display_url" : "youtube.com\/watch?v=wVY7qD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220707518811340800",
  "text" : "Current status: http:\/\/t.co\/XmgL5edY",
  "id" : 220707518811340800,
  "created_at" : "2012-07-05 02:35:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 0, 12 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220268862296440834",
  "geo" : { },
  "id_str" : "220588569453006848",
  "in_reply_to_user_id" : 6556972,
  "text" : "@techpickles congrats dude!",
  "id" : 220588569453006848,
  "in_reply_to_status_id" : 220268862296440834,
  "created_at" : "2012-07-04 18:43:07 +0000",
  "in_reply_to_screen_name" : "techpickles",
  "in_reply_to_user_id_str" : "6556972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/STtGhvor",
      "expanded_url" : "http:\/\/instagr.am\/p\/MqviPjM6tg\/",
      "display_url" : "instagr.am\/p\/MqviPjM6tg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "220574533428584448",
  "text" : "Geddy at 65 mph. http:\/\/t.co\/STtGhvor",
  "id" : 220574533428584448,
  "created_at" : "2012-07-04 17:47:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 74 ],
      "url" : "https:\/\/t.co\/IliHO2qj",
      "expanded_url" : "https:\/\/github.com\/qrush\/dotfiles\/blob\/master\/irbrc",
      "display_url" : "github.com\/qrush\/dotfiles\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "220497826650652673",
  "geo" : { },
  "id_str" : "220516894703222784",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr irb is the best. Make it even more awesome: https:\/\/t.co\/IliHO2qj",
  "id" : 220516894703222784,
  "in_reply_to_status_id" : 220497826650652673,
  "created_at" : "2012-07-04 13:58:19 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220391520510025728",
  "geo" : { },
  "id_str" : "220392006638256130",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft wooshcester",
  "id" : 220392006638256130,
  "in_reply_to_status_id" : 220391520510025728,
  "created_at" : "2012-07-04 05:42:03 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/NFmXF4kh",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_m6b3ilTcHm1r7n19no1_500.jpg",
      "display_url" : "25.media.tumblr.com\/tumblr_m6b3ilT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220387073880891393",
  "text" : "Current status: http:\/\/t.co\/NFmXF4kh",
  "id" : 220387073880891393,
  "created_at" : "2012-07-04 05:22:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 35, 49 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220372045719023618",
  "text" : "Crazy day. Biggest turnout yet for @coworkbuffalo, extremely productive hacking day, drove through a mad lightning storm to Ohio. Phew!",
  "id" : 220372045719023618,
  "created_at" : "2012-07-04 04:22:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Peruzzini",
      "screen_name" : "KeightP",
      "indices" : [ 0, 8 ],
      "id_str" : "18247553",
      "id" : 18247553
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 49, 56 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/CKi7GyaH",
      "expanded_url" : "http:\/\/dancroak.com\/post\/21920327049\/ship-it",
      "display_url" : "dancroak.com\/post\/219203270\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "220223687507456000",
  "geo" : { },
  "id_str" : "220228135973699584",
  "in_reply_to_user_id" : 18247553,
  "text" : "@KeightP he's got a hat on! and a cigar! i blame @Croaky for this. http:\/\/t.co\/CKi7GyaH",
  "id" : 220228135973699584,
  "in_reply_to_status_id" : 220223687507456000,
  "created_at" : "2012-07-03 18:50:53 +0000",
  "in_reply_to_screen_name" : "KeightP",
  "in_reply_to_user_id_str" : "18247553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "220222232956379138",
  "text" : "DJing in the CoworkBuffalo room. Now playing ^Graycat^ #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 220222232956379138,
  "created_at" : "2012-07-03 18:27:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Rieder",
      "screen_name" : "Overbryd",
      "indices" : [ 3, 12 ],
      "id_str" : "6696102",
      "id" : 6696102
    }, {
      "name" : "Steffen Leistner",
      "screen_name" : "sleistner",
      "indices" : [ 74, 84 ],
      "id_str" : "2947981",
      "id" : 2947981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/FEGYx3UX",
      "expanded_url" : "http:\/\/j.mp\/Ljb9If",
      "display_url" : "j.mp\/Ljb9If"
    } ]
  },
  "geo" : { },
  "id_str" : "220187792167276546",
  "text" : "RT @Overbryd: my impression of dubstep - YouTube http:\/\/t.co\/FEGYx3UX \/cc @sleistner",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steffen Leistner",
        "screen_name" : "sleistner",
        "indices" : [ 60, 70 ],
        "id_str" : "2947981",
        "id" : 2947981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/FEGYx3UX",
        "expanded_url" : "http:\/\/j.mp\/Ljb9If",
        "display_url" : "j.mp\/Ljb9If"
      } ]
    },
    "geo" : { },
    "id_str" : "220185670331809793",
    "text" : "my impression of dubstep - YouTube http:\/\/t.co\/FEGYx3UX \/cc @sleistner",
    "id" : 220185670331809793,
    "created_at" : "2012-07-03 16:02:09 +0000",
    "user" : {
      "name" : "Lukas Rieder",
      "screen_name" : "Overbryd",
      "protected" : false,
      "id_str" : "6696102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477771608988188672\/ZnZrUpB1_normal.jpeg",
      "id" : 6696102,
      "verified" : false
    }
  },
  "id" : 220187792167276546,
  "created_at" : "2012-07-03 16:10:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220163337902768129",
  "text" : "RT @coworkbuffalo: 10 folks coworking today. TOP SCORE!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220163279467720704",
    "text" : "10 folks coworking today. TOP SCORE!",
    "id" : 220163279467720704,
    "created_at" : "2012-07-03 14:33:10 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 220163337902768129,
  "created_at" : "2012-07-03 14:33:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/dVTqsXBH",
      "expanded_url" : "http:\/\/www.1871.com\/",
      "display_url" : "1871.com"
    } ]
  },
  "in_reply_to_status_id_str" : "219966477560840193",
  "geo" : { },
  "id_str" : "219966573622996992",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef http:\/\/t.co\/dVTqsXBH",
  "id" : 219966573622996992,
  "in_reply_to_status_id" : 219966477560840193,
  "created_at" : "2012-07-03 01:31:32 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219965089766313985",
  "geo" : { },
  "id_str" : "219966385999196160",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey \"foo[bar]\".scan(\/\\w+\/)",
  "id" : 219966385999196160,
  "in_reply_to_status_id" : 219965089766313985,
  "created_at" : "2012-07-03 01:30:47 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/SMotvalE",
      "expanded_url" : "http:\/\/pine.fm\/LearnToProgram\/",
      "display_url" : "pine.fm\/LearnToProgram\/"
    } ]
  },
  "geo" : { },
  "id_str" : "219921683857948672",
  "text" : "Nevermind! http:\/\/t.co\/SMotvalE is back.",
  "id" : 219921683857948672,
  "created_at" : "2012-07-02 22:33:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219921270211489793",
  "text" : "Anyone know how to bug Chris Pine? (Learn to Program) ? pine.fm is down.",
  "id" : 219921270211489793,
  "created_at" : "2012-07-02 22:31:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/IOz4HIRS",
      "expanded_url" : "https:\/\/twitter.com\/#!\/NeedADebitCard",
      "display_url" : "twitter.com\/#!\/NeedADebitC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219903018328522752",
  "text" : "And today in Exploiting Stupid People on The Internet: https:\/\/t.co\/IOz4HIRS",
  "id" : 219903018328522752,
  "created_at" : "2012-07-02 21:18:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/YqOMr2HM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SmnoM5yoUcw&list=UU_3JbOmL48TMal015yX13Iw&index=7&feature=plcp",
      "display_url" : "youtube.com\/watch?v=SmnoM5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219865099324755969",
  "text" : "Minecraft timelapses have gotten 10x crazier in past year since I've seen one. http:\/\/t.co\/YqOMr2HM",
  "id" : 219865099324755969,
  "created_at" : "2012-07-02 18:48:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/wWp1uu89",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=KBx4RGoB6XI&feature=fvwrel",
      "display_url" : "youtube.com\/watch?v=KBx4RG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219859611983945732",
  "text" : "Just a real life minecraft block. \"Not for sale\". Dude could make a killing. http:\/\/t.co\/wWp1uu89",
  "id" : 219859611983945732,
  "created_at" : "2012-07-02 18:26:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "219824700765908993",
  "text" : "DJing in the CoworkBuffalo room. Now playing Daft Beatles: Something about us comes together \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 219824700765908993,
  "created_at" : "2012-07-02 16:07:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 40, 54 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219821635698573312",
  "text" : "RT @coworkbuffalo: 7 people are down at @coworkbuffalo today! Mondays here are awesome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 21, 35 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219820647432462338",
    "text" : "7 people are down at @coworkbuffalo today! Mondays here are awesome.",
    "id" : 219820647432462338,
    "created_at" : "2012-07-02 15:51:41 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 219821635698573312,
  "created_at" : "2012-07-02 15:55:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/or9Jqwcl",
      "expanded_url" : "http:\/\/www.internetdeclaration.org\/freedom",
      "display_url" : "internetdeclaration.org\/freedom"
    } ]
  },
  "geo" : { },
  "id_str" : "219813037476036608",
  "text" : "I was going to take http:\/\/t.co\/or9Jqwcl seriously until it linked to Cheezburger.",
  "id" : 219813037476036608,
  "created_at" : "2012-07-02 15:21:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219650524876767232",
  "geo" : { },
  "id_str" : "219652209837740033",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi because most people don\u2019t even understand zip files.",
  "id" : 219652209837740033,
  "in_reply_to_status_id" : 219650524876767232,
  "created_at" : "2012-07-02 04:42:22 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219644655048994817",
  "geo" : { },
  "id_str" : "219646793317761024",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda impressive, yes",
  "id" : 219646793317761024,
  "in_reply_to_status_id" : 219644655048994817,
  "created_at" : "2012-07-02 04:20:51 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219610591747248128",
  "geo" : { },
  "id_str" : "219614286400589825",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs i still don't get the appeal of dribble. same with sites that let you comment\/critique \"chunks\" of code without context.",
  "id" : 219614286400589825,
  "in_reply_to_status_id" : 219610591747248128,
  "created_at" : "2012-07-02 02:11:40 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219535022263238656",
  "text" : "Instagram: 1 billion dollars earned, a new redesign slapped on, and still no way to list your photos on their site.",
  "id" : 219535022263238656,
  "created_at" : "2012-07-01 20:56:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 0, 10 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219530843025186818",
  "geo" : { },
  "id_str" : "219531010176581633",
  "in_reply_to_user_id" : 14182110,
  "text" : "@confreaks what happened to the rest of the railsconf videos? there's a lot of sessions missing",
  "id" : 219531010176581633,
  "in_reply_to_status_id" : 219530843025186818,
  "created_at" : "2012-07-01 20:40:46 +0000",
  "in_reply_to_screen_name" : "confreaks",
  "in_reply_to_user_id_str" : "14182110",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219448134856753152",
  "text" : "Cooking For Geeks is an awesome book. For any programmers like me who are to the point of fear and loathing of the kitchen: read it.",
  "id" : 219448134856753152,
  "created_at" : "2012-07-01 15:11:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
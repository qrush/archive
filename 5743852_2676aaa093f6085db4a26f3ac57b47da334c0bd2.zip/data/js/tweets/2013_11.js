Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406879123169374208",
  "geo" : { },
  "id_str" : "406903961439174656",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski I will invest. \uD83D\uDCB8",
  "id" : 406903961439174656,
  "in_reply_to_status_id" : 406879123169374208,
  "created_at" : "2013-11-30 21:53:58 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406829780726591488",
  "text" : "Bob's Burgers is hilarious.",
  "id" : 406829780726591488,
  "created_at" : "2013-11-30 16:59:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 3, 14 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/W8M1eQp53U",
      "expanded_url" : "http:\/\/i.imgur.com\/oPtXtas.jpg",
      "display_url" : "i.imgur.com\/oPtXtas.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "406768543305592832",
  "text" : "RT @nickelcity: Ehrhoff's through-a-skate OT goal last night on repeat. http:\/\/t.co\/W8M1eQp53U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/W8M1eQp53U",
        "expanded_url" : "http:\/\/i.imgur.com\/oPtXtas.jpg",
        "display_url" : "i.imgur.com\/oPtXtas.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "406767740888682496",
    "text" : "Ehrhoff's through-a-skate OT goal last night on repeat. http:\/\/t.co\/W8M1eQp53U",
    "id" : 406767740888682496,
    "created_at" : "2013-11-30 12:52:41 +0000",
    "user" : {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "protected" : false,
      "id_str" : "137891464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541312075570491395\/PrAOKda4_normal.jpeg",
      "id" : 137891464,
      "verified" : false
    }
  },
  "id" : 406768543305592832,
  "created_at" : "2013-11-30 12:55:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John V.",
      "screen_name" : "wettbutt",
      "indices" : [ 0, 9 ],
      "id_str" : "1736855654",
      "id" : 1736855654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406746785429073920",
  "geo" : { },
  "id_str" : "406764967430721536",
  "in_reply_to_user_id" : 1736855654,
  "text" : "@wettbutt whatchamacallit whenevers yous wanna sez \"all of the time now\"",
  "id" : 406764967430721536,
  "in_reply_to_status_id" : 406746785429073920,
  "created_at" : "2013-11-30 12:41:40 +0000",
  "in_reply_to_screen_name" : "wettbutt",
  "in_reply_to_user_id_str" : "1736855654",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 63, 73 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406681241618882560",
  "geo" : { },
  "id_str" : "406694801435013120",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove one of the best things to say to a screaming baby (@aquaranto said this the other day and I lost it)",
  "id" : 406694801435013120,
  "in_reply_to_status_id" : 406681241618882560,
  "created_at" : "2013-11-30 08:02:51 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Walsh",
      "screen_name" : "rwalsh06",
      "indices" : [ 0, 9 ],
      "id_str" : "179660537",
      "id" : 179660537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406503485425737728",
  "geo" : { },
  "id_str" : "406608570055008256",
  "in_reply_to_user_id" : 179660537,
  "text" : "@rwalsh06 it\u2019s not complicated\u2026based on a modulo of the user id. Pseudo: (avatar_id = user.id % number_of_avatars)",
  "id" : 406608570055008256,
  "in_reply_to_status_id" : 406503485425737728,
  "created_at" : "2013-11-30 02:20:12 +0000",
  "in_reply_to_screen_name" : "rwalsh06",
  "in_reply_to_user_id_str" : "179660537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406262917521485824",
  "geo" : { },
  "id_str" : "406263130138750976",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky yeah, it's a process. seems so extremely finicky at times, but when it works, it's gold.",
  "id" : 406263130138750976,
  "in_reply_to_status_id" : 406262917521485824,
  "created_at" : "2013-11-29 03:27:32 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406262462409736192",
  "text" : "...but it's terrible to have an essential photo that's unsavable. Out of focus, blurry, etc. Can't fix it all.",
  "id" : 406262462409736192,
  "created_at" : "2013-11-29 03:24:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406262276774051840",
  "text" : "It's great to have a \"saveable\" photo (overexposed) that can be corrected with a lot of tweaking...",
  "id" : 406262276774051840,
  "created_at" : "2013-11-29 03:24:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406261670726488064",
  "text" : "Every time I use Lightroom, I learn a little more. Editing photos is mostly about feeling in the moment.",
  "id" : 406261670726488064,
  "created_at" : "2013-11-29 03:21:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405914166172856320",
  "geo" : { },
  "id_str" : "405914310263586816",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 welcome back to loganberry land",
  "id" : 405914310263586816,
  "in_reply_to_status_id" : 405914166172856320,
  "created_at" : "2013-11-28 04:21:27 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Buddin",
      "screen_name" : "brettbuddin",
      "indices" : [ 0, 12 ],
      "id_str" : "7727232",
      "id" : 7727232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405906231011061760",
  "geo" : { },
  "id_str" : "405913901851615232",
  "in_reply_to_user_id" : 7727232,
  "text" : "@brettbuddin once it actually works i\u2019ll write about it :)",
  "id" : 405913901851615232,
  "in_reply_to_status_id" : 405906231011061760,
  "created_at" : "2013-11-28 04:19:50 +0000",
  "in_reply_to_screen_name" : "brettbuddin",
  "in_reply_to_user_id_str" : "7727232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Sagara",
      "screen_name" : "jonsagara",
      "indices" : [ 0, 10 ],
      "id_str" : "818766",
      "id" : 818766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405896456709484544",
  "geo" : { },
  "id_str" : "405897201605296129",
  "in_reply_to_user_id" : 818766,
  "text" : "@jonsagara SHHHHHH",
  "id" : 405897201605296129,
  "in_reply_to_status_id" : 405896456709484544,
  "created_at" : "2013-11-28 03:13:28 +0000",
  "in_reply_to_screen_name" : "jonsagara",
  "in_reply_to_user_id_str" : "818766",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405896924793827328",
  "text" : "Having never played with IFTTT or any kind of home automation stuff before today (the WeMo)...I am sold. I want everything automated.",
  "id" : 405896924793827328,
  "created_at" : "2013-11-28 03:12:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405895804210016256",
  "text" : "CCCCCOMBO!!!! Just got this working: SMS =&gt; Twilio =&gt; Heroku (via webhook) =&gt; Twilio =&gt; IFTTT =&gt; WeMo",
  "id" : 405895804210016256,
  "created_at" : "2013-11-28 03:07:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405766220181684224",
  "text" : "Alright, inverted aeropress is way better than whatever I was doing before. **eyes turn blue, all paths and futures become apparent**",
  "id" : 405766220181684224,
  "created_at" : "2013-11-27 18:33:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 10, 21 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 22, 28 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405416077049737216",
  "geo" : { },
  "id_str" : "405417538613280768",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage @samkottler @cmeik plenty of companies sponsor people to work on it\u2026I think that model works, would love to see more of it",
  "id" : 405417538613280768,
  "in_reply_to_status_id" : 405416077049737216,
  "created_at" : "2013-11-26 19:27:28 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 10, 21 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 22, 28 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/I907vMv2Ir",
      "expanded_url" : "http:\/\/RG.org",
      "display_url" : "RG.org"
    } ]
  },
  "in_reply_to_status_id_str" : "405415496260263936",
  "geo" : { },
  "id_str" : "405415655756660736",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage @samkottler @cmeik that's an entirely different model... Travis is a business, http:\/\/t.co\/I907vMv2Ir is not (and neither is NPM)",
  "id" : 405415655756660736,
  "in_reply_to_status_id" : 405415496260263936,
  "created_at" : "2013-11-26 19:19:59 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 10, 16 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 17, 28 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405413488866385920",
  "geo" : { },
  "id_str" : "405413855993425920",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage @cmeik @samkottler granted, we have problems too...but i'm not interested in working on OSS full-time.",
  "id" : 405413855993425920,
  "in_reply_to_status_id" : 405413488866385920,
  "created_at" : "2013-11-26 19:12:50 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 7, 18 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405411514867146753",
  "geo" : { },
  "id_str" : "405413030080442368",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik @samkottler \"Work had already begun to move the package tarballs out of CouchDB\" ...waaaaat",
  "id" : 405413030080442368,
  "in_reply_to_status_id" : 405411514867146753,
  "created_at" : "2013-11-26 19:09:33 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 9, 24 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405398206659309568",
  "geo" : { },
  "id_str" : "405398398796570624",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @gabrielgironda Canadian bacon.",
  "id" : 405398398796570624,
  "in_reply_to_status_id" : 405398206659309568,
  "created_at" : "2013-11-26 18:11:24 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 78, 89 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/w3TV2w6IWJ",
      "expanded_url" : "https:\/\/tonx.org\/frequency\/aeropress-video",
      "display_url" : "tonx.org\/frequency\/aero\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405368246679138304",
  "text" : "Whoa, inverted aeropress! I need to try this out. https:\/\/t.co\/w3TV2w6IWJ \/cc @kevinpurdy",
  "id" : 405368246679138304,
  "created_at" : "2013-11-26 16:11:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 11, 22 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/j4ZeL3NBkC",
      "expanded_url" : "http:\/\/thejesuitpost.org\/",
      "display_url" : "thejesuitpost.org"
    } ]
  },
  "in_reply_to_status_id_str" : "405365856630104064",
  "geo" : { },
  "id_str" : "405366222125928448",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy @ashedryden same, and I wish. Lots of nerdery here: http:\/\/t.co\/j4ZeL3NBkC",
  "id" : 405366222125928448,
  "in_reply_to_status_id" : 405365856630104064,
  "created_at" : "2013-11-26 16:03:33 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405361478040956929",
  "geo" : { },
  "id_str" : "405365220614619136",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden nope! Jesuits. \uD83D\uDE01",
  "id" : 405365220614619136,
  "in_reply_to_status_id" : 405361478040956929,
  "created_at" : "2013-11-26 15:59:34 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/4C99M8QxkZ",
      "expanded_url" : "http:\/\/www.catfactstexts.com\/",
      "display_url" : "catfactstexts.com"
    } ]
  },
  "in_reply_to_status_id_str" : "405199621485780992",
  "geo" : { },
  "id_str" : "405200396349882368",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d except for http:\/\/t.co\/4C99M8QxkZ",
  "id" : 405200396349882368,
  "in_reply_to_status_id" : 405199621485780992,
  "created_at" : "2013-11-26 05:04:37 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405188341940748289",
  "text" : "The PA job listing is disgusting but what\u2019s worse: they will get away with it. The gaming industry is the worst.",
  "id" : 405188341940748289,
  "created_at" : "2013-11-26 04:16:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 36, 47 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405180450118717442",
  "geo" : { },
  "id_str" : "405183333857886208",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant can you get a grant? Also @kevinpurdy has a pair.",
  "id" : 405183333857886208,
  "in_reply_to_status_id" : 405180450118717442,
  "created_at" : "2013-11-26 03:56:49 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/Bhx4STy2fV",
      "expanded_url" : "https:\/\/isitchristmas.com\/",
      "display_url" : "isitchristmas.com"
    } ]
  },
  "geo" : { },
  "id_str" : "405178319156416512",
  "text" : "Seen a few tree pictures go up. A reminder: https:\/\/t.co\/Bhx4STy2fV",
  "id" : 405178319156416512,
  "created_at" : "2013-11-26 03:36:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405170878364659712",
  "geo" : { },
  "id_str" : "405177220752089088",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs would kill for this with appliances.",
  "id" : 405177220752089088,
  "in_reply_to_status_id" : 405170878364659712,
  "created_at" : "2013-11-26 03:32:31 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405138065263697920",
  "geo" : { },
  "id_str" : "405140693560991744",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle we didn't use them for a few days...I have no idea why. They're just so friggin easy compared to a normal swaddling blanket.",
  "id" : 405140693560991744,
  "in_reply_to_status_id" : 405138065263697920,
  "created_at" : "2013-11-26 01:07:23 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405134507730534400",
  "geo" : { },
  "id_str" : "405137876196679680",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle things we've used most in order: boppy pillow, swaddleme sacks, wubbanubs. Get at least 3 SwaddleMe's.",
  "id" : 405137876196679680,
  "in_reply_to_status_id" : 405134507730534400,
  "created_at" : "2013-11-26 00:56:11 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 80, 86 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 91, 99 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/edeO9wuTjP",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Sz0o9clVQu8&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=Sz0o9c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405134822575579136",
  "text" : "Oh god, Millennials in the Workplace Training Video: http:\/\/t.co\/edeO9wuTjP via @jfine \/cc @fending",
  "id" : 405134822575579136,
  "created_at" : "2013-11-26 00:44:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Mendolera",
      "screen_name" : "mattmendo",
      "indices" : [ 0, 10 ],
      "id_str" : "6293582",
      "id" : 6293582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405002911408603138",
  "geo" : { },
  "id_str" : "405129836177281024",
  "in_reply_to_user_id" : 6293582,
  "text" : "@mattmendo welcome back! sorry I didn't get a chance to say hi.",
  "id" : 405129836177281024,
  "in_reply_to_status_id" : 405002911408603138,
  "created_at" : "2013-11-26 00:24:14 +0000",
  "in_reply_to_screen_name" : "mattmendo",
  "in_reply_to_user_id_str" : "6293582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "jrbar",
      "screen_name" : "jrbar",
      "indices" : [ 6, 12 ],
      "id_str" : "16320712",
      "id" : 16320712
    }, {
      "name" : "Stephanie Baran",
      "screen_name" : "StefB",
      "indices" : [ 13, 19 ],
      "id_str" : "16124377",
      "id" : 16124377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/cjJfSWYQvo",
      "expanded_url" : "http:\/\/www.theonion.com\/video\/the-onion-reviews-the-hunger-games-catching-fire,34637\/",
      "display_url" : "theonion.com\/video\/the-onio\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "405068910694629376",
  "geo" : { },
  "id_str" : "405070328176472064",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo @jrbar @StefB http:\/\/t.co\/cjJfSWYQvo",
  "id" : 405070328176472064,
  "in_reply_to_status_id" : 405068910694629376,
  "created_at" : "2013-11-25 20:27:46 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9208421127, -78.8804179456 ]
  },
  "id_str" : "405049465989365760",
  "text" : "Has anyone used home automation switches compatible with Bluetooth\/SMS\/wifi? I promise this isn\u2019t to control the baby.",
  "id" : 405049465989365760,
  "created_at" : "2013-11-25 19:04:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404813225469820928",
  "geo" : { },
  "id_str" : "404827975222566913",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt there\u2019s no respawn in real life!",
  "id" : 404827975222566913,
  "in_reply_to_status_id" : 404813225469820928,
  "created_at" : "2013-11-25 04:24:45 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404632135224410112",
  "geo" : { },
  "id_str" : "404635617981526017",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik you can see my house from there! \uD83D\uDE1B",
  "id" : 404635617981526017,
  "in_reply_to_status_id" : 404632135224410112,
  "created_at" : "2013-11-24 15:40:23 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/rVUrq6Zwec",
      "expanded_url" : "https:\/\/tonx.org\/3c31ff59",
      "display_url" : "tonx.org\/3c31ff59"
    } ]
  },
  "in_reply_to_status_id_str" : "404623488109248512",
  "geo" : { },
  "id_str" : "404625121672843264",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo ditch it. One of us\u2026 https:\/\/t.co\/rVUrq6Zwec",
  "id" : 404625121672843264,
  "in_reply_to_status_id" : 404623488109248512,
  "created_at" : "2013-11-24 14:58:41 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 8, 19 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 20, 26 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404511237167267840",
  "geo" : { },
  "id_str" : "404537980238299136",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @phillapier @cmeik what is a band without saxophones?",
  "id" : 404537980238299136,
  "in_reply_to_status_id" : 404511237167267840,
  "created_at" : "2013-11-24 09:12:25 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404503492955353088",
  "geo" : { },
  "id_str" : "404504284303491072",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal felt the same way after consuming the books. The environment was better than the characters.",
  "id" : 404504284303491072,
  "in_reply_to_status_id" : 404503492955353088,
  "created_at" : "2013-11-24 06:58:31 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 0, 10 ],
      "id_str" : "14437070",
      "id" : 14437070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404443509454692352",
  "geo" : { },
  "id_str" : "404448839035129856",
  "in_reply_to_user_id" : 14437070,
  "text" : "@marksands pretty sure you can\u2019t sync\/edit with two separate accounts, afaik",
  "id" : 404448839035129856,
  "in_reply_to_status_id" : 404443509454692352,
  "created_at" : "2013-11-24 03:18:12 +0000",
  "in_reply_to_screen_name" : "marksands",
  "in_reply_to_user_id_str" : "14437070",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404445989487902722",
  "text" : "Infinity Blade 2 crashed and with it my save data. \uD83D\uDE2C",
  "id" : 404445989487902722,
  "created_at" : "2013-11-24 03:06:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404379424134803456",
  "geo" : { },
  "id_str" : "404380010431008768",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja we've used Avocado for this...obviously not &gt; 2 people though.",
  "id" : 404380010431008768,
  "in_reply_to_status_id" : 404379424134803456,
  "created_at" : "2013-11-23 22:44:42 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404378504021958656",
  "geo" : { },
  "id_str" : "404379306198982658",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier yeah, I guess it's kind of the same setup. Need accounts, need to install an app :)",
  "id" : 404379306198982658,
  "in_reply_to_status_id" : 404378504021958656,
  "created_at" : "2013-11-23 22:41:54 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404374704930033664",
  "text" : "I still can't believe how that's not native\/built-in somehow. Had to sign up for a service and install an app. Weak.",
  "id" : 404374704930033664,
  "created_at" : "2013-11-23 22:23:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/QHKCnxl3Wp",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/11\/23\/sync-and-edit-files-on-two-iphones\/",
      "display_url" : "quaran.to\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404374592765968384",
  "text" : "Wrote up a quick post about how to sync and edit files on two iPhones: http:\/\/t.co\/QHKCnxl3Wp",
  "id" : 404374592765968384,
  "created_at" : "2013-11-23 22:23:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/weHmu6SLne",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=i6zaVYWLTkU&desktop_uri=%2Fwatch%3Fv%3Di6zaVYWLTkU",
      "display_url" : "m.youtube.com\/watch?v=i6zaVY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404275941020401664",
  "text" : "Current WNY status: http:\/\/t.co\/weHmu6SLne",
  "id" : 404275941020401664,
  "created_at" : "2013-11-23 15:51:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 0, 7 ],
      "id_str" : "7979212",
      "id" : 7979212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403951715822477312",
  "geo" : { },
  "id_str" : "403955018140614656",
  "in_reply_to_user_id" : 7979212,
  "text" : "@dankim yep, basically!",
  "id" : 403955018140614656,
  "in_reply_to_status_id" : 403951715822477312,
  "created_at" : "2013-11-22 18:35:56 +0000",
  "in_reply_to_screen_name" : "dankim",
  "in_reply_to_user_id_str" : "7979212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403947717019582464",
  "text" : "Didn\u2019t do a movie, but Wegmans trip for stuff and lunch sufficed. New normals.",
  "id" : 403947717019582464,
  "created_at" : "2013-11-22 18:06:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Alexandra Farrington",
      "screen_name" : "trampabroad",
      "indices" : [ 12, 24 ],
      "id_str" : "130199378",
      "id" : 130199378
    }, {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 80, 89 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403583853572661248",
  "geo" : { },
  "id_str" : "403760874873442304",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @trampabroad perhaps the best tag line of this site i\u2019ve heard. \/cc @ubuwaits",
  "id" : 403760874873442304,
  "in_reply_to_status_id" : 403583853572661248,
  "created_at" : "2013-11-22 05:44:28 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stefan",
      "screen_name" : "boring_as_heck",
      "indices" : [ 3, 18 ],
      "id_str" : "119000092",
      "id" : 119000092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403639692228165632",
  "text" : "RT @boring_as_heck: Jen's a rich doctor. Todd can't stop making record scratch noises. But they're both [record scratch] but- [record scrat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403597354487398400",
    "text" : "Jen's a rich doctor. Todd can't stop making record scratch noises. But they're both [record scratch] but- [record scratch] god damn it Todd.",
    "id" : 403597354487398400,
    "created_at" : "2013-11-21 18:54:42 +0000",
    "user" : {
      "name" : "stefan",
      "screen_name" : "boring_as_heck",
      "protected" : false,
      "id_str" : "119000092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570294836227518464\/xBxFBo-D_normal.jpeg",
      "id" : 119000092,
      "verified" : false
    }
  },
  "id" : 403639692228165632,
  "created_at" : "2013-11-21 21:42:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/WvVBcrgVIp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gAYL5H46QnQ",
      "display_url" : "youtube.com\/watch?v=gAYL5H\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403624650405470208",
  "geo" : { },
  "id_str" : "403627375570608128",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold basically http:\/\/t.co\/WvVBcrgVIp",
  "id" : 403627375570608128,
  "in_reply_to_status_id" : 403624650405470208,
  "created_at" : "2013-11-21 20:54:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Deckard",
      "screen_name" : "sethdeckard",
      "indices" : [ 0, 12 ],
      "id_str" : "16378611",
      "id" : 16378611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/yItuS8OqWY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zuQK6t2Esng",
      "display_url" : "youtube.com\/watch?v=zuQK6t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403625787267379200",
  "geo" : { },
  "id_str" : "403625933694722048",
  "in_reply_to_user_id" : 16378611,
  "text" : "@sethdeckard http:\/\/t.co\/yItuS8OqWY",
  "id" : 403625933694722048,
  "in_reply_to_status_id" : 403625787267379200,
  "created_at" : "2013-11-21 20:48:16 +0000",
  "in_reply_to_screen_name" : "sethdeckard",
  "in_reply_to_user_id_str" : "16378611",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "j\u0309\u030C\u0309\u1ECF\u0355\u0309h\u033B\u0355\u0309\u0309\u0309\u0309\u031An\u0316\u0309\u0309",
      "screen_name" : "jrecursive",
      "indices" : [ 3, 14 ],
      "id_str" : "13002342",
      "id" : 13002342
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jrecursive\/status\/403624496684216320\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/09VBqBQJuE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZn2V0oCEAABQke.png",
      "id_str" : "403624496390606848",
      "id" : 403624496390606848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZn2V0oCEAABQke.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 947
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 947
      } ],
      "display_url" : "pic.twitter.com\/09VBqBQJuE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403625519440482304",
  "text" : "RT @jrecursive: great advertising http:\/\/t.co\/09VBqBQJuE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jrecursive\/status\/403624496684216320\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/09VBqBQJuE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZn2V0oCEAABQke.png",
        "id_str" : "403624496390606848",
        "id" : 403624496390606848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZn2V0oCEAABQke.png",
        "sizes" : [ {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 947
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 947
        } ],
        "display_url" : "pic.twitter.com\/09VBqBQJuE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403624496684216320",
    "text" : "great advertising http:\/\/t.co\/09VBqBQJuE",
    "id" : 403624496684216320,
    "created_at" : "2013-11-21 20:42:33 +0000",
    "user" : {
      "name" : "j\u0309\u030C\u0309\u1ECF\u0355\u0309h\u033B\u0355\u0309\u0309\u0309\u0309\u031An\u0316\u0309\u0309",
      "screen_name" : "jrecursive",
      "protected" : false,
      "id_str" : "13002342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458990518160998401\/Tgo-kZwI_normal.png",
      "id" : 13002342,
      "verified" : false
    }
  },
  "id" : 403625519440482304,
  "created_at" : "2013-11-21 20:46:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 91, 97 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403624363179536384",
  "geo" : { },
  "id_str" : "403625344235606016",
  "in_reply_to_user_id" : 896641,
  "text" : "@JZ great to hear. definitely just dynamic enough. hoping it continues to stay simple. \/cc @parkr",
  "id" : 403625344235606016,
  "in_reply_to_status_id" : 403624363179536384,
  "created_at" : "2013-11-21 20:45:55 +0000",
  "in_reply_to_screen_name" : "jasonzimdars",
  "in_reply_to_user_id_str" : "896641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 0, 14 ],
      "id_str" : "14457987",
      "id" : 14457987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ewWoRLXvVz",
      "expanded_url" : "http:\/\/guides.rubyonrails.org\/getting_started.html",
      "display_url" : "guides.rubyonrails.org\/getting_starte\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403624672560156672",
  "geo" : { },
  "id_str" : "403625100320059392",
  "in_reply_to_user_id" : 14457987,
  "text" : "@nerdofthunder awesome. I refer to the guides site constantly. This one is good. http:\/\/t.co\/ewWoRLXvVz",
  "id" : 403625100320059392,
  "in_reply_to_status_id" : 403624672560156672,
  "created_at" : "2013-11-21 20:44:57 +0000",
  "in_reply_to_screen_name" : "nerdofthunder",
  "in_reply_to_user_id_str" : "14457987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403622625723056128",
  "geo" : { },
  "id_str" : "403622850554130432",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski Genius! We're gonna be in the pictures!",
  "id" : 403622850554130432,
  "in_reply_to_status_id" : 403622625723056128,
  "created_at" : "2013-11-21 20:36:01 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jekyll",
      "screen_name" : "jekyllrb",
      "indices" : [ 73, 82 ],
      "id_str" : "1143789606",
      "id" : 1143789606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/54xmkNozqU",
      "expanded_url" : "https:\/\/www.ruby-lang.org",
      "display_url" : "ruby-lang.org"
    } ]
  },
  "geo" : { },
  "id_str" : "403621828603559936",
  "text" : "Very happy about https:\/\/t.co\/54xmkNozqU. Re-designed by @jz, running on @jekyllrb. BOOM!",
  "id" : 403621828603559936,
  "created_at" : "2013-11-21 20:31:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3055\u308A",
      "screen_name" : "hiro_asari",
      "indices" : [ 0, 11 ],
      "id_str" : "14284130",
      "id" : 14284130
    }, {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 12, 25 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403517331986345985",
  "geo" : { },
  "id_str" : "403621651205476352",
  "in_reply_to_user_id" : 14284130,
  "text" : "@hiro_asari @olivierlacan @JZ WOOT!!",
  "id" : 403621651205476352,
  "in_reply_to_status_id" : 403517331986345985,
  "created_at" : "2013-11-21 20:31:15 +0000",
  "in_reply_to_screen_name" : "hiro_asari",
  "in_reply_to_user_id_str" : "14284130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403620971380477952",
  "geo" : { },
  "id_str" : "403621413015150594",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden it's awful.",
  "id" : 403621413015150594,
  "in_reply_to_status_id" : 403620971380477952,
  "created_at" : "2013-11-21 20:30:18 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403617612346970113",
  "geo" : { },
  "id_str" : "403619448466067456",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella see replies, there are special mom\/baby times at some theaters. Otherwise probably need to go to a very old show way off hours.",
  "id" : 403619448466067456,
  "in_reply_to_status_id" : 403617612346970113,
  "created_at" : "2013-11-21 20:22:30 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 92, 100 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403617708270313472",
  "geo" : { },
  "id_str" : "403617846757826560",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz yeah going to call around to see when this is. had a feeling it might be a thing \/cc @mperham",
  "id" : 403617846757826560,
  "in_reply_to_status_id" : 403617708270313472,
  "created_at" : "2013-11-21 20:16:08 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 7, 14 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 15, 21 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/PI555izBUw",
      "expanded_url" : "http:\/\/www.chem.purdue.edu\/chemsafety\/training\/ppetrain\/dblevels.htm",
      "display_url" : "chem.purdue.edu\/chemsafety\/tra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403616915651710976",
  "geo" : { },
  "id_str" : "403617435237883905",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @nathos @chorn That seems a little high: http:\/\/t.co\/PI555izBUw",
  "id" : 403617435237883905,
  "in_reply_to_status_id" : 403616915651710976,
  "created_at" : "2013-11-21 20:14:30 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403616910085861376",
  "text" : "OK so, movie seems like a dumb idea. Maybe in a few months, with some ear protection. Babbies.",
  "id" : 403616910085861376,
  "created_at" : "2013-11-21 20:12:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 7, 14 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 15, 21 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403615307832377344",
  "geo" : { },
  "id_str" : "403616629583405056",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @nathos @chorn Ear. EAR.",
  "id" : 403616629583405056,
  "in_reply_to_status_id" : 403615307832377344,
  "created_at" : "2013-11-21 20:11:17 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 7, 14 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 15, 21 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403615307832377344",
  "geo" : { },
  "id_str" : "403616601217331200",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @nathos @chorn ahhhh good point. Curses! Need some eat protection.",
  "id" : 403616601217331200,
  "in_reply_to_status_id" : 403615307832377344,
  "created_at" : "2013-11-21 20:11:11 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Ordonez",
      "screen_name" : "tomordonez",
      "indices" : [ 0, 11 ],
      "id_str" : "253121529",
      "id" : 253121529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403615387930996736",
  "geo" : { },
  "id_str" : "403616503083171840",
  "in_reply_to_user_id" : 253121529,
  "text" : "@tomordonez lol. in the morning though!? (I am too tired for hacker references)",
  "id" : 403616503083171840,
  "in_reply_to_status_id" : 403615387930996736,
  "created_at" : "2013-11-21 20:10:47 +0000",
  "in_reply_to_screen_name" : "tomordonez",
  "in_reply_to_user_id_str" : "253121529",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/IVgTflPM1w",
      "expanded_url" : "http:\/\/orlyowl.tripod.com\/sitebuildercontent\/sitebuilderpictures\/orly.jpg",
      "display_url" : "orlyowl.tripod.com\/sitebuildercon\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403613478659031040",
  "geo" : { },
  "id_str" : "403614803387633665",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos http:\/\/t.co\/IVgTflPM1w",
  "id" : 403614803387633665,
  "in_reply_to_status_id" : 403613478659031040,
  "created_at" : "2013-11-21 20:04:02 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Roes",
      "screen_name" : "jroes",
      "indices" : [ 0, 6 ],
      "id_str" : "1431461",
      "id" : 1431461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403613568899481600",
  "geo" : { },
  "id_str" : "403614747041353728",
  "in_reply_to_user_id" : 1431461,
  "text" : "@jroes thanks! ~1.5...so kind of nervous about it.",
  "id" : 403614747041353728,
  "in_reply_to_status_id" : 403613568899481600,
  "created_at" : "2013-11-21 20:03:49 +0000",
  "in_reply_to_screen_name" : "jroes",
  "in_reply_to_user_id_str" : "1431461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403613144506847232",
  "text" : "Considering bringing a newborn to a 11AM movie tomorrow. Pretty sure I've never seen a show before noon. Anyone else crazy enough to try it?",
  "id" : 403613144506847232,
  "created_at" : "2013-11-21 19:57:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pat tobin",
      "screen_name" : "tastefactory",
      "indices" : [ 3, 16 ],
      "id_str" : "138102228",
      "id" : 138102228
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tastefactory\/status\/344541250222956546\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/1yVXZ3vAaO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMgOcQ5CIAAzOzT.png",
      "id_str" : "344541250227150848",
      "id" : 344541250227150848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMgOcQ5CIAAzOzT.png",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1yVXZ3vAaO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403588328034803712",
  "text" : "RT @tastefactory: \"Rear-End\" was sick on the day they made this commercial. http:\/\/t.co\/1yVXZ3vAaO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tastefactory\/status\/344541250222956546\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/1yVXZ3vAaO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMgOcQ5CIAAzOzT.png",
        "id_str" : "344541250227150848",
        "id" : 344541250227150848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMgOcQ5CIAAzOzT.png",
        "sizes" : [ {
          "h" : 485,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1yVXZ3vAaO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344541250222956546",
    "text" : "\"Rear-End\" was sick on the day they made this commercial. http:\/\/t.co\/1yVXZ3vAaO",
    "id" : 344541250222956546,
    "created_at" : "2013-06-11 19:46:50 +0000",
    "user" : {
      "name" : "pat tobin",
      "screen_name" : "tastefactory",
      "protected" : false,
      "id_str" : "138102228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000827073872\/035905b3107bc08410b6b628ffe94240_normal.jpeg",
      "id" : 138102228,
      "verified" : false
    }
  },
  "id" : 403588328034803712,
  "created_at" : "2013-11-21 18:18:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403360466203725824",
  "geo" : { },
  "id_str" : "403361054945574913",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety \uD83D\uDC4D",
  "id" : 403361054945574913,
  "in_reply_to_status_id" : 403360466203725824,
  "created_at" : "2013-11-21 03:15:44 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rickcolosimo",
      "screen_name" : "rickcolosimo",
      "indices" : [ 0, 13 ],
      "id_str" : "14404925",
      "id" : 14404925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403342230678552576",
  "geo" : { },
  "id_str" : "403349521171623937",
  "in_reply_to_user_id" : 14404925,
  "text" : "@rickcolosimo I really hope not for BUF. I wonder if you can opt out of it.",
  "id" : 403349521171623937,
  "in_reply_to_status_id" : 403342230678552576,
  "created_at" : "2013-11-21 02:29:54 +0000",
  "in_reply_to_screen_name" : "rickcolosimo",
  "in_reply_to_user_id_str" : "14404925",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 10, 15 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403295470190997504",
  "geo" : { },
  "id_str" : "403295921368092672",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 @r00k as someone who still refuses to go through the machines...I doubt they ever will.",
  "id" : 403295921368092672,
  "in_reply_to_status_id" : 403295470190997504,
  "created_at" : "2013-11-20 22:56:55 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ag7yOBt11c",
      "expanded_url" : "http:\/\/www.nbcnews.com\/video\/nightly-news\/53594630",
      "display_url" : "nbcnews.com\/video\/nightly-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403292097496633344",
  "text" : "At some point I'm probably just going to stop flying: http:\/\/t.co\/ag7yOBt11c",
  "id" : 403292097496633344,
  "created_at" : "2013-11-20 22:41:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/1HmupWG52f",
      "expanded_url" : "http:\/\/www.winamp.com\/media-player\/en",
      "display_url" : "winamp.com\/media-player\/en"
    } ]
  },
  "geo" : { },
  "id_str" : "403241765613735936",
  "text" : "End of an era, Winamp is shutting down. I remember skinning it back in the day... http:\/\/t.co\/1HmupWG52f",
  "id" : 403241765613735936,
  "created_at" : "2013-11-20 19:21:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/9WfQel7XHL",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QaoyLogqql",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/alltechconsidered\/2013\/11\/19\/246132770\/this-slide-shows-why-healthcare-gov-wouldnt-work-at-launch",
      "display_url" : "npr.org\/blogs\/alltechc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403240872214396928",
  "text" : "RT @kevinpurdy: Auditors knew (last spring) http:\/\/t.co\/9WfQel7XHL had a deeply flawed spec\/design\/build\/test flow. It was charted. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/9WfQel7XHL",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      }, {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/QaoyLogqql",
        "expanded_url" : "http:\/\/www.npr.org\/blogs\/alltechconsidered\/2013\/11\/19\/246132770\/this-slide-shows-why-healthcare-gov-wouldnt-work-at-launch",
        "display_url" : "npr.org\/blogs\/alltechc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403240410102763520",
    "text" : "Auditors knew (last spring) http:\/\/t.co\/9WfQel7XHL had a deeply flawed spec\/design\/build\/test flow. It was charted. http:\/\/t.co\/QaoyLogqql",
    "id" : 403240410102763520,
    "created_at" : "2013-11-20 19:16:20 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 403240872214396928,
  "created_at" : "2013-11-20 19:18:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 21, 33 ],
      "id_str" : "140515765",
      "id" : 140515765
    }, {
      "name" : "Bishnu Prasad Adhika",
      "screen_name" : "BishnuPrasadAd2",
      "indices" : [ 42, 58 ],
      "id_str" : "1964501216",
      "id" : 1964501216
    }, {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 62, 67 ],
      "id_str" : "20612109",
      "id" : 20612109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/tl35ncKTdf",
      "expanded_url" : "http:\/\/news.wbfo.org\/post\/refugees-revitalize-rust-belt-city-buffalo",
      "display_url" : "news.wbfo.org\/post\/refugees-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403117265539067904",
  "text" : "RT @kevinpurdy: Hey! @TEDxBuffalo speaker @BishnuPrasadAd2 on @WBFO this morning, talking about accepting and training refugees: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxBuffalo",
        "screen_name" : "TEDxBuffalo",
        "indices" : [ 5, 17 ],
        "id_str" : "140515765",
        "id" : 140515765
      }, {
        "name" : "Bishnu Prasad Adhika",
        "screen_name" : "BishnuPrasadAd2",
        "indices" : [ 26, 42 ],
        "id_str" : "1964501216",
        "id" : 1964501216
      }, {
        "name" : "WBFO",
        "screen_name" : "WBFO",
        "indices" : [ 46, 51 ],
        "id_str" : "20612109",
        "id" : 20612109
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/tl35ncKTdf",
        "expanded_url" : "http:\/\/news.wbfo.org\/post\/refugees-revitalize-rust-belt-city-buffalo",
        "display_url" : "news.wbfo.org\/post\/refugees-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403117132549857280",
    "text" : "Hey! @TEDxBuffalo speaker @BishnuPrasadAd2 on @WBFO this morning, talking about accepting and training refugees: http:\/\/t.co\/tl35ncKTdf",
    "id" : 403117132549857280,
    "created_at" : "2013-11-20 11:06:28 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 403117265539067904,
  "created_at" : "2013-11-20 11:07:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie",
      "screen_name" : "ntljk",
      "indices" : [ 0, 6 ],
      "id_str" : "21778760",
      "id" : 21778760
    }, {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 7, 21 ],
      "id_str" : "679103",
      "id" : 679103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403109083047149569",
  "geo" : { },
  "id_str" : "403116521339121664",
  "in_reply_to_user_id" : 21778760,
  "text" : "@ntljk @travisjeffery avoiding malls in general on BF is good enough (and at all times) if only the Apple Store wasn\u2019t there\u2026",
  "id" : 403116521339121664,
  "in_reply_to_status_id" : 403109083047149569,
  "created_at" : "2013-11-20 11:04:02 +0000",
  "in_reply_to_screen_name" : "ntljk",
  "in_reply_to_user_id_str" : "21778760",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402987365066473473",
  "geo" : { },
  "id_str" : "402988885040308224",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein we're well beyond kicking",
  "id" : 402988885040308224,
  "in_reply_to_status_id" : 402987365066473473,
  "created_at" : "2013-11-20 02:36:52 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402988023391846401",
  "geo" : { },
  "id_str" : "402988362237091840",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic HELLO. I AM AUSTRALIAN PRINCE. I RECEIVED GIFT OF ONE MILLION USD THAT I WILL SEND TO YOU. PLEASE HAND OVER VISA AND FIRSTBORN.",
  "id" : 402988362237091840,
  "in_reply_to_status_id" : 402988023391846401,
  "created_at" : "2013-11-20 02:34:47 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402979073552830464",
  "geo" : { },
  "id_str" : "402986445511475201",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair thanks!",
  "id" : 402986445511475201,
  "in_reply_to_status_id" : 402979073552830464,
  "created_at" : "2013-11-20 02:27:10 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 18, 32 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402984251177852928",
  "geo" : { },
  "id_str" : "402986381963579393",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 oh god :( @dragonladyB17 hope you get better soon!",
  "id" : 402986381963579393,
  "in_reply_to_status_id" : 402984251177852928,
  "created_at" : "2013-11-20 02:26:55 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 3, 10 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/XUOiUiVhLg",
      "expanded_url" : "https:\/\/www.heroku.com\/1",
      "display_url" : "heroku.com\/1"
    } ]
  },
  "geo" : { },
  "id_str" : "402983238508896256",
  "text" : "RT @soffes: You can tell this is for Salesforce since after reading the product page, I have no idea what it actually does https:\/\/t.co\/XUO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/XUOiUiVhLg",
        "expanded_url" : "https:\/\/www.heroku.com\/1",
        "display_url" : "heroku.com\/1"
      } ]
    },
    "geo" : { },
    "id_str" : "402983097764835328",
    "text" : "You can tell this is for Salesforce since after reading the product page, I have no idea what it actually does https:\/\/t.co\/XUOiUiVhLg",
    "id" : 402983097764835328,
    "created_at" : "2013-11-20 02:13:52 +0000",
    "user" : {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "protected" : false,
      "id_str" : "6154602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545995221914230785\/N9a6vr0W_normal.jpeg",
      "id" : 6154602,
      "verified" : false
    }
  },
  "id" : 402983238508896256,
  "created_at" : "2013-11-20 02:14:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402978792609550336",
  "text" : "Pretty sure I saw a rocket launch into SPACE with my one week old tonight. \uD83D\uDE80\uD83D\uDC4D",
  "id" : 402978792609550336,
  "created_at" : "2013-11-20 01:56:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hussey",
      "screen_name" : "seanhussey",
      "indices" : [ 0, 11 ],
      "id_str" : "14685595",
      "id" : 14685595
    }, {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 12, 25 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402975313036320768",
  "geo" : { },
  "id_str" : "402978379957161984",
  "in_reply_to_user_id" : 14685595,
  "text" : "@seanhussey @stevenhaddox wooot!",
  "id" : 402978379957161984,
  "in_reply_to_status_id" : 402975313036320768,
  "created_at" : "2013-11-20 01:55:07 +0000",
  "in_reply_to_screen_name" : "seanhussey",
  "in_reply_to_user_id_str" : "14685595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hussey",
      "screen_name" : "seanhussey",
      "indices" : [ 0, 11 ],
      "id_str" : "14685595",
      "id" : 14685595
    }, {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 12, 25 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402973624640217088",
  "geo" : { },
  "id_str" : "402973907482714112",
  "in_reply_to_user_id" : 14685595,
  "text" : "@seanhussey @stevenhaddox Didn't blink. Not that high...I am terrible with angles, so maybe 20-30\u00BA SE ?",
  "id" : 402973907482714112,
  "in_reply_to_status_id" : 402973624640217088,
  "created_at" : "2013-11-20 01:37:21 +0000",
  "in_reply_to_screen_name" : "seanhussey",
  "in_reply_to_user_id_str" : "14685595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    }, {
      "name" : "Sean Hussey",
      "screen_name" : "seanhussey",
      "indices" : [ 14, 25 ],
      "id_str" : "14685595",
      "id" : 14685595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402972877089021952",
  "text" : "@stevenhaddox @seanhussey I think so, but not sure. Pinprick of light appeared and faded. Could have been a plane? :(",
  "id" : 402972877089021952,
  "created_at" : "2013-11-20 01:33:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/XlMeq8eHQ8",
      "expanded_url" : "http:\/\/www.nasa.gov\/sites\/default\/files\/files\/ORS3_Visibility_111213_v2.jpg",
      "display_url" : "nasa.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402965495306940417",
  "text" : "Launch at 8:15! I really hope to see this launch: http:\/\/t.co\/XlMeq8eHQ8",
  "id" : 402965495306940417,
  "created_at" : "2013-11-20 01:03:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Wallops",
      "screen_name" : "NASA_Wallops",
      "indices" : [ 3, 16 ],
      "id_str" : "30258963",
      "id" : 30258963
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ORS3",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ZyVvDKuSIa",
      "expanded_url" : "http:\/\/www.nasa.gov\/sites\/default\/files\/files\/ORS3_Visibility_111213_v2.jpg",
      "display_url" : "nasa.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402958015487152129",
  "text" : "RT @NASA_Wallops: East Coast:  Eyes in the skies next week! #ORS3 launch visible up and down the coast! http:\/\/t.co\/ZyVvDKuSIa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ORS3",
        "indices" : [ 42, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/ZyVvDKuSIa",
        "expanded_url" : "http:\/\/www.nasa.gov\/sites\/default\/files\/files\/ORS3_Visibility_111213_v2.jpg",
        "display_url" : "nasa.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400717567955726336",
    "text" : "East Coast:  Eyes in the skies next week! #ORS3 launch visible up and down the coast! http:\/\/t.co\/ZyVvDKuSIa",
    "id" : 400717567955726336,
    "created_at" : "2013-11-13 20:11:27 +0000",
    "user" : {
      "name" : "NASA Wallops",
      "screen_name" : "NASA_Wallops",
      "protected" : false,
      "id_str" : "30258963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487332108566667265\/WCxO5Buj_normal.jpeg",
      "id" : 30258963,
      "verified" : true
    }
  },
  "id" : 402958015487152129,
  "created_at" : "2013-11-20 00:34:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Wallops",
      "screen_name" : "NASA_Wallops",
      "indices" : [ 3, 16 ],
      "id_str" : "30258963",
      "id" : 30258963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/g4eRdL8Xlw",
      "expanded_url" : "http:\/\/www.nasa.gov\/nasatv",
      "display_url" : "nasa.gov\/nasatv"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/lKpnPiC8Ws",
      "expanded_url" : "http:\/\/www.ustream.tv\/channel\/nasa-tv-wallops",
      "display_url" : "ustream.tv\/channel\/nasa-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402957357098860544",
  "text" : "RT @NASA_Wallops: Wallops rocket launch 7:30 p.m today. Live coverage begins 6:30 p.m. EST at http:\/\/t.co\/g4eRdL8Xlw or http:\/\/t.co\/lKpnPiC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/g4eRdL8Xlw",
        "expanded_url" : "http:\/\/www.nasa.gov\/nasatv",
        "display_url" : "nasa.gov\/nasatv"
      }, {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/lKpnPiC8Ws",
        "expanded_url" : "http:\/\/www.ustream.tv\/channel\/nasa-tv-wallops",
        "display_url" : "ustream.tv\/channel\/nasa-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402878607246127104",
    "text" : "Wallops rocket launch 7:30 p.m today. Live coverage begins 6:30 p.m. EST at http:\/\/t.co\/g4eRdL8Xlw or http:\/\/t.co\/lKpnPiC8Ws",
    "id" : 402878607246127104,
    "created_at" : "2013-11-19 19:18:39 +0000",
    "user" : {
      "name" : "NASA Wallops",
      "screen_name" : "NASA_Wallops",
      "protected" : false,
      "id_str" : "30258963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487332108566667265\/WCxO5Buj_normal.jpeg",
      "id" : 30258963,
      "verified" : true
    }
  },
  "id" : 402957357098860544,
  "created_at" : "2013-11-20 00:31:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    }, {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 11, 20 ],
      "id_str" : "787975",
      "id" : 787975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402904604536365056",
  "geo" : { },
  "id_str" : "402909486953664512",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy @mathiasx oh god, haven\u2019t used rdio in forever.",
  "id" : 402909486953664512,
  "in_reply_to_status_id" : 402904604536365056,
  "created_at" : "2013-11-19 21:21:22 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 40, 49 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 62, 76 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/EBA1kklDDs",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/12501",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402878943516446721",
  "text" : "RT @zobar2: Oh hey, tonight is the last @openhack at \"the old @coworkbuffalo\" - RSVP at http:\/\/t.co\/EBA1kklDDs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 28, 37 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 50, 64 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/EBA1kklDDs",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/12501",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402878829879771136",
    "text" : "Oh hey, tonight is the last @openhack at \"the old @coworkbuffalo\" - RSVP at http:\/\/t.co\/EBA1kklDDs",
    "id" : 402878829879771136,
    "created_at" : "2013-11-19 19:19:32 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 402878943516446721,
  "created_at" : "2013-11-19 19:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402846234840285184",
  "text" : "Moby wrap: fantastic for getting things done, until there\u2019s a smelly baby strapped to you.",
  "id" : 402846234840285184,
  "created_at" : "2013-11-19 17:10:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 0, 7 ],
      "id_str" : "7979212",
      "id" : 7979212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402423575564410880",
  "geo" : { },
  "id_str" : "402424021037248513",
  "in_reply_to_user_id" : 7979212,
  "text" : "@dankim I\u2019ll wait for the kid to do this",
  "id" : 402424021037248513,
  "in_reply_to_status_id" : 402423575564410880,
  "created_at" : "2013-11-18 13:12:17 +0000",
  "in_reply_to_screen_name" : "dankim",
  "in_reply_to_user_id_str" : "7979212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 43, 58 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/402399513576370176\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/v8seTKtfKV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZWcObTCUAAAh2i.jpg",
      "id_str" : "402399513379229696",
      "id" : 402399513379229696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZWcObTCUAAAh2i.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1397,
        "resize" : "fit",
        "w" : 1975
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/v8seTKtfKV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402408644223840256",
  "text" : "What a pathetic way to treat your readers, @TheBuffaloNews. Ads don\u2019t need to be this ugly or intrusive. http:\/\/t.co\/v8seTKtfKV",
  "id" : 402408644223840256,
  "created_at" : "2013-11-18 12:11:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402284088683679744",
  "text" : "Burp &amp; Destroy",
  "id" : 402284088683679744,
  "created_at" : "2013-11-18 03:56:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402283911536848897",
  "text" : "Nothing Else Burps",
  "id" : 402283911536848897,
  "created_at" : "2013-11-18 03:55:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Darby",
      "screen_name" : "mattdarby",
      "indices" : [ 3, 13 ],
      "id_str" : "13251052",
      "id" : 13251052
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402283850581045248",
  "text" : "RT @mattdarby: @qrush Master of Burps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "402283515942682625",
    "geo" : { },
    "id_str" : "402283716879585281",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Master of Burps",
    "id" : 402283716879585281,
    "in_reply_to_status_id" : 402283515942682625,
    "created_at" : "2013-11-18 03:54:46 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Matt Darby",
      "screen_name" : "mattdarby",
      "protected" : false,
      "id_str" : "13251052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565674394685431808\/gQYygcKt_normal.jpeg",
      "id" : 13251052,
      "verified" : false
    }
  },
  "id" : 402283850581045248,
  "created_at" : "2013-11-18 03:55:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402283515942682625",
  "text" : "Enter Burpman",
  "id" : 402283515942682625,
  "created_at" : "2013-11-18 03:53:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402283457537003521",
  "text" : "For Whom The Burp Tolls",
  "id" : 402283457537003521,
  "created_at" : "2013-11-18 03:53:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402276769509949440",
  "geo" : { },
  "id_str" : "402278045110640641",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws I have basically done this in Dwarf Fortress.",
  "id" : 402278045110640641,
  "in_reply_to_status_id" : 402276769509949440,
  "created_at" : "2013-11-18 03:32:14 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/9TgGuf3auG",
      "expanded_url" : "http:\/\/www.bay12forums.com\/smf\/index.php?topic=104261.0",
      "display_url" : "bay12forums.com\/smf\/index.php?\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "402263462099038209",
  "geo" : { },
  "id_str" : "402264233808633856",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda it's boggling to watch, so I use a tileset: http:\/\/t.co\/9TgGuf3auG NetHack is somewhat less complicated but still Matrixy :)",
  "id" : 402264233808633856,
  "in_reply_to_status_id" : 402263462099038209,
  "created_at" : "2013-11-18 02:37:21 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Yxp80LimHx",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/f8e281b1a5758e53a09e80ca1796a0e7\/tumblr_mvsgszPiPr1qgehn7o1_500.png",
      "display_url" : "24.media.tumblr.com\/f8e281b1a5758e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402261845555171328",
  "text" : "Playing Dwarf Fortress: http:\/\/t.co\/Yxp80LimHx",
  "id" : 402261845555171328,
  "created_at" : "2013-11-18 02:27:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "402177217310240770",
  "geo" : { },
  "id_str" : "402241031497719808",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr it's not supported yet via metadata...it's pretty new. you have to edit those links on http:\/\/t.co\/2bA9BVLhWr. we could start though!",
  "id" : 402241031497719808,
  "in_reply_to_status_id" : 402177217310240770,
  "created_at" : "2013-11-18 01:05:09 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402168451751358464",
  "geo" : { },
  "id_str" : "402169198241009664",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft got one of these yesterday. They pointed out the QR code on the back.",
  "id" : 402169198241009664,
  "in_reply_to_status_id" : 402168451751358464,
  "created_at" : "2013-11-17 20:19:43 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402095234080727040",
  "geo" : { },
  "id_str" : "402095305241686017",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss daaaaang",
  "id" : 402095305241686017,
  "in_reply_to_status_id" : 402095234080727040,
  "created_at" : "2013-11-17 15:26:05 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streeting",
      "screen_name" : "stevestreeting",
      "indices" : [ 0, 15 ],
      "id_str" : "138065190",
      "id" : 138065190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402093111431528448",
  "geo" : { },
  "id_str" : "402093870084673536",
  "in_reply_to_user_id" : 138065190,
  "text" : "@stevestreeting definitely my favorite. Adds some risk to completing features (and nulling out opponents\u2019)",
  "id" : 402093870084673536,
  "in_reply_to_status_id" : 402093111431528448,
  "created_at" : "2013-11-17 15:20:23 +0000",
  "in_reply_to_screen_name" : "stevestreeting",
  "in_reply_to_user_id_str" : "138065190",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/WlIOkljFn3",
      "expanded_url" : "http:\/\/mattnt.files.wordpress.com\/2011\/12\/cray.png",
      "display_url" : "mattnt.files.wordpress.com\/2011\/12\/cray.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "402091677696790529",
  "geo" : { },
  "id_str" : "402092815099781121",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed http:\/\/t.co\/WlIOkljFn3",
  "id" : 402092815099781121,
  "in_reply_to_status_id" : 402091677696790529,
  "created_at" : "2013-11-17 15:16:12 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402090910735163393",
  "geo" : { },
  "id_str" : "402091262083608576",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon worth it? Looks like a Wind Waker clone.",
  "id" : 402091262083608576,
  "in_reply_to_status_id" : 402090910735163393,
  "created_at" : "2013-11-17 15:10:02 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402082895873208320",
  "geo" : { },
  "id_str" : "402083038353715200",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac where can I invest?",
  "id" : 402083038353715200,
  "in_reply_to_status_id" : 402082895873208320,
  "created_at" : "2013-11-17 14:37:21 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 0, 9 ],
      "id_str" : "14531472",
      "id" : 14531472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402069509072506882",
  "geo" : { },
  "id_str" : "402070190684254208",
  "in_reply_to_user_id" : 14531472,
  "text" : "@mikesusz bingo",
  "id" : 402070190684254208,
  "in_reply_to_status_id" : 402069509072506882,
  "created_at" : "2013-11-17 13:46:18 +0000",
  "in_reply_to_screen_name" : "mikesusz",
  "in_reply_to_user_id_str" : "14531472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 94, 105 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402068822712397824",
  "text" : "PlainText + Dropbox sync was the answer. Ridiculous how hard it was to set up overall. Thanks @dangigante !",
  "id" : 402068822712397824,
  "created_at" : "2013-11-17 13:40:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401928268150235136",
  "geo" : { },
  "id_str" : "401930274167992320",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment thought about this: my dad thought his phone was broke since auto lock default changed in iOS7 update to never. Just was lost.",
  "id" : 401930274167992320,
  "in_reply_to_status_id" : 401928268150235136,
  "created_at" : "2013-11-17 04:30:19 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401925333923815424",
  "geo" : { },
  "id_str" : "401929756939005952",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I feel like the first one didn\u2019t\u2026funny how glaring the test is once you know about it.",
  "id" : 401929756939005952,
  "in_reply_to_status_id" : 401925333923815424,
  "created_at" : "2013-11-17 04:28:16 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401907714864844800",
  "geo" : { },
  "id_str" : "401918877224812544",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale shithawks, Bubs.",
  "id" : 401918877224812544,
  "in_reply_to_status_id" : 401907714864844800,
  "created_at" : "2013-11-17 03:45:02 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 57, 69 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/401896463216943104\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/UYBHe7r4Se",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZPStC1IEAAPjjD.jpg",
      "id_str" : "401896463061749760",
      "id" : 401896463061749760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZPStC1IEAAPjjD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UYBHe7r4Se"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401896463216943104",
  "text" : "Sheets on the baby\u2019s cradle accurately predict tonight\u2019s @AqueousBand performance: MONSTER JAM! http:\/\/t.co\/UYBHe7r4Se",
  "id" : 401896463216943104,
  "created_at" : "2013-11-17 02:15:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 3, 19 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/0IvkLFpcDO",
      "expanded_url" : "http:\/\/www.buffalonyjobs.org\/",
      "display_url" : "buffalonyjobs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "401871662062108673",
  "text" : "RT @Millennial_Dave: Looking for a job in Buffalo?\nhttp:\/\/t.co\/0IvkLFpcDO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/0IvkLFpcDO",
        "expanded_url" : "http:\/\/www.buffalonyjobs.org\/",
        "display_url" : "buffalonyjobs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "401871259278917632",
    "text" : "Looking for a job in Buffalo?\nhttp:\/\/t.co\/0IvkLFpcDO",
    "id" : 401871259278917632,
    "created_at" : "2013-11-17 00:35:49 +0000",
    "user" : {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "protected" : false,
      "id_str" : "60185021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465203814283243520\/_cZY_OW1_normal.jpeg",
      "id" : 60185021,
      "verified" : false
    }
  },
  "id" : 401871662062108673,
  "created_at" : "2013-11-17 00:37:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/XcLDn6nk5o",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/84-million-new-yorkers-suddenly-realize-new-york-c,18003\/",
      "display_url" : "theonion.com\/articles\/84-mi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "401850778861572097",
  "geo" : { },
  "id_str" : "401852096372170753",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan http:\/\/t.co\/XcLDn6nk5o",
  "id" : 401852096372170753,
  "in_reply_to_status_id" : 401850778861572097,
  "created_at" : "2013-11-16 23:19:40 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Wagener",
      "screen_name" : "a_wagener",
      "indices" : [ 0, 10 ],
      "id_str" : "140208068",
      "id" : 140208068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401849913648381952",
  "geo" : { },
  "id_str" : "401850198214733824",
  "in_reply_to_user_id" : 140208068,
  "text" : "@a_wagener hacked?",
  "id" : 401850198214733824,
  "in_reply_to_status_id" : 401849913648381952,
  "created_at" : "2013-11-16 23:12:07 +0000",
  "in_reply_to_screen_name" : "a_wagener",
  "in_reply_to_user_id_str" : "140208068",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/401849360989691904\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/lVbTA9XEAq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZOn3VKCMAABznf.jpg",
      "id_str" : "401849360779980800",
      "id" : 401849360779980800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZOn3VKCMAABznf.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/lVbTA9XEAq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401849360989691904",
  "text" : "Shout out to this truck parked at Home Depot today http:\/\/t.co\/lVbTA9XEAq",
  "id" : 401849360989691904,
  "created_at" : "2013-11-16 23:08:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401789716653019136",
  "geo" : { },
  "id_str" : "401799882815860736",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo I hope someone is taping. Packing and a 4 day old at home means a break for a while :) have fun!",
  "id" : 401799882815860736,
  "in_reply_to_status_id" : 401789716653019136,
  "created_at" : "2013-11-16 19:52:11 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/HBuvjFumQ8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=O_zx7jPLmyk",
      "display_url" : "youtube.com\/watch?v=O_zx7j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401697489817841665",
  "text" : "RT @themcgruff: More great advertising from Mike http:\/\/t.co\/HBuvjFumQ8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/HBuvjFumQ8",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=O_zx7jPLmyk",
        "display_url" : "youtube.com\/watch?v=O_zx7j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401694130218090497",
    "text" : "More great advertising from Mike http:\/\/t.co\/HBuvjFumQ8",
    "id" : 401694130218090497,
    "created_at" : "2013-11-16 12:51:58 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 401697489817841665,
  "created_at" : "2013-11-16 13:05:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merissa",
      "screen_name" : "merissie",
      "indices" : [ 0, 9 ],
      "id_str" : "15338379",
      "id" : 15338379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401560538217336832",
  "geo" : { },
  "id_str" : "401561031400361984",
  "in_reply_to_user_id" : 15338379,
  "text" : "@merissie hacked?",
  "id" : 401561031400361984,
  "in_reply_to_status_id" : 401560538217336832,
  "created_at" : "2013-11-16 04:03:05 +0000",
  "in_reply_to_screen_name" : "merissie",
  "in_reply_to_user_id_str" : "15338379",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/vcUSYcFPbr",
      "expanded_url" : "http:\/\/github.com\/rubygems\/bundler-api",
      "display_url" : "github.com\/rubygems\/bundl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "401517239448244224",
  "geo" : { },
  "id_str" : "401532368827080704",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej started as a separate API, eventually broke off to its own service http:\/\/t.co\/vcUSYcFPbr",
  "id" : 401532368827080704,
  "in_reply_to_status_id" : 401517239448244224,
  "created_at" : "2013-11-16 02:09:11 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 35, 46 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401497008520712192",
  "geo" : { },
  "id_str" : "401497780763381761",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden is dinner a monad? \/cc @Jonplussed",
  "id" : 401497780763381761,
  "in_reply_to_status_id" : 401497008520712192,
  "created_at" : "2013-11-15 23:51:45 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401437922328449024",
  "geo" : { },
  "id_str" : "401438093171257344",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren there\u2019s an iPhone app too, hater",
  "id" : 401438093171257344,
  "in_reply_to_status_id" : 401437922328449024,
  "created_at" : "2013-11-15 19:54:34 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natasha allegri",
      "screen_name" : "natazilla",
      "indices" : [ 3, 13 ],
      "id_str" : "14860638",
      "id" : 14860638
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/natazilla\/status\/401433858794455040\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/pl6Gl3zbFu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZIt97qCAAA9Q4Y.png",
      "id_str" : "401433858798649344",
      "id" : 401433858798649344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZIt97qCAAA9Q4Y.png",
      "sizes" : [ {
        "h" : 932,
        "resize" : "fit",
        "w" : 705
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 932,
        "resize" : "fit",
        "w" : 705
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pl6Gl3zbFu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401437048449798144",
  "text" : "RT @natazilla: dilbert, no shirt, my wrist hurts http:\/\/t.co\/pl6Gl3zbFu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/natazilla\/status\/401433858794455040\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/pl6Gl3zbFu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZIt97qCAAA9Q4Y.png",
        "id_str" : "401433858798649344",
        "id" : 401433858798649344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZIt97qCAAA9Q4Y.png",
        "sizes" : [ {
          "h" : 932,
          "resize" : "fit",
          "w" : 705
        }, {
          "h" : 793,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 932,
          "resize" : "fit",
          "w" : 705
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pl6Gl3zbFu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401433858794455040",
    "text" : "dilbert, no shirt, my wrist hurts http:\/\/t.co\/pl6Gl3zbFu",
    "id" : 401433858794455040,
    "created_at" : "2013-11-15 19:37:47 +0000",
    "user" : {
      "name" : "natasha allegri",
      "screen_name" : "natazilla",
      "protected" : false,
      "id_str" : "14860638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541179560776065025\/Y32So1Ky_normal.png",
      "id" : 14860638,
      "verified" : false
    }
  },
  "id" : 401437048449798144,
  "created_at" : "2013-11-15 19:50:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401433763923894272",
  "text" : "\u2705 Got peed on",
  "id" : 401433763923894272,
  "created_at" : "2013-11-15 19:37:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401423395994095616",
  "text" : "And Simplenote doesn\u2019t sync between two devices despite saying it can. You get what you pay for I guess\u2026",
  "id" : 401423395994095616,
  "created_at" : "2013-11-15 18:56:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401420924714360833",
  "geo" : { },
  "id_str" : "401421534386208768",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV that\u2019s CRAZY!",
  "id" : 401421534386208768,
  "in_reply_to_status_id" : 401420924714360833,
  "created_at" : "2013-11-15 18:48:46 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401419338495713280",
  "text" : "I need to share a note between 2 iPhones and edit on both. Evernote can do this, but feels like too much. Is there anything simpler?",
  "id" : 401419338495713280,
  "created_at" : "2013-11-15 18:40:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401247677200859136",
  "geo" : { },
  "id_str" : "401311861657722880",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky sure, I link them from quaran.to",
  "id" : 401311861657722880,
  "in_reply_to_status_id" : 401247677200859136,
  "created_at" : "2013-11-15 11:32:58 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401212683791241216",
  "text" : "Our life right now: \"What emoji should I use for a wet diaper?\"",
  "id" : 401212683791241216,
  "created_at" : "2013-11-15 04:58:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 0, 11 ],
      "id_str" : "12304192",
      "id" : 12304192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401056029447700480",
  "geo" : { },
  "id_str" : "401056328870670336",
  "in_reply_to_user_id" : 12304192,
  "text" : "@thenickguy call me cynical but that\u2019s a huge missed opportunity.",
  "id" : 401056328870670336,
  "in_reply_to_status_id" : 401056029447700480,
  "created_at" : "2013-11-14 18:37:34 +0000",
  "in_reply_to_screen_name" : "thenickguy",
  "in_reply_to_user_id_str" : "12304192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/6y6S4joKbz",
      "expanded_url" : "https:\/\/onlycoin.com\/",
      "display_url" : "onlycoin.com"
    } ]
  },
  "geo" : { },
  "id_str" : "401055926381477888",
  "text" : "I wonder what kind of fees this will cost: https:\/\/t.co\/6y6S4joKbz % on every tx? Monthly sub?",
  "id" : 401055926381477888,
  "created_at" : "2013-11-14 18:35:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/401033096960569344\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/VhAIH7PwiH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDBegdCAAA17sa.jpg",
      "id_str" : "401033096687910912",
      "id" : 401033096687910912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDBegdCAAA17sa.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VhAIH7PwiH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401033096960569344",
  "text" : "Home. \uD83D\uDC76\uD83D\uDC49\uD83C\uDFE1 http:\/\/t.co\/VhAIH7PwiH",
  "id" : 401033096960569344,
  "created_at" : "2013-11-14 17:05:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 11, 21 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 22, 31 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400995944012857345",
  "geo" : { },
  "id_str" : "400996410495344641",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano @aquaranto @bquarant too late",
  "id" : 400996410495344641,
  "in_reply_to_status_id" : 400995944012857345,
  "created_at" : "2013-11-14 14:39:29 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400990255421353984",
  "text" : "This just after we decided to not post meme photos of the newborn.",
  "id" : 400990255421353984,
  "created_at" : "2013-11-14 14:15:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grumpyCam",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400989995361918977",
  "text" : "RT @aquaranto: I was born once; it was awful #grumpyCam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grumpyCam",
        "indices" : [ 30, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400989903741538304",
    "text" : "I was born once; it was awful #grumpyCam",
    "id" : 400989903741538304,
    "created_at" : "2013-11-14 14:13:37 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 400989995361918977,
  "created_at" : "2013-11-14 14:13:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400952952850251777",
  "text" : "And suddenly it\u2019s Thursday?",
  "id" : 400952952850251777,
  "created_at" : "2013-11-14 11:46:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400935600595156992",
  "geo" : { },
  "id_str" : "400935671298523136",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden lol",
  "id" : 400935671298523136,
  "in_reply_to_status_id" : 400935600595156992,
  "created_at" : "2013-11-14 10:38:07 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400935178954371072",
  "geo" : { },
  "id_str" : "400935497138470912",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden for all domains?",
  "id" : 400935497138470912,
  "in_reply_to_status_id" : 400935178954371072,
  "created_at" : "2013-11-14 10:37:26 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400725383366316032",
  "text" : "Easily best birthday present ever. Second to that: short nap after nearly 48 hours of being up.",
  "id" : 400725383366316032,
  "created_at" : "2013-11-13 20:42:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 13, 26 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 27, 35 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400631761488855040",
  "text" : "@juliepagano @steveklabnik @jcoglan lots of 37s works on OSS as part of our jobs\u2026it\u2019s just not FT for anyone. It\u2019s a blurry line.",
  "id" : 400631761488855040,
  "created_at" : "2013-11-13 14:30:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400491942855061504",
  "text" : "Baby and Mom @aquaranto doing well. Dad already working on perfecting dad jokes.",
  "id" : 400491942855061504,
  "created_at" : "2013-11-13 05:14:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/400486577035829248\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/XdaKfkc1zd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY7Qa3cIIAAhPl2.jpg",
      "id_str" : "400486576859652096",
      "id" : 400486576859652096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY7Qa3cIIAAhPl2.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/XdaKfkc1zd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400486577035829248",
  "text" : "Cameron Richard, 8lbs 3oz. 11\/12\/13 11:15PM. \uD83D\uDC76\uD83D\uDE80 http:\/\/t.co\/XdaKfkc1zd",
  "id" : 400486577035829248,
  "created_at" : "2013-11-13 04:53:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400201044950781952",
  "text" : "THUNDERCATS ARE GOOOO!!! For real this time.",
  "id" : 400201044950781952,
  "created_at" : "2013-11-12 09:58:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400170108909154304",
  "geo" : { },
  "id_str" : "400171255996755968",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant you missed your alarm",
  "id" : 400171255996755968,
  "in_reply_to_status_id" : 400170108909154304,
  "created_at" : "2013-11-12 08:00:36 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400162982736711680",
  "geo" : { },
  "id_str" : "400167215736958976",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j looks shopped",
  "id" : 400167215736958976,
  "in_reply_to_status_id" : 400162982736711680,
  "created_at" : "2013-11-12 07:44:33 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400115620689092608",
  "geo" : { },
  "id_str" : "400134565802434560",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh verizon tries to give you one when you buy. I traded for an extra power cord.",
  "id" : 400134565802434560,
  "in_reply_to_status_id" : 400115620689092608,
  "created_at" : "2013-11-12 05:34:49 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400108496215351296",
  "geo" : { },
  "id_str" : "400109003486687232",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler WANT TO GET BIG?!",
  "id" : 400109003486687232,
  "in_reply_to_status_id" : 400108496215351296,
  "created_at" : "2013-11-12 03:53:14 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 81, 90 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/AX6drfFc2a",
      "expanded_url" : "https:\/\/medium.com\/hackers-and-hacking\/7ebcd6bfda26",
      "display_url" : "medium.com\/hackers-and-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400108954337832960",
  "text" : "Everything that is wrong with the \"hackathon\" mentality: https:\/\/t.co\/AX6drfFc2a @openhack is the antidote to this sickness.",
  "id" : 400108954337832960,
  "created_at" : "2013-11-12 03:53:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 88, 94 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400106118774419456",
  "geo" : { },
  "id_str" : "400106276924841985",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy yeah, these posts are absurd. Trying to avoid the addon temptation, although @jamis keeps selling me hard on MechJeb.",
  "id" : 400106276924841985,
  "in_reply_to_status_id" : 400106118774419456,
  "created_at" : "2013-11-12 03:42:24 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/py2J0x0yBF",
      "expanded_url" : "http:\/\/i.imgur.com\/zoJ7n7l.png",
      "display_url" : "i.imgur.com\/zoJ7n7l.png"
    } ]
  },
  "geo" : { },
  "id_str" : "400105549926133760",
  "text" : "Absolutely clutch Mun landing in Career mode with no landing gear: http:\/\/t.co\/py2J0x0yBF",
  "id" : 400105549926133760,
  "created_at" : "2013-11-12 03:39:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400071483432902656",
  "geo" : { },
  "id_str" : "400072025437253633",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden you are so 2000 and late",
  "id" : 400072025437253633,
  "in_reply_to_status_id" : 400071483432902656,
  "created_at" : "2013-11-12 01:26:18 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 9, 20 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 21, 33 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400070791791796224",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @samkottler @dwradcliffe ping in #rubygems",
  "id" : 400070791791796224,
  "created_at" : "2013-11-12 01:21:24 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 58, 69 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400016217039458306",
  "geo" : { },
  "id_str" : "400028324950335488",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta what exact URL was it, if you still have it? \/cc @samkottler",
  "id" : 400028324950335488,
  "in_reply_to_status_id" : 400016217039458306,
  "created_at" : "2013-11-11 22:32:39 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400026234140102656",
  "geo" : { },
  "id_str" : "400027372889464833",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej fresh air interview with Hadfield said they make custom molds for each astronaut's butt in the capsule. No joke.",
  "id" : 400027372889464833,
  "in_reply_to_status_id" : 400026234140102656,
  "created_at" : "2013-11-11 22:28:52 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Dagenais",
      "screen_name" : "oliiscool",
      "indices" : [ 0, 10 ],
      "id_str" : "29337210",
      "id" : 29337210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400018228425920512",
  "geo" : { },
  "id_str" : "400019471156264961",
  "in_reply_to_user_id" : 29337210,
  "text" : "@oliiscool i'll update that thread, thanks",
  "id" : 400019471156264961,
  "in_reply_to_status_id" : 400018228425920512,
  "created_at" : "2013-11-11 21:57:28 +0000",
  "in_reply_to_screen_name" : "oliiscool",
  "in_reply_to_user_id_str" : "29337210",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/HsNhGlTez1",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "400017988109099008",
  "text" : "Cleaned out the http:\/\/t.co\/HsNhGlTez1 queue. Over 50 issues! :|",
  "id" : 400017988109099008,
  "created_at" : "2013-11-11 21:51:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 43, 51 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 52, 63 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400016217039458306",
  "geo" : { },
  "id_str" : "400016858738204672",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta I just got a few of these. :( \/cc @evanphx @samkottler",
  "id" : 400016858738204672,
  "in_reply_to_status_id" : 400016217039458306,
  "created_at" : "2013-11-11 21:47:05 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/3zjUbdSWqr",
      "expanded_url" : "http:\/\/i.imgur.com\/9HY53al.gif",
      "display_url" : "i.imgur.com\/9HY53al.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "400009475945283584",
  "text" : "\"...THREAT OF BLACK ICE TONIGHT...\" http:\/\/t.co\/3zjUbdSWqr",
  "id" : 400009475945283584,
  "created_at" : "2013-11-11 21:17:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Whole Hog Truck",
      "screen_name" : "WholeHogTruck",
      "indices" : [ 0, 14 ],
      "id_str" : "298098634",
      "id" : 298098634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399930716177592320",
  "geo" : { },
  "id_str" : "399993006880608256",
  "in_reply_to_user_id" : 298098634,
  "text" : "@WholeHogTruck There's already 2300+ people that follow this account. Why switch?",
  "id" : 399993006880608256,
  "in_reply_to_status_id" : 399930716177592320,
  "created_at" : "2013-11-11 20:12:19 +0000",
  "in_reply_to_screen_name" : "WholeHogTruck",
  "in_reply_to_user_id_str" : "298098634",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 93, 104 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "399674730107523073",
  "geo" : { },
  "id_str" : "399675297919823873",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh now realizing we need some retina images (or makeover!) for http:\/\/t.co\/2bA9BVLhWr\u2026 \/cc @thoughtbot",
  "id" : 399675297919823873,
  "in_reply_to_status_id" : 399674730107523073,
  "created_at" : "2013-11-10 23:09:51 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 14, 24 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/399672931002757120\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/0pVeKP6cYH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYvsabiCcAEdkpY.jpg",
      "id_str" : "399672930763698177",
      "id" : 399672930763698177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYvsabiCcAEdkpY.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/0pVeKP6cYH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399672931002757120",
  "text" : "From earlier: @aquaranto is sick of waiting for the baby, and has now resorted to dressing up the dog. http:\/\/t.co\/0pVeKP6cYH",
  "id" : 399672931002757120,
  "created_at" : "2013-11-10 23:00:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399672515213008896",
  "text" : "I know I'm behind on this...but first time actually using a retina and seeing it side by side with non: holy. crap.",
  "id" : 399672515213008896,
  "created_at" : "2013-11-10 22:58:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399656565063843841",
  "text" : "Thor 2 was great. Is it sad that I like Loki more than the other characters?",
  "id" : 399656565063843841,
  "created_at" : "2013-11-10 21:55:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399529080338808832",
  "geo" : { },
  "id_str" : "399530109670928385",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius narf",
  "id" : 399530109670928385,
  "in_reply_to_status_id" : 399529080338808832,
  "created_at" : "2013-11-10 13:32:55 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Katie Fiorini",
      "screen_name" : "_katertot",
      "indices" : [ 12, 22 ],
      "id_str" : "6584032",
      "id" : 6584032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/399358483008483328\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/kofvcQcEPv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYrObI0CMAAiXm7.png",
      "id_str" : "399358482593230848",
      "id" : 399358482593230848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYrObI0CMAAiXm7.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kofvcQcEPv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399340230412472321",
  "geo" : { },
  "id_str" : "399358483008483328",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini @_katertot eventual consistency? http:\/\/t.co\/kofvcQcEPv",
  "id" : 399358483008483328,
  "in_reply_to_status_id" : 399340230412472321,
  "created_at" : "2013-11-10 02:10:56 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Katie Fiorini",
      "screen_name" : "_katertot",
      "indices" : [ 12, 22 ],
      "id_str" : "6584032",
      "id" : 6584032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399340230412472321",
  "geo" : { },
  "id_str" : "399340979557109760",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini @_katertot gauntlet. Dropped.",
  "id" : 399340979557109760,
  "in_reply_to_status_id" : 399340230412472321,
  "created_at" : "2013-11-10 01:01:23 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399196065036914688",
  "text" : "RT @drbrain: Katie Hagerty on programming: \"\u2026 so you're really just saying hello to yourself\" \uD83D\uDE2D #rubyconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399195603332513792",
    "text" : "Katie Hagerty on programming: \"\u2026 so you're really just saying hello to yourself\" \uD83D\uDE2D #rubyconf",
    "id" : 399195603332513792,
    "created_at" : "2013-11-09 15:23:43 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 399196065036914688,
  "created_at" : "2013-11-09 15:25:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "embrown",
      "indices" : [ 3, 11 ],
      "id_str" : "425253989",
      "id" : 425253989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399196055016710144",
  "text" : "RT @embrown: Anyone who says there isn't love \u2764\uFE0F in the Ruby community, hasn't seen Katie Hagerty talk in front of hundreds of Rubyists at \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399195637457371136",
    "text" : "Anyone who says there isn't love \u2764\uFE0F in the Ruby community, hasn't seen Katie Hagerty talk in front of hundreds of Rubyists at #rubyconf.",
    "id" : 399195637457371136,
    "created_at" : "2013-11-09 15:23:51 +0000",
    "user" : {
      "name" : "Erin",
      "screen_name" : "embrown",
      "protected" : false,
      "id_str" : "425253989",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_6_normal.png",
      "id" : 425253989,
      "verified" : false
    }
  },
  "id" : 399196055016710144,
  "created_at" : "2013-11-09 15:25:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Long",
      "screen_name" : "davejlong",
      "indices" : [ 3, 13 ],
      "id_str" : "62404063",
      "id" : 62404063
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399196002709544960",
  "text" : "RT @davejlong: Sorry speakers but this girl is probably the best speaker at #rubyconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399194838593441793",
    "text" : "Sorry speakers but this girl is probably the best speaker at #rubyconf",
    "id" : 399194838593441793,
    "created_at" : "2013-11-09 15:20:40 +0000",
    "user" : {
      "name" : "David Long",
      "screen_name" : "davejlong",
      "protected" : false,
      "id_str" : "62404063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000720865969\/3047ce885b92a5ff0841f2f8310d5d85_normal.jpeg",
      "id" : 62404063,
      "verified" : false
    }
  },
  "id" : 399196002709544960,
  "created_at" : "2013-11-09 15:25:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 74, 89 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399154735401672704",
  "text" : "Excited for everyone at #rubyconf to see Katie\u2019s talk today\u2026she killed it @nickelcityruby.",
  "id" : 399154735401672704,
  "created_at" : "2013-11-09 12:41:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399153792739848192",
  "geo" : { },
  "id_str" : "399154483952750593",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden gla-ceirs",
  "id" : 399154483952750593,
  "in_reply_to_status_id" : 399153792739848192,
  "created_at" : "2013-11-09 12:40:19 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/G9U8opi6DN",
      "expanded_url" : "http:\/\/imgur.com\/a\/Y9EQU",
      "display_url" : "imgur.com\/a\/Y9EQU"
    } ]
  },
  "geo" : { },
  "id_str" : "399061158339944448",
  "text" : "Had a little too much fun boosting Kerbals into space tonight that I turned one into Mr. Kerbtastic: http:\/\/t.co\/G9U8opi6DN",
  "id" : 399061158339944448,
  "created_at" : "2013-11-09 06:29:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399011614848212992",
  "geo" : { },
  "id_str" : "399012322720882688",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda 13 floors so far. Save bux for the elevators. Damn these addictive bastards.",
  "id" : 399012322720882688,
  "in_reply_to_status_id" : 399011614848212992,
  "created_at" : "2013-11-09 03:15:25 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/h1B3sGDJEr",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/star-wars-tiny-death-star\/id663576850?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/star-wa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "399009902108344320",
  "geo" : { },
  "id_str" : "399011796914548736",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda https:\/\/t.co\/h1B3sGDJEr",
  "id" : 399011796914548736,
  "in_reply_to_status_id" : 399009902108344320,
  "created_at" : "2013-11-09 03:13:20 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399008820758069248",
  "text" : "Tiny Death Star consumes all.",
  "id" : 399008820758069248,
  "created_at" : "2013-11-09 03:01:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399002004120297472",
  "geo" : { },
  "id_str" : "399005983596625920",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude SOON",
  "id" : 399005983596625920,
  "in_reply_to_status_id" : 399002004120297472,
  "created_at" : "2013-11-09 02:50:14 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398929549892657152",
  "text" : "Shitwinds are acomin'",
  "id" : 398929549892657152,
  "created_at" : "2013-11-08 21:46:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/9kcdvCaMeU",
      "expanded_url" : "http:\/\/earthobservatory.nasa.gov\/IOTD\/view.php?id=989",
      "display_url" : "earthobservatory.nasa.gov\/IOTD\/view.php?\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "398869320815882240",
  "geo" : { },
  "id_str" : "398889139115814912",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu http:\/\/t.co\/9kcdvCaMeU",
  "id" : 398889139115814912,
  "in_reply_to_status_id" : 398869320815882240,
  "created_at" : "2013-11-08 19:05:56 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 6, 14 ],
      "id_str" : "900882032",
      "id" : 900882032
    }, {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 43, 57 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398866283921682432",
  "text" : "Snow, @theBMFT banh mis, and spotted a new @communitybeer neon sign. Awesome day on Elmwood.",
  "id" : 398866283921682432,
  "created_at" : "2013-11-08 17:35:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398857754929926144",
  "text" : "Snow in Buffalo!",
  "id" : 398857754929926144,
  "created_at" : "2013-11-08 17:01:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zalar",
      "screen_name" : "ZalarMark",
      "indices" : [ 0, 10 ],
      "id_str" : "483153848",
      "id" : 483153848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398834427138408448",
  "geo" : { },
  "id_str" : "398835854023483392",
  "in_reply_to_user_id" : 483153848,
  "text" : "@ZalarMark I really hope Halfway to the Moon and Yarmouth Road make the cut too.",
  "id" : 398835854023483392,
  "in_reply_to_status_id" : 398834427138408448,
  "created_at" : "2013-11-08 15:34:12 +0000",
  "in_reply_to_screen_name" : "ZalarMark",
  "in_reply_to_user_id_str" : "483153848",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zalar",
      "screen_name" : "ZalarMark",
      "indices" : [ 0, 10 ],
      "id_str" : "483153848",
      "id" : 483153848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398834427138408448",
  "geo" : { },
  "id_str" : "398835783462699008",
  "in_reply_to_user_id" : 483153848,
  "text" : "@ZalarMark Wombat and Monica have been my favorites so far. Digging Fuego too.",
  "id" : 398835783462699008,
  "in_reply_to_status_id" : 398834427138408448,
  "created_at" : "2013-11-08 15:33:55 +0000",
  "in_reply_to_screen_name" : "ZalarMark",
  "in_reply_to_user_id_str" : "483153848",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zalar",
      "screen_name" : "ZalarMark",
      "indices" : [ 0, 10 ],
      "id_str" : "483153848",
      "id" : 483153848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398833392193908736",
  "geo" : { },
  "id_str" : "398833509856333824",
  "in_reply_to_user_id" : 483153848,
  "text" : "@ZalarMark er, didn't mean to say I'm holding out - it's been on repeat for days.",
  "id" : 398833509856333824,
  "in_reply_to_status_id" : 398833392193908736,
  "created_at" : "2013-11-08 15:24:53 +0000",
  "in_reply_to_screen_name" : "ZalarMark",
  "in_reply_to_user_id_str" : "483153848",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/5YUwQb4X28",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/2013\/10\/21\/hey-coworkbuffalo-has-some-pretty-big-news.html",
      "display_url" : "coworkbuffalo.com\/newsletter\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "398829535283523585",
  "geo" : { },
  "id_str" : "398831512822378496",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity that being said, we are moving soon: http:\/\/t.co\/5YUwQb4X28",
  "id" : 398831512822378496,
  "in_reply_to_status_id" : 398829535283523585,
  "created_at" : "2013-11-08 15:16:57 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398829535283523585",
  "geo" : { },
  "id_str" : "398829809704239104",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity not saying that doesn't happen, but it happens.",
  "id" : 398829809704239104,
  "in_reply_to_status_id" : 398829535283523585,
  "created_at" : "2013-11-08 15:10:11 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 30, 44 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398824207041036288",
  "geo" : { },
  "id_str" : "398828784662507521",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity you're welcome at @coworkbuffalo if you need a break :)",
  "id" : 398828784662507521,
  "in_reply_to_status_id" : 398824207041036288,
  "created_at" : "2013-11-08 15:06:06 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Q7MmFW0im6",
      "expanded_url" : "http:\/\/www.phishtracks.com\/shows\/2013-10-31\/wingsuit",
      "display_url" : "phishtracks.com\/shows\/2013-10-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398828643675172865",
  "text" : "Having a hard time not listening to Wingsuit this week. Phish's new album, live: http:\/\/t.co\/Q7MmFW0im6",
  "id" : 398828643675172865,
  "created_at" : "2013-11-08 15:05:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398693796168228864",
  "geo" : { },
  "id_str" : "398694113907728384",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt That\u2019s So Braven",
  "id" : 398694113907728384,
  "in_reply_to_status_id" : 398693796168228864,
  "created_at" : "2013-11-08 06:10:58 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 11, 20 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "Eron Nicholson",
      "screen_name" : "VinzClortho",
      "indices" : [ 21, 33 ],
      "id_str" : "15759219",
      "id" : 15759219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398636898765111297",
  "geo" : { },
  "id_str" : "398660741529489408",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack @shildner @VinzClortho ugh you still have to drag the tiny idiots up the elevator. Sucks when you get to a lot of floors.",
  "id" : 398660741529489408,
  "in_reply_to_status_id" : 398636898765111297,
  "created_at" : "2013-11-08 03:58:22 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/jmYReS8f2x",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vhuzb3WMntc",
      "display_url" : "youtube.com\/watch?v=vhuzb3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398654051652349952",
  "text" : "Current status: http:\/\/t.co\/jmYReS8f2x",
  "id" : 398654051652349952,
  "created_at" : "2013-11-08 03:31:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398633246423924736",
  "geo" : { },
  "id_str" : "398635596987789312",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave awesome. You should charge to list jobs too!",
  "id" : 398635596987789312,
  "in_reply_to_status_id" : 398633246423924736,
  "created_at" : "2013-11-08 02:18:27 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398630437188165632",
  "geo" : { },
  "id_str" : "398632097822162944",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave nice!!",
  "id" : 398632097822162944,
  "in_reply_to_status_id" : 398630437188165632,
  "created_at" : "2013-11-08 02:04:33 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/uHSm9NlNmg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=x4TziTiUnx0",
      "display_url" : "youtube.com\/watch?v=x4TziT\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "398627477364703232",
  "geo" : { },
  "id_str" : "398630602124951552",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier http:\/\/t.co\/uHSm9NlNmg",
  "id" : 398630602124951552,
  "in_reply_to_status_id" : 398627477364703232,
  "created_at" : "2013-11-08 01:58:36 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 5, 13 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 14, 24 ],
      "id_str" : "15031577",
      "id" : 15031577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/M5ZUZHZKrW",
      "expanded_url" : "http:\/\/rubyforge.org",
      "display_url" : "rubyforge.org"
    } ]
  },
  "geo" : { },
  "id_str" : "398583944670498816",
  "text" : "Ping @evanphx @tcopeland what happened to http:\/\/t.co\/M5ZUZHZKrW ?",
  "id" : 398583944670498816,
  "created_at" : "2013-11-07 22:53:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398578284465647616",
  "geo" : { },
  "id_str" : "398578510656069632",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy Coworkin' 2: Electric Denim Boogaloo",
  "id" : 398578510656069632,
  "in_reply_to_status_id" : 398578284465647616,
  "created_at" : "2013-11-07 22:31:36 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398543568039469056",
  "geo" : { },
  "id_str" : "398543701082767360",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat you need to be in All Nerds more.",
  "id" : 398543701082767360,
  "in_reply_to_status_id" : 398543568039469056,
  "created_at" : "2013-11-07 20:13:17 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R Murphy",
      "screen_name" : "michaelmurphy",
      "indices" : [ 0, 14 ],
      "id_str" : "11092742",
      "id" : 11092742
    }, {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 15, 21 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/r1FYAOkPVR",
      "expanded_url" : "http:\/\/vooza.com\/videos\/honest-business-card-exchange\/",
      "display_url" : "vooza.com\/videos\/honest-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "398526810381500416",
  "geo" : { },
  "id_str" : "398531430235385856",
  "in_reply_to_user_id" : 11092742,
  "text" : "@michaelmurphy @jfine http:\/\/t.co\/r1FYAOkPVR",
  "id" : 398531430235385856,
  "in_reply_to_status_id" : 398526810381500416,
  "created_at" : "2013-11-07 19:24:31 +0000",
  "in_reply_to_screen_name" : "michaelmurphy",
  "in_reply_to_user_id_str" : "11092742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0425\u043B\u0443\u0434\u0435\u0432a \u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0430",
      "screen_name" : "casualpro",
      "indices" : [ 0, 10 ],
      "id_str" : "2815471651",
      "id" : 2815471651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398529990322831360",
  "geo" : { },
  "id_str" : "398530678276386816",
  "in_reply_to_user_id" : 120837801,
  "text" : "@casualpro it's for a club on Chippewa.",
  "id" : 398530678276386816,
  "in_reply_to_status_id" : 398529990322831360,
  "created_at" : "2013-11-07 19:21:32 +0000",
  "in_reply_to_screen_name" : "davejachimiak",
  "in_reply_to_user_id_str" : "120837801",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 9, 16 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398524195492990976",
  "geo" : { },
  "id_str" : "398524650776305664",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @hiteak how about a \"GRILL\"",
  "id" : 398524650776305664,
  "in_reply_to_status_id" : 398524195492990976,
  "created_at" : "2013-11-07 18:57:35 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aanand Prasad",
      "screen_name" : "aanand",
      "indices" : [ 0, 7 ],
      "id_str" : "14149919",
      "id" : 14149919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398521625085087744",
  "geo" : { },
  "id_str" : "398521810494291968",
  "in_reply_to_user_id" : 14149919,
  "text" : "@aanand it's a joke :) we're next to some clubs.",
  "id" : 398521810494291968,
  "in_reply_to_status_id" : 398521625085087744,
  "created_at" : "2013-11-07 18:46:18 +0000",
  "in_reply_to_screen_name" : "aanand",
  "in_reply_to_user_id_str" : "14149919",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 4, 18 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/398520569039040512\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/7aeJojehLN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYfUWISCEAAzDRq.jpg",
      "id_str" : "398520568690905088",
      "id" : 398520568690905088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYfUWISCEAAzDRq.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/7aeJojehLN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398520569039040512",
  "text" : "New @coworkbuffalo dress code. http:\/\/t.co\/7aeJojehLN",
  "id" : 398520569039040512,
  "created_at" : "2013-11-07 18:41:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398515957892935682",
  "text" : "Confirmed: @coworkbuffalo\u2019s new space has sidewalks today!",
  "id" : 398515957892935682,
  "created_at" : "2013-11-07 18:23:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheresaPrestonWerner",
      "screen_name" : "tpdubs2",
      "indices" : [ 0, 8 ],
      "id_str" : "118292028",
      "id" : 118292028
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 31, 45 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398502849291624449",
  "geo" : { },
  "id_str" : "398505801079193600",
  "in_reply_to_user_id" : 118292028,
  "text" : "@tpdubs2 congrats!! One of our @coworkbuffalo members who runs a nonprofit is going to bug you about getting listed :)",
  "id" : 398505801079193600,
  "in_reply_to_status_id" : 398502849291624449,
  "created_at" : "2013-11-07 17:42:41 +0000",
  "in_reply_to_screen_name" : "tpdubs2",
  "in_reply_to_user_id_str" : "118292028",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SQUASHCASH",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398489005303414784",
  "text" : "Be a part of the #SQUASHCASH revolution. Our INITIAL PUMPKIN OFFERING is coming up in Q1!",
  "id" : 398489005303414784,
  "created_at" : "2013-11-07 16:35:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398488702847971328",
  "text" : "Send GOURDS and other FALL VEGETABLES to your friends. No fees.",
  "id" : 398488702847971328,
  "created_at" : "2013-11-07 16:34:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398488640319279104",
  "text" : "SQUASH CASH is now accepting VC funding.",
  "id" : 398488640319279104,
  "created_at" : "2013-11-07 16:34:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 0, 11 ],
      "id_str" : "12304192",
      "id" : 12304192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398486848898891776",
  "geo" : { },
  "id_str" : "398487045485502466",
  "in_reply_to_user_id" : 12304192,
  "text" : "@thenickguy no fees?",
  "id" : 398487045485502466,
  "in_reply_to_status_id" : 398486848898891776,
  "created_at" : "2013-11-07 16:28:09 +0000",
  "in_reply_to_screen_name" : "thenickguy",
  "in_reply_to_user_id_str" : "12304192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/gOlBCztfqJ",
      "expanded_url" : "http:\/\/quaran.to\/archive",
      "display_url" : "quaran.to\/archive"
    }, {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/EDI4tMd5Md",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/statuses\/176674519258374144",
      "display_url" : "twitter.com\/qrush\/statuses\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398485237279113216",
  "text" : "Another great use of the twitter archive at http:\/\/t.co\/gOlBCztfqJ: https:\/\/t.co\/EDI4tMd5Md",
  "id" : 398485237279113216,
  "created_at" : "2013-11-07 16:20:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398484525052743680",
  "geo" : { },
  "id_str" : "398484861096173568",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines How I Learned To Stop Worrying, And Reuse This Stupid Fucking Quote",
  "id" : 398484861096173568,
  "in_reply_to_status_id" : 398484525052743680,
  "created_at" : "2013-11-07 16:19:29 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 0, 8 ],
      "id_str" : "1696",
      "id" : 1696
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 9, 19 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398482409642930177",
  "geo" : { },
  "id_str" : "398482675259822080",
  "in_reply_to_user_id" : 1696,
  "text" : "@ktheory @aquaranto Can't get better than quaran.to",
  "id" : 398482675259822080,
  "in_reply_to_status_id" : 398482409642930177,
  "created_at" : "2013-11-07 16:10:47 +0000",
  "in_reply_to_screen_name" : "ktheory",
  "in_reply_to_user_id_str" : "1696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 0, 8 ],
      "id_str" : "1696",
      "id" : 1696
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 19, 29 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398479834302541824",
  "geo" : { },
  "id_str" : "398481690378526720",
  "in_reply_to_user_id" : 1696,
  "text" : "@ktheory i am not! @aquaranto is due tomorrow, all travel on hold for a while :)",
  "id" : 398481690378526720,
  "in_reply_to_status_id" : 398479834302541824,
  "created_at" : "2013-11-07 16:06:53 +0000",
  "in_reply_to_screen_name" : "ktheory",
  "in_reply_to_user_id_str" : "1696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398481206913679360",
  "text" : "There are only two hard things in Computer Science: cache invalidations and reusing this same stupid fucking quote everywhere.",
  "id" : 398481206913679360,
  "created_at" : "2013-11-07 16:04:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398478762863370240",
  "text" : "Can I trade the Failwhale for some $TWTR stock options?",
  "id" : 398478762863370240,
  "created_at" : "2013-11-07 15:55:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 69, 80 ],
      "id_str" : "16891327",
      "id" : 16891327
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 81, 89 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398261186447147008",
  "geo" : { },
  "id_str" : "398263567406755840",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape latest version? I know some recent ones had SSL troubles @luislavena @drbrain",
  "id" : 398263567406755840,
  "in_reply_to_status_id" : 398261186447147008,
  "created_at" : "2013-11-07 01:40:08 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 0, 5 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398252224842698752",
  "geo" : { },
  "id_str" : "398252719074332672",
  "in_reply_to_user_id" : 637533,
  "text" : "@coda unlikely, but the drummer wears a muumuu and I have seen plenty of fans wearing one or knockoffs.",
  "id" : 398252719074332672,
  "in_reply_to_status_id" : 398252224842698752,
  "created_at" : "2013-11-07 00:57:02 +0000",
  "in_reply_to_screen_name" : "coda",
  "in_reply_to_user_id_str" : "637533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 0, 5 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398251818582429696",
  "geo" : { },
  "id_str" : "398251944726102016",
  "in_reply_to_user_id" : 637533,
  "text" : "@coda or a phish show.",
  "id" : 398251944726102016,
  "in_reply_to_status_id" : 398251818582429696,
  "created_at" : "2013-11-07 00:53:57 +0000",
  "in_reply_to_screen_name" : "coda",
  "in_reply_to_user_id_str" : "637533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Meagher",
      "screen_name" : "evanm",
      "indices" : [ 0, 6 ],
      "id_str" : "1583331",
      "id" : 1583331
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 7, 15 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398206398674128896",
  "geo" : { },
  "id_str" : "398206963021905921",
  "in_reply_to_user_id" : 1583331,
  "text" : "@evanm @capotej ugh, lame, so shortcuts would be broken too.",
  "id" : 398206963021905921,
  "in_reply_to_status_id" : 398206398674128896,
  "created_at" : "2013-11-06 21:55:12 +0000",
  "in_reply_to_screen_name" : "evanm",
  "in_reply_to_user_id_str" : "1583331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Evan Meagher",
      "screen_name" : "evanm",
      "indices" : [ 9, 15 ],
      "id_str" : "1583331",
      "id" : 1583331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398201943144689665",
  "geo" : { },
  "id_str" : "398202288897933312",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @evanm just exec to the script inside of libexec...should be pretty transparent",
  "id" : 398202288897933312,
  "in_reply_to_status_id" : 398201943144689665,
  "created_at" : "2013-11-06 21:36:38 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Evan Meagher",
      "screen_name" : "evanm",
      "indices" : [ 9, 15 ],
      "id_str" : "1583331",
      "id" : 1583331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398201418365952000",
  "geo" : { },
  "id_str" : "398201606698577920",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @evanm definitely is! this would be a neat way to package them up.",
  "id" : 398201606698577920,
  "in_reply_to_status_id" : 398201418365952000,
  "created_at" : "2013-11-06 21:33:55 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Evan Meagher",
      "screen_name" : "evanm",
      "indices" : [ 9, 15 ],
      "id_str" : "1583331",
      "id" : 1583331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398200740683870208",
  "geo" : { },
  "id_str" : "398201282487259136",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @evanm havent tried really...but it might be possible. why?",
  "id" : 398201282487259136,
  "in_reply_to_status_id" : 398200740683870208,
  "created_at" : "2013-11-06 21:32:38 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/0W6jlptXx7",
      "expanded_url" : "http:\/\/livephish.com\/",
      "display_url" : "livephish.com"
    } ]
  },
  "geo" : { },
  "id_str" : "398199610033729536",
  "text" : "Wow, http:\/\/t.co\/0W6jlptXx7 got updated and it doesn't look like a custom Winamp skin anymore. Woot!!",
  "id" : 398199610033729536,
  "created_at" : "2013-11-06 21:25:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398187988049350656",
  "text" : "RT @themcgruff: Yo ops people -- Who is responsible for your office (ie non datacenter) network? What's the setup?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398187857954619392",
    "text" : "Yo ops people -- Who is responsible for your office (ie non datacenter) network? What's the setup?",
    "id" : 398187857954619392,
    "created_at" : "2013-11-06 20:39:17 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 398187988049350656,
  "created_at" : "2013-11-06 20:39:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merissa",
      "screen_name" : "merissie",
      "indices" : [ 0, 9 ],
      "id_str" : "15338379",
      "id" : 15338379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/miox4MGxHU",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=xG6K5hbPJKs",
      "display_url" : "youtube.com\/watch?v=xG6K5h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "398135764082360320",
  "geo" : { },
  "id_str" : "398142860907667456",
  "in_reply_to_user_id" : 15338379,
  "text" : "@merissie \"those times are for patients, not doctors\" http:\/\/t.co\/miox4MGxHU",
  "id" : 398142860907667456,
  "in_reply_to_status_id" : 398135764082360320,
  "created_at" : "2013-11-06 17:40:29 +0000",
  "in_reply_to_screen_name" : "merissie",
  "in_reply_to_user_id_str" : "15338379",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398138247420710912",
  "geo" : { },
  "id_str" : "398138302420615169",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape havent used it much",
  "id" : 398138302420615169,
  "in_reply_to_status_id" : 398138247420710912,
  "created_at" : "2013-11-06 17:22:23 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 34, 42 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/ttW25mJGaM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_o_dn9kF-DA",
      "display_url" : "youtube.com\/watch?v=_o_dn9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398137750169210880",
  "text" : "I found some good uke lessons for @noahhlo http:\/\/t.co\/ttW25mJGaM",
  "id" : 398137750169210880,
  "created_at" : "2013-11-06 17:20:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398112630466162689",
  "geo" : { },
  "id_str" : "398112855926390784",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic tell katie to break a leg!!",
  "id" : 398112855926390784,
  "in_reply_to_status_id" : 398112630466162689,
  "created_at" : "2013-11-06 15:41:16 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398102572084383744",
  "geo" : { },
  "id_str" : "398102727235862528",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej I died at Tim Snortins",
  "id" : 398102727235862528,
  "in_reply_to_status_id" : 398102572084383744,
  "created_at" : "2013-11-06 15:01:01 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/zw3PFrQ3YR",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=uVsgurevo-g",
      "display_url" : "youtube.com\/watch?v=uVsgur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398098740507996160",
  "text" : "Taiwanese news covers Rob Ford: http:\/\/t.co\/zw3PFrQ3YR",
  "id" : 398098740507996160,
  "created_at" : "2013-11-06 14:45:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398082880922189824",
  "geo" : { },
  "id_str" : "398084088638095361",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh I\u2019m still amazed no internal NSA engineers have come out as whistleblowers yet. No sense of morality or ethics.",
  "id" : 398084088638095361,
  "in_reply_to_status_id" : 398082880922189824,
  "created_at" : "2013-11-06 13:46:57 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397918435532759040",
  "geo" : { },
  "id_str" : "397918687409090560",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr hell yes. :) I\u2019ll hit you with a Dropbox link tomorrow.",
  "id" : 397918687409090560,
  "in_reply_to_status_id" : 397918435532759040,
  "created_at" : "2013-11-06 02:49:42 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/rSccPvb0ri",
      "expanded_url" : "http:\/\/www.marco.org\/2011\/05\/26\/geek-intro-to-phish",
      "display_url" : "marco.org\/2011\/05\/26\/gee\u2026"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/gV66uZHQX8",
      "expanded_url" : "http:\/\/youtube.com\/user\/notmkdev0",
      "display_url" : "youtube.com\/user\/notmkdev0"
    } ]
  },
  "in_reply_to_status_id_str" : "397917537163169792",
  "geo" : { },
  "id_str" : "397917850297323520",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr wonderful. Read http:\/\/t.co\/rSccPvb0ri, watch some shows on http:\/\/t.co\/gV66uZHQX8",
  "id" : 397917850297323520,
  "in_reply_to_status_id" : 397917537163169792,
  "created_at" : "2013-11-06 02:46:23 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397913407497584640",
  "geo" : { },
  "id_str" : "397917412596527104",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz PLEASE ADVISE",
  "id" : 397917412596527104,
  "in_reply_to_status_id" : 397913407497584640,
  "created_at" : "2013-11-06 02:44:38 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397914591847407616",
  "geo" : { },
  "id_str" : "397917156249051136",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman ZOMG",
  "id" : 397917156249051136,
  "in_reply_to_status_id" : 397914591847407616,
  "created_at" : "2013-11-06 02:43:37 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    }, {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 13, 24 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397908851863089152",
  "geo" : { },
  "id_str" : "397910496839352320",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius @jaytennier One remote person does not a team make",
  "id" : 397910496839352320,
  "in_reply_to_status_id" : 397908851863089152,
  "created_at" : "2013-11-06 02:17:09 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397910124205191168",
  "geo" : { },
  "id_str" : "397910278714572800",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh sortfolio?",
  "id" : 397910278714572800,
  "in_reply_to_status_id" : 397910124205191168,
  "created_at" : "2013-11-06 02:16:17 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 72, 78 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/wUdXGLtXHE",
      "expanded_url" : "http:\/\/vimeo.com\/m\/44340650",
      "display_url" : "vimeo.com\/m\/44340650"
    } ]
  },
  "geo" : { },
  "id_str" : "397909663356055552",
  "text" : "Next conference I go to needs a BoF session. http:\/\/t.co\/wUdXGLtXHE \/cc @cmeik",
  "id" : 397909663356055552,
  "created_at" : "2013-11-06 02:13:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397881019442802688",
  "geo" : { },
  "id_str" : "397882461952417792",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx had a false alarm today. Long day.",
  "id" : 397882461952417792,
  "in_reply_to_status_id" : 397881019442802688,
  "created_at" : "2013-11-06 00:25:45 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397880489673236480",
  "text" : "It\u2019s also fun to stick a ballot in what looks to be an electronic recycling bin.",
  "id" : 397880489673236480,
  "created_at" : "2013-11-06 00:17:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397880292507418624",
  "text" : "Still find it ironic that my polling place is a church.",
  "id" : 397880292507418624,
  "created_at" : "2013-11-06 00:17:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/XogSp7Z9og",
      "expanded_url" : "http:\/\/lnkd.in\/bii3zXF",
      "display_url" : "lnkd.in\/bii3zXF"
    } ]
  },
  "geo" : { },
  "id_str" : "397858029757939712",
  "text" : "Just added COMEDIC TIMING, FUN, and EXTREME ENVIRONMENTS to my skill list. http:\/\/t.co\/XogSp7Z9og",
  "id" : 397858029757939712,
  "created_at" : "2013-11-05 22:48:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397855630666379265",
  "geo" : { },
  "id_str" : "397857136346013697",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes just updated my skills to include Comedic Timing",
  "id" : 397857136346013697,
  "in_reply_to_status_id" : 397855630666379265,
  "created_at" : "2013-11-05 22:45:07 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/XogSp7Z9og",
      "expanded_url" : "http:\/\/lnkd.in\/bii3zXF",
      "display_url" : "lnkd.in\/bii3zXF"
    } ]
  },
  "geo" : { },
  "id_str" : "397855114460798976",
  "text" : "I forgot about my awesome linkedin profile. Endorse me! http:\/\/t.co\/XogSp7Z9og",
  "id" : 397855114460798976,
  "created_at" : "2013-11-05 22:37:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397820998537318400",
  "text" : "OH \"I probably changed my logo once in a drunken stupor\"",
  "id" : 397820998537318400,
  "created_at" : "2013-11-05 20:21:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fawn Livingston-Gray",
      "screen_name" : "fawnapril",
      "indices" : [ 0, 10 ],
      "id_str" : "931412629",
      "id" : 931412629
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 11, 22 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 23, 33 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397747591053467649",
  "geo" : { },
  "id_str" : "397775840915644416",
  "in_reply_to_user_id" : 931412629,
  "text" : "@fawnapril @ashedryden @aquaranto agreed. will need much emoji support soon!",
  "id" : 397775840915644416,
  "in_reply_to_status_id" : 397747591053467649,
  "created_at" : "2013-11-05 17:22:05 +0000",
  "in_reply_to_screen_name" : "fawnapril",
  "in_reply_to_user_id_str" : "931412629",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397732461310144513",
  "text" : "And false alarm. \uD83D\uDD1C",
  "id" : 397732461310144513,
  "created_at" : "2013-11-05 14:29:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397698186074415104",
  "text" : "THUNDERCATS ARE GO!",
  "id" : 397698186074415104,
  "created_at" : "2013-11-05 12:13:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397643450423590912",
  "geo" : { },
  "id_str" : "397659091926925313",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain you can check out, but never leave\u2026 \uD83C\uDFB5",
  "id" : 397659091926925313,
  "in_reply_to_status_id" : 397643450423590912,
  "created_at" : "2013-11-05 09:38:10 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397594307668217856",
  "geo" : { },
  "id_str" : "397594747205722112",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan stolen probably\u2026hot goods!",
  "id" : 397594747205722112,
  "in_reply_to_status_id" : 397594307668217856,
  "created_at" : "2013-11-05 05:22:29 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myron Marston",
      "screen_name" : "myronmarston",
      "indices" : [ 0, 13 ],
      "id_str" : "89517808",
      "id" : 89517808
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 14, 22 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397384047598383104",
  "geo" : { },
  "id_str" : "397385992698462208",
  "in_reply_to_user_id" : 89517808,
  "text" : "@myronmarston @evanphx yikes! not sure. that email does exist as a user right?",
  "id" : 397385992698462208,
  "in_reply_to_status_id" : 397384047598383104,
  "created_at" : "2013-11-04 15:32:58 +0000",
  "in_reply_to_screen_name" : "myronmarston",
  "in_reply_to_user_id_str" : "89517808",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Who Knows",
      "screen_name" : "mike_ftw",
      "indices" : [ 3, 12 ],
      "id_str" : "2228978804",
      "id" : 2228978804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397359531744694273",
  "text" : "RT @Mike_FTW: \u201CWhat can we do to make them forget we\u2019re spying on them?\u201D\n\n\u201CLet them use their iPads on takeoff.\u201D\n\n\u201CDo it.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396077784553902080",
    "text" : "\u201CWhat can we do to make them forget we\u2019re spying on them?\u201D\n\n\u201CLet them use their iPads on takeoff.\u201D\n\n\u201CDo it.\u201D",
    "id" : 396077784553902080,
    "created_at" : "2013-11-01 00:54:37 +0000",
    "user" : {
      "name" : "Mike Monteiro",
      "screen_name" : "monteiro",
      "protected" : false,
      "id_str" : "2426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552632215503245312\/jtlGzC07_normal.jpeg",
      "id" : 2426,
      "verified" : false
    }
  },
  "id" : 397359531744694273,
  "created_at" : "2013-11-04 13:47:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397215534204190720",
  "geo" : { },
  "id_str" : "397217378536136704",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout have you seen 2001?",
  "id" : 397217378536136704,
  "in_reply_to_status_id" : 397215534204190720,
  "created_at" : "2013-11-04 04:22:57 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Youngman",
      "screen_name" : "nathany",
      "indices" : [ 3, 11 ],
      "id_str" : "7145962",
      "id" : 7145962
    }, {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 108, 115 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "confreaks",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/UCNAShP0a7",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2695-nickelcityruby2013-smash-the-monolith-refactoring-legacy-rails-applications",
      "display_url" : "confreaks.com\/videos\/2695-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397175797838266368",
  "text" : "RT @nathany: \u201CLegacy code is a gift from the past to the present.\u201D Refactoring Legacy Rails Applications by @bantik http:\/\/t.co\/UCNAShP0a7\u201D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Follow @CoralineAda",
        "screen_name" : "Bantik",
        "indices" : [ 95, 102 ],
        "id_str" : "2375715212",
        "id" : 2375715212
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "confreaks",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/UCNAShP0a7",
        "expanded_url" : "http:\/\/confreaks.com\/videos\/2695-nickelcityruby2013-smash-the-monolith-refactoring-legacy-rails-applications",
        "display_url" : "confreaks.com\/videos\/2695-ni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "397169108128526336",
    "text" : "\u201CLegacy code is a gift from the past to the present.\u201D Refactoring Legacy Rails Applications by @bantik http:\/\/t.co\/UCNAShP0a7\u201D #confreaks",
    "id" : 397169108128526336,
    "created_at" : "2013-11-04 01:11:09 +0000",
    "user" : {
      "name" : "Nathan Youngman",
      "screen_name" : "nathany",
      "protected" : false,
      "id_str" : "7145962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533825454869073920\/BMdo4hpd_normal.jpeg",
      "id" : 7145962,
      "verified" : false
    }
  },
  "id" : 397175797838266368,
  "created_at" : "2013-11-04 01:37:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397082278620594176",
  "geo" : { },
  "id_str" : "397090502186909696",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss pretty typical. Buy gold\/Rez tokens.",
  "id" : 397090502186909696,
  "in_reply_to_status_id" : 397082278620594176,
  "created_at" : "2013-11-03 19:58:47 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Herman",
      "screen_name" : "littlecalculist",
      "indices" : [ 3, 19 ],
      "id_str" : "104245499",
      "id" : 104245499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397045774003208193",
  "text" : "RT @littlecalculist: When I see people warring over programming approaches I imagine the computer sitting there going \"is someone gonna tel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396842074156183552",
    "text" : "When I see people warring over programming approaches I imagine the computer sitting there going \"is someone gonna tell me what to do?\"",
    "id" : 396842074156183552,
    "created_at" : "2013-11-03 03:31:38 +0000",
    "user" : {
      "name" : "David Herman",
      "screen_name" : "littlecalculist",
      "protected" : false,
      "id_str" : "104245499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1229650863\/twitter-profile_normal.jpg",
      "id" : 104245499,
      "verified" : false
    }
  },
  "id" : 397045774003208193,
  "created_at" : "2013-11-03 17:01:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Rose",
      "screen_name" : "heimidal",
      "indices" : [ 0, 9 ],
      "id_str" : "1399981",
      "id" : 1399981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396866634175897600",
  "geo" : { },
  "id_str" : "396867257428492288",
  "in_reply_to_user_id" : 1399981,
  "text" : "@heimidal 5C here. No way I\u2019m going to be using Touch ID.",
  "id" : 396867257428492288,
  "in_reply_to_status_id" : 396866634175897600,
  "created_at" : "2013-11-03 05:11:42 +0000",
  "in_reply_to_screen_name" : "heimidal",
  "in_reply_to_user_id_str" : "1399981",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/iM8sHrnG34",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/max-axe\/id598049812?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/max-axe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396859881266745344",
  "text" : "Mad Axe is the funniest iOS game I\u2019ve played since Ridiculous Fishing. https:\/\/t.co\/iM8sHrnG34",
  "id" : 396859881266745344,
  "created_at" : "2013-11-03 04:42:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396859174740451328",
  "text" : "@juliepagano paying\/filming an interpreter might work too. I miss RIT classes\/events with them.",
  "id" : 396859174740451328,
  "created_at" : "2013-11-03 04:39:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396858339378094080",
  "text" : "@juliepagano I think there might be paid services that do this. I remember something existed when I used to work for NTID.",
  "id" : 396858339378094080,
  "created_at" : "2013-11-03 04:36:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 26, 37 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/396857563758985216\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Cmao2ITMcX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYHr2flIYAAsLvm.png",
      "id_str" : "396857563608014848",
      "id" : 396857563608014848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYHr2flIYAAsLvm.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Cmao2ITMcX"
    } ],
    "hashtags" : [ {
      "text" : "fhc5",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396857563758985216",
  "text" : "My twitter feed, starring @ashedryden and #fhc5 in a new age Shakespeare play. http:\/\/t.co\/Cmao2ITMcX",
  "id" : 396857563758985216,
  "created_at" : "2013-11-03 04:33:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/awholV8SBM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=lHj7jgQpnBM&sns=tw",
      "display_url" : "youtube.com\/watch?v=lHj7jg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396855378001948674",
  "text" : "Blaming Snowden for NSA programs is like blaming Al Gore for global warming: http:\/\/t.co\/awholV8SBM",
  "id" : 396855378001948674,
  "created_at" : "2013-11-03 04:24:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 3, 13 ],
      "id_str" : "14182110",
      "id" : 14182110
    }, {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 80, 95 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nickelcityruby2013",
      "indices" : [ 26, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/pp8ES8lMVs",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2689-nickelcityruby2013-rubymotion-and-accessibility",
      "display_url" : "confreaks.com\/videos\/2689-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396830770783715329",
  "text" : "RT @confreaks: New Video! #nickelcityruby2013 - RubyMotion and Accessibility by @AustinSeraphin http:\/\/t.co\/pp8ES8lMVs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Austin Seraphin",
        "screen_name" : "AustinSeraphin",
        "indices" : [ 65, 80 ],
        "id_str" : "16393800",
        "id" : 16393800
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nickelcityruby2013",
        "indices" : [ 11, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/pp8ES8lMVs",
        "expanded_url" : "http:\/\/confreaks.com\/videos\/2689-nickelcityruby2013-rubymotion-and-accessibility",
        "display_url" : "confreaks.com\/videos\/2689-ni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396817485946552320",
    "text" : "New Video! #nickelcityruby2013 - RubyMotion and Accessibility by @AustinSeraphin http:\/\/t.co\/pp8ES8lMVs",
    "id" : 396817485946552320,
    "created_at" : "2013-11-03 01:53:55 +0000",
    "user" : {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "protected" : false,
      "id_str" : "14182110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508193987417485312\/4FaFrBga_normal.png",
      "id" : 14182110,
      "verified" : false
    }
  },
  "id" : 396830770783715329,
  "created_at" : "2013-11-03 02:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 3, 13 ],
      "id_str" : "14182110",
      "id" : 14182110
    }, {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 105, 114 ],
      "id_str" : "787975",
      "id" : 787975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nickelcityruby2013",
      "indices" : [ 26, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/r1KcVSfAa2",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2690-nickelcityruby2013-software-craftsmanship-s-missing-link-apprenticeship",
      "display_url" : "confreaks.com\/videos\/2690-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396830759429746689",
  "text" : "RT @confreaks: New Video! #nickelcityruby2013 - Software Craftsmanship's Missing Link: Apprenticeship by @mathiasx http:\/\/t.co\/r1KcVSfAa2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mathiasx",
        "screen_name" : "mathiasx",
        "indices" : [ 90, 99 ],
        "id_str" : "787975",
        "id" : 787975
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nickelcityruby2013",
        "indices" : [ 11, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/r1KcVSfAa2",
        "expanded_url" : "http:\/\/confreaks.com\/videos\/2690-nickelcityruby2013-software-craftsmanship-s-missing-link-apprenticeship",
        "display_url" : "confreaks.com\/videos\/2690-ni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396818202732142592",
    "text" : "New Video! #nickelcityruby2013 - Software Craftsmanship's Missing Link: Apprenticeship by @mathiasx http:\/\/t.co\/r1KcVSfAa2",
    "id" : 396818202732142592,
    "created_at" : "2013-11-03 01:56:46 +0000",
    "user" : {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "protected" : false,
      "id_str" : "14182110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508193987417485312\/4FaFrBga_normal.png",
      "id" : 14182110,
      "verified" : false
    }
  },
  "id" : 396830759429746689,
  "created_at" : "2013-11-03 02:46:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 23, 34 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 35, 39 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/396761796927045632\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/VfyXPGBwJd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYGUwIBIUAAX6NW.jpg",
      "id_str" : "396761796692168704",
      "id" : 396761796692168704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYGUwIBIUAAX6NW.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VfyXPGBwJd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396761796927045632",
  "text" : "\u201CBest in Business\u201D \/cc @jasonfried @dhh http:\/\/t.co\/VfyXPGBwJd",
  "id" : 396761796927045632,
  "created_at" : "2013-11-02 22:12:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrence Pegulska",
      "screen_name" : "Husaria",
      "indices" : [ 3, 11 ],
      "id_str" : "16414352",
      "id" : 16414352
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 37, 49 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396443512721248256",
  "text" : "RT @Husaria: If Ron Burgundy went to @whereslloyd's, he would never thrown out that burrito",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lloyd Taco Trucks",
        "screen_name" : "whereslloyd",
        "indices" : [ 24, 36 ],
        "id_str" : "156689065",
        "id" : 156689065
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396441486633361408",
    "text" : "If Ron Burgundy went to @whereslloyd's, he would never thrown out that burrito",
    "id" : 396441486633361408,
    "created_at" : "2013-11-02 00:59:50 +0000",
    "user" : {
      "name" : "Terrence Pegulska",
      "screen_name" : "Husaria",
      "protected" : false,
      "id_str" : "16414352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554989000071860225\/e8D_8ou4_normal.jpeg",
      "id" : 16414352,
      "verified" : false
    }
  },
  "id" : 396443512721248256,
  "created_at" : "2013-11-02 01:07:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 35, 41 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396431589342588928",
  "text" : "Runaway Jim &gt; Shaft tease? This @phish show is already getting goofy.",
  "id" : 396431589342588928,
  "created_at" : "2013-11-02 00:20:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396299203686592512",
  "text" : "@juliepagano hopefully we'll have your video up soon!",
  "id" : 396299203686592512,
  "created_at" : "2013-11-01 15:34:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 59, 70 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/s2mh5DLRbk",
      "expanded_url" : "http:\/\/www.theatlanticwire.com\/politics\/2013\/10\/how-spot-reptilians-runing-us-government\/71020\/",
      "display_url" : "theatlanticwire.com\/politics\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396275652115959808",
  "text" : "Looks like @bquarant was right: http:\/\/t.co\/s2mh5DLRbk \/cc @kevinpurdy",
  "id" : 396275652115959808,
  "created_at" : "2013-11-01 14:00:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 15, 28 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175081458195628032",
  "text" : "I won't go all @herpderpedia with the Buffalo tweets. The derpness awaits.",
  "id" : 175081458195628032,
  "created_at" : "2012-03-01 04:54:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "indices" : [ 3, 15 ],
      "id_str" : "261031908",
      "id" : 261031908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175081312703623169",
  "text" : "RT @HeyRaChaCha: Either Kim Jong Un is nuking my neighborhood, or we just got one MOTHER of a lightning strike. #Buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 95, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175080230925508608",
    "text" : "Either Kim Jong Un is nuking my neighborhood, or we just got one MOTHER of a lightning strike. #Buffalo",
    "id" : 175080230925508608,
    "created_at" : "2012-03-01 04:49:14 +0000",
    "user" : {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "protected" : false,
      "id_str" : "261031908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1262350601\/userpic-5725-100x100_normal.png",
      "id" : 261031908,
      "verified" : false
    }
  },
  "id" : 175081312703623169,
  "created_at" : "2012-03-01 04:53:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Sponholz",
      "screen_name" : "AdamSponholz",
      "indices" : [ 3, 16 ],
      "id_str" : "163206481",
      "id" : 163206481
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "outkast",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175081230457511938",
  "text" : "RT @AdamSponholz: Was that thunder or.bombs over buffalo? #outkast",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "outkast",
        "indices" : [ 40, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175080872674992128",
    "text" : "Was that thunder or.bombs over buffalo? #outkast",
    "id" : 175080872674992128,
    "created_at" : "2012-03-01 04:51:47 +0000",
    "user" : {
      "name" : "Adam Sponholz",
      "screen_name" : "AdamSponholz",
      "protected" : false,
      "id_str" : "163206481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000623438859\/2b128a3241e395917d4c6fc94b81345d_normal.jpeg",
      "id" : 163206481,
      "verified" : false
    }
  },
  "id" : 175081230457511938,
  "created_at" : "2012-03-01 04:53:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vancy Pants",
      "screen_name" : "vancy_pants",
      "indices" : [ 3, 15 ],
      "id_str" : "1668634464",
      "id" : 1668634464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175081164120395778",
  "text" : "RT @Vancy_Pants: buffalo about to be poopin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175080543766069248",
    "text" : "buffalo about to be poopin",
    "id" : 175080543766069248,
    "created_at" : "2012-03-01 04:50:29 +0000",
    "user" : {
      "name" : "Vance Hamilton",
      "screen_name" : "Vanceee_",
      "protected" : false,
      "id_str" : "258262307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539488105711935488\/ZMVqlhYJ_normal.jpeg",
      "id" : 258262307,
      "verified" : false
    }
  },
  "id" : 175081164120395778,
  "created_at" : "2012-03-01 04:52:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 11, 18 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175080633406734336",
  "geo" : { },
  "id_str" : "175080949162319873",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @nb3004 this is how twitter trends start right?",
  "id" : 175080949162319873,
  "in_reply_to_status_id" : 175080633406734336,
  "created_at" : "2012-03-01 04:52:05 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175079885096747008",
  "text" : "WTF thunder and lightning in #buffalo. Never heard windows rattle that hard before.",
  "id" : 175079885096747008,
  "created_at" : "2012-03-01 04:47:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175077555785842691",
  "geo" : { },
  "id_str" : "175078011341783040",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos oh man, I wish we would get some more snow here. Dying to unleash Ged into some deep powder.",
  "id" : 175078011341783040,
  "in_reply_to_status_id" : 175077555785842691,
  "created_at" : "2012-03-01 04:40:25 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/azXFt13N",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?desktop_uri=%2Fwatch%3Fv%3D_sUeGC-8dyk&v=_sUeGC-8dyk&gl=US",
      "display_url" : "m.youtube.com\/#\/watch?deskto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175077528237645825",
  "text" : "Quadrotor robots playing 007 theme song. All hope of preventing robot takeover is now gone. http:\/\/t.co\/azXFt13N",
  "id" : 175077528237645825,
  "created_at" : "2012-03-01 04:38:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175024825079836673",
  "geo" : { },
  "id_str" : "175024892201279489",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton that's way too much effort.",
  "id" : 175024892201279489,
  "in_reply_to_status_id" : 175024825079836673,
  "created_at" : "2012-03-01 01:09:20 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 0, 11 ],
      "id_str" : "21390942",
      "id" : 21390942
    }, {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 12, 24 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175013117837844481",
  "geo" : { },
  "id_str" : "175024850019155969",
  "in_reply_to_user_id" : 21390942,
  "text" : "@jamesuriah @codeofficer uh. uh...",
  "id" : 175024850019155969,
  "in_reply_to_status_id" : 175013117837844481,
  "created_at" : "2012-03-01 01:09:10 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/175022938511253504\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/T4izTGOX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am3Ob23CIAAtGW8.png",
      "id_str" : "175022938515447808",
      "id" : 175022938515447808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am3Ob23CIAAtGW8.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/T4izTGOX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175022509559783424",
  "geo" : { },
  "id_str" : "175022938511253504",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton \/etc\/hosts. I actually want to redirect to a site i made on localhost but couldn't figure it out http:\/\/t.co\/T4izTGOX",
  "id" : 175022938511253504,
  "in_reply_to_status_id" : 175022509559783424,
  "created_at" : "2012-03-01 01:01:37 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175022076439175169",
  "geo" : { },
  "id_str" : "175022632931045377",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight most folks I talk to with serious wow habits scoff at that number. some won't even admit to how many days\/months.",
  "id" : 175022632931045377,
  "in_reply_to_status_id" : 175022076439175169,
  "created_at" : "2012-03-01 01:00:22 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175021473306648576",
  "geo" : { },
  "id_str" : "175021871731978240",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight i kicked WoW cold turkey too, after ~100+ days played (had full tier 1 druid, some tier 2!). One relapse so far. :)",
  "id" : 175021871731978240,
  "in_reply_to_status_id" : 175021473306648576,
  "created_at" : "2012-03-01 00:57:20 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175021602323439616",
  "text" : "That being said, Tumblr and Twitter are not blocked. I don't seem to get lost in those too much.",
  "id" : 175021602323439616,
  "created_at" : "2012-03-01 00:56:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175020938868436994",
  "text" : "Hoping a few weeks of this will kick this stupid reflex and help me focus.",
  "id" : 175020938868436994,
  "created_at" : "2012-03-01 00:53:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175020834862268416",
  "text" : "HN, Reddit, and Facebook blocking on my laptop has been going extremely well. Still opening up a new tab every so often for them though.",
  "id" : 175020834862268416,
  "created_at" : "2012-03-01 00:53:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174959515177992192",
  "text" : "I think this song has a \"drop\". Is that what it's called now? \"Fokin drop\" ?",
  "id" : 174959515177992192,
  "created_at" : "2012-02-29 20:49:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174899743045070848",
  "geo" : { },
  "id_str" : "174914584174538752",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary the gifs make it way better...I should just make the .key available too. if you want it, yell.",
  "id" : 174914584174538752,
  "in_reply_to_status_id" : 174899743045070848,
  "created_at" : "2012-02-29 17:51:01 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/174737421945147392\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/JAZQWOvY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmzKwmyCEAALU-I.png",
      "id_str" : "174737421953536000",
      "id" : 174737421953536000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmzKwmyCEAALU-I.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/JAZQWOvY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174737421945147392",
  "text" : "Once again, at the Castle, this time as an Arch. +6 Mjol\/+5 Crysknife, lots of spells and loaded. Gonna be rough. http:\/\/t.co\/JAZQWOvY",
  "id" : 174737421945147392,
  "created_at" : "2012-02-29 06:07:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 0, 8 ],
      "id_str" : "270917610",
      "id" : 270917610
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Brent LaRowe",
      "screen_name" : "Blarowe",
      "indices" : [ 20, 28 ],
      "id_str" : "15080463",
      "id" : 15080463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174628542104092674",
  "geo" : { },
  "id_str" : "174674713942032384",
  "in_reply_to_user_id" : 270917610,
  "text" : "@alarowe @37signals @Blarowe zomg! congrats!",
  "id" : 174674713942032384,
  "in_reply_to_status_id" : 174628542104092674,
  "created_at" : "2012-02-29 01:57:51 +0000",
  "in_reply_to_screen_name" : "alarowe",
  "in_reply_to_user_id_str" : "270917610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/PC5nar1R",
      "expanded_url" : "http:\/\/ihasahotdog.files.wordpress.com\/2011\/08\/funny-dog-pictures-awww-yeah.jpg",
      "display_url" : "ihasahotdog.files.wordpress.com\/2011\/08\/funny-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174663599497809920",
  "text" : "The voice of Camaxtli booms: \"Use my gift wisely!\" Z - a war hammer named Mjollnir. http:\/\/t.co\/PC5nar1R",
  "id" : 174663599497809920,
  "created_at" : "2012-02-29 01:13:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/hn3OsYf9",
      "expanded_url" : "http:\/\/instagr.am\/p\/HkVvODs6lX\/",
      "display_url" : "instagr.am\/p\/HkVvODs6lX\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8921506518, -78.894828558 ]
  },
  "id_str" : "174637416353771520",
  "text" : "Triple triple!  @ Buffalo Barkyard - Dog Park http:\/\/t.co\/hn3OsYf9",
  "id" : 174637416353771520,
  "created_at" : "2012-02-28 23:29:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 13, 25 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174591216896327681",
  "geo" : { },
  "id_str" : "174593393287118849",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @SaraJChipps this list is ripe for disruption",
  "id" : 174593393287118849,
  "in_reply_to_status_id" : 174591216896327681,
  "created_at" : "2012-02-28 20:34:43 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney a. crispell",
      "screen_name" : "whitneyarlene",
      "indices" : [ 3, 17 ],
      "id_str" : "213939016",
      "id" : 213939016
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitneyarlene\/status\/174567086125875200\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OaSoqHCg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Amwv1waCAAA5c6i.jpg",
      "id_str" : "174567086134263808",
      "id" : 174567086134263808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Amwv1waCAAA5c6i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1532,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/OaSoqHCg"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174568715688488960",
  "text" : "RT @whitneyarlene: Here's the statue that was damaged & then stolen. David is offering a personal reward for information. #Buffalo http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/whitneyarlene\/status\/174567086125875200\/photo\/1",
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/OaSoqHCg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Amwv1waCAAA5c6i.jpg",
        "id_str" : "174567086134263808",
        "id" : 174567086134263808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Amwv1waCAAA5c6i.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1532,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/OaSoqHCg"
      } ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174567086125875200",
    "text" : "Here's the statue that was damaged & then stolen. David is offering a personal reward for information. #Buffalo http:\/\/t.co\/OaSoqHCg",
    "id" : 174567086125875200,
    "created_at" : "2012-02-28 18:50:12 +0000",
    "user" : {
      "name" : "whitney a. crispell",
      "screen_name" : "whitneyarlene",
      "protected" : false,
      "id_str" : "213939016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2837107442\/ae2f9b28e3b6c3a004332b88b782c56e_normal.jpeg",
      "id" : 213939016,
      "verified" : false
    }
  },
  "id" : 174568715688488960,
  "created_at" : "2012-02-28 18:56:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 11, 19 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174551883002818560",
  "geo" : { },
  "id_str" : "174561280974262272",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh @kkuchta didn't realize you did vimbits! nice work!",
  "id" : 174561280974262272,
  "in_reply_to_status_id" : 174551883002818560,
  "created_at" : "2012-02-28 18:27:07 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 3, 12 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Eo84xVY2",
      "expanded_url" : "http:\/\/youtu.be\/44NQkFJaEuE",
      "display_url" : "youtu.be\/44NQkFJaEuE"
    } ]
  },
  "geo" : { },
  "id_str" : "174521173785313280",
  "text" : "RT @ivyhurst: Mahna Mahna... http:\/\/t.co\/Eo84xVY2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/Eo84xVY2",
        "expanded_url" : "http:\/\/youtu.be\/44NQkFJaEuE",
        "display_url" : "youtu.be\/44NQkFJaEuE"
      } ]
    },
    "geo" : { },
    "id_str" : "174520315689435136",
    "text" : "Mahna Mahna... http:\/\/t.co\/Eo84xVY2",
    "id" : 174520315689435136,
    "created_at" : "2012-02-28 15:44:20 +0000",
    "user" : {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "protected" : false,
      "id_str" : "16450420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046828495\/faf20934e2c12bc4d6a562b38c193d0f_normal.jpeg",
      "id" : 16450420,
      "verified" : false
    }
  },
  "id" : 174521173785313280,
  "created_at" : "2012-02-28 15:47:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174520554383097857",
  "text" : "Day 2 of standing desk, knees feeling shitty. Need a mat. Obviously a good change so far!",
  "id" : 174520554383097857,
  "created_at" : "2012-02-28 15:45:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Hardy",
      "screen_name" : "packagethief",
      "indices" : [ 0, 13 ],
      "id_str" : "12089482",
      "id" : 12089482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174193919381356544",
  "geo" : { },
  "id_str" : "174353642160275456",
  "in_reply_to_user_id" : 12089482,
  "text" : "@packagethief \uD83D\uDEAD",
  "id" : 174353642160275456,
  "in_reply_to_status_id" : 174193919381356544,
  "created_at" : "2012-02-28 04:42:02 +0000",
  "in_reply_to_screen_name" : "packagethief",
  "in_reply_to_user_id_str" : "12089482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174305854873546754",
  "geo" : { },
  "id_str" : "174309601536258048",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave just got stomped by a mumak. game over man.",
  "id" : 174309601536258048,
  "in_reply_to_status_id" : 174305854873546754,
  "created_at" : "2012-02-28 01:47:02 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174304542412906496",
  "geo" : { },
  "id_str" : "174305701634641921",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave lets hope! although yesterday i broke a wand of wishing, and then choked to death on a C-ration :(",
  "id" : 174305701634641921,
  "in_reply_to_status_id" : 174304542412906496,
  "created_at" : "2012-02-28 01:31:32 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/174303471854559232\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/jEfhFjSI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmtAFYtCIAAPNAl.jpg",
      "id_str" : "174303471858753536",
      "id" : 174303471858753536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmtAFYtCIAAPNAl.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/jEfhFjSI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174303471854559232",
  "text" : "The voice of Venus booms: \"Use my gift wisely!\" M - an athame named Magicbane. http:\/\/t.co\/jEfhFjSI",
  "id" : 174303471854559232,
  "created_at" : "2012-02-28 01:22:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/eVgmGZMH",
      "expanded_url" : "http:\/\/instagr.am\/p\/HhxYD0M6gN\/",
      "display_url" : "instagr.am\/p\/HhxYD0M6gN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8921506518, -78.894828558 ]
  },
  "id_str" : "174276118436786178",
  "text" : "Another triple night!  @ Buffalo Barkyard - Dog Park http:\/\/t.co\/eVgmGZMH",
  "id" : 174276118436786178,
  "created_at" : "2012-02-27 23:33:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Dorrans",
      "screen_name" : "blowdart",
      "indices" : [ 0, 9 ],
      "id_str" : "1847381",
      "id" : 1847381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174164295037362177",
  "geo" : { },
  "id_str" : "174164850853945344",
  "in_reply_to_user_id" : 1847381,
  "text" : "@blowdart yes, this might be the next one to go",
  "id" : 174164850853945344,
  "in_reply_to_status_id" : 174164295037362177,
  "created_at" : "2012-02-27 16:11:50 +0000",
  "in_reply_to_screen_name" : "blowdart",
  "in_reply_to_user_id_str" : "1847381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/uB6Fdneg",
      "expanded_url" : "http:\/\/facebook.com",
      "display_url" : "facebook.com"
    } ]
  },
  "geo" : { },
  "id_str" : "174164074454720513",
  "text" : "Now also blocking http:\/\/t.co\/uB6Fdneg. Trying to shut down my reflex site visiting.",
  "id" : 174164074454720513,
  "created_at" : "2012-02-27 16:08:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174150324314062848",
  "geo" : { },
  "id_str" : "174163946348101632",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez actually pow's \"it works\" but yes, haha!",
  "id" : 174163946348101632,
  "in_reply_to_status_id" : 174150324314062848,
  "created_at" : "2012-02-27 16:08:15 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/Zuun1rgG",
      "expanded_url" : "http:\/\/news.ycombinator.com",
      "display_url" : "news.ycombinator.com"
    }, {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/iVv69j1V",
      "expanded_url" : "http:\/\/reddit.com",
      "display_url" : "reddit.com"
    } ]
  },
  "geo" : { },
  "id_str" : "174145856398831616",
  "text" : "Redirected http:\/\/t.co\/Zuun1rgG and http:\/\/t.co\/iVv69j1V to 127.0.0.1. Might keep it this way on my laptop.",
  "id" : 174145856398831616,
  "created_at" : "2012-02-27 14:56:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/kjPVd8Zk",
      "expanded_url" : "http:\/\/instagr.am\/p\/Hf05drM6ju\/",
      "display_url" : "instagr.am\/p\/Hf05drM6ju\/"
    } ]
  },
  "geo" : { },
  "id_str" : "174002463421112320",
  "text" : "Triple Conjuction tonight: Jupiter, Moon, Venus! \uD83D\uDC7E http:\/\/t.co\/kjPVd8Zk",
  "id" : 174002463421112320,
  "created_at" : "2012-02-27 05:26:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/scQ451oy",
      "expanded_url" : "http:\/\/alt.org\/nethack\/userdata\/D\/DoctorNick\/dumplog\/1330286604.nh343.txt",
      "display_url" : "alt.org\/nethack\/userda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173987434483302400",
  "text" : "YASD. First choking death. :( http:\/\/t.co\/scQ451oy",
  "id" : 173987434483302400,
  "created_at" : "2012-02-27 04:26:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/173971449370001409\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/I2iUz6f0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmoSHIkCQAILEsg.png",
      "id_str" : "173971449374195714",
      "id" : 173971449374195714,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmoSHIkCQAILEsg.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/I2iUz6f0"
    } ],
    "hashtags" : [ {
      "text" : "nethack",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173971449370001409",
  "text" : "3 Liches on this Ranger's Castle run. Let's hope this wand of death has 3 charges. #nethack http:\/\/t.co\/I2iUz6f0",
  "id" : 173971449370001409,
  "created_at" : "2012-02-27 03:23:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173952201763459072",
  "geo" : { },
  "id_str" : "173953176272240640",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems with &gt; 2 expansions the scores get high quickly",
  "id" : 173953176272240640,
  "in_reply_to_status_id" : 173952201763459072,
  "created_at" : "2012-02-27 02:10:43 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173952496119709696",
  "geo" : { },
  "id_str" : "173953021728927744",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn basically, build a map with tiles, score on completed features (roads, towns, etc)",
  "id" : 173953021728927744,
  "in_reply_to_status_id" : 173952496119709696,
  "created_at" : "2012-02-27 02:10:06 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 69, 79 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/173950599472222210\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/3psEHyae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Amn_JgpCEAI80xe.jpg",
      "id_str" : "173950599476416514",
      "id" : 173950599476416514,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Amn_JgpCEAI80xe.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3psEHyae"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173950599472222210",
  "text" : "Take 2! Inns, Cathedrals, Bridges, Castles, Bazaars. 246 to 213, got @aquaranto back :) http:\/\/t.co\/3psEHyae",
  "id" : 173950599472222210,
  "created_at" : "2012-02-27 02:00:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 38, 48 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/173937128735129601\/photo\/1",
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/GISuPOU4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Amny5aPCQAIoLPF.jpg",
      "id_str" : "173937128739323906",
      "id" : 173937128739323906,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Amny5aPCQAIoLPF.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GISuPOU4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173937128735129601",
  "text" : "Got whipped in vanilla Carcassonne by @aquaranto. http:\/\/t.co\/GISuPOU4",
  "id" : 173937128735129601,
  "created_at" : "2012-02-27 01:06:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173810329745240064",
  "text" : "Never a good way to start a Nethack game: \"Click! Barf triggers something.  The boulder hits Barf!  Barf is killed!\"",
  "id" : 173810329745240064,
  "created_at" : "2012-02-26 16:43:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    }, {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 14, 21 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173551934354100226",
  "geo" : { },
  "id_str" : "173556054850936832",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham @marick yep! How did you end up at that FAQ? what did you search for?",
  "id" : 173556054850936832,
  "in_reply_to_status_id" : 173551934354100226,
  "created_at" : "2012-02-25 23:52:42 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173233729588838400",
  "text" : "Pimps. Autocorrect!!!!",
  "id" : 173233729588838400,
  "created_at" : "2012-02-25 02:31:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/173206938610434050\/photo\/1",
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/XbscbG9e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmdaywDCAAAeogf.jpg",
      "id_str" : "173206938614628352",
      "id" : 173206938614628352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmdaywDCAAAeogf.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/XbscbG9e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173206938610434050",
  "text" : "ERR::DOGFISHOVERFLOW http:\/\/t.co\/XbscbG9e",
  "id" : 173206938610434050,
  "created_at" : "2012-02-25 00:45:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173196863518945281",
  "text" : "Dogfish tap takeover at Cole's tonight. Next level bar maneuver.",
  "id" : 173196863518945281,
  "created_at" : "2012-02-25 00:05:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173124478358917120",
  "text" : "There's two types of programmers out there: ones that choose to shit all over someone else's work, constantly, and those that have humility.",
  "id" : 173124478358917120,
  "created_at" : "2012-02-24 19:17:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerred",
      "screen_name" : "justicefries",
      "indices" : [ 0, 13 ],
      "id_str" : "188906158",
      "id" : 188906158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173122301884252160",
  "geo" : { },
  "id_str" : "173122697935593472",
  "in_reply_to_user_id" : 188906158,
  "text" : "@justicefries ...what",
  "id" : 173122697935593472,
  "in_reply_to_status_id" : 173122301884252160,
  "created_at" : "2012-02-24 19:10:42 +0000",
  "in_reply_to_screen_name" : "justicefries",
  "in_reply_to_user_id_str" : "188906158",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Munson",
      "screen_name" : "BenatNewdigs",
      "indices" : [ 0, 13 ],
      "id_str" : "17048048",
      "id" : 17048048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173107650953871361",
  "geo" : { },
  "id_str" : "173116440969355264",
  "in_reply_to_user_id" : 17048048,
  "text" : "@BenatNewdigs yeah, trying to get it going! saw a decent place today. just is going to take time.",
  "id" : 173116440969355264,
  "in_reply_to_status_id" : 173107650953871361,
  "created_at" : "2012-02-24 18:45:50 +0000",
  "in_reply_to_screen_name" : "BenatNewdigs",
  "in_reply_to_user_id_str" : "17048048",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frankelly Valdez",
      "screen_name" : "frankyurban",
      "indices" : [ 0, 12 ],
      "id_str" : "24889964",
      "id" : 24889964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173092970457870336",
  "geo" : { },
  "id_str" : "173094061794787328",
  "in_reply_to_user_id" : 24889964,
  "text" : "@frankyurban thanks! :D",
  "id" : 173094061794787328,
  "in_reply_to_status_id" : 173092970457870336,
  "created_at" : "2012-02-24 17:16:54 +0000",
  "in_reply_to_screen_name" : "frankyurban",
  "in_reply_to_user_id_str" : "24889964",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 0, 10 ],
      "id_str" : "21003240",
      "id" : 21003240
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 21, 35 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173090116015882241",
  "geo" : { },
  "id_str" : "173090973310648322",
  "in_reply_to_user_id" : 21003240,
  "text" : "@BlockClub whoa! \/cc @joshuaclayton @IselaMariaPhoto look familiar?",
  "id" : 173090973310648322,
  "in_reply_to_status_id" : 173090116015882241,
  "created_at" : "2012-02-24 17:04:38 +0000",
  "in_reply_to_screen_name" : "BlockClub",
  "in_reply_to_user_id_str" : "21003240",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/aSrCmmwk",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3120-all-hands-battlestations",
      "display_url" : "37signals.com\/svn\/posts\/3120\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173071513807884288",
  "text" : "RT @37signals: Interior designers take note: The workspaces of 37signals http:\/\/t.co\/aSrCmmwk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/aSrCmmwk",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3120-all-hands-battlestations",
        "display_url" : "37signals.com\/svn\/posts\/3120\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "173070436916150274",
    "text" : "Interior designers take note: The workspaces of 37signals http:\/\/t.co\/aSrCmmwk",
    "id" : 173070436916150274,
    "created_at" : "2012-02-24 15:43:02 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 173071513807884288,
  "created_at" : "2012-02-24 15:47:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173071213306982402",
  "geo" : { },
  "id_str" : "173071319309627393",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark the order was random! :( sorry!",
  "id" : 173071319309627393,
  "in_reply_to_status_id" : 173071213306982402,
  "created_at" : "2012-02-24 15:46:32 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173052396665180161",
  "geo" : { },
  "id_str" : "173055479726096386",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors looking at a place for coworking today...sorry!",
  "id" : 173055479726096386,
  "in_reply_to_status_id" : 173052396665180161,
  "created_at" : "2012-02-24 14:43:36 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/173043011540881408\/photo\/1",
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/VW7CHMWO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmbFs8ICEAAXt-N.jpg",
      "id_str" : "173043011545075712",
      "id" : 173043011545075712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmbFs8ICEAAXt-N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/VW7CHMWO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173043011540881408",
  "text" : "iOS groups can have emoji for names! http:\/\/t.co\/VW7CHMWO",
  "id" : 173043011540881408,
  "created_at" : "2012-02-24 13:54:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172893788002451456",
  "geo" : { },
  "id_str" : "172893901529681920",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat i think there's a huge opportunity for an OSS project to destroy it.",
  "id" : 172893901529681920,
  "in_reply_to_status_id" : 172893788002451456,
  "created_at" : "2012-02-24 04:01:32 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172888962262773760",
  "text" : "My dog has separation anxiety with toys he loses under things.",
  "id" : 172888962262773760,
  "created_at" : "2012-02-24 03:41:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172854928342126593",
  "geo" : { },
  "id_str" : "172858994594021376",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak oh hell yes. Naan?",
  "id" : 172858994594021376,
  "in_reply_to_status_id" : 172854928342126593,
  "created_at" : "2012-02-24 01:42:50 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "citricsquid",
      "screen_name" : "citricsquid",
      "indices" : [ 0, 12 ],
      "id_str" : "15494939",
      "id" : 15494939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/Rgqa5We6",
      "expanded_url" : "http:\/\/www.codyfauser.com\/2008\/7\/4\/rails-http-status-code-to-symbol-mapping",
      "display_url" : "codyfauser.com\/2008\/7\/4\/rails\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "172707007105732608",
  "geo" : { },
  "id_str" : "172809510107348992",
  "in_reply_to_user_id" : 15494939,
  "text" : "@citricsquid gorgeous. is it OSS? would you accept patches for adding rails status code symbols? (http:\/\/t.co\/Rgqa5We6)",
  "id" : 172809510107348992,
  "in_reply_to_status_id" : 172707007105732608,
  "created_at" : "2012-02-23 22:26:12 +0000",
  "in_reply_to_screen_name" : "citricsquid",
  "in_reply_to_user_id_str" : "15494939",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "citricsquid",
      "screen_name" : "citricsquid",
      "indices" : [ 3, 15 ],
      "id_str" : "15494939",
      "id" : 15494939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/SeADrpsq",
      "expanded_url" : "http:\/\/httpstatus.es\/",
      "display_url" : "httpstatus.es"
    } ]
  },
  "geo" : { },
  "id_str" : "172809332780580866",
  "text" : "RT @citricsquid: http:\/\/t.co\/SeADrpsq I couldn't find a good simple directory of HTTP statuses that included ietf description, so I made ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/SeADrpsq",
        "expanded_url" : "http:\/\/httpstatus.es\/",
        "display_url" : "httpstatus.es"
      } ]
    },
    "geo" : { },
    "id_str" : "172707007105732608",
    "text" : "http:\/\/t.co\/SeADrpsq I couldn't find a good simple directory of HTTP statuses that included ietf description, so I made this. xoxo.",
    "id" : 172707007105732608,
    "created_at" : "2012-02-23 15:38:53 +0000",
    "user" : {
      "name" : "citricsquid",
      "screen_name" : "citricsquid",
      "protected" : false,
      "id_str" : "15494939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569520951419600896\/NrFUcLXm_normal.jpeg",
      "id" : 15494939,
      "verified" : false
    }
  },
  "id" : 172809332780580866,
  "created_at" : "2012-02-23 22:25:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 3, 9 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/Ik7wLoPd",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/q1qii\/want_to_try_your_hand_at_writing_exploits_try\/c3u09kc",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172723959761076224",
  "text" : "RT @dozba: Umad, Reddit? http:\/\/t.co\/Ik7wLoPd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http:\/\/t.co\/Ik7wLoPd",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/q1qii\/want_to_try_your_hand_at_writing_exploits_try\/c3u09kc",
        "display_url" : "reddit.com\/r\/programming\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172722896324661248",
    "text" : "Umad, Reddit? http:\/\/t.co\/Ik7wLoPd",
    "id" : 172722896324661248,
    "created_at" : "2012-02-23 16:42:02 +0000",
    "user" : {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "protected" : false,
      "id_str" : "44282335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537809944037191681\/kPC8Noli_normal.jpeg",
      "id" : 44282335,
      "verified" : false
    }
  },
  "id" : 172723959761076224,
  "created_at" : "2012-02-23 16:46:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 0, 9 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172532283822182400",
  "geo" : { },
  "id_str" : "172533848687656962",
  "in_reply_to_user_id" : 16450420,
  "text" : "@ivyhurst agreed! The barkyard was awesome. Driving, not so much",
  "id" : 172533848687656962,
  "in_reply_to_status_id" : 172532283822182400,
  "created_at" : "2012-02-23 04:10:49 +0000",
  "in_reply_to_screen_name" : "ivyhurst",
  "in_reply_to_user_id_str" : "16450420",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172528492062310400",
  "geo" : { },
  "id_str" : "172533331748061184",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits what about spacer gifs?",
  "id" : 172533331748061184,
  "in_reply_to_status_id" : 172528492062310400,
  "created_at" : "2012-02-23 04:08:46 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isis madrid",
      "screen_name" : "mellamoisis",
      "indices" : [ 0, 12 ],
      "id_str" : "20410276",
      "id" : 20410276
    }, {
      "name" : "Kate Peruzzini",
      "screen_name" : "KeightP",
      "indices" : [ 13, 21 ],
      "id_str" : "18247553",
      "id" : 18247553
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 27, 34 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Jason Evanish",
      "screen_name" : "Evanish",
      "indices" : [ 39, 47 ],
      "id_str" : "38380590",
      "id" : 38380590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172412771927982080",
  "geo" : { },
  "id_str" : "172533167289401345",
  "in_reply_to_user_id" : 20410276,
  "text" : "@mellamoisis @KeightP hey, @Croaky and @Evanish should have plenty of juicy info",
  "id" : 172533167289401345,
  "in_reply_to_status_id" : 172412771927982080,
  "created_at" : "2012-02-23 04:08:07 +0000",
  "in_reply_to_screen_name" : "mellamoisis",
  "in_reply_to_user_id_str" : "20410276",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172409809298145280",
  "geo" : { },
  "id_str" : "172412130732146688",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene would you mind posting this with your thoughts on the google group?",
  "id" : 172412130732146688,
  "in_reply_to_status_id" : 172409809298145280,
  "created_at" : "2012-02-22 20:07:09 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172395600401268738",
  "geo" : { },
  "id_str" : "172406051864444928",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene yeah i dont see how this helps. it's still in the repo, regardless.",
  "id" : 172406051864444928,
  "in_reply_to_status_id" : 172395600401268738,
  "created_at" : "2012-02-22 19:43:00 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 95, 109 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/uN1uariQ",
      "expanded_url" : "http:\/\/i6.photobucket.com\/albums\/y218\/brownies4life\/aaaaah\/4312538836_c050dd2c4e_b.jpg",
      "display_url" : "i6.photobucket.com\/albums\/y218\/br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172393186503835648",
  "text" : "I think it's time to diversify the \"wat\" meme.   Let's try on \"\u00BFque?\" http:\/\/t.co\/uN1uariQ \/cc @garybernhardt",
  "id" : 172393186503835648,
  "created_at" : "2012-02-22 18:51:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/3qL52L5u",
      "expanded_url" : "http:\/\/robey.lag.net\/2010\/06\/21\/mensch-font.html",
      "display_url" : "robey.lag.net\/2010\/06\/21\/men\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "172387690501775362",
  "geo" : { },
  "id_str" : "172392536252493826",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant monospace ftw! i prefer Mensch. (menlo with some slight variations) http:\/\/t.co\/3qL52L5u",
  "id" : 172392536252493826,
  "in_reply_to_status_id" : 172387690501775362,
  "created_at" : "2012-02-22 18:49:18 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172353498158088193",
  "geo" : { },
  "id_str" : "172353969337810944",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant whoaaaaaaaa",
  "id" : 172353969337810944,
  "in_reply_to_status_id" : 172353498158088193,
  "created_at" : "2012-02-22 16:16:03 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172235298409955328",
  "geo" : { },
  "id_str" : "172326820966965249",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene not sure how that's different.",
  "id" : 172326820966965249,
  "in_reply_to_status_id" : 172235298409955328,
  "created_at" : "2012-02-22 14:28:10 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172208575513497600",
  "text" : "Having one of those \"brain please shut up so I can get sleep\" nights. Oh wait, this happens almost every night.",
  "id" : 172208575513497600,
  "created_at" : "2012-02-22 06:38:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172151668014723072",
  "geo" : { },
  "id_str" : "172198191826087936",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene taking longer for the app to clone is worth that reliability, IMO",
  "id" : 172198191826087936,
  "in_reply_to_status_id" : 172151668014723072,
  "created_at" : "2012-02-22 05:57:02 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/t7WFqMGN",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "172151668014723072",
  "geo" : { },
  "id_str" : "172197911508164609",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene it's because if http:\/\/t.co\/t7WFqMGN is down...and we can't deploy the site...KABOOM",
  "id" : 172197911508164609,
  "in_reply_to_status_id" : 172151668014723072,
  "created_at" : "2012-02-22 05:55:56 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4rQ9U3R1",
      "expanded_url" : "http:\/\/thew.me\/writing\/developers-should-design\/",
      "display_url" : "thew.me\/writing\/develo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172181982711787521",
  "text" : "RT @sstephenson: \u201CThere is value in being able to write software while being legitimately concerned with the \u2026 ability to use it.\u201D http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/4rQ9U3R1",
        "expanded_url" : "http:\/\/thew.me\/writing\/developers-should-design\/",
        "display_url" : "thew.me\/writing\/develo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172161988644962307",
    "text" : "\u201CThere is value in being able to write software while being legitimately concerned with the \u2026 ability to use it.\u201D http:\/\/t.co\/4rQ9U3R1",
    "id" : 172161988644962307,
    "created_at" : "2012-02-22 03:33:11 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 172181982711787521,
  "created_at" : "2012-02-22 04:52:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172159645081804801",
  "geo" : { },
  "id_str" : "172161158260862976",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw worf is just too much of a badass.",
  "id" : 172161158260862976,
  "in_reply_to_status_id" : 172159645081804801,
  "created_at" : "2012-02-22 03:29:53 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172147084613521408",
  "geo" : { },
  "id_str" : "172147391099703298",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis Bye! :(",
  "id" : 172147391099703298,
  "in_reply_to_status_id" : 172147084613521408,
  "created_at" : "2012-02-22 02:35:11 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 0, 8 ],
      "id_str" : "14408469",
      "id" : 14408469
    }, {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 9, 20 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172139968611889153",
  "geo" : { },
  "id_str" : "172140731459321856",
  "in_reply_to_user_id" : 14408469,
  "text" : "@uptonic @jasonfried this would be fun for tadalist...some of the dragging is strange (pinch feels awkward)",
  "id" : 172140731459321856,
  "in_reply_to_status_id" : 172139968611889153,
  "created_at" : "2012-02-22 02:08:43 +0000",
  "in_reply_to_screen_name" : "uptonic",
  "in_reply_to_user_id_str" : "14408469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172140246098657280",
  "geo" : { },
  "id_str" : "172140628870823937",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems most likely!",
  "id" : 172140628870823937,
  "in_reply_to_status_id" : 172140246098657280,
  "created_at" : "2012-02-22 02:08:18 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172138424101371904",
  "geo" : { },
  "id_str" : "172138759561814017",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene we're still on 3.0. there's a branch for 3.1, feel free to get hacking :)",
  "id" : 172138759561814017,
  "in_reply_to_status_id" : 172138424101371904,
  "created_at" : "2012-02-22 02:00:53 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172132737782788096",
  "geo" : { },
  "id_str" : "172136627332845568",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine or get a tiny car! Yaris FTW",
  "id" : 172136627332845568,
  "in_reply_to_status_id" : 172132737782788096,
  "created_at" : "2012-02-22 01:52:24 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 39, 48 ],
      "id_str" : "729936824",
      "id" : 729936824
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 50, 57 ],
      "id_str" : "14237099",
      "id" : 14237099
    }, {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 59, 72 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172135430492397572",
  "geo" : { },
  "id_str" : "172136304392417281",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems oh snap! Congrats! say hi to @hgimenez, @geemus, @ryandotsmith !!",
  "id" : 172136304392417281,
  "in_reply_to_status_id" : 172135430492397572,
  "created_at" : "2012-02-22 01:51:07 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172081783754604544",
  "geo" : { },
  "id_str" : "172083567776641024",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits i chortled",
  "id" : 172083567776641024,
  "in_reply_to_status_id" : 172081783754604544,
  "created_at" : "2012-02-21 22:21:34 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172081487028559872",
  "text" : "I apparently am terrible at sed.",
  "id" : 172081487028559872,
  "created_at" : "2012-02-21 22:13:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/EB7PQm6y",
      "expanded_url" : "http:\/\/mothereff.in\/js-variables#%E0%B2%A0%5f%E0%B2%A0",
      "display_url" : "mothereff.in\/js-variables#%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172079469765464065",
  "text" : "JAVASCRIPT! http:\/\/t.co\/EB7PQm6y",
  "id" : 172079469765464065,
  "created_at" : "2012-02-21 22:05:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garun Vagidov",
      "screen_name" : "garunvagidov",
      "indices" : [ 0, 13 ],
      "id_str" : "24246639",
      "id" : 24246639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/RyvmWKSH",
      "expanded_url" : "http:\/\/refreshingcities.org\/",
      "display_url" : "refreshingcities.org"
    } ]
  },
  "in_reply_to_status_id_str" : "171962030155247616",
  "geo" : { },
  "id_str" : "171993876033310720",
  "in_reply_to_user_id" : 24246639,
  "text" : "@garunvagidov is it different from Refresh? http:\/\/t.co\/RyvmWKSH pretty well known outside of Buffalo...sounds confusing to me.",
  "id" : 171993876033310720,
  "in_reply_to_status_id" : 171962030155247616,
  "created_at" : "2012-02-21 16:25:10 +0000",
  "in_reply_to_screen_name" : "garunvagidov",
  "in_reply_to_user_id_str" : "24246639",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel Martin",
      "screen_name" : "GabrielMtn",
      "indices" : [ 0, 11 ],
      "id_str" : "139358992",
      "id" : 139358992
    }, {
      "name" : "Refresh Buffalo",
      "screen_name" : "RefreshBuffalo",
      "indices" : [ 12, 27 ],
      "id_str" : "351268761",
      "id" : 351268761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171823040584359936",
  "geo" : { },
  "id_str" : "171823515526381568",
  "in_reply_to_user_id" : 139358992,
  "text" : "@GabrielMtn @RefreshBuffalo ah, cool! Any humans behind this? Would love to meet them.",
  "id" : 171823515526381568,
  "in_reply_to_status_id" : 171823040584359936,
  "created_at" : "2012-02-21 05:08:13 +0000",
  "in_reply_to_screen_name" : "GabrielMtn",
  "in_reply_to_user_id_str" : "139358992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel Martin",
      "screen_name" : "GabrielMtn",
      "indices" : [ 0, 11 ],
      "id_str" : "139358992",
      "id" : 139358992
    }, {
      "name" : "Refresh Buffalo",
      "screen_name" : "RefreshBuffalo",
      "indices" : [ 12, 27 ],
      "id_str" : "351268761",
      "id" : 351268761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171818609310576640",
  "geo" : { },
  "id_str" : "171821433410949120",
  "in_reply_to_user_id" : 139358992,
  "text" : "@GabrielMtn @RefreshBuffalo kind of confused what this is...a meetup?",
  "id" : 171821433410949120,
  "in_reply_to_status_id" : 171818609310576640,
  "created_at" : "2012-02-21 04:59:56 +0000",
  "in_reply_to_screen_name" : "GabrielMtn",
  "in_reply_to_user_id_str" : "139358992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Kiddy",
      "screen_name" : "jonkiddy",
      "indices" : [ 0, 9 ],
      "id_str" : "34032105",
      "id" : 34032105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171807619722387456",
  "geo" : { },
  "id_str" : "171816025820643328",
  "in_reply_to_user_id" : 34032105,
  "text" : "@jonkiddy I once was asked the difference between &lt;tr&gt; and &lt;td&gt; since I listed HTML on my resume.",
  "id" : 171816025820643328,
  "in_reply_to_status_id" : 171807619722387456,
  "created_at" : "2012-02-21 04:38:27 +0000",
  "in_reply_to_screen_name" : "jonkiddy",
  "in_reply_to_user_id_str" : "34032105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Kiddy",
      "screen_name" : "jonkiddy",
      "indices" : [ 0, 9 ],
      "id_str" : "34032105",
      "id" : 34032105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171807823687200768",
  "geo" : { },
  "id_str" : "171815772363046912",
  "in_reply_to_user_id" : 34032105,
  "text" : "@jonkiddy another selling point of coworking :)",
  "id" : 171815772363046912,
  "in_reply_to_status_id" : 171807823687200768,
  "created_at" : "2012-02-21 04:37:26 +0000",
  "in_reply_to_screen_name" : "jonkiddy",
  "in_reply_to_user_id_str" : "34032105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "Seed Coworking",
      "screen_name" : "seedcowork",
      "indices" : [ 9, 20 ],
      "id_str" : "403807816",
      "id" : 403807816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171813586161770496",
  "geo" : { },
  "id_str" : "171814826509742080",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright @seedcowork would love to talk!",
  "id" : 171814826509742080,
  "in_reply_to_status_id" : 171813586161770496,
  "created_at" : "2012-02-21 04:33:41 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171811851112415233",
  "text" : "Really excited to get Coworking in Buffalo figured out and started. Learning a lot in the process. Pumped to do something positive locally.",
  "id" : 171811851112415233,
  "created_at" : "2012-02-21 04:21:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 0, 10 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171758828076007424",
  "geo" : { },
  "id_str" : "171774932429180928",
  "in_reply_to_user_id" : 19725644,
  "text" : "@neiltyson definitely saw it here in Buffalo, was just on the lake. It's on the approach for BUF too, thought it was an airplane!",
  "id" : 171774932429180928,
  "in_reply_to_status_id" : 171758828076007424,
  "created_at" : "2012-02-21 01:55:09 +0000",
  "in_reply_to_screen_name" : "neiltyson",
  "in_reply_to_user_id_str" : "19725644",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171744173630816256",
  "geo" : { },
  "id_str" : "171744710170394624",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella definitely wrong photog then. Plenty do full rights.",
  "id" : 171744710170394624,
  "in_reply_to_status_id" : 171744173630816256,
  "created_at" : "2012-02-20 23:55:04 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 3, 14 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171741199571488768",
  "text" : "RT @joshsusser: This Open Source stuff is hard. Nothing is ever perfect, but I'm grateful to all the people who work so hard to make it  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171739971219243008",
    "text" : "This Open Source stuff is hard. Nothing is ever perfect, but I'm grateful to all the people who work so hard to make it as useable as it is.",
    "id" : 171739971219243008,
    "created_at" : "2012-02-20 23:36:14 +0000",
    "user" : {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "protected" : false,
      "id_str" : "35954885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502547892230316032\/njGJleCw_normal.png",
      "id" : 35954885,
      "verified" : false
    }
  },
  "id" : 171741199571488768,
  "created_at" : "2012-02-20 23:41:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 67, 75 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 77, 87 ],
      "id_str" : "15031577",
      "id" : 15031577
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 89, 97 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171738791315374080",
  "text" : "More thanks are deserved for those doing thankless jobs. Here's to @evanphx, @tcopeland, @drbrain for constantly helping with RubyGems. \uD83C\uDF7B",
  "id" : 171738791315374080,
  "created_at" : "2012-02-20 23:31:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/DeaH0b16",
      "expanded_url" : "http:\/\/scratching.psybermonkey.net\/2011\/02\/perl-how-to-uninstall-delete-perl.html",
      "display_url" : "scratching.psybermonkey.net\/2011\/02\/perl-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171645184508035072",
  "text" : "Absolute stupidity: I have to install a cpan module to remove a cpan module. http:\/\/t.co\/DeaH0b16",
  "id" : 171645184508035072,
  "created_at" : "2012-02-20 17:19:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171639523514662912",
  "geo" : { },
  "id_str" : "171640401181159424",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv Normal scroll, like every other computer ever has always worked.",
  "id" : 171640401181159424,
  "in_reply_to_status_id" : 171639523514662912,
  "created_at" : "2012-02-20 17:00:35 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/171640306415054848\/photo\/1",
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/K7XV9FBi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmHJ8wVCMAACQTQ.png",
      "id_str" : "171640306419249152",
      "id" : 171640306419249152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmHJ8wVCMAACQTQ.png",
      "sizes" : [ {
        "h" : 145,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 252
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 252
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 252
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 252
      } ],
      "display_url" : "pic.twitter.com\/K7XV9FBi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171640306415054848",
  "text" : "You stay classy, Buffalo bars. http:\/\/t.co\/K7XV9FBi",
  "id" : 171640306415054848,
  "created_at" : "2012-02-20 17:00:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 11, 18 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171625074103820288",
  "geo" : { },
  "id_str" : "171626040718921729",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @nb3004 wat :(",
  "id" : 171626040718921729,
  "in_reply_to_status_id" : 171625074103820288,
  "created_at" : "2012-02-20 16:03:31 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171623347665375232",
  "geo" : { },
  "id_str" : "171624556228902913",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy yes, it must have taken several man-years to set up that animation",
  "id" : 171624556228902913,
  "in_reply_to_status_id" : 171623347665375232,
  "created_at" : "2012-02-20 15:57:37 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/yeNsBn30",
      "expanded_url" : "http:\/\/guides.rubygems.org\/command-reference\/#gem_owner",
      "display_url" : "guides.rubygems.org\/command-refere\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "171618276235952128",
  "geo" : { },
  "id_str" : "171620168039006208",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey add them as an owner, remove yourself http:\/\/t.co\/yeNsBn30",
  "id" : 171620168039006208,
  "in_reply_to_status_id" : 171618276235952128,
  "created_at" : "2012-02-20 15:40:11 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/vQ2vu6yn",
      "expanded_url" : "http:\/\/29.media.tumblr.com\/tumblr_lzhwcwLK4P1r3s5n0o1_400.jpg",
      "display_url" : "29.media.tumblr.com\/tumblr_lzhwcwL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171462295602466816",
  "text" : "Current status: http:\/\/t.co\/vQ2vu6yn",
  "id" : 171462295602466816,
  "created_at" : "2012-02-20 05:12:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 0, 9 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171451570834255874",
  "geo" : { },
  "id_str" : "171461815912497152",
  "in_reply_to_user_id" : 1051521,
  "text" : "@migreyes woot! welcome!",
  "id" : 171461815912497152,
  "in_reply_to_status_id" : 171451570834255874,
  "created_at" : "2012-02-20 05:10:57 +0000",
  "in_reply_to_screen_name" : "migreyes",
  "in_reply_to_user_id_str" : "1051521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 11, 21 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171373456405966848",
  "geo" : { },
  "id_str" : "171459111597244416",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @magnachef sounds mega shady. restaurant seems like a bad idea.",
  "id" : 171459111597244416,
  "in_reply_to_status_id" : 171373456405966848,
  "created_at" : "2012-02-20 05:00:12 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171272471167770624",
  "geo" : { },
  "id_str" : "171279305593192448",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy now go put them all in front of whatever establishment originally posted them!",
  "id" : 171279305593192448,
  "in_reply_to_status_id" : 171272471167770624,
  "created_at" : "2012-02-19 17:05:43 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/170932317727105024\/photo\/1",
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/cXCSIdOi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Al9GCY8CIAIYFL3.jpg",
      "id_str" : "170932317731299330",
      "id" : 170932317731299330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Al9GCY8CIAIYFL3.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/cXCSIdOi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170932317727105024",
  "text" : "Elmwood Village...always friendly! http:\/\/t.co\/cXCSIdOi",
  "id" : 170932317727105024,
  "created_at" : "2012-02-18 18:06:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Whitmire",
      "screen_name" : "jwhitmire",
      "indices" : [ 0, 10 ],
      "id_str" : "23374570",
      "id" : 23374570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170911630090174464",
  "geo" : { },
  "id_str" : "170922103778983937",
  "in_reply_to_user_id" : 23374570,
  "text" : "@jwhitmire every Agricola set I see looks different.",
  "id" : 170922103778983937,
  "in_reply_to_status_id" : 170911630090174464,
  "created_at" : "2012-02-18 17:26:19 +0000",
  "in_reply_to_screen_name" : "jwhitmire",
  "in_reply_to_user_id_str" : "23374570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170736262922244098",
  "geo" : { },
  "id_str" : "170738069773881346",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams NOW YOU'RE A MAN, A MANLY MAN MAAAAAA NNNN",
  "id" : 170738069773881346,
  "in_reply_to_status_id" : 170736262922244098,
  "created_at" : "2012-02-18 05:15:02 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "djeisyn.luys.",
      "screen_name" : "canweriotnow",
      "indices" : [ 0, 13 ],
      "id_str" : "158606135",
      "id" : 158606135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170698821586780160",
  "geo" : { },
  "id_str" : "170700962636369920",
  "in_reply_to_user_id" : 158606135,
  "text" : "@canweriotnow Why does distribution matter?",
  "id" : 170700962636369920,
  "in_reply_to_status_id" : 170698821586780160,
  "created_at" : "2012-02-18 02:47:35 +0000",
  "in_reply_to_screen_name" : "canweriotnow",
  "in_reply_to_user_id_str" : "158606135",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170698121448398848",
  "text" : "Stupid idea: are there any OSS authentication services? Not OpenID. OAuth would be cool though.",
  "id" : 170698121448398848,
  "created_at" : "2012-02-18 02:36:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170697324320931841",
  "text" : "Anyone else's dog freak out the moment s\/he's off lead after a walk? FREEEDOM!!! Can't do dog park every day when it's muddy\/gross out :\/",
  "id" : 170697324320931841,
  "created_at" : "2012-02-18 02:33:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 0, 8 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170681167916445696",
  "geo" : { },
  "id_str" : "170683046276775937",
  "in_reply_to_user_id" : 13861042,
  "text" : "@jcoglan it may not have been you...still unsure. Deleted your gem anyway.",
  "id" : 170683046276775937,
  "in_reply_to_status_id" : 170681167916445696,
  "created_at" : "2012-02-18 01:36:24 +0000",
  "in_reply_to_screen_name" : "mountain_ghosts",
  "in_reply_to_user_id_str" : "13861042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "way mondo",
      "screen_name" : "waymondo",
      "indices" : [ 0, 9 ],
      "id_str" : "306309471",
      "id" : 306309471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170676484732755968",
  "geo" : { },
  "id_str" : "170677527822606336",
  "in_reply_to_user_id" : 306309471,
  "text" : "@waymondo agreed :(",
  "id" : 170677527822606336,
  "in_reply_to_status_id" : 170676484732755968,
  "created_at" : "2012-02-18 01:14:28 +0000",
  "in_reply_to_screen_name" : "waymondo",
  "in_reply_to_user_id_str" : "306309471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Cochran",
      "screen_name" : "sj26",
      "indices" : [ 0, 5 ],
      "id_str" : "6355522",
      "id" : 6355522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170676071052754945",
  "geo" : { },
  "id_str" : "170677427385798657",
  "in_reply_to_user_id" : 6355522,
  "text" : "@sj26 agreed, but as usual with rubygems it's high interest, low commitment. any help would be awesome.",
  "id" : 170677427385798657,
  "in_reply_to_status_id" : 170676071052754945,
  "created_at" : "2012-02-18 01:14:04 +0000",
  "in_reply_to_screen_name" : "sj26",
  "in_reply_to_user_id_str" : "6355522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/wWRCm6RM",
      "expanded_url" : "http:\/\/www.cigarettesandcoffee.com\/storage\/WhatUpWithThat_5.gif",
      "display_url" : "cigarettesandcoffee.com\/storage\/WhatUp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170677060342263808",
  "text" : "Current status: http:\/\/t.co\/wWRCm6RM",
  "id" : 170677060342263808,
  "created_at" : "2012-02-18 01:12:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erol ziya",
      "screen_name" : "eazynow",
      "indices" : [ 0, 8 ],
      "id_str" : "25806337",
      "id" : 25806337
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 28, 38 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170674820990763008",
  "geo" : { },
  "id_str" : "170676902581907456",
  "in_reply_to_user_id" : 25806337,
  "text" : "@eazynow sorry dude. follow @gemcutter for more updates.",
  "id" : 170676902581907456,
  "in_reply_to_status_id" : 170674820990763008,
  "created_at" : "2012-02-18 01:11:59 +0000",
  "in_reply_to_screen_name" : "eazynow",
  "in_reply_to_user_id_str" : "25806337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quinn Danita",
      "screen_name" : "pav_gup",
      "indices" : [ 0, 8 ],
      "id_str" : "3007386466",
      "id" : 3007386466
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 9, 18 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170675105708515328",
  "geo" : { },
  "id_str" : "170676842079064064",
  "in_reply_to_user_id" : 17742321,
  "text" : "@pav_gup @rubygems fixed now :)",
  "id" : 170676842079064064,
  "in_reply_to_status_id" : 170675105708515328,
  "created_at" : "2012-02-18 01:11:44 +0000",
  "in_reply_to_screen_name" : "pavgup",
  "in_reply_to_user_id_str" : "17742321",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Dean",
      "screen_name" : "colindean",
      "indices" : [ 0, 10 ],
      "id_str" : "14381906",
      "id" : 14381906
    }, {
      "name" : "Andrew Knapp",
      "screen_name" : "andrewknapp",
      "indices" : [ 11, 23 ],
      "id_str" : "27048029",
      "id" : 27048029
    }, {
      "name" : "Lame Men's Terms",
      "screen_name" : "timonk",
      "indices" : [ 24, 31 ],
      "id_str" : "15407095",
      "id" : 15407095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170675457824534528",
  "geo" : { },
  "id_str" : "170676791709663232",
  "in_reply_to_user_id" : 14381906,
  "text" : "@colindean @andrewknapp @timonk back up!",
  "id" : 170676791709663232,
  "in_reply_to_status_id" : 170675457824534528,
  "created_at" : "2012-02-18 01:11:32 +0000",
  "in_reply_to_screen_name" : "colindean",
  "in_reply_to_user_id_str" : "14381906",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip",
      "screen_name" : "parndt",
      "indices" : [ 0, 7 ],
      "id_str" : "15346781",
      "id" : 15346781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170675965826043904",
  "geo" : { },
  "id_str" : "170676758016831491",
  "in_reply_to_user_id" : 15346781,
  "text" : "@parndt we were down.",
  "id" : 170676758016831491,
  "in_reply_to_status_id" : 170675965826043904,
  "created_at" : "2012-02-18 01:11:24 +0000",
  "in_reply_to_screen_name" : "parndt",
  "in_reply_to_user_id_str" : "15346781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Fueger",
      "screen_name" : "mfueger",
      "indices" : [ 0, 8 ],
      "id_str" : "19920065",
      "id" : 19920065
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 28, 38 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170676350145937409",
  "geo" : { },
  "id_str" : "170676703847395328",
  "in_reply_to_user_id" : 19920065,
  "text" : "@mfueger we're back. follow @gemcutter for more updates.",
  "id" : 170676703847395328,
  "in_reply_to_status_id" : 170676350145937409,
  "created_at" : "2012-02-18 01:11:11 +0000",
  "in_reply_to_screen_name" : "mfueger",
  "in_reply_to_user_id_str" : "19920065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rlaneve",
      "screen_name" : "rlaneve",
      "indices" : [ 0, 8 ],
      "id_str" : "14850817",
      "id" : 14850817
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 36, 46 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170673331043975168",
  "geo" : { },
  "id_str" : "170674780666724354",
  "in_reply_to_user_id" : 14850817,
  "text" : "@rlaneve sorry dude. updates are on @gemcutter.",
  "id" : 170674780666724354,
  "in_reply_to_status_id" : 170673331043975168,
  "created_at" : "2012-02-18 01:03:33 +0000",
  "in_reply_to_screen_name" : "rlaneve",
  "in_reply_to_user_id_str" : "14850817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170674682184466433",
  "text" : "RT @gemcutter: We're back up in maintenance mode. Bundling, installing gems should work!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170674627360731137",
    "text" : "We're back up in maintenance mode. Bundling, installing gems should work!",
    "id" : 170674627360731137,
    "created_at" : "2012-02-18 01:02:56 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 170674682184466433,
  "created_at" : "2012-02-18 01:03:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clinton Blackburn",
      "screen_name" : "ccb621",
      "indices" : [ 0, 7 ],
      "id_str" : "43314773",
      "id" : 43314773
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 31, 41 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170673102617968640",
  "geo" : { },
  "id_str" : "170673807202320384",
  "in_reply_to_user_id" : 43314773,
  "text" : "@ccb621 Agreed. updates are on @gemcutter.",
  "id" : 170673807202320384,
  "in_reply_to_status_id" : 170673102617968640,
  "created_at" : "2012-02-18 00:59:41 +0000",
  "in_reply_to_screen_name" : "ccb621",
  "in_reply_to_user_id_str" : "43314773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Tutty",
      "screen_name" : "Caleb_T",
      "indices" : [ 0, 8 ],
      "id_str" : "24484407",
      "id" : 24484407
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 32, 42 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170673017276473344",
  "geo" : { },
  "id_str" : "170673238412763136",
  "in_reply_to_user_id" : 24484407,
  "text" : "@Caleb_T yes, it is. updates on @gemcutter. sorry :(",
  "id" : 170673238412763136,
  "in_reply_to_status_id" : 170673017276473344,
  "created_at" : "2012-02-18 00:57:25 +0000",
  "in_reply_to_screen_name" : "Caleb_T",
  "in_reply_to_user_id_str" : "24484407",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ikawe",
      "screen_name" : "Ikawe",
      "indices" : [ 0, 6 ],
      "id_str" : "16060798",
      "id" : 16060798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170672387971489794",
  "geo" : { },
  "id_str" : "170673042018676737",
  "in_reply_to_user_id" : 16060798,
  "text" : "@Ikawe 100% agree :(",
  "id" : 170673042018676737,
  "in_reply_to_status_id" : 170672387971489794,
  "created_at" : "2012-02-18 00:56:38 +0000",
  "in_reply_to_screen_name" : "Ikawe",
  "in_reply_to_user_id_str" : "16060798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Carleton",
      "screen_name" : "ScotterC",
      "indices" : [ 0, 9 ],
      "id_str" : "90048571",
      "id" : 90048571
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 50, 60 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170672495416971264",
  "geo" : { },
  "id_str" : "170672923844161536",
  "in_reply_to_user_id" : 90048571,
  "text" : "@ScotterC Same. we're working on it. please check @gemcutter.",
  "id" : 170672923844161536,
  "in_reply_to_status_id" : 170672495416971264,
  "created_at" : "2012-02-18 00:56:10 +0000",
  "in_reply_to_screen_name" : "ScotterC",
  "in_reply_to_user_id_str" : "90048571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Dean",
      "screen_name" : "colindean",
      "indices" : [ 0, 10 ],
      "id_str" : "14381906",
      "id" : 14381906
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 11, 20 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 48, 58 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170672746450259968",
  "geo" : { },
  "id_str" : "170672868072501248",
  "in_reply_to_user_id" : 14381906,
  "text" : "@colindean @rubygems yes, we do. updates are on @gemcutter.",
  "id" : 170672868072501248,
  "in_reply_to_status_id" : 170672746450259968,
  "created_at" : "2012-02-18 00:55:57 +0000",
  "in_reply_to_screen_name" : "colindean",
  "in_reply_to_user_id_str" : "14381906",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lancefisher",
      "screen_name" : "lancefisher",
      "indices" : [ 0, 12 ],
      "id_str" : "8312312",
      "id" : 8312312
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 36, 46 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170672333156126720",
  "geo" : { },
  "id_str" : "170672580825595904",
  "in_reply_to_user_id" : 8312312,
  "text" : "@lancefisher yes, sorry. updates at @gemcutter.",
  "id" : 170672580825595904,
  "in_reply_to_status_id" : 170672333156126720,
  "created_at" : "2012-02-18 00:54:48 +0000",
  "in_reply_to_screen_name" : "lancefisher",
  "in_reply_to_user_id_str" : "8312312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Jones",
      "screen_name" : "nickj89",
      "indices" : [ 0, 8 ],
      "id_str" : "18743288",
      "id" : 18743288
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 32, 42 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170671732393390080",
  "geo" : { },
  "id_str" : "170671879378575363",
  "in_reply_to_user_id" : 18743288,
  "text" : "@nickj89 yes, it is. updates at @gemcutter.",
  "id" : 170671879378575363,
  "in_reply_to_status_id" : 170671732393390080,
  "created_at" : "2012-02-18 00:52:01 +0000",
  "in_reply_to_screen_name" : "nickj89",
  "in_reply_to_user_id_str" : "18743288",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuhiro Takahashi",
      "screen_name" : "a_takahashi",
      "indices" : [ 0, 12 ],
      "id_str" : "44639783",
      "id" : 44639783
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 13, 22 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 38, 48 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170671089599528960",
  "geo" : { },
  "id_str" : "170671708095787009",
  "in_reply_to_user_id" : 44639783,
  "text" : "@a_takahashi @rubygems updates are on @gemcutter.",
  "id" : 170671708095787009,
  "in_reply_to_status_id" : 170671089599528960,
  "created_at" : "2012-02-18 00:51:20 +0000",
  "in_reply_to_screen_name" : "a_takahashi",
  "in_reply_to_user_id_str" : "44639783",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuhiro Takahashi",
      "screen_name" : "a_takahashi",
      "indices" : [ 0, 12 ],
      "id_str" : "44639783",
      "id" : 44639783
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 13, 22 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170671089599528960",
  "geo" : { },
  "id_str" : "170671683307442178",
  "in_reply_to_user_id" : 44639783,
  "text" : "@a_takahashi @rubygems Sorry :(",
  "id" : 170671683307442178,
  "in_reply_to_status_id" : 170671089599528960,
  "created_at" : "2012-02-18 00:51:14 +0000",
  "in_reply_to_screen_name" : "a_takahashi",
  "in_reply_to_user_id_str" : "44639783",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "mbarnett",
      "indices" : [ 0, 9 ],
      "id_str" : "1674271",
      "id" : 1674271
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 56, 66 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170671333636706304",
  "geo" : { },
  "id_str" : "170671661501251587",
  "in_reply_to_user_id" : 1674271,
  "text" : "@mbarnett No, it's not. We're working on it. Updates on @gemcutter.",
  "id" : 170671661501251587,
  "in_reply_to_status_id" : 170671333636706304,
  "created_at" : "2012-02-18 00:51:09 +0000",
  "in_reply_to_screen_name" : "mbarnett",
  "in_reply_to_user_id_str" : "1674271",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Ostler",
      "screen_name" : "philostler",
      "indices" : [ 0, 11 ],
      "id_str" : "48106029",
      "id" : 48106029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170671481360089088",
  "geo" : { },
  "id_str" : "170671602537738240",
  "in_reply_to_user_id" : 48106029,
  "text" : "@PhilOstler Yes, literally every day.",
  "id" : 170671602537738240,
  "in_reply_to_status_id" : 170671481360089088,
  "created_at" : "2012-02-18 00:50:55 +0000",
  "in_reply_to_screen_name" : "philostler",
  "in_reply_to_user_id_str" : "48106029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marius Ducea",
      "screen_name" : "mariusducea",
      "indices" : [ 0, 12 ],
      "id_str" : "16829516",
      "id" : 16829516
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 45, 55 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170671009320546305",
  "geo" : { },
  "id_str" : "170671410384076800",
  "in_reply_to_user_id" : 16829516,
  "text" : "@mariusducea you're not the only one. follow @gemcutter for more updates.",
  "id" : 170671410384076800,
  "in_reply_to_status_id" : 170671009320546305,
  "created_at" : "2012-02-18 00:50:09 +0000",
  "in_reply_to_screen_name" : "mariusducea",
  "in_reply_to_user_id_str" : "16829516",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eleather",
      "screen_name" : "eleather",
      "indices" : [ 0, 9 ],
      "id_str" : "14480307",
      "id" : 14480307
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 68, 78 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170666493925793792",
  "geo" : { },
  "id_str" : "170671225029398529",
  "in_reply_to_user_id" : 14480307,
  "text" : "@eleather sorry about the hassle :( We're working on it. updates at @gemcutter.",
  "id" : 170671225029398529,
  "in_reply_to_status_id" : 170666493925793792,
  "created_at" : "2012-02-18 00:49:25 +0000",
  "in_reply_to_screen_name" : "eleather",
  "in_reply_to_user_id_str" : "14480307",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 9, 18 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 43, 53 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170670102319087616",
  "geo" : { },
  "id_str" : "170671130431066112",
  "in_reply_to_user_id" : 121188310,
  "text" : "@enthooz @rubygems no, it's not. check out @gemcutter.",
  "id" : 170671130431066112,
  "in_reply_to_status_id" : 170670102319087616,
  "created_at" : "2012-02-18 00:49:03 +0000",
  "in_reply_to_screen_name" : "andrewashbacher",
  "in_reply_to_user_id_str" : "121188310",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Gilson",
      "screen_name" : "d1plo1d",
      "indices" : [ 0, 8 ],
      "id_str" : "171253446",
      "id" : 171253446
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 9, 18 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 73, 83 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170670621502607360",
  "geo" : { },
  "id_str" : "170671081621950464",
  "in_reply_to_user_id" : 171253446,
  "text" : "@d1plo1d @rubygems yep! we're dealing with the downtime here. updates at @gemcutter.",
  "id" : 170671081621950464,
  "in_reply_to_status_id" : 170670621502607360,
  "created_at" : "2012-02-18 00:48:51 +0000",
  "in_reply_to_screen_name" : "d1plo1d",
  "in_reply_to_user_id_str" : "171253446",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Ostler",
      "screen_name" : "philostler",
      "indices" : [ 0, 11 ],
      "id_str" : "48106029",
      "id" : 48106029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170670784514236417",
  "geo" : { },
  "id_str" : "170670993373806593",
  "in_reply_to_user_id" : 48106029,
  "text" : "@PhilOstler seriously :( we're working on it.",
  "id" : 170670993373806593,
  "in_reply_to_status_id" : 170670784514236417,
  "created_at" : "2012-02-18 00:48:30 +0000",
  "in_reply_to_screen_name" : "philostler",
  "in_reply_to_user_id_str" : "48106029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "r\/o\\b",
      "screen_name" : "robacarp",
      "indices" : [ 0, 9 ],
      "id_str" : "17901884",
      "id" : 17901884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170670478141300737",
  "geo" : { },
  "id_str" : "170670731485642754",
  "in_reply_to_user_id" : 17901884,
  "text" : "@robacarp sorry for the hassle. we're working on it.",
  "id" : 170670731485642754,
  "in_reply_to_status_id" : 170670478141300737,
  "created_at" : "2012-02-18 00:47:27 +0000",
  "in_reply_to_screen_name" : "robacarp",
  "in_reply_to_user_id_str" : "17901884",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Dean",
      "screen_name" : "colindean",
      "indices" : [ 0, 10 ],
      "id_str" : "14381906",
      "id" : 14381906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170669734373756928",
  "geo" : { },
  "id_str" : "170670034790776833",
  "in_reply_to_user_id" : 14381906,
  "text" : "@colindean we're working on it. sorry for the hassle.",
  "id" : 170670034790776833,
  "in_reply_to_status_id" : 170669734373756928,
  "created_at" : "2012-02-18 00:44:41 +0000",
  "in_reply_to_screen_name" : "colindean",
  "in_reply_to_user_id_str" : "14381906",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gonzalo Correa",
      "screen_name" : "gonchimon",
      "indices" : [ 0, 10 ],
      "id_str" : "68459455",
      "id" : 68459455
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 16, 26 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170669099079311361",
  "geo" : { },
  "id_str" : "170669973688164352",
  "in_reply_to_user_id" : 68459455,
  "text" : "@gonchimon yes, @gemcutter.",
  "id" : 170669973688164352,
  "in_reply_to_status_id" : 170669099079311361,
  "created_at" : "2012-02-18 00:44:27 +0000",
  "in_reply_to_screen_name" : "gonchimon",
  "in_reply_to_user_id_str" : "68459455",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 68 ],
      "url" : "https:\/\/t.co\/sp4duoTn",
      "expanded_url" : "https:\/\/img.skitch.com\/20120218-tgyfafyih1t4edax2e77hbux7u.jpg",
      "display_url" : "img.skitch.com\/20120218-tgyfa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170669118947721217",
  "text" : "RT @gemcutter: For the curious, what happened: https:\/\/t.co\/sp4duoTn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 53 ],
        "url" : "https:\/\/t.co\/sp4duoTn",
        "expanded_url" : "https:\/\/img.skitch.com\/20120218-tgyfafyih1t4edax2e77hbux7u.jpg",
        "display_url" : "img.skitch.com\/20120218-tgyfa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170669076664954881",
    "text" : "For the curious, what happened: https:\/\/t.co\/sp4duoTn",
    "id" : 170669076664954881,
    "created_at" : "2012-02-18 00:40:53 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 170669118947721217,
  "created_at" : "2012-02-18 00:41:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gonzalo Correa",
      "screen_name" : "gonchimon",
      "indices" : [ 0, 10 ],
      "id_str" : "68459455",
      "id" : 68459455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170668508131237888",
  "geo" : { },
  "id_str" : "170668812172144640",
  "in_reply_to_user_id" : 68459455,
  "text" : "@gonchimon we're down right now. looking into it. :(",
  "id" : 170668812172144640,
  "in_reply_to_status_id" : 170668508131237888,
  "created_at" : "2012-02-18 00:39:50 +0000",
  "in_reply_to_screen_name" : "gonchimon",
  "in_reply_to_user_id_str" : "68459455",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 0, 8 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 14, 22 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 23, 33 ],
      "id_str" : "15031577",
      "id" : 15031577
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 34, 40 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170667593500336128",
  "geo" : { },
  "id_str" : "170668295245139968",
  "in_reply_to_user_id" : 13861042,
  "text" : "@jcoglan send @evanphx @tcopeland @cmeik some beer since they have to fix it.",
  "id" : 170668295245139968,
  "in_reply_to_status_id" : 170667593500336128,
  "created_at" : "2012-02-18 00:37:47 +0000",
  "in_reply_to_screen_name" : "mountain_ghosts",
  "in_reply_to_user_id_str" : "13861042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trotter Cashion",
      "screen_name" : "cashion",
      "indices" : [ 0, 8 ],
      "id_str" : "1226651",
      "id" : 1226651
    }, {
      "name" : "Jeremy Dunck",
      "screen_name" : "jdunck",
      "indices" : [ 9, 16 ],
      "id_str" : "837641",
      "id" : 837641
    }, {
      "name" : "Junya Ogu\u00AEa",
      "screen_name" : "junya",
      "indices" : [ 17, 23 ],
      "id_str" : "2799501",
      "id" : 2799501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170667142134497280",
  "geo" : { },
  "id_str" : "170667707971284992",
  "in_reply_to_user_id" : 1226651,
  "text" : "@cashion @jdunck @junya we're working on it. sorry for the hassle.",
  "id" : 170667707971284992,
  "in_reply_to_status_id" : 170667142134497280,
  "created_at" : "2012-02-18 00:35:27 +0000",
  "in_reply_to_screen_name" : "cashion",
  "in_reply_to_user_id_str" : "1226651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 3, 16 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170666586313732096",
  "text" : "RT @Horse_ebooks: Congratulations!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170666394835357696",
    "text" : "Congratulations!",
    "id" : 170666394835357696,
    "created_at" : "2012-02-18 00:30:14 +0000",
    "user" : {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "protected" : false,
      "id_str" : "174958347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096005346\/1_normal.jpg",
      "id" : 174958347,
      "verified" : false
    }
  },
  "id" : 170666586313732096,
  "created_at" : "2012-02-18 00:30:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 0, 8 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170663811198619648",
  "geo" : { },
  "id_str" : "170666390292938753",
  "in_reply_to_user_id" : 13861042,
  "text" : "@jcoglan congrats, i think you killed the site.",
  "id" : 170666390292938753,
  "in_reply_to_status_id" : 170663811198619648,
  "created_at" : "2012-02-18 00:30:12 +0000",
  "in_reply_to_screen_name" : "mountain_ghosts",
  "in_reply_to_user_id_str" : "13861042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170665558767972352",
  "text" : "RT @gemcutter: Site's down, we're looking into why. Sorry everyone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170665354647961600",
    "text" : "Site's down, we're looking into why. Sorry everyone.",
    "id" : 170665354647961600,
    "created_at" : "2012-02-18 00:26:06 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 170665558767972352,
  "created_at" : "2012-02-18 00:26:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170614099393257472",
  "geo" : { },
  "id_str" : "170614685505302529",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens Yep! Moved in November.",
  "id" : 170614685505302529,
  "in_reply_to_status_id" : 170614099393257472,
  "created_at" : "2012-02-17 21:04:45 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Dorrans",
      "screen_name" : "blowdart",
      "indices" : [ 0, 9 ],
      "id_str" : "1847381",
      "id" : 1847381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170612838270902272",
  "geo" : { },
  "id_str" : "170613268073824256",
  "in_reply_to_user_id" : 1847381,
  "text" : "@blowdart Basically! But yeah, the perils of public work spaces. :)",
  "id" : 170613268073824256,
  "in_reply_to_status_id" : 170612838270902272,
  "created_at" : "2012-02-17 20:59:07 +0000",
  "in_reply_to_screen_name" : "blowdart",
  "in_reply_to_user_id_str" : "1847381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170610318291124224",
  "text" : "One reason I can't wait to get coworking in Buffalo figured out: the horde of loud high school kids that roll into Spot daily around 3pm.",
  "id" : 170610318291124224,
  "created_at" : "2012-02-17 20:47:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170607101691961345",
  "geo" : { },
  "id_str" : "170608029023215616",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu d3 (ne\u00E9 protovis) is fantastic too.",
  "id" : 170608029023215616,
  "in_reply_to_status_id" : 170607101691961345,
  "created_at" : "2012-02-17 20:38:18 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Florenzano",
      "screen_name" : "ericflo",
      "indices" : [ 0, 8 ],
      "id_str" : "14087951",
      "id" : 14087951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170584718436339713",
  "geo" : { },
  "id_str" : "170601476773785600",
  "in_reply_to_user_id" : 14087951,
  "text" : "@ericflo agreed! luckily most of the hard stuff is on the server side. but yeah, in general: programming is hard, let's go shopping! :)",
  "id" : 170601476773785600,
  "in_reply_to_status_id" : 170584718436339713,
  "created_at" : "2012-02-17 20:12:16 +0000",
  "in_reply_to_screen_name" : "ericflo",
  "in_reply_to_user_id_str" : "14087951",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170592065258930176",
  "text" : "Just noticed this in my `env`. WTF? COM_GOOGLE_CHROME_FRAMEWORK_SERVICE_PROCESS\/USERS\/QRUSH\/LIBRARY\/APPLICATION_SUPPORT\/GOOGLE\/CHROME_SOCKET",
  "id" : 170592065258930176,
  "created_at" : "2012-02-17 19:34:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170583162244702208",
  "geo" : { },
  "id_str" : "170583314313379841",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh well duh, caching is hard :)",
  "id" : 170583314313379841,
  "in_reply_to_status_id" : 170583162244702208,
  "created_at" : "2012-02-17 19:00:06 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Florenzano",
      "screen_name" : "ericflo",
      "indices" : [ 0, 8 ],
      "id_str" : "14087951",
      "id" : 14087951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170582156312190976",
  "geo" : { },
  "id_str" : "170583002307497984",
  "in_reply_to_user_id" : 14087951,
  "text" : "@ericflo as someone in those trenches, i'd love to hear what made it difficult. any thoughts?",
  "id" : 170583002307497984,
  "in_reply_to_status_id" : 170582156312190976,
  "created_at" : "2012-02-17 18:58:51 +0000",
  "in_reply_to_screen_name" : "ericflo",
  "in_reply_to_user_id_str" : "14087951",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina Benedetti",
      "screen_name" : "cristibenedetti",
      "indices" : [ 0, 16 ],
      "id_str" : "25901252",
      "id" : 25901252
    }, {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 29, 38 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170566825799725057",
  "geo" : { },
  "id_str" : "170567113591885824",
  "in_reply_to_user_id" : 25901252,
  "text" : "@cristibenedetti are you and @hgimenez in buffalo!!!?",
  "id" : 170567113591885824,
  "in_reply_to_status_id" : 170566825799725057,
  "created_at" : "2012-02-17 17:55:43 +0000",
  "in_reply_to_screen_name" : "cristibenedetti",
  "in_reply_to_user_id_str" : "25901252",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Krueger",
      "screen_name" : "raykrueger",
      "indices" : [ 0, 11 ],
      "id_str" : "5778932",
      "id" : 5778932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170514252967329792",
  "geo" : { },
  "id_str" : "170517605692612608",
  "in_reply_to_user_id" : 5778932,
  "text" : "@raykrueger what book is that?",
  "id" : 170517605692612608,
  "in_reply_to_status_id" : 170514252967329792,
  "created_at" : "2012-02-17 14:38:59 +0000",
  "in_reply_to_screen_name" : "raykrueger",
  "in_reply_to_user_id_str" : "5778932",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170317450955587584",
  "geo" : { },
  "id_str" : "170340920171048960",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders this is what IRC and mailing lists are for ;)",
  "id" : 170340920171048960,
  "in_reply_to_status_id" : 170317450955587584,
  "created_at" : "2012-02-17 02:56:54 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BM5k",
      "screen_name" : "BM5k",
      "indices" : [ 0, 5 ],
      "id_str" : "39593",
      "id" : 39593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170316417177108480",
  "geo" : { },
  "id_str" : "170316644806168576",
  "in_reply_to_user_id" : 39593,
  "text" : "@BM5k wow, that app is nuts!",
  "id" : 170316644806168576,
  "in_reply_to_status_id" : 170316417177108480,
  "created_at" : "2012-02-17 01:20:27 +0000",
  "in_reply_to_screen_name" : "BM5k",
  "in_reply_to_user_id_str" : "39593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170229615326011392",
  "text" : "Ecstatic to have helped get Basecamp Next ready to launch. Even more excited to keep it greased, oiled, and awesome in years to come.",
  "id" : 170229615326011392,
  "created_at" : "2012-02-16 19:34:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/dPOwHwdV",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3111-basecamp-next-ui-preview",
      "display_url" : "37signals.com\/svn\/posts\/3111\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170228724028018689",
  "text" : "RT @rjs: The first public look at our new interface for Basecamp Next: http:\/\/t.co\/dPOwHwdV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/dPOwHwdV",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3111-basecamp-next-ui-preview",
        "display_url" : "37signals.com\/svn\/posts\/3111\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170228202772508673",
    "text" : "The first public look at our new interface for Basecamp Next: http:\/\/t.co\/dPOwHwdV",
    "id" : 170228202772508673,
    "created_at" : "2012-02-16 19:29:00 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 170228724028018689,
  "created_at" : "2012-02-16 19:31:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170188806983651328",
  "geo" : { },
  "id_str" : "170228572672372737",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair nope, sorry :(",
  "id" : 170228572672372737,
  "in_reply_to_status_id" : 170188806983651328,
  "created_at" : "2012-02-16 19:30:29 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/1RaJcMid",
      "expanded_url" : "http:\/\/penny-arcade.com\/patv\/episode\/so-you-want-to-be-a-developer-part-1",
      "display_url" : "penny-arcade.com\/patv\/episode\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170184536188141569",
  "text" : "Penny Arcade pretty much is nailing what's behind being a developer. http:\/\/t.co\/1RaJcMid",
  "id" : 170184536188141569,
  "created_at" : "2012-02-16 16:35:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170035260577419264",
  "text" : "New stupid twitter idea, robot to retweet misspellings of \"baby\" as \"babby\".",
  "id" : 170035260577419264,
  "created_at" : "2012-02-16 06:42:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169926978839916544",
  "geo" : { },
  "id_str" : "169928091613937664",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss she was working on a cool sweater like thing! ping her at amanda@quaran.to, perhaps she can whip something up",
  "id" : 169928091613937664,
  "in_reply_to_status_id" : 169926978839916544,
  "created_at" : "2012-02-15 23:36:28 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 28, 38 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169922085945212928",
  "text" : "Related: I need to convince @aquaranto to knit\/crochet up some badass dude articles.",
  "id" : 169922085945212928,
  "created_at" : "2012-02-15 23:12:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 16, 26 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/78rMuax4",
      "expanded_url" : "http:\/\/etsy.com\/shop\/QuCrafts",
      "display_url" : "etsy.com\/shop\/QuCrafts"
    } ]
  },
  "geo" : { },
  "id_str" : "169921941170438145",
  "text" : "Really proud of @aquaranto! Several items listed on her new Etsy store! Would appreciate sharing this w\/ gfs\/wives! http:\/\/t.co\/78rMuax4",
  "id" : 169921941170438145,
  "created_at" : "2012-02-15 23:12:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169897305741332480",
  "text" : "I can't wait for 20 years down the road to see how stupid all of these dumbasses with ear gauges look.",
  "id" : 169897305741332480,
  "created_at" : "2012-02-15 21:34:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169893840029884416",
  "geo" : { },
  "id_str" : "169894217466916864",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack basically seems like pinterest, for video only",
  "id" : 169894217466916864,
  "in_reply_to_status_id" : 169893840029884416,
  "created_at" : "2012-02-15 21:21:52 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/chill.com\/\" rel=\"nofollow\"\u003EChill\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/UHLXWfdl",
      "expanded_url" : "http:\/\/chill.com\/qrush\/post\/a4e5fcdad653486c962d6911782d4512\/trying-out-chill-keeping-funny-videos-in-one-place-lets-start-with-this-one?utm_campaign=user_post_sharing&utm_content=a4e5fcdad653486c962d6911782d4512&utm_medium=twitter&utm_source=users&utm_term=38158a8f69764b2db3ee82912e4525a1",
      "display_url" : "chill.com\/qrush\/post\/a4e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169893384784322560",
  "text" : "Trying out Chill, keeping funny videos in one place. Let's start with this one. http:\/\/t.co\/UHLXWfdl",
  "id" : 169893384784322560,
  "created_at" : "2012-02-15 21:18:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/9tPvqB5j",
      "expanded_url" : "http:\/\/s3-ak.buzzfed.com\/static\/enhanced\/terminal01\/2011\/11\/3\/17\/enhanced-buzz-20103-1320354484-3.jpg",
      "display_url" : "s3-ak.buzzfed.com\/static\/enhance\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169837675573022720",
  "text" : "Found my new office chair. http:\/\/t.co\/9tPvqB5j",
  "id" : 169837675573022720,
  "created_at" : "2012-02-15 17:37:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/169809661082603520\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/ui1Uy4aa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AltI_LCCEAAdxDZ.png",
      "id_str" : "169809661086797824",
      "id" : 169809661086797824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AltI_LCCEAAdxDZ.png",
      "sizes" : [ {
        "h" : 902,
        "resize" : "fit",
        "w" : 644
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 902,
        "resize" : "fit",
        "w" : 644
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ui1Uy4aa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/NuECuH84",
      "expanded_url" : "http:\/\/www.piqtur.com\/",
      "display_url" : "piqtur.com"
    } ]
  },
  "geo" : { },
  "id_str" : "169809661082603520",
  "text" : "Am I doing this right? (Trying out http:\/\/t.co\/NuECuH84) http:\/\/t.co\/ui1Uy4aa",
  "id" : 169809661082603520,
  "created_at" : "2012-02-15 15:45:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169652370710609920",
  "geo" : { },
  "id_str" : "169652538658922496",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens drinking driven development?",
  "id" : 169652538658922496,
  "in_reply_to_status_id" : 169652370710609920,
  "created_at" : "2012-02-15 05:21:31 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/FxI8q18r",
      "expanded_url" : "http:\/\/media-cdn.pinterest.com\/upload\/260997740874694549_nZk8SKjy_f.jpg",
      "display_url" : "media-cdn.pinterest.com\/upload\/2609977\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169616204049293312",
  "text" : "Current status: http:\/\/t.co\/FxI8q18r",
  "id" : 169616204049293312,
  "created_at" : "2012-02-15 02:57:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 11, 21 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169397180996657152",
  "geo" : { },
  "id_str" : "169544240827867137",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @magnachef awesome! thanks!",
  "id" : 169544240827867137,
  "in_reply_to_status_id" : 169397180996657152,
  "created_at" : "2012-02-14 22:11:11 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 19, 29 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/d2XoDIY3",
      "expanded_url" : "http:\/\/us.quaran.to\/",
      "display_url" : "us.quaran.to"
    } ]
  },
  "geo" : { },
  "id_str" : "169445082334896128",
  "text" : "Instead of getting @aquaranto a card for Valentine's Day, I made http:\/\/t.co\/d2XoDIY3 . &lt;3!",
  "id" : 169445082334896128,
  "created_at" : "2012-02-14 15:37:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/x5MXvSPd",
      "expanded_url" : "http:\/\/www.dos.ny.gov\/corps\/llccorp.html",
      "display_url" : "dos.ny.gov\/corps\/llccorp.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169266008190746625",
  "text" : "Absolutely dumbfounded that newspapers are involved in forming an LLC in NYS. Wow. Just...WTF. http:\/\/t.co\/x5MXvSPd",
  "id" : 169266008190746625,
  "created_at" : "2012-02-14 03:45:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : " Eric Lawrence ",
      "screen_name" : "ericlaw",
      "indices" : [ 12, 20 ],
      "id_str" : "5725652",
      "id" : 5725652
    }, {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 21, 33 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169229213155590144",
  "geo" : { },
  "id_str" : "169230069716357120",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin @ericlaw @jongalloway do www., twitter is mangling the URL",
  "id" : 169230069716357120,
  "in_reply_to_status_id" : 169229213155590144,
  "created_at" : "2012-02-14 01:22:47 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Eric Lawrence ",
      "screen_name" : "ericlaw",
      "indices" : [ 49, 57 ],
      "id_str" : "5725652",
      "id" : 5725652
    }, {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 59, 71 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/EIHO4dIN",
      "expanded_url" : "http:\/\/www.reddit.com",
      "display_url" : "reddit.com"
    } ]
  },
  "geo" : { },
  "id_str" : "169228419719106560",
  "text" : "curl -Is http:\/\/t.co\/EIHO4dIN | grep Server (via @ericlaw, @jongalloway)",
  "id" : 169228419719106560,
  "created_at" : "2012-02-14 01:16:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169180763680538625",
  "text" : "4 MacVim crashes today. WTF.",
  "id" : 169180763680538625,
  "created_at" : "2012-02-13 22:06:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169150048255475712",
  "text" : "\"they  want  to  set  up  telephonic  talk  on  the  phone.\" actual text from recruiter email.",
  "id" : 169150048255475712,
  "created_at" : "2012-02-13 20:04:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/sdJtcbgd",
      "expanded_url" : "http:\/\/path.com\/p\/3XrAsI",
      "display_url" : "path.com\/p\/3XrAsI"
    } ]
  },
  "geo" : { },
  "id_str" : "168755399586086912",
  "text" : "Finally got another Thundershirt. WITH RACING STRIPES. [pic] \u2014 http:\/\/t.co\/sdJtcbgd",
  "id" : 168755399586086912,
  "created_at" : "2012-02-12 17:56:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 9, 20 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168494554901774336",
  "geo" : { },
  "id_str" : "168723350481403904",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @luislavena ugh :(",
  "id" : 168723350481403904,
  "in_reply_to_status_id" : 168494554901774336,
  "created_at" : "2012-02-12 15:49:16 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/vaJERIin",
      "expanded_url" : "http:\/\/i.imgur.com\/v7Bgv.gif",
      "display_url" : "i.imgur.com\/v7Bgv.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "168722459015651329",
  "text" : "Current status: http:\/\/t.co\/vaJERIin",
  "id" : 168722459015651329,
  "created_at" : "2012-02-12 15:45:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168495386539986945",
  "geo" : { },
  "id_str" : "168517472755003393",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida will do !!",
  "id" : 168517472755003393,
  "in_reply_to_status_id" : 168495386539986945,
  "created_at" : "2012-02-12 02:11:11 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gisi",
      "screen_name" : "gisikw",
      "indices" : [ 0, 7 ],
      "id_str" : "14308739",
      "id" : 14308739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168470761282093056",
  "geo" : { },
  "id_str" : "168472304106479616",
  "in_reply_to_user_id" : 14308739,
  "text" : "@gisikw HTML and Notepad.",
  "id" : 168472304106479616,
  "in_reply_to_status_id" : 168470761282093056,
  "created_at" : "2012-02-11 23:11:42 +0000",
  "in_reply_to_screen_name" : "gisikw",
  "in_reply_to_user_id_str" : "14308739",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168459595860295680",
  "geo" : { },
  "id_str" : "168459850832035840",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv games.",
  "id" : 168459850832035840,
  "in_reply_to_status_id" : 168459595860295680,
  "created_at" : "2012-02-11 22:22:12 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stevens",
      "screen_name" : "kevdog",
      "indices" : [ 0, 7 ],
      "id_str" : "10696812",
      "id" : 10696812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168427686249762817",
  "geo" : { },
  "id_str" : "168457999759839233",
  "in_reply_to_user_id" : 10696812,
  "text" : "@kevdog oh yeah, i'm sold on one place, on elmwood. super excited.",
  "id" : 168457999759839233,
  "in_reply_to_status_id" : 168427686249762817,
  "created_at" : "2012-02-11 22:14:51 +0000",
  "in_reply_to_screen_name" : "kevdog",
  "in_reply_to_user_id_str" : "10696812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/0SVAMTnl",
      "expanded_url" : "http:\/\/ghettohikes.tumblr.com\/",
      "display_url" : "ghettohikes.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "168457714593312768",
  "text" : "\"THEM SHEEPS IS FUNNY LOOKIN HOMIE WEARIN A SNUGGIE FULL TIME\" http:\/\/t.co\/0SVAMTnl",
  "id" : 168457714593312768,
  "created_at" : "2012-02-11 22:13:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168390226316759040",
  "text" : "Checking out potential coworking spaces in Buffalo this weekend. Excited to do something positive for this city.",
  "id" : 168390226316759040,
  "created_at" : "2012-02-11 17:45:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 87 ],
      "url" : "https:\/\/t.co\/Xqv6Xnon",
      "expanded_url" : "https:\/\/minefold.com\/ddollar\/rubycraft",
      "display_url" : "minefold.com\/ddollar\/rubycr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168367595794333696",
  "text" : "RubyCraft is still alive and well! I need to play more Minecraft. https:\/\/t.co\/Xqv6Xnon",
  "id" : 168367595794333696,
  "created_at" : "2012-02-11 16:15:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 13, 20 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168126437113610241",
  "geo" : { },
  "id_str" : "168126857743577088",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @sferik `gem install` does that pretty well already",
  "id" : 168126857743577088,
  "in_reply_to_status_id" : 168126437113610241,
  "created_at" : "2012-02-11 00:19:01 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 8, 20 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168125981431828480",
  "geo" : { },
  "id_str" : "168126160134352897",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @bcardarella i lol'd",
  "id" : 168126160134352897,
  "in_reply_to_status_id" : 168125981431828480,
  "created_at" : "2012-02-11 00:16:14 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 13, 20 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168119269895315456",
  "geo" : { },
  "id_str" : "168122054292410368",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @sferik i'm not in the business of policing gem names.",
  "id" : 168122054292410368,
  "in_reply_to_status_id" : 168119269895315456,
  "created_at" : "2012-02-10 23:59:55 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 11, 23 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168100336781893632",
  "geo" : { },
  "id_str" : "168101563892645889",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier @fredyatesiv how about highrise?",
  "id" : 168101563892645889,
  "in_reply_to_status_id" : 168100336781893632,
  "created_at" : "2012-02-10 22:38:30 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Gl3j9VMh",
      "expanded_url" : "http:\/\/weknowmemes.com\/wp-content\/uploads\/2012\/01\/skirllex-bee-gif.gif",
      "display_url" : "weknowmemes.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168081158301683713",
  "text" : "Current status: http:\/\/t.co\/Gl3j9VMh",
  "id" : 168081158301683713,
  "created_at" : "2012-02-10 21:17:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 7, 22 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "United Pixelworkers",
      "screen_name" : "pixelworkers",
      "indices" : [ 23, 36 ],
      "id_str" : "135201019",
      "id" : 135201019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168069921031462912",
  "geo" : { },
  "id_str" : "168071207080562688",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @kevinjohngomez @pixelworkers yes, i murdered all the buffaloes in buffalo. buffalo, buffalo buffalo buffalo buffalo.",
  "id" : 168071207080562688,
  "in_reply_to_status_id" : 168069921031462912,
  "created_at" : "2012-02-10 20:37:53 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 3, 18 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "United Pixelworkers",
      "screen_name" : "pixelworkers",
      "indices" : [ 75, 88 ],
      "id_str" : "135201019",
      "id" : 135201019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/CU9PHP0K",
      "expanded_url" : "http:\/\/www.unitedpixelworkers.com\/pages\/rust-belt",
      "display_url" : "unitedpixelworkers.com\/pages\/rust-belt"
    } ]
  },
  "geo" : { },
  "id_str" : "168067184151633921",
  "text" : "RT @kevinjohngomez: Finally, my hometown & current home get some love from @pixelworkers! http:\/\/t.co\/CU9PHP0K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United Pixelworkers",
        "screen_name" : "pixelworkers",
        "indices" : [ 55, 68 ],
        "id_str" : "135201019",
        "id" : 135201019
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/CU9PHP0K",
        "expanded_url" : "http:\/\/www.unitedpixelworkers.com\/pages\/rust-belt",
        "display_url" : "unitedpixelworkers.com\/pages\/rust-belt"
      } ]
    },
    "geo" : { },
    "id_str" : "168062141713231873",
    "text" : "Finally, my hometown & current home get some love from @pixelworkers! http:\/\/t.co\/CU9PHP0K",
    "id" : 168062141713231873,
    "created_at" : "2012-02-10 20:01:51 +0000",
    "user" : {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "protected" : false,
      "id_str" : "26253666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1550650908\/portrait_500x500_normal.png",
      "id" : 26253666,
      "verified" : false
    }
  },
  "id" : 168067184151633921,
  "created_at" : "2012-02-10 20:21:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168061853791027200",
  "text" : "irb: variable $KCODE is no longer effective\nme: Rails app's attack failed! Use SIGQUIT!\nirb: It's SUPER EFFECTIVE!",
  "id" : 168061853791027200,
  "created_at" : "2012-02-10 20:00:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neckbeard Hacker",
      "screen_name" : "NeckbeardHacker",
      "indices" : [ 3, 19 ],
      "id_str" : "278523798",
      "id" : 278523798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168000982083575808",
  "text" : "RT @NeckbeardHacker: The world could use one more rougelike. Kickstarter?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168000818577027073",
    "text" : "The world could use one more rougelike. Kickstarter?",
    "id" : 168000818577027073,
    "created_at" : "2012-02-10 15:58:11 +0000",
    "user" : {
      "name" : "Neckbeard Hacker",
      "screen_name" : "NeckbeardHacker",
      "protected" : false,
      "id_str" : "278523798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303125542\/neckbeard_normal.jpg",
      "id" : 278523798,
      "verified" : false
    }
  },
  "id" : 168000982083575808,
  "created_at" : "2012-02-10 15:58:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 0, 9 ],
      "id_str" : "14212405",
      "id" : 14212405
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 10, 25 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 26, 37 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167998985976553473",
  "geo" : { },
  "id_str" : "167999349383643136",
  "in_reply_to_user_id" : 14212405,
  "text" : "@metadave @1ofyourmeteors @jonplussed on-call, sorry.",
  "id" : 167999349383643136,
  "in_reply_to_status_id" : 167998985976553473,
  "created_at" : "2012-02-10 15:52:20 +0000",
  "in_reply_to_screen_name" : "metadave",
  "in_reply_to_user_id_str" : "14212405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167845295256907776",
  "geo" : { },
  "id_str" : "167845836619923456",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw lol @ every project",
  "id" : 167845836619923456,
  "in_reply_to_status_id" : 167845295256907776,
  "created_at" : "2012-02-10 05:42:20 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 3, 10 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 63, 69 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 57 ],
      "url" : "https:\/\/t.co\/5bxSGqHv",
      "expanded_url" : "https:\/\/github.com\/gabebw\/pull",
      "display_url" : "github.com\/gabebw\/pull"
    } ]
  },
  "geo" : { },
  "id_str" : "167845776360345600",
  "text" : "RT @gabebw: So this is a thing now: https:\/\/t.co\/5bxSGqHv (\/cc @qrush)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 51, 57 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 45 ],
        "url" : "https:\/\/t.co\/5bxSGqHv",
        "expanded_url" : "https:\/\/github.com\/gabebw\/pull",
        "display_url" : "github.com\/gabebw\/pull"
      } ]
    },
    "geo" : { },
    "id_str" : "167845295256907776",
    "text" : "So this is a thing now: https:\/\/t.co\/5bxSGqHv (\/cc @qrush)",
    "id" : 167845295256907776,
    "created_at" : "2012-02-10 05:40:11 +0000",
    "user" : {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "protected" : false,
      "id_str" : "224887329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522042513951977472\/vthKCPDr_normal.jpeg",
      "id" : 224887329,
      "verified" : false
    }
  },
  "id" : 167845776360345600,
  "created_at" : "2012-02-10 05:42:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/EsztKGE0",
      "expanded_url" : "http:\/\/vimeo.com\/30784316",
      "display_url" : "vimeo.com\/30784316"
    } ]
  },
  "geo" : { },
  "id_str" : "167842265904054273",
  "text" : "Stunning timelapses from a USA roadtrip: http:\/\/t.co\/EsztKGE0",
  "id" : 167842265904054273,
  "created_at" : "2012-02-10 05:28:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167789068225216512",
  "geo" : { },
  "id_str" : "167790380752969729",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky haha i get it.",
  "id" : 167790380752969729,
  "in_reply_to_status_id" : 167789068225216512,
  "created_at" : "2012-02-10 02:01:58 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Jacques Crocker",
      "screen_name" : "railsjedi",
      "indices" : [ 13, 23 ],
      "id_str" : "1453071312",
      "id" : 1453071312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/QIWvaACc",
      "expanded_url" : "http:\/\/quaran.to\/m",
      "display_url" : "quaran.to\/m"
    } ]
  },
  "in_reply_to_status_id_str" : "167743056815198209",
  "geo" : { },
  "id_str" : "167749037188071426",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @railsjedi I use it daily. Rock on! http:\/\/t.co\/QIWvaACc",
  "id" : 167749037188071426,
  "in_reply_to_status_id" : 167743056815198209,
  "created_at" : "2012-02-09 23:17:41 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 24, 38 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/167498208988237824\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/KCdDasLS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlMSu8-CEAE80Ce.jpg",
      "id_str" : "167498208992432129",
      "id" : 167498208992432129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlMSu8-CEAE80Ce.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/KCdDasLS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167498208988237824",
  "text" : "A tie in Carcassonne vs @joshuaclayton !!!? FFFFUUUUUUU http:\/\/t.co\/KCdDasLS",
  "id" : 167498208988237824,
  "created_at" : "2012-02-09 06:41:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 18, 31 ],
      "id_str" : "467162656",
      "id" : 467162656
    }, {
      "name" : "Homophobes",
      "screen_name" : "homophobes",
      "indices" : [ 51, 62 ],
      "id_str" : "318831260",
      "id" : 318831260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167489925615321088",
  "text" : "Wow, if you think @herpderpedia was bad, check out @homophobes. Justice.",
  "id" : 167489925615321088,
  "created_at" : "2012-02-09 06:08:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattstache Ferguson",
      "screen_name" : "RUferg",
      "indices" : [ 42, 49 ],
      "id_str" : "24570618",
      "id" : 24570618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/1g4iWSAK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aJA-Tfbbtdg",
      "display_url" : "youtube.com\/watch?v=aJA-Tf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167469214762926080",
  "text" : "Current status: http:\/\/t.co\/1g4iWSAK \/via @ruferg",
  "id" : 167469214762926080,
  "created_at" : "2012-02-09 04:45:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weird History",
      "screen_name" : "historyweird",
      "indices" : [ 3, 16 ],
      "id_str" : "224437276",
      "id" : 224437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167464055458627584",
  "text" : "RT @historyweird: 1894: Razor mogul & wacky idealist King Gillette says that most North Americans should live in a giant three-storey ci ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166508441064570880",
    "text" : "1894: Razor mogul & wacky idealist King Gillette says that most North Americans should live in a giant three-storey city near Niagara Falls",
    "id" : 166508441064570880,
    "created_at" : "2012-02-06 13:08:00 +0000",
    "user" : {
      "name" : "Weird History",
      "screen_name" : "historyweird",
      "protected" : false,
      "id_str" : "224437276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2409090792\/jpdjo2j3gdskgo7jp500_normal.png",
      "id" : 224437276,
      "verified" : false
    }
  },
  "id" : 167464055458627584,
  "created_at" : "2012-02-09 04:25:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 3, 13 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/2bBIb3Mo",
      "expanded_url" : "http:\/\/yfrog.com\/nx3vibzj",
      "display_url" : "yfrog.com\/nx3vibzj"
    } ]
  },
  "geo" : { },
  "id_str" : "167440110114189313",
  "text" : "RT @jankowski: If you liked my texas-shaped eggs you're going to love my NY state shaped waffles!!! http:\/\/t.co\/2bBIb3Mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/2bBIb3Mo",
        "expanded_url" : "http:\/\/yfrog.com\/nx3vibzj",
        "display_url" : "yfrog.com\/nx3vibzj"
      } ]
    },
    "geo" : { },
    "id_str" : "167439043100033024",
    "text" : "If you liked my texas-shaped eggs you're going to love my NY state shaped waffles!!! http:\/\/t.co\/2bBIb3Mo",
    "id" : 167439043100033024,
    "created_at" : "2012-02-09 02:45:53 +0000",
    "user" : {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "protected" : false,
      "id_str" : "5965482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1581486057\/IMG_1216_normal.JPG",
      "id" : 5965482,
      "verified" : false
    }
  },
  "id" : 167440110114189313,
  "created_at" : "2012-02-09 02:50:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 18, 26 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167401317474639873",
  "geo" : { },
  "id_str" : "167402417279860736",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried get a @wegmans in chicago first :)",
  "id" : 167402417279860736,
  "in_reply_to_status_id" : 167401317474639873,
  "created_at" : "2012-02-09 00:20:21 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167392901624643584",
  "geo" : { },
  "id_str" : "167393383239782401",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn SHOOPED",
  "id" : 167393383239782401,
  "in_reply_to_status_id" : 167392901624643584,
  "created_at" : "2012-02-08 23:44:27 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/r7BI7kNA",
      "expanded_url" : "http:\/\/instagr.am\/p\/Gw1sobM6hT\/",
      "display_url" : "instagr.am\/p\/Gw1sobM6hT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "167389552074436609",
  "text" : "Naan! After. http:\/\/t.co\/r7BI7kNA",
  "id" : 167389552074436609,
  "created_at" : "2012-02-08 23:29:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/IMQAOuaJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/Gw0O7xs6hF\/",
      "display_url" : "instagr.am\/p\/Gw0O7xs6hF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "167386169687019520",
  "text" : "Heck yes it's Naan Pizza night. Before. http:\/\/t.co\/IMQAOuaJ",
  "id" : 167386169687019520,
  "created_at" : "2012-02-08 23:15:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @henrikhodne",
      "screen_name" : "dvyjones",
      "indices" : [ 0, 9 ],
      "id_str" : "632309987",
      "id" : 632309987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167352713041035264",
  "geo" : { },
  "id_str" : "167368854677360640",
  "in_reply_to_user_id" : 14746604,
  "text" : "@dvyjones yeah, buffalo doesn't have the money (or people) to warrant it. :(",
  "id" : 167368854677360640,
  "in_reply_to_status_id" : 167352713041035264,
  "created_at" : "2012-02-08 22:06:59 +0000",
  "in_reply_to_screen_name" : "henrikhodne",
  "in_reply_to_user_id_str" : "14746604",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 0, 10 ],
      "id_str" : "1942",
      "id" : 1942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167364002496786432",
  "geo" : { },
  "id_str" : "167364817118699520",
  "in_reply_to_user_id" : 1942,
  "text" : "@jremsikjr Some days you rebase the branch, some days the branch PLEASE COMMIT OR STASH YOUR CHANGES",
  "id" : 167364817118699520,
  "in_reply_to_status_id" : 167364002496786432,
  "created_at" : "2012-02-08 21:50:56 +0000",
  "in_reply_to_screen_name" : "jremsikjr",
  "in_reply_to_user_id_str" : "1942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/0iP1YkjZ",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/commute\/2012\/02\/death-row-urban-highways-part-2\/1170\/",
      "display_url" : "theatlanticcities.com\/commute\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167348415196442624",
  "text" : "Seriously. Down with the Skyway. http:\/\/t.co\/0iP1YkjZ",
  "id" : 167348415196442624,
  "created_at" : "2012-02-08 20:45:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3HzagXdY",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/17272077669\/your-next-great-teammate?utm_source=twitter",
      "display_url" : "robots.thoughtbot.com\/post\/172720776\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167321198777221120",
  "text" : "RT @thoughtbot: Your company can now take advantage of our successful apprenticeship program to find great designers and developers. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/3HzagXdY",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/17272077669\/your-next-great-teammate?utm_source=twitter",
        "display_url" : "robots.thoughtbot.com\/post\/172720776\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "167319184265584640",
    "text" : "Your company can now take advantage of our successful apprenticeship program to find great designers and developers. http:\/\/t.co\/3HzagXdY",
    "id" : 167319184265584640,
    "created_at" : "2012-02-08 18:49:36 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 167321198777221120,
  "created_at" : "2012-02-08 18:57:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Griffey",
      "screen_name" : "briangriffey",
      "indices" : [ 0, 13 ],
      "id_str" : "24887250",
      "id" : 24887250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167296298809176064",
  "geo" : { },
  "id_str" : "167320818269958144",
  "in_reply_to_user_id" : 24887250,
  "text" : "@briangriffey no sorry :(",
  "id" : 167320818269958144,
  "in_reply_to_status_id" : 167296298809176064,
  "created_at" : "2012-02-08 18:56:06 +0000",
  "in_reply_to_screen_name" : "briangriffey",
  "in_reply_to_user_id_str" : "24887250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Kwiatek",
      "screen_name" : "nkwiatek",
      "indices" : [ 26, 35 ],
      "id_str" : "486208515",
      "id" : 486208515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/a36MjViO",
      "expanded_url" : "http:\/\/nkwiatek.com\/",
      "display_url" : "nkwiatek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "167307926015459329",
  "text" : "Wow. http:\/\/t.co\/a36MjViO @nkwiatek this is awesome.",
  "id" : 167307926015459329,
  "created_at" : "2012-02-08 18:04:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167244219059150848",
  "geo" : { },
  "id_str" : "167245721966354433",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh was just thinking the same thing, but how much world energy is spent on the Netflix Silverlight client burning CPU when idle",
  "id" : 167245721966354433,
  "in_reply_to_status_id" : 167244219059150848,
  "created_at" : "2012-02-08 13:57:42 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/N9E4aejs",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/en\/thumb\/8\/80\/Snuffy31.jpg\/220px-Snuffy31.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/en\/t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "166930399124140032",
  "geo" : { },
  "id_str" : "166930900066631680",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills http:\/\/t.co\/N9E4aejs ? also, too much scope re: meetup",
  "id" : 166930900066631680,
  "in_reply_to_status_id" : 166930399124140032,
  "created_at" : "2012-02-07 17:06:42 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166929739993456642",
  "geo" : { },
  "id_str" : "166929861389189121",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike no. i think it would have caught on by now.",
  "id" : 166929861389189121,
  "in_reply_to_status_id" : 166929739993456642,
  "created_at" : "2012-02-07 17:02:35 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166925664342118400",
  "geo" : { },
  "id_str" : "166925979632140289",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik developers.",
  "id" : 166925979632140289,
  "in_reply_to_status_id" : 166925664342118400,
  "created_at" : "2012-02-07 16:47:09 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166923933667442688",
  "geo" : { },
  "id_str" : "166924139104448513",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik no, would definitely be OSS",
  "id" : 166924139104448513,
  "in_reply_to_status_id" : 166923933667442688,
  "created_at" : "2012-02-07 16:39:50 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 10, 17 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166923529474940928",
  "geo" : { },
  "id_str" : "166923810262618112",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik @GitHub that's not their business model, and I hope they stay away from it",
  "id" : 166923810262618112,
  "in_reply_to_status_id" : 166923529474940928,
  "created_at" : "2012-02-07 16:38:32 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166923555601268737",
  "geo" : { },
  "id_str" : "166923696441786368",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh no, i don't think librelist is the right answer",
  "id" : 166923696441786368,
  "in_reply_to_status_id" : 166923555601268737,
  "created_at" : "2012-02-07 16:38:05 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166923346007699456",
  "text" : "I think my next big open source project is going to be a Google Groups replacement. It's just not fun or engaging to use.",
  "id" : 166923346007699456,
  "created_at" : "2012-02-07 16:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/R1zIwCyi",
      "expanded_url" : "http:\/\/blog.exceptional.io\/news\/how-exceptional-and-airbrake-first-met\/",
      "display_url" : "blog.exceptional.io\/news\/how-excep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166919704148049920",
  "text" : "Really glad Airbrake (ne\u00E9 Hoptoad) and Exceptional are teaming up. Excited to see how this ends up. http:\/\/t.co\/R1zIwCyi",
  "id" : 166919704148049920,
  "created_at" : "2012-02-07 16:22:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/76vDuOY5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=B7Ar3ckeVOg",
      "display_url" : "youtube.com\/watch?v=B7Ar3c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166769059629760512",
  "text" : "New Radio Disney Death Metal too. Great music night. http:\/\/t.co\/76vDuOY5",
  "id" : 166769059629760512,
  "created_at" : "2012-02-07 06:23:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 43 ],
      "url" : "https:\/\/t.co\/R0RUJ6ke",
      "expanded_url" : "https:\/\/github.com\/AndrewVos\/fuckingawesomesongs.com\/pull\/23",
      "display_url" : "github.com\/AndrewVos\/fuck\u2026"
    }, {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/lIqzDxKw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=g4ouPGGLI6Q",
      "display_url" : "youtube.com\/watch?v=g4ouPG\u2026"
    }, {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/WNv1EWT4",
      "expanded_url" : "http:\/\/fuckingawesomesongs.com\/",
      "display_url" : "fuckingawesomesongs.com"
    } ]
  },
  "geo" : { },
  "id_str" : "166764329620873216",
  "text" : "+1 THIS PULL REQUEST. https:\/\/t.co\/R0RUJ6ke ( it's for adding http:\/\/t.co\/lIqzDxKw to http:\/\/t.co\/WNv1EWT4 )",
  "id" : 166764329620873216,
  "created_at" : "2012-02-07 06:04:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 24, 29 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/ArItUNh5",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3560204",
      "display_url" : "news.ycombinator.com\/item?id=3560204"
    } ]
  },
  "geo" : { },
  "id_str" : "166714964843831296",
  "text" : "Returning some kudos to @r00k. Upboats on HN, anyone? http:\/\/t.co\/ArItUNh5",
  "id" : 166714964843831296,
  "created_at" : "2012-02-07 02:48:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 3, 11 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166713131341590528",
  "text" : "RT @kkuchta: Turns out OS X has a dubstep generator built-in.  From Terminal.app, run `yes \"wub\" | xargs say`",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166712450215976964",
    "text" : "Turns out OS X has a dubstep generator built-in.  From Terminal.app, run `yes \"wub\" | xargs say`",
    "id" : 166712450215976964,
    "created_at" : "2012-02-07 02:38:40 +0000",
    "user" : {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "protected" : false,
      "id_str" : "19041990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1638281947\/KevSuit_normal.jpeg",
      "id" : 19041990,
      "verified" : false
    }
  },
  "id" : 166713131341590528,
  "created_at" : "2012-02-07 02:41:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupy",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/AdGQZH2V",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/02\/take-back-the-neighborhoods.html",
      "display_url" : "buffalorising.com\/2012\/02\/take-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166711439346761729",
  "text" : "Wow, the #occupy movement is doing something actionable and real in Buffalo. Impressed. http:\/\/t.co\/AdGQZH2V",
  "id" : 166711439346761729,
  "created_at" : "2012-02-07 02:34:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 138 ],
      "url" : "https:\/\/t.co\/xD7fztMJ",
      "expanded_url" : "https:\/\/www.us.hsbc.com\/1\/2\/3\/personal\/start\/rcc?SCMCLP=default_RCC&x=&code=MIW0000560&WT.ac=HBUS_MIW0000560",
      "display_url" : "us.hsbc.com\/1\/2\/3\/personal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166689857165459457",
  "text" : "Just now realizing that HSBC's stupid new login form must mean they store passwords in plaintext. I need a new bank. https:\/\/t.co\/xD7fztMJ",
  "id" : 166689857165459457,
  "created_at" : "2012-02-07 01:08:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166669745821716480",
  "geo" : { },
  "id_str" : "166675116653166592",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike work work work",
  "id" : 166675116653166592,
  "in_reply_to_status_id" : 166669745821716480,
  "created_at" : "2012-02-07 00:10:19 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speaker Deck",
      "screen_name" : "speakerdeck",
      "indices" : [ 25, 37 ],
      "id_str" : "144190968",
      "id" : 144190968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/QweVtosw",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/qrush\/p\/test-driven-development",
      "display_url" : "speakerdeck.com\/u\/qrush\/p\/test\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166670988212305920",
  "text" : "Dropped my TDD talk into @speakerdeck. I wish I could get my gifs to work! http:\/\/t.co\/QweVtosw",
  "id" : 166670988212305920,
  "created_at" : "2012-02-06 23:53:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 11, 18 ],
      "id_str" : "15827231",
      "id" : 15827231
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 19, 26 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/8rh07UU9",
      "expanded_url" : "http:\/\/www.topatoco.com\/merchant.mvc?Screen=PROD&Store_Code=TO&Product_Code=AXE-OCTOBER&Category_Code=AXE",
      "display_url" : "topatoco.com\/merchant.mvc?S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166667690000392193",
  "text" : "Octobear!? @tekkub @github have you seen this? http:\/\/t.co\/8rh07UU9",
  "id" : 166667690000392193,
  "created_at" : "2012-02-06 23:40:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/ltLy5jiM",
      "expanded_url" : "http:\/\/www.speakingforhackers.com\/pages\/dont-be-boring",
      "display_url" : "speakingforhackers.com\/pages\/dont-be-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166665952199581696",
  "text" : "Speakers: Don't be boring. http:\/\/t.co\/ltLy5jiM",
  "id" : 166665952199581696,
  "created_at" : "2012-02-06 23:33:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166657804956999680",
  "geo" : { },
  "id_str" : "166665727401672704",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k wow dude, flattered. thanks!",
  "id" : 166665727401672704,
  "in_reply_to_status_id" : 166657804956999680,
  "created_at" : "2012-02-06 23:33:00 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernard Poon",
      "screen_name" : "StackOverflow",
      "indices" : [ 37, 51 ],
      "id_str" : "128700677",
      "id" : 128700677
    }, {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 124, 137 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166664675394727936",
  "text" : "For all of my jokes\/crap given about @StackOverflow, I gotta say, I'm on it daily and my job is easier thanks to it. Thanks @codinghorror.",
  "id" : 166664675394727936,
  "created_at" : "2012-02-06 23:28:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/nm3NYcrN",
      "expanded_url" : "http:\/\/i.imgur.com\/mSdRA.jpg",
      "display_url" : "i.imgur.com\/mSdRA.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "166660064994787328",
  "text" : "Suddenly, Warcraft 2 urges. http:\/\/t.co\/nm3NYcrN",
  "id" : 166660064994787328,
  "created_at" : "2012-02-06 23:10:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Lachut",
      "screen_name" : "BradLachut",
      "indices" : [ 3, 14 ],
      "id_str" : "80014187",
      "id" : 80014187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166379676418310145",
  "text" : "RT @BradLachut: The real winners tonight are Buffalo Hotels.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166358770287513600",
    "text" : "The real winners tonight are Buffalo Hotels.",
    "id" : 166358770287513600,
    "created_at" : "2012-02-06 03:13:16 +0000",
    "user" : {
      "name" : "Brad Lachut",
      "screen_name" : "BradLachut",
      "protected" : false,
      "id_str" : "80014187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2790242805\/6f84db9a38d4b4690ebd7f73e5f9caa0_normal.jpeg",
      "id" : 80014187,
      "verified" : false
    }
  },
  "id" : 166379676418310145,
  "created_at" : "2012-02-06 04:36:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166359354176577536",
  "text" : "Coded a bunch of ObjectiveC this weekend. Starting to \"get it\", slow coming though. StackOverflow'in\/Google constantly.",
  "id" : 166359354176577536,
  "created_at" : "2012-02-06 03:15:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/Exb9GEqW",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/pc6j9\/iama_former_fulltime_zynga_engineer_quit_6_months\/",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166352156557971456",
  "text" : "AmA from former Zynga engineer reveals programmers will basically stoop to any level for a paycheck. http:\/\/t.co\/Exb9GEqW",
  "id" : 166352156557971456,
  "created_at" : "2012-02-06 02:46:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166343630259359745",
  "text" : "If you name your dog \"Wego\" after this stupid Bud Light commercial, I will hunt you down and end your pathetic existence.",
  "id" : 166343630259359745,
  "created_at" : "2012-02-06 02:13:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166331831980015616",
  "text" : "What was America like before the Super Bowl? And before Twitter where we could complain about the whole thing?",
  "id" : 166331831980015616,
  "created_at" : "2012-02-06 01:26:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166226890485542912",
  "text" : "HIGHWAY TO THE DANGER ZONE. It's playing in JFK T5 right now. Yep.",
  "id" : 166226890485542912,
  "created_at" : "2012-02-05 18:29:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166196114226286593",
  "text" : "Yay, delayed and missed connection at JFK!",
  "id" : 166196114226286593,
  "created_at" : "2012-02-05 16:26:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166143321440399360",
  "text" : "Seriously, so sick of this Opt out bullshit.",
  "id" : 166143321440399360,
  "created_at" : "2012-02-05 12:57:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166143201420390401",
  "text" : "Maybe next time through Logan I won't wear any underwear, it'll surprise the agent when he sticks his hands down my pants next time!",
  "id" : 166143201420390401,
  "created_at" : "2012-02-05 12:56:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166142915918303232",
  "text" : "As usual, went to a metal detector line at Logan and had to opt out anyway.",
  "id" : 166142915918303232,
  "created_at" : "2012-02-05 12:55:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 29, 36 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165970373500866561",
  "geo" : { },
  "id_str" : "166012332688945152",
  "in_reply_to_user_id" : 15507545,
  "text" : "@bquarant what did you do to @hiteak",
  "id" : 166012332688945152,
  "in_reply_to_status_id" : 165970373500866561,
  "created_at" : "2012-02-05 04:16:39 +0000",
  "in_reply_to_screen_name" : "hiteak",
  "in_reply_to_user_id_str" : "15507545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 0, 7 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165970373500866561",
  "geo" : { },
  "id_str" : "166012230066913280",
  "in_reply_to_user_id" : 15507545,
  "text" : "@hiteak oh no",
  "id" : 166012230066913280,
  "in_reply_to_status_id" : 165970373500866561,
  "created_at" : "2012-02-05 04:16:14 +0000",
  "in_reply_to_screen_name" : "hiteak",
  "in_reply_to_user_id_str" : "15507545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 38, 45 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Jason Evanish",
      "screen_name" : "Evanish",
      "indices" : [ 50, 58 ],
      "id_str" : "38380590",
      "id" : 38380590
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bostonio",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165929527548194816",
  "text" : "Had a great time at #bostonio, thanks @Croaky and @Evanish for organizing a superb event!",
  "id" : 165929527548194816,
  "created_at" : "2012-02-04 22:47:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165892398310887425",
  "geo" : { },
  "id_str" : "165892731363799041",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps brogrammers are in the minority",
  "id" : 165892731363799041,
  "in_reply_to_status_id" : 165892398310887425,
  "created_at" : "2012-02-04 20:21:23 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Griffey",
      "screen_name" : "briangriffey",
      "indices" : [ 0, 13 ],
      "id_str" : "24887250",
      "id" : 24887250
    }, {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 61, 70 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165886084776075264",
  "geo" : { },
  "id_str" : "165891841621893120",
  "in_reply_to_user_id" : 24887250,
  "text" : "@briangriffey also curious, have you seen\/tried campyre? \/cc @Klondike",
  "id" : 165891841621893120,
  "in_reply_to_status_id" : 165886084776075264,
  "created_at" : "2012-02-04 20:17:51 +0000",
  "in_reply_to_screen_name" : "briangriffey",
  "in_reply_to_user_id_str" : "24887250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Griffey",
      "screen_name" : "briangriffey",
      "indices" : [ 0, 13 ],
      "id_str" : "24887250",
      "id" : 24887250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165886084776075264",
  "geo" : { },
  "id_str" : "165891618099044354",
  "in_reply_to_user_id" : 24887250,
  "text" : "@briangriffey sure! DM?",
  "id" : 165891618099044354,
  "in_reply_to_status_id" : 165886084776075264,
  "created_at" : "2012-02-04 20:16:58 +0000",
  "in_reply_to_screen_name" : "briangriffey",
  "in_reply_to_user_id_str" : "24887250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165878600376123393",
  "geo" : { },
  "id_str" : "165878998751121408",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw wat",
  "id" : 165878998751121408,
  "in_reply_to_status_id" : 165878600376123393,
  "created_at" : "2012-02-04 19:26:49 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tauber",
      "screen_name" : "jtauber",
      "indices" : [ 0, 8 ],
      "id_str" : "1583811",
      "id" : 1583811
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 14, 21 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165873893112954880",
  "geo" : { },
  "id_str" : "165874306121871360",
  "in_reply_to_user_id" : 1583811,
  "text" : "@jtauber hey! @Croaky 's your man.",
  "id" : 165874306121871360,
  "in_reply_to_status_id" : 165873893112954880,
  "created_at" : "2012-02-04 19:08:11 +0000",
  "in_reply_to_screen_name" : "jtauber",
  "in_reply_to_user_id_str" : "1583811",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rich rines",
      "screen_name" : "richrines",
      "indices" : [ 0, 10 ],
      "id_str" : "123329223",
      "id" : 123329223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165873294980026369",
  "geo" : { },
  "id_str" : "165873724317380609",
  "in_reply_to_user_id" : 123329223,
  "text" : "@richrines thanks!!",
  "id" : 165873724317380609,
  "in_reply_to_status_id" : 165873294980026369,
  "created_at" : "2012-02-04 19:05:52 +0000",
  "in_reply_to_screen_name" : "richrines",
  "in_reply_to_user_id_str" : "123329223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Grant",
      "screen_name" : "grantovich",
      "indices" : [ 0, 11 ],
      "id_str" : "17433435",
      "id" : 17433435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165871456310411264",
  "geo" : { },
  "id_str" : "165873679111163904",
  "in_reply_to_user_id" : 17433435,
  "text" : "@grantovich thanks!",
  "id" : 165873679111163904,
  "in_reply_to_status_id" : 165871456310411264,
  "created_at" : "2012-02-04 19:05:41 +0000",
  "in_reply_to_screen_name" : "grantovich",
  "in_reply_to_user_id_str" : "17433435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Evanish",
      "screen_name" : "Evanish",
      "indices" : [ 3, 11 ],
      "id_str" : "38380590",
      "id" : 38380590
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 18, 24 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bostonio",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165873516804177920",
  "text" : "RT @Evanish: Love @qrush's talk on testing. Particularly the encouragement to be a hooligan in your startup and ask why they don't test. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 5, 11 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bostonio",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165873192844537856",
    "text" : "Love @qrush's talk on testing. Particularly the encouragement to be a hooligan in your startup and ask why they don't test. #bostonio",
    "id" : 165873192844537856,
    "created_at" : "2012-02-04 19:03:45 +0000",
    "user" : {
      "name" : "Jason Evanish",
      "screen_name" : "Evanish",
      "protected" : false,
      "id_str" : "38380590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2983505158\/46a0f5eadf450f553472c4361133e4cc_normal.jpeg",
      "id" : 38380590,
      "verified" : false
    }
  },
  "id" : 165873516804177920,
  "created_at" : "2012-02-04 19:05:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 3, 10 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/rj7EFr50",
      "expanded_url" : "http:\/\/boston.io",
      "display_url" : "boston.io"
    } ]
  },
  "geo" : { },
  "id_str" : "165800496194527232",
  "text" : "RT @sferik: Excited to be talking about open source to 300+ students at http:\/\/t.co\/rj7EFr50. Looking forward to meeting the next genera ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/rj7EFr50",
        "expanded_url" : "http:\/\/boston.io",
        "display_url" : "boston.io"
      } ]
    },
    "geo" : { },
    "id_str" : "165798715670532096",
    "text" : "Excited to be talking about open source to 300+ students at http:\/\/t.co\/rj7EFr50. Looking forward to meeting the next generation of hackers.",
    "id" : 165798715670532096,
    "created_at" : "2012-02-04 14:07:48 +0000",
    "user" : {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "protected" : false,
      "id_str" : "7505382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567932260847206401\/ErQwT5za_normal.jpeg",
      "id" : 7505382,
      "verified" : false
    }
  },
  "id" : 165800496194527232,
  "created_at" : "2012-02-04 14:14:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myron Marston",
      "screen_name" : "myronmarston",
      "indices" : [ 0, 13 ],
      "id_str" : "89517808",
      "id" : 89517808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165659051877875713",
  "geo" : { },
  "id_str" : "165660492700991488",
  "in_reply_to_user_id" : 89517808,
  "text" : "@myronmarston check HN.",
  "id" : 165660492700991488,
  "in_reply_to_status_id" : 165659051877875713,
  "created_at" : "2012-02-04 04:58:33 +0000",
  "in_reply_to_screen_name" : "myronmarston",
  "in_reply_to_user_id_str" : "89517808",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165657742823010304",
  "text" : "The most terrifying conclusion from the Facebook git drama is that they work from one giant, behemoth repo. Really?",
  "id" : 165657742823010304,
  "created_at" : "2012-02-04 04:47:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165655160272584704",
  "text" : "I wish all iPhone games didn't turn into a twitch\/reaction fest. I miss NetHack.",
  "id" : 165655160272584704,
  "created_at" : "2012-02-04 04:37:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165590024899923970",
  "geo" : { },
  "id_str" : "165646691981205504",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam finally understood this, LOL.",
  "id" : 165646691981205504,
  "in_reply_to_status_id" : 165590024899923970,
  "created_at" : "2012-02-04 04:03:43 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165640729606111232",
  "geo" : { },
  "id_str" : "165646147166285826",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx TAAAACO TOWWWWN",
  "id" : 165646147166285826,
  "in_reply_to_status_id" : 165640729606111232,
  "created_at" : "2012-02-04 04:01:33 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165626887299809280",
  "text" : "OH \"dude I LOVE taylor smith\"",
  "id" : 165626887299809280,
  "created_at" : "2012-02-04 02:45:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/165576296808722432\/photo\/1",
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/o0tIVJrL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Akw-w8KCMAEXCAZ.jpg",
      "id_str" : "165576296808722433",
      "id" : 165576296808722433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Akw-w8KCMAEXCAZ.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/o0tIVJrL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165576296808722432",
  "text" : "Wat? http:\/\/t.co\/o0tIVJrL",
  "id" : 165576296808722432,
  "created_at" : "2012-02-03 23:24:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Baker",
      "screen_name" : "peter_baker",
      "indices" : [ 0, 12 ],
      "id_str" : "70729384",
      "id" : 70729384
    }, {
      "name" : "zenspider",
      "screen_name" : "zenspider",
      "indices" : [ 68, 78 ],
      "id_str" : "14989847",
      "id" : 14989847
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 82, 90 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/qQdKwaOP",
      "expanded_url" : "http:\/\/irc.freenode.net",
      "display_url" : "irc.freenode.net"
    } ]
  },
  "in_reply_to_status_id_str" : "165497934891331584",
  "geo" : { },
  "id_str" : "165529186562342913",
  "in_reply_to_user_id" : 70729384,
  "text" : "@peter_baker I'd ask on #rubygems on http:\/\/t.co\/qQdKwaOP, or maybe @zenspider or @drbrain know :(",
  "id" : 165529186562342913,
  "in_reply_to_status_id" : 165497934891331584,
  "created_at" : "2012-02-03 20:16:48 +0000",
  "in_reply_to_screen_name" : "peter_baker",
  "in_reply_to_user_id_str" : "70729384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Baker",
      "screen_name" : "peter_baker",
      "indices" : [ 0, 12 ],
      "id_str" : "70729384",
      "id" : 70729384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165497934891331584",
  "geo" : { },
  "id_str" : "165512515537739776",
  "in_reply_to_user_id" : 70729384,
  "text" : "@peter_baker i don't :(",
  "id" : 165512515537739776,
  "in_reply_to_status_id" : 165497934891331584,
  "created_at" : "2012-02-03 19:10:33 +0000",
  "in_reply_to_screen_name" : "peter_baker",
  "in_reply_to_user_id_str" : "70729384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/vJqApHnA",
      "expanded_url" : "http:\/\/rubydoc.info\/stdlib\/securerandom\/1.9.2\/SecureRandom",
      "display_url" : "rubydoc.info\/stdlib\/securer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165470989440917506",
  "text" : "TIL that ActiveSupport::SecureRandom is gone in Rails 3.2, use SecureRandom instead: http:\/\/t.co\/vJqApHnA",
  "id" : 165470989440917506,
  "created_at" : "2012-02-03 16:25:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165433740644974593",
  "geo" : { },
  "id_str" : "165443134921244673",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors in Boston, sorry!",
  "id" : 165443134921244673,
  "in_reply_to_status_id" : 165433740644974593,
  "created_at" : "2012-02-03 14:34:51 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165282861304381440",
  "geo" : { },
  "id_str" : "165283132038316033",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv hey Bruce wayne, want a bat mobile too?",
  "id" : 165283132038316033,
  "in_reply_to_status_id" : 165282861304381440,
  "created_at" : "2012-02-03 03:59:04 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165279496369487872",
  "geo" : { },
  "id_str" : "165282180644343808",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton if you wrote no tests they would run even faster! Trolololo",
  "id" : 165282180644343808,
  "in_reply_to_status_id" : 165279496369487872,
  "created_at" : "2012-02-03 03:55:17 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165231852603449344",
  "text" : "Hi Boston!",
  "id" : 165231852603449344,
  "created_at" : "2012-02-03 00:35:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/kyPm35B4",
      "expanded_url" : "http:\/\/Boston.io",
      "display_url" : "Boston.io"
    } ]
  },
  "geo" : { },
  "id_str" : "165191600564207616",
  "text" : "On our way to Boston for http:\/\/t.co\/kyPm35B4 !",
  "id" : 165191600564207616,
  "created_at" : "2012-02-02 21:55:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165190897443684354",
  "geo" : { },
  "id_str" : "165191416669155328",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick congrats ! Also, so Canadian",
  "id" : 165191416669155328,
  "in_reply_to_status_id" : 165190897443684354,
  "created_at" : "2012-02-02 21:54:37 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Pomeroy",
      "screen_name" : "xxv",
      "indices" : [ 0, 4 ],
      "id_str" : "7061802",
      "id" : 7061802
    }, {
      "name" : "MBTA Assholes",
      "screen_name" : "mbtaassholes",
      "indices" : [ 29, 42 ],
      "id_str" : "275142342",
      "id" : 275142342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164948943795535872",
  "geo" : { },
  "id_str" : "164949330254503936",
  "in_reply_to_user_id" : 7061802,
  "text" : "@xxv sounds like a story for @mbtaassholes",
  "id" : 164949330254503936,
  "in_reply_to_status_id" : 164948943795535872,
  "created_at" : "2012-02-02 05:52:39 +0000",
  "in_reply_to_screen_name" : "xxv",
  "in_reply_to_user_id_str" : "7061802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 4, 11 ],
      "id_str" : "14381877",
      "id" : 14381877
    }, {
      "name" : "charley baker",
      "screen_name" : "charley_baker",
      "indices" : [ 12, 26 ],
      "id_str" : "14385792",
      "id" : 14385792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/X8GhLqbH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?nomobile=1&v=aWbpelEmM34",
      "display_url" : "youtube.com\/watch?nomobile\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "164946123126091776",
  "geo" : { },
  "id_str" : "164948758164021249",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 @gustin @charley_baker http:\/\/t.co\/X8GhLqbH ?",
  "id" : 164948758164021249,
  "in_reply_to_status_id" : 164946123126091776,
  "created_at" : "2012-02-02 05:50:23 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    }, {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 8, 12 ],
      "id_str" : "15532680",
      "id" : 15532680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164930122481287171",
  "geo" : { },
  "id_str" : "164930422508236801",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus @pvh some of my friends think dominion is superior, but i like the dice building aspect. games go pretty quick too (20-30 mins)",
  "id" : 164930422508236801,
  "in_reply_to_status_id" : 164930122481287171,
  "created_at" : "2012-02-02 04:37:31 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 3, 13 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164922216654442496",
  "text" : "RT @magnachef: Best part of my day was telling 30+ computer science students: \"fuck trying to get a job at a big company after of school ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164922014098927618",
    "text" : "Best part of my day was telling 30+ computer science students: \"fuck trying to get a job at a big company after of school - start your own\"",
    "id" : 164922014098927618,
    "created_at" : "2012-02-02 04:04:06 +0000",
    "user" : {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "protected" : false,
      "id_str" : "23703410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557740024620261376\/4Td91096_normal.jpeg",
      "id" : 23703410,
      "verified" : false
    }
  },
  "id" : 164922216654442496,
  "created_at" : "2012-02-02 04:04:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 5, 12 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164881198022270977",
  "geo" : { },
  "id_str" : "164882182488342528",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh @geemus @crayolaly LOL",
  "id" : 164882182488342528,
  "in_reply_to_status_id" : 164881198022270977,
  "created_at" : "2012-02-02 01:25:50 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 5, 12 ],
      "id_str" : "14237099",
      "id" : 14237099
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 90, 99 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164880282007252993",
  "geo" : { },
  "id_str" : "164880506989723649",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh @geemus oh man, just picked up Quarriors and the expansion after being introduced at @codemash. Loving it.",
  "id" : 164880506989723649,
  "in_reply_to_status_id" : 164880282007252993,
  "created_at" : "2012-02-02 01:19:10 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164876909967196162",
  "geo" : { },
  "id_str" : "164877990977740800",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad seeing it, thanks. not sure how to fix it and most folks have signed off for the evening. it'll get attention tomorrow!",
  "id" : 164877990977740800,
  "in_reply_to_status_id" : 164876909967196162,
  "created_at" : "2012-02-02 01:09:10 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164870402223521793",
  "geo" : { },
  "id_str" : "164871700025049089",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel let's be reasonable here. replied to the gist.",
  "id" : 164871700025049089,
  "in_reply_to_status_id" : 164870402223521793,
  "created_at" : "2012-02-02 00:44:11 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164867273805402113",
  "geo" : { },
  "id_str" : "164868504783306752",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad emailed ya.",
  "id" : 164868504783306752,
  "in_reply_to_status_id" : 164867273805402113,
  "created_at" : "2012-02-02 00:31:29 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164866207252627456",
  "geo" : { },
  "id_str" : "164866937157992448",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad can I help? What's wrong?",
  "id" : 164866937157992448,
  "in_reply_to_status_id" : 164866207252627456,
  "created_at" : "2012-02-02 00:25:15 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 16, 23 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/164840401398792192\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/C5ryg7Al",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkmheMJCAAEvs2s.png",
      "id_str" : "164840401402986497",
      "id" : 164840401402986497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkmheMJCAAEvs2s.png",
      "sizes" : [ {
        "h" : 105,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 105,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 325
      } ],
      "display_url" : "pic.twitter.com\/C5ryg7Al"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164840401398792192",
  "text" : "Does someone at @github need glasses? Why does everything keep getting bigger? http:\/\/t.co\/C5ryg7Al",
  "id" : 164840401398792192,
  "created_at" : "2012-02-01 22:39:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 0, 8 ],
      "id_str" : "768197",
      "id" : 768197
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 17, 24 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164828976261513216",
  "geo" : { },
  "id_str" : "164829105257332736",
  "in_reply_to_user_id" : 768197,
  "text" : "@haacked doesn't @github have some?",
  "id" : 164829105257332736,
  "in_reply_to_status_id" : 164828976261513216,
  "created_at" : "2012-02-01 21:54:55 +0000",
  "in_reply_to_screen_name" : "haacked",
  "in_reply_to_user_id_str" : "768197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/cMjhTiLR",
      "expanded_url" : "http:\/\/api.rubyonrails.org",
      "display_url" : "api.rubyonrails.org"
    } ]
  },
  "geo" : { },
  "id_str" : "164804416971603968",
  "text" : "Searching for \"render\" on http:\/\/t.co\/cMjhTiLR is useless.",
  "id" : 164804416971603968,
  "created_at" : "2012-02-01 20:16:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164743414242484225",
  "geo" : { },
  "id_str" : "164743622036697090",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 i have to bring you to a Phish concert :)",
  "id" : 164743622036697090,
  "in_reply_to_status_id" : 164743414242484225,
  "created_at" : "2012-02-01 16:15:14 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164741968541401088",
  "geo" : { },
  "id_str" : "164743055218454528",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 seriously! pumped for their tour this summer.",
  "id" : 164743055218454528,
  "in_reply_to_status_id" : 164741968541401088,
  "created_at" : "2012-02-01 16:12:59 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/jv3zseLp",
      "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PLFB85CB460BF420BF",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164738852773298176",
  "text" : "Found a 9 hour Rush youtube playlist. DONE. http:\/\/t.co\/jv3zseLp",
  "id" : 164738852773298176,
  "created_at" : "2012-02-01 15:56:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/hB5kqutO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=LQEgZNqa8jE",
      "display_url" : "youtube.com\/watch?v=LQEgZN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164732484943224832",
  "text" : "Happy 2\/1\/12! http:\/\/t.co\/hB5kqutO",
  "id" : 164732484943224832,
  "created_at" : "2012-02-01 15:30:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164728791858561024",
  "text" : "Today we interrupt your regularly scheduled Phish for all day RUSH!",
  "id" : 164728791858561024,
  "created_at" : "2012-02-01 15:16:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Adamson",
      "screen_name" : "invalidname",
      "indices" : [ 3, 15 ],
      "id_str" : "12604932",
      "id" : 12604932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164724764810821633",
  "text" : "RT @invalidname: So, I suppose this is the ideal day to listen to Rush's \"2112\", right?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164719248323776512",
    "text" : "So, I suppose this is the ideal day to listen to Rush's \"2112\", right?",
    "id" : 164719248323776512,
    "created_at" : "2012-02-01 14:38:23 +0000",
    "user" : {
      "name" : "Chris Adamson",
      "screen_name" : "invalidname",
      "protected" : false,
      "id_str" : "12604932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476301738853404672\/pUd0vvMB_normal.jpeg",
      "id" : 12604932,
      "verified" : false
    }
  },
  "id" : 164724764810821633,
  "created_at" : "2012-02-01 15:00:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 3, 19 ],
      "id_str" : "43234200",
      "id" : 43234200
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 48, 54 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 61, 70 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/G5HiTZd4",
      "expanded_url" : "http:\/\/rubysource.com\/a-chat-with-nick-quaranto-about-rubygems-org-internals\/",
      "display_url" : "rubysource.com\/a-chat-with-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164724575626723329",
  "text" : "RT @pat_shaughnessy: I had a blast talking with @qrush about @rubygems internals - check out our conversation on @rubysource http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 27, 33 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 40, 49 ],
        "id_str" : "14881835",
        "id" : 14881835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/G5HiTZd4",
        "expanded_url" : "http:\/\/rubysource.com\/a-chat-with-nick-quaranto-about-rubygems-org-internals\/",
        "display_url" : "rubysource.com\/a-chat-with-ni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164718512944848896",
    "text" : "I had a blast talking with @qrush about @rubygems internals - check out our conversation on @rubysource http:\/\/t.co\/G5HiTZd4",
    "id" : 164718512944848896,
    "created_at" : "2012-02-01 14:35:28 +0000",
    "user" : {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "protected" : false,
      "id_str" : "43234200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415122501006413824\/9OlBVXvY_normal.jpeg",
      "id" : 43234200,
      "verified" : false
    }
  },
  "id" : 164724575626723329,
  "created_at" : "2012-02-01 14:59:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
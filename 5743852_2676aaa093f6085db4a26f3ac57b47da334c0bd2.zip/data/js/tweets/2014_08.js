Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivePhish",
      "screen_name" : "LivePhish",
      "indices" : [ 13, 23 ],
      "id_str" : "232312841",
      "id" : 232312841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243180545, -78.8791895464 ]
  },
  "id_str" : "506270854154444800",
  "text" : "3rd night of @livephish. \uD83D\uDE24",
  "id" : 506270854154444800,
  "created_at" : "2014-09-01 02:42:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506192558780067840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244919851, -78.8792612415 ]
  },
  "id_str" : "506215892930154496",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek congrats on player 3! \uD83D\uDC76\uD83D\uDE80",
  "id" : 506215892930154496,
  "in_reply_to_status_id" : 506192558780067840,
  "created_at" : "2014-08-31 23:04:08 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Thorn",
      "screen_name" : "JesseThorn",
      "indices" : [ 3, 14 ],
      "id_str" : "5611152",
      "id" : 5611152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506206938426658816",
  "text" : "RT @JesseThorn: Thirty Tech Industry Guys Disinterested In Basic Human Empathy Under Thirty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506203392167788544",
    "text" : "Thirty Tech Industry Guys Disinterested In Basic Human Empathy Under Thirty",
    "id" : 506203392167788544,
    "created_at" : "2014-08-31 22:14:28 +0000",
    "user" : {
      "name" : "Jesse Thorn",
      "screen_name" : "JesseThorn",
      "protected" : false,
      "id_str" : "5611152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471863015084523520\/WQvw47Fc_normal.jpeg",
      "id" : 5611152,
      "verified" : false
    }
  },
  "id" : 506206938426658816,
  "created_at" : "2014-08-31 22:28:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 3, 12 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 45, 54 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/R94aLuAiEa",
      "expanded_url" : "http:\/\/rubyconf.org\/cfp",
      "display_url" : "rubyconf.org\/cfp"
    } ]
  },
  "geo" : { },
  "id_str" : "506104325391654912",
  "text" : "RT @sarahmei: Last day to send us a talk for @rubyconf! CFP closes at 11:59 Pacific tonight - that's just over 15 hours away. http:\/\/t.co\/R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rubyconf",
        "screen_name" : "rubyconf",
        "indices" : [ 31, 40 ],
        "id_str" : "16222737",
        "id" : 16222737
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/R94aLuAiEa",
        "expanded_url" : "http:\/\/rubyconf.org\/cfp",
        "display_url" : "rubyconf.org\/cfp"
      } ]
    },
    "geo" : { },
    "id_str" : "506102380392243200",
    "text" : "Last day to send us a talk for @rubyconf! CFP closes at 11:59 Pacific tonight - that's just over 15 hours away. http:\/\/t.co\/R94aLuAiEa",
    "id" : 506102380392243200,
    "created_at" : "2014-08-31 15:33:05 +0000",
    "user" : {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "protected" : false,
      "id_str" : "14164724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564645861771079680\/i-bwhBp0_normal.jpeg",
      "id" : 14164724,
      "verified" : false
    }
  },
  "id" : 506104325391654912,
  "created_at" : "2014-08-31 15:40:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506086025811460096",
  "geo" : { },
  "id_str" : "506086361913229314",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 does the shield have muscles too?",
  "id" : 506086361913229314,
  "in_reply_to_status_id" : 506086025811460096,
  "created_at" : "2014-08-31 14:29:25 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    }, {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 68, 80 ],
      "id_str" : "17004618",
      "id" : 17004618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Uul1AVPIlt",
      "expanded_url" : "http:\/\/nyti.ms\/1pwEGAY",
      "display_url" : "nyti.ms\/1pwEGAY"
    } ]
  },
  "geo" : { },
  "id_str" : "506082003691646976",
  "text" : "RT @rachbarnhart: Whites don't get it http:\/\/t.co\/Uul1AVPIlt Thanks @NickKristof",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas Kristof",
        "screen_name" : "NickKristof",
        "indices" : [ 50, 62 ],
        "id_str" : "17004618",
        "id" : 17004618
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/Uul1AVPIlt",
        "expanded_url" : "http:\/\/nyti.ms\/1pwEGAY",
        "display_url" : "nyti.ms\/1pwEGAY"
      } ]
    },
    "geo" : { },
    "id_str" : "506081015333679104",
    "text" : "Whites don't get it http:\/\/t.co\/Uul1AVPIlt Thanks @NickKristof",
    "id" : 506081015333679104,
    "created_at" : "2014-08-31 14:08:11 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 506082003691646976,
  "created_at" : "2014-08-31 14:12:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506062749190094848",
  "geo" : { },
  "id_str" : "506063452066955264",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan parking, it's all underground",
  "id" : 506063452066955264,
  "in_reply_to_status_id" : 506062749190094848,
  "created_at" : "2014-08-31 12:58:23 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506061920802463744",
  "geo" : { },
  "id_str" : "506062494545092608",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan and chamfered bezel edges",
  "id" : 506062494545092608,
  "in_reply_to_status_id" : 506061920802463744,
  "created_at" : "2014-08-31 12:54:35 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506061920802463744",
  "geo" : { },
  "id_str" : "506062388311752704",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan probably a lot of concrete, steel, and glass",
  "id" : 506062388311752704,
  "in_reply_to_status_id" : 506061920802463744,
  "created_at" : "2014-08-31 12:54:10 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506061037612040192",
  "geo" : { },
  "id_str" : "506061580513968128",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown that's unfathomably big",
  "id" : 506061580513968128,
  "in_reply_to_status_id" : 506061037612040192,
  "created_at" : "2014-08-31 12:50:57 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 3, 15 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/WnQoIF4efw",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_detailpage&v=pfZvimPkKio#t=394",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506061341518360576",
  "text" : "RT @barelyknown: Trench run attempted on Apple\u2019s new spaceship headquarters. https:\/\/t.co\/WnQoIF4efw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/WnQoIF4efw",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_detailpage&v=pfZvimPkKio#t=394",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "506061037612040192",
    "text" : "Trench run attempted on Apple\u2019s new spaceship headquarters. https:\/\/t.co\/WnQoIF4efw",
    "id" : 506061037612040192,
    "created_at" : "2014-08-31 12:48:48 +0000",
    "user" : {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "protected" : false,
      "id_str" : "156708162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538511339040538624\/jQHVi93g_normal.jpeg",
      "id" : 156708162,
      "verified" : false
    }
  },
  "id" : 506061341518360576,
  "created_at" : "2014-08-31 12:50:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505928178444300288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243139644, -78.8790393156 ]
  },
  "id_str" : "505928353845493760",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad how about videos of people taking comically far away photos of concerts",
  "id" : 505928353845493760,
  "in_reply_to_status_id" : 505928178444300288,
  "created_at" : "2014-08-31 04:01:33 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505927830925213696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243139644, -78.8790393156 ]
  },
  "id_str" : "505928040187056128",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad would follow",
  "id" : 505928040187056128,
  "in_reply_to_status_id" : 505927830925213696,
  "created_at" : "2014-08-31 04:00:19 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243520601, -78.879110897 ]
  },
  "id_str" : "505897808268775425",
  "text" : "Very astounded that a tiny watch battery has kept my monsters alive  for over 13 years and counting. Can\u2019t say that too often.",
  "id" : 505897808268775425,
  "created_at" : "2014-08-31 02:00:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242018251, -78.8792305379 ]
  },
  "id_str" : "505897218679644160",
  "text" : "Blown away: 13 year old me transferred all of my original Blue catches onto Yellow, and that cart is still alive.",
  "id" : 505897218679644160,
  "created_at" : "2014-08-31 01:57:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Anthony",
      "screen_name" : "SevenOneFlix",
      "indices" : [ 3, 16 ],
      "id_str" : "325966404",
      "id" : 325966404
    }, {
      "name" : "Shark Girl",
      "screen_name" : "sharkgirlbflo",
      "indices" : [ 37, 51 ],
      "id_str" : "2751997175",
      "id" : 2751997175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sharkgirl",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "timelapse",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "buffalove14",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "canalside",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/t0abdOW27A",
      "expanded_url" : "http:\/\/instagram.com\/p\/sV4VPKyl4u\/",
      "display_url" : "instagram.com\/p\/sV4VPKyl4u\/"
    } ]
  },
  "geo" : { },
  "id_str" : "505872069834203136",
  "text" : "RT @SevenOneFlix: The most excellent @sharkgirlbflo #Sharkgirl #timelapse #buffalove14 #canalside #Buffalo @ Canalside\u2026 http:\/\/t.co\/t0abdOW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shark Girl",
        "screen_name" : "sharkgirlbflo",
        "indices" : [ 19, 33 ],
        "id_str" : "2751997175",
        "id" : 2751997175
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sharkgirl",
        "indices" : [ 34, 44 ]
      }, {
        "text" : "timelapse",
        "indices" : [ 45, 55 ]
      }, {
        "text" : "buffalove14",
        "indices" : [ 56, 68 ]
      }, {
        "text" : "canalside",
        "indices" : [ 69, 79 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/t0abdOW27A",
        "expanded_url" : "http:\/\/instagram.com\/p\/sV4VPKyl4u\/",
        "display_url" : "instagram.com\/p\/sV4VPKyl4u\/"
      } ]
    },
    "geo" : { },
    "id_str" : "505870140148572160",
    "text" : "The most excellent @sharkgirlbflo #Sharkgirl #timelapse #buffalove14 #canalside #Buffalo @ Canalside\u2026 http:\/\/t.co\/t0abdOW27A",
    "id" : 505870140148572160,
    "created_at" : "2014-08-31 00:10:14 +0000",
    "user" : {
      "name" : "Jerry Anthony",
      "screen_name" : "SevenOneFlix",
      "protected" : false,
      "id_str" : "325966404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504604487470682113\/3e96oqs5_normal.jpeg",
      "id" : 325966404,
      "verified" : false
    }
  },
  "id" : 505872069834203136,
  "created_at" : "2014-08-31 00:17:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "jlsmp",
      "indices" : [ 0, 6 ],
      "id_str" : "1856037409",
      "id" : 1856037409
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/505824248288792576\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/MuGp7ZbLjz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwUMeMxCQAAxeI3.jpg",
      "id_str" : "505824246111551488",
      "id" : 505824246111551488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwUMeMxCQAAxeI3.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/MuGp7ZbLjz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505822250197868545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0553826163, -78.8642743293 ]
  },
  "id_str" : "505824248288792576",
  "in_reply_to_user_id" : 1856037409,
  "text" : "@jlsmp funny because I found this too\u2026 http:\/\/t.co\/MuGp7ZbLjz",
  "id" : 505824248288792576,
  "in_reply_to_status_id" : 505822250197868545,
  "created_at" : "2014-08-30 21:07:53 +0000",
  "in_reply_to_screen_name" : "jlsmp",
  "in_reply_to_user_id_str" : "1856037409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/505820045839454209\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/M2fvEfklzZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwUImqnCAAAsSNm.jpg",
      "id_str" : "505819993515098112",
      "id" : 505819993515098112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwUImqnCAAAsSNm.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/M2fvEfklzZ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/505820045839454209\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/M2fvEfklzZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwUIphvCcAARD_1.jpg",
      "id_str" : "505820042672369664",
      "id" : 505820042672369664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwUIphvCcAARD_1.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/M2fvEfklzZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0554171559, -78.8641775307 ]
  },
  "id_str" : "505820045839454209",
  "text" : "No idea where Blue went, but this Red case is still in great condition. Such a simple design. http:\/\/t.co\/M2fvEfklzZ",
  "id" : 505820045839454209,
  "created_at" : "2014-08-30 20:51:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505783717403832320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.991826674, -78.820887683 ]
  },
  "id_str" : "505786048279220224",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone \uD83D\uDC40",
  "id" : 505786048279220224,
  "in_reply_to_status_id" : 505783717403832320,
  "created_at" : "2014-08-30 18:36:05 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9963323671, -78.8168790659 ]
  },
  "id_str" : "505780882058518528",
  "text" : "Shocking: Tim Hortons Dark Roast is not terrible coffee.",
  "id" : 505780882058518528,
  "created_at" : "2014-08-30 18:15:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 38, 53 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505549118308352000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9968235045, -78.8208711118 ]
  },
  "id_str" : "505765261065334784",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester need set list updates!! @UnclePhilsBlog",
  "id" : 505765261065334784,
  "in_reply_to_status_id" : 505549118308352000,
  "created_at" : "2014-08-30 17:13:29 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505761501228314624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9968397227, -78.8208922093 ]
  },
  "id_str" : "505761746062438400",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc it is the only solace in a swath of angry suburban drivers and square miles of Muzak infused parking lots",
  "id" : 505761746062438400,
  "in_reply_to_status_id" : 505761501228314624,
  "created_at" : "2014-08-30 16:59:31 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/wBvj3HdgQS",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/5402020c498e3d6304126c11?s=ufUbMZGVz64ajVjoIop9EsmGsfY&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9968438047, -78.8210624456 ]
  },
  "id_str" : "505760777027215360",
  "text" : "\uD83C\uDF5C (@ Pho Saigon in Amherst, NY) https:\/\/t.co\/wBvj3HdgQS",
  "id" : 505760777027215360,
  "created_at" : "2014-08-30 16:55:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 41, 53 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/kaKheyyg13",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/5401f739498ebec295247295?s=xhYrDIVoeYvPrc5xJH_6H2M9iPc&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9206441731, -78.8771124621 ]
  },
  "id_str" : "505749154816339968",
  "text" : "On Hertel! (@ Lloyd the III Taco Truck - @whereslloyd in Buffalo, NY) https:\/\/t.co\/kaKheyyg13",
  "id" : 505749154816339968,
  "created_at" : "2014-08-30 16:09:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CAN U NOT",
      "screen_name" : "nerdpropeller",
      "indices" : [ 0, 14 ],
      "id_str" : "380970929",
      "id" : 380970929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505561065561014272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240259569, -78.8791345186 ]
  },
  "id_str" : "505561625475047425",
  "in_reply_to_user_id" : 380970929,
  "text" : "@nerdpropeller how so?",
  "id" : 505561625475047425,
  "in_reply_to_status_id" : 505561065561014272,
  "created_at" : "2014-08-30 03:44:19 +0000",
  "in_reply_to_screen_name" : "nerdpropeller",
  "in_reply_to_user_id_str" : "380970929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.923516143, -78.879345681 ]
  },
  "id_str" : "505560169640509440",
  "text" : "Phish is live streaming a timelapse of creating their posters in Illustrator. They know their audience.",
  "id" : 505560169640509440,
  "created_at" : "2014-08-30 03:38:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Overheard at Phish",
      "screen_name" : "overheardphish",
      "indices" : [ 3, 18 ],
      "id_str" : "68008192",
      "id" : 68008192
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/overheardphish\/status\/505526927810375681\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/mw6VxVC5ZT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwP-D4BCYAAiB3t.jpg",
      "id_str" : "505526925725425664",
      "id" : 505526925725425664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwP-D4BCYAAiB3t.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mw6VxVC5ZT"
    } ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505527097578631168",
  "text" : "RT @overheardphish: \"Requests are Lame\" #phish http:\/\/t.co\/mw6VxVC5ZT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/overheardphish\/status\/505526927810375681\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/mw6VxVC5ZT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwP-D4BCYAAiB3t.jpg",
        "id_str" : "505526925725425664",
        "id" : 505526925725425664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwP-D4BCYAAiB3t.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mw6VxVC5ZT"
      } ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 20, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505526927810375681",
    "text" : "\"Requests are Lame\" #phish http:\/\/t.co\/mw6VxVC5ZT",
    "id" : 505526927810375681,
    "created_at" : "2014-08-30 01:26:26 +0000",
    "user" : {
      "name" : "Overheard at Phish",
      "screen_name" : "overheardphish",
      "protected" : false,
      "id_str" : "68008192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3276184625\/67af44db1547b16d028cc77221416f24_normal.jpeg",
      "id" : 68008192,
      "verified" : false
    }
  },
  "id" : 505527097578631168,
  "created_at" : "2014-08-30 01:27:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 0, 15 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505524343372517377",
  "geo" : { },
  "id_str" : "505524433503526912",
  "in_reply_to_user_id" : 1472209542,
  "text" : "@PublicEspresso Leave them. You can hang stuff on them. Way easier than brick.",
  "id" : 505524433503526912,
  "in_reply_to_status_id" : 505524343372517377,
  "created_at" : "2014-08-30 01:16:31 +0000",
  "in_reply_to_screen_name" : "PublicEspresso",
  "in_reply_to_user_id_str" : "1472209542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    }, {
      "name" : "thePhish",
      "screen_name" : "ThePhishFromTT",
      "indices" : [ 12, 27 ],
      "id_str" : "500243442",
      "id" : 500243442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505521539333488641",
  "geo" : { },
  "id_str" : "505521713413505024",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns @ThePhishFromTT :metal: have a good show!",
  "id" : 505521713413505024,
  "in_reply_to_status_id" : 505521539333488641,
  "created_at" : "2014-08-30 01:05:43 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 3, 17 ],
      "id_str" : "369585978",
      "id" : 369585978
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 51, 66 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505490369920774144",
  "text" : "RT @meaganewaller: Have you bought your tickets to @nickelcityruby yet? If not, you should definitely do that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 32, 47 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505489973752369152",
    "text" : "Have you bought your tickets to @nickelcityruby yet? If not, you should definitely do that.",
    "id" : 505489973752369152,
    "created_at" : "2014-08-29 22:59:35 +0000",
    "user" : {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "protected" : false,
      "id_str" : "369585978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559117803043950592\/Dxshutmf_normal.jpeg",
      "id" : 369585978,
      "verified" : false
    }
  },
  "id" : 505490369920774144,
  "created_at" : "2014-08-29 23:01:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 0, 15 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 16, 30 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505488021203218432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239853008, -78.8796659029 ]
  },
  "id_str" : "505489000191098880",
  "in_reply_to_user_id" : 1067596351,
  "text" : "@nickelcityruby @meaganewaller looks a little outdated, oops",
  "id" : 505489000191098880,
  "in_reply_to_status_id" : 505488021203218432,
  "created_at" : "2014-08-29 22:55:43 +0000",
  "in_reply_to_screen_name" : "nickelcityruby",
  "in_reply_to_user_id_str" : "1067596351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505433415404244992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244597183, -78.8793572863 ]
  },
  "id_str" : "505472420191281152",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive couch touring here\u2026thanks for doing this!",
  "id" : 505472420191281152,
  "in_reply_to_status_id" : 505433415404244992,
  "created_at" : "2014-08-29 21:49:50 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Brecher",
      "screen_name" : "EricaBrecher",
      "indices" : [ 0, 13 ],
      "id_str" : "188415509",
      "id" : 188415509
    }, {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "indices" : [ 14, 19 ],
      "id_str" : "15308015",
      "id" : 15308015
    }, {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 20, 31 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/PcGYeyBZBW",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Betteridge",
      "display_url" : "en.m.wikipedia.org\/wiki\/Betteridge"
    } ]
  },
  "in_reply_to_status_id_str" : "505452869148233728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924209971, -78.8792206411 ]
  },
  "id_str" : "505457199749922816",
  "in_reply_to_user_id" : 188415509,
  "text" : "@EricaBrecher @WGRZ @natebenson http:\/\/t.co\/PcGYeyBZBW\u2019s_law_of_headlines",
  "id" : 505457199749922816,
  "in_reply_to_status_id" : 505452869148233728,
  "created_at" : "2014-08-29 20:49:22 +0000",
  "in_reply_to_screen_name" : "EricaBrecher",
  "in_reply_to_user_id_str" : "188415509",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M Magnuson",
      "screen_name" : "m_magnuson",
      "indices" : [ 0, 11 ],
      "id_str" : "355041948",
      "id" : 355041948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505455067290693633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242385272, -78.8792120666 ]
  },
  "id_str" : "505456706764017665",
  "in_reply_to_user_id" : 355041948,
  "text" : "@m_magnuson the content is great but the way they present it and block you from accessing it is detestable.",
  "id" : 505456706764017665,
  "in_reply_to_status_id" : 505455067290693633,
  "created_at" : "2014-08-29 20:47:24 +0000",
  "in_reply_to_screen_name" : "m_magnuson",
  "in_reply_to_user_id_str" : "355041948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505453113781002241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.913032168, -78.876951556 ]
  },
  "id_str" : "505453898275237888",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski first I\u2019ve heard of this\u2026has it actually been proposed?",
  "id" : 505453898275237888,
  "in_reply_to_status_id" : 505453113781002241,
  "created_at" : "2014-08-29 20:36:14 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "indices" : [ 3, 12 ],
      "id_str" : "19278778",
      "id" : 19278778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gogaruco",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SI9ZX6ZsA2",
      "expanded_url" : "http:\/\/bit.ly\/1piVV6Y",
      "display_url" : "bit.ly\/1piVV6Y"
    } ]
  },
  "geo" : { },
  "id_str" : "505446628095197184",
  "text" : "RT @gogaruco: Only ~40 tickets left to #gogaruco 2014 :) We\u2019re in the home stretch, the time to act is now! http:\/\/t.co\/SI9ZX6ZsA2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gogaruco",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/SI9ZX6ZsA2",
        "expanded_url" : "http:\/\/bit.ly\/1piVV6Y",
        "display_url" : "bit.ly\/1piVV6Y"
      } ]
    },
    "geo" : { },
    "id_str" : "505433442448707584",
    "text" : "Only ~40 tickets left to #gogaruco 2014 :) We\u2019re in the home stretch, the time to act is now! http:\/\/t.co\/SI9ZX6ZsA2",
    "id" : 505433442448707584,
    "created_at" : "2014-08-29 19:14:57 +0000",
    "user" : {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "protected" : false,
      "id_str" : "19278778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473191115361759232\/sZC2l6GQ_normal.png",
      "id" : 19278778,
      "verified" : false
    }
  },
  "id" : 505446628095197184,
  "created_at" : "2014-08-29 20:07:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "indices" : [ 3, 19 ],
      "id_str" : "16450873",
      "id" : 16450873
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 48, 63 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/FC93Z5bjFk",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "505443611476250624",
  "text" : "RT @infotechniagara: Have you signed up yet for @nickelcityruby Conference?!\n#Buffalo http:\/\/t.co\/FC93Z5bjFk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 27, 42 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 56, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/FC93Z5bjFk",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "505396434158759936",
    "text" : "Have you signed up yet for @nickelcityruby Conference?!\n#Buffalo http:\/\/t.co\/FC93Z5bjFk",
    "id" : 505396434158759936,
    "created_at" : "2014-08-29 16:47:54 +0000",
    "user" : {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "protected" : false,
      "id_str" : "16450873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64732059\/itn_logo_normal.jpg",
      "id" : 16450873,
      "verified" : false
    }
  },
  "id" : 505443611476250624,
  "created_at" : "2014-08-29 19:55:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 3, 15 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Q959f4Nh3B",
      "expanded_url" : "http:\/\/www.codemash.org\/call-speakers\/",
      "display_url" : "codemash.org\/call-speakers\/"
    } ]
  },
  "geo" : { },
  "id_str" : "505432109851635712",
  "text" : "RT @antiheroine: Hey! Did I mention that Codemash talk submissions close tomorrow? And that I'm looking for awesome design talks? http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Q959f4Nh3B",
        "expanded_url" : "http:\/\/www.codemash.org\/call-speakers\/",
        "display_url" : "codemash.org\/call-speakers\/"
      } ]
    },
    "geo" : { },
    "id_str" : "505429295171641344",
    "text" : "Hey! Did I mention that Codemash talk submissions close tomorrow? And that I'm looking for awesome design talks? http:\/\/t.co\/Q959f4Nh3B",
    "id" : 505429295171641344,
    "created_at" : "2014-08-29 18:58:29 +0000",
    "user" : {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "protected" : false,
      "id_str" : "588743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528165243961102337\/6SEpv7ld_normal.png",
      "id" : 588743,
      "verified" : false
    }
  },
  "id" : 505432109851635712,
  "created_at" : "2014-08-29 19:09:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/OfuLrtRX11",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/5400a760498e0b1713d38ec9?s=iMmD17RY3YxwtCKGrfKVG3TFNqA&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9115881341, -78.8772009053 ]
  },
  "id_str" : "505388541275561984",
  "text" : "I'm at Joe's Deli Elmwood in Buffalo, NY https:\/\/t.co\/OfuLrtRX11",
  "id" : 505388541275561984,
  "created_at" : "2014-08-29 16:16:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 89, 101 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505375371223502848",
  "text" : "RT @nickelcityruby: The only person lucky enough to be a return speaker, our dear friend @CoralineAda will be heading to #ncrc14 in October\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coraline Ada Ehmke",
        "screen_name" : "CoralineAda",
        "indices" : [ 69, 81 ],
        "id_str" : "9526722",
        "id" : 9526722
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505080980651401216",
    "text" : "The only person lucky enough to be a return speaker, our dear friend @CoralineAda will be heading to #ncrc14 in October, will you?",
    "id" : 505080980651401216,
    "created_at" : "2014-08-28 19:54:24 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 505375371223502848,
  "created_at" : "2014-08-29 15:24:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Julian Cheal",
      "screen_name" : "juliancheal",
      "indices" : [ 54, 66 ],
      "id_str" : "951511",
      "id" : 951511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/p0Yc9pUdRS",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
      "display_url" : "nickelcityruby.com\/#register"
    } ]
  },
  "geo" : { },
  "id_str" : "505375333088890880",
  "text" : "RT @nickelcityruby: Robots?!?!  That's right, we said @juliancheal and robots at #ncrc14 Get your tickets now!! http:\/\/t.co\/p0Yc9pUdRS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julian Cheal",
        "screen_name" : "juliancheal",
        "indices" : [ 34, 46 ],
        "id_str" : "951511",
        "id" : 951511
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 61, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/p0Yc9pUdRS",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
        "display_url" : "nickelcityruby.com\/#register"
      } ]
    },
    "geo" : { },
    "id_str" : "504683169271275520",
    "text" : "Robots?!?!  That's right, we said @juliancheal and robots at #ncrc14 Get your tickets now!! http:\/\/t.co\/p0Yc9pUdRS",
    "id" : 504683169271275520,
    "created_at" : "2014-08-27 17:33:38 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 505375333088890880,
  "created_at" : "2014-08-29 15:24:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "16-Bit Bar+Arcade",
      "screen_name" : "16BitBar",
      "indices" : [ 3, 12 ],
      "id_str" : "1335471740",
      "id" : 1335471740
    }, {
      "name" : "Cleveland Scene",
      "screen_name" : "Cleveland_Scene",
      "indices" : [ 28, 44 ],
      "id_str" : "18245880",
      "id" : 18245880
    }, {
      "name" : "Douglas Trattner",
      "screen_name" : "dougtrattner",
      "indices" : [ 104, 117 ],
      "id_str" : "87255373",
      "id" : 87255373
    }, {
      "name" : "16-Bit Bar+Arcade",
      "screen_name" : "16BitBar",
      "indices" : [ 118, 127 ],
      "id_str" : "1335471740",
      "id" : 1335471740
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Cleveland_Scene\/status\/505362680891207681\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/fqOWNtAQKQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwNorgTIAAAV6nN.jpg",
      "id_str" : "505362679809441792",
      "id" : 505362679809441792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwNorgTIAAAV6nN.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/fqOWNtAQKQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/lZQC3r6uDN",
      "expanded_url" : "http:\/\/www.clevescene.com\/scene-and-heard\/archives\/2014\/08\/29\/16-bit-bar-arcade-opens-today-in-lakewood",
      "display_url" : "clevescene.com\/scene-and-hear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505368976873226240",
  "text" : "RT @16BitBar: HELL YEAH!!! \u201C@Cleveland_Scene: 16-Bit Bar Opens Today in Lakewood\nhttp:\/\/t.co\/lZQC3r6uDN @dougtrattner @16BitBar http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cleveland Scene",
        "screen_name" : "Cleveland_Scene",
        "indices" : [ 14, 30 ],
        "id_str" : "18245880",
        "id" : 18245880
      }, {
        "name" : "Douglas Trattner",
        "screen_name" : "dougtrattner",
        "indices" : [ 90, 103 ],
        "id_str" : "87255373",
        "id" : 87255373
      }, {
        "name" : "16-Bit Bar+Arcade",
        "screen_name" : "16BitBar",
        "indices" : [ 104, 113 ],
        "id_str" : "1335471740",
        "id" : 1335471740
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Cleveland_Scene\/status\/505362680891207681\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/fqOWNtAQKQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwNorgTIAAAV6nN.jpg",
        "id_str" : "505362679809441792",
        "id" : 505362679809441792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwNorgTIAAAV6nN.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/fqOWNtAQKQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/lZQC3r6uDN",
        "expanded_url" : "http:\/\/www.clevescene.com\/scene-and-heard\/archives\/2014\/08\/29\/16-bit-bar-arcade-opens-today-in-lakewood",
        "display_url" : "clevescene.com\/scene-and-hear\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "505362680891207681",
    "geo" : { },
    "id_str" : "505364989709148163",
    "in_reply_to_user_id" : 18245880,
    "text" : "HELL YEAH!!! \u201C@Cleveland_Scene: 16-Bit Bar Opens Today in Lakewood\nhttp:\/\/t.co\/lZQC3r6uDN @dougtrattner @16BitBar http:\/\/t.co\/fqOWNtAQKQ\u201D",
    "id" : 505364989709148163,
    "in_reply_to_status_id" : 505362680891207681,
    "created_at" : "2014-08-29 14:42:57 +0000",
    "in_reply_to_screen_name" : "Cleveland_Scene",
    "in_reply_to_user_id_str" : "18245880",
    "user" : {
      "name" : "16-Bit Bar+Arcade",
      "screen_name" : "16BitBar",
      "protected" : false,
      "id_str" : "1335471740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3512152011\/56f0cde50ad17962337dfda83f699589_normal.png",
      "id" : 1335471740,
      "verified" : false
    }
  },
  "id" : 505368976873226240,
  "created_at" : "2014-08-29 14:58:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 3, 9 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 66, 78 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ZoWpxr5d70",
      "expanded_url" : "http:\/\/jonas.do\/writing\/the-power-of-free-design\/",
      "display_url" : "jonas.do\/writing\/the-po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505368738276061184",
  "text" : "RT @javan: \u2764\uFE0F The power of free design http:\/\/t.co\/ZoWpxr5d70 (by @jonasdowney)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonas Downey",
        "screen_name" : "jonasdowney",
        "indices" : [ 55, 67 ],
        "id_str" : "16454301",
        "id" : 16454301
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/ZoWpxr5d70",
        "expanded_url" : "http:\/\/jonas.do\/writing\/the-power-of-free-design\/",
        "display_url" : "jonas.do\/writing\/the-po\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "505364383510577153",
    "text" : "\u2764\uFE0F The power of free design http:\/\/t.co\/ZoWpxr5d70 (by @jonasdowney)",
    "id" : 505364383510577153,
    "created_at" : "2014-08-29 14:40:32 +0000",
    "user" : {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "protected" : false,
      "id_str" : "1679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526722729123143680\/0-ppDKP__normal.jpeg",
      "id" : 1679,
      "verified" : false
    }
  },
  "id" : 505368738276061184,
  "created_at" : "2014-08-29 14:57:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 3, 15 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/67Ky81hEic",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/mitch-hedberg-hippie-martian-zen-genius",
      "display_url" : "mcsweeneys.net\/articles\/mitch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505362484765536256",
  "text" : "RT @jonasdowney: Mitch Hedberg: Hippie Martian Zen Genius http:\/\/t.co\/67Ky81hEic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/67Ky81hEic",
        "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/mitch-hedberg-hippie-martian-zen-genius",
        "display_url" : "mcsweeneys.net\/articles\/mitch\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "505362007835426816",
    "text" : "Mitch Hedberg: Hippie Martian Zen Genius http:\/\/t.co\/67Ky81hEic",
    "id" : 505362007835426816,
    "created_at" : "2014-08-29 14:31:06 +0000",
    "user" : {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "protected" : false,
      "id_str" : "16454301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153090409\/f136c60eca258e42e43b2d1760196833_normal.jpeg",
      "id" : 16454301,
      "verified" : false
    }
  },
  "id" : 505362484765536256,
  "created_at" : "2014-08-29 14:33:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505361239963234304",
  "text" : "RT @dwarfort_txt: learning to be a necromancer and then animating your own severed arm as a permanent traveling companion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505143229080014849",
    "text" : "learning to be a necromancer and then animating your own severed arm as a permanent traveling companion",
    "id" : 505143229080014849,
    "created_at" : "2014-08-29 00:01:45 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 505361239963234304,
  "created_at" : "2014-08-29 14:28:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505200944263725056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242535612, -78.8793446582 ]
  },
  "id_str" : "505201778564927489",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 Diners, Driveins, and Dies",
  "id" : 505201778564927489,
  "in_reply_to_status_id" : 505200944263725056,
  "created_at" : "2014-08-29 03:54:24 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike El",
      "screen_name" : "mesharif",
      "indices" : [ 3, 12 ],
      "id_str" : "30205317",
      "id" : 30205317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505137071204618240",
  "text" : "RT @mesharif: Love it or hate it, there was a line to see Sharkgirl on a Thursday afternoon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505072767575015424",
    "text" : "Love it or hate it, there was a line to see Sharkgirl on a Thursday afternoon.",
    "id" : 505072767575015424,
    "created_at" : "2014-08-28 19:21:46 +0000",
    "user" : {
      "name" : "Mike El",
      "screen_name" : "mesharif",
      "protected" : false,
      "id_str" : "30205317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571480763927035904\/2HQtIePL_normal.jpeg",
      "id" : 30205317,
      "verified" : false
    }
  },
  "id" : 505137071204618240,
  "created_at" : "2014-08-28 23:37:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505096417762115585",
  "geo" : { },
  "id_str" : "505098780505817088",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @nickelcityruby Really considering a field trip.",
  "id" : 505098780505817088,
  "in_reply_to_status_id" : 505096417762115585,
  "created_at" : "2014-08-28 21:05:08 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BAKOON ",
      "screen_name" : "BAKKOOONN",
      "indices" : [ 3, 13 ],
      "id_str" : "1263540390",
      "id" : 1263540390
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BAKKOOONN\/status\/505090640657408001\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7OIGqhqsH7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwJxQsMCEAAz9w4.jpg",
      "id_str" : "505090639772389376",
      "id" : 505090639772389376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwJxQsMCEAAz9w4.jpg",
      "sizes" : [ {
        "h" : 552,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7OIGqhqsH7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505091170976792576",
  "text" : "RT @BAKKOOONN: i wish i didnt look at the analytics thing and found out all my followers are these guys http:\/\/t.co\/7OIGqhqsH7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BAKKOOONN\/status\/505090640657408001\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/7OIGqhqsH7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwJxQsMCEAAz9w4.jpg",
        "id_str" : "505090639772389376",
        "id" : 505090639772389376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwJxQsMCEAAz9w4.jpg",
        "sizes" : [ {
          "h" : 552,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 552,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 552,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7OIGqhqsH7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505090640657408001",
    "text" : "i wish i didnt look at the analytics thing and found out all my followers are these guys http:\/\/t.co\/7OIGqhqsH7",
    "id" : 505090640657408001,
    "created_at" : "2014-08-28 20:32:47 +0000",
    "user" : {
      "name" : "BAKOON ",
      "screen_name" : "BAKKOOONN",
      "protected" : false,
      "id_str" : "1263540390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573804120840122368\/RmV_AarU_normal.jpeg",
      "id" : 1263540390,
      "verified" : false
    }
  },
  "id" : 505091170976792576,
  "created_at" : "2014-08-28 20:34:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 97, 112 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505063233552519169",
  "text" : "Let's clear up a misconception - you don't need to know Ruby well, or at all to get a lot out of @nickelcityruby! \"Ruby\" here = welcoming :)",
  "id" : 505063233552519169,
  "created_at" : "2014-08-28 18:43:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505062500636049408",
  "geo" : { },
  "id_str" : "505062820937859072",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel @nickelcityruby I count no less than 7 talks that aren't Ruby focused. I don't know how else to express this :)",
  "id" : 505062820937859072,
  "in_reply_to_status_id" : 505062500636049408,
  "created_at" : "2014-08-28 18:42:14 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 14, 29 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "505059445135523840",
  "text" : "36 days until @nickelcityruby. Perfect time to make some plans to get here. We have an awesome lineup for you --&gt; http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 505059445135523840,
  "created_at" : "2014-08-28 18:28:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 3, 9 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 60, 75 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505057489449000961",
  "text" : "RT @chorn: This is a really good time to buy your ticket to @nickelcityruby!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 49, 64 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504972994662641664",
    "text" : "This is a really good time to buy your ticket to @nickelcityruby!",
    "id" : 504972994662641664,
    "created_at" : "2014-08-28 12:45:18 +0000",
    "user" : {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "protected" : false,
      "id_str" : "744613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2310147637\/niixqq7ibisfwaat2xmg_normal.png",
      "id" : 744613,
      "verified" : false
    }
  },
  "id" : 505057489449000961,
  "created_at" : "2014-08-28 18:21:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "indices" : [ 0, 12 ],
      "id_str" : "261031908",
      "id" : 261031908
    }, {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 13, 25 ],
      "id_str" : "48160411",
      "id" : 48160411
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 26, 40 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505037409894268932",
  "geo" : { },
  "id_str" : "505038596131147776",
  "in_reply_to_user_id" : 261031908,
  "text" : "@HeyRaChaCha @timbouchard @coworkbuffalo it sure seems like a bike lane",
  "id" : 505038596131147776,
  "in_reply_to_status_id" : 505037409894268932,
  "created_at" : "2014-08-28 17:05:59 +0000",
  "in_reply_to_screen_name" : "HeyRaChaCha",
  "in_reply_to_user_id_str" : "261031908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/505034460455501824\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ahNA30ckKP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwI-KaSIcAAinEd.jpg",
      "id_str" : "505034456793903104",
      "id" : 505034456793903104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwI-KaSIcAAinEd.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/ahNA30ckKP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505034527388209152",
  "text" : "RT @coworkbuffalo: Our bike lanes are going in! \uD83D\uDE02\uD83D\uDEB2 http:\/\/t.co\/ahNA30ckKP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/505034460455501824\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/ahNA30ckKP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwI-KaSIcAAinEd.jpg",
        "id_str" : "505034456793903104",
        "id" : 505034456793903104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwI-KaSIcAAinEd.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/ahNA30ckKP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505034460455501824",
    "text" : "Our bike lanes are going in! \uD83D\uDE02\uD83D\uDEB2 http:\/\/t.co\/ahNA30ckKP",
    "id" : 505034460455501824,
    "created_at" : "2014-08-28 16:49:33 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 505034527388209152,
  "created_at" : "2014-08-28 16:49:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YgvAtN9Zxp",
      "expanded_url" : "https:\/\/www.meteor.com\/blog\/2014\/08\/28\/isobuild-why-meteor-created-a-new-package-system",
      "display_url" : "meteor.com\/blog\/2014\/08\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505033552300236800",
  "text" : "Impressive to see lots of time, thought, and energy being put into JS packaging. I wish Ruby had more competition: https:\/\/t.co\/YgvAtN9Zxp",
  "id" : 505033552300236800,
  "created_at" : "2014-08-28 16:45:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/505030792355926016\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/4PG4NYoEHh",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BwI607kCQAAMcio.png",
      "id_str" : "505030789235359744",
      "id" : 505030789235359744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BwI607kCQAAMcio.png",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 228
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 228
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 228
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 228
      } ],
      "display_url" : "pic.twitter.com\/4PG4NYoEHh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505030792355926016",
  "text" : "\"created from three sets of overlapping circles, suggesting the way interests, events and people interact\" http:\/\/t.co\/4PG4NYoEHh",
  "id" : 505030792355926016,
  "created_at" : "2014-08-28 16:34:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/iYAwkz9gG1",
      "expanded_url" : "http:\/\/somebodyapp.com",
      "display_url" : "somebodyapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "505024773655498752",
  "text" : "This is a wild social experiment: http:\/\/t.co\/iYAwkz9gG1",
  "id" : 505024773655498752,
  "created_at" : "2014-08-28 16:11:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/SSAqXHPFzY",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2014\/08\/27\/cities-quality-of-life_n_5718585.html?utm_hp_ref=tw",
      "display_url" : "huffingtonpost.com\/2014\/08\/27\/cit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505010919928119297",
  "text" : "RT @nickelcityruby: Come to the city with the 6th Highest Quaility of Life for #ncrc14 - http:\/\/t.co\/SSAqXHPFzY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/SSAqXHPFzY",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2014\/08\/27\/cities-quality-of-life_n_5718585.html?utm_hp_ref=tw",
        "display_url" : "huffingtonpost.com\/2014\/08\/27\/cit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "505010223405629440",
    "text" : "Come to the city with the 6th Highest Quaility of Life for #ncrc14 - http:\/\/t.co\/SSAqXHPFzY",
    "id" : 505010223405629440,
    "created_at" : "2014-08-28 15:13:14 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 505010919928119297,
  "created_at" : "2014-08-28 15:16:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 3, 14 ],
      "id_str" : "67117740",
      "id" : 67117740
    }, {
      "name" : "Turkuaz",
      "screen_name" : "Turkuaz",
      "indices" : [ 17, 25 ],
      "id_str" : "195630460",
      "id" : 195630460
    }, {
      "name" : "brooklynbowl",
      "screen_name" : "brooklynbowl",
      "indices" : [ 71, 84 ],
      "id_str" : "17885166",
      "id" : 17885166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/H3w6ginodL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=NsXQUHH8Euo",
      "display_url" : "youtube.com\/watch?v=NsXQUH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504999295007744000",
  "text" : "RT @Dianna_2Ns: .@turkuaz debuted their brand new music video \"XYZ\" at @brooklynbowl last night &amp; it was awesome :) Check it out! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Turkuaz",
        "screen_name" : "Turkuaz",
        "indices" : [ 1, 9 ],
        "id_str" : "195630460",
        "id" : 195630460
      }, {
        "name" : "brooklynbowl",
        "screen_name" : "brooklynbowl",
        "indices" : [ 55, 68 ],
        "id_str" : "17885166",
        "id" : 17885166
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/H3w6ginodL",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=NsXQUHH8Euo",
        "display_url" : "youtube.com\/watch?v=NsXQUH\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504994575023636480",
    "text" : ".@turkuaz debuted their brand new music video \"XYZ\" at @brooklynbowl last night &amp; it was awesome :) Check it out! https:\/\/t.co\/H3w6ginodL",
    "id" : 504994575023636480,
    "created_at" : "2014-08-28 14:11:03 +0000",
    "user" : {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "protected" : false,
      "id_str" : "67117740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546699404082950144\/apgZNPDY_normal.jpeg",
      "id" : 67117740,
      "verified" : false
    }
  },
  "id" : 504999295007744000,
  "created_at" : "2014-08-28 14:29:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Owens",
      "screen_name" : "intjonathan",
      "indices" : [ 3, 15 ],
      "id_str" : "62634651",
      "id" : 62634651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Zrn3PNoEQu",
      "expanded_url" : "http:\/\/www.cgsociety.org\/index.php\/CGSFeatures\/CGSFeatureSpecial\/building_3d_with_ikea",
      "display_url" : "cgsociety.org\/index.php\/CGSF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504993941834715136",
  "text" : "RT @intjonathan: Many of IKEA's product photos are computer generated. http:\/\/t.co\/Zrn3PNoEQu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/Zrn3PNoEQu",
        "expanded_url" : "http:\/\/www.cgsociety.org\/index.php\/CGSFeatures\/CGSFeatureSpecial\/building_3d_with_ikea",
        "display_url" : "cgsociety.org\/index.php\/CGSF\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504990770030321664",
    "text" : "Many of IKEA's product photos are computer generated. http:\/\/t.co\/Zrn3PNoEQu",
    "id" : 504990770030321664,
    "created_at" : "2014-08-28 13:55:56 +0000",
    "user" : {
      "name" : "Jonathan Owens",
      "screen_name" : "intjonathan",
      "protected" : false,
      "id_str" : "62634651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346477099\/IMG_0101_normal.jpg",
      "id" : 62634651,
      "verified" : false
    }
  },
  "id" : 504993941834715136,
  "created_at" : "2014-08-28 14:08:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Y4DpLjhJ6Z",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=bjZO94Ox7Fc",
      "display_url" : "m.youtube.com\/watch?v=bjZO94\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504962607124860928",
  "text" : "This is a lot more fun to learn piano with than kids songs. http:\/\/t.co\/Y4DpLjhJ6Z",
  "id" : 504962607124860928,
  "created_at" : "2014-08-28 12:04:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/504843029581017088\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ZE8uhsTD7O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwGQD0QCAAENYgp.png",
      "id_str" : "504843028482097153",
      "id" : 504843028482097153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwGQD0QCAAENYgp.png",
      "sizes" : [ {
        "h" : 292,
        "resize" : "fit",
        "w" : 692
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 692
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZE8uhsTD7O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504843029581017088",
  "text" : "First time setting up CloudFront as an asset host. I feel like I deserve to put this on my fridge. http:\/\/t.co\/ZE8uhsTD7O",
  "id" : 504843029581017088,
  "created_at" : "2014-08-28 04:08:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 0, 11 ],
      "id_str" : "28650670",
      "id" : 28650670
    }, {
      "name" : "lynn_cyrin.py",
      "screen_name" : "lynncyrin",
      "indices" : [ 12, 22 ],
      "id_str" : "2482743224",
      "id" : 2482743224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504842444127866880",
  "geo" : { },
  "id_str" : "504842761405599744",
  "in_reply_to_user_id" : 28650670,
  "text" : "@duckinator @lynncyrin not too sure if this is configurable. could make a quick rake (or cap!) task to hide it: `rake deploy`",
  "id" : 504842761405599744,
  "in_reply_to_status_id" : 504842444127866880,
  "created_at" : "2014-08-28 04:07:48 +0000",
  "in_reply_to_screen_name" : "duckinator",
  "in_reply_to_user_id_str" : "28650670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 0, 11 ],
      "id_str" : "28650670",
      "id" : 28650670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504840584780337152",
  "geo" : { },
  "id_str" : "504841283177684992",
  "in_reply_to_user_id" : 28650670,
  "text" : "@duckinator git push origin whatever-branch:master",
  "id" : 504841283177684992,
  "in_reply_to_status_id" : 504840584780337152,
  "created_at" : "2014-08-28 04:01:56 +0000",
  "in_reply_to_screen_name" : "duckinator",
  "in_reply_to_user_id_str" : "28650670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/504781262985633792\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/cqtuBLXSjQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwFX4f6CQAE8XVj.png",
      "id_str" : "504781261391413249",
      "id" : 504781261391413249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwFX4f6CQAE8XVj.png",
      "sizes" : [ {
        "h" : 151,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 1216
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cqtuBLXSjQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504781262985633792",
  "text" : "This is awful. http:\/\/t.co\/cqtuBLXSjQ",
  "id" : 504781262985633792,
  "created_at" : "2014-08-28 00:03:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 0, 12 ],
      "id_str" : "48160411",
      "id" : 48160411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/l6czdNp8lh",
      "expanded_url" : "https:\/\/itunes.apple.com\/app\/id740146917",
      "display_url" : "itunes.apple.com\/app\/id740146917"
    } ]
  },
  "in_reply_to_status_id_str" : "504726845389299712",
  "geo" : { },
  "id_str" : "504727060292448256",
  "in_reply_to_user_id" : 48160411,
  "text" : "@timbouchard https:\/\/t.co\/l6czdNp8lh",
  "id" : 504727060292448256,
  "in_reply_to_status_id" : 504726845389299712,
  "created_at" : "2014-08-27 20:28:03 +0000",
  "in_reply_to_screen_name" : "timbouchard",
  "in_reply_to_user_id_str" : "48160411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504726594846351360",
  "text" : "Has anyone taken Hyperlapse on a rollercoaster yet?",
  "id" : 504726594846351360,
  "created_at" : "2014-08-27 20:26:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 19, 29 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504725570958426113",
  "geo" : { },
  "id_str" : "504726008210014209",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss ughhhh \/cc @zachwaugh",
  "id" : 504726008210014209,
  "in_reply_to_status_id" : 504725570958426113,
  "created_at" : "2014-08-27 20:23:52 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504724751919886336",
  "geo" : { },
  "id_str" : "504725412211986433",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss why?",
  "id" : 504725412211986433,
  "in_reply_to_status_id" : 504724751919886336,
  "created_at" : "2014-08-27 20:21:30 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 9, 16 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504686957796945920",
  "geo" : { },
  "id_str" : "504699106963374082",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms @wycats &lt;3",
  "id" : 504699106963374082,
  "in_reply_to_status_id" : 504686957796945920,
  "created_at" : "2014-08-27 18:36:58 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/6QqJULNsHf",
      "expanded_url" : "http:\/\/bv.ms\/1tDDwDW",
      "display_url" : "bv.ms\/1tDDwDW"
    } ]
  },
  "geo" : { },
  "id_str" : "504698071645970433",
  "text" : "RT @rachbarnhart: \"Print newspapers are going to die; at this point they\u2019re living off coupons...and old people\" http:\/\/t.co\/6QqJULNsHf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/6QqJULNsHf",
        "expanded_url" : "http:\/\/bv.ms\/1tDDwDW",
        "display_url" : "bv.ms\/1tDDwDW"
      } ]
    },
    "geo" : { },
    "id_str" : "504697803734392832",
    "text" : "\"Print newspapers are going to die; at this point they\u2019re living off coupons...and old people\" http:\/\/t.co\/6QqJULNsHf",
    "id" : 504697803734392832,
    "created_at" : "2014-08-27 18:31:47 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 504698071645970433,
  "created_at" : "2014-08-27 18:32:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "jlsmp",
      "indices" : [ 0, 6 ],
      "id_str" : "1856037409",
      "id" : 1856037409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504686969746882561",
  "geo" : { },
  "id_str" : "504687753506725888",
  "in_reply_to_user_id" : 1856037409,
  "text" : "@jlsmp what other apps does it have?",
  "id" : 504687753506725888,
  "in_reply_to_status_id" : 504686969746882561,
  "created_at" : "2014-08-27 17:51:51 +0000",
  "in_reply_to_screen_name" : "jlsmp",
  "in_reply_to_user_id_str" : "1856037409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/504682080404398080\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/RcB6W6Bf8u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwD9rZACUAENh1F.jpg",
      "id_str" : "504682080152735745",
      "id" : 504682080152735745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwD9rZACUAENh1F.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RcB6W6Bf8u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504682080404398080",
  "text" : "Refactor &gt; Extract Method http:\/\/t.co\/RcB6W6Bf8u",
  "id" : 504682080404398080,
  "created_at" : "2014-08-27 17:29:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 3, 10 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/bNEwbymmoI",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "504673997506621441",
  "text" : "RT @bryanl: My next talk will be entitled, \"Abstractions Breed Intuition\" I'll be giving it in October at Nickel City Ruby (http:\/\/t.co\/bNE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/bNEwbymmoI",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "504673881035374593",
    "text" : "My next talk will be entitled, \"Abstractions Breed Intuition\" I'll be giving it in October at Nickel City Ruby (http:\/\/t.co\/bNEwbymmoI)",
    "id" : 504673881035374593,
    "created_at" : "2014-08-27 16:56:44 +0000",
    "user" : {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "protected" : false,
      "id_str" : "659933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573327799135559680\/GiTRW1Hw_normal.jpeg",
      "id" : 659933,
      "verified" : false
    }
  },
  "id" : 504673997506621441,
  "created_at" : "2014-08-27 16:57:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jon hendren",
      "screen_name" : "fart",
      "indices" : [ 3, 8 ],
      "id_str" : "14166714",
      "id" : 14166714
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DevOps",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/jnUd3WcsJR",
      "expanded_url" : "http:\/\/jonhendren.com",
      "display_url" : "jonhendren.com"
    } ]
  },
  "geo" : { },
  "id_str" : "504672191330254849",
  "text" : "RT @fart: last night i unveiled my new #DevOps Thought Leader website. it is beautiful and i love it. http:\/\/t.co\/jnUd3WcsJR i am a powerho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DevOps",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/jnUd3WcsJR",
        "expanded_url" : "http:\/\/jonhendren.com",
        "display_url" : "jonhendren.com"
      } ]
    },
    "geo" : { },
    "id_str" : "504670628276744192",
    "text" : "last night i unveiled my new #DevOps Thought Leader website. it is beautiful and i love it. http:\/\/t.co\/jnUd3WcsJR i am a powerhouse",
    "id" : 504670628276744192,
    "created_at" : "2014-08-27 16:43:48 +0000",
    "user" : {
      "name" : "jon hendren",
      "screen_name" : "fart",
      "protected" : false,
      "id_str" : "14166714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524567386729775104\/eaE_S9Rq_normal.jpeg",
      "id" : 14166714,
      "verified" : false
    }
  },
  "id" : 504672191330254849,
  "created_at" : "2014-08-27 16:50:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/504652870424084481\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/ro31asau5b",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BwDjG-XCUAEenuD.png",
      "id_str" : "504652867223834625",
      "id" : 504652867223834625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BwDjG-XCUAEenuD.png",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/ro31asau5b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504652870424084481",
  "text" : "POJO.\nPORO.\nPONSO. http:\/\/t.co\/ro31asau5b",
  "id" : 504652870424084481,
  "created_at" : "2014-08-27 15:33:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 0, 11 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504646400206852096",
  "geo" : { },
  "id_str" : "504646619917086720",
  "in_reply_to_user_id" : 25678101,
  "text" : "@natebenson awesome. i really hope you weren't laying on the ground in a median.",
  "id" : 504646619917086720,
  "in_reply_to_status_id" : 504646400206852096,
  "created_at" : "2014-08-27 15:08:24 +0000",
  "in_reply_to_screen_name" : "natebenson",
  "in_reply_to_user_id_str" : "25678101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/8S9eQENsQM",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=mC0JjsPesq4",
      "display_url" : "youtube.com\/watch?v=mC0Jjs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504637591774187522",
  "text" : "Starting today off right with The Median: https:\/\/t.co\/8S9eQENsQM (Was on the rail for this show, love this venue!)",
  "id" : 504637591774187522,
  "created_at" : "2014-08-27 14:32:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 3, 15 ],
      "id_str" : "9526722",
      "id" : 9526722
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 80, 95 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504613681112432640",
  "text" : "RT @CoralineAda: Come see me talk about aesthetics and the evolution of code at @nickelcityruby in October!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 63, 78 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504466352162099201",
    "text" : "Come see me talk about aesthetics and the evolution of code at @nickelcityruby in October!",
    "id" : 504466352162099201,
    "created_at" : "2014-08-27 03:12:05 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 504613681112432640,
  "created_at" : "2014-08-27 12:57:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CISBSC",
      "screen_name" : "CISBSC",
      "indices" : [ 3, 10 ],
      "id_str" : "765849866",
      "id" : 765849866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/13DluYGDhb",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    }, {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/avkW1glGK5",
      "expanded_url" : "http:\/\/fb.me\/2tkRyaMPf",
      "display_url" : "fb.me\/2tkRyaMPf"
    } ]
  },
  "geo" : { },
  "id_str" : "504613668441452545",
  "text" : "RT @CISBSC: Nickel City Ruby! Check out the website at http:\/\/t.co\/13DluYGDhb\n\nThis local conference is a great chance... http:\/\/t.co\/avkW1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/13DluYGDhb",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      }, {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/avkW1glGK5",
        "expanded_url" : "http:\/\/fb.me\/2tkRyaMPf",
        "display_url" : "fb.me\/2tkRyaMPf"
      } ]
    },
    "geo" : { },
    "id_str" : "504446634978443264",
    "text" : "Nickel City Ruby! Check out the website at http:\/\/t.co\/13DluYGDhb\n\nThis local conference is a great chance... http:\/\/t.co\/avkW1glGK5",
    "id" : 504446634978443264,
    "created_at" : "2014-08-27 01:53:44 +0000",
    "user" : {
      "name" : "CISBSC",
      "screen_name" : "CISBSC",
      "protected" : false,
      "id_str" : "765849866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556203016\/q6uzrnsc0myhqpy63x16_normal.jpeg",
      "id" : 765849866,
      "verified" : false
    }
  },
  "id" : 504613668441452545,
  "created_at" : "2014-08-27 12:57:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Pochron",
      "screen_name" : "garypochron",
      "indices" : [ 3, 15 ],
      "id_str" : "36580514",
      "id" : 36580514
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504613657024528385",
  "text" : "RT @garypochron: Last year's @nickelcityruby conference was solid. Developers from any background will definitely take something from it. C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 12, 27 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504457374313512960",
    "text" : "Last year's @nickelcityruby conference was solid. Developers from any background will definitely take something from it. Check it out.",
    "id" : 504457374313512960,
    "created_at" : "2014-08-27 02:36:25 +0000",
    "user" : {
      "name" : "Gary Pochron",
      "screen_name" : "garypochron",
      "protected" : false,
      "id_str" : "36580514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2821294155\/ade795d65bee581aa36a565bd32bba42_normal.jpeg",
      "id" : 36580514,
      "verified" : false
    }
  },
  "id" : 504613657024528385,
  "created_at" : "2014-08-27 12:57:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504493455116996608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243578855, -78.8791242243 ]
  },
  "id_str" : "504493753222959106",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft I think that\u2019s why it\u2019s so compelling. The mystery and the sheer guts to do that for 10000 days.",
  "id" : 504493753222959106,
  "in_reply_to_status_id" : 504493455116996608,
  "created_at" : "2014-08-27 05:00:58 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504407526771654656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243578855, -78.8791242243 ]
  },
  "id_str" : "504493098756341760",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan UGHHHHHHH (I hope this buzzes your phone at 1am that\u2019s how bad it is)",
  "id" : 504493098756341760,
  "in_reply_to_status_id" : 504407526771654656,
  "created_at" : "2014-08-27 04:58:22 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IoT Wario",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504491739382423552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240281509, -78.879144238 ]
  },
  "id_str" : "504492463243816960",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft that GQ story is really good. Amazed they just could not find him. It\u2019s like no one really tried.",
  "id" : 504492463243816960,
  "in_reply_to_status_id" : 504491739382423552,
  "created_at" : "2014-08-27 04:55:50 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241940016, -78.8796442768 ]
  },
  "id_str" : "504482301246324736",
  "text" : "Trying out The Firm, and feels way too fucked up that your player kills themself when you lose a game. Even keeps track of \u201Csuicides\u201D",
  "id" : 504482301246324736,
  "created_at" : "2014-08-27 04:15:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 0, 13 ],
      "id_str" : "35163668",
      "id" : 35163668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504472843267362816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242192438, -78.8791877788 ]
  },
  "id_str" : "504472964759166976",
  "in_reply_to_user_id" : 35163668,
  "text" : "@pookleblinky I think you just invented a new Lisp dialect",
  "id" : 504472964759166976,
  "in_reply_to_status_id" : 504472843267362816,
  "created_at" : "2014-08-27 03:38:22 +0000",
  "in_reply_to_screen_name" : "pookleblinky",
  "in_reply_to_user_id_str" : "35163668",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raymond T. Hightower",
      "screen_name" : "RayHightower",
      "indices" : [ 3, 16 ],
      "id_str" : "17503660",
      "id" : 17503660
    }, {
      "name" : "WindyCityRails",
      "screen_name" : "WindyCityRails",
      "indices" : [ 31, 46 ],
      "id_str" : "16104710",
      "id" : 16104710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/G30VaTLMu6",
      "expanded_url" : "http:\/\/www.windycityrails.org\/schedule\/",
      "display_url" : "windycityrails.org\/schedule\/"
    } ]
  },
  "geo" : { },
  "id_str" : "504472332140679168",
  "text" : "RT @RayHightower: Amazing # of @WindyCityRails ticket sales today. Want to boost your Ruby\/Rails skills? Speakers &amp; registration: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WindyCityRails",
        "screen_name" : "WindyCityRails",
        "indices" : [ 13, 28 ],
        "id_str" : "16104710",
        "id" : 16104710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/G30VaTLMu6",
        "expanded_url" : "http:\/\/www.windycityrails.org\/schedule\/",
        "display_url" : "windycityrails.org\/schedule\/"
      } ]
    },
    "geo" : { },
    "id_str" : "504355429883707392",
    "text" : "Amazing # of @WindyCityRails ticket sales today. Want to boost your Ruby\/Rails skills? Speakers &amp; registration: http:\/\/t.co\/G30VaTLMu6",
    "id" : 504355429883707392,
    "created_at" : "2014-08-26 19:51:19 +0000",
    "user" : {
      "name" : "Raymond T. Hightower",
      "screen_name" : "RayHightower",
      "protected" : false,
      "id_str" : "17503660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485857090036981760\/o-2RmuZQ_normal.png",
      "id" : 17503660,
      "verified" : false
    }
  },
  "id" : 504472332140679168,
  "created_at" : "2014-08-27 03:35:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243732663, -78.8791758568 ]
  },
  "id_str" : "504468363611893761",
  "text" : "Quite glad the Hyperlapse app does not require an Instagram account. Will try it out tomorrow!",
  "id" : 504468363611893761,
  "created_at" : "2014-08-27 03:20:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242912075, -78.8790725079 ]
  },
  "id_str" : "504467714123911168",
  "text" : "Kodak : Digital Camera :: Microsoft : Hyperlapse",
  "id" : 504467714123911168,
  "created_at" : "2014-08-27 03:17:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yoder",
      "screen_name" : "doug_yoder",
      "indices" : [ 3, 14 ],
      "id_str" : "14680570",
      "id" : 14680570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/G3nPHDy7JU",
      "expanded_url" : "https:\/\/ti.to\/-\/MtdaHw",
      "display_url" : "ti.to\/-\/MtdaHw"
    } ]
  },
  "geo" : { },
  "id_str" : "504464383464857601",
  "text" : "RT @doug_yoder: I just registered for Nickel City Ruby Conf 2014 https:\/\/t.co\/G3nPHDy7JU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/G3nPHDy7JU",
        "expanded_url" : "https:\/\/ti.to\/-\/MtdaHw",
        "display_url" : "ti.to\/-\/MtdaHw"
      } ]
    },
    "geo" : { },
    "id_str" : "504278000427212800",
    "text" : "I just registered for Nickel City Ruby Conf 2014 https:\/\/t.co\/G3nPHDy7JU",
    "id" : 504278000427212800,
    "created_at" : "2014-08-26 14:43:38 +0000",
    "user" : {
      "name" : "Doug Yoder",
      "screen_name" : "doug_yoder",
      "protected" : false,
      "id_str" : "14680570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426210551124217856\/RWKWZxPn_normal.jpeg",
      "id" : 14680570,
      "verified" : false
    }
  },
  "id" : 504464383464857601,
  "created_at" : "2014-08-27 03:04:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "indices" : [ 3, 12 ],
      "id_str" : "2998581",
      "id" : 2998581
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504464268398309376",
  "text" : "RT @kerrizor: If you ever wanted to play poker with me, @nickelcityruby is the conference to do it at!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 42, 57 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504376304704036864",
    "text" : "If you ever wanted to play poker with me, @nickelcityruby is the conference to do it at!",
    "id" : 504376304704036864,
    "created_at" : "2014-08-26 21:14:16 +0000",
    "user" : {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "protected" : false,
      "id_str" : "2998581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/498699336813797376\/qYzK1KlC_normal.jpeg",
      "id" : 2998581,
      "verified" : false
    }
  },
  "id" : 504464268398309376,
  "created_at" : "2014-08-27 03:03:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 80, 90 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "JorDan\u00E9e Key",
      "screen_name" : "JorDaneeKey",
      "indices" : [ 91, 103 ],
      "id_str" : "258063176",
      "id" : 258063176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/5zw3NMl6zl",
      "expanded_url" : "http:\/\/rochester.craigslist.org\/rvs\/4629027222.html",
      "display_url" : "rochester.craigslist.org\/rvs\/4629027222\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504447987716587520",
  "text" : "I'm not an Airstream guy, but this combo is amazing: http:\/\/t.co\/5zw3NMl6zl \/cc @asianmack @JorDaneeKey",
  "id" : 504447987716587520,
  "created_at" : "2014-08-27 01:59:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/rWhcZU2pZr",
      "expanded_url" : "https:\/\/github.com\/thoughtbot\/high_voltage#top-level-routes",
      "display_url" : "github.com\/thoughtbot\/hig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504439794894512128",
  "text" : "HIGH VOLTAGE has aged fantastically. Serves static pages with a host of tiny great features: https:\/\/t.co\/rWhcZU2pZr",
  "id" : 504439794894512128,
  "created_at" : "2014-08-27 01:26:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504439092650983424",
  "geo" : { },
  "id_str" : "504439472767774720",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda watching Archer has the same effect",
  "id" : 504439472767774720,
  "in_reply_to_status_id" : 504439092650983424,
  "created_at" : "2014-08-27 01:25:17 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504439368413491200",
  "text" : "@juliepagano thanks!",
  "id" : 504439368413491200,
  "created_at" : "2014-08-27 01:24:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 40, 55 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/6DlZQo7xMp",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3550-a-diverse-conference",
      "display_url" : "signalvnoise.com\/posts\/3550-a-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504426892493987840",
  "text" : "@juliepagano would appreciate a link to @nickelcityruby \/ https:\/\/t.co\/6DlZQo7xMp :)",
  "id" : 504426892493987840,
  "created_at" : "2014-08-27 00:35:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504413965045489664",
  "geo" : { },
  "id_str" : "504420994539220992",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel basically the point",
  "id" : 504420994539220992,
  "in_reply_to_status_id" : 504413965045489664,
  "created_at" : "2014-08-27 00:11:51 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    }, {
      "name" : "Albright-Knox",
      "screen_name" : "AlbrightKnox",
      "indices" : [ 143, 144 ],
      "id_str" : "19289541",
      "id" : 19289541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkGirl",
      "indices" : [ 137, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504402849971712001",
  "text" : "RT @markpoloncarz: (2) that is what great public art should do: make people think &amp; talk about art regardless of whether you like it #Shark\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Albright-Knox",
        "screen_name" : "AlbrightKnox",
        "indices" : [ 129, 142 ],
        "id_str" : "19289541",
        "id" : 19289541
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkGirl",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504400058171674624",
    "text" : "(2) that is what great public art should do: make people think &amp; talk about art regardless of whether you like it #SharkGirl @AlbrightKnox",
    "id" : 504400058171674624,
    "created_at" : "2014-08-26 22:48:39 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 504402849971712001,
  "created_at" : "2014-08-26 22:59:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504396444418457600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242103001, -78.8802209433 ]
  },
  "id_str" : "504396693417123840",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy went down to see it myself. The pressed just wrapped up. Random people started taking photos with it. It\u2019s gonna be a great hit.",
  "id" : 504396693417123840,
  "in_reply_to_status_id" : 504396444418457600,
  "created_at" : "2014-08-26 22:35:17 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    }, {
      "name" : "Shark Girl",
      "screen_name" : "sharkgirlbflo",
      "indices" : [ 90, 104 ],
      "id_str" : "2751997175",
      "id" : 2751997175
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/504371280351866880\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/SD95bDkDcH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_i_sjIQAIlMNl.jpg",
      "id_str" : "504371267206922242",
      "id" : 504371267206922242,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_i_sjIQAIlMNl.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SD95bDkDcH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504395931626639361",
  "text" : "RT @markpoloncarz: Seriously, it did not take long for Shark Girl to have a twitter page: @sharkgirlbflo. Didn't know your hands moved. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shark Girl",
        "screen_name" : "sharkgirlbflo",
        "indices" : [ 71, 85 ],
        "id_str" : "2751997175",
        "id" : 2751997175
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/504371280351866880\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/SD95bDkDcH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_i_sjIQAIlMNl.jpg",
        "id_str" : "504371267206922242",
        "id" : 504371267206922242,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_i_sjIQAIlMNl.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SD95bDkDcH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504371280351866880",
    "text" : "Seriously, it did not take long for Shark Girl to have a twitter page: @sharkgirlbflo. Didn't know your hands moved. http:\/\/t.co\/SD95bDkDcH",
    "id" : 504371280351866880,
    "created_at" : "2014-08-26 20:54:18 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 504395931626639361,
  "created_at" : "2014-08-26 22:32:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Grabianowski",
      "screen_name" : "therobotviking",
      "indices" : [ 3, 18 ],
      "id_str" : "38103823",
      "id" : 38103823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5lyI2MGx7a",
      "expanded_url" : "http:\/\/www.buffalonews.com\/gusto\/art\/shark-girl-is-buffalos-newest-public-sculpture-20140826",
      "display_url" : "buffalonews.com\/gusto\/art\/shar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504395861602734081",
  "text" : "RT @therobotviking: Buffalo's surrealism\/absurdism quotient significantly increased by Shark Girl. Two fins up. http:\/\/t.co\/5lyI2MGx7a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/5lyI2MGx7a",
        "expanded_url" : "http:\/\/www.buffalonews.com\/gusto\/art\/shark-girl-is-buffalos-newest-public-sculpture-20140826",
        "display_url" : "buffalonews.com\/gusto\/art\/shar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504363540246179841",
    "text" : "Buffalo's surrealism\/absurdism quotient significantly increased by Shark Girl. Two fins up. http:\/\/t.co\/5lyI2MGx7a",
    "id" : 504363540246179841,
    "created_at" : "2014-08-26 20:23:33 +0000",
    "user" : {
      "name" : "Ed Grabianowski",
      "screen_name" : "therobotviking",
      "protected" : false,
      "id_str" : "38103823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000676534306\/39b3cbd55f15ce58678f76f4cf5f94d4_normal.jpeg",
      "id" : 38103823,
      "verified" : false
    }
  },
  "id" : 504395861602734081,
  "created_at" : "2014-08-26 22:31:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/XUTiP4ZPZk",
      "expanded_url" : "https:\/\/flic.kr\/p\/oD6HM9",
      "display_url" : "flic.kr\/p\/oD6HM9"
    } ]
  },
  "geo" : { },
  "id_str" : "504357588348043264",
  "text" : "SHARK GIRL is real. Mobbed by people taking photos with it. https:\/\/t.co\/XUTiP4ZPZk",
  "id" : 504357588348043264,
  "created_at" : "2014-08-26 19:59:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBF Comics",
      "screen_name" : "PBFcomics",
      "indices" : [ 83, 93 ],
      "id_str" : "535561004",
      "id" : 535561004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504351360096419840",
  "text" : "I am going to embark on a mission to see SHARK GIRL. This is like something out of @pbfcomics.",
  "id" : 504351360096419840,
  "created_at" : "2014-08-26 19:35:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 71, 86 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AshleyHirtz\/status\/504348425815855105\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/EuexCEVCKA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_OOIKIUAAzocU.jpg",
      "id_str" : "504348425392246784",
      "id" : 504348425392246784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_OOIKIUAAzocU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/EuexCEVCKA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504348901827424256",
  "text" : "THERE IS A STATUE OF A SHARK GIRL at our waterfront. ~10 min walk from @nickelcityruby venue. Field trip? http:\/\/t.co\/EuexCEVCKA",
  "id" : 504348901827424256,
  "created_at" : "2014-08-26 19:25:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Hirtzel",
      "screen_name" : "AshleyHirtz",
      "indices" : [ 3, 15 ],
      "id_str" : "196353523",
      "id" : 196353523
    }, {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 106, 111 ],
      "id_str" : "20612109",
      "id" : 20612109
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AshleyHirtz\/status\/504348425815855105\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/7vjR54fgx1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_OOIKIUAAzocU.jpg",
      "id_str" : "504348425392246784",
      "id" : 504348425392246784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_OOIKIUAAzocU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/7vjR54fgx1"
    } ],
    "hashtags" : [ {
      "text" : "Canalside",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504348550357340160",
  "text" : "RT @AshleyHirtz: A public sculpture was unveiled at #Canalside today. The artwork is called \"Shark Girl.\" @WBFO http:\/\/t.co\/7vjR54fgx1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WBFO",
        "screen_name" : "WBFO",
        "indices" : [ 89, 94 ],
        "id_str" : "20612109",
        "id" : 20612109
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AshleyHirtz\/status\/504348425815855105\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/7vjR54fgx1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_OOIKIUAAzocU.jpg",
        "id_str" : "504348425392246784",
        "id" : 504348425392246784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_OOIKIUAAzocU.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/7vjR54fgx1"
      } ],
      "hashtags" : [ {
        "text" : "Canalside",
        "indices" : [ 35, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504348425815855105",
    "text" : "A public sculpture was unveiled at #Canalside today. The artwork is called \"Shark Girl.\" @WBFO http:\/\/t.co\/7vjR54fgx1",
    "id" : 504348425815855105,
    "created_at" : "2014-08-26 19:23:29 +0000",
    "user" : {
      "name" : "Ashley Hirtzel",
      "screen_name" : "AshleyHirtz",
      "protected" : false,
      "id_str" : "196353523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505943178252668928\/4PEdsGj-_normal.jpeg",
      "id" : 196353523,
      "verified" : false
    }
  },
  "id" : 504348550357340160,
  "created_at" : "2014-08-26 19:23:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 97, 112 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/kd7cL8zDZ3",
      "expanded_url" : "http:\/\/stepoutbuffalo.com\/10-great-patios-for-drinking-dining\/",
      "display_url" : "stepoutbuffalo.com\/10-great-patio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504327552261844992",
  "text" : "10 great patios in Buffalo's restaurants. Bonus points to anyone who manages to see them all for @nickelcityruby: http:\/\/t.co\/kd7cL8zDZ3",
  "id" : 504327552261844992,
  "created_at" : "2014-08-26 18:00:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504314389215084545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8905104896, -78.8726912157 ]
  },
  "id_str" : "504315565305896960",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh oh man. Type to remove splattered bugs from your screen",
  "id" : 504315565305896960,
  "in_reply_to_status_id" : 504314389215084545,
  "created_at" : "2014-08-26 17:12:55 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew S. Burns",
      "screen_name" : "mrwasteland",
      "indices" : [ 0, 12 ],
      "id_str" : "61336370",
      "id" : 61336370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504293845275017216",
  "geo" : { },
  "id_str" : "504294044659245056",
  "in_reply_to_user_id" : 61336370,
  "text" : "@mrwasteland peak subtweets",
  "id" : 504294044659245056,
  "in_reply_to_status_id" : 504293845275017216,
  "created_at" : "2014-08-26 15:47:24 +0000",
  "in_reply_to_screen_name" : "mrwasteland",
  "in_reply_to_user_id_str" : "61336370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 34, 46 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504287842227728384",
  "geo" : { },
  "id_str" : "504288204334170113",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad Need to find the right @AqueousBand jam for you. Going to take some time.",
  "id" : 504288204334170113,
  "in_reply_to_status_id" : 504287842227728384,
  "created_at" : "2014-08-26 15:24:11 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504287693564440576",
  "geo" : { },
  "id_str" : "504288088802095105",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda This is going to be a new lightning talk of mine. Just talk about brunch food.",
  "id" : 504288088802095105,
  "in_reply_to_status_id" : 504287693564440576,
  "created_at" : "2014-08-26 15:23:44 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 3, 15 ],
      "id_str" : "9526722",
      "id" : 9526722
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 17, 23 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504287976096927744",
  "text" : "RT @CoralineAda: @qrush I\u2019m a half-stack with blueberries and a side of scrambled eggs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "504287171763662850",
    "geo" : { },
    "id_str" : "504287693564440576",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush I\u2019m a half-stack with blueberries and a side of scrambled eggs.",
    "id" : 504287693564440576,
    "in_reply_to_status_id" : 504287171763662850,
    "created_at" : "2014-08-26 15:22:10 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 504287976096927744,
  "created_at" : "2014-08-26 15:23:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "indices" : [ 0, 10 ],
      "id_str" : "1649136702",
      "id" : 1649136702
    }, {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 11, 21 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504287493571629058",
  "in_reply_to_user_id" : 1649136702,
  "text" : "@phishmaps @mikehamad hey, do you do commissions? or take requests?",
  "id" : 504287493571629058,
  "created_at" : "2014-08-26 15:21:22 +0000",
  "in_reply_to_screen_name" : "phishmaps",
  "in_reply_to_user_id_str" : "1649136702",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504287171763662850",
  "text" : "I feel like we've reached peak \"full-stack developer\". What happened to just being a programmer?",
  "id" : 504287171763662850,
  "created_at" : "2014-08-26 15:20:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Z5NExDLRP7",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/tenth-circle-added-to-rapidly-growing-hell,507",
      "display_url" : "theonion.com\/articles\/tenth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504281014298894336",
  "text" : "\"This is an exciting time to be in Hell.\" http:\/\/t.co\/Z5NExDLRP7",
  "id" : 504281014298894336,
  "created_at" : "2014-08-26 14:55:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/cv3TaGXUn6",
      "expanded_url" : "http:\/\/git.io\/k7KQzQ",
      "display_url" : "git.io\/k7KQzQ"
    } ]
  },
  "geo" : { },
  "id_str" : "504279198752440320",
  "text" : "Bourbon.io continues to save time and energy. One quick mixin and bam, cross browser compatibility. Here's a diff: http:\/\/t.co\/cv3TaGXUn6",
  "id" : 504279198752440320,
  "created_at" : "2014-08-26 14:48:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Eichert",
      "screen_name" : "steveeichert",
      "indices" : [ 3, 16 ],
      "id_str" : "8126672",
      "id" : 8126672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/XdkhDNjRS0",
      "expanded_url" : "http:\/\/bit.ly\/XP0dtm",
      "display_url" : "bit.ly\/XP0dtm"
    } ]
  },
  "geo" : { },
  "id_str" : "504274871757463552",
  "text" : "RT @steveeichert: Basecamp's Rebel Recipe for Success: 5 Ways the Software Maverick Made Millions by Being Different http:\/\/t.co\/XdkhDNjRS0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/XdkhDNjRS0",
        "expanded_url" : "http:\/\/bit.ly\/XP0dtm",
        "display_url" : "bit.ly\/XP0dtm"
      } ]
    },
    "geo" : { },
    "id_str" : "504274618769997824",
    "text" : "Basecamp's Rebel Recipe for Success: 5 Ways the Software Maverick Made Millions by Being Different http:\/\/t.co\/XdkhDNjRS0",
    "id" : 504274618769997824,
    "created_at" : "2014-08-26 14:30:12 +0000",
    "user" : {
      "name" : "Steve Eichert",
      "screen_name" : "steveeichert",
      "protected" : false,
      "id_str" : "8126672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560175534189969409\/enQBGIDi_normal.jpeg",
      "id" : 8126672,
      "verified" : false
    }
  },
  "id" : 504274871757463552,
  "created_at" : "2014-08-26 14:31:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Schafer",
      "screen_name" : "TimOfLegend",
      "indices" : [ 3, 15 ],
      "id_str" : "24585498",
      "id" : 24585498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/5W56lFNVp2",
      "expanded_url" : "http:\/\/youtu.be\/5i_RPr9DwMA",
      "display_url" : "youtu.be\/5i_RPr9DwMA"
    } ]
  },
  "geo" : { },
  "id_str" : "504272751545176064",
  "text" : "RT @TimOfLegend: I think everyone who makes games should watch this video from start to finish.  http:\/\/t.co\/5W56lFNVp2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/5W56lFNVp2",
        "expanded_url" : "http:\/\/youtu.be\/5i_RPr9DwMA",
        "display_url" : "youtu.be\/5i_RPr9DwMA"
      } ]
    },
    "geo" : { },
    "id_str" : "504095132220526592",
    "text" : "I think everyone who makes games should watch this video from start to finish.  http:\/\/t.co\/5W56lFNVp2",
    "id" : 504095132220526592,
    "created_at" : "2014-08-26 02:36:59 +0000",
    "user" : {
      "name" : "Tim Schafer",
      "screen_name" : "TimOfLegend",
      "protected" : false,
      "id_str" : "24585498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543564604190646272\/9OIp8HvK_normal.jpeg",
      "id" : 24585498,
      "verified" : true
    }
  },
  "id" : 504272751545176064,
  "created_at" : "2014-08-26 14:22:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 3, 13 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Wm33dU1PN9",
      "expanded_url" : "http:\/\/fw.to\/IQ6tk6Q",
      "display_url" : "fw.to\/IQ6tk6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "504224636544905220",
  "text" : "RT @MikeHamad: Boycotting the football industrial complex http:\/\/t.co\/Wm33dU1PN9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/Wm33dU1PN9",
        "expanded_url" : "http:\/\/fw.to\/IQ6tk6Q",
        "display_url" : "fw.to\/IQ6tk6Q"
      } ]
    },
    "geo" : { },
    "id_str" : "504215106859716608",
    "text" : "Boycotting the football industrial complex http:\/\/t.co\/Wm33dU1PN9",
    "id" : 504215106859716608,
    "created_at" : "2014-08-26 10:33:44 +0000",
    "user" : {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "protected" : false,
      "id_str" : "27085484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000221554908\/fe385bec717753725959986bdc25832a_normal.jpeg",
      "id" : 27085484,
      "verified" : false
    }
  },
  "id" : 504224636544905220,
  "created_at" : "2014-08-26 11:11:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504118276289355776",
  "geo" : { },
  "id_str" : "504119977993961472",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza i really do hate most of these genres\/games.",
  "id" : 504119977993961472,
  "in_reply_to_status_id" : 504118276289355776,
  "created_at" : "2014-08-26 04:15:43 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Pumm",
      "screen_name" : "pummer",
      "indices" : [ 0, 7 ],
      "id_str" : "45489027",
      "id" : 45489027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504108052937596928",
  "geo" : { },
  "id_str" : "504108597945454592",
  "in_reply_to_user_id" : 45489027,
  "text" : "@pummer Babies, dude.",
  "id" : 504108597945454592,
  "in_reply_to_status_id" : 504108052937596928,
  "created_at" : "2014-08-26 03:30:30 +0000",
  "in_reply_to_screen_name" : "pummer",
  "in_reply_to_user_id_str" : "45489027",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504106644809080832",
  "text" : "Any designers up late and are willing to give some quick feedback?",
  "id" : 504106644809080832,
  "created_at" : "2014-08-26 03:22:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/tSsnTrXbVk",
      "expanded_url" : "http:\/\/youtu.be\/i6LQDp-Ue44",
      "display_url" : "youtu.be\/i6LQDp-Ue44"
    } ]
  },
  "geo" : { },
  "id_str" : "504074140970541056",
  "text" : "RT @nickelcityruby: Grab a ticket to #ncrc14 - because we've came a long way since this: http:\/\/t.co\/tSsnTrXbVk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/tSsnTrXbVk",
        "expanded_url" : "http:\/\/youtu.be\/i6LQDp-Ue44",
        "display_url" : "youtu.be\/i6LQDp-Ue44"
      } ]
    },
    "geo" : { },
    "id_str" : "504073697523933184",
    "text" : "Grab a ticket to #ncrc14 - because we've came a long way since this: http:\/\/t.co\/tSsnTrXbVk",
    "id" : 504073697523933184,
    "created_at" : "2014-08-26 01:11:49 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 504074140970541056,
  "created_at" : "2014-08-26 01:13:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504070965605957632",
  "geo" : { },
  "id_str" : "504072349923028992",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope holy shit",
  "id" : 504072349923028992,
  "in_reply_to_status_id" : 504070965605957632,
  "created_at" : "2014-08-26 01:06:28 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/rFdxCebKuQ",
      "expanded_url" : "http:\/\/youtubedoubler.com\/dh22",
      "display_url" : "youtubedoubler.com\/dh22"
    } ]
  },
  "geo" : { },
  "id_str" : "504069829611888640",
  "text" : "Better URL for that: http:\/\/t.co\/rFdxCebKuQ I can't get over the sheep on repeat.",
  "id" : 504069829611888640,
  "created_at" : "2014-08-26 00:56:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/dos8Go01lq",
      "expanded_url" : "http:\/\/www.youtubedoubler.com\/?video1=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DEglOsfErtaE&start1=109&video2=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DSIaFtAKnqBU&start2=9&authorName=qrush",
      "display_url" : "youtubedoubler.com\/?video1=https%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504068915744370688",
  "text" : "Screaming Sheep vs Yelling Dude Whose Dad Ran Over His Video Games: http:\/\/t.co\/dos8Go01lq",
  "id" : 504068915744370688,
  "created_at" : "2014-08-26 00:52:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 26, 40 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "Madison+ Ruby",
      "screen_name" : "MadisonRuby",
      "indices" : [ 45, 57 ],
      "id_str" : "121324195",
      "id" : 121324195
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 113, 128 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504065366805336064",
  "text" : "If the tweets coming from @steelcityruby and @madisonruby are any indication, we have a high standard to set for @nickelcityruby !",
  "id" : 504065366805336064,
  "created_at" : "2014-08-26 00:38:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 0, 12 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504063251442049026",
  "geo" : { },
  "id_str" : "504064893192900608",
  "in_reply_to_user_id" : 588743,
  "text" : "@antiheroine Look, Your Worshipfulness, just tell them.",
  "id" : 504064893192900608,
  "in_reply_to_status_id" : 504063251442049026,
  "created_at" : "2014-08-26 00:36:50 +0000",
  "in_reply_to_screen_name" : "antiheroine",
  "in_reply_to_user_id_str" : "588743",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 0, 10 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504059899928539136",
  "geo" : { },
  "id_str" : "504061574504407040",
  "in_reply_to_user_id" : 253464752,
  "text" : "@jessicard &gt; You have found a canteen. Pick it up? (Y\/N)",
  "id" : 504061574504407040,
  "in_reply_to_status_id" : 504059899928539136,
  "created_at" : "2014-08-26 00:23:39 +0000",
  "in_reply_to_screen_name" : "jessicard",
  "in_reply_to_user_id_str" : "253464752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "indices" : [ 15, 24 ],
      "id_str" : "2998581",
      "id" : 2998581
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504022272571883521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244232225, -78.8790147566 ]
  },
  "id_str" : "504041570639679488",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @kerrizor @nickelcityruby kind of want to do a secret Santa now. In October.",
  "id" : 504041570639679488,
  "in_reply_to_status_id" : 504022272571883521,
  "created_at" : "2014-08-25 23:04:09 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 89, 98 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504041457741623296",
  "text" : "RT @nickelcityruby: From one coast to another, we bring you the best - West Coast legend @sarahmei is keynoting #ncrc14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Mei",
        "screen_name" : "sarahmei",
        "indices" : [ 69, 78 ],
        "id_str" : "14164724",
        "id" : 14164724
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "503961830415687680",
    "text" : "From one coast to another, we bring you the best - West Coast legend @sarahmei is keynoting #ncrc14",
    "id" : 503961830415687680,
    "created_at" : "2014-08-25 17:47:18 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 504041457741623296,
  "created_at" : "2014-08-25 23:03:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "indices" : [ 0, 5 ],
      "id_str" : "3364",
      "id" : 3364
    }, {
      "name" : " Tom Lee ",
      "screen_name" : "tjl",
      "indices" : [ 6, 10 ],
      "id_str" : "720863",
      "id" : 720863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504019710846197762",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9177648585, -78.8769704811 ]
  },
  "id_str" : "504023813873741825",
  "in_reply_to_user_id" : 3364,
  "text" : "@cjoh @tjl IFTTT has SMS, which you can wire into WeMo. Or can use Twilio\u2019s web hooks + ouimeaux\u2019s API",
  "id" : 504023813873741825,
  "in_reply_to_status_id" : 504019710846197762,
  "created_at" : "2014-08-25 21:53:36 +0000",
  "in_reply_to_screen_name" : "cjoh",
  "in_reply_to_user_id_str" : "3364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "indices" : [ 0, 5 ],
      "id_str" : "3364",
      "id" : 3364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/WK3oeUkSZS",
      "expanded_url" : "https:\/\/github.com\/iancmcc\/ouimeaux",
      "display_url" : "github.com\/iancmcc\/ouimea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "503967104035717121",
  "geo" : { },
  "id_str" : "503967476653510656",
  "in_reply_to_user_id" : 3364,
  "text" : "@cjoh Belkin Wemo. Can use IFTTT with it or https:\/\/t.co\/WK3oeUkSZS",
  "id" : 503967476653510656,
  "in_reply_to_status_id" : 503967104035717121,
  "created_at" : "2014-08-25 18:09:44 +0000",
  "in_reply_to_screen_name" : "cjoh",
  "in_reply_to_user_id_str" : "3364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. History ",
      "screen_name" : "AhistoricalPics",
      "indices" : [ 3, 19 ],
      "id_str" : "2277140276",
      "id" : 2277140276
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AhistoricalPics\/status\/503964665819713536\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/K0H4MFLyWE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv5xMWVCIAAt0ac.jpg",
      "id_str" : "503964665278242816",
      "id" : 503964665278242816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv5xMWVCIAAt0ac.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/K0H4MFLyWE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503964847894458368",
  "text" : "RT @AhistoricalPics: The first Burning Man Festival http:\/\/t.co\/K0H4MFLyWE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AhistoricalPics\/status\/503964665819713536\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/K0H4MFLyWE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv5xMWVCIAAt0ac.jpg",
        "id_str" : "503964665278242816",
        "id" : 503964665278242816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv5xMWVCIAAt0ac.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/K0H4MFLyWE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "503964665819713536",
    "text" : "The first Burning Man Festival http:\/\/t.co\/K0H4MFLyWE",
    "id" : 503964665819713536,
    "created_at" : "2014-08-25 17:58:34 +0000",
    "user" : {
      "name" : "A. History ",
      "screen_name" : "AhistoricalPics",
      "protected" : false,
      "id_str" : "2277140276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419701923944480769\/AzrkOS2P_normal.jpeg",
      "id" : 2277140276,
      "verified" : false
    }
  },
  "id" : 503964847894458368,
  "created_at" : "2014-08-25 17:59:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/FC2do355oH",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=EglOsfErtaE",
      "display_url" : "youtube.com\/watch?v=EglOsf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503956197217538048",
  "text" : "Dad of the year award: https:\/\/t.co\/FC2do355oH",
  "id" : 503956197217538048,
  "created_at" : "2014-08-25 17:24:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/bzLFht1wOG",
      "expanded_url" : "https:\/\/medium.com\/@fart\/why-i-am-the-most-important-devops-thought-leader-46a191ac0f42",
      "display_url" : "medium.com\/@fart\/why-i-am\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503922421561163777",
  "text" : "\"Begin kissing your data immediately.\" https:\/\/t.co\/bzLFht1wOG",
  "id" : 503922421561163777,
  "created_at" : "2014-08-25 15:10:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Hl6e7jXPDR",
      "expanded_url" : "http:\/\/xs-sniper.com\/blackhat2014\/BH2014-Billy-Rios.pdf",
      "display_url" : "xs-sniper.com\/blackhat2014\/B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503897959797248000",
  "text" : "Not surprising: TSA hardware and software totally insecure. http:\/\/t.co\/Hl6e7jXPDR",
  "id" : 503897959797248000,
  "created_at" : "2014-08-25 13:33:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lois Beckett",
      "screen_name" : "loisbeckett",
      "indices" : [ 3, 15 ],
      "id_str" : "21134925",
      "id" : 21134925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503893990173708289",
  "text" : "RT @loisbeckett: data wizardry\ndata sorcery\ndata tarot\ndata scrying in a data crystal\ndata astrology \nquantitative sacrifice of a data chic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "503613324622180352",
    "text" : "data wizardry\ndata sorcery\ndata tarot\ndata scrying in a data crystal\ndata astrology \nquantitative sacrifice of a data chicken",
    "id" : 503613324622180352,
    "created_at" : "2014-08-24 18:42:27 +0000",
    "user" : {
      "name" : "Lois Beckett",
      "screen_name" : "loisbeckett",
      "protected" : false,
      "id_str" : "21134925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551921299992236032\/BeRvU8hZ_normal.jpeg",
      "id" : 21134925,
      "verified" : true
    }
  },
  "id" : 503893990173708289,
  "created_at" : "2014-08-25 13:17:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Reeves",
      "screen_name" : "lukereeves",
      "indices" : [ 3, 14 ],
      "id_str" : "26039611",
      "id" : 26039611
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lukereeves\/status\/503740912967909378\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/VQoL75DJyL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv2lsPQIUAAB09s.jpg",
      "id_str" : "503740912762376192",
      "id" : 503740912762376192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv2lsPQIUAAB09s.jpg",
      "sizes" : [ {
        "h" : 323,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VQoL75DJyL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503761111611502593",
  "text" : "RT @lukereeves: videogames.jpg http:\/\/t.co\/VQoL75DJyL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lukereeves\/status\/503740912967909378\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/VQoL75DJyL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv2lsPQIUAAB09s.jpg",
        "id_str" : "503740912762376192",
        "id" : 503740912762376192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv2lsPQIUAAB09s.jpg",
        "sizes" : [ {
          "h" : 323,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VQoL75DJyL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "503740912967909378",
    "text" : "videogames.jpg http:\/\/t.co\/VQoL75DJyL",
    "id" : 503740912967909378,
    "created_at" : "2014-08-25 03:09:27 +0000",
    "user" : {
      "name" : "Luke Reeves",
      "screen_name" : "lukereeves",
      "protected" : false,
      "id_str" : "26039611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1380678270\/df_normal.png",
      "id" : 26039611,
      "verified" : false
    }
  },
  "id" : 503761111611502593,
  "created_at" : "2014-08-25 04:29:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503730828565020672",
  "geo" : { },
  "id_str" : "503731034806964224",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone it felt like a Chance card response from Monopoly",
  "id" : 503731034806964224,
  "in_reply_to_status_id" : 503730828565020672,
  "created_at" : "2014-08-25 02:30:12 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonan Scheffler",
      "screen_name" : "1337807",
      "indices" : [ 0, 8 ],
      "id_str" : "117846486",
      "id" : 117846486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503730305329819650",
  "geo" : { },
  "id_str" : "503730441535250432",
  "in_reply_to_user_id" : 117846486,
  "text" : "@1337807 noooooooo. too many in this household are allergic.",
  "id" : 503730441535250432,
  "in_reply_to_status_id" : 503730305329819650,
  "created_at" : "2014-08-25 02:27:50 +0000",
  "in_reply_to_screen_name" : "1337807",
  "in_reply_to_user_id_str" : "117846486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "503725749472600064",
  "geo" : { },
  "id_str" : "503730095253491712",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone \/play horn \"Dang. http:\/\/t.co\/2bA9BVLhWr is using a certificate signed with SHA-1. Make a new cert using SHA-2. Start over.\"",
  "id" : 503730095253491712,
  "in_reply_to_status_id" : 503725749472600064,
  "created_at" : "2014-08-25 02:26:28 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503729811815006209",
  "text" : "Adorable stray cat not only spent an evening with a porch with us, introduced to the husky, and now sits on the porch staring sadly at us :(",
  "id" : 503729811815006209,
  "created_at" : "2014-08-25 02:25:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503551974449876993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.92182594, -78.88246454 ]
  },
  "id_str" : "503552504115003392",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo do you deliver?",
  "id" : 503552504115003392,
  "in_reply_to_status_id" : 503551974449876993,
  "created_at" : "2014-08-24 14:40:47 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503550729702100992",
  "text" : "RT @dwarfort_txt: an elf that had become assimilated into a dwarven site lead both the attack on and the defense of the dwarven fortress",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502817589848854530",
    "text" : "an elf that had become assimilated into a dwarven site lead both the attack on and the defense of the dwarven fortress",
    "id" : 502817589848854530,
    "created_at" : "2014-08-22 14:00:29 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 503550729702100992,
  "created_at" : "2014-08-24 14:33:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503550596751052800",
  "text" : "RT @dwarfort_txt: stopped pigs from thinking that they are selling things at the market",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501519123205988353",
    "text" : "stopped pigs from thinking that they are selling things at the market",
    "id" : 501519123205988353,
    "created_at" : "2014-08-19 00:00:51 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 503550596751052800,
  "created_at" : "2014-08-24 14:33:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/NseKs3df7N",
      "expanded_url" : "http:\/\/bit.ly\/1ttyius",
      "display_url" : "bit.ly\/1ttyius"
    } ]
  },
  "geo" : { },
  "id_str" : "503546640352149504",
  "text" : "RT @rachbarnhart: More techies like Buffalo http:\/\/t.co\/NseKs3df7N But article lacks data",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/NseKs3df7N",
        "expanded_url" : "http:\/\/bit.ly\/1ttyius",
        "display_url" : "bit.ly\/1ttyius"
      } ]
    },
    "geo" : { },
    "id_str" : "503542872541757442",
    "text" : "More techies like Buffalo http:\/\/t.co\/NseKs3df7N But article lacks data",
    "id" : 503542872541757442,
    "created_at" : "2014-08-24 14:02:30 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 503546640352149504,
  "created_at" : "2014-08-24 14:17:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 3, 18 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Marco Zehe",
      "screen_name" : "MarcoZehe",
      "indices" : [ 33, 43 ],
      "id_str" : "14147295",
      "id" : 14147295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1giklQ3IAW",
      "expanded_url" : "http:\/\/bit.ly\/1AFh7bH",
      "display_url" : "bit.ly\/1AFh7bH"
    } ]
  },
  "geo" : { },
  "id_str" : "502947548701523968",
  "text" : "RT @AustinSeraphin: A blind user @MarcoZehe  tried switching from iOS to Android for 30 days. He bailed after 18. http:\/\/t.co\/1giklQ3IAW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marco Zehe",
        "screen_name" : "MarcoZehe",
        "indices" : [ 13, 23 ],
        "id_str" : "14147295",
        "id" : 14147295
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/1giklQ3IAW",
        "expanded_url" : "http:\/\/bit.ly\/1AFh7bH",
        "display_url" : "bit.ly\/1AFh7bH"
      } ]
    },
    "geo" : { },
    "id_str" : "502944345235152896",
    "text" : "A blind user @MarcoZehe  tried switching from iOS to Android for 30 days. He bailed after 18. http:\/\/t.co\/1giklQ3IAW",
    "id" : 502944345235152896,
    "created_at" : "2014-08-22 22:24:10 +0000",
    "user" : {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "protected" : false,
      "id_str" : "16393800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/382052821\/cib8blue_normal.jpg",
      "id" : 16393800,
      "verified" : false
    }
  },
  "id" : 502947548701523968,
  "created_at" : "2014-08-22 22:36:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/Lo5nHpk4SW",
      "expanded_url" : "http:\/\/grorarebookroom.files.wordpress.com\/2014\/04\/ill-repute-map-blog-copy1.jpg",
      "display_url" : "grorarebookroom.files.wordpress.com\/2014\/04\/ill-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502930829643763714",
  "text" : "RT @kevinpurdy: Celebrate \"filthy Buffalo, NY, where they love perversion of every kind\" with the appropriate wallpaper: http:\/\/t.co\/Lo5nHp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/Lo5nHpk4SW",
        "expanded_url" : "http:\/\/grorarebookroom.files.wordpress.com\/2014\/04\/ill-repute-map-blog-copy1.jpg",
        "display_url" : "grorarebookroom.files.wordpress.com\/2014\/04\/ill-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502850771663089664",
    "text" : "Celebrate \"filthy Buffalo, NY, where they love perversion of every kind\" with the appropriate wallpaper: http:\/\/t.co\/Lo5nHpk4SW",
    "id" : 502850771663089664,
    "created_at" : "2014-08-22 16:12:21 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 502930829643763714,
  "created_at" : "2014-08-22 21:30:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/pIRGcKTb4A",
      "expanded_url" : "http:\/\/www.changesinlongitude.com\/things-to-do-in-buffalo-ny\/",
      "display_url" : "changesinlongitude.com\/things-to-do-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502870116267470849",
  "text" : "RT @nickelcityruby: Need to know more about things to do in Buffalo before grabbing a ticket for #ncrc14 - check this out: http:\/\/t.co\/pIRG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/pIRGcKTb4A",
        "expanded_url" : "http:\/\/www.changesinlongitude.com\/things-to-do-in-buffalo-ny\/",
        "display_url" : "changesinlongitude.com\/things-to-do-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502813418601345024",
    "text" : "Need to know more about things to do in Buffalo before grabbing a ticket for #ncrc14 - check this out: http:\/\/t.co\/pIRGcKTb4A",
    "id" : 502813418601345024,
    "created_at" : "2014-08-22 13:43:55 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 502870116267470849,
  "created_at" : "2014-08-22 17:29:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drew Ludwig",
      "screen_name" : "DrewLudwig",
      "indices" : [ 3, 14 ],
      "id_str" : "15334097",
      "id" : 15334097
    }, {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 25, 39 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Nchn6sw0jO",
      "expanded_url" : "https:\/\/www.facebook.com\/drew.ludwig\/posts\/10152189788316890",
      "display_url" : "facebook.com\/drew.ludwig\/po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502868695849635840",
  "text" : "RT @DrewLudwig: What can @markpoloncarz  do with Erie County's mine resistant vehicle? https:\/\/t.co\/Nchn6sw0jO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Poloncarz",
        "screen_name" : "markpoloncarz",
        "indices" : [ 9, 23 ],
        "id_str" : "45490102",
        "id" : 45490102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/Nchn6sw0jO",
        "expanded_url" : "https:\/\/www.facebook.com\/drew.ludwig\/posts\/10152189788316890",
        "display_url" : "facebook.com\/drew.ludwig\/po\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502867412824633344",
    "text" : "What can @markpoloncarz  do with Erie County's mine resistant vehicle? https:\/\/t.co\/Nchn6sw0jO",
    "id" : 502867412824633344,
    "created_at" : "2014-08-22 17:18:28 +0000",
    "user" : {
      "name" : "Drew Ludwig",
      "screen_name" : "DrewLudwig",
      "protected" : false,
      "id_str" : "15334097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/56278134\/TerryMikeBday80902_normal.jpg",
      "id" : 15334097,
      "verified" : false
    }
  },
  "id" : 502868695849635840,
  "created_at" : "2014-08-22 17:23:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Ted Han",
      "screen_name" : "knowtheory",
      "indices" : [ 10, 21 ],
      "id_str" : "14227842",
      "id" : 14227842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502686243847929856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240202394, -78.8788144597 ]
  },
  "id_str" : "502791354506674176",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @knowtheory I just found a video explaining this situation and I cannot. Even.",
  "id" : 502791354506674176,
  "in_reply_to_status_id" : 502686243847929856,
  "created_at" : "2014-08-22 12:16:14 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502678639721603072",
  "geo" : { },
  "id_str" : "502679884468998144",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone wtf",
  "id" : 502679884468998144,
  "in_reply_to_status_id" : 502678639721603072,
  "created_at" : "2014-08-22 04:53:18 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modern Seinfeld",
      "screen_name" : "SeinfeldToday",
      "indices" : [ 3, 17 ],
      "id_str" : "1000262514",
      "id" : 1000262514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502638193372856320",
  "text" : "RT @SeinfeldToday: Kramer rents out his apartment every night on Airbnb &amp; lives in the hallway. K:\u201CI\u2019m making cash hand over fist, Jerry!\u201D \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484735016967356418",
    "text" : "Kramer rents out his apartment every night on Airbnb &amp; lives in the hallway. K:\u201CI\u2019m making cash hand over fist, Jerry!\u201D J:\u201CYou\u2019re homeless!\"",
    "id" : 484735016967356418,
    "created_at" : "2014-07-03 16:26:48 +0000",
    "user" : {
      "name" : "Modern Seinfeld",
      "screen_name" : "SeinfeldToday",
      "protected" : false,
      "id_str" : "1000262514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2954374125\/0afd5df8dea7c1818da1dcbc438f5a2a_normal.jpeg",
      "id" : 1000262514,
      "verified" : false
    }
  },
  "id" : 502638193372856320,
  "created_at" : "2014-08-22 02:07:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502634918523179009",
  "geo" : { },
  "id_str" : "502635382685843456",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo PARTY HARD",
  "id" : 502635382685843456,
  "in_reply_to_status_id" : 502634918523179009,
  "created_at" : "2014-08-22 01:56:28 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502573126166003712",
  "geo" : { },
  "id_str" : "502573847879897091",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy Awesome. Not totally at this point yet but within the next month or two will be.",
  "id" : 502573847879897091,
  "in_reply_to_status_id" : 502573126166003712,
  "created_at" : "2014-08-21 21:51:57 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502571535803363330",
  "geo" : { },
  "id_str" : "502571685607141376",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy awesome. would appreciate links\/urls :)",
  "id" : 502571685607141376,
  "in_reply_to_status_id" : 502571535803363330,
  "created_at" : "2014-08-21 21:43:21 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502571004615725057",
  "geo" : { },
  "id_str" : "502571161163943937",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy what is that?",
  "id" : 502571161163943937,
  "in_reply_to_status_id" : 502571004615725057,
  "created_at" : "2014-08-21 21:41:16 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502570097761083393",
  "text" : "Been trying out AppCode all day today and it's a pleasure to use. Liking how it highlights unused code\/imports.",
  "id" : 502570097761083393,
  "created_at" : "2014-08-21 21:37:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502569792633843713",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer Not a bad thing.",
  "id" : 502569792633843713,
  "created_at" : "2014-08-21 21:35:50 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "indices" : [ 3, 14 ],
      "id_str" : "126030998",
      "id" : 126030998
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/0xabad1dea\/status\/502562855376654337\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/tYt8E46WKX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvl2QPiIMAAswci.png",
      "id_str" : "502562854848180224",
      "id" : 502562854848180224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvl2QPiIMAAswci.png",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/tYt8E46WKX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ZeeR8AQY5P",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/vwptqn3mhq9xvy7\/ArchCity%20Defenders%20Municipal%20Courts%20Whitepaper.pdf",
      "display_url" : "dropbox.com\/s\/vwptqn3mhq9x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502563336743956480",
  "text" : "RT @0xabad1dea: HOLY HELL FERGUSON ISSUES MORE WARRANTS PER YEAR THAN THEY HAVE CITIZENS. https:\/\/t.co\/ZeeR8AQY5P http:\/\/t.co\/tYt8E46WKX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/0xabad1dea\/status\/502562855376654337\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/tYt8E46WKX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvl2QPiIMAAswci.png",
        "id_str" : "502562854848180224",
        "id" : 502562854848180224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvl2QPiIMAAswci.png",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/tYt8E46WKX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/ZeeR8AQY5P",
        "expanded_url" : "https:\/\/www.dropbox.com\/s\/vwptqn3mhq9xvy7\/ArchCity%20Defenders%20Municipal%20Courts%20Whitepaper.pdf",
        "display_url" : "dropbox.com\/s\/vwptqn3mhq9x\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502562855376654337",
    "text" : "HOLY HELL FERGUSON ISSUES MORE WARRANTS PER YEAR THAN THEY HAVE CITIZENS. https:\/\/t.co\/ZeeR8AQY5P http:\/\/t.co\/tYt8E46WKX",
    "id" : 502562855376654337,
    "created_at" : "2014-08-21 21:08:16 +0000",
    "user" : {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "protected" : false,
      "id_str" : "126030998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528398279571038208\/Zc_ZWgUI_normal.png",
      "id" : 126030998,
      "verified" : false
    }
  },
  "id" : 502563336743956480,
  "created_at" : "2014-08-21 21:10:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 0, 15 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/wPxtxDVUsp",
      "expanded_url" : "http:\/\/quaran.to\/kidsmash",
      "display_url" : "quaran.to\/kidsmash"
    } ]
  },
  "in_reply_to_status_id_str" : "502556628420657154",
  "geo" : { },
  "id_str" : "502557059414753281",
  "in_reply_to_user_id" : 81525784,
  "text" : "@franklinwebber time for some http:\/\/t.co\/wPxtxDVUsp",
  "id" : 502557059414753281,
  "in_reply_to_status_id" : 502556628420657154,
  "created_at" : "2014-08-21 20:45:14 +0000",
  "in_reply_to_screen_name" : "franklinwebber",
  "in_reply_to_user_id_str" : "81525784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/502542455712284673\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/5clIBjTawX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvljszEIEAEfMPF.png",
      "id_str" : "502542454701428737",
      "id" : 502542454701428737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvljszEIEAEfMPF.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1290,
        "resize" : "fit",
        "w" : 1720
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5clIBjTawX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502542455712284673",
  "text" : "forecast.io has been really unreliable this summer. Not a single drop of rain today. http:\/\/t.co\/5clIBjTawX",
  "id" : 502542455712284673,
  "created_at" : "2014-08-21 19:47:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502536808950169601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8901931687, -78.8735880705 ]
  },
  "id_str" : "502537329773645826",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV 3 prepare for months of terrible imitations",
  "id" : 502537329773645826,
  "in_reply_to_status_id" : 502536808950169601,
  "created_at" : "2014-08-21 19:26:50 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 101, 113 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502536086347087872",
  "text" : "RT @nickelcityruby: Make sure to grab tickets to #ncrc14 - keynoter and famed Jen Myers impersonator @antiheroine will be there dropping kn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen Myers",
        "screen_name" : "antiheroine",
        "indices" : [ 81, 93 ],
        "id_str" : "588743",
        "id" : 588743
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502535614915674113",
    "text" : "Make sure to grab tickets to #ncrc14 - keynoter and famed Jen Myers impersonator @antiheroine will be there dropping knowledge!",
    "id" : 502535614915674113,
    "created_at" : "2014-08-21 19:20:01 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 502536086347087872,
  "created_at" : "2014-08-21 19:21:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TweetsOfAdventure",
      "screen_name" : "bombsfall",
      "indices" : [ 3, 13 ],
      "id_str" : "298942872",
      "id" : 298942872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xjU1WdVVjr",
      "expanded_url" : "http:\/\/www.clickhole.com\/article\/one-incredible-entrepreneur-saved-struggling-neigh-746",
      "display_url" : "clickhole.com\/article\/one-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502513913863217152",
  "text" : "RT @bombsfall: Incredible Entrepreneur Saved This Struggling Neighborhood By Replacing Everyone In It With Affluent Twentysomethings\nhttp:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xjU1WdVVjr",
        "expanded_url" : "http:\/\/www.clickhole.com\/article\/one-incredible-entrepreneur-saved-struggling-neigh-746",
        "display_url" : "clickhole.com\/article\/one-in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502513166744817664",
    "text" : "Incredible Entrepreneur Saved This Struggling Neighborhood By Replacing Everyone In It With Affluent Twentysomethings\nhttp:\/\/t.co\/xjU1WdVVjr",
    "id" : 502513166744817664,
    "created_at" : "2014-08-21 17:50:49 +0000",
    "user" : {
      "name" : "TweetsOfAdventure",
      "screen_name" : "bombsfall",
      "protected" : false,
      "id_str" : "298942872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538168596862484480\/LqfzFCRe_normal.jpeg",
      "id" : 298942872,
      "verified" : false
    }
  },
  "id" : 502513913863217152,
  "created_at" : "2014-08-21 17:53:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/v6AcIIedzM",
      "expanded_url" : "http:\/\/www.gq.com\/news-politics\/newsmakers\/201409\/the-last-true-hermit?printable=true",
      "display_url" : "gq.com\/news-politics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502513091846737920",
  "text" : "Over 10,000 days sleeping outside, alone. Cannot even begin to imagine. http:\/\/t.co\/v6AcIIedzM",
  "id" : 502513091846737920,
  "created_at" : "2014-08-21 17:50:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 0, 8 ],
      "id_str" : "15048829",
      "id" : 15048829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502504953395412992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8906059308, -78.8745476389 ]
  },
  "id_str" : "502505077857607680",
  "in_reply_to_user_id" : 15048829,
  "text" : "@greggyb yep. Book is very repetitive but it works.",
  "id" : 502505077857607680,
  "in_reply_to_status_id" : 502504953395412992,
  "created_at" : "2014-08-21 17:18:41 +0000",
  "in_reply_to_screen_name" : "greggyb",
  "in_reply_to_user_id_str" : "15048829",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 7, 15 ],
      "id_str" : "12986052",
      "id" : 12986052
    }, {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 16, 29 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502504722973360131",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8905302227, -78.8743008063 ]
  },
  "id_str" : "502504900635680768",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden @hcatlin @olivierlacan hey computers need a break too",
  "id" : 502504900635680768,
  "in_reply_to_status_id" : 502504722973360131,
  "created_at" : "2014-08-21 17:17:59 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 0, 8 ],
      "id_str" : "15048829",
      "id" : 15048829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502504288401113088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8908870705, -78.873489078 ]
  },
  "id_str" : "502504756359987200",
  "in_reply_to_user_id" : 15048829,
  "text" : "@greggyb \/r\/predaddit and daddit are great. Did you read Happiest Baby yet?",
  "id" : 502504756359987200,
  "in_reply_to_status_id" : 502504288401113088,
  "created_at" : "2014-08-21 17:17:24 +0000",
  "in_reply_to_screen_name" : "greggyb",
  "in_reply_to_user_id_str" : "15048829",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROC",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "therochesterian",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/KzfYJRa5JH",
      "expanded_url" : "http:\/\/bit.ly\/1p0wi6F",
      "display_url" : "bit.ly\/1p0wi6F"
    } ]
  },
  "geo" : { },
  "id_str" : "502475834133708801",
  "text" : "RT @rachbarnhart: Does where officers live matter? http:\/\/t.co\/KzfYJRa5JH In RPD, very few live in city. #ROC #therochesterian",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROC",
        "indices" : [ 87, 91 ]
      }, {
        "text" : "therochesterian",
        "indices" : [ 92, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/KzfYJRa5JH",
        "expanded_url" : "http:\/\/bit.ly\/1p0wi6F",
        "display_url" : "bit.ly\/1p0wi6F"
      } ]
    },
    "geo" : { },
    "id_str" : "502475716764893184",
    "text" : "Does where officers live matter? http:\/\/t.co\/KzfYJRa5JH In RPD, very few live in city. #ROC #therochesterian",
    "id" : 502475716764893184,
    "created_at" : "2014-08-21 15:22:01 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 502475834133708801,
  "created_at" : "2014-08-21 15:22:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/3cvX654B0j",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!msg\/rack-devel\/P8oOycVBaH0\/1bm4eERJWPQJ",
      "display_url" : "groups.google.com\/forum\/#!msg\/ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502470891897229312",
  "text" : "RT @steveklabnik: \"Rack as the sole middle-tier specification for the Ruby community is at this point no longer appropriate.\" https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/3cvX654B0j",
        "expanded_url" : "https:\/\/groups.google.com\/forum\/#!msg\/rack-devel\/P8oOycVBaH0\/1bm4eERJWPQJ",
        "display_url" : "groups.google.com\/forum\/#!msg\/ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502469893623930881",
    "text" : "\"Rack as the sole middle-tier specification for the Ruby community is at this point no longer appropriate.\" https:\/\/t.co\/3cvX654B0j",
    "id" : 502469893623930881,
    "created_at" : "2014-08-21 14:58:52 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 502470891897229312,
  "created_at" : "2014-08-21 15:02:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abdelkader Boudih",
      "screen_name" : "IchThain",
      "indices" : [ 0, 9 ],
      "id_str" : "1244397780",
      "id" : 1244397780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502388908433604608",
  "geo" : { },
  "id_str" : "502464262715891715",
  "in_reply_to_user_id" : 1244397780,
  "text" : "@IchThain on your edit profile page.",
  "id" : 502464262715891715,
  "in_reply_to_status_id" : 502388908433604608,
  "created_at" : "2014-08-21 14:36:30 +0000",
  "in_reply_to_screen_name" : "IchThain",
  "in_reply_to_user_id_str" : "1244397780",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 3, 10 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502299661286137856",
  "text" : "RT @searls: @qrush startup weekend: \"it's like Uber but for paramilitary operations\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "502299466406191104",
    "geo" : { },
    "id_str" : "502299612561285120",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush startup weekend: \"it's like Uber but for paramilitary operations\"",
    "id" : 502299612561285120,
    "in_reply_to_status_id" : 502299466406191104,
    "created_at" : "2014-08-21 03:42:14 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "protected" : false,
      "id_str" : "9038902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2360535353\/20120630-face_normal.jpg",
      "id" : 9038902,
      "verified" : false
    }
  },
  "id" : 502299661286137856,
  "created_at" : "2014-08-21 03:42:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/TpvhBeE6E4",
      "expanded_url" : "http:\/\/www.theverge.com\/2014\/8\/20\/6050937\/private-military-in-ferguson",
      "display_url" : "theverge.com\/2014\/8\/20\/6050\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242126861, -78.8791576013 ]
  },
  "id_str" : "502299466406191104",
  "text" : "Huh I wonder who would hire a private military contractor in Ferguson? Maybe a former Twitter founder who is there? http:\/\/t.co\/TpvhBeE6E4",
  "id" : 502299466406191104,
  "created_at" : "2014-08-21 03:41:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa O'Brien",
      "screen_name" : "carwinb",
      "indices" : [ 0, 8 ],
      "id_str" : "197848744",
      "id" : 197848744
    }, {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 9, 23 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502285887145668608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244443868, -78.8790303469 ]
  },
  "id_str" : "502298017454510081",
  "in_reply_to_user_id" : 197848744,
  "text" : "@carwinb @PhilDarnowsky I have a strong guess, whose handle starts with j and ends with ack",
  "id" : 502298017454510081,
  "in_reply_to_status_id" : 502285887145668608,
  "created_at" : "2014-08-21 03:35:54 +0000",
  "in_reply_to_screen_name" : "carwinb",
  "in_reply_to_user_id_str" : "197848744",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 0, 8 ],
      "id_str" : "33588043",
      "id" : 33588043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502292326719700992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242474851, -78.8792755006 ]
  },
  "id_str" : "502292541073408002",
  "in_reply_to_user_id" : 33588043,
  "text" : "@Pete716 l still despise it :) it\u2019s a big reason why i dug into Jekyll and Ruby.",
  "id" : 502292541073408002,
  "in_reply_to_status_id" : 502292326719700992,
  "created_at" : "2014-08-21 03:14:08 +0000",
  "in_reply_to_screen_name" : "Pete716",
  "in_reply_to_user_id_str" : "33588043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 25, 31 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "moe.",
      "screen_name" : "moeperiod",
      "indices" : [ 32, 42 ],
      "id_str" : "60102709",
      "id" : 60102709
    }, {
      "name" : "Umphrey's McGee",
      "screen_name" : "umphreysmcgee",
      "indices" : [ 43, 57 ],
      "id_str" : "16724705",
      "id" : 16724705
    }, {
      "name" : "Dopapod",
      "screen_name" : "Dopapod",
      "indices" : [ 58, 66 ],
      "id_str" : "44571170",
      "id" : 44571170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502278697844350976",
  "text" : "Interesting observation: @phish @moeperiod @umphreysmcgee @dopapod all using WordPress for their site. Easy to forget how big it is.",
  "id" : 502278697844350976,
  "created_at" : "2014-08-21 02:19:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502207188224708610",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244472913, -78.8793767956 ]
  },
  "id_str" : "502209614759211008",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin I am making pizza tonight. Forgot I bought a big pack of dried oregano a while ago",
  "id" : 502209614759211008,
  "in_reply_to_status_id" : 502207188224708610,
  "created_at" : "2014-08-20 21:44:37 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 0, 15 ],
      "id_str" : "81525784",
      "id" : 81525784
    }, {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 16, 31 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 32, 40 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Blithe Rocher",
      "screen_name" : "Blithe",
      "indices" : [ 41, 48 ],
      "id_str" : "6304322",
      "id" : 6304322
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 49, 53 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 54, 64 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/502206937232982016\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/4aGmUEgtGj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvgyi0CIYAAy2rf.jpg",
      "id_str" : "502206932116332544",
      "id" : 502206932116332544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvgyi0CIYAAy2rf.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/4aGmUEgtGj"
    } ],
    "hashtags" : [ {
      "text" : "SpicyPizza",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501143693974597632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243269563, -78.8791978174 ]
  },
  "id_str" : "502206937232982016",
  "in_reply_to_user_id" : 81525784,
  "text" : "@franklinwebber @AustinSeraphin @headius @Blithe @lrz @aquaranto  making some #SpicyPizza! http:\/\/t.co\/4aGmUEgtGj",
  "id" : 502206937232982016,
  "in_reply_to_status_id" : 501143693974597632,
  "created_at" : "2014-08-20 21:33:59 +0000",
  "in_reply_to_screen_name" : "franklinwebber",
  "in_reply_to_user_id_str" : "81525784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243710917, -78.8794085661 ]
  },
  "id_str" : "502201697385476096",
  "text" : "Finally ditched my 5C case and this device feels too slippery and small.",
  "id" : 502201697385476096,
  "created_at" : "2014-08-20 21:13:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Eichert",
      "screen_name" : "steveeichert",
      "indices" : [ 0, 13 ],
      "id_str" : "8126672",
      "id" : 8126672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502186082247925760",
  "geo" : { },
  "id_str" : "502186287642984449",
  "in_reply_to_user_id" : 8126672,
  "text" : "@steveeichert I don't know at this point. At least there's a choice now between 3 languages. It's still the same problems underneath.",
  "id" : 502186287642984449,
  "in_reply_to_status_id" : 502186082247925760,
  "created_at" : "2014-08-20 20:11:55 +0000",
  "in_reply_to_screen_name" : "steveeichert",
  "in_reply_to_user_id_str" : "8126672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502185407732523010",
  "text" : "RT @mperham: @qrush There's always the sweet embrace of death.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "502182585657995265",
    "geo" : { },
    "id_str" : "502185233148424192",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush There's always the sweet embrace of death.",
    "id" : 502185233148424192,
    "in_reply_to_status_id" : 502182585657995265,
    "created_at" : "2014-08-20 20:07:44 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519271188569128960\/i2t9GfcA_normal.jpeg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 502185407732523010,
  "created_at" : "2014-08-20 20:08:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radek",
      "screen_name" : "radexp",
      "indices" : [ 0, 7 ],
      "id_str" : "107770370",
      "id" : 107770370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502183292213678080",
  "geo" : { },
  "id_str" : "502185321782849537",
  "in_reply_to_user_id" : 107770370,
  "text" : "@radexp Crashes 3-4 times a day. XVim seems to blame for most, but many things outside of that. Too many windows\/tabs\/stuff moving around.",
  "id" : 502185321782849537,
  "in_reply_to_status_id" : 502183292213678080,
  "created_at" : "2014-08-20 20:08:05 +0000",
  "in_reply_to_screen_name" : "radexp",
  "in_reply_to_user_id_str" : "107770370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Wilcox",
      "screen_name" : "rwilcox",
      "indices" : [ 0, 8 ],
      "id_str" : "11766092",
      "id" : 11766092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502184236846419970",
  "geo" : { },
  "id_str" : "502185107994972160",
  "in_reply_to_user_id" : 11766092,
  "text" : "@rwilcox Never tried it.",
  "id" : 502185107994972160,
  "in_reply_to_status_id" : 502184236846419970,
  "created_at" : "2014-08-20 20:07:14 +0000",
  "in_reply_to_screen_name" : "rwilcox",
  "in_reply_to_user_id_str" : "11766092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Eichert",
      "screen_name" : "steveeichert",
      "indices" : [ 0, 13 ],
      "id_str" : "8126672",
      "id" : 8126672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502184770017959937",
  "geo" : { },
  "id_str" : "502185070669856768",
  "in_reply_to_user_id" : 8126672,
  "text" : "@steveeichert iPad app is in ObjC. Wanted to dig into the platform more.",
  "id" : 502185070669856768,
  "in_reply_to_status_id" : 502184770017959937,
  "created_at" : "2014-08-20 20:07:05 +0000",
  "in_reply_to_screen_name" : "steveeichert",
  "in_reply_to_user_id_str" : "8126672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502182585657995265",
  "text" : "Is AppCode worth it? Is there any escape from how awful Xcode is?",
  "id" : 502182585657995265,
  "created_at" : "2014-08-20 19:57:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Moffatt",
      "screen_name" : "jakeonrails",
      "indices" : [ 0, 12 ],
      "id_str" : "242177294",
      "id" : 242177294
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 13, 22 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502174157191127040",
  "geo" : { },
  "id_str" : "502174299176718336",
  "in_reply_to_user_id" : 242177294,
  "text" : "@jakeonrails @konklone I get patted down maybe 90% of the time. It's fucking awful and I hate flying.",
  "id" : 502174299176718336,
  "in_reply_to_status_id" : 502174157191127040,
  "created_at" : "2014-08-20 19:24:17 +0000",
  "in_reply_to_screen_name" : "jakeonrails",
  "in_reply_to_user_id_str" : "242177294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 76, 85 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/0Fj8BOaJnY",
      "expanded_url" : "https:\/\/radsec.org\/press.html",
      "display_url" : "radsec.org\/press.html"
    } ]
  },
  "geo" : { },
  "id_str" : "502173531749093376",
  "text" : "Always opt out. Even the scanners are useless: https:\/\/t.co\/0Fj8BOaJnY (via @konklone)",
  "id" : 502173531749093376,
  "created_at" : "2014-08-20 19:21:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reid Wiseman",
      "screen_name" : "astro_reid",
      "indices" : [ 3, 14 ],
      "id_str" : "330921167",
      "id" : 330921167
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/astro_reid\/status\/502168353956720640\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7jwTdvc3md",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvgPdERIcAEXu8g.jpg",
      "id_str" : "502168350488031233",
      "id" : 502168350488031233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvgPdERIcAEXu8g.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7jwTdvc3md"
    } ],
    "hashtags" : [ {
      "text" : "Toronto",
      "indices" : [ 16, 24 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "Huron",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "Erie",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502170310850789376",
  "text" : "RT @astro_reid: #Toronto and #Buffalo on the banks of Lakes #Huron and #Erie http:\/\/t.co\/7jwTdvc3md",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/astro_reid\/status\/502168353956720640\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/7jwTdvc3md",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvgPdERIcAEXu8g.jpg",
        "id_str" : "502168350488031233",
        "id" : 502168350488031233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvgPdERIcAEXu8g.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7jwTdvc3md"
      } ],
      "hashtags" : [ {
        "text" : "Toronto",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 13, 21 ]
      }, {
        "text" : "Huron",
        "indices" : [ 44, 50 ]
      }, {
        "text" : "Erie",
        "indices" : [ 55, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502168353956720640",
    "text" : "#Toronto and #Buffalo on the banks of Lakes #Huron and #Erie http:\/\/t.co\/7jwTdvc3md",
    "id" : 502168353956720640,
    "created_at" : "2014-08-20 19:00:40 +0000",
    "user" : {
      "name" : "Reid Wiseman",
      "screen_name" : "astro_reid",
      "protected" : false,
      "id_str" : "330921167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1431054149\/image_normal.jpg",
      "id" : 330921167,
      "verified" : true
    }
  },
  "id" : 502170310850789376,
  "created_at" : "2014-08-20 19:08:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 19, 33 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Startup CEO",
      "screen_name" : "voozahq",
      "indices" : [ 61, 69 ],
      "id_str" : "524691753",
      "id" : 524691753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/fs1iT4FZrH",
      "expanded_url" : "http:\/\/vooza.com\/videos\/coffee-snob\/",
      "display_url" : "vooza.com\/videos\/coffee-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502160294987055104",
  "text" : "Basically everyday @coworkbuffalo http:\/\/t.co\/fs1iT4FZrH via @VoozaHQ",
  "id" : 502160294987055104,
  "created_at" : "2014-08-20 18:28:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brooklynbowl",
      "screen_name" : "brooklynbowl",
      "indices" : [ 3, 16 ],
      "id_str" : "17885166",
      "id" : 17885166
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 33, 45 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "The McLovins",
      "screen_name" : "TheMclovins",
      "indices" : [ 48, 60 ],
      "id_str" : "71704140",
      "id" : 71704140
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/brooklynbowl\/status\/502107877704609793\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/c2bHkRls4t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvfWBMbIAAAXHgr.png",
      "id_str" : "502105199478308864",
      "id" : 502105199478308864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvfWBMbIAAAXHgr.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/c2bHkRls4t"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/cNyc4MUq0q",
      "expanded_url" : "http:\/\/bkbwl.com\/5l",
      "display_url" : "bkbwl.com\/5l"
    } ]
  },
  "geo" : { },
  "id_str" : "502148065361268737",
  "text" : "RT @brooklynbowl: COMING OCT 28: @AqueousBand + @TheMclovins equal a night of two-fold funk\u2013tix on sale FRIDAY! http:\/\/t.co\/cNyc4MUq0q http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 15, 27 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "The McLovins",
        "screen_name" : "TheMclovins",
        "indices" : [ 30, 42 ],
        "id_str" : "71704140",
        "id" : 71704140
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/brooklynbowl\/status\/502107877704609793\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/c2bHkRls4t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvfWBMbIAAAXHgr.png",
        "id_str" : "502105199478308864",
        "id" : 502105199478308864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvfWBMbIAAAXHgr.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/c2bHkRls4t"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/cNyc4MUq0q",
        "expanded_url" : "http:\/\/bkbwl.com\/5l",
        "display_url" : "bkbwl.com\/5l"
      } ]
    },
    "geo" : { },
    "id_str" : "502107877704609793",
    "text" : "COMING OCT 28: @AqueousBand + @TheMclovins equal a night of two-fold funk\u2013tix on sale FRIDAY! http:\/\/t.co\/cNyc4MUq0q http:\/\/t.co\/c2bHkRls4t",
    "id" : 502107877704609793,
    "created_at" : "2014-08-20 15:00:21 +0000",
    "user" : {
      "name" : "brooklynbowl",
      "screen_name" : "brooklynbowl",
      "protected" : false,
      "id_str" : "17885166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458704571926188033\/z72G4Xku_normal.png",
      "id" : 17885166,
      "verified" : false
    }
  },
  "id" : 502148065361268737,
  "created_at" : "2014-08-20 17:40:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502133395800195073",
  "geo" : { },
  "id_str" : "502144322934829056",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael Yeesh. I was hoping to do the same once I order a new pair. Let me know if you find one!",
  "id" : 502144322934829056,
  "in_reply_to_status_id" : 502133395800195073,
  "created_at" : "2014-08-20 17:25:10 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502141231884144640",
  "geo" : { },
  "id_str" : "502141386263506944",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc I'm wrong as usual :)",
  "id" : 502141386263506944,
  "in_reply_to_status_id" : 502141231884144640,
  "created_at" : "2014-08-20 17:13:30 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502141030569738241",
  "text" : "Most seem to be airsoft\/BB guns. Still though.",
  "id" : 502141030569738241,
  "created_at" : "2014-08-20 17:12:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Batt",
      "screen_name" : "carolbatt",
      "indices" : [ 3, 13 ],
      "id_str" : "27682017",
      "id" : 27682017
    }, {
      "name" : "Buffalo\/Erie Library",
      "screen_name" : "buffalolibrary",
      "indices" : [ 99, 114 ],
      "id_str" : "34322946",
      "id" : 34322946
    }, {
      "name" : "Albright-Knox",
      "screen_name" : "AlbrightKnox",
      "indices" : [ 115, 128 ],
      "id_str" : "19289541",
      "id" : 19289541
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/carolbatt\/status\/502140013149437952\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aPFC2pOQo8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvf1rm1IQAE6VDQ.jpg",
      "id_str" : "502140012981665793",
      "id" : 502140012981665793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvf1rm1IQAE6VDQ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/aPFC2pOQo8"
    } ],
    "hashtags" : [ {
      "text" : "BuffaloCaverns",
      "indices" : [ 42, 57 ]
    }, {
      "text" : "TapeArt",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502140865595183105",
  "text" : "RT @carolbatt: With scaffold at the ready #BuffaloCaverns mural by #TapeArt soaring to new heights @buffalolibrary @albrightknox http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo\/Erie Library",
        "screen_name" : "buffalolibrary",
        "indices" : [ 84, 99 ],
        "id_str" : "34322946",
        "id" : 34322946
      }, {
        "name" : "Albright-Knox",
        "screen_name" : "AlbrightKnox",
        "indices" : [ 100, 113 ],
        "id_str" : "19289541",
        "id" : 19289541
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/carolbatt\/status\/502140013149437952\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/aPFC2pOQo8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvf1rm1IQAE6VDQ.jpg",
        "id_str" : "502140012981665793",
        "id" : 502140012981665793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvf1rm1IQAE6VDQ.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/aPFC2pOQo8"
      } ],
      "hashtags" : [ {
        "text" : "BuffaloCaverns",
        "indices" : [ 27, 42 ]
      }, {
        "text" : "TapeArt",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502140013149437952",
    "text" : "With scaffold at the ready #BuffaloCaverns mural by #TapeArt soaring to new heights @buffalolibrary @albrightknox http:\/\/t.co\/aPFC2pOQo8",
    "id" : 502140013149437952,
    "created_at" : "2014-08-20 17:08:03 +0000",
    "user" : {
      "name" : "Carol Batt",
      "screen_name" : "carolbatt",
      "protected" : false,
      "id_str" : "27682017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629798172\/Carol4_normal.JPG",
      "id" : 27682017,
      "verified" : false
    }
  },
  "id" : 502140865595183105,
  "created_at" : "2014-08-20 17:11:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502140466419085312",
  "text" : "So apparently you can buy guns off Amazon, and even ship it via Prime. Not sure why this surprises me, but it does.",
  "id" : 502140466419085312,
  "created_at" : "2014-08-20 17:09:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Powers",
      "screen_name" : "billmaxpowers",
      "indices" : [ 0, 14 ],
      "id_str" : "16143487",
      "id" : 16143487
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 15, 29 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/MOoGY74BI6",
      "expanded_url" : "http:\/\/www.wgrz.com\/story\/news\/local\/hamburg\/2014\/02\/07\/hamburg-police-department-receives-free-swat-vehicle-as-part-of-surplus-program\/5275429\/",
      "display_url" : "wgrz.com\/story\/news\/loc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "502120754855809024",
  "geo" : { },
  "id_str" : "502121132086927360",
  "in_reply_to_user_id" : 16143487,
  "text" : "@billmaxpowers @BuffaloRising Ask Hamburg. Maybe it's all those crazy Fair goers. http:\/\/t.co\/MOoGY74BI6",
  "id" : 502121132086927360,
  "in_reply_to_status_id" : 502120754855809024,
  "created_at" : "2014-08-20 15:53:01 +0000",
  "in_reply_to_screen_name" : "billmaxpowers",
  "in_reply_to_user_id_str" : "16143487",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurav Ragtah",
      "screen_name" : "gragtah",
      "indices" : [ 3, 11 ],
      "id_str" : "22242886",
      "id" : 22242886
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gragtah\/status\/442053685837717504\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/8Ss7r3yOnf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiJ9fCrCEAAcn2u.jpg",
      "id_str" : "442053685682507776",
      "id" : 442053685682507776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiJ9fCrCEAAcn2u.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/8Ss7r3yOnf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502120210027933697",
  "text" : "RT @gragtah: San Francisco described in a 1930s history book http:\/\/t.co\/8Ss7r3yOnf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gragtah\/status\/442053685837717504\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/8Ss7r3yOnf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiJ9fCrCEAAcn2u.jpg",
        "id_str" : "442053685682507776",
        "id" : 442053685682507776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiJ9fCrCEAAcn2u.jpg",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/8Ss7r3yOnf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442053685837717504",
    "text" : "San Francisco described in a 1930s history book http:\/\/t.co\/8Ss7r3yOnf",
    "id" : 442053685837717504,
    "created_at" : "2014-03-07 21:46:26 +0000",
    "user" : {
      "name" : "Gaurav Ragtah",
      "screen_name" : "gragtah",
      "protected" : false,
      "id_str" : "22242886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1506236170\/Gaurav_RA_pic_normal.jpg",
      "id" : 22242886,
      "verified" : false
    }
  },
  "id" : 502120210027933697,
  "created_at" : "2014-08-20 15:49:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britney Wright",
      "screen_name" : "britneywright",
      "indices" : [ 0, 14 ],
      "id_str" : "26582920",
      "id" : 26582920
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 15, 29 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501835647414710272",
  "geo" : { },
  "id_str" : "502120105170313216",
  "in_reply_to_user_id" : 26582920,
  "text" : "@britneywright @SteelCityRuby thanks for the mention! :D",
  "id" : 502120105170313216,
  "in_reply_to_status_id" : 501835647414710272,
  "created_at" : "2014-08-20 15:48:56 +0000",
  "in_reply_to_screen_name" : "britneywright",
  "in_reply_to_user_id_str" : "26582920",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 81, 87 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ZaOJfe02vU",
      "expanded_url" : "http:\/\/lowercasecapital.com\/2014\/08\/18\/a-few-thoughts-on-race-america-and-our-president\/",
      "display_url" : "lowercasecapital.com\/2014\/08\/18\/a-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502117572632797184",
  "text" : "Disgusted and appalled by this post. \"it appears Michael Brown was an asshole\" - @sacca http:\/\/t.co\/ZaOJfe02vU",
  "id" : 502117572632797184,
  "created_at" : "2014-08-20 15:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 0, 14 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/MOoGY74BI6",
      "expanded_url" : "http:\/\/www.wgrz.com\/story\/news\/local\/hamburg\/2014\/02\/07\/hamburg-police-department-receives-free-swat-vehicle-as-part-of-surplus-program\/5275429\/",
      "display_url" : "wgrz.com\/story\/news\/loc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "502116494655115264",
  "geo" : { },
  "id_str" : "502116772632219648",
  "in_reply_to_user_id" : 5896952,
  "text" : "@BuffaloRising According to WGRZ some of these may have been free\/low cost. Value is the same though. http:\/\/t.co\/MOoGY74BI6",
  "id" : 502116772632219648,
  "in_reply_to_status_id" : 502116494655115264,
  "created_at" : "2014-08-20 15:35:42 +0000",
  "in_reply_to_screen_name" : "BuffaloRising",
  "in_reply_to_user_id_str" : "5896952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 12, 23 ],
      "id_str" : "17386551",
      "id" : 17386551
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 60, 71 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502109029758283776",
  "geo" : { },
  "id_str" : "502110077545750528",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @natekontny **shoves 100 Paula's donut holes in @kevinpurdy mouth and watches as he dies happy**",
  "id" : 502110077545750528,
  "in_reply_to_status_id" : 502109029758283776,
  "created_at" : "2014-08-20 15:09:05 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Ward",
      "screen_name" : "eviltrout",
      "indices" : [ 0, 10 ],
      "id_str" : "16712921",
      "id" : 16712921
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502106399552598016",
  "geo" : { },
  "id_str" : "502108395915063297",
  "in_reply_to_user_id" : 16712921,
  "text" : "@eviltrout @coworkbuffalo I'd call them timbits if they were, actually timbits. These are a higher order.",
  "id" : 502108395915063297,
  "in_reply_to_status_id" : 502106399552598016,
  "created_at" : "2014-08-20 15:02:24 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pavel",
      "screen_name" : "zoftie",
      "indices" : [ 0, 7 ],
      "id_str" : "12165792",
      "id" : 12165792
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502099891980873729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915993252, -78.872256587 ]
  },
  "id_str" : "502100521931374592",
  "in_reply_to_user_id" : 12165792,
  "text" : "@zoftie @coworkbuffalo they are Paula\u2019s!!",
  "id" : 502100521931374592,
  "in_reply_to_status_id" : 502099891980873729,
  "created_at" : "2014-08-20 14:31:07 +0000",
  "in_reply_to_screen_name" : "zoftie",
  "in_reply_to_user_id_str" : "12165792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 0, 14 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Luminus Media, LLC",
      "screen_name" : "luminusmedia",
      "indices" : [ 24, 37 ],
      "id_str" : "88742394",
      "id" : 88742394
    }, {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 38, 46 ],
      "id_str" : "632391390",
      "id" : 632391390
    }, {
      "name" : "asbuffalo",
      "screen_name" : "asbuffalo",
      "indices" : [ 47, 57 ],
      "id_str" : "3032011745",
      "id" : 3032011745
    }, {
      "name" : "360 PSG",
      "screen_name" : "360PSG",
      "indices" : [ 58, 65 ],
      "id_str" : "18906882",
      "id" : 18906882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502100102983344128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915993252, -78.872256587 ]
  },
  "id_str" : "502100411029798912",
  "in_reply_to_user_id" : 491801330,
  "text" : "@coworkbuffalo zOMG \/cc @luminusmedia @Z80Labs @ASBuffalo @360psg",
  "id" : 502100411029798912,
  "in_reply_to_status_id" : 502100102983344128,
  "created_at" : "2014-08-20 14:30:41 +0000",
  "in_reply_to_screen_name" : "coworkbuffalo",
  "in_reply_to_user_id_str" : "491801330",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/502100102983344128\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/rhqMjyOzJt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvfRYP4CUAAh7jo.jpg",
      "id_str" : "502100097983729664",
      "id" : 502100097983729664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvfRYP4CUAAh7jo.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/rhqMjyOzJt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502100126593081346",
  "text" : "RT @coworkbuffalo: We have a hilarious amount of donut holes. Come in and help us not eat them all. http:\/\/t.co\/rhqMjyOzJt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/502100102983344128\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/rhqMjyOzJt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvfRYP4CUAAh7jo.jpg",
        "id_str" : "502100097983729664",
        "id" : 502100097983729664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvfRYP4CUAAh7jo.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/rhqMjyOzJt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502100102983344128",
    "text" : "We have a hilarious amount of donut holes. Come in and help us not eat them all. http:\/\/t.co\/rhqMjyOzJt",
    "id" : 502100102983344128,
    "created_at" : "2014-08-20 14:29:27 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 502100126593081346,
  "created_at" : "2014-08-20 14:29:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/501932308979793922\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/OPGPJOCtB3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvc4xn-IQAA9VJz.jpg",
      "id_str" : "501932308669415424",
      "id" : 501932308669415424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvc4xn-IQAA9VJz.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OPGPJOCtB3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502050375835193345",
  "text" : "RT @coworkbuffalo: FOLKS. If you are ANYWHERE NEAR our space tomorrow, stop in for some of these 150 PAULA'S DONUT HOLES. http:\/\/t.co\/OPGPJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/501932308979793922\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/OPGPJOCtB3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvc4xn-IQAA9VJz.jpg",
        "id_str" : "501932308669415424",
        "id" : 501932308669415424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvc4xn-IQAA9VJz.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OPGPJOCtB3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501932308979793922",
    "text" : "FOLKS. If you are ANYWHERE NEAR our space tomorrow, stop in for some of these 150 PAULA'S DONUT HOLES. http:\/\/t.co\/OPGPJOCtB3",
    "id" : 501932308979793922,
    "created_at" : "2014-08-20 03:22:42 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 502050375835193345,
  "created_at" : "2014-08-20 11:11:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/lVOOsmcYBF",
      "expanded_url" : "http:\/\/i.imgur.com\/hSOS9WB.jpg",
      "display_url" : "i.imgur.com\/hSOS9WB.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "501949294606163969",
  "text" : "Randomly generated human town in Dwarf Fortress. Huge, fortified, complete with suburbs. http:\/\/t.co\/lVOOsmcYBF",
  "id" : 501949294606163969,
  "created_at" : "2014-08-20 04:30:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501915662436929536",
  "text" : "RT @themcgruff: Anyone that follows me using apache kafka in production at scale?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501878721171968001",
    "text" : "Anyone that follows me using apache kafka in production at scale?",
    "id" : 501878721171968001,
    "created_at" : "2014-08-19 23:49:46 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 501915662436929536,
  "created_at" : "2014-08-20 02:16:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/XkZrwsmEnt",
      "expanded_url" : "http:\/\/www.rafflecopter.com\/",
      "display_url" : "rafflecopter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "501913350301700096",
  "text" : "I haven't used this service but would based on the URL alone http:\/\/t.co\/XkZrwsmEnt",
  "id" : 501913350301700096,
  "created_at" : "2014-08-20 02:07:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/lc5o3nceEl",
      "expanded_url" : "http:\/\/www.w3schools.com\/html\/html5_form_input_types.asp",
      "display_url" : "w3schools.com\/html\/html5_for\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501908073875644416",
  "text" : "Didn't know about input type=number or url. Neat: http:\/\/t.co\/lc5o3nceEl",
  "id" : 501908073875644416,
  "created_at" : "2014-08-20 01:46:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 0, 13 ],
      "id_str" : "35163668",
      "id" : 35163668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/abbqjtFdFr",
      "expanded_url" : "https:\/\/twitter.com\/laurakirsop\/status\/501830527788515330",
      "display_url" : "twitter.com\/laurakirsop\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "501899008634523648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9235219928, -78.8793528951 ]
  },
  "id_str" : "501899234115735552",
  "in_reply_to_user_id" : 35163668,
  "text" : "@pookleblinky relevant: https:\/\/t.co\/abbqjtFdFr",
  "id" : 501899234115735552,
  "in_reply_to_status_id" : 501899008634523648,
  "created_at" : "2014-08-20 01:11:16 +0000",
  "in_reply_to_screen_name" : "pookleblinky",
  "in_reply_to_user_id_str" : "35163668",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Estreet ",
      "screen_name" : "estreetpicks",
      "indices" : [ 0, 13 ],
      "id_str" : "19929749",
      "id" : 19929749
    }, {
      "name" : "Jill Terreri Ramos",
      "screen_name" : "jillterreri",
      "indices" : [ 14, 26 ],
      "id_str" : "46209505",
      "id" : 46209505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/AOHe2T7OPy",
      "expanded_url" : "http:\/\/git.io\/DZGvMQ",
      "display_url" : "git.io\/DZGvMQ"
    } ]
  },
  "in_reply_to_status_id_str" : "501891508929560577",
  "geo" : { },
  "id_str" : "501891777989595137",
  "in_reply_to_user_id" : 19929749,
  "text" : "@estreetpicks @jillterreri That sure sounds like the MRV $650K pricetag - http:\/\/t.co\/AOHe2T7OPy",
  "id" : 501891777989595137,
  "in_reply_to_status_id" : 501891508929560577,
  "created_at" : "2014-08-20 00:41:39 +0000",
  "in_reply_to_screen_name" : "estreetpicks",
  "in_reply_to_user_id_str" : "19929749",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Terreri Ramos",
      "screen_name" : "jillterreri",
      "indices" : [ 0, 12 ],
      "id_str" : "46209505",
      "id" : 46209505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fvX1bMorki",
      "expanded_url" : "https:\/\/github.com\/TheUpshot\/Military-Surplus-Gear#military-surplus-gear",
      "display_url" : "github.com\/TheUpshot\/Mili\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "501891153286156288",
  "geo" : { },
  "id_str" : "501891527287660544",
  "in_reply_to_user_id" : 46209505,
  "text" : "@jillterreri Forgot to cc you, sorry! It's not clear. Here's all the explanation the NYT provided: https:\/\/t.co\/fvX1bMorki",
  "id" : 501891527287660544,
  "in_reply_to_status_id" : 501891153286156288,
  "created_at" : "2014-08-20 00:40:39 +0000",
  "in_reply_to_screen_name" : "jillterreri",
  "in_reply_to_user_id_str" : "46209505",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/war3CV64F3",
      "expanded_url" : "https:\/\/github.com\/TheUpshot\/Military-Surplus-Gear",
      "display_url" : "github.com\/TheUpshot\/Mili\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "501889513325867008",
  "geo" : { },
  "id_str" : "501889641868296193",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic You can look it up yourself! https:\/\/t.co\/war3CV64F3",
  "id" : 501889641868296193,
  "in_reply_to_status_id" : 501889513325867008,
  "created_at" : "2014-08-20 00:33:09 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 85, 99 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/xK1mn2y6j3",
      "expanded_url" : "http:\/\/git.io\/DZGvMQ",
      "display_url" : "git.io\/DZGvMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "501887943263682560",
  "text" : "$658,000 on a MINE RESISTANT VEHICLE. I bet that'll open up cars on Main Street. \/cc @buffalopundit http:\/\/t.co\/xK1mn2y6j3",
  "id" : 501887943263682560,
  "created_at" : "2014-08-20 00:26:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Hirtzel",
      "screen_name" : "AshleyHirtz",
      "indices" : [ 72, 84 ],
      "id_str" : "196353523",
      "id" : 196353523
    }, {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 85, 99 ],
      "id_str" : "45490102",
      "id" : 45490102
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 100, 114 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/tIHNr8qrZ3",
      "expanded_url" : "http:\/\/git.io\/Un0K1g",
      "display_url" : "git.io\/Un0K1g"
    } ]
  },
  "geo" : { },
  "id_str" : "501887587674361856",
  "text" : "$973332.12 spent on MRV, 6 7.62mm rifles, NVG, and more in Erie Co. \/cc @AshleyHirtz @markpoloncarz @BuffaloRising http:\/\/t.co\/tIHNr8qrZ3",
  "id" : 501887587674361856,
  "created_at" : "2014-08-20 00:25:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 13, 21 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/iY7gIbOIrh",
      "expanded_url" : "https:\/\/github.com\/qrush\/Military-Surplus-Gear\/blob\/master\/1033-program-foia-may-2014.csv",
      "display_url" : "github.com\/qrush\/Military\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501886735513444352",
  "text" : "Cut down the @NYTimes military surplus data to just Erie and Niagara counties: https:\/\/t.co\/iY7gIbOIrh",
  "id" : 501886735513444352,
  "created_at" : "2014-08-20 00:21:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 15, 27 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/XSidMSgDHG",
      "expanded_url" : "http:\/\/aqueousband.net\/search?utf8=%E2%9C%93&query=pittsburgh",
      "display_url" : "aqueousband.net\/search?utf8=%E\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "501862724339781633",
  "geo" : { },
  "id_str" : "501863110286651392",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @AqueousBand Missed them in May! http:\/\/t.co\/XSidMSgDHG Maybe 2 Buffalo road trips in October? :P",
  "id" : 501863110286651392,
  "in_reply_to_status_id" : 501862724339781633,
  "created_at" : "2014-08-19 22:47:44 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@pplcallmejam",
      "screen_name" : "Justjamonit",
      "indices" : [ 3, 15 ],
      "id_str" : "2863047410",
      "id" : 2863047410
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Browser Spree",
      "screen_name" : "browserspree",
      "indices" : [ 104, 117 ],
      "id_str" : "2569730581",
      "id" : 2569730581
    }, {
      "name" : "Rails Girls SoC",
      "screen_name" : "RailsGirlsSoC",
      "indices" : [ 118, 132 ],
      "id_str" : "1370240701",
      "id" : 1370240701
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 133, 143 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 145, 146 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 145, 146 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501862903037689856",
  "text" : "RT @justjamonit: Time off approved! Looks like I'll be  @nickelcityruby in October! &lt;happy dance&gt; @browserspree @RailsGirlsSoC @aspleenic @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 39, 54 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Browser Spree",
        "screen_name" : "browserspree",
        "indices" : [ 87, 100 ],
        "id_str" : "2569730581",
        "id" : 2569730581
      }, {
        "name" : "Rails Girls SoC",
        "screen_name" : "RailsGirlsSoC",
        "indices" : [ 101, 115 ],
        "id_str" : "1370240701",
        "id" : 1370240701
      }, {
        "name" : "PJ Hagerty",
        "screen_name" : "aspleenic",
        "indices" : [ 116, 126 ],
        "id_str" : "31435721",
        "id" : 31435721
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 127, 137 ],
        "id_str" : "5744442",
        "id" : 5744442
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 138, 144 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501861155804307456",
    "text" : "Time off approved! Looks like I'll be  @nickelcityruby in October! &lt;happy dance&gt; @browserspree @RailsGirlsSoC @aspleenic @aquaranto @qrush",
    "id" : 501861155804307456,
    "created_at" : "2014-08-19 22:39:58 +0000",
    "user" : {
      "name" : "Jam Black",
      "screen_name" : "pplcallmejam",
      "protected" : false,
      "id_str" : "1547239940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535571829289938944\/HHoNyk5A_normal.jpeg",
      "id" : 1547239940,
      "verified" : false
    }
  },
  "id" : 501862903037689856,
  "created_at" : "2014-08-19 22:46:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 19, 29 ],
      "id_str" : "816041347",
      "id" : 816041347
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 57, 72 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241794426, -78.8821476691 ]
  },
  "id_str" : "501847896644259840",
  "text" : "New outdoor pickup @BreadHive is fantastic. Bonus: To go @PublicEspresso cold brew. Double bonus: happy and tired husky after a walk.",
  "id" : 501847896644259840,
  "created_at" : "2014-08-19 21:47:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501830851429015552",
  "text" : "RT @nickelcityruby: Are you a member or organizer of a group teaching people to code? Reach out to us for a discount code for Students!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501827831563694080",
    "text" : "Are you a member or organizer of a group teaching people to code? Reach out to us for a discount code for Students!",
    "id" : 501827831563694080,
    "created_at" : "2014-08-19 20:27:33 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 501830851429015552,
  "created_at" : "2014-08-19 20:39:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 3, 12 ],
      "id_str" : "18824526",
      "id" : 18824526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/HbL8E2DbxR",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/features\/how-many-americans-the-police-kill-each-year\/",
      "display_url" : "fivethirtyeight.com\/features\/how-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501819765070237696",
  "text" : "RT @jacobian: We don\u2019t track how many Americans are killed by cops every year. We care so little that we don\u2019t even track it. http:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/HbL8E2DbxR",
        "expanded_url" : "http:\/\/fivethirtyeight.com\/features\/how-many-americans-the-police-kill-each-year\/",
        "display_url" : "fivethirtyeight.com\/features\/how-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "501819245764698112",
    "text" : "We don\u2019t track how many Americans are killed by cops every year. We care so little that we don\u2019t even track it. http:\/\/t.co\/HbL8E2DbxR",
    "id" : 501819245764698112,
    "created_at" : "2014-08-19 19:53:26 +0000",
    "user" : {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "protected" : false,
      "id_str" : "18824526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70449715\/me-as-a-baby_normal.jpg",
      "id" : 18824526,
      "verified" : false
    }
  },
  "id" : 501819765070237696,
  "created_at" : "2014-08-19 19:55:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 32, 44 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/OZGoWLWIog",
      "expanded_url" : "http:\/\/www.jambase.com\/Articles\/122497\/Tour-Dates-Aqueous-Fall-Tour",
      "display_url" : "jambase.com\/Articles\/12249\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501797908212383745",
  "text" : "Only one Buffalo show for fall. @AqueousBand is killing it and coming to a city near you: http:\/\/t.co\/OZGoWLWIog",
  "id" : 501797908212383745,
  "created_at" : "2014-08-19 18:28:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JamBase",
      "screen_name" : "JamBase",
      "indices" : [ 3, 11 ],
      "id_str" : "14156684",
      "id" : 14156684
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 56, 68 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JamBase\/status\/501786169810493441\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KrkBpbMmIS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvaz3MCIYAEc2Fm.jpg",
      "id_str" : "501786169202728961",
      "id" : 501786169202728961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvaz3MCIYAEc2Fm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 388
      } ],
      "display_url" : "pic.twitter.com\/KrkBpbMmIS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/nOKiLGLdJ5",
      "expanded_url" : "http:\/\/bit.ly\/1qmX3Un",
      "display_url" : "bit.ly\/1qmX3Un"
    } ]
  },
  "geo" : { },
  "id_str" : "501787836484317184",
  "text" : "RT @JamBase: Tour Dates: Up-and-coming jam act Aqueous (@AqueousBand) has announced an extensive fall tour http:\/\/t.co\/nOKiLGLdJ5 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 43, 55 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JamBase\/status\/501786169810493441\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KrkBpbMmIS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvaz3MCIYAEc2Fm.jpg",
        "id_str" : "501786169202728961",
        "id" : 501786169202728961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvaz3MCIYAEc2Fm.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 388
        } ],
        "display_url" : "pic.twitter.com\/KrkBpbMmIS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/nOKiLGLdJ5",
        "expanded_url" : "http:\/\/bit.ly\/1qmX3Un",
        "display_url" : "bit.ly\/1qmX3Un"
      } ]
    },
    "geo" : { },
    "id_str" : "501786169810493441",
    "text" : "Tour Dates: Up-and-coming jam act Aqueous (@AqueousBand) has announced an extensive fall tour http:\/\/t.co\/nOKiLGLdJ5 http:\/\/t.co\/KrkBpbMmIS",
    "id" : 501786169810493441,
    "created_at" : "2014-08-19 17:42:00 +0000",
    "user" : {
      "name" : "JamBase",
      "screen_name" : "JamBase",
      "protected" : false,
      "id_str" : "14156684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458780708844994560\/4yhJ1bzT_normal.png",
      "id" : 14156684,
      "verified" : false
    }
  },
  "id" : 501787836484317184,
  "created_at" : "2014-08-19 17:48:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/501783704331902976\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/RDmxGNOp83",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvaxnqZIgAAJEMp.jpg",
      "id_str" : "501783703451107328",
      "id" : 501783703451107328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvaxnqZIgAAJEMp.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 927,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 621
      } ],
      "display_url" : "pic.twitter.com\/RDmxGNOp83"
    } ],
    "hashtags" : [ {
      "text" : "AQband",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "tourdates",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "livemusic",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501783814549409792",
  "text" : "RT @UnclePhilsBlog: @AqueousBand fall tour 2014! So many states! #AQband #tourdates #livemusic http:\/\/t.co\/RDmxGNOp83",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/501783704331902976\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/RDmxGNOp83",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvaxnqZIgAAJEMp.jpg",
        "id_str" : "501783703451107328",
        "id" : 501783703451107328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvaxnqZIgAAJEMp.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 621
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 927,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 621
        } ],
        "display_url" : "pic.twitter.com\/RDmxGNOp83"
      } ],
      "hashtags" : [ {
        "text" : "AQband",
        "indices" : [ 45, 52 ]
      }, {
        "text" : "tourdates",
        "indices" : [ 53, 63 ]
      }, {
        "text" : "livemusic",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501783704331902976",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand fall tour 2014! So many states! #AQband #tourdates #livemusic http:\/\/t.co\/RDmxGNOp83",
    "id" : 501783704331902976,
    "created_at" : "2014-08-19 17:32:12 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 501783814549409792,
  "created_at" : "2014-08-19 17:32:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 13, 24 ],
      "id_str" : "17386551",
      "id" : 17386551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/58AR6EP3bP",
      "expanded_url" : "http:\/\/37svn.com\/3770",
      "display_url" : "37svn.com\/3770"
    } ]
  },
  "geo" : { },
  "id_str" : "501783795721175040",
  "text" : "Happy to see @natekontny taking over Highrise: http:\/\/t.co\/58AR6EP3bP",
  "id" : 501783795721175040,
  "created_at" : "2014-08-19 17:32:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Benziger",
      "screen_name" : "tybenz",
      "indices" : [ 0, 7 ],
      "id_str" : "25610580",
      "id" : 25610580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501771424948690944",
  "geo" : { },
  "id_str" : "501771759448641536",
  "in_reply_to_user_id" : 25610580,
  "text" : "@tybenz awesome. are you making a hubot bot? Because I didn't want to port it, and all the Ruby CF bots suck.",
  "id" : 501771759448641536,
  "in_reply_to_status_id" : 501771424948690944,
  "created_at" : "2014-08-19 16:44:44 +0000",
  "in_reply_to_screen_name" : "tybenz",
  "in_reply_to_user_id_str" : "25610580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/YjDhCGJmD1",
      "expanded_url" : "https:\/\/flic.kr\/p\/owpqWk",
      "display_url" : "flic.kr\/p\/owpqWk"
    } ]
  },
  "geo" : { },
  "id_str" : "501757258296868864",
  "text" : "Late summer husky. https:\/\/t.co\/YjDhCGJmD1",
  "id" : 501757258296868864,
  "created_at" : "2014-08-19 15:47:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 24, 34 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/501726567190388736\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/c49A0Vb6jG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvZ5KkCIYAA2-fz.jpg",
      "id_str" : "501721630876655616",
      "id" : 501721630876655616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvZ5KkCIYAA2-fz.jpg",
      "sizes" : [ {
        "h" : 820,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 850
      } ],
      "display_url" : "pic.twitter.com\/c49A0Vb6jG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/0tXZCcoIQt",
      "expanded_url" : "http:\/\/bit.ly\/1rSqL5s",
      "display_url" : "bit.ly\/1rSqL5s"
    } ]
  },
  "geo" : { },
  "id_str" : "501731845696786432",
  "text" : "Photos from Rochester: \u201C@voxdotcom: The ugly history of racist policing in America: http:\/\/t.co\/0tXZCcoIQt http:\/\/t.co\/c49A0Vb6jG\u201D",
  "id" : 501731845696786432,
  "created_at" : "2014-08-19 14:06:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 77, 87 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PublicEspresso\/status\/501521174828818432\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HiUTpGTCeT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvXC2WNCQAEpfZA.png",
      "id_str" : "501521172450656257",
      "id" : 501521172450656257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvXC2WNCQAEpfZA.png",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 535
      } ],
      "display_url" : "pic.twitter.com\/HiUTpGTCeT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/P55S4n6orP",
      "expanded_url" : "http:\/\/www.publicespresso.com\/products\/publicoffering",
      "display_url" : "publicespresso.com\/products\/publi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501530945971687424",
  "text" : "RT @PublicEspresso: Did you know you can pick up our coffee every Tuesday at @BreadHive as part of our CSA? http:\/\/t.co\/P55S4n6orP http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BreadHive",
        "screen_name" : "BreadHive",
        "indices" : [ 57, 67 ],
        "id_str" : "816041347",
        "id" : 816041347
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PublicEspresso\/status\/501521174828818432\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/HiUTpGTCeT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvXC2WNCQAEpfZA.png",
        "id_str" : "501521172450656257",
        "id" : 501521172450656257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvXC2WNCQAEpfZA.png",
        "sizes" : [ {
          "h" : 508,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 535
        } ],
        "display_url" : "pic.twitter.com\/HiUTpGTCeT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/P55S4n6orP",
        "expanded_url" : "http:\/\/www.publicespresso.com\/products\/publicoffering",
        "display_url" : "publicespresso.com\/products\/publi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "501521174828818432",
    "text" : "Did you know you can pick up our coffee every Tuesday at @BreadHive as part of our CSA? http:\/\/t.co\/P55S4n6orP http:\/\/t.co\/HiUTpGTCeT",
    "id" : 501521174828818432,
    "created_at" : "2014-08-19 00:09:00 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 501530945971687424,
  "created_at" : "2014-08-19 00:47:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/vRpg7kx9Yi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=3N6NGs7ji9w",
      "display_url" : "youtube.com\/watch?v=3N6NGs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501523186886782976",
  "text" : "TIL I learned there's a Pokemon World Championship, with announcers, and the winner won with a tiny squirrel. https:\/\/t.co\/vRpg7kx9Yi",
  "id" : 501523186886782976,
  "created_at" : "2014-08-19 00:17:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 11, 25 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 26, 38 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501493121734021120",
  "geo" : { },
  "id_str" : "501497603628888066",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @Carols10cents @coreyhaines Yes\/No\/French Fries",
  "id" : 501497603628888066,
  "in_reply_to_status_id" : 501493121734021120,
  "created_at" : "2014-08-18 22:35:20 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501469174859046912",
  "text" : "We owe it to ourselves and others to make leaving OSS projects easier and less guilt-ridden\/difficult for those involved.",
  "id" : 501469174859046912,
  "created_at" : "2014-08-18 20:42:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 3, 9 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/DptHCBnrts",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/rack-devel\/P8oOycVBaH0",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501469019560742912",
  "text" : "RT @raggi: It's official, I'm done! (Rack)\n\nhttps:\/\/t.co\/DptHCBnrts\n\nNeeded doing for a long while. BIG weight lifted.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/DptHCBnrts",
        "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/rack-devel\/P8oOycVBaH0",
        "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "501466890670469120",
    "text" : "It's official, I'm done! (Rack)\n\nhttps:\/\/t.co\/DptHCBnrts\n\nNeeded doing for a long while. BIG weight lifted.",
    "id" : 501466890670469120,
    "created_at" : "2014-08-18 20:33:18 +0000",
    "user" : {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "protected" : false,
      "id_str" : "15359408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3388593743\/5530c82013709c3922ef8f947092b623_normal.jpeg",
      "id" : 15359408,
      "verified" : false
    }
  },
  "id" : 501469019560742912,
  "created_at" : "2014-08-18 20:41:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501426609518575617",
  "geo" : { },
  "id_str" : "501426715059441664",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN didnt know they had a patio now!",
  "id" : 501426715059441664,
  "in_reply_to_status_id" : 501426609518575617,
  "created_at" : "2014-08-18 17:53:39 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trailer Park Boys",
      "screen_name" : "trailerparkboys",
      "indices" : [ 56, 72 ],
      "id_str" : "18210554",
      "id" : 18210554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501425470542323712",
  "text" : "Better haul in the jib before it's covered in shit. New @trailerparkboys only on Netflix coming soon.",
  "id" : 501425470542323712,
  "created_at" : "2014-08-18 17:48:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 45, 60 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Ce3ysi4p2e",
      "expanded_url" : "https:\/\/twitter.com\/SharonCantillon\/status\/501407600668598274",
      "display_url" : "twitter.com\/SharonCantillo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501413534387802112",
  "text" : "Some neat art being created at our venue for @nickelcityruby. Have your ticket yet? https:\/\/t.co\/Ce3ysi4p2e",
  "id" : 501413534387802112,
  "created_at" : "2014-08-18 17:01:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Cantillon",
      "screen_name" : "SharonCantillon",
      "indices" : [ 3, 19 ],
      "id_str" : "1849285620",
      "id" : 1849285620
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SharonCantillon\/status\/501407600668598274\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/6iKZbxu2L3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvVbjjHIMAAHZcv.jpg",
      "id_str" : "501407599800365056",
      "id" : 501407599800365056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvVbjjHIMAAHZcv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6iKZbxu2L3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501413188718444544",
  "text" : "RT @SharonCantillon: Art scene being created entirely of painter's tape on the north wall at the Central Library in Buffalo. http:\/\/t.co\/6i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SharonCantillon\/status\/501407600668598274\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/6iKZbxu2L3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvVbjjHIMAAHZcv.jpg",
        "id_str" : "501407599800365056",
        "id" : 501407599800365056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvVbjjHIMAAHZcv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/6iKZbxu2L3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501407600668598274",
    "text" : "Art scene being created entirely of painter's tape on the north wall at the Central Library in Buffalo. http:\/\/t.co\/6iKZbxu2L3",
    "id" : 501407600668598274,
    "created_at" : "2014-08-18 16:37:42 +0000",
    "user" : {
      "name" : "Sharon Cantillon",
      "screen_name" : "SharonCantillon",
      "protected" : false,
      "id_str" : "1849285620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000435606460\/ea496904a4a0ac14bfa79ddd371cceaf_normal.jpeg",
      "id" : 1849285620,
      "verified" : false
    }
  },
  "id" : 501413188718444544,
  "created_at" : "2014-08-18 16:59:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501396995698073601",
  "geo" : { },
  "id_str" : "501397609542471681",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo It'll be shorter coming from SFO. OAK is just a longer train ride.",
  "id" : 501397609542471681,
  "in_reply_to_status_id" : 501396995698073601,
  "created_at" : "2014-08-18 15:58:00 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501394925146361856",
  "geo" : { },
  "id_str" : "501395598864424960",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo BART goes to both. Is this for the SF show?",
  "id" : 501395598864424960,
  "in_reply_to_status_id" : 501394925146361856,
  "created_at" : "2014-08-18 15:50:00 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 0, 15 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501363711009759233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242030362, -78.8790083351 ]
  },
  "id_str" : "501366161452179457",
  "in_reply_to_user_id" : 81525784,
  "text" : "@franklinwebber yep it\u2019s CC!",
  "id" : 501366161452179457,
  "in_reply_to_status_id" : 501363711009759233,
  "created_at" : "2014-08-18 13:53:02 +0000",
  "in_reply_to_screen_name" : "franklinwebber",
  "in_reply_to_user_id_str" : "81525784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501207933254766592",
  "text" : "Watching the live streams from Ferguson is the scariest shit I\u2019ve seen in a long time. Cannot imagine what it\u2019s like being there.",
  "id" : 501207933254766592,
  "created_at" : "2014-08-18 03:24:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/spaB9lfS5z",
      "expanded_url" : "https:\/\/flic.kr\/p\/ouSXdv",
      "display_url" : "flic.kr\/p\/ouSXdv"
    } ]
  },
  "geo" : { },
  "id_str" : "501183129973825536",
  "text" : "Just one more: HDR PGH https:\/\/t.co\/spaB9lfS5z",
  "id" : 501183129973825536,
  "created_at" : "2014-08-18 01:45:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 16, 31 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/cQWZNrLqhs",
      "expanded_url" : "https:\/\/flic.kr\/p\/ouSYR1",
      "display_url" : "flic.kr\/p\/ouSYR1"
    } ]
  },
  "geo" : { },
  "id_str" : "501182922057986049",
  "text" : "High definition @franklinwebber https:\/\/t.co\/cQWZNrLqhs",
  "id" : 501182922057986049,
  "created_at" : "2014-08-18 01:44:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 0, 10 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501182445811957760",
  "geo" : { },
  "id_str" : "501182717338210304",
  "in_reply_to_user_id" : 253464752,
  "text" : "@jessicard You've acquired a new pet! &lt;Boo&gt;",
  "id" : 501182717338210304,
  "in_reply_to_status_id" : 501182445811957760,
  "created_at" : "2014-08-18 01:44:06 +0000",
  "in_reply_to_screen_name" : "jessicard",
  "in_reply_to_user_id_str" : "253464752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 32, 46 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/T76Dl3UkvX",
      "expanded_url" : "https:\/\/flic.kr\/s\/aHsk1WPYRC",
      "display_url" : "flic.kr\/s\/aHsk1WPYRC"
    } ]
  },
  "geo" : { },
  "id_str" : "501182289259163648",
  "text" : "Just a few shots from #scrc14 \/ @steelcityruby https:\/\/t.co\/T76Dl3UkvX",
  "id" : 501182289259163648,
  "created_at" : "2014-08-18 01:42:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drew Olson",
      "screen_name" : "drewolson",
      "indices" : [ 0, 10 ],
      "id_str" : "7482872",
      "id" : 7482872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501173146179751936",
  "geo" : { },
  "id_str" : "501175587231113217",
  "in_reply_to_user_id" : 7482872,
  "text" : "@drewolson cool thanks!",
  "id" : 501175587231113217,
  "in_reply_to_status_id" : 501173146179751936,
  "created_at" : "2014-08-18 01:15:46 +0000",
  "in_reply_to_screen_name" : "drewolson",
  "in_reply_to_user_id_str" : "7482872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drew Olson",
      "screen_name" : "drewolson",
      "indices" : [ 0, 10 ],
      "id_str" : "7482872",
      "id" : 7482872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501172370372296704",
  "geo" : { },
  "id_str" : "501172685284442112",
  "in_reply_to_user_id" : 7482872,
  "text" : "@drewolson what is this and how do i play!?",
  "id" : 501172685284442112,
  "in_reply_to_status_id" : 501172370372296704,
  "created_at" : "2014-08-18 01:04:14 +0000",
  "in_reply_to_screen_name" : "drewolson",
  "in_reply_to_user_id_str" : "7482872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501154092232634369",
  "text" : "RT @IAM_SHAKESPEARE: liquor.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501154010066587648",
    "text" : "liquor.",
    "id" : 501154010066587648,
    "created_at" : "2014-08-17 23:50:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 501154092232634369,
  "created_at" : "2014-08-17 23:50:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew S. Burns",
      "screen_name" : "mrwasteland",
      "indices" : [ 3, 15 ],
      "id_str" : "61336370",
      "id" : 61336370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501107687753809922",
  "text" : "RT @mrwasteland: Our app is slow-compiled in small batches, with minimal optimizations and linking only locally-sourced libraries",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501101762632486912",
    "text" : "Our app is slow-compiled in small batches, with minimal optimizations and linking only locally-sourced libraries",
    "id" : 501101762632486912,
    "created_at" : "2014-08-17 20:22:24 +0000",
    "user" : {
      "name" : "Matthew S. Burns",
      "screen_name" : "mrwasteland",
      "protected" : false,
      "id_str" : "61336370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568663464613126144\/MnMU12jc_normal.jpeg",
      "id" : 61336370,
      "verified" : false
    }
  },
  "id" : 501107687753809922,
  "created_at" : "2014-08-17 20:45:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Graham",
      "screen_name" : "ByTimGraham",
      "indices" : [ 0, 12 ],
      "id_str" : "41540854",
      "id" : 41540854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501054608677273601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.166781402, -80.6653629049 ]
  },
  "id_str" : "501055340180676612",
  "in_reply_to_user_id" : 41540854,
  "text" : "@ByTimGraham just passed this in PGH. Pick up some goodies from IKEA!",
  "id" : 501055340180676612,
  "in_reply_to_status_id" : 501054608677273601,
  "created_at" : "2014-08-17 17:17:56 +0000",
  "in_reply_to_screen_name" : "ByTimGraham",
  "in_reply_to_user_id_str" : "41540854",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/AHtiQayncg",
      "expanded_url" : "http:\/\/m.imgur.com\/a\/foRgr",
      "display_url" : "m.imgur.com\/a\/foRgr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1666987325, -80.6654531323 ]
  },
  "id_str" : "501055072424697856",
  "text" : "Awesome Studio Ghibli street art from Buffalo this weekend: http:\/\/t.co\/AHtiQayncg",
  "id" : 501055072424697856,
  "created_at" : "2014-08-17 17:16:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Overheard at Phish",
      "screen_name" : "overheardphish",
      "indices" : [ 3, 18 ],
      "id_str" : "68008192",
      "id" : 68008192
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/overheardphish\/status\/501032627134947328\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/8jN64KQJYS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvQGhMcCAAAuEGI.jpg",
      "id_str" : "501032625889214464",
      "id" : 501032625889214464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvQGhMcCAAAuEGI.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/8jN64KQJYS"
    } ],
    "hashtags" : [ {
      "text" : "RollingStoneInterview",
      "indices" : [ 63, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501037457228722176",
  "text" : "RT @overheardphish: \"It's not like I'm Phish\"\n--Paul McCartney #RollingStoneInterview http:\/\/t.co\/8jN64KQJYS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/overheardphish\/status\/501032627134947328\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/8jN64KQJYS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvQGhMcCAAAuEGI.jpg",
        "id_str" : "501032625889214464",
        "id" : 501032625889214464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvQGhMcCAAAuEGI.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/8jN64KQJYS"
      } ],
      "hashtags" : [ {
        "text" : "RollingStoneInterview",
        "indices" : [ 43, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501032627134947328",
    "text" : "\"It's not like I'm Phish\"\n--Paul McCartney #RollingStoneInterview http:\/\/t.co\/8jN64KQJYS",
    "id" : 501032627134947328,
    "created_at" : "2014-08-17 15:47:41 +0000",
    "user" : {
      "name" : "Overheard at Phish",
      "screen_name" : "overheardphish",
      "protected" : false,
      "id_str" : "68008192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3276184625\/67af44db1547b16d028cc77221416f24_normal.jpeg",
      "id" : 68008192,
      "verified" : false
    }
  },
  "id" : 501037457228722176,
  "created_at" : "2014-08-17 16:06:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Peach Music Festival",
      "screen_name" : "PeachMusicFest",
      "indices" : [ 27, 42 ],
      "id_str" : "510950211",
      "id" : 510950211
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/501035484446228480\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/b9oPHELS5i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvQJHiFIAAAYNuQ.jpg",
      "id_str" : "501035483557003264",
      "id" : 501035483557003264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvQJHiFIAAAYNuQ.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/b9oPHELS5i"
    } ],
    "hashtags" : [ {
      "text" : "rage",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501037234825756674",
  "text" : "RT @AqueousBand: Thank you @PeachMusicFest! We love you! #rage http:\/\/t.co\/b9oPHELS5i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peach Music Festival",
        "screen_name" : "PeachMusicFest",
        "indices" : [ 10, 25 ],
        "id_str" : "510950211",
        "id" : 510950211
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/501035484446228480\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/b9oPHELS5i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvQJHiFIAAAYNuQ.jpg",
        "id_str" : "501035483557003264",
        "id" : 501035483557003264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvQJHiFIAAAYNuQ.jpg",
        "sizes" : [ {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/b9oPHELS5i"
      } ],
      "hashtags" : [ {
        "text" : "rage",
        "indices" : [ 40, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501035484446228480",
    "text" : "Thank you @PeachMusicFest! We love you! #rage http:\/\/t.co\/b9oPHELS5i",
    "id" : 501035484446228480,
    "created_at" : "2014-08-17 15:59:02 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 501037234825756674,
  "created_at" : "2014-08-17 16:06:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 27, 39 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/B1udmLAR7Y",
      "expanded_url" : "https:\/\/twitter.com\/UnclePhilsBlog\/status\/500796071120220160",
      "display_url" : "twitter.com\/UnclePhilsBlog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "500796413077626881",
  "text" : "Looks like quite a few new @AqueousBand fans were made tonight, biggest crowd I've seen: https:\/\/t.co\/B1udmLAR7Y",
  "id" : 500796413077626881,
  "created_at" : "2014-08-17 00:09:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "PhishatTheMann",
      "screen_name" : "PhishatTheMann",
      "indices" : [ 16, 31 ],
      "id_str" : "2202143780",
      "id" : 2202143780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500796071120220160",
  "geo" : { },
  "id_str" : "500796243640336386",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @PhishatTheMann Aww yeah!",
  "id" : 500796243640336386,
  "in_reply_to_status_id" : 500796071120220160,
  "created_at" : "2014-08-17 00:08:23 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "PhishatTheMann",
      "screen_name" : "PhishatTheMann",
      "indices" : [ 16, 31 ],
      "id_str" : "2202143780",
      "id" : 2202143780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500774145052139521",
  "geo" : { },
  "id_str" : "500794082869141504",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @PhishatTheMann how'd it go?",
  "id" : 500794082869141504,
  "in_reply_to_status_id" : 500774145052139521,
  "created_at" : "2014-08-16 23:59:48 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhishatTheMann",
      "screen_name" : "PhishatTheMann",
      "indices" : [ 3, 18 ],
      "id_str" : "2202143780",
      "id" : 2202143780
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PhishatTheMann\/status\/500772595680440320\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/G0lH8gWdAo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvMZ_cgIIAAD2g-.jpg",
      "id_str" : "500772561341652992",
      "id" : 500772561341652992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvMZ_cgIIAAD2g-.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/G0lH8gWdAo"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/PhishatTheMann\/status\/500772595680440320\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/G0lH8gWdAo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvMaAsuIYAATkVK.jpg",
      "id_str" : "500772582875226112",
      "id" : 500772582875226112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvMaAsuIYAATkVK.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/G0lH8gWdAo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500774391417167874",
  "text" : "RT @PhishatTheMann: @AqueousBand killin it http:\/\/t.co\/G0lH8gWdAo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PhishatTheMann\/status\/500772595680440320\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/G0lH8gWdAo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvMZ_cgIIAAD2g-.jpg",
        "id_str" : "500772561341652992",
        "id" : 500772561341652992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvMZ_cgIIAAD2g-.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/G0lH8gWdAo"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/PhishatTheMann\/status\/500772595680440320\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/G0lH8gWdAo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvMaAsuIYAATkVK.jpg",
        "id_str" : "500772582875226112",
        "id" : 500772582875226112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvMaAsuIYAATkVK.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/G0lH8gWdAo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500772595680440320",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand killin it http:\/\/t.co\/G0lH8gWdAo",
    "id" : 500772595680440320,
    "created_at" : "2014-08-16 22:34:25 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "PhishatTheMann",
      "screen_name" : "PhishatTheMann",
      "protected" : false,
      "id_str" : "2202143780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551557188356177920\/RtgTM28x_normal.jpeg",
      "id" : 2202143780,
      "verified" : false
    }
  },
  "id" : 500774391417167874,
  "created_at" : "2014-08-16 22:41:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4532223313, -80.0047835198 ]
  },
  "id_str" : "500750839896875010",
  "text" : "One thing I learned at #scrc14: everyone has cooler socks than me.",
  "id" : 500750839896875010,
  "created_at" : "2014-08-16 21:07:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/PbeiCkAlzW",
      "expanded_url" : "http:\/\/www.reactiongifs.com\/r\/nope_girl.gif",
      "display_url" : "reactiongifs.com\/r\/nope_girl.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4532310383, -80.0047325366 ]
  },
  "id_str" : "500663268269391874",
  "text" : "TL;DR of RubyGems\/Bundler require internals http:\/\/t.co\/PbeiCkAlzW #scrc14",
  "id" : 500663268269391874,
  "created_at" : "2014-08-16 15:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/9VtIZctoUM",
      "expanded_url" : "http:\/\/rubygems.org\/search?utf8=%E2%9C%93&query=Hola",
      "display_url" : "rubygems.org\/search?utf8=%E\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "500659882547486720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4531852244, -80.0047869837 ]
  },
  "id_str" : "500660229391257601",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors http:\/\/t.co\/9VtIZctoUM",
  "id" : 500660229391257601,
  "in_reply_to_status_id" : 500659882547486720,
  "created_at" : "2014-08-16 15:07:55 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/500656607349735424\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/qHheqksMEz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BvKwhwvCIAA_Pv6.png",
      "id_str" : "500656602655891456",
      "id" : 500656602655891456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BvKwhwvCIAA_Pv6.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/qHheqksMEz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/OyZQIuj5Dr",
      "expanded_url" : "https:\/\/speakerdeck.com\/qrush\/how-to-find-gifs",
      "display_url" : "speakerdeck.com\/qrush\/how-to-f\u2026"
    }, {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/oDVz0nMzSC",
      "expanded_url" : "http:\/\/i.imgur.com\/Bt3qlPZ.gif",
      "display_url" : "i.imgur.com\/Bt3qlPZ.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "500656607349735424",
  "text" : "Here's my slides and some GIFs from yesterday's talk. https:\/\/t.co\/OyZQIuj5Dr http:\/\/t.co\/oDVz0nMzSC http:\/\/t.co\/qHheqksMEz",
  "id" : 500656607349735424,
  "created_at" : "2014-08-16 14:53:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/Ntp2B757Yu",
      "expanded_url" : "http:\/\/i.imgur.com\/VAfLNHd.gif",
      "display_url" : "i.imgur.com\/VAfLNHd.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "500654888670748672",
  "text" : "Current status: http:\/\/t.co\/Ntp2B757Yu",
  "id" : 500654888670748672,
  "created_at" : "2014-08-16 14:46:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/vw1nUDgp6M",
      "expanded_url" : "https:\/\/flic.kr\/p\/otkkni",
      "display_url" : "flic.kr\/p\/otkkni"
    } ]
  },
  "geo" : { },
  "id_str" : "500645854940639232",
  "text" : "Yinz. https:\/\/t.co\/vw1nUDgp6M",
  "id" : 500645854940639232,
  "created_at" : "2014-08-16 14:10:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4546484725, -79.9949839767 ]
  },
  "id_str" : "500491319287238656",
  "text" : "Oregano tastes great on pizza!",
  "id" : 500491319287238656,
  "created_at" : "2014-08-16 03:56:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 3, 14 ],
      "id_str" : "10774712",
      "id" : 10774712
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/richdownie\/status\/500457475213389825\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/3oJM1IDqmN",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BvH7a3BIcAAzNpO.png",
      "id_str" : "500457472478703616",
      "id" : 500457472478703616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BvH7a3BIcAAzNpO.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/3oJM1IDqmN"
    } ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500467571565805568",
  "text" : "RT @richdownie: Day 1 #scrc14 http:\/\/t.co\/3oJM1IDqmN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/richdownie\/status\/500457475213389825\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/3oJM1IDqmN",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BvH7a3BIcAAzNpO.png",
        "id_str" : "500457472478703616",
        "id" : 500457472478703616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BvH7a3BIcAAzNpO.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/3oJM1IDqmN"
      } ],
      "hashtags" : [ {
        "text" : "scrc14",
        "indices" : [ 6, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500457475213389825",
    "text" : "Day 1 #scrc14 http:\/\/t.co\/3oJM1IDqmN",
    "id" : 500457475213389825,
    "created_at" : "2014-08-16 01:42:14 +0000",
    "user" : {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "protected" : false,
      "id_str" : "10774712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558639851176603649\/3qXKrGpA_normal.jpeg",
      "id" : 10774712,
      "verified" : false
    }
  },
  "id" : 500467571565805568,
  "created_at" : "2014-08-16 02:22:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500388326659342336",
  "text" : "RT @aquaranto: Awesome observation of the day for #scrc14, in a room full of tech people, only a couple of computers open.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scrc14",
        "indices" : [ 35, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500383400734494720",
    "text" : "Awesome observation of the day for #scrc14, in a room full of tech people, only a couple of computers open.",
    "id" : 500383400734494720,
    "created_at" : "2014-08-15 20:47:54 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 500388326659342336,
  "created_at" : "2014-08-15 21:07:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 58, 73 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/VUSYR030ia",
      "expanded_url" : "http:\/\/www.nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "500362553525284865",
  "text" : "RT @aquaranto: Hey #scrc14 I hope everyone can make it to @nickelcityruby in Buffalo, October 3rd and 4th! http:\/\/t.co\/VUSYR030ia see you t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 43, 58 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scrc14",
        "indices" : [ 4, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/VUSYR030ia",
        "expanded_url" : "http:\/\/www.nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "500354207539806208",
    "text" : "Hey #scrc14 I hope everyone can make it to @nickelcityruby in Buffalo, October 3rd and 4th! http:\/\/t.co\/VUSYR030ia see you there!!",
    "id" : 500354207539806208,
    "created_at" : "2014-08-15 18:51:53 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 500362553525284865,
  "created_at" : "2014-08-15 19:25:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/skzrNLnUVC",
      "expanded_url" : "http:\/\/content9.flixster.com\/question\/54\/68\/67\/5468675_std.jpg",
      "display_url" : "content9.flixster.com\/question\/54\/68\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "500359247683915776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4532353144, -80.0047357629 ]
  },
  "id_str" : "500362035985936385",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair I\u2019ve just sucked one year of your life away. Tell me\u2026how do you feel? http:\/\/t.co\/skzrNLnUVC",
  "id" : 500362035985936385,
  "in_reply_to_status_id" : 500359247683915776,
  "created_at" : "2014-08-15 19:23:00 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500349085639901185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4532735569, -80.0047163553 ]
  },
  "id_str" : "500358587861204992",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick yeah, there\u2019s a few like this now",
  "id" : 500358587861204992,
  "in_reply_to_status_id" : 500349085639901185,
  "created_at" : "2014-08-15 19:09:18 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500342765008334850",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4532429849, -80.0047317377 ]
  },
  "id_str" : "500348486282674176",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick yes. I want to try out snapshot testing.",
  "id" : 500348486282674176,
  "in_reply_to_status_id" : 500342765008334850,
  "created_at" : "2014-08-15 18:29:09 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ERIC",
      "screen_name" : "OCPpittsburgh",
      "indices" : [ 25, 39 ],
      "id_str" : "2181106653",
      "id" : 2181106653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/kmG3viZd9Y",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53ee3660498ed6f08c7b740d?s=8KnnvP2X8qoFnVzCKplR-O_GHtc&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4537642544, -79.9804258347 ]
  },
  "id_str" : "500319406363529217",
  "text" : "I'm at Ohio City Pasta - @ocppittsburgh in Pittsburgh, PA https:\/\/t.co\/kmG3viZd9Y",
  "id" : 500319406363529217,
  "created_at" : "2014-08-15 16:33:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Hazlett Theater",
      "screen_name" : "newhazlett",
      "indices" : [ 23, 34 ],
      "id_str" : "20180512",
      "id" : 20180512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 5, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/AdfmZUwEbJ",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53ee12e1498e07dfd526df23?s=zvIkMlUh0P5-yM4Z_iIqs44aLTM&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.452860532, -80.0047859115 ]
  },
  "id_str" : "500281291439611905",
  "text" : "it's #scrc14 time! (at @NewHazlett Theater in Pittsburgh, PA) https:\/\/t.co\/AdfmZUwEbJ",
  "id" : 500281291439611905,
  "created_at" : "2014-08-15 14:02:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/9nOrIhsnc2",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53ed86b4498e04fd3e42fff1?s=nJVjfQp6rN_XB9Cq4MllNdJNNdM&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4478451727, -80.0041365623 ]
  },
  "id_str" : "500130781554298882",
  "text" : "I'm at The Beer Market in Pittsburgh, PA https:\/\/t.co\/9nOrIhsnc2",
  "id" : 500130781554298882,
  "created_at" : "2014-08-15 04:04:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500116410413359104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4519878524, -79.9828765958 ]
  },
  "id_str" : "500116925415165954",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik ~48 HOURS REMAIN~",
  "id" : 500116925415165954,
  "in_reply_to_status_id" : 500116410413359104,
  "created_at" : "2014-08-15 03:09:01 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BeerHive",
      "screen_name" : "TheBeerHive",
      "indices" : [ 7, 19 ],
      "id_str" : "274789187",
      "id" : 274789187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/KgJmb78H5R",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53ed6a51498e334badf591bf?s=vTCfSJ4lpchATWDTlUAjwFl1jKo&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.452113, -79.982671 ]
  },
  "id_str" : "500100298699177985",
  "text" : "I'm at @TheBeerHive in Pittsburgh, PA https:\/\/t.co\/KgJmb78H5R",
  "id" : 500100298699177985,
  "created_at" : "2014-08-15 02:02:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 3, 9 ],
      "id_str" : "15265916",
      "id" : 15265916
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 53, 68 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500083784231174145",
  "text" : "RT @dabit: Just finalized my travel arrangements for @nickelcityruby. Will I meet you there?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 42, 57 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500073717607964673",
    "text" : "Just finalized my travel arrangements for @nickelcityruby. Will I meet you there?",
    "id" : 500073717607964673,
    "created_at" : "2014-08-15 00:17:19 +0000",
    "user" : {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "protected" : false,
      "id_str" : "15265916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561348487561117696\/q38sJ7kb_normal.jpeg",
      "id" : 15265916,
      "verified" : false
    }
  },
  "id" : 500083784231174145,
  "created_at" : "2014-08-15 00:57:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500072789236539392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4547018514, -79.9948472122 ]
  },
  "id_str" : "500074025734119425",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz funny because we are in Germantown",
  "id" : 500074025734119425,
  "in_reply_to_status_id" : 500072789236539392,
  "created_at" : "2014-08-15 00:18:33 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/500067177299718144\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/OkT219Dhyj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvCYcamCYAE7279.jpg",
      "id_str" : "500067172580745217",
      "id" : 500067172580745217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvCYcamCYAE7279.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OkT219Dhyj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4550193297, -79.9950245955 ]
  },
  "id_str" : "500067177299718144",
  "text" : "Hi PGH! http:\/\/t.co\/OkT219Dhyj",
  "id" : 500067177299718144,
  "created_at" : "2014-08-14 23:51:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 119, 133 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924371541, -78.8793330251 ]
  },
  "id_str" : "499967326276435969",
  "text" : "Settlers, Agricola, Origin, Boss Monster, Dixit, Castle Panic, king of Tokyo, Castles of Burgundy, Smallworld. Enough? @SteelCityRuby",
  "id" : 499967326276435969,
  "created_at" : "2014-08-14 17:14:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/VD4MirluOi",
      "expanded_url" : "http:\/\/www.clickhole.com\/blogpost\/time-i-spent-commercial-whaling-ship-totally-chang-768",
      "display_url" : "clickhole.com\/blogpost\/time-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499956877367599104",
  "text" : "\"The Time I Spent On A Commercial Whaling Ship Totally Changed My Perspective On The World\" http:\/\/t.co\/VD4MirluOi",
  "id" : 499956877367599104,
  "created_at" : "2014-08-14 16:33:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 14, 27 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/DnDmSmPmJX",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/president-obama-makes-statement-22",
      "display_url" : "whitehouse.gov\/live\/president\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "499947596123615233",
  "geo" : { },
  "id_str" : "499948323097169920",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @steveklabnik also http:\/\/t.co\/DnDmSmPmJX",
  "id" : 499948323097169920,
  "in_reply_to_status_id" : 499947596123615233,
  "created_at" : "2014-08-14 15:59:03 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/A0XIpzayqQ",
      "expanded_url" : "http:\/\/gitready.com\/advanced\/2009\/02\/11\/pull-with-rebase.html",
      "display_url" : "gitready.com\/advanced\/2009\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "499931540185677824",
  "geo" : { },
  "id_str" : "499933296315219968",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan bingo. if you pull --rebase it's smoother too. http:\/\/t.co\/A0XIpzayqQ",
  "id" : 499933296315219968,
  "in_reply_to_status_id" : 499931540185677824,
  "created_at" : "2014-08-14 14:59:20 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 0, 14 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499929239773536256",
  "geo" : { },
  "id_str" : "499929360678129664",
  "in_reply_to_user_id" : 45490102,
  "text" : "@markpoloncarz Insane. Not a stat to be proud of.",
  "id" : 499929360678129664,
  "in_reply_to_status_id" : 499929239773536256,
  "created_at" : "2014-08-14 14:43:42 +0000",
  "in_reply_to_screen_name" : "markpoloncarz",
  "in_reply_to_user_id_str" : "45490102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499914846654451713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9389895671, -78.8825443548 ]
  },
  "id_str" : "499919234034843648",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan just commit or stash before pulling. The reflog won\u2019t ever lose what you did.",
  "id" : 499919234034843648,
  "in_reply_to_status_id" : 499914846654451713,
  "created_at" : "2014-08-14 14:03:28 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JorDan\u00E9e Key",
      "screen_name" : "JorDaneeKey",
      "indices" : [ 0, 12 ],
      "id_str" : "258063176",
      "id" : 258063176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499906447501979648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242632775, -78.8790625223 ]
  },
  "id_str" : "499909818824417280",
  "in_reply_to_user_id" : 258063176,
  "text" : "@JorDaneeKey both",
  "id" : 499909818824417280,
  "in_reply_to_status_id" : 499906447501979648,
  "created_at" : "2014-08-14 13:26:03 +0000",
  "in_reply_to_screen_name" : "JorDaneeKey",
  "in_reply_to_user_id_str" : "258063176",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499898586671218689",
  "text" : "RT @bquarant: @qrush vs. med school notes: \"why are they using comic sans?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499898435055931392",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush vs. med school notes: \"why are they using comic sans?\"",
    "id" : 499898435055931392,
    "created_at" : "2014-08-14 12:40:49 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 499898586671218689,
  "created_at" : "2014-08-14 12:41:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harper",
      "screen_name" : "harper",
      "indices" : [ 3, 10 ],
      "id_str" : "1497",
      "id" : 1497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499752400115077120",
  "text" : "RT @harper: Coming to a town near you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 41.903495011, -87.6638318227 ]
    },
    "id_str" : "499751524986540033",
    "text" : "Coming to a town near you!",
    "id" : 499751524986540033,
    "created_at" : "2014-08-14 02:57:03 +0000",
    "user" : {
      "name" : "harper",
      "screen_name" : "harper",
      "protected" : false,
      "id_str" : "1497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550153119208726529\/ZZqJSFpi_normal.jpeg",
      "id" : 1497,
      "verified" : true
    }
  },
  "id" : 499752400115077120,
  "created_at" : "2014-08-14 03:00:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " P. Mimi Poinsett MD",
      "screen_name" : "yayayarndiva",
      "indices" : [ 0, 13 ],
      "id_str" : "27818124",
      "id" : 27818124
    }, {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 14, 27 ],
      "id_str" : "6742522",
      "id" : 6742522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499733113056923648",
  "geo" : { },
  "id_str" : "499734682322214916",
  "in_reply_to_user_id" : 27818124,
  "text" : "@yayayarndiva @hypatiadotca this shattered me when I found out the town I grew up in was one.",
  "id" : 499734682322214916,
  "in_reply_to_status_id" : 499733113056923648,
  "created_at" : "2014-08-14 01:50:07 +0000",
  "in_reply_to_screen_name" : "yayayarndiva",
  "in_reply_to_user_id_str" : "27818124",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 3, 16 ],
      "id_str" : "35163668",
      "id" : 35163668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499716630767624192",
  "text" : "RT @pookleblinky: The US may be a police state, but at least the healthcare is, damn, wait a second, no, the education system is, hm, aha n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499715363635200000",
    "text" : "The US may be a police state, but at least the healthcare is, damn, wait a second, no, the education system is, hm, aha no wait hmmmm",
    "id" : 499715363635200000,
    "created_at" : "2014-08-14 00:33:21 +0000",
    "user" : {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "protected" : false,
      "id_str" : "35163668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511563470471720961\/rJz8jTRS_normal.png",
      "id" : 35163668,
      "verified" : false
    }
  },
  "id" : 499716630767624192,
  "created_at" : "2014-08-14 00:38:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Jean Lange",
      "screen_name" : "jean_lange",
      "indices" : [ 15, 26 ],
      "id_str" : "538455311",
      "id" : 538455311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499710964309426176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9234073706, -78.8794557886 ]
  },
  "id_str" : "499711474747457536",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @jean_lange HI JEAN",
  "id" : 499711474747457536,
  "in_reply_to_status_id" : 499710964309426176,
  "created_at" : "2014-08-14 00:17:54 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Amazing Maps ",
      "screen_name" : "Amazing_Maps",
      "indices" : [ 3, 16 ],
      "id_str" : "1571270053",
      "id" : 1571270053
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Amazing_Maps\/status\/491695311304527873\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/djWcO2xfxF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtLaR7WIEAEo12g.png",
      "id_str" : "491695310859931649",
      "id" : 491695310859931649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtLaR7WIEAEo12g.png",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/djWcO2xfxF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/uo2v6AKbMF",
      "expanded_url" : "http:\/\/www.businessinsider.com\/half-of-the-united-states-lives-in-these-counties-2013-9",
      "display_url" : "businessinsider.com\/half-of-the-un\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499627285222543361",
  "text" : "RT @Amazing_Maps: Half the population of the US lives in these counties\n\nSource: http:\/\/t.co\/uo2v6AKbMF\n- http:\/\/t.co\/djWcO2xfxF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Amazing_Maps\/status\/491695311304527873\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/djWcO2xfxF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtLaR7WIEAEo12g.png",
        "id_str" : "491695310859931649",
        "id" : 491695310859931649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtLaR7WIEAEo12g.png",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/djWcO2xfxF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/uo2v6AKbMF",
        "expanded_url" : "http:\/\/www.businessinsider.com\/half-of-the-united-states-lives-in-these-counties-2013-9",
        "display_url" : "businessinsider.com\/half-of-the-un\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "491695311304527873",
    "text" : "Half the population of the US lives in these counties\n\nSource: http:\/\/t.co\/uo2v6AKbMF\n- http:\/\/t.co\/djWcO2xfxF",
    "id" : 491695311304527873,
    "created_at" : "2014-07-22 21:24:32 +0000",
    "user" : {
      "name" : " Amazing Maps ",
      "screen_name" : "Amazing_Maps",
      "protected" : false,
      "id_str" : "1571270053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514370076816850944\/gvXYbbZO_normal.jpeg",
      "id" : 1571270053,
      "verified" : false
    }
  },
  "id" : 499627285222543361,
  "created_at" : "2014-08-13 18:43:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 34, 46 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Peach Music Festival",
      "screen_name" : "PeachMusicFest",
      "indices" : [ 56, 71 ],
      "id_str" : "510950211",
      "id" : 510950211
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/499597827660869632\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BqosJgjqdD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu7tk5BCcAMHemW.jpg",
      "id_str" : "499597826720952323",
      "id" : 499597826720952323,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu7tk5BCcAMHemW.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/BqosJgjqdD"
    } ],
    "hashtags" : [ {
      "text" : "seeyouatthepeach",
      "indices" : [ 103, 120 ]
    }, {
      "text" : "AQband",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499598130741280769",
  "text" : "RT @UnclePhilsBlog: THIS WEEKEND! @AqueousBand hits the @PeachMusicFest and never will it be the same. #seeyouatthepeach #AQband http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 14, 26 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "Peach Music Festival",
        "screen_name" : "PeachMusicFest",
        "indices" : [ 36, 51 ],
        "id_str" : "510950211",
        "id" : 510950211
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/499597827660869632\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/BqosJgjqdD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu7tk5BCcAMHemW.jpg",
        "id_str" : "499597826720952323",
        "id" : 499597826720952323,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu7tk5BCcAMHemW.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/BqosJgjqdD"
      } ],
      "hashtags" : [ {
        "text" : "seeyouatthepeach",
        "indices" : [ 83, 100 ]
      }, {
        "text" : "AQband",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499597827660869632",
    "text" : "THIS WEEKEND! @AqueousBand hits the @PeachMusicFest and never will it be the same. #seeyouatthepeach #AQband http:\/\/t.co\/BqosJgjqdD",
    "id" : 499597827660869632,
    "created_at" : "2014-08-13 16:46:18 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 499598130741280769,
  "created_at" : "2014-08-13 16:47:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blithe Rocher",
      "screen_name" : "Blithe",
      "indices" : [ 0, 7 ],
      "id_str" : "6304322",
      "id" : 6304322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499559946342498304",
  "geo" : { },
  "id_str" : "499566255959838720",
  "in_reply_to_user_id" : 6304322,
  "text" : "@Blithe woot!",
  "id" : 499566255959838720,
  "in_reply_to_status_id" : 499559946342498304,
  "created_at" : "2014-08-13 14:40:51 +0000",
  "in_reply_to_screen_name" : "Blithe",
  "in_reply_to_user_id_str" : "6304322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499558350557032449",
  "geo" : { },
  "id_str" : "499559286674976768",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss yes, because it's precisely not those things?",
  "id" : 499559286674976768,
  "in_reply_to_status_id" : 499558350557032449,
  "created_at" : "2014-08-13 14:13:09 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Gunner",
      "screen_name" : "nicholas_gunner",
      "indices" : [ 3, 19 ],
      "id_str" : "346542491",
      "id" : 346542491
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 35, 49 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/r0kYhK8RpU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=v5Lmkm5EF5E",
      "display_url" : "youtube.com\/watch?v=v5Lmkm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499549906910994433",
  "text" : "RT @nicholas_gunner: I'll be using @coworkbuffalo soon because their homepage demonstrates outstanding taste in youtube - https:\/\/t.co\/r0kY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 14, 28 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/r0kYhK8RpU",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=v5Lmkm5EF5E",
        "display_url" : "youtube.com\/watch?v=v5Lmkm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "498921115407101952",
    "text" : "I'll be using @coworkbuffalo soon because their homepage demonstrates outstanding taste in youtube - https:\/\/t.co\/r0kYhK8RpU",
    "id" : 498921115407101952,
    "created_at" : "2014-08-11 19:57:18 +0000",
    "user" : {
      "name" : "Nicholas Gunner",
      "screen_name" : "nicholas_gunner",
      "protected" : false,
      "id_str" : "346542491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502862083411939328\/44tDPWjL_normal.jpeg",
      "id" : 346542491,
      "verified" : false
    }
  },
  "id" : 499549906910994433,
  "created_at" : "2014-08-13 13:35:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Gaebel \u272D",
      "screen_name" : "gryghostvisuals",
      "indices" : [ 0, 16 ],
      "id_str" : "218159376",
      "id" : 218159376
    }, {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 17, 26 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499516267007856640",
  "geo" : { },
  "id_str" : "499549835985313793",
  "in_reply_to_user_id" : 218159376,
  "text" : "@gryghostvisuals @sabiddle we don't charge for members.",
  "id" : 499549835985313793,
  "in_reply_to_status_id" : 499516267007856640,
  "created_at" : "2014-08-13 13:35:36 +0000",
  "in_reply_to_screen_name" : "gryghostvisuals",
  "in_reply_to_user_id_str" : "218159376",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 12, 26 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499549293259149312",
  "text" : "Leaving for @SteelCityRuby tomorrow. Who's going to be there?",
  "id" : 499549293259149312,
  "created_at" : "2014-08-13 13:33:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499532788454789120",
  "geo" : { },
  "id_str" : "499548245391982592",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines welcome to the world of fussy coffee",
  "id" : 499548245391982592,
  "in_reply_to_status_id" : 499532788454789120,
  "created_at" : "2014-08-13 13:29:17 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499407795880349696",
  "text" : "Found out how to get infinite rides in Crazy Taxi: City Ride. Set your device\u2019s time to a day ahead, launch game, return time to auto.",
  "id" : 499407795880349696,
  "created_at" : "2014-08-13 04:11:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristina Halvorson",
      "screen_name" : "halvorson",
      "indices" : [ 3, 13 ],
      "id_str" : "14335160",
      "id" : 14335160
    }, {
      "name" : "Amanda Costello",
      "screen_name" : "amandaesque",
      "indices" : [ 118, 130 ],
      "id_str" : "15064617",
      "id" : 15064617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aE9xQfxJSU",
      "expanded_url" : "http:\/\/youtu.be\/cKaOpnfjs3c",
      "display_url" : "youtu.be\/cKaOpnfjs3c"
    } ]
  },
  "geo" : { },
  "id_str" : "499402980169228288",
  "text" : "RT @halvorson: I cannot stress how important this is for you to watch. MN dude wants to sell his crazy-ass house, via @amandaesque: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Costello",
        "screen_name" : "amandaesque",
        "indices" : [ 103, 115 ],
        "id_str" : "15064617",
        "id" : 15064617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/aE9xQfxJSU",
        "expanded_url" : "http:\/\/youtu.be\/cKaOpnfjs3c",
        "display_url" : "youtu.be\/cKaOpnfjs3c"
      } ]
    },
    "geo" : { },
    "id_str" : "499398829738053632",
    "text" : "I cannot stress how important this is for you to watch. MN dude wants to sell his crazy-ass house, via @amandaesque: http:\/\/t.co\/aE9xQfxJSU",
    "id" : 499398829738053632,
    "created_at" : "2014-08-13 03:35:34 +0000",
    "user" : {
      "name" : "Kristina Halvorson",
      "screen_name" : "halvorson",
      "protected" : false,
      "id_str" : "14335160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554377526860976128\/_CYBcpTq_normal.jpeg",
      "id" : 14335160,
      "verified" : false
    }
  },
  "id" : 499402980169228288,
  "created_at" : "2014-08-13 03:52:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/qLZVKeZHGN",
      "expanded_url" : "http:\/\/gifsound.com\/?gif=d3dsacqprgcsqh.cloudfront.net\/photo\/a3YOv2N_460sa.gif&v=Mw4O9pN-a1g",
      "display_url" : "gifsound.com\/?gif=d3dsacqpr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499386806291296256",
  "text" : "Going through my gifs, and had to: http:\/\/t.co\/qLZVKeZHGN",
  "id" : 499386806291296256,
  "created_at" : "2014-08-13 02:47:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/499377616411824128\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/bgCbgvjIN2",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Bu4lSv1CAAEjn6c.png",
      "id_str" : "499377612691472385",
      "id" : 499377612691472385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Bu4lSv1CAAEjn6c.png",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bgCbgvjIN2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499377404490813440",
  "geo" : { },
  "id_str" : "499377616411824128",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik http:\/\/t.co\/bgCbgvjIN2",
  "id" : 499377616411824128,
  "in_reply_to_status_id" : 499377404490813440,
  "created_at" : "2014-08-13 02:11:16 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499376695174901760",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik are you going to SCRC, and should I bring a massive amount of board games?",
  "id" : 499376695174901760,
  "created_at" : "2014-08-13 02:07:36 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/k6m76KVk5f",
      "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/show-me-the-books-poloncarz-tells-nfl-on-stadium-demand-20140812",
      "display_url" : "buffalonews.com\/city-region\/sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499360666096893952",
  "text" : "RT @markpoloncarz: I\u2019m not going to cut libraries, parks, or child protective services to give more money to the multibillionaires http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/k6m76KVk5f",
        "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/show-me-the-books-poloncarz-tells-nfl-on-stadium-demand-20140812",
        "display_url" : "buffalonews.com\/city-region\/sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "499360541744562176",
    "text" : "I\u2019m not going to cut libraries, parks, or child protective services to give more money to the multibillionaires http:\/\/t.co\/k6m76KVk5f",
    "id" : 499360541744562176,
    "created_at" : "2014-08-13 01:03:25 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 499360666096893952,
  "created_at" : "2014-08-13 01:03:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "indices" : [ 3, 19 ],
      "id_str" : "16450873",
      "id" : 16450873
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 66, 81 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/FC93Z5tsTs",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "499357990709780481",
  "text" : "RT @infotechniagara: This year will be even better  - October 2-4 @nickelcityruby http:\/\/t.co\/FC93Z5tsTs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 45, 60 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/FC93Z5tsTs",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "499251436505792512",
    "text" : "This year will be even better  - October 2-4 @nickelcityruby http:\/\/t.co\/FC93Z5tsTs",
    "id" : 499251436505792512,
    "created_at" : "2014-08-12 17:49:52 +0000",
    "user" : {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "protected" : false,
      "id_str" : "16450873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64732059\/itn_logo_normal.jpg",
      "id" : 16450873,
      "verified" : false
    }
  },
  "id" : 499357990709780481,
  "created_at" : "2014-08-13 00:53:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Radcliff",
      "screen_name" : "scottradcliff",
      "indices" : [ 3, 17 ],
      "id_str" : "15789234",
      "id" : 15789234
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 28, 43 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499357963639746560",
  "text" : "RT @scottradcliff: Thinking @nickelcityruby looks pretty nice this year. Any Toledo area people headed that way.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 9, 24 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499223602211094528",
    "text" : "Thinking @nickelcityruby looks pretty nice this year. Any Toledo area people headed that way.",
    "id" : 499223602211094528,
    "created_at" : "2014-08-12 15:59:16 +0000",
    "user" : {
      "name" : "Scott Radcliff",
      "screen_name" : "scottradcliff",
      "protected" : false,
      "id_str" : "15789234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2276044147\/8zzal988v07sdi6eh14o_normal.jpeg",
      "id" : 15789234,
      "verified" : false
    }
  },
  "id" : 499357963639746560,
  "created_at" : "2014-08-13 00:53:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 3, 7 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 10, 16 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lrz\/status\/499356117298716672\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/R1iApMOArI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu4RvQCCAAAIlS_.jpg",
      "id_str" : "499356112139714560",
      "id" : 499356112139714560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu4RvQCCAAAIlS_.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/R1iApMOArI"
    } ],
    "hashtags" : [ {
      "text" : "yuengling",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499356606836903936",
  "text" : "RT @lrz: .@qrush here we go! #yuengling http:\/\/t.co\/R1iApMOArI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 1, 7 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lrz\/status\/499356117298716672\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/R1iApMOArI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu4RvQCCAAAIlS_.jpg",
        "id_str" : "499356112139714560",
        "id" : 499356112139714560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu4RvQCCAAAIlS_.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/R1iApMOArI"
      } ],
      "hashtags" : [ {
        "text" : "yuengling",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499356117298716672",
    "text" : ".@qrush here we go! #yuengling http:\/\/t.co\/R1iApMOArI",
    "id" : 499356117298716672,
    "created_at" : "2014-08-13 00:45:50 +0000",
    "user" : {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "protected" : false,
      "id_str" : "10452222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459499652228714497\/EiSPykkq_normal.png",
      "id" : 10452222,
      "verified" : false
    }
  },
  "id" : 499356606836903936,
  "created_at" : "2014-08-13 00:47:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "indices" : [ 3, 12 ],
      "id_str" : "10545",
      "id" : 10545
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/flyosity\/status\/499281905133826049\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/nvnglAA7dO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3OPujCEAADJjB.png",
      "id_str" : "499281903296319488",
      "id" : 499281903296319488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3OPujCEAADJjB.png",
      "sizes" : [ {
        "h" : 677,
        "resize" : "fit",
        "w" : 1022
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 1021
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nvnglAA7dO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499282684099588096",
  "text" : "RT @flyosity: America, 2014. http:\/\/t.co\/nvnglAA7dO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/flyosity\/status\/499281905133826049\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/nvnglAA7dO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3OPujCEAADJjB.png",
        "id_str" : "499281903296319488",
        "id" : 499281903296319488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3OPujCEAADJjB.png",
        "sizes" : [ {
          "h" : 677,
          "resize" : "fit",
          "w" : 1022
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 677,
          "resize" : "fit",
          "w" : 1021
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nvnglAA7dO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499281905133826049",
    "text" : "America, 2014. http:\/\/t.co\/nvnglAA7dO",
    "id" : 499281905133826049,
    "created_at" : "2014-08-12 19:50:57 +0000",
    "user" : {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "protected" : false,
      "id_str" : "10545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536904370613653504\/D8bnagC7_normal.jpeg",
      "id" : 10545,
      "verified" : false
    }
  },
  "id" : 499282684099588096,
  "created_at" : "2014-08-12 19:54:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/Lb4IeT6eXT",
      "expanded_url" : "http:\/\/www.comedyfoodsports.com\/wp-content\/uploads\/2013\/02\/waynesworld.jpg",
      "display_url" : "comedyfoodsports.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "499282091335380992",
  "geo" : { },
  "id_str" : "499282357086461952",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack Delaware? http:\/\/t.co\/Lb4IeT6eXT Sounds good.",
  "id" : 499282357086461952,
  "in_reply_to_status_id" : 499282091335380992,
  "created_at" : "2014-08-12 19:52:44 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    }, {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 12, 22 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499281073675579393",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker @alindeman it would be helpful for private repos to see *who* cloned (re: security)",
  "id" : 499281073675579393,
  "created_at" : "2014-08-12 19:47:38 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/W2tMFHDsSl",
      "expanded_url" : "https:\/\/squareup.com\/legal\/cash-ua",
      "display_url" : "squareup.com\/legal\/cash-ua"
    } ]
  },
  "in_reply_to_status_id_str" : "499266640169947136",
  "geo" : { },
  "id_str" : "499268365806878720",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit this is an awful idea. $2500 limit on a 7 day rolling basis. Nebulous for business use. https:\/\/t.co\/W2tMFHDsSl",
  "id" : 499268365806878720,
  "in_reply_to_status_id" : 499266640169947136,
  "created_at" : "2014-08-12 18:57:09 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 3, 17 ],
      "id_str" : "5543292",
      "id" : 5543292
    }, {
      "name" : "Larkin Square",
      "screen_name" : "larkinsquare",
      "indices" : [ 49, 62 ],
      "id_str" : "36047275",
      "id" : 36047275
    }, {
      "name" : "Canalside Buffalo",
      "screen_name" : "CanalsideBflo",
      "indices" : [ 143, 144 ],
      "id_str" : "54994502",
      "id" : 54994502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499244358466416640",
  "text" : "RT @edwardmichael: Am I the only one that thinks @larkinsquare needs Metro Rail to truly be woven into the fabric of #Buffalo &amp; not compete\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Larkin Square",
        "screen_name" : "larkinsquare",
        "indices" : [ 30, 43 ],
        "id_str" : "36047275",
        "id" : 36047275
      }, {
        "name" : "Canalside Buffalo",
        "screen_name" : "CanalsideBflo",
        "indices" : [ 128, 142 ],
        "id_str" : "54994502",
        "id" : 54994502
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499244181647548416",
    "text" : "Am I the only one that thinks @larkinsquare needs Metro Rail to truly be woven into the fabric of #Buffalo &amp; not compete w\/ @CanalsideBflo?",
    "id" : 499244181647548416,
    "created_at" : "2014-08-12 17:21:03 +0000",
    "user" : {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "protected" : false,
      "id_str" : "5543292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557388021344243712\/I0XrDV7N_normal.jpeg",
      "id" : 5543292,
      "verified" : false
    }
  },
  "id" : 499244358466416640,
  "created_at" : "2014-08-12 17:21:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499237938379907072",
  "geo" : { },
  "id_str" : "499243926104969217",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc There's a similar one on Asbury Hall\/Hallwalls on the Tupper side. Just a guess!",
  "id" : 499243926104969217,
  "in_reply_to_status_id" : 499237938379907072,
  "created_at" : "2014-08-12 17:20:02 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499241406280765440",
  "geo" : { },
  "id_str" : "499241928433487872",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns * Your call is important to us teases",
  "id" : 499241928433487872,
  "in_reply_to_status_id" : 499241406280765440,
  "created_at" : "2014-08-12 17:12:05 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499235153605296128",
  "geo" : { },
  "id_str" : "499235376746086400",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc looks like a ground wire for lightning strikes",
  "id" : 499235376746086400,
  "in_reply_to_status_id" : 499235153605296128,
  "created_at" : "2014-08-12 16:46:03 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 11, 19 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499227745319391233",
  "geo" : { },
  "id_str" : "499227957756301312",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack @noahhlo awesome. Headed any further north ?",
  "id" : 499227957756301312,
  "in_reply_to_status_id" : 499227745319391233,
  "created_at" : "2014-08-12 16:16:34 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Gee",
      "screen_name" : "DerekGeePhoto",
      "indices" : [ 3, 17 ],
      "id_str" : "1634451608",
      "id" : 1634451608
    }, {
      "name" : "Statler City",
      "screen_name" : "StatlerCity",
      "indices" : [ 83, 95 ],
      "id_str" : "382817306",
      "id" : 382817306
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DerekGeePhoto\/status\/499221025155215361\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/IyHSfdwW7v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu2W4JAIEAAXrlA.jpg",
      "id_str" : "499221024941281280",
      "id" : 499221024941281280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu2W4JAIEAAXrlA.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com\/IyHSfdwW7v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499221719098216448",
  "text" : "RT @DerekGeePhoto: A team of engineers begins inspecting the terra cotta facade at @StatlerCity for a $5.3M renovation of the exterior http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Statler City",
        "screen_name" : "StatlerCity",
        "indices" : [ 64, 76 ],
        "id_str" : "382817306",
        "id" : 382817306
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DerekGeePhoto\/status\/499221025155215361\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/IyHSfdwW7v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu2W4JAIEAAXrlA.jpg",
        "id_str" : "499221024941281280",
        "id" : 499221024941281280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu2W4JAIEAAXrlA.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 568
        } ],
        "display_url" : "pic.twitter.com\/IyHSfdwW7v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499221025155215361",
    "text" : "A team of engineers begins inspecting the terra cotta facade at @StatlerCity for a $5.3M renovation of the exterior http:\/\/t.co\/IyHSfdwW7v",
    "id" : 499221025155215361,
    "created_at" : "2014-08-12 15:49:02 +0000",
    "user" : {
      "name" : "Derek Gee",
      "screen_name" : "DerekGeePhoto",
      "protected" : false,
      "id_str" : "1634451608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000226582128\/ae10cebbc5d83d1014a8cfd45e3a0044_normal.jpeg",
      "id" : 1634451608,
      "verified" : false
    }
  },
  "id" : 499221719098216448,
  "created_at" : "2014-08-12 15:51:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Underwood",
      "screen_name" : "davefp",
      "indices" : [ 0, 7 ],
      "id_str" : "17146704",
      "id" : 17146704
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 8, 22 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499215184968183808",
  "geo" : { },
  "id_str" : "499218893605318656",
  "in_reply_to_user_id" : 17146704,
  "text" : "@davefp @SteelCityRuby I was just going to hold cards on my face the whole time",
  "id" : 499218893605318656,
  "in_reply_to_status_id" : 499215184968183808,
  "created_at" : "2014-08-12 15:40:33 +0000",
  "in_reply_to_screen_name" : "davefp",
  "in_reply_to_user_id_str" : "17146704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 36, 51 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodeRetreat",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KX8FYf5CFR",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "499211745278189569",
  "text" : "Just opened up our #CodeRetreat for @nickelcityruby 2014. Don't have a lot of space for this, so please sign up! http:\/\/t.co\/KX8FYf5CFR",
  "id" : 499211745278189569,
  "created_at" : "2014-08-12 15:12:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sundeep Gupta",
      "screen_name" : "guptron",
      "indices" : [ 3, 11 ],
      "id_str" : "456794930",
      "id" : 456794930
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 13, 28 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499204990129303552",
  "text" : "RT @guptron: @nickelcityruby Can't wait to attend this will be my first Ruby event!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 0, 15 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "491574292249735168",
    "geo" : { },
    "id_str" : "498996714330947584",
    "in_reply_to_user_id" : 1067596351,
    "text" : "@nickelcityruby Can't wait to attend this will be my first Ruby event!",
    "id" : 498996714330947584,
    "in_reply_to_status_id" : 491574292249735168,
    "created_at" : "2014-08-12 00:57:42 +0000",
    "in_reply_to_screen_name" : "nickelcityruby",
    "in_reply_to_user_id_str" : "1067596351",
    "user" : {
      "name" : "Sundeep Gupta",
      "screen_name" : "guptron",
      "protected" : false,
      "id_str" : "456794930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419991460348301312\/TLJd2LtF_normal.jpeg",
      "id" : 456794930,
      "verified" : false
    }
  },
  "id" : 499204990129303552,
  "created_at" : "2014-08-12 14:45:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 65, 79 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499204942553284608",
  "text" : "Back as a human for now. Also so I don't appear as a cartoon for @SteelCityRuby !",
  "id" : 499204942553284608,
  "created_at" : "2014-08-12 14:45:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 0, 10 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498922219872210944",
  "geo" : { },
  "id_str" : "499203825433980929",
  "in_reply_to_user_id" : 816041347,
  "text" : "@BreadHive in my breakfast, for days",
  "id" : 499203825433980929,
  "in_reply_to_status_id" : 498922219872210944,
  "created_at" : "2014-08-12 14:40:41 +0000",
  "in_reply_to_screen_name" : "BreadHive",
  "in_reply_to_user_id_str" : "816041347",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Hirtzel",
      "screen_name" : "AshleyHirtz",
      "indices" : [ 3, 15 ],
      "id_str" : "196353523",
      "id" : 196353523
    }, {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 108, 113 ],
      "id_str" : "20612109",
      "id" : 20612109
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grainelevator",
      "indices" : [ 42, 56 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/GE7C2YEejk",
      "expanded_url" : "http:\/\/bit.ly\/VinmCv",
      "display_url" : "bit.ly\/VinmCv"
    } ]
  },
  "geo" : { },
  "id_str" : "499192978959654912",
  "text" : "RT @AshleyHirtz: Construction to begin on #grainelevator light show in #Buffalo. http:\/\/t.co\/GE7C2YEejk via @WBFO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WBFO",
        "screen_name" : "WBFO",
        "indices" : [ 91, 96 ],
        "id_str" : "20612109",
        "id" : 20612109
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grainelevator",
        "indices" : [ 25, 39 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/GE7C2YEejk",
        "expanded_url" : "http:\/\/bit.ly\/VinmCv",
        "display_url" : "bit.ly\/VinmCv"
      } ]
    },
    "geo" : { },
    "id_str" : "499192540512260096",
    "text" : "Construction to begin on #grainelevator light show in #Buffalo. http:\/\/t.co\/GE7C2YEejk via @WBFO",
    "id" : 499192540512260096,
    "created_at" : "2014-08-12 13:55:50 +0000",
    "user" : {
      "name" : "Ashley Hirtzel",
      "screen_name" : "AshleyHirtz",
      "protected" : false,
      "id_str" : "196353523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505943178252668928\/4PEdsGj-_normal.jpeg",
      "id" : 196353523,
      "verified" : false
    }
  },
  "id" : 499192978959654912,
  "created_at" : "2014-08-12 13:57:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499175901230546944",
  "geo" : { },
  "id_str" : "499177064075780096",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz Have you tried Yuengling yet?",
  "id" : 499177064075780096,
  "in_reply_to_status_id" : 499175901230546944,
  "created_at" : "2014-08-12 12:54:20 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wint",
      "screen_name" : "dril",
      "indices" : [ 3, 8 ],
      "id_str" : "16298441",
      "id" : 16298441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499050956940537856",
  "text" : "RT @dril: i think police should get extensive background checks so that i can hire all fo the most insane, mentally ill cops as my personal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496072540482453504",
    "text" : "i think police should get extensive background checks so that i can hire all fo the most insane, mentally ill cops as my personal bodyguards",
    "id" : 496072540482453504,
    "created_at" : "2014-08-03 23:18:04 +0000",
    "user" : {
      "name" : "wint",
      "screen_name" : "dril",
      "protected" : false,
      "id_str" : "16298441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473173117263564800\/no2X3257_normal.jpeg",
      "id" : 16298441,
      "verified" : false
    }
  },
  "id" : 499050956940537856,
  "created_at" : "2014-08-12 04:33:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Swangin",
      "screen_name" : "CallMe_Rad",
      "indices" : [ 0, 11 ],
      "id_str" : "256591239",
      "id" : 256591239
    }, {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 12, 26 ],
      "id_str" : "184501661",
      "id" : 184501661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499046971286757377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241307241, -78.8799428094 ]
  },
  "id_str" : "499049296499445760",
  "in_reply_to_user_id" : 256591239,
  "text" : "@CallMe_Rad @MileHighMusik where\u2019s Lloyd?!",
  "id" : 499049296499445760,
  "in_reply_to_status_id" : 499046971286757377,
  "created_at" : "2014-08-12 04:26:38 +0000",
  "in_reply_to_screen_name" : "CallMe_Rad",
  "in_reply_to_user_id_str" : "256591239",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Wallace Booker",
      "screen_name" : "LuvLiteracy",
      "indices" : [ 3, 15 ],
      "id_str" : "1219315939",
      "id" : 1219315939
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LuvLiteracy\/status\/499043709905022976\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/FTIi3ZI6mq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Buz1mQeIcAAUFlV.jpg",
      "id_str" : "499043696336465920",
      "id" : 499043696336465920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Buz1mQeIcAAUFlV.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FTIi3ZI6mq"
    } ],
    "hashtags" : [ {
      "text" : "standtall",
      "indices" : [ 60, 70 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 71, 80 ]
    }, {
      "text" : "Enough",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499048596751147008",
  "text" : "RT @LuvLiteracy: A picture worth a thousand powerful words. #standtall #Ferguson #Enough http:\/\/t.co\/FTIi3ZI6mq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LuvLiteracy\/status\/499043709905022976\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/FTIi3ZI6mq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Buz1mQeIcAAUFlV.jpg",
        "id_str" : "499043696336465920",
        "id" : 499043696336465920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Buz1mQeIcAAUFlV.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FTIi3ZI6mq"
      } ],
      "hashtags" : [ {
        "text" : "standtall",
        "indices" : [ 43, 53 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 54, 63 ]
      }, {
        "text" : "Enough",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499043709905022976",
    "text" : "A picture worth a thousand powerful words. #standtall #Ferguson #Enough http:\/\/t.co\/FTIi3ZI6mq",
    "id" : 499043709905022976,
    "created_at" : "2014-08-12 04:04:26 +0000",
    "user" : {
      "name" : "Diane Wallace Booker",
      "screen_name" : "LuvLiteracy",
      "protected" : false,
      "id_str" : "1219315939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503372527218225152\/ojwxuaQI_normal.jpeg",
      "id" : 1219315939,
      "verified" : false
    }
  },
  "id" : 499048596751147008,
  "created_at" : "2014-08-12 04:23:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "indices" : [ 0, 10 ],
      "id_str" : "1649136702",
      "id" : 1649136702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499046377205559296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242234181, -78.879123842 ]
  },
  "id_str" : "499047004207456256",
  "in_reply_to_user_id" : 1649136702,
  "text" : "@phishmaps love the lyrics woven in!",
  "id" : 499047004207456256,
  "in_reply_to_status_id" : 499046377205559296,
  "created_at" : "2014-08-12 04:17:32 +0000",
  "in_reply_to_screen_name" : "phishmaps",
  "in_reply_to_user_id_str" : "1649136702",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 62, 72 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499010181171126274",
  "text" : "Watching The Birdcage tonight. Haven't seen the entire thing. @aquaranto has and picked it.",
  "id" : 499010181171126274,
  "created_at" : "2014-08-12 01:51:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/xOFzN9iMPA",
      "expanded_url" : "http:\/\/scrapetv.com\/News\/News%20Pages\/Science\/Images\/dune-sandworm.jpg",
      "display_url" : "scrapetv.com\/News\/News%20Pa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "498913726297546752",
  "geo" : { },
  "id_str" : "498914724516737024",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh http:\/\/t.co\/xOFzN9iMPA",
  "id" : 498914724516737024,
  "in_reply_to_status_id" : 498913726297546752,
  "created_at" : "2014-08-11 19:31:54 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "indices" : [ 3, 15 ],
      "id_str" : "21283898",
      "id" : 21283898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/uL4meUMFrX",
      "expanded_url" : "http:\/\/www.buffalonews.com\/sports\/bills-nfl\/nfl-renews-push-for-a-new-bills-stadium-20140811",
      "display_url" : "buffalonews.com\/sports\/bills-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498901080739418112",
  "text" : "RT @goosesroost: \"The fans really want this,\" insists Expensive Haircut before leaping naked into swimming pool full of gold Doubloons http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/uL4meUMFrX",
        "expanded_url" : "http:\/\/www.buffalonews.com\/sports\/bills-nfl\/nfl-renews-push-for-a-new-bills-stadium-20140811",
        "display_url" : "buffalonews.com\/sports\/bills-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "498900272920690688",
    "text" : "\"The fans really want this,\" insists Expensive Haircut before leaping naked into swimming pool full of gold Doubloons http:\/\/t.co\/uL4meUMFrX",
    "id" : 498900272920690688,
    "created_at" : "2014-08-11 18:34:28 +0000",
    "user" : {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "protected" : false,
      "id_str" : "21283898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568494566907457536\/uCpwEbcv_normal.jpeg",
      "id" : 21283898,
      "verified" : false
    }
  },
  "id" : 498901080739418112,
  "created_at" : "2014-08-11 18:37:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 98, 104 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/24x6t1FiI6",
      "expanded_url" : "http:\/\/fortune.com\/2014\/08\/11\/why-chris-sacca-isnt-buying-the-buffalo-bills\/",
      "display_url" : "fortune.com\/2014\/08\/11\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498900313534119936",
  "text" : "\u201CFuck Bon Jovi and his steel horse for even considering taking that team out of Buffalo.\u201D - Bravo @sacca ! http:\/\/t.co\/24x6t1FiI6",
  "id" : 498900313534119936,
  "created_at" : "2014-08-11 18:34:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Tyrrell",
      "screen_name" : "timtyrrell",
      "indices" : [ 0, 11 ],
      "id_str" : "15012484",
      "id" : 15012484
    }, {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 12, 21 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498888125930696704",
  "geo" : { },
  "id_str" : "498888901281714176",
  "in_reply_to_user_id" : 15012484,
  "text" : "@timtyrrell @schneems WHYME",
  "id" : 498888901281714176,
  "in_reply_to_status_id" : 498888125930696704,
  "created_at" : "2014-08-11 17:49:17 +0000",
  "in_reply_to_screen_name" : "timtyrrell",
  "in_reply_to_user_id_str" : "15012484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/avUzNG17BP",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Q-bZLFRjVCA",
      "display_url" : "youtube.com\/watch?v=Q-bZLF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498869616442347520",
  "text" : "Imagine the worst thing ever. Could it be Waluigi in the Water Temple? Yes, yes it is: https:\/\/t.co\/avUzNG17BP",
  "id" : 498869616442347520,
  "created_at" : "2014-08-11 16:32:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhanArt Pete",
      "screen_name" : "PhanArt",
      "indices" : [ 3, 11 ],
      "id_str" : "15940833",
      "id" : 15940833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Fy26yStk37",
      "expanded_url" : "http:\/\/instagram.com\/p\/rgUo-mRbrg\/",
      "display_url" : "instagram.com\/p\/rgUo-mRbrg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "498864696880275456",
  "text" : "RT @PhanArt: Matt Pickering from Mister F playing with Aqueous at Backwoods Pondfest http:\/\/t.co\/Fy26yStk37",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/Fy26yStk37",
        "expanded_url" : "http:\/\/instagram.com\/p\/rgUo-mRbrg\/",
        "display_url" : "instagram.com\/p\/rgUo-mRbrg\/"
      } ]
    },
    "geo" : { },
    "id_str" : "498331162415087616",
    "text" : "Matt Pickering from Mister F playing with Aqueous at Backwoods Pondfest http:\/\/t.co\/Fy26yStk37",
    "id" : 498331162415087616,
    "created_at" : "2014-08-10 04:53:02 +0000",
    "user" : {
      "name" : "PhanArt Pete",
      "screen_name" : "PhanArt",
      "protected" : false,
      "id_str" : "15940833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517908813471444992\/b6VXNJqO_normal.png",
      "id" : 15940833,
      "verified" : false
    }
  },
  "id" : 498864696880275456,
  "created_at" : "2014-08-11 16:13:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498855058658701312",
  "geo" : { },
  "id_str" : "498859373113126913",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave well, none of the APIs have changed so far. I think the next few years will tell as a Swift style emerges",
  "id" : 498859373113126913,
  "in_reply_to_status_id" : 498855058658701312,
  "created_at" : "2014-08-11 15:51:57 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fatachrestic",
      "screen_name" : "fatachrestic",
      "indices" : [ 0, 13 ],
      "id_str" : "2850993548",
      "id" : 2850993548
    }, {
      "name" : "Ray Brown",
      "screen_name" : "bitmanic",
      "indices" : [ 14, 23 ],
      "id_str" : "17897760",
      "id" : 17897760
    }, {
      "name" : "de-reference pointer",
      "screen_name" : "silentbicycle",
      "indices" : [ 24, 38 ],
      "id_str" : "26786635",
      "id" : 26786635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498853148555890689",
  "geo" : { },
  "id_str" : "498854070623698945",
  "in_reply_to_user_id" : 165453873,
  "text" : "@fatachrestic @bitmanic @silentbicycle Truth, have had bikes stolen off my porch here in Buffalo. I despise the accessory hate though.",
  "id" : 498854070623698945,
  "in_reply_to_status_id" : 498853148555890689,
  "created_at" : "2014-08-11 15:30:53 +0000",
  "in_reply_to_screen_name" : "fatneckbeardguy",
  "in_reply_to_user_id_str" : "165453873",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fatachrestic",
      "screen_name" : "fatachrestic",
      "indices" : [ 0, 13 ],
      "id_str" : "2850993548",
      "id" : 2850993548
    }, {
      "name" : "Ray Brown",
      "screen_name" : "bitmanic",
      "indices" : [ 14, 23 ],
      "id_str" : "17897760",
      "id" : 17897760
    }, {
      "name" : "de-reference pointer",
      "screen_name" : "silentbicycle",
      "indices" : [ 24, 38 ],
      "id_str" : "26786635",
      "id" : 26786635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498852228908597250",
  "geo" : { },
  "id_str" : "498852526020894720",
  "in_reply_to_user_id" : 165453873,
  "text" : "@fatachrestic @bitmanic @silentbicycle no kickstand forces you to lock it up and not leave it somewhere.",
  "id" : 498852526020894720,
  "in_reply_to_status_id" : 498852228908597250,
  "created_at" : "2014-08-11 15:24:45 +0000",
  "in_reply_to_screen_name" : "fatneckbeardguy",
  "in_reply_to_user_id_str" : "165453873",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 3, 18 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498849070547734528",
  "text" : "RT @ChristineLSloc: Renewed request for Buffalo-area open datasets (or even the closed ones). I just want to know what exists so I can aggr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "498848582821507072",
    "text" : "Renewed request for Buffalo-area open datasets (or even the closed ones). I just want to know what exists so I can aggregate it in one place",
    "id" : 498848582821507072,
    "created_at" : "2014-08-11 15:09:04 +0000",
    "user" : {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "protected" : false,
      "id_str" : "73221502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569953927438024704\/y_kM5xtD_normal.jpeg",
      "id" : 73221502,
      "verified" : false
    }
  },
  "id" : 498849070547734528,
  "created_at" : "2014-08-11 15:11:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498844990223945728",
  "geo" : { },
  "id_str" : "498845094427234304",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl I'll assume Bitcoins mined\/hour then.",
  "id" : 498845094427234304,
  "in_reply_to_status_id" : 498844990223945728,
  "created_at" : "2014-08-11 14:55:13 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498844004755460096",
  "geo" : { },
  "id_str" : "498844741904379904",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl what is that measuring?",
  "id" : 498844741904379904,
  "in_reply_to_status_id" : 498844004755460096,
  "created_at" : "2014-08-11 14:53:49 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Holovaty",
      "screen_name" : "adrianholovaty",
      "indices" : [ 3, 18 ],
      "id_str" : "1392281",
      "id" : 1392281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Fu5Zmk7GuT",
      "expanded_url" : "http:\/\/research.microsoft.com\/en-us\/um\/redmond\/projects\/hyperlapse\/",
      "display_url" : "research.microsoft.com\/en-us\/um\/redmo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498675282727804928",
  "text" : "RT @adrianholovaty: This new \"hyperlapse\" video technology is amazing. Get ready to see this ad nauseam in music videos and TV shows. :-) h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Fu5Zmk7GuT",
        "expanded_url" : "http:\/\/research.microsoft.com\/en-us\/um\/redmond\/projects\/hyperlapse\/",
        "display_url" : "research.microsoft.com\/en-us\/um\/redmo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "498668518171086851",
    "text" : "This new \"hyperlapse\" video technology is amazing. Get ready to see this ad nauseam in music videos and TV shows. :-) http:\/\/t.co\/Fu5Zmk7GuT",
    "id" : 498668518171086851,
    "created_at" : "2014-08-11 03:13:34 +0000",
    "user" : {
      "name" : "Adrian Holovaty",
      "screen_name" : "adrianholovaty",
      "protected" : false,
      "id_str" : "1392281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/65862473\/adrian_normal.jpg",
      "id" : 1392281,
      "verified" : false
    }
  },
  "id" : 498675282727804928,
  "created_at" : "2014-08-11 03:40:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 3, 10 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ftrain\/status\/498663827006058496\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/fQcSPdZoeF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuucG4wCUAEhQX6.png",
      "id_str" : "498663825881583617",
      "id" : 498663825881583617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuucG4wCUAEhQX6.png",
      "sizes" : [ {
        "h" : 469,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 958
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 958
      } ],
      "display_url" : "pic.twitter.com\/fQcSPdZoeF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/c75xfCFBU5",
      "expanded_url" : "http:\/\/www.wordplace.com\/ap\/ap_chap11.shtml",
      "display_url" : "wordplace.com\/ap\/ap_chap11.s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498666943352553472",
  "text" : "RT @ftrain: A little note from WordPerfect, from the era before Chief Happiness Officers. http:\/\/t.co\/c75xfCFBU5 http:\/\/t.co\/fQcSPdZoeF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ftrain\/status\/498663827006058496\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/fQcSPdZoeF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuucG4wCUAEhQX6.png",
        "id_str" : "498663825881583617",
        "id" : 498663825881583617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuucG4wCUAEhQX6.png",
        "sizes" : [ {
          "h" : 469,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 958
        } ],
        "display_url" : "pic.twitter.com\/fQcSPdZoeF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/c75xfCFBU5",
        "expanded_url" : "http:\/\/www.wordplace.com\/ap\/ap_chap11.shtml",
        "display_url" : "wordplace.com\/ap\/ap_chap11.s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "498663827006058496",
    "text" : "A little note from WordPerfect, from the era before Chief Happiness Officers. http:\/\/t.co\/c75xfCFBU5 http:\/\/t.co\/fQcSPdZoeF",
    "id" : 498663827006058496,
    "created_at" : "2014-08-11 02:54:55 +0000",
    "user" : {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "protected" : false,
      "id_str" : "6981492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3363818792\/c90e33ccf22e3146d5cd871ce561795a_normal.png",
      "id" : 6981492,
      "verified" : false
    }
  },
  "id" : 498666943352553472,
  "created_at" : "2014-08-11 03:07:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 3, 15 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/UVxzhX4gAg",
      "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/police-courts\/erie-county-deputies-shoot-dog-after-going-to-wrong-house-for-a-suspect-20140810",
      "display_url" : "buffalonews.com\/city-region\/po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498663230110052353",
  "text" : "RT @mikemikemac: Whoops, we accidentally shot your dog in front of your 5 year old kid  http:\/\/t.co\/UVxzhX4gAg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/UVxzhX4gAg",
        "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/police-courts\/erie-county-deputies-shoot-dog-after-going-to-wrong-house-for-a-suspect-20140810",
        "display_url" : "buffalonews.com\/city-region\/po\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "498662986743951360",
    "text" : "Whoops, we accidentally shot your dog in front of your 5 year old kid  http:\/\/t.co\/UVxzhX4gAg",
    "id" : 498662986743951360,
    "created_at" : "2014-08-11 02:51:35 +0000",
    "user" : {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "protected" : false,
      "id_str" : "158098704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1797045056\/mikemac_normal.png",
      "id" : 158098704,
      "verified" : false
    }
  },
  "id" : 498663230110052353,
  "created_at" : "2014-08-11 02:52:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498650756963401728",
  "geo" : { },
  "id_str" : "498650892963287043",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik UNACCEPTABLE",
  "id" : 498650892963287043,
  "in_reply_to_status_id" : 498650756963401728,
  "created_at" : "2014-08-11 02:03:32 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/498631902241124353\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/ENkpm6xA4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/But_EoHCcAAIJDg.png",
      "id_str" : "498631901217714176",
      "id" : 498631901217714176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/But_EoHCcAAIJDg.png",
      "sizes" : [ {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 1338
      } ],
      "display_url" : "pic.twitter.com\/ENkpm6xA4h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498631902241124353",
  "text" : "Nintendo, this error message is not helpful. http:\/\/t.co\/ENkpm6xA4h",
  "id" : 498631902241124353,
  "created_at" : "2014-08-11 00:48:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/RSL2PGvv2d",
      "expanded_url" : "http:\/\/news.softpedia.com\/images\/news2\/How-Flamethrowers-Work-2.jpg",
      "display_url" : "news.softpedia.com\/images\/news2\/H\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "498629232034349056",
  "geo" : { },
  "id_str" : "498630400109850625",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine http:\/\/t.co\/RSL2PGvv2d",
  "id" : 498630400109850625,
  "in_reply_to_status_id" : 498629232034349056,
  "created_at" : "2014-08-11 00:42:06 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498629697782046721",
  "geo" : { },
  "id_str" : "498630298376994816",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub yeah, home ownership fail. old house + tons of nooks = bad",
  "id" : 498630298376994816,
  "in_reply_to_status_id" : 498629697782046721,
  "created_at" : "2014-08-11 00:41:41 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498630164549365760",
  "text" : "@juliepagano as Khaleesi\/Queen of Firebees I'd assume you have gained some kind of immunity by now",
  "id" : 498630164549365760,
  "created_at" : "2014-08-11 00:41:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243497052, -78.8792628618 ]
  },
  "id_str" : "498628636405010433",
  "text" : "My war against yellow jackets reached a new level tonight.\nOne in the newly installed trap watched on and raged as I sprayed poison. \uD83D\uDE31\uD83D\uDC1D\uD83D\uDC80",
  "id" : 498628636405010433,
  "created_at" : "2014-08-11 00:35:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243097315, -78.8793020882 ]
  },
  "id_str" : "498623812229820416",
  "text" : "Ugh \u201Csox pack\u201D. I wish editing tweets was possible.",
  "id" : 498623812229820416,
  "created_at" : "2014-08-11 00:15:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241740699, -78.8800086433 ]
  },
  "id_str" : "498622448665776131",
  "text" : "Buffalo really is the City of Good Neighbors. Came home to a sox pack of homebrews waiting on our porch from next door.",
  "id" : 498622448665776131,
  "created_at" : "2014-08-11 00:10:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 37, 48 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "indices" : [ 59, 69 ],
      "id_str" : "14807622",
      "id" : 14807622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/nvGDpI3eyI",
      "expanded_url" : "http:\/\/ow.ly\/i\/6vOTs",
      "display_url" : "ow.ly\/i\/6vOTs"
    } ]
  },
  "geo" : { },
  "id_str" : "498621588674457601",
  "text" : "RT @coworkbuffalo: DOING IT RIGHT MT @dangigante: ran into @chazadams at Edgefest\u2014both wore the same shirt http:\/\/t.co\/nvGDpI3eyI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dan gigante",
        "screen_name" : "dangigante",
        "indices" : [ 18, 29 ],
        "id_str" : "43151378",
        "id" : 43151378
      }, {
        "name" : "Chaz Adams",
        "screen_name" : "chazadams",
        "indices" : [ 40, 50 ],
        "id_str" : "14807622",
        "id" : 14807622
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/nvGDpI3eyI",
        "expanded_url" : "http:\/\/ow.ly\/i\/6vOTs",
        "display_url" : "ow.ly\/i\/6vOTs"
      } ]
    },
    "geo" : { },
    "id_str" : "498617344139476993",
    "text" : "DOING IT RIGHT MT @dangigante: ran into @chazadams at Edgefest\u2014both wore the same shirt http:\/\/t.co\/nvGDpI3eyI",
    "id" : 498617344139476993,
    "created_at" : "2014-08-10 23:50:13 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 498621588674457601,
  "created_at" : "2014-08-11 00:07:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 12, 28 ],
      "id_str" : "10114802",
      "id" : 10114802
    }, {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 29, 39 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498331560006135808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244371783, -78.8791957219 ]
  },
  "id_str" : "498440176268374017",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @whentheponydies @sabre1041 low flying copter thats all. I mean, let\u2019s fly sometime",
  "id" : 498440176268374017,
  "in_reply_to_status_id" : 498331560006135808,
  "created_at" : "2014-08-10 12:06:13 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240219031, -78.8804380182 ]
  },
  "id_str" : "498314571677839361",
  "text" : "11:45 sounds like a great time for a helicopter ride over Buffalo.",
  "id" : 498314571677839361,
  "created_at" : "2014-08-10 03:47:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 0, 11 ],
      "id_str" : "426455861",
      "id" : 426455861
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 12, 20 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498283997286248448",
  "geo" : { },
  "id_str" : "498284201699848192",
  "in_reply_to_user_id" : 426455861,
  "text" : "@cadeparade @jayunit congrats!!! Holy crap it's been 3 years.",
  "id" : 498284201699848192,
  "in_reply_to_status_id" : 498283997286248448,
  "created_at" : "2014-08-10 01:46:26 +0000",
  "in_reply_to_screen_name" : "cadeparade",
  "in_reply_to_user_id_str" : "426455861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/OhQbuVDVAY",
      "expanded_url" : "https:\/\/flic.kr\/p\/onHXpR",
      "display_url" : "flic.kr\/p\/onHXpR"
    } ]
  },
  "geo" : { },
  "id_str" : "498282108482113536",
  "text" : "Life without music https:\/\/t.co\/OhQbuVDVAY",
  "id" : 498282108482113536,
  "created_at" : "2014-08-10 01:38:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/G57Gun8FrJ",
      "expanded_url" : "http:\/\/www.meetup.com\/SF-Startups-for-Normal-People\/?gj=ej1b&a=wg2.2_rdmr",
      "display_url" : "meetup.com\/SF-Startups-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498272785584517120",
  "text" : "\"Do you have some legitimately real stuff to discuss because you are building an actual company?\" http:\/\/t.co\/G57Gun8FrJ",
  "id" : 498272785584517120,
  "created_at" : "2014-08-10 01:01:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 26, 38 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/SvGF6ME5te",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?v=10153044516322729&set=vb.98023357728&type=2&theater",
      "display_url" : "facebook.com\/photo.php?v=10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498150050875195392",
  "text" : "String section on the new @AqueousBand album. Next level: https:\/\/t.co\/SvGF6ME5te",
  "id" : 498150050875195392,
  "created_at" : "2014-08-09 16:53:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael M",
      "screen_name" : "michaelmphysics",
      "indices" : [ 3, 19 ],
      "id_str" : "19721045",
      "id" : 19721045
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/michaelmphysics\/status\/497806911748984832\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/x62m7JkWfs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuiQv0LIAAALPte.jpg",
      "id_str" : "497806909957996544",
      "id" : 497806909957996544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuiQv0LIAAALPte.jpg",
      "sizes" : [ {
        "h" : 587,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x62m7JkWfs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497886988561678337",
  "text" : "RT @michaelmphysics: So anyway, this is what the Venus de Milo would look like if she had a rapper's arms. http:\/\/t.co\/x62m7JkWfs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/michaelmphysics\/status\/497806911748984832\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/x62m7JkWfs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuiQv0LIAAALPte.jpg",
        "id_str" : "497806909957996544",
        "id" : 497806909957996544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuiQv0LIAAALPte.jpg",
        "sizes" : [ {
          "h" : 587,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/x62m7JkWfs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497806911748984832",
    "text" : "So anyway, this is what the Venus de Milo would look like if she had a rapper's arms. http:\/\/t.co\/x62m7JkWfs",
    "id" : 497806911748984832,
    "created_at" : "2014-08-08 18:09:51 +0000",
    "user" : {
      "name" : "Michael M",
      "screen_name" : "michaelmphysics",
      "protected" : false,
      "id_str" : "19721045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552616363802378240\/jS1irIdo_normal.jpeg",
      "id" : 19721045,
      "verified" : false
    }
  },
  "id" : 497886988561678337,
  "created_at" : "2014-08-08 23:28:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497886676467728384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243242741, -78.8791057003 ]
  },
  "id_str" : "497886808353423360",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel too many hats",
  "id" : 497886808353423360,
  "in_reply_to_status_id" : 497886676467728384,
  "created_at" : "2014-08-08 23:27:20 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/497885144670560256\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/kpECRfTlER",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BujX5kHIcAAIP0e.jpg",
      "id_str" : "497885142770544640",
      "id" : 497885142770544640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BujX5kHIcAAIP0e.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kpECRfTlER"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9237839049, -78.8769008716 ]
  },
  "id_str" : "497885144670560256",
  "text" : "Dear god they are going to be serving these around the corner from my house http:\/\/t.co\/kpECRfTlER",
  "id" : 497885144670560256,
  "created_at" : "2014-08-08 23:20:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 0, 6 ],
      "id_str" : "920539489",
      "id" : 920539489
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 7, 17 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497880300819468288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9235635419, -78.8768933268 ]
  },
  "id_str" : "497884997362417665",
  "in_reply_to_user_id" : 920539489,
  "text" : "@_zzak @aquaranto hi!",
  "id" : 497884997362417665,
  "in_reply_to_status_id" : 497880300819468288,
  "created_at" : "2014-08-08 23:20:08 +0000",
  "in_reply_to_screen_name" : "_zzak",
  "in_reply_to_user_id_str" : "920539489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morty",
      "screen_name" : "Mortystinks",
      "indices" : [ 3, 15 ],
      "id_str" : "2657330150",
      "id" : 2657330150
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Mortystinks\/status\/497723571440209920\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/aKRUUrFvEh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuhE81YCAAAmC07.jpg",
      "id_str" : "497723570735153152",
      "id" : 497723570735153152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuhE81YCAAAmC07.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/aKRUUrFvEh"
    } ],
    "hashtags" : [ {
      "text" : "corpseflower",
      "indices" : [ 57, 70 ]
    }, {
      "text" : "buffalogardens",
      "indices" : [ 71, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497879867334340609",
  "text" : "RT @Mortystinks: A beautiful day to bloom! Check me out! #corpseflower #buffalogardens http:\/\/t.co\/aKRUUrFvEh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Mortystinks\/status\/497723571440209920\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/aKRUUrFvEh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuhE81YCAAAmC07.jpg",
        "id_str" : "497723570735153152",
        "id" : 497723570735153152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuhE81YCAAAmC07.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/aKRUUrFvEh"
      } ],
      "hashtags" : [ {
        "text" : "corpseflower",
        "indices" : [ 40, 53 ]
      }, {
        "text" : "buffalogardens",
        "indices" : [ 54, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497723571440209920",
    "text" : "A beautiful day to bloom! Check me out! #corpseflower #buffalogardens http:\/\/t.co\/aKRUUrFvEh",
    "id" : 497723571440209920,
    "created_at" : "2014-08-08 12:38:41 +0000",
    "user" : {
      "name" : "Morty",
      "screen_name" : "Mortystinks",
      "protected" : false,
      "id_str" : "2657330150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490197427782045697\/1DU9wSIK_normal.jpeg",
      "id" : 2657330150,
      "verified" : false
    }
  },
  "id" : 497879867334340609,
  "created_at" : "2014-08-08 22:59:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison BreadHive",
      "screen_name" : "AlisonBreadHive",
      "indices" : [ 0, 16 ],
      "id_str" : "1945604605",
      "id" : 1945604605
    }, {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 17, 26 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497779945511612417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240929416, -78.8793102358 ]
  },
  "id_str" : "497849216224333824",
  "in_reply_to_user_id" : 1945604605,
  "text" : "@AlisonBreadHive @Sigafoos I\u2019m going to have nightmares if this is in next week\u2019s share",
  "id" : 497849216224333824,
  "in_reply_to_status_id" : 497779945511612417,
  "created_at" : "2014-08-08 20:57:57 +0000",
  "in_reply_to_screen_name" : "AlisonBreadHive",
  "in_reply_to_user_id_str" : "1945604605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 3, 18 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/VNUeSmTdPy",
      "expanded_url" : "https:\/\/www.google.com\/maps\/place\/Clark+St+%26+Kent+St,+Buffalo,+NY+14212\/@42.892021,-78.8361622,17z\/data=!3m1!4b1!4m2!3m1!1s0x89d30d870884c22f:0x27dcbef27213ad56",
      "display_url" : "google.com\/maps\/place\/Cla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497797820435296256",
  "text" : "RT @ChristineLSloc: TIL: Clark and Kent Streets intersect in Buffalo. I am hereby referring to this intersection as The Super Corner. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/VNUeSmTdPy",
        "expanded_url" : "https:\/\/www.google.com\/maps\/place\/Clark+St+%26+Kent+St,+Buffalo,+NY+14212\/@42.892021,-78.8361622,17z\/data=!3m1!4b1!4m2!3m1!1s0x89d30d870884c22f:0x27dcbef27213ad56",
        "display_url" : "google.com\/maps\/place\/Cla\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "497797409158991873",
    "text" : "TIL: Clark and Kent Streets intersect in Buffalo. I am hereby referring to this intersection as The Super Corner. https:\/\/t.co\/VNUeSmTdPy",
    "id" : 497797409158991873,
    "created_at" : "2014-08-08 17:32:05 +0000",
    "user" : {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "protected" : false,
      "id_str" : "73221502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569953927438024704\/y_kM5xtD_normal.jpeg",
      "id" : 73221502,
      "verified" : false
    }
  },
  "id" : 497797820435296256,
  "created_at" : "2014-08-08 17:33:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/SdbDnPXskb",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2014\/08\/07\/postmortem.html",
      "display_url" : "blog.rubygems.org\/2014\/08\/07\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497558044398862336",
  "text" : "RT @rubygems_status: Here's a quick postmortem of the issues we had this morning - http:\/\/t.co\/SdbDnPXskb.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/SdbDnPXskb",
        "expanded_url" : "http:\/\/blog.rubygems.org\/2014\/08\/07\/postmortem.html",
        "display_url" : "blog.rubygems.org\/2014\/08\/07\/pos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "497557748658089984",
    "text" : "Here's a quick postmortem of the issues we had this morning - http:\/\/t.co\/SdbDnPXskb.",
    "id" : 497557748658089984,
    "created_at" : "2014-08-08 01:39:46 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 497558044398862336,
  "created_at" : "2014-08-08 01:40:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 0, 10 ],
      "id_str" : "253464752",
      "id" : 253464752
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 21, 31 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497554721629290496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9247562774, -78.8792691474 ]
  },
  "id_str" : "497556068546125825",
  "in_reply_to_user_id" : 253464752,
  "text" : "@jessicard say hi to @aquaranto! Also if she gets to meet Boo I will be jealous.",
  "id" : 497556068546125825,
  "in_reply_to_status_id" : 497554721629290496,
  "created_at" : "2014-08-08 01:33:05 +0000",
  "in_reply_to_screen_name" : "jessicard",
  "in_reply_to_user_id_str" : "253464752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497494456505864192",
  "text" : "Nevermind, I got trolled.",
  "id" : 497494456505864192,
  "created_at" : "2014-08-07 21:28:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/csCV79jP6N",
      "expanded_url" : "http:\/\/www.twitch.tv\/fishplayspokemon",
      "display_url" : "twitch.tv\/fishplayspokem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497464800041893889",
  "text" : "20,000 people are watching a fish play Pokemon right now. http:\/\/t.co\/csCV79jP6N",
  "id" : 497464800041893889,
  "created_at" : "2014-08-07 19:30:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Ivan Grey",
      "screen_name" : "LadyIvanGrey",
      "indices" : [ 0, 13 ],
      "id_str" : "2469964320",
      "id" : 2469964320
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 42, 56 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497458062274199552",
  "geo" : { },
  "id_str" : "497459841938382850",
  "in_reply_to_user_id" : 2469964320,
  "text" : "@LadyIvanGrey if\/when you need some A\/C...@coworkbuffalo has plenty :)",
  "id" : 497459841938382850,
  "in_reply_to_status_id" : 497458062274199552,
  "created_at" : "2014-08-07 19:10:43 +0000",
  "in_reply_to_screen_name" : "LadyIvanGrey",
  "in_reply_to_user_id_str" : "2469964320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/mnEWlIJOmN",
      "expanded_url" : "http:\/\/slugsolos.tumblr.com\/",
      "display_url" : "slugsolos.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "497452591173746689",
  "text" : "Favorite new tumblr: http:\/\/t.co\/mnEWlIJOmN",
  "id" : 497452591173746689,
  "created_at" : "2014-08-07 18:41:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael M",
      "screen_name" : "michaelmphysics",
      "indices" : [ 0, 16 ],
      "id_str" : "19721045",
      "id" : 19721045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/m8jaszMBQl",
      "expanded_url" : "http:\/\/thetreyface.tumblr.com\/",
      "display_url" : "thetreyface.tumblr.com"
    } ]
  },
  "in_reply_to_status_id_str" : "497451818642055168",
  "geo" : { },
  "id_str" : "497451930717655040",
  "in_reply_to_user_id" : 19721045,
  "text" : "@michaelmphysics Plenty to choose from: http:\/\/t.co\/m8jaszMBQl",
  "id" : 497451930717655040,
  "in_reply_to_status_id" : 497451818642055168,
  "created_at" : "2014-08-07 18:39:17 +0000",
  "in_reply_to_screen_name" : "michaelmphysics",
  "in_reply_to_user_id_str" : "19721045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael M",
      "screen_name" : "michaelmphysics",
      "indices" : [ 0, 16 ],
      "id_str" : "19721045",
      "id" : 19721045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/tuPaMPXzNv",
      "expanded_url" : "http:\/\/i.imgur.com\/Hcu4l4W.jpg",
      "display_url" : "i.imgur.com\/Hcu4l4W.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "497451476411633665",
  "in_reply_to_user_id" : 19721045,
  "text" : "@michaelmphysics do you take requests for slugsolos? http:\/\/t.co\/tuPaMPXzNv",
  "id" : 497451476411633665,
  "created_at" : "2014-08-07 18:37:28 +0000",
  "in_reply_to_screen_name" : "michaelmphysics",
  "in_reply_to_user_id_str" : "19721045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497447841925578752",
  "geo" : { },
  "id_str" : "497447962251759617",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense ok FINE i will download this tonight",
  "id" : 497447962251759617,
  "in_reply_to_status_id" : 497447841925578752,
  "created_at" : "2014-08-07 18:23:30 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497447748669411328",
  "text" : "My favorite part of Xcode is the part where debugging completely freezes Finder and forces me to restart my computer.",
  "id" : 497447748669411328,
  "created_at" : "2014-08-07 18:22:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Artvoice",
      "screen_name" : "artvoice",
      "indices" : [ 3, 12 ],
      "id_str" : "14334727",
      "id" : 14334727
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/artvoice\/status\/497382322589937664\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/zSeucoDsN8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BucOlefCAAEwVdj.jpg",
      "id_str" : "497382320848896001",
      "id" : 497382320848896001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BucOlefCAAEwVdj.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/zSeucoDsN8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qqmH6PxvAG",
      "expanded_url" : "http:\/\/artvoice.com\/issues\/v13n32\/cover_story",
      "display_url" : "artvoice.com\/issues\/v13n32\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497446944394858496",
  "text" : "RT @Artvoice: Our Downtown Stadium: If done right, could be a catalyst for billions in new development:\nhttp:\/\/t.co\/qqmH6PxvAG http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/artvoice\/status\/497382322589937664\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/zSeucoDsN8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BucOlefCAAEwVdj.jpg",
        "id_str" : "497382320848896001",
        "id" : 497382320848896001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BucOlefCAAEwVdj.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/zSeucoDsN8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/qqmH6PxvAG",
        "expanded_url" : "http:\/\/artvoice.com\/issues\/v13n32\/cover_story",
        "display_url" : "artvoice.com\/issues\/v13n32\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "497382322589937664",
    "text" : "Our Downtown Stadium: If done right, could be a catalyst for billions in new development:\nhttp:\/\/t.co\/qqmH6PxvAG http:\/\/t.co\/zSeucoDsN8",
    "id" : 497382322589937664,
    "created_at" : "2014-08-07 14:02:41 +0000",
    "user" : {
      "name" : "Artvoice",
      "screen_name" : "artvoice",
      "protected" : false,
      "id_str" : "14334727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566280545085054976\/PxDLOUvS_normal.jpeg",
      "id" : 14334727,
      "verified" : false
    }
  },
  "id" : 497446944394858496,
  "created_at" : "2014-08-07 18:19:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "indices" : [ 3, 14 ],
      "id_str" : "14693115",
      "id" : 14693115
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 59, 73 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/SAT3g5Pf0x",
      "expanded_url" : "http:\/\/steelcityruby.org",
      "display_url" : "steelcityruby.org"
    } ]
  },
  "geo" : { },
  "id_str" : "497445730953748480",
  "text" : "RT @rayonrails: You still have time to get your tickets to @SteelCityRuby 2014. For all the details see http:\/\/t.co\/SAT3g5Pf0x. Conf is onl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 43, 57 ],
        "id_str" : "404851600",
        "id" : 404851600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/SAT3g5Pf0x",
        "expanded_url" : "http:\/\/steelcityruby.org",
        "display_url" : "steelcityruby.org"
      } ]
    },
    "geo" : { },
    "id_str" : "497445159576281088",
    "text" : "You still have time to get your tickets to @SteelCityRuby 2014. For all the details see http:\/\/t.co\/SAT3g5Pf0x. Conf is only 8 days away.",
    "id" : 497445159576281088,
    "created_at" : "2014-08-07 18:12:22 +0000",
    "user" : {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "protected" : false,
      "id_str" : "14693115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736560986\/e187009e5f3e50f26239cd009622d7c8_normal.jpeg",
      "id" : 14693115,
      "verified" : false
    }
  },
  "id" : 497445730953748480,
  "created_at" : "2014-08-07 18:14:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497433494822592514",
  "geo" : { },
  "id_str" : "497434100790067201",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I think there's a big distinction between pre and post Rails JS. Pre works great. Post, not so much.",
  "id" : 497434100790067201,
  "in_reply_to_status_id" : 497433494822592514,
  "created_at" : "2014-08-07 17:28:26 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497432707375570945",
  "geo" : { },
  "id_str" : "497433083117699073",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik ah, oops. in any case... I think a lot of the newer stuff being Node focused is part of the problem.",
  "id" : 497433083117699073,
  "in_reply_to_status_id" : 497432707375570945,
  "created_at" : "2014-08-07 17:24:23 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497430960351506433",
  "geo" : { },
  "id_str" : "497431478481862658",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik i know this is a tone argument, but \"degenerate\" colors this entire article for me",
  "id" : 497431478481862658,
  "in_reply_to_status_id" : 497430960351506433,
  "created_at" : "2014-08-07 17:18:00 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/wuL2XQNd8R",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "497384133920690176",
  "text" : "RT @samkottler: In one of the more interesting denial of service issue http:\/\/t.co\/wuL2XQNd8R has ever seen, someone has us configured as t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/wuL2XQNd8R",
        "expanded_url" : "http:\/\/RubyGems.org",
        "display_url" : "RubyGems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "497383795499479040",
    "text" : "In one of the more interesting denial of service issue http:\/\/t.co\/wuL2XQNd8R has ever seen, someone has us configured as their maven source",
    "id" : 497383795499479040,
    "created_at" : "2014-08-07 14:08:32 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 497384133920690176,
  "created_at" : "2014-08-07 14:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wCsxAXRmfr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/cjm2lD3KaF",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/131647",
      "display_url" : "uptime.rubygems.org\/131647"
    } ]
  },
  "geo" : { },
  "id_str" : "497382365283377153",
  "text" : "http:\/\/t.co\/wCsxAXRmfr has been having some issues today, thanks to our volunteer ops team for being on it. http:\/\/t.co\/cjm2lD3KaF",
  "id" : 497382365283377153,
  "created_at" : "2014-08-07 14:02:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497382206264721409",
  "text" : "RT @rubygems_status: We're aware of the intermittent errors and are working to resolve! ^DR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497381944573706241",
    "text" : "We're aware of the intermittent errors and are working to resolve! ^DR",
    "id" : 497381944573706241,
    "created_at" : "2014-08-07 14:01:11 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 497382206264721409,
  "created_at" : "2014-08-07 14:02:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497344827760336896",
  "geo" : { },
  "id_str" : "497345348545691648",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy one of many symptoms of drinking from the firehose",
  "id" : 497345348545691648,
  "in_reply_to_status_id" : 497344827760336896,
  "created_at" : "2014-08-07 11:35:45 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy White",
      "screen_name" : "JeremyWGR",
      "indices" : [ 3, 13 ],
      "id_str" : "135649762",
      "id" : 135649762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/S5sAhrAqc5",
      "expanded_url" : "http:\/\/bit.ly\/V41RoK",
      "display_url" : "bit.ly\/V41RoK"
    } ]
  },
  "geo" : { },
  "id_str" : "497343989880606722",
  "text" : "RT @JeremyWGR: Not just Artvoice's plan...\"people of power and influence\" have talked about this idea. Artvoice's stadium plan http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/S5sAhrAqc5",
        "expanded_url" : "http:\/\/bit.ly\/V41RoK",
        "display_url" : "bit.ly\/V41RoK"
      } ]
    },
    "geo" : { },
    "id_str" : "497325946064474115",
    "text" : "Not just Artvoice's plan...\"people of power and influence\" have talked about this idea. Artvoice's stadium plan http:\/\/t.co\/S5sAhrAqc5",
    "id" : 497325946064474115,
    "created_at" : "2014-08-07 10:18:40 +0000",
    "user" : {
      "name" : "Jeremy White",
      "screen_name" : "JeremyWGR",
      "protected" : false,
      "id_str" : "135649762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476351882492116992\/pgmvCDyr_normal.jpeg",
      "id" : 135649762,
      "verified" : false
    }
  },
  "id" : 497343989880606722,
  "created_at" : "2014-08-07 11:30:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 40, 49 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497207031913123841",
  "geo" : { },
  "id_str" : "497215663039995906",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham i'd open a thread anyway. Also @rubygems is a bot.",
  "id" : 497215663039995906,
  "in_reply_to_status_id" : 497207031913123841,
  "created_at" : "2014-08-07 03:00:26 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/497206170264682496\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/dcGKfbwOHY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuZuYG6CUAA8kCm.png",
      "id_str" : "497206169320968192",
      "id" : 497206169320968192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuZuYG6CUAA8kCm.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 572
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 572
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 572
      } ],
      "display_url" : "pic.twitter.com\/dcGKfbwOHY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497095880324157440",
  "geo" : { },
  "id_str" : "497206170264682496",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler http:\/\/t.co\/dcGKfbwOHY",
  "id" : 497206170264682496,
  "in_reply_to_status_id" : 497095880324157440,
  "created_at" : "2014-08-07 02:22:43 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/mJ5lBZjGVr",
      "expanded_url" : "https:\/\/pokemon.campfirenow.com\/bf6eb",
      "display_url" : "pokemon.campfirenow.com\/bf6eb"
    } ]
  },
  "geo" : { },
  "id_str" : "497205616968876032",
  "text" : "Anyone up for some quick Pokemon battle testing? Please be gentle if so: https:\/\/t.co\/mJ5lBZjGVr",
  "id" : 497205616968876032,
  "created_at" : "2014-08-07 02:20:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497089733407682560",
  "geo" : { },
  "id_str" : "497204764212346880",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham if it's MIT licensed, we can't do much i feel. maybe open a discussion on the google group. lots of activity recently",
  "id" : 497204764212346880,
  "in_reply_to_status_id" : 497089733407682560,
  "created_at" : "2014-08-07 02:17:08 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/wTgcSifwAR",
      "expanded_url" : "http:\/\/gifsound.com\/?gif=i.imgur.com\/1Asrg.gif&v=M11SvDtPBhA&s=45",
      "display_url" : "gifsound.com\/?gif=i.imgur.c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497188872812376064",
  "text" : "OK, I lol'd hard: http:\/\/t.co\/wTgcSifwAR",
  "id" : 497188872812376064,
  "created_at" : "2014-08-07 01:13:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/JD4XIWx2h9",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53e2aefd498efd9bb9c11ef4?s=Y77jWckf2w0y-AxDCrO29AUALOA&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9355545063, -78.8775159835 ]
  },
  "id_str" : "497150379755577344",
  "text" : "I'm at Food Truck Rodeo in Buffalo, NY w\/ 2 others https:\/\/t.co\/JD4XIWx2h9",
  "id" : 497150379755577344,
  "created_at" : "2014-08-06 22:41:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loki Meyburg",
      "screen_name" : "LokiMeyburg",
      "indices" : [ 0, 12 ],
      "id_str" : "23282564",
      "id" : 23282564
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 17, 21 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497066816099729411",
  "geo" : { },
  "id_str" : "497112882467700736",
  "in_reply_to_user_id" : 23282564,
  "text" : "@LokiMeyburg @JZ @dhh Wow, that's really neat.",
  "id" : 497112882467700736,
  "in_reply_to_status_id" : 497066816099729411,
  "created_at" : "2014-08-06 20:12:01 +0000",
  "in_reply_to_screen_name" : "LokiMeyburg",
  "in_reply_to_user_id_str" : "23282564",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497111689889054721",
  "geo" : { },
  "id_str" : "497111857170092033",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky I don't miss this",
  "id" : 497111857170092033,
  "in_reply_to_status_id" : 497111689889054721,
  "created_at" : "2014-08-06 20:07:57 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497101020779274240",
  "geo" : { },
  "id_str" : "497102462063357953",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr fun, i don't remember this at all! wooooooo time",
  "id" : 497102462063357953,
  "in_reply_to_status_id" : 497101020779274240,
  "created_at" : "2014-08-06 19:30:37 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497040330228006912",
  "geo" : { },
  "id_str" : "497040506069581824",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy Hey, run by the new space? I don't remember if you've seen it :)",
  "id" : 497040506069581824,
  "in_reply_to_status_id" : 497040330228006912,
  "created_at" : "2014-08-06 15:24:25 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/jwATmdZdpI",
      "expanded_url" : "http:\/\/tshirtgun.com\/images\/banana_launcher_web.gif",
      "display_url" : "tshirtgun.com\/images\/banana_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497040452122460160",
  "text" : "Current status: http:\/\/t.co\/jwATmdZdpI",
  "id" : 497040452122460160,
  "created_at" : "2014-08-06 15:24:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory M. Gelz",
      "screen_name" : "BUFFALOYALS",
      "indices" : [ 0, 12 ],
      "id_str" : "2223658756",
      "id" : 2223658756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/FOp1UN5HWw",
      "expanded_url" : "https:\/\/twitter.com\/desusnice\/status\/496745779353358336",
      "display_url" : "twitter.com\/desusnice\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "497039392201256960",
  "geo" : { },
  "id_str" : "497039577782042625",
  "in_reply_to_user_id" : 2223658756,
  "text" : "@BUFFALOYALS https:\/\/t.co\/FOp1UN5HWw",
  "id" : 497039577782042625,
  "in_reply_to_status_id" : 497039392201256960,
  "created_at" : "2014-08-06 15:20:44 +0000",
  "in_reply_to_screen_name" : "BUFFALOYALS",
  "in_reply_to_user_id_str" : "2223658756",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497038893665882112",
  "text" : "\".rich is an extension intended for rich people and their needs.\" Price - $1,769.61\n$2,035.05 incl. tax",
  "id" : 497038893665882112,
  "created_at" : "2014-08-06 15:18:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497036432473485312",
  "text" : "Fail: I can't think of a funny .fail domain to register.",
  "id" : 497036432473485312,
  "created_at" : "2014-08-06 15:08:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 37, 49 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/mpAfogNcdq",
      "expanded_url" : "https:\/\/archive.org\/details\/AQ2014-07-25",
      "display_url" : "archive.org\/details\/AQ2014\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497029806396276736",
  "text" : "Fantastic quality recording a recent @AqueousBand gig. Love the streaming here: https:\/\/t.co\/mpAfogNcdq",
  "id" : 497029806396276736,
  "created_at" : "2014-08-06 14:41:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496989989918744576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924408596, -78.8791025989 ]
  },
  "id_str" : "496990079131197440",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier yeah I think so",
  "id" : 496990079131197440,
  "in_reply_to_status_id" : 496989989918744576,
  "created_at" : "2014-08-06 12:04:03 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Eii8g1uaHw",
      "expanded_url" : "https:\/\/www.digitalocean.com\/community\/tutorials\/how-to-use-the-dokku-one-click-digitalocean-image-to-run-a-ruby-on-rails-app",
      "display_url" : "digitalocean.com\/community\/tuto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496884139585310720",
  "text" : "Here's the tutorial I've been following: https:\/\/t.co\/Eii8g1uaHw",
  "id" : 496884139585310720,
  "created_at" : "2014-08-06 05:03:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/d8JLRejDwF",
      "expanded_url" : "https:\/\/www.digitalocean.com\/?refcode=2d1532006d25",
      "display_url" : "digitalocean.com\/?refcode=2d153\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496883933716287488",
  "text" : "Set a deadline of 20 minutes to get a new droplet with Dokku &amp; worker only Procfile and made it work! Try it out: https:\/\/t.co\/d8JLRejDwF",
  "id" : 496883933716287488,
  "created_at" : "2014-08-06 05:02:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496721096553795586",
  "geo" : { },
  "id_str" : "496872500345573378",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik I think both felt creepy. Will need to watch more I guess. Just finished Sidonia.",
  "id" : 496872500345573378,
  "in_reply_to_status_id" : 496721096553795586,
  "created_at" : "2014-08-06 04:16:50 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Bijlani",
      "screen_name" : "paradoxed",
      "indices" : [ 0, 10 ],
      "id_str" : "16648488",
      "id" : 16648488
    }, {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 11, 18 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496674665004544000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243988359, -78.8797070474 ]
  },
  "id_str" : "496810133981102080",
  "in_reply_to_user_id" : 16648488,
  "text" : "@paradoxed @mwhuss why isn\u2019t there official docs for these?",
  "id" : 496810133981102080,
  "in_reply_to_status_id" : 496674665004544000,
  "created_at" : "2014-08-06 00:09:00 +0000",
  "in_reply_to_screen_name" : "paradoxed",
  "in_reply_to_user_id_str" : "16648488",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496809869542821889",
  "text" : "RT @dwarfort_txt: we ended up with regions that rain rodent man blood, which isn't as good as raining human or dwarven blood",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496807991694213120",
    "text" : "we ended up with regions that rain rodent man blood, which isn't as good as raining human or dwarven blood",
    "id" : 496807991694213120,
    "created_at" : "2014-08-06 00:00:30 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 496809869542821889,
  "created_at" : "2014-08-06 00:07:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deadspin",
      "screen_name" : "Deadspin",
      "indices" : [ 3, 12 ],
      "id_str" : "13213122",
      "id" : 13213122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/9MsVsrixig",
      "expanded_url" : "http:\/\/deadsp.in\/hzkB9Mm",
      "display_url" : "deadsp.in\/hzkB9Mm"
    } ]
  },
  "geo" : { },
  "id_str" : "496788112962359297",
  "text" : "RT @Deadspin: VIDEO: Dude's massive rave leads to historically great local news segment http:\/\/t.co\/9MsVsrixig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/9MsVsrixig",
        "expanded_url" : "http:\/\/deadsp.in\/hzkB9Mm",
        "display_url" : "deadsp.in\/hzkB9Mm"
      } ]
    },
    "geo" : { },
    "id_str" : "496785627464368128",
    "text" : "VIDEO: Dude's massive rave leads to historically great local news segment http:\/\/t.co\/9MsVsrixig",
    "id" : 496785627464368128,
    "created_at" : "2014-08-05 22:31:38 +0000",
    "user" : {
      "name" : "Deadspin",
      "screen_name" : "Deadspin",
      "protected" : false,
      "id_str" : "13213122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630483389\/821871b941a2bd5e52a609ef1e9156aa_normal.jpeg",
      "id" : 13213122,
      "verified" : true
    }
  },
  "id" : 496788112962359297,
  "created_at" : "2014-08-05 22:41:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/ZqnLg6ytO6",
      "expanded_url" : "http:\/\/instagram.com\/p\/rVUZ4ZMObZ\/",
      "display_url" : "instagram.com\/p\/rVUZ4ZMObZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "496783902875189248",
  "text" : "RT @PublicEspresso: This just happened at breadhive a traveling puppet troupe stopped by to taste some bread and coffee.\u2026 http:\/\/t.co\/ZqnLg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ZqnLg6ytO6",
        "expanded_url" : "http:\/\/instagram.com\/p\/rVUZ4ZMObZ\/",
        "display_url" : "instagram.com\/p\/rVUZ4ZMObZ\/"
      } ]
    },
    "geo" : { },
    "id_str" : "496782532583505922",
    "text" : "This just happened at breadhive a traveling puppet troupe stopped by to taste some bread and coffee.\u2026 http:\/\/t.co\/ZqnLg6ytO6",
    "id" : 496782532583505922,
    "created_at" : "2014-08-05 22:19:20 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 496783902875189248,
  "created_at" : "2014-08-05 22:24:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496766759798456321",
  "text" : "Actually not joking about that. This would be a lot of fun and charge a hilarious amount of (REAL) money.",
  "id" : 496766759798456321,
  "created_at" : "2014-08-05 21:16:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496765669036158976",
  "geo" : { },
  "id_str" : "496766049077829632",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam i had to google this",
  "id" : 496766049077829632,
  "in_reply_to_status_id" : 496765669036158976,
  "created_at" : "2014-08-05 21:13:50 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496765454950486018",
  "text" : "I'm going to start an artisanal bitcoin wallet service. I'll write down your ssh key and wallet address by hand, store it in a mason jar.",
  "id" : 496765454950486018,
  "created_at" : "2014-08-05 21:11:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/2n9HvrZl0A",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/All-America_City_Award",
      "display_url" : "en.wikipedia.org\/wiki\/All-Ameri\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "496755910841077760",
  "geo" : { },
  "id_str" : "496759364338712576",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents \"Pittsburgh Pennsylvania 1986-87 Two-time winner\" http:\/\/t.co\/2n9HvrZl0A",
  "id" : 496759364338712576,
  "in_reply_to_status_id" : 496755910841077760,
  "created_at" : "2014-08-05 20:47:16 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "indices" : [ 3, 12 ],
      "id_str" : "65433646",
      "id" : 65433646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496756057587609600",
  "text" : "RT @crylenol: \"Welcome to America. Do you have anything to declare?\"\njust my god damn freedom\n\"Amen\"\n*customs agent &amp; I both fire our guns \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496697560586014721",
    "text" : "\"Welcome to America. Do you have anything to declare?\"\njust my god damn freedom\n\"Amen\"\n*customs agent &amp; I both fire our guns into the air*",
    "id" : 496697560586014721,
    "created_at" : "2014-08-05 16:41:41 +0000",
    "user" : {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "protected" : false,
      "id_str" : "65433646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548664026050199552\/zHvu3Wlg_normal.png",
      "id" : 65433646,
      "verified" : false
    }
  },
  "id" : 496756057587609600,
  "created_at" : "2014-08-05 20:34:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/qZV953sZhO",
      "expanded_url" : "http:\/\/aqueousband.net\/",
      "display_url" : "aqueousband.net"
    } ]
  },
  "geo" : { },
  "id_str" : "496753633493778432",
  "text" : "And http:\/\/t.co\/qZV953sZhO is alive on DigitalOcean. Dokku is some pretty cool stuff. Using pg, memcached, redirect plugins.",
  "id" : 496753633493778432,
  "created_at" : "2014-08-05 20:24:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496743173428092928",
  "text" : "I want Vessyl, but for a garbage can. How else will I know what I just threw out?",
  "id" : 496743173428092928,
  "created_at" : "2014-08-05 19:42:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496721478369705984",
  "geo" : { },
  "id_str" : "496723303629746177",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc Portland, OR.",
  "id" : 496723303629746177,
  "in_reply_to_status_id" : 496721478369705984,
  "created_at" : "2014-08-05 18:23:58 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Cheal",
      "screen_name" : "juliancheal",
      "indices" : [ 0, 12 ],
      "id_str" : "951511",
      "id" : 951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496720711323770881",
  "geo" : { },
  "id_str" : "496723264765296642",
  "in_reply_to_user_id" : 951511,
  "text" : "@juliancheal there are some American Bison at our zoo.",
  "id" : 496723264765296642,
  "in_reply_to_status_id" : 496720711323770881,
  "created_at" : "2014-08-05 18:23:49 +0000",
  "in_reply_to_screen_name" : "juliancheal",
  "in_reply_to_user_id_str" : "951511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496719518627291137",
  "geo" : { },
  "id_str" : "496720509711577090",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik was watching a little with my brother in law over the weekend. The animation style creeps me out a bit",
  "id" : 496720509711577090,
  "in_reply_to_status_id" : 496719518627291137,
  "created_at" : "2014-08-05 18:12:52 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/6qtuaRq6ax",
      "expanded_url" : "http:\/\/i.imgur.com\/swDmafu.jpg",
      "display_url" : "i.imgur.com\/swDmafu.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "496718554490621954",
  "text" : "Ahh, beautiful BUFFALO, New York! http:\/\/t.co\/6qtuaRq6ax",
  "id" : 496718554490621954,
  "created_at" : "2014-08-05 18:05:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496702928443699201",
  "geo" : { },
  "id_str" : "496703587104223232",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy Forgot about Soho.",
  "id" : 496703587104223232,
  "in_reply_to_status_id" : 496702928443699201,
  "created_at" : "2014-08-05 17:05:38 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miah Johnson",
      "screen_name" : "miah_",
      "indices" : [ 0, 6 ],
      "id_str" : "14260840",
      "id" : 14260840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496700378319044609",
  "geo" : { },
  "id_str" : "496700504953479171",
  "in_reply_to_user_id" : 14260840,
  "text" : "@miah_ orange sooooooda",
  "id" : 496700504953479171,
  "in_reply_to_status_id" : 496700378319044609,
  "created_at" : "2014-08-05 16:53:23 +0000",
  "in_reply_to_screen_name" : "miah_",
  "in_reply_to_user_id_str" : "14260840",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ZzvxzonzmF",
      "expanded_url" : "https:\/\/thedistance.com\/hollymatic",
      "display_url" : "thedistance.com\/hollymatic"
    } ]
  },
  "geo" : { },
  "id_str" : "496700163155427328",
  "text" : "Why isn't there a good burger place downtown? https:\/\/t.co\/ZzvxzonzmF has me realizing this fact.",
  "id" : 496700163155427328,
  "created_at" : "2014-08-05 16:52:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/QPsEnXoMsW",
      "expanded_url" : "http:\/\/www.airbnb.com\/c\/nquaranto",
      "display_url" : "airbnb.com\/c\/nquaranto"
    }, {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ey6JkYvnpr",
      "expanded_url" : "https:\/\/www.airbnb.com\/rooms\/2535258",
      "display_url" : "airbnb.com\/rooms\/2535258"
    } ]
  },
  "in_reply_to_status_id_str" : "496698632096481280",
  "geo" : { },
  "id_str" : "496699242753167360",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik word. well in any case, if you'd like to toss $25 my way ;) http:\/\/t.co\/QPsEnXoMsW https:\/\/t.co\/ey6JkYvnpr",
  "id" : 496699242753167360,
  "in_reply_to_status_id" : 496698632096481280,
  "created_at" : "2014-08-05 16:48:22 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496697489157017600",
  "geo" : { },
  "id_str" : "496698288519667713",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik I just stayed at a good AirBNB if you'd like a link",
  "id" : 496698288519667713,
  "in_reply_to_status_id" : 496697489157017600,
  "created_at" : "2014-08-05 16:44:34 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/JMbCdEUkHq",
      "expanded_url" : "https:\/\/trello.com\/b\/vdSSFMOp\/rubygems-org",
      "display_url" : "trello.com\/b\/vdSSFMOp\/rub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496692671298039811",
  "text" : "Trello public boards don't allow you to do much, so if you'd like access to the http:\/\/t.co\/EmUiG90kOd board: https:\/\/t.co\/JMbCdEUkHq",
  "id" : 496692671298039811,
  "created_at" : "2014-08-05 16:22:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 50, 64 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496661847312179200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8933318264, -78.8717066906 ]
  },
  "id_str" : "496662662210936832",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc it is an institutional problem at @coworkbuffalo",
  "id" : 496662662210936832,
  "in_reply_to_status_id" : 496661847312179200,
  "created_at" : "2014-08-05 14:23:00 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496650822676410368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241815169, -78.8795598811 ]
  },
  "id_str" : "496650946688978944",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc nope.",
  "id" : 496650946688978944,
  "in_reply_to_status_id" : 496650822676410368,
  "created_at" : "2014-08-05 13:36:27 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paolo Perrotta",
      "screen_name" : "nusco",
      "indices" : [ 82, 88 ],
      "id_str" : "5944932",
      "id" : 5944932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/fq8Y0WkdDK",
      "expanded_url" : "http:\/\/dilbert.com\/dyn\/str_strip\/000000000\/00000000\/0000000\/200000\/20000\/6000\/400\/226484\/226484.strip.gif",
      "display_url" : "dilbert.com\/dyn\/str_strip\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496617267665186816",
  "text" : "\u201CMy mother taught herself Ruby on Rails in a weekend\u201D http:\/\/t.co\/fq8Y0WkdDK (via @nusco)",
  "id" : 496617267665186816,
  "created_at" : "2014-08-05 11:22:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496507320851910657",
  "text" : "I have no idea how Docker works.",
  "id" : 496507320851910657,
  "created_at" : "2014-08-05 04:05:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496479045626777600",
  "text" : "DigitalOcean and Dokku are amazing. It's crazy how far this has come.",
  "id" : 496479045626777600,
  "created_at" : "2014-08-05 02:13:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496397702243315713",
  "text" : "My favorite part of iTunes Connect is guessing what all the numbers in the URL are for. 6.0.0.12.5.0.7.3.3.1.0.13.3.1.1.11.9.0.1.7.0",
  "id" : 496397702243315713,
  "created_at" : "2014-08-04 20:50:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/lCs3FghreI",
      "expanded_url" : "http:\/\/iliftthingsupandputthemdown.ytmnd.com\/",
      "display_url" : "iliftthingsupandputthemdown.ytmnd.com"
    } ]
  },
  "in_reply_to_status_id_str" : "496396182675931136",
  "geo" : { },
  "id_str" : "496397311656730625",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 http:\/\/t.co\/lCs3FghreI",
  "id" : 496397311656730625,
  "in_reply_to_status_id" : 496396182675931136,
  "created_at" : "2014-08-04 20:48:36 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496378187396304896",
  "text" : "Thanks Xcode, for making me seem way more productive than I really am:  5 files changed, 7379 insertions(+), 7336 deletions(-)",
  "id" : 496378187396304896,
  "created_at" : "2014-08-04 19:32:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/3UAdoKIt5Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "496358968801779713",
  "text" : "All of our speakers are ready to roll for @nickelcityruby: http:\/\/t.co\/3UAdoKIt5Q Robots. Music. That's only 3 of them. Attending yet?",
  "id" : 496358968801779713,
  "created_at" : "2014-08-04 18:16:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/SozsUSJBgv",
      "expanded_url" : "http:\/\/www.chezgeeks.com\/",
      "display_url" : "chezgeeks.com"
    } ]
  },
  "in_reply_to_status_id_str" : "496356295239163904",
  "geo" : { },
  "id_str" : "496356797507059712",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej we stopped by http:\/\/t.co\/SozsUSJBgv, on a neat little street with lots to see.",
  "id" : 496356797507059712,
  "in_reply_to_status_id" : 496356295239163904,
  "created_at" : "2014-08-04 18:07:37 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wood",
      "screen_name" : "JellybobUK",
      "indices" : [ 0, 11 ],
      "id_str" : "16557322",
      "id" : 16557322
    }, {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 12, 20 ],
      "id_str" : "15944824",
      "id" : 15944824
    }, {
      "name" : "John Feminella",
      "screen_name" : "jxxf",
      "indices" : [ 21, 26 ],
      "id_str" : "19463693",
      "id" : 19463693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496191244817952768",
  "geo" : { },
  "id_str" : "496307775656308736",
  "in_reply_to_user_id" : 16557322,
  "text" : "@JellybobUK @paulehr @jxxf part of the problem here is that full access to the servers is required to fix issues. Can't distribute fully yet",
  "id" : 496307775656308736,
  "in_reply_to_status_id" : 496191244817952768,
  "created_at" : "2014-08-04 14:52:49 +0000",
  "in_reply_to_screen_name" : "JellybobUK",
  "in_reply_to_user_id_str" : "16557322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Kanalley",
      "screen_name" : "ckanal",
      "indices" : [ 0, 7 ],
      "id_str" : "15964196",
      "id" : 15964196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242957543, -78.8800822694 ]
  },
  "id_str" : "496282137142624256",
  "in_reply_to_user_id" : 15964196,
  "text" : "@ckanal it\u2019s pathetic that the organization cannot pay people for this",
  "id" : 496282137142624256,
  "created_at" : "2014-08-04 13:10:56 +0000",
  "in_reply_to_screen_name" : "ckanal",
  "in_reply_to_user_id_str" : "15964196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo\/Erie Library",
      "screen_name" : "buffalolibrary",
      "indices" : [ 3, 18 ],
      "id_str" : "34322946",
      "id" : 34322946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/klID6svjwL",
      "expanded_url" : "http:\/\/bit.ly\/1zbxAUl",
      "display_url" : "bit.ly\/1zbxAUl"
    } ]
  },
  "geo" : { },
  "id_str" : "496280271453294592",
  "text" : "RT @buffalolibrary: Huge Used Book Sale Thursday-Friday-Saturday @ Central Library. Everything 50 cents. Spread the word. Details http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/klID6svjwL",
        "expanded_url" : "http:\/\/bit.ly\/1zbxAUl",
        "display_url" : "bit.ly\/1zbxAUl"
      } ]
    },
    "geo" : { },
    "id_str" : "496276394200940544",
    "text" : "Huge Used Book Sale Thursday-Friday-Saturday @ Central Library. Everything 50 cents. Spread the word. Details http:\/\/t.co\/klID6svjwL",
    "id" : 496276394200940544,
    "created_at" : "2014-08-04 12:48:07 +0000",
    "user" : {
      "name" : "Buffalo\/Erie Library",
      "screen_name" : "buffalolibrary",
      "protected" : false,
      "id_str" : "34322946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552899931749380096\/AYFTbkPi_normal.png",
      "id" : 34322946,
      "verified" : false
    }
  },
  "id" : 496280271453294592,
  "created_at" : "2014-08-04 13:03:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 3, 17 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/26tqkkMMLL",
      "expanded_url" : "http:\/\/www.steelcityruby.org\/travel",
      "display_url" : "steelcityruby.org\/travel"
    } ]
  },
  "geo" : { },
  "id_str" : "496280208643608576",
  "text" : "RT @SteelCityRuby: If you've not already made your travel plans, you probably should do that pretty soon.\n\nCheck out our info: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/26tqkkMMLL",
        "expanded_url" : "http:\/\/www.steelcityruby.org\/travel",
        "display_url" : "steelcityruby.org\/travel"
      } ]
    },
    "geo" : { },
    "id_str" : "496279660120907776",
    "text" : "If you've not already made your travel plans, you probably should do that pretty soon.\n\nCheck out our info: http:\/\/t.co\/26tqkkMMLL",
    "id" : 496279660120907776,
    "created_at" : "2014-08-04 13:01:06 +0000",
    "user" : {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "protected" : false,
      "id_str" : "404851600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551460511951228928\/ExkXJuce_normal.png",
      "id" : 404851600,
      "verified" : false
    }
  },
  "id" : 496280208643608576,
  "created_at" : "2014-08-04 13:03:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "indices" : [ 3, 13 ],
      "id_str" : "11969",
      "id" : 11969
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/zachklein\/status\/496275454215872512\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/HxO3m9FGKz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuMf5QUIcAIqXvP.png",
      "id_str" : "496275452433297410",
      "id" : 496275452433297410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuMf5QUIcAIqXvP.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HxO3m9FGKz"
    } ],
    "hashtags" : [ {
      "text" : "SF",
      "indices" : [ 15, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/TYCXoPZs49",
      "expanded_url" : "http:\/\/sf.curbed.com\/archives\/2014\/07\/31\/san_francisco_is_expensive_but_millennials_are_coming_anyway.php#more",
      "display_url" : "sf.curbed.com\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496278152784920577",
  "text" : "RT @zachklein: #SF \"Millennials\" in the county spend 78% of their median income on house payments. http:\/\/t.co\/TYCXoPZs49 http:\/\/t.co\/HxO3m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/zachklein\/status\/496275454215872512\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/HxO3m9FGKz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuMf5QUIcAIqXvP.png",
        "id_str" : "496275452433297410",
        "id" : 496275452433297410,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuMf5QUIcAIqXvP.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HxO3m9FGKz"
      } ],
      "hashtags" : [ {
        "text" : "SF",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/TYCXoPZs49",
        "expanded_url" : "http:\/\/sf.curbed.com\/archives\/2014\/07\/31\/san_francisco_is_expensive_but_millennials_are_coming_anyway.php#more",
        "display_url" : "sf.curbed.com\/archives\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496275454215872512",
    "text" : "#SF \"Millennials\" in the county spend 78% of their median income on house payments. http:\/\/t.co\/TYCXoPZs49 http:\/\/t.co\/HxO3m9FGKz",
    "id" : 496275454215872512,
    "created_at" : "2014-08-04 12:44:23 +0000",
    "user" : {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "protected" : false,
      "id_str" : "11969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496370289115009026\/dqey2AVU_normal.jpeg",
      "id" : 11969,
      "verified" : false
    }
  },
  "id" : 496278152784920577,
  "created_at" : "2014-08-04 12:55:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/sJVIU4o4b9",
      "expanded_url" : "https:\/\/flic.kr\/p\/oiFLgP",
      "display_url" : "flic.kr\/p\/oiFLgP"
    } ]
  },
  "geo" : { },
  "id_str" : "496263491108356098",
  "text" : "Feeling a little crazy https:\/\/t.co\/sJVIU4o4b9",
  "id" : 496263491108356098,
  "created_at" : "2014-08-04 11:56:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496151935771103232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241895981, -78.8794340637 ]
  },
  "id_str" : "496153555892330496",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt the most recent legal threat was the last straw. I am just out of energy for it.",
  "id" : 496153555892330496,
  "in_reply_to_status_id" : 496151935771103232,
  "created_at" : "2014-08-04 04:40:00 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "Adam Stacoviak",
      "screen_name" : "adamstac",
      "indices" : [ 22, 31 ],
      "id_str" : "816954",
      "id" : 816954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496151075997884417",
  "geo" : { },
  "id_str" : "496151282088833024",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k i think you and @adamstac need a new publicist :P Let's wait until this is all figured out.",
  "id" : 496151282088833024,
  "in_reply_to_status_id" : 496151075997884417,
  "created_at" : "2014-08-04 04:30:58 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496150141712470016",
  "geo" : { },
  "id_str" : "496150653249413120",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy Constant status",
  "id" : 496150653249413120,
  "in_reply_to_status_id" : 496150141712470016,
  "created_at" : "2014-08-04 04:28:28 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Stacoviak",
      "screen_name" : "adamstac",
      "indices" : [ 0, 9 ],
      "id_str" : "816954",
      "id" : 816954
    }, {
      "name" : "The Changelog",
      "screen_name" : "TheChangelog",
      "indices" : [ 10, 23 ],
      "id_str" : "90286855",
      "id" : 90286855
    }, {
      "name" : "Jerod Santo",
      "screen_name" : "jerodsanto",
      "indices" : [ 24, 35 ],
      "id_str" : "14872146",
      "id" : 14872146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496150388840480768",
  "geo" : { },
  "id_str" : "496150597582606336",
  "in_reply_to_user_id" : 816954,
  "text" : "@adamstac @TheChangelog @jerodsanto thank you for the offer though :)",
  "id" : 496150597582606336,
  "in_reply_to_status_id" : 496150388840480768,
  "created_at" : "2014-08-04 04:28:15 +0000",
  "in_reply_to_screen_name" : "adamstac",
  "in_reply_to_user_id_str" : "816954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Stacoviak",
      "screen_name" : "adamstac",
      "indices" : [ 0, 9 ],
      "id_str" : "816954",
      "id" : 816954
    }, {
      "name" : "The Changelog",
      "screen_name" : "TheChangelog",
      "indices" : [ 10, 23 ],
      "id_str" : "90286855",
      "id" : 90286855
    }, {
      "name" : "Jerod Santo",
      "screen_name" : "jerodsanto",
      "indices" : [ 24, 35 ],
      "id_str" : "14872146",
      "id" : 14872146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496150388840480768",
  "geo" : { },
  "id_str" : "496150508646572032",
  "in_reply_to_user_id" : 816954,
  "text" : "@adamstac @TheChangelog @jerodsanto not until we figure it out",
  "id" : 496150508646572032,
  "in_reply_to_status_id" : 496150388840480768,
  "created_at" : "2014-08-04 04:27:53 +0000",
  "in_reply_to_screen_name" : "adamstac",
  "in_reply_to_user_id_str" : "816954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496148514091454465",
  "geo" : { },
  "id_str" : "496148780735938561",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect If you think VC is the only way...I sincerely hope it is not",
  "id" : 496148780735938561,
  "in_reply_to_status_id" : 496148514091454465,
  "created_at" : "2014-08-04 04:21:01 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 73, 82 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 83, 94 ],
      "id_str" : "247090698",
      "id" : 247090698
    }, {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 95, 107 ],
      "id_str" : "253374465",
      "id" : 253374465
    }, {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 108, 121 ],
      "id_str" : "121941652",
      "id" : 121941652
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 122, 135 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/3EE7Gg50B5",
      "expanded_url" : "http:\/\/imgur.com\/a\/xwRWq",
      "display_url" : "imgur.com\/a\/xwRWq"
    } ]
  },
  "geo" : { },
  "id_str" : "496148304195895296",
  "text" : "Quick waveform between Fuegos: http:\/\/t.co\/3EE7Gg50B5 Want them all! \/cc @LawnMemo @bizarchive @fluffhead67 @Jmkrochester @antelopeezer",
  "id" : 496148304195895296,
  "created_at" : "2014-08-04 04:19:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/eDrAtAI8X1",
      "expanded_url" : "https:\/\/github.com\/beschulz\/wav2png",
      "display_url" : "github.com\/beschulz\/wav2p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496139458526208000",
  "text" : "wav2png, awesome: https:\/\/t.co\/eDrAtAI8X1",
  "id" : 496139458526208000,
  "created_at" : "2014-08-04 03:43:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 12, 24 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496136425939537920",
  "text" : "Watching as @fluffhead67 explodes into a thousand tiny pieces.",
  "id" : 496136425939537920,
  "created_at" : "2014-08-04 03:31:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496131967159906305",
  "geo" : { },
  "id_str" : "496132314049421312",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad Brouego",
  "id" : 496132314049421312,
  "in_reply_to_status_id" : 496131967159906305,
  "created_at" : "2014-08-04 03:15:36 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241052937, -78.8793038687 ]
  },
  "id_str" : "496128918185713664",
  "text" : "@juliepagano agreed. Sadly we basically blew off a lot of interested people last year",
  "id" : 496128918185713664,
  "created_at" : "2014-08-04 03:02:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "npmbot",
      "screen_name" : "npmjs",
      "indices" : [ 25, 31 ],
      "id_str" : "309528017",
      "id" : 309528017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/1LSOXzEdIP",
      "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/rubygems-org\/jixzTASyA6Q\/GK0on52ZsMYJ",
      "display_url" : "groups.google.com\/d\/msg\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496120165138849793",
  "text" : "Wrote a deep response to @npmjs' \"Legal Stuff\" and CoC: https:\/\/t.co\/1LSOXzEdIP Would appreciate a read.",
  "id" : 496120165138849793,
  "created_at" : "2014-08-04 02:27:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Schofield",
      "screen_name" : "uberzealot",
      "indices" : [ 0, 11 ],
      "id_str" : "227046773",
      "id" : 227046773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496096293450960898",
  "geo" : { },
  "id_str" : "496103415672344576",
  "in_reply_to_user_id" : 227046773,
  "text" : "@uberzealot quality of the broadcast always stuns me. and it's LIVE!",
  "id" : 496103415672344576,
  "in_reply_to_status_id" : 496096293450960898,
  "created_at" : "2014-08-04 01:20:46 +0000",
  "in_reply_to_screen_name" : "uberzealot",
  "in_reply_to_user_id_str" : "227046773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 45, 59 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 77, 92 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496099567113228288",
  "geo" : { },
  "id_str" : "496099772575387649",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald Deal. It's across the street from @coworkbuffalo! (Also: Going to @nickelcityruby?!)",
  "id" : 496099772575387649,
  "in_reply_to_status_id" : 496099567113228288,
  "created_at" : "2014-08-04 01:06:17 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 11, 24 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496098142966652928",
  "geo" : { },
  "id_str" : "496098251901120512",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @rachbarnhart I can't wait until one billionaire owns both teams here!",
  "id" : 496098251901120512,
  "in_reply_to_status_id" : 496098142966652928,
  "created_at" : "2014-08-04 01:00:14 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496097497022881793",
  "text" : "RT @rachbarnhart: Show me study, show me data showing the Bills support hundreds of jobs &amp; hundreds of millions in investment annually. Ple\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496005373145657344",
    "text" : "Show me study, show me data showing the Bills support hundreds of jobs &amp; hundreds of millions in investment annually. Please. Show me.",
    "id" : 496005373145657344,
    "created_at" : "2014-08-03 18:51:10 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 496097497022881793,
  "created_at" : "2014-08-04 00:57:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 5, 11 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/xY3qnq35WJ",
      "expanded_url" : "http:\/\/livephish.tv\/index.html",
      "display_url" : "livephish.tv\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "496088635976871936",
  "text" : "Free @phish, starting now. If you haven't listened to any, start now: http:\/\/t.co\/xY3qnq35WJ",
  "id" : 496088635976871936,
  "created_at" : "2014-08-04 00:22:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 14, 27 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495987866515017730",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241073609, -78.8800014442 ]
  },
  "id_str" : "496013419619700736",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach @steveklabnik agreed, I thoroughly enjoyed this. I also enjoyed watching videos instead of lecture in school. Related?",
  "id" : 496013419619700736,
  "in_reply_to_status_id" : 495987866515017730,
  "created_at" : "2014-08-03 19:23:09 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 123, 138 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495921921943289857",
  "text" : "RT @coworkbuffalo: Serious coffee dude told us this morning that we're making the best coffee in Buffalo (presumably until @PublicEspresso \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PublicEspresso",
        "screen_name" : "PublicEspresso",
        "indices" : [ 104, 119 ],
        "id_str" : "1472209542",
        "id" : 1472209542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495225341120499713",
    "text" : "Serious coffee dude told us this morning that we're making the best coffee in Buffalo (presumably until @PublicEspresso serves weekdays!)",
    "id" : 495225341120499713,
    "created_at" : "2014-08-01 15:11:36 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 495921921943289857,
  "created_at" : "2014-08-03 13:19:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chitsung",
      "screen_name" : "chitsung",
      "indices" : [ 0, 9 ],
      "id_str" : "18891726",
      "id" : 18891726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495801876256800768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243247351, -78.8790689037 ]
  },
  "id_str" : "495889769390292992",
  "in_reply_to_user_id" : 18891726,
  "text" : "@chitsung just in time for Swift too!",
  "id" : 495889769390292992,
  "in_reply_to_status_id" : 495801876256800768,
  "created_at" : "2014-08-03 11:11:48 +0000",
  "in_reply_to_screen_name" : "chitsung",
  "in_reply_to_user_id_str" : "18891726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chitsung",
      "screen_name" : "chitsung",
      "indices" : [ 0, 9 ],
      "id_str" : "18891726",
      "id" : 18891726
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 72, 82 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495801876256800768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242504238, -78.8798480597 ]
  },
  "id_str" : "495889662427144193",
  "in_reply_to_user_id" : 18891726,
  "text" : "@chitsung we wanted to dig into the platform and learn it. And we hired @zachwaugh :)",
  "id" : 495889662427144193,
  "in_reply_to_status_id" : 495801876256800768,
  "created_at" : "2014-08-03 11:11:23 +0000",
  "in_reply_to_screen_name" : "chitsung",
  "in_reply_to_user_id_str" : "18891726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495768764143902720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244586779, -78.8791844901 ]
  },
  "id_str" : "495768906410127360",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 that was the same weekend as @nickelcityruby last year! :(",
  "id" : 495768906410127360,
  "in_reply_to_status_id" : 495768764143902720,
  "created_at" : "2014-08-03 03:11:32 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 0, 9 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 10, 15 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 16, 24 ],
      "id_str" : "38699900",
      "id" : 38699900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495765579190784000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241673554, -78.8790723393 ]
  },
  "id_str" : "495765900557959168",
  "in_reply_to_user_id" : 14164724,
  "text" : "@sarahmei @avdi @geeksam might be a big city thing too. Barely anyone uses Ruby here, I hear of PHP, Perl, .NET etc more often.",
  "id" : 495765900557959168,
  "in_reply_to_status_id" : 495765579190784000,
  "created_at" : "2014-08-03 02:59:36 +0000",
  "in_reply_to_screen_name" : "sarahmei",
  "in_reply_to_user_id_str" : "14164724",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 6, 15 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 16, 24 ],
      "id_str" : "38699900",
      "id" : 38699900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495764824744157184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241673554, -78.8790723393 ]
  },
  "id_str" : "495765104437112833",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @sarahmei @geeksam I haven\u2019t been to a multilingual one outside of Barcamp. Maybe that is part of the problem (for me and everyone)",
  "id" : 495765104437112833,
  "in_reply_to_status_id" : 495764824744157184,
  "created_at" : "2014-08-03 02:56:26 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 6, 14 ],
      "id_str" : "38699900",
      "id" : 38699900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495757617679958016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241673554, -78.8790723393 ]
  },
  "id_str" : "495764205287403520",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @geeksam this has been on my mind a lot lately. Will consider OSCON next year, first year with a little one has been busy",
  "id" : 495764205287403520,
  "in_reply_to_status_id" : 495757617679958016,
  "created_at" : "2014-08-03 02:52:52 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495759107433848832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243015128, -78.8793243891 ]
  },
  "id_str" : "495760091186855936",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide so did Pitchfork just extend a few weeks?",
  "id" : 495760091186855936,
  "in_reply_to_status_id" : 495759107433848832,
  "created_at" : "2014-08-03 02:36:31 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 3, 12 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 59, 74 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495758956518576128",
  "text" : "RT @sebasoga: I\u2019m thrilled to announce I\u2019ll be speaking at @nickelcityruby in October!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 45, 60 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495302091460845568",
    "text" : "I\u2019m thrilled to announce I\u2019ll be speaking at @nickelcityruby in October!",
    "id" : 495302091460845568,
    "created_at" : "2014-08-01 20:16:35 +0000",
    "user" : {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "protected" : false,
      "id_str" : "41438974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488894836628418560\/teTisCDG_normal.jpeg",
      "id" : 41438974,
      "verified" : false
    }
  },
  "id" : 495758956518576128,
  "created_at" : "2014-08-03 02:32:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495742824793784320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243958164, -78.8792309781 ]
  },
  "id_str" : "495743800598228993",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 your end is the road!",
  "id" : 495743800598228993,
  "in_reply_to_status_id" : 495742824793784320,
  "created_at" : "2014-08-03 01:31:47 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 46, 58 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQband",
      "indices" : [ 116, 123 ]
    }, {
      "text" : "nofacesremained",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kUj1t2djbF",
      "expanded_url" : "https:\/\/soundcloud.com\/unclephilsblog\/sets\/aqueous-2014-07-25-gathering",
      "display_url" : "soundcloud.com\/unclephilsblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "495724763562508290",
  "text" : "RT @UnclePhilsBlog: Want to know what all the @AqueousBand hype is about? LISTEN TO THIS!!! https:\/\/t.co\/kUj1t2djbF #AQband #nofacesremained",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 26, 38 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQband",
        "indices" : [ 96, 103 ]
      }, {
        "text" : "nofacesremained",
        "indices" : [ 104, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/kUj1t2djbF",
        "expanded_url" : "https:\/\/soundcloud.com\/unclephilsblog\/sets\/aqueous-2014-07-25-gathering",
        "display_url" : "soundcloud.com\/unclephilsblog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "495624508364300288",
    "text" : "Want to know what all the @AqueousBand hype is about? LISTEN TO THIS!!! https:\/\/t.co\/kUj1t2djbF #AQband #nofacesremained",
    "id" : 495624508364300288,
    "created_at" : "2014-08-02 17:37:45 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 495724763562508290,
  "created_at" : "2014-08-03 00:16:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "495721223381590016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241053009, -78.8786455508 ]
  },
  "id_str" : "495723170255486976",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls ranting here sorry. Will post a longer piece on the http:\/\/t.co\/EmUiG90kOd google group",
  "id" : 495723170255486976,
  "in_reply_to_status_id" : 495721223381590016,
  "created_at" : "2014-08-03 00:09:48 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495721223381590016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245365458, -78.8792299201 ]
  },
  "id_str" : "495722720558985217",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls it feels like \u201Cwork\u201D and not fun at all (for me). Not sure how to fix, but a putting a policy in place before fixing = irresponsible",
  "id" : 495722720558985217,
  "in_reply_to_status_id" : 495721223381590016,
  "created_at" : "2014-08-03 00:08:01 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495721223381590016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245365458, -78.8792299201 ]
  },
  "id_str" : "495722304655990784",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls I guess I\u2019m saying\u2026I don\u2019t think it works well as a volunteer support queue. Maybe biased since we have very few who work the queue",
  "id" : 495722304655990784,
  "in_reply_to_status_id" : 495721223381590016,
  "created_at" : "2014-08-03 00:06:22 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495721223381590016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245365458, -78.8792299201 ]
  },
  "id_str" : "495721809887514624",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls sure, here\u2019s the problem: it\u2019s literally a job. The support queue already takes serious time and investigation for most issues",
  "id" : 495721809887514624,
  "in_reply_to_status_id" : 495721223381590016,
  "created_at" : "2014-08-03 00:04:24 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 29, 39 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242603842, -78.8799285406 ]
  },
  "id_str" : "495721326326185984",
  "text" : "SF friends: the one and only @aquaranto will be in your vicinity starting tomorrow! You know what to do.",
  "id" : 495721326326185984,
  "created_at" : "2014-08-03 00:02:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495721057349689344",
  "text" : "RT @aquaranto: Hey SF friends, I'm going to be in town all next week. Ping me if you're up for dinner\/drinks!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495275279581855744",
    "text" : "Hey SF friends, I'm going to be in town all next week. Ping me if you're up for dinner\/drinks!",
    "id" : 495275279581855744,
    "created_at" : "2014-08-01 18:30:03 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 495721057349689344,
  "created_at" : "2014-08-03 00:01:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/CdP5xjHxBV",
      "expanded_url" : "http:\/\/www.npmjs.com\/policies\/conduct\/",
      "display_url" : "npmjs.com\/policies\/condu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245532677, -78.8793010824 ]
  },
  "id_str" : "495719557609189376",
  "text" : "This is great for NPM: http:\/\/t.co\/CdP5xjHxBV would love to do the same for rubygems but worried we don\u2019t have the human bandwidth to do it",
  "id" : 495719557609189376,
  "created_at" : "2014-08-02 23:55:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "indices" : [ 3, 10 ],
      "id_str" : "39617149",
      "id" : 39617149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/hRnLZIMwFm",
      "expanded_url" : "http:\/\/www.npmjs.com\/policies\/conduct\/",
      "display_url" : "npmjs.com\/policies\/condu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "495719330420490241",
  "text" : "RT @cczona: I like that OSS communities are choosing to make explicit their collective values, intentions, &amp; conduct expectations http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/hRnLZIMwFm",
        "expanded_url" : "http:\/\/www.npmjs.com\/policies\/conduct\/",
        "display_url" : "npmjs.com\/policies\/condu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "495717900422901760",
    "text" : "I like that OSS communities are choosing to make explicit their collective values, intentions, &amp; conduct expectations http:\/\/t.co\/hRnLZIMwFm",
    "id" : 495717900422901760,
    "created_at" : "2014-08-02 23:48:52 +0000",
    "user" : {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "protected" : false,
      "id_str" : "39617149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3448372624\/fbfdda29ff5fcee3ff0ad60e2d3932ae_normal.jpeg",
      "id" : 39617149,
      "verified" : false
    }
  },
  "id" : 495719330420490241,
  "created_at" : "2014-08-02 23:54:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244797584, -78.8790981565 ]
  },
  "id_str" : "495711958855729152",
  "text" : "Crazy Taxi City Ride might be the first iOS game I\u2019ve played to get driving right. No on screen pedal or tilting.",
  "id" : 495711958855729152,
  "created_at" : "2014-08-02 23:25:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 69, 84 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/U0OXEsoqFS",
      "expanded_url" : "http:\/\/nymag.com\/travel\/weekends\/buffalo\/",
      "display_url" : "nymag.com\/travel\/weekend\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "495696709507223552",
  "text" : "Great little guide for what to do, eat, see while you're in town for @nickelcityruby: http:\/\/t.co\/U0OXEsoqFS",
  "id" : 495696709507223552,
  "created_at" : "2014-08-02 22:24:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 38, 46 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 47, 58 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 59, 71 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495673712126218241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924107484, -78.8792966401 ]
  },
  "id_str" : "495674051822497793",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone it should be, I think. Ping @evanphx @samkottler @dwradcliffe",
  "id" : 495674051822497793,
  "in_reply_to_status_id" : 495673712126218241,
  "created_at" : "2014-08-02 20:54:37 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 56, 67 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/495598133209235456\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/4mvRwx5ztX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuC33ofIEAAhGvD.jpg",
      "id_str" : "495598125399412736",
      "id" : 495598125399412736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuC33ofIEAAhGvD.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4mvRwx5ztX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.0658814946, -80.1037077081 ]
  },
  "id_str" : "495598133209235456",
  "text" : "Ralph is moonlighting on menus at fast food chains. \/cc @thoughtbot http:\/\/t.co\/4mvRwx5ztX",
  "id" : 495598133209235456,
  "created_at" : "2014-08-02 15:52:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "Grayson Wright",
      "screen_name" : "grayson_wright",
      "indices" : [ 17, 32 ],
      "id_str" : "16683371",
      "id" : 16683371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495504533129555969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244547803, -78.8792814688 ]
  },
  "id_str" : "495538666760966144",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase @grayson_wright true story",
  "id" : 495538666760966144,
  "in_reply_to_status_id" : 495504533129555969,
  "created_at" : "2014-08-02 11:56:39 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wolf pupy",
      "screen_name" : "wolfpupy",
      "indices" : [ 3, 12 ],
      "id_str" : "159121042",
      "id" : 159121042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495538372782194688",
  "text" : "RT @wolfpupy: once the baby dogs hatch from their eggs and dig out of the sand they instinctively know to head towards the ocean. nature is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495515833955659777",
    "text" : "once the baby dogs hatch from their eggs and dig out of the sand they instinctively know to head towards the ocean. nature is amazing",
    "id" : 495515833955659777,
    "created_at" : "2014-08-02 10:25:55 +0000",
    "user" : {
      "name" : "wolf pupy",
      "screen_name" : "wolfpupy",
      "protected" : false,
      "id_str" : "159121042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558529208448581633\/6XlAEnKF_normal.png",
      "id" : 159121042,
      "verified" : false
    }
  },
  "id" : 495538372782194688,
  "created_at" : "2014-08-02 11:55:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495361741963137024",
  "geo" : { },
  "id_str" : "495402981114667008",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt realizing this is complaining without action...sorry to be a bummer. I'll try to come up with some counterexamples.",
  "id" : 495402981114667008,
  "in_reply_to_status_id" : 495361741963137024,
  "created_at" : "2014-08-02 02:57:29 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495361741963137024",
  "geo" : { },
  "id_str" : "495362325302353920",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt Sure, that works. I think it's a combination of 5 different indent levels and 3 brackets in strange locations. Maybe Swift's fault",
  "id" : 495362325302353920,
  "in_reply_to_status_id" : 495361741963137024,
  "created_at" : "2014-08-02 00:15:56 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495286362032320513",
  "geo" : { },
  "id_str" : "495361327175438336",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt Love the curl output option and other goodies. Nice!",
  "id" : 495361327175438336,
  "in_reply_to_status_id" : 495286362032320513,
  "created_at" : "2014-08-02 00:11:58 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Jo9d3HPqEC",
      "expanded_url" : "https:\/\/github.com\/Alamofire\/Alamofire#downloading-a-file",
      "display_url" : "github.com\/Alamofire\/Alam\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "495286362032320513",
  "geo" : { },
  "id_str" : "495361198636797952",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt Not sure yet. Examples like this are very difficult to read though: https:\/\/t.co\/Jo9d3HPqEC",
  "id" : 495361198636797952,
  "in_reply_to_status_id" : 495286362032320513,
  "created_at" : "2014-08-02 00:11:27 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Statler City",
      "screen_name" : "StatlerCity",
      "indices" : [ 0, 12 ],
      "id_str" : "382817306",
      "id" : 382817306
    }, {
      "name" : "Paula's Donuts",
      "screen_name" : "PaulasDonuts",
      "indices" : [ 13, 26 ],
      "id_str" : "739385342",
      "id" : 739385342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495193476620111872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9251057189, -78.8783727866 ]
  },
  "id_str" : "495195630042497025",
  "in_reply_to_user_id" : 382817306,
  "text" : "@StatlerCity @PaulasDonuts Yes!!!",
  "id" : 495195630042497025,
  "in_reply_to_status_id" : 495193476620111872,
  "created_at" : "2014-08-01 13:13:33 +0000",
  "in_reply_to_screen_name" : "StatlerCity",
  "in_reply_to_user_id_str" : "382817306",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
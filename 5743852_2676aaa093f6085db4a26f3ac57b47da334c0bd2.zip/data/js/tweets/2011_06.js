Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86615754144882689",
  "text" : "Current status: http:\/\/endlessax.com\/",
  "id" : 86615754144882689,
  "created_at" : "2011-07-01 02:02:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86599164317810688",
  "geo" : { },
  "id_str" : "86613594036383745",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath to date this is the most fucked up thing about ruby, imo",
  "id" : 86613594036383745,
  "in_reply_to_status_id" : 86599164317810688,
  "created_at" : "2011-07-01 01:54:24 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86473243468369921",
  "text" : "bundle install --make-my-shit-work-please-without-asking-twice",
  "id" : 86473243468369921,
  "created_at" : "2011-06-30 16:36:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Zygmuntowicz",
      "screen_name" : "ezmobius",
      "indices" : [ 0, 9 ],
      "id_str" : "3560241",
      "id" : 3560241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86201883403878401",
  "geo" : { },
  "id_str" : "86219123729760257",
  "in_reply_to_user_id" : 3560241,
  "text" : "@ezmobius did vmware force you to patent it? How could this possibly help?",
  "id" : 86219123729760257,
  "in_reply_to_status_id" : 86201883403878401,
  "created_at" : "2011-06-29 23:46:55 +0000",
  "in_reply_to_screen_name" : "ezmobius",
  "in_reply_to_user_id_str" : "3560241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86156105222328321",
  "text" : "alias -g bake='bundle exec rake'",
  "id" : 86156105222328321,
  "created_at" : "2011-06-29 19:36:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GiT DiFF RAFF",
      "screen_name" : "CLINT",
      "indices" : [ 0, 6 ],
      "id_str" : "45993",
      "id" : 45993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85029005568380928",
  "geo" : { },
  "id_str" : "85877135566323712",
  "in_reply_to_user_id" : 45993,
  "text" : "@clint no. let us know if you're having issues at help.rubygems.org please!",
  "id" : 85877135566323712,
  "in_reply_to_status_id" : 85029005568380928,
  "created_at" : "2011-06-29 01:07:59 +0000",
  "in_reply_to_screen_name" : "CLINT",
  "in_reply_to_user_id_str" : "45993",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85874088819695616",
  "text" : "On the way back from Nantucket! WILL VISIT AGAIN A+++++",
  "id" : 85874088819695616,
  "created_at" : "2011-06-29 00:55:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85784066309361665",
  "text" : "Current status: http:\/\/yfrog.com\/khl8uekj",
  "id" : 85784066309361665,
  "created_at" : "2011-06-28 18:58:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85719993119019008",
  "text" : "I am so sick of rake activation errors.",
  "id" : 85719993119019008,
  "created_at" : "2011-06-28 14:43:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/31dR17d",
      "expanded_url" : "http:\/\/mlkshk.com\/r\/3ZZ5",
      "display_url" : "mlkshk.com\/r\/3ZZ5"
    } ]
  },
  "geo" : { },
  "id_str" : "85706794470617088",
  "text" : "The first Bills touchdown of the year: http:\/\/t.co\/31dR17d",
  "id" : 85706794470617088,
  "created_at" : "2011-06-28 13:51:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 74, 85 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85464280744476672",
  "geo" : { },
  "id_str" : "85470636218126336",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini it does, on Arel::Table. You're confusing AR with Arel :) \/cc @tenderlove",
  "id" : 85470636218126336,
  "in_reply_to_status_id" : 85464280744476672,
  "created_at" : "2011-06-27 22:12:42 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85419063500742656",
  "geo" : { },
  "id_str" : "85419571107987456",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen tbh i'd rather see ruby style interpolation. $s(\"one plus one is #\u007B1 + 1\u007D\")",
  "id" : 85419571107987456,
  "in_reply_to_status_id" : 85419063500742656,
  "created_at" : "2011-06-27 18:49:47 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B",
      "screen_name" : "CesarioGW",
      "indices" : [ 0, 10 ],
      "id_str" : "451327214",
      "id" : 451327214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85418795526660096",
  "geo" : { },
  "id_str" : "85419003857747968",
  "in_reply_to_user_id" : 48102727,
  "text" : "@CesarioGW ha, sure. i need your email!",
  "id" : 85419003857747968,
  "in_reply_to_status_id" : 85418795526660096,
  "created_at" : "2011-06-27 18:47:32 +0000",
  "in_reply_to_screen_name" : "franckverrot",
  "in_reply_to_user_id_str" : "48102727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 18, 27 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85418381158793216",
  "text" : "3 more invites to @irccloud to any followers who don't have one yet, and have a funny image to share. (and your email!)",
  "id" : 85418381158793216,
  "created_at" : "2011-06-27 18:45:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85384852798582784",
  "geo" : { },
  "id_str" : "85388828155719680",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez got a sample\/gist of the output? Definitely will help with decreasing load from MONITOR on high traffic instances",
  "id" : 85388828155719680,
  "in_reply_to_status_id" : 85384852798582784,
  "created_at" : "2011-06-27 16:47:37 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/1tx6Mxc",
      "expanded_url" : "http:\/\/i.imgur.com\/4lZhj.jpg",
      "display_url" : "i.imgur.com\/4lZhj.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "85367501822767105",
  "text" : "Current status: http:\/\/t.co\/1tx6Mxc",
  "id" : 85367501822767105,
  "created_at" : "2011-06-27 15:22:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seana q.",
      "screen_name" : "ladysauce",
      "indices" : [ 0, 10 ],
      "id_str" : "14955094",
      "id" : 14955094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85353137258504192",
  "geo" : { },
  "id_str" : "85360942338162689",
  "in_reply_to_user_id" : 14955094,
  "text" : "@ladysauce heh, that was near the watch factory in waltham",
  "id" : 85360942338162689,
  "in_reply_to_status_id" : 85353137258504192,
  "created_at" : "2011-06-27 14:56:49 +0000",
  "in_reply_to_screen_name" : "ladysauce",
  "in_reply_to_user_id_str" : "14955094",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85358231106502656",
  "text" : "Current status: http:\/\/yfrog.com\/kkpfyoj",
  "id" : 85358231106502656,
  "created_at" : "2011-06-27 14:46:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85351703200808960",
  "text" : "From the walk this morning, I wonder if either of these work... http:\/\/yfrog.com\/khfsdxj",
  "id" : 85351703200808960,
  "created_at" : "2011-06-27 14:20:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85338358947119106",
  "geo" : { },
  "id_str" : "85342073804435456",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh identify from imagemagick?",
  "id" : 85342073804435456,
  "in_reply_to_status_id" : 85338358947119106,
  "created_at" : "2011-06-27 13:41:50 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/XywPuep",
      "expanded_url" : "http:\/\/i.imgur.com\/r8JSC.jpg",
      "display_url" : "i.imgur.com\/r8JSC.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "85158972830646272",
  "text" : "Current dog status: http:\/\/t.co\/XywPuep",
  "id" : 85158972830646272,
  "created_at" : "2011-06-27 01:34:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 0, 7 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85087411285131264",
  "geo" : { },
  "id_str" : "85105029375201280",
  "in_reply_to_user_id" : 1566201,
  "text" : "@zapnap awesome, but how are you going to pay all the licensing fees for the lyrics? (Why the other sites suck, since ads pay for it)",
  "id" : 85105029375201280,
  "in_reply_to_status_id" : 85087411285131264,
  "created_at" : "2011-06-26 21:59:54 +0000",
  "in_reply_to_screen_name" : "zapnap",
  "in_reply_to_user_id_str" : "1566201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85069907494043648",
  "text" : "This is by far the strangest Catholic procession I've come across. http:\/\/yfrog.com\/hs1u0mpdj",
  "id" : 85069907494043648,
  "created_at" : "2011-06-26 19:40:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85047864702681088",
  "text" : "Saw a real Ruby! http:\/\/yfrog.com\/khy8fsj",
  "id" : 85047864702681088,
  "created_at" : "2011-06-26 18:12:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 3, 13 ],
      "id_str" : "220097555",
      "id" : 220097555
    }, {
      "name" : "Redis To Go",
      "screen_name" : "redistogo",
      "indices" : [ 21, 31 ],
      "id_str" : "164181615",
      "id" : 164181615
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 35, 42 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http:\/\/t.co\/IStKDhd",
      "expanded_url" : "https:\/\/github.com\/thoughtbot\/radish-heroku",
      "display_url" : "github.com\/thoughtbot\/rad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84363376452567040",
  "text" : "RT @radishapp: Using @redistogo on @heroku? Now you can use Radish too! http:\/\/t.co\/IStKDhd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Redis To Go",
        "screen_name" : "redistogo",
        "indices" : [ 6, 16 ],
        "id_str" : "164181615",
        "id" : 164181615
      }, {
        "name" : "Heroku",
        "screen_name" : "heroku",
        "indices" : [ 20, 27 ],
        "id_str" : "10257182",
        "id" : 10257182
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 76 ],
        "url" : "http:\/\/t.co\/IStKDhd",
        "expanded_url" : "https:\/\/github.com\/thoughtbot\/radish-heroku",
        "display_url" : "github.com\/thoughtbot\/rad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "84363240888475648",
    "text" : "Using @redistogo on @heroku? Now you can use Radish too! http:\/\/t.co\/IStKDhd",
    "id" : 84363240888475648,
    "created_at" : "2011-06-24 20:52:18 +0000",
    "user" : {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "protected" : false,
      "id_str" : "220097555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268075541\/radish_small_normal.png",
      "id" : 220097555,
      "verified" : false
    }
  },
  "id" : 84363376452567040,
  "created_at" : "2011-06-24 20:52:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 56, 64 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 65, 72 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 73, 83 ],
      "id_str" : "14575143",
      "id" : 14575143
    }, {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 84, 93 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http:\/\/t.co\/JMSwslG",
      "expanded_url" : "http:\/\/bostonography.com\/2011\/cantabrigian-namesakes\/",
      "display_url" : "bostonography.com\/2011\/cantabrig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84083784387018752",
  "text" : "Cambridge folks will love this. http:\/\/t.co\/JMSwslG \/cc @jayunit @Croaky @joeferris @ubuwaits",
  "id" : 84083784387018752,
  "created_at" : "2011-06-24 02:21:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/Ze21fyZ",
      "expanded_url" : "http:\/\/29.media.tumblr.com\/tumblr_ll4kcltDYH1qjvsoxo1_r2_500.png",
      "display_url" : "29.media.tumblr.com\/tumblr_ll4kclt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84080668849610752",
  "text" : "Current status: http:\/\/t.co\/Ze21fyZ",
  "id" : 84080668849610752,
  "created_at" : "2011-06-24 02:09:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84035806125228032",
  "geo" : { },
  "id_str" : "84038011343482880",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD its sad, but I thought this was actually in Boston.",
  "id" : 84038011343482880,
  "in_reply_to_status_id" : 84035806125228032,
  "created_at" : "2011-06-23 23:19:57 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 3, 12 ],
      "id_str" : "729936824",
      "id" : 729936824
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 70, 78 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83921576650735616",
  "text" : "RT @hgimenez: \"Redis stands for making things with sets in Italian\" - @jayunit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Morrison",
        "screen_name" : "jayunit",
        "indices" : [ 56, 64 ],
        "id_str" : "14238213",
        "id" : 14238213
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83919014987956224",
    "text" : "\"Redis stands for making things with sets in Italian\" - @jayunit",
    "id" : 83919014987956224,
    "created_at" : "2011-06-23 15:27:06 +0000",
    "user" : {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "protected" : false,
      "id_str" : "24425454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491047783214747648\/6czBp_vy_normal.jpeg",
      "id" : 24425454,
      "verified" : false
    }
  },
  "id" : 83921576650735616,
  "created_at" : "2011-06-23 15:37:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/o6Io8Kv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=O6VAU-1qE5Y",
      "display_url" : "youtube.com\/watch?v=O6VAU-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83920836171538434",
  "text" : "Hardcore pair programming: http:\/\/t.co\/o6Io8Kv",
  "id" : 83920836171538434,
  "created_at" : "2011-06-23 15:34:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 0, 12 ],
      "id_str" : "10687942",
      "id" : 10687942
    }, {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 13, 20 ],
      "id_str" : "6753782",
      "id" : 6753782
    }, {
      "name" : "Joel Watson",
      "screen_name" : "watsonian",
      "indices" : [ 21, 31 ],
      "id_str" : "7696262",
      "id" : 7696262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83683109857542144",
  "geo" : { },
  "id_str" : "83683401181302784",
  "in_reply_to_user_id" : 10687942,
  "text" : "@hotgazpacho @sartak @watsonian ideally something between a wiki and twitter. hmm..",
  "id" : 83683401181302784,
  "in_reply_to_status_id" : 83683109857542144,
  "created_at" : "2011-06-22 23:50:52 +0000",
  "in_reply_to_screen_name" : "hotgazpacho",
  "in_reply_to_user_id_str" : "10687942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    }, {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 10, 17 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83664885845721088",
  "geo" : { },
  "id_str" : "83676288782573569",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez @mwhuss we're getting other exceptions though :?",
  "id" : 83676288782573569,
  "in_reply_to_status_id" : 83664885845721088,
  "created_at" : "2011-06-22 23:22:36 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83672209662541824",
  "text" : "Are there any apps that help with tracking learning (like bits of knowledge) for a team?",
  "id" : 83672209662541824,
  "created_at" : "2011-06-22 23:06:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83615530958860288",
  "geo" : { },
  "id_str" : "83615811998191616",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham we are using hoptoad actively, but it is not reporting this error, i have no idea how or why it happens :(",
  "id" : 83615811998191616,
  "in_reply_to_status_id" : 83615530958860288,
  "created_at" : "2011-06-22 19:22:17 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 109, 117 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83590728269299712",
  "geo" : { },
  "id_str" : "83611501604241409",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham what username\/email? Can you make a request on help.rubygems.org? I can never reproduce this :( \/cc @sikachu",
  "id" : 83611501604241409,
  "in_reply_to_status_id" : 83590728269299712,
  "created_at" : "2011-06-22 19:05:10 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan Horrocks",
      "screen_name" : "dylanhorrocks",
      "indices" : [ 3, 17 ],
      "id_str" : "16090858",
      "id" : 16090858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83495886742757376",
  "text" : "RT @dylanhorrocks: The Onion covers all the big stories. At once. http:\/\/onion.com\/m2XMVL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83279925913726976",
    "text" : "The Onion covers all the big stories. At once. http:\/\/onion.com\/m2XMVL",
    "id" : 83279925913726976,
    "created_at" : "2011-06-21 21:07:36 +0000",
    "user" : {
      "name" : "Dylan Horrocks",
      "screen_name" : "dylanhorrocks",
      "protected" : false,
      "id_str" : "16090858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552948701342097408\/unTsIIsr_normal.jpeg",
      "id" : 16090858,
      "verified" : false
    }
  },
  "id" : 83495886742757376,
  "created_at" : "2011-06-22 11:25:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83367775732633600",
  "geo" : { },
  "id_str" : "83368696063602688",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton SNAPE KILLS DUMBLEDORE",
  "id" : 83368696063602688,
  "in_reply_to_status_id" : 83367775732633600,
  "created_at" : "2011-06-22 03:00:20 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83310377886167043",
  "text" : "Turns out puppies with a giant plastic cone attached to their head are way more annoying than just puppies.",
  "id" : 83310377886167043,
  "created_at" : "2011-06-21 23:08:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83306135934865408",
  "geo" : { },
  "id_str" : "83309612811554817",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss np! Come back to Boston soon!",
  "id" : 83309612811554817,
  "in_reply_to_status_id" : 83306135934865408,
  "created_at" : "2011-06-21 23:05:34 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83237924660981760",
  "text" : "Fuck base64 image encoding and everything about it. This makes the web worse.",
  "id" : 83237924660981760,
  "created_at" : "2011-06-21 18:20:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 29 ],
      "url" : "http:\/\/t.co\/ftd5tdV",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Armand_de_Brignac",
      "display_url" : "en.wikipedia.org\/wiki\/Armand_de\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "83206677431730176",
  "geo" : { },
  "id_str" : "83222212982747136",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant http:\/\/t.co\/ftd5tdV",
  "id" : 83222212982747136,
  "in_reply_to_status_id" : 83206677431730176,
  "created_at" : "2011-06-21 17:18:16 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/iEXhJgL",
      "expanded_url" : "http:\/\/coedbc.files.wordpress.com\/2011\/06\/bruins-foxwoods-2.jpg",
      "display_url" : "coedbc.files.wordpress.com\/2011\/06\/bruins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83220979098193920",
  "text" : "Drinkin' out of Lord Stanley LIKE A BOSS. http:\/\/t.co\/iEXhJgL",
  "id" : 83220979098193920,
  "created_at" : "2011-06-21 17:13:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/zivEizb",
      "expanded_url" : "http:\/\/bostinnovation.com\/2011\/06\/21\/boston-bruins-156679-74-bar-tab-receipt-image\/",
      "display_url" : "bostinnovation.com\/2011\/06\/21\/bos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83204516010401792",
  "text" : "Apparently winning the Cup means you can drink $150,000 in 4 hours. http:\/\/t.co\/zivEizb",
  "id" : 83204516010401792,
  "created_at" : "2011-06-21 16:07:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83202496146833408",
  "geo" : { },
  "id_str" : "83204369897623552",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius 1 bottle of champagne comped!",
  "id" : 83204369897623552,
  "in_reply_to_status_id" : 83202496146833408,
  "created_at" : "2011-06-21 16:07:22 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83196950240968705",
  "text" : "Firefox 5 doesn't work with Selenium. Firefail? Failfox?",
  "id" : 83196950240968705,
  "created_at" : "2011-06-21 15:37:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82961022218018816",
  "geo" : { },
  "id_str" : "82964688861802498",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits its that kind of Monday!",
  "id" : 82964688861802498,
  "in_reply_to_status_id" : 82961022218018816,
  "created_at" : "2011-06-21 00:14:57 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82853271777198080",
  "geo" : { },
  "id_str" : "82888075172261889",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik moving pictures still is my fav. Signals too.",
  "id" : 82888075172261889,
  "in_reply_to_status_id" : 82853271777198080,
  "created_at" : "2011-06-20 19:10:31 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 30 ],
      "url" : "http:\/\/t.co\/bjpFczD",
      "expanded_url" : "https:\/\/gist.github.com\/1036314",
      "display_url" : "gist.github.com\/1036314"
    } ]
  },
  "geo" : { },
  "id_str" : "82886956182282240",
  "text" : "*facepalm* http:\/\/t.co\/bjpFczD",
  "id" : 82886956182282240,
  "created_at" : "2011-06-20 19:06:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Fults",
      "screen_name" : "h3h",
      "indices" : [ 0, 4 ],
      "id_str" : "59503",
      "id" : 59503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82834424969957378",
  "geo" : { },
  "id_str" : "82847887230382080",
  "in_reply_to_user_id" : 59503,
  "text" : "@h3h thanks! Definitely a work in progress.",
  "id" : 82847887230382080,
  "in_reply_to_status_id" : 82834424969957378,
  "created_at" : "2011-06-20 16:30:50 +0000",
  "in_reply_to_screen_name" : "h3h",
  "in_reply_to_user_id_str" : "59503",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyalert",
      "screen_name" : "rubyalert",
      "indices" : [ 3, 13 ],
      "id_str" : "279514715",
      "id" : 279514715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82831341045035008",
  "text" : "RT @rubyalert: Make your own gem - RubyGems Guides:  http:\/\/bit.ly\/kkPScw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82740023312646144",
    "text" : "Make your own gem - RubyGems Guides:  http:\/\/bit.ly\/kkPScw",
    "id" : 82740023312646144,
    "created_at" : "2011-06-20 09:22:13 +0000",
    "user" : {
      "name" : "rubyalert",
      "screen_name" : "rubyalert",
      "protected" : false,
      "id_str" : "279514715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1305480594\/ruby_normal.png",
      "id" : 279514715,
      "verified" : false
    }
  },
  "id" : 82831341045035008,
  "created_at" : "2011-06-20 15:25:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82562262962929664",
  "geo" : { },
  "id_str" : "82831074589278208",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich er, that's 3 syllables. fail.",
  "id" : 82831074589278208,
  "in_reply_to_status_id" : 82562262962929664,
  "created_at" : "2011-06-20 15:24:01 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82562262962929664",
  "geo" : { },
  "id_str" : "82830952027521024",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich gemcutter? :P",
  "id" : 82830952027521024,
  "in_reply_to_status_id" : 82562262962929664,
  "created_at" : "2011-06-20 15:23:32 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82830703963815936",
  "geo" : { },
  "id_str" : "82830860151291905",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv time for a flash site and some SWEET TUNES",
  "id" : 82830860151291905,
  "in_reply_to_status_id" : 82830703963815936,
  "created_at" : "2011-06-20 15:23:10 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82828849406160896",
  "text" : "\"X SaaS at $Y\/mo is expensive, so I wrote my own, Z, now available at $Y\/[2,3,4] the price!\" Why don't software devs value their own time?",
  "id" : 82828849406160896,
  "created_at" : "2011-06-20 15:15:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/G21Z1WR",
      "expanded_url" : "http:\/\/29.media.tumblr.com\/tumblr_lmwt2vuuOb1qjvsoxo1_500.png",
      "display_url" : "29.media.tumblr.com\/tumblr_lmwt2vu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "82813648774508544",
  "text" : "Current status: http:\/\/t.co\/G21Z1WR",
  "id" : 82813648774508544,
  "created_at" : "2011-06-20 14:14:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Exceptional Ruby",
      "screen_name" : "exceptionalruby",
      "indices" : [ 39, 55 ],
      "id_str" : "289199497",
      "id" : 289199497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82795076270555136",
  "text" : "Seriously, read through a big chunk of @exceptionalruby on the commute this morning and learned a lot about Ruby. Get it.",
  "id" : 82795076270555136,
  "created_at" : "2011-06-20 13:00:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "hoptoad",
      "screen_name" : "hoptoad",
      "indices" : [ 25, 33 ],
      "id_str" : "7703562",
      "id" : 7703562
    }, {
      "name" : "Exceptional Ruby",
      "screen_name" : "exceptionalruby",
      "indices" : [ 51, 67 ],
      "id_str" : "289199497",
      "id" : 289199497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82794892870426624",
  "text" : "RT @avdi: Still got some @hoptoad coupons left for @exceptionalruby buyers: http:\/\/exceptionalruby.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hoptoad",
        "screen_name" : "hoptoad",
        "indices" : [ 15, 23 ],
        "id_str" : "7703562",
        "id" : 7703562
      }, {
        "name" : "Exceptional Ruby",
        "screen_name" : "exceptionalruby",
        "indices" : [ 41, 57 ],
        "id_str" : "289199497",
        "id" : 289199497
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82779781913001984",
    "text" : "Still got some @hoptoad coupons left for @exceptionalruby buyers: http:\/\/exceptionalruby.com",
    "id" : 82779781913001984,
    "created_at" : "2011-06-20 12:00:12 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 82794892870426624,
  "created_at" : "2011-06-20 13:00:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 10, 22 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82736122849017856",
  "geo" : { },
  "id_str" : "82794665518178304",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage @seacreature later versions of RG will not help. have you tried the bundler prerelease?",
  "id" : 82794665518178304,
  "in_reply_to_status_id" : 82736122849017856,
  "created_at" : "2011-06-20 12:59:21 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82654742584635392",
  "text" : "Trying out words with friends again... My handle is now 'qrush40' !!",
  "id" : 82654742584635392,
  "created_at" : "2011-06-20 03:43:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82632720936738816",
  "text" : "Started Lost & Damned, forced to be some biker's bitch and had to see a low polygon count penis. WTF and why can't I stop playing it?",
  "id" : 82632720936738816,
  "created_at" : "2011-06-20 02:15:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82491366856339458",
  "text" : "Beat Ballad of Gay Tony...why couldn't all of GTA4 be that awesome?",
  "id" : 82491366856339458,
  "created_at" : "2011-06-19 16:54:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 3, 12 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82270095606415361",
  "text" : "RT @rtomayko: I've been hoping someone would write this git-pull-request program since we shipped Pull Requests 2.0: http:\/\/bit.ly\/mETGU ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82269037534511105",
    "text" : "I've been hoping someone would write this git-pull-request program since we shipped Pull Requests 2.0: http:\/\/bit.ly\/mETGUS - Looks perfect.",
    "id" : 82269037534511105,
    "created_at" : "2011-06-19 02:10:41 +0000",
    "user" : {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "protected" : false,
      "id_str" : "9267332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3109364645\/f89b77ce2f3afa72fdc3ca7e08f3c4f9_normal.png",
      "id" : 9267332,
      "verified" : false
    }
  },
  "id" : 82270095606415361,
  "created_at" : "2011-06-19 02:14:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82268926427414528",
  "text" : "The music for Ocarina of Time always gets to me. They really don't make music for games like this anymore.",
  "id" : 82268926427414528,
  "created_at" : "2011-06-19 02:10:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82157092559011841",
  "geo" : { },
  "id_str" : "82164830710145024",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense he better rape and pillage something",
  "id" : 82164830710145024,
  "in_reply_to_status_id" : 82157092559011841,
  "created_at" : "2011-06-18 19:16:36 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Johnson",
      "screen_name" : "traviscj",
      "indices" : [ 0, 9 ],
      "id_str" : "13980272",
      "id" : 13980272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82151781387337728",
  "geo" : { },
  "id_str" : "82164713580011520",
  "in_reply_to_user_id" : 13980272,
  "text" : "@traviscj thanks dude! Glad someone does :)",
  "id" : 82164713580011520,
  "in_reply_to_status_id" : 82151781387337728,
  "created_at" : "2011-06-18 19:16:08 +0000",
  "in_reply_to_screen_name" : "traviscj",
  "in_reply_to_user_id_str" : "13980272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicol\u00E1s Hock Isaza",
      "screen_name" : "nhocki",
      "indices" : [ 0, 7 ],
      "id_str" : "85498700",
      "id" : 85498700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82158412644880384",
  "geo" : { },
  "id_str" : "82164637323370496",
  "in_reply_to_user_id" : 85498700,
  "text" : "@nhocki craigslist, hotpads",
  "id" : 82164637323370496,
  "in_reply_to_status_id" : 82158412644880384,
  "created_at" : "2011-06-18 19:15:50 +0000",
  "in_reply_to_screen_name" : "nhocki",
  "in_reply_to_user_id_str" : "85498700",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81780022720991233",
  "geo" : { },
  "id_str" : "81780416054435842",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh that load is on all S3\/cloudfront, so, BRING IT",
  "id" : 81780416054435842,
  "in_reply_to_status_id" : 81780022720991233,
  "created_at" : "2011-06-17 17:49:05 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81777947379376128",
  "geo" : { },
  "id_str" : "81779651009183744",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh no, patches welcome :)",
  "id" : 81779651009183744,
  "in_reply_to_status_id" : 81777947379376128,
  "created_at" : "2011-06-17 17:46:02 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/fCCl2fQ",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/LittleMonsterJudas#p\/u\/14\/ynkhrn2bCo4",
      "display_url" : "youtube.com\/user\/LittleMon\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "81503970366984192",
  "geo" : { },
  "id_str" : "81507001183641600",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft even better http:\/\/t.co\/fCCl2fQ",
  "id" : 81507001183641600,
  "in_reply_to_status_id" : 81503970366984192,
  "created_at" : "2011-06-16 23:42:38 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81467209611878400",
  "text" : "Just discovered `cal` ! Fuck that iCal thing. `cal 2011` BOOM",
  "id" : 81467209611878400,
  "created_at" : "2011-06-16 21:04:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81462478898343936",
  "geo" : { },
  "id_str" : "81463235315892224",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej not happening here.",
  "id" : 81463235315892224,
  "in_reply_to_status_id" : 81462478898343936,
  "created_at" : "2011-06-16 20:48:43 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81461203490181121",
  "geo" : { },
  "id_str" : "81462315735719936",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej what rubygems errors?",
  "id" : 81462315735719936,
  "in_reply_to_status_id" : 81461203490181121,
  "created_at" : "2011-06-16 20:45:04 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81452797387747328",
  "text" : "Completed 200 OK in 1023909ms",
  "id" : 81452797387747328,
  "created_at" : "2011-06-16 20:07:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/6fddtLZ",
      "expanded_url" : "http:\/\/www.lamosca.info\/maps\/",
      "display_url" : "lamosca.info\/maps\/"
    } ]
  },
  "geo" : { },
  "id_str" : "81391009040314369",
  "text" : "Loving this map of NY: http:\/\/t.co\/6fddtLZ",
  "id" : 81391009040314369,
  "created_at" : "2011-06-16 16:01:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "indices" : [ 0, 8 ],
      "id_str" : "14587814",
      "id" : 14587814
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 63, 73 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81253114442821633",
  "geo" : { },
  "id_str" : "81382079409037312",
  "in_reply_to_user_id" : 14587814,
  "text" : "@jlecour looks fine now...and there's no caching whatsoever on @gemcutter ;)",
  "id" : 81382079409037312,
  "in_reply_to_status_id" : 81253114442821633,
  "created_at" : "2011-06-16 15:26:14 +0000",
  "in_reply_to_screen_name" : "jlecour",
  "in_reply_to_user_id_str" : "14587814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/IqvynLl",
      "expanded_url" : "http:\/\/higo.herokuapp.com\/",
      "display_url" : "higo.herokuapp.com"
    }, {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/cG1hJJU",
      "expanded_url" : "https:\/\/github.com\/qrush\/higo",
      "display_url" : "github.com\/qrush\/higo"
    } ]
  },
  "geo" : { },
  "id_str" : "81212633914679297",
  "text" : "Well, a deploy worked! http:\/\/t.co\/IqvynLl Pushed the code up if you're curious. http:\/\/t.co\/cG1hJJU",
  "id" : 81212633914679297,
  "created_at" : "2011-06-16 04:12:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 13, 20 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81209256279425025",
  "text" : "I gotta say, @heroku's cedar stack is awesome. irb actually *works* !",
  "id" : 81209256279425025,
  "created_at" : "2011-06-16 03:59:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 56, 63 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http:\/\/t.co\/21NjfNq",
      "expanded_url" : "http:\/\/golang.org\/",
      "display_url" : "golang.org"
    }, {
      "indices" : [ 74, 93 ],
      "url" : "http:\/\/t.co\/IqvynLl",
      "expanded_url" : "http:\/\/higo.herokuapp.com\/",
      "display_url" : "higo.herokuapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "81208599321382913",
  "text" : "This page was rendered with Go (http:\/\/t.co\/21NjfNq) on @heroku. Muahaha! http:\/\/t.co\/IqvynLl Blog post soon!",
  "id" : 81208599321382913,
  "created_at" : "2011-06-16 03:56:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81179736130338816",
  "text" : "Read every @KERMlT tweet, say it in Kermit's voice. Instant hilarity.",
  "id" : 81179736130338816,
  "created_at" : "2011-06-16 02:02:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81122863293280256",
  "text" : "Puppy ingested radio power cord plug. Tempted to hook up an antenna to see if he'll transmit NPR.",
  "id" : 81122863293280256,
  "created_at" : "2011-06-15 22:16:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81060944607838208",
  "text" : "Programming is hard, let's go bikeshedding!",
  "id" : 81060944607838208,
  "created_at" : "2011-06-15 18:10:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 98, 107 ],
      "id_str" : "14506011",
      "id" : 14506011
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 108, 116 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/ZYTrRPP",
      "expanded_url" : "http:\/\/bit.ly\/jdimlk",
      "display_url" : "bit.ly\/jdimlk"
    } ]
  },
  "geo" : { },
  "id_str" : "81015801620082688",
  "text" : "It's sad that I have to refer to this ~3 year old article on Rails date formats. WTB Rails Guide, @ryanbigg @sikachu! http:\/\/t.co\/ZYTrRPP",
  "id" : 81015801620082688,
  "created_at" : "2011-06-15 15:10:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 23, 32 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80730392667242496",
  "text" : "Hey, I just got 3 more @irccloud invites. Funny picture + your email = invite.",
  "id" : 80730392667242496,
  "created_at" : "2011-06-14 20:16:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80716969518698496",
  "geo" : { },
  "id_str" : "80720728722374657",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv fuck you i'm an anteater",
  "id" : 80720728722374657,
  "in_reply_to_status_id" : 80716969518698496,
  "created_at" : "2011-06-14 19:38:16 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80680962735882241",
  "geo" : { },
  "id_str" : "80683928209457152",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant definitely considering going. let's learn some shit.",
  "id" : 80683928209457152,
  "in_reply_to_status_id" : 80680962735882241,
  "created_at" : "2011-06-14 17:12:02 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80679172946669568",
  "geo" : { },
  "id_str" : "80679837286678528",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant never too late to learn bro.",
  "id" : 80679837286678528,
  "in_reply_to_status_id" : 80679172946669568,
  "created_at" : "2011-06-14 16:55:46 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/wOf904c",
      "expanded_url" : "http:\/\/amzn.to\/iGXpfr",
      "display_url" : "amzn.to\/iGXpfr"
    } ]
  },
  "geo" : { },
  "id_str" : "80677537289744384",
  "text" : "RT @bquarant Samuel L Jackson narrates the audiobook of \"Go the F**K to SLEEP\". Get it free at:  http:\/\/t.co\/wOf904c",
  "id" : 80677537289744384,
  "created_at" : "2011-06-14 16:46:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/zVybHXf",
      "expanded_url" : "http:\/\/www.asciiflow.com\/",
      "display_url" : "asciiflow.com"
    } ]
  },
  "geo" : { },
  "id_str" : "80657890561638400",
  "text" : "Someone needs to adapt http:\/\/t.co\/zVybHXf to make custom NetHack levels. NOW.",
  "id" : 80657890561638400,
  "created_at" : "2011-06-14 15:28:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 12, 17 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 29, 40 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 62 ],
      "url" : "http:\/\/t.co\/trHPvzy",
      "expanded_url" : "http:\/\/codeulate.com\/2011\/06\/programmer-resumes-are-deprecated\/",
      "display_url" : "codeulate.com\/2011\/06\/progra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80645396149448705",
  "text" : "Pumped that @r00k is joining @thoughtbot!! http:\/\/t.co\/trHPvzy",
  "id" : 80645396149448705,
  "created_at" : "2011-06-14 14:38:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/bIOi2eS",
      "expanded_url" : "http:\/\/codeulate.com\/2011\/06\/programmer-resumes-are-deprecated\/",
      "display_url" : "codeulate.com\/2011\/06\/progra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80645281892405248",
  "text" : "RT @r00k: No, really: programmer resumes are deprecated. http:\/\/t.co\/bIOi2eS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 66 ],
        "url" : "http:\/\/t.co\/bIOi2eS",
        "expanded_url" : "http:\/\/codeulate.com\/2011\/06\/programmer-resumes-are-deprecated\/",
        "display_url" : "codeulate.com\/2011\/06\/progra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "80644819684298752",
    "text" : "No, really: programmer resumes are deprecated. http:\/\/t.co\/bIOi2eS",
    "id" : 80644819684298752,
    "created_at" : "2011-06-14 14:36:37 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 80645281892405248,
  "created_at" : "2011-06-14 14:38:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/DaAZu95",
      "expanded_url" : "https:\/\/github.com\/flori\/json\/issues\/68",
      "display_url" : "github.com\/flori\/json\/iss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80642331329564673",
  "text" : "Is anyone else seeing this JSON issue? http:\/\/t.co\/DaAZu95",
  "id" : 80642331329564673,
  "created_at" : "2011-06-14 14:26:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http:\/\/t.co\/0Ls0Br7",
      "expanded_url" : "http:\/\/paper.li\/",
      "display_url" : "paper.li"
    } ]
  },
  "geo" : { },
  "id_str" : "80436990159486977",
  "text" : "Do sites like http:\/\/t.co\/0Ls0Br7 exist solely to be the dirty hobo anus of the internet on purpose?",
  "id" : 80436990159486977,
  "created_at" : "2011-06-14 00:50:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80394089878667264",
  "geo" : { },
  "id_str" : "80396861457960960",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw write your own? :)",
  "id" : 80396861457960960,
  "in_reply_to_status_id" : 80394089878667264,
  "created_at" : "2011-06-13 22:11:20 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 0, 10 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80328852638924801",
  "geo" : { },
  "id_str" : "80329084470693889",
  "in_reply_to_user_id" : 116526817,
  "text" : "@JeffLinse lol you work for that company",
  "id" : 80329084470693889,
  "in_reply_to_status_id" : 80328852638924801,
  "created_at" : "2011-06-13 17:42:00 +0000",
  "in_reply_to_screen_name" : "JeffLinse",
  "in_reply_to_user_id_str" : "116526817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Krailo",
      "screen_name" : "ckrailo",
      "indices" : [ 0, 8 ],
      "id_str" : "15608533",
      "id" : 15608533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/kmY9lVK",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/2729333530\/fetching-source-index-for-http-rubygems-org",
      "display_url" : "robots.thoughtbot.com\/post\/272933353\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "80319107551076352",
  "geo" : { },
  "id_str" : "80323912193425408",
  "in_reply_to_user_id" : 15608533,
  "text" : "@ckrailo have you read http:\/\/t.co\/kmY9lVK ?",
  "id" : 80323912193425408,
  "in_reply_to_status_id" : 80319107551076352,
  "created_at" : "2011-06-13 17:21:27 +0000",
  "in_reply_to_screen_name" : "ckrailo",
  "in_reply_to_user_id_str" : "15608533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80303038786572289",
  "text" : "Finally started playing the GTA4 expansions this weekend. So good. Really glad they didn't keep going with Nico.",
  "id" : 80303038786572289,
  "created_at" : "2011-06-13 15:58:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 9, 22 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/nMolAbv",
      "expanded_url" : "http:\/\/www.penny-arcade.com\/comic\/2011\/6\/10\/",
      "display_url" : "penny-arcade.com\/comic\/2011\/6\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80300627124686848",
  "text" : "I'm sure @codemastermm has seen this, but rofl. http:\/\/t.co\/nMolAbv",
  "id" : 80300627124686848,
  "created_at" : "2011-06-13 15:48:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 3, 13 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/muiOEXe",
      "expanded_url" : "https:\/\/github.com\/mkrecny\/redis-extend",
      "display_url" : "github.com\/mkrecny\/redis-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80290436744351744",
  "text" : "RT @radishapp: redis-extend is getting really interesting, now includes PATTERNOP (run a command on a pattern of keys): http:\/\/t.co\/muiOEXe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 124 ],
        "url" : "http:\/\/t.co\/muiOEXe",
        "expanded_url" : "https:\/\/github.com\/mkrecny\/redis-extend",
        "display_url" : "github.com\/mkrecny\/redis-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "80288810755293185",
    "text" : "redis-extend is getting really interesting, now includes PATTERNOP (run a command on a pattern of keys): http:\/\/t.co\/muiOEXe",
    "id" : 80288810755293185,
    "created_at" : "2011-06-13 15:01:58 +0000",
    "user" : {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "protected" : false,
      "id_str" : "220097555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268075541\/radish_small_normal.png",
      "id" : 220097555,
      "verified" : false
    }
  },
  "id" : 80290436744351744,
  "created_at" : "2011-06-13 15:08:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/sm65jUM",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/emptysquare\/5254693071\/",
      "display_url" : "flickr.com\/photos\/emptysq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80289779723419648",
  "text" : "Current status: http:\/\/t.co\/sm65jUM",
  "id" : 80289779723419648,
  "created_at" : "2011-06-13 15:05:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McGrath",
      "screen_name" : "ryanmcgrath",
      "indices" : [ 0, 12 ],
      "id_str" : "15833737",
      "id" : 15833737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80102897332916224",
  "geo" : { },
  "id_str" : "80287859944333312",
  "in_reply_to_user_id" : 15833737,
  "text" : "@ryanmcgrath hey can you open a request on help.rubygems.org?",
  "id" : 80287859944333312,
  "in_reply_to_status_id" : 80102897332916224,
  "created_at" : "2011-06-13 14:58:12 +0000",
  "in_reply_to_screen_name" : "ryanmcgrath",
  "in_reply_to_user_id_str" : "15833737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 37, 44 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "to_s",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80097509346770944",
  "text" : "Solved it by #to_s'ing both. Shitty. @tsaleh i'm on rspec!",
  "id" : 80097509346770944,
  "created_at" : "2011-06-13 02:21:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/QvpkKKY",
      "expanded_url" : "https:\/\/gist.github.com\/1022230",
      "display_url" : "gist.github.com\/1022230"
    } ]
  },
  "geo" : { },
  "id_str" : "80094810479935488",
  "text" : "Fuck you, Time. http:\/\/t.co\/QvpkKKY",
  "id" : 80094810479935488,
  "created_at" : "2011-06-13 02:11:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/Vh9iPMu",
      "expanded_url" : "http:\/\/27.media.tumblr.com\/tumblr_lmnwdxoX4P1qjmniro1_500.gif",
      "display_url" : "27.media.tumblr.com\/tumblr_lmnwdxo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80073283818618880",
  "text" : "Current status: http:\/\/t.co\/Vh9iPMu",
  "id" : 80073283818618880,
  "created_at" : "2011-06-13 00:45:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79972356315033600",
  "geo" : { },
  "id_str" : "79985681191022592",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect uh, sure? for what?",
  "id" : 79985681191022592,
  "in_reply_to_status_id" : 79972356315033600,
  "created_at" : "2011-06-12 18:57:27 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http:\/\/t.co\/Wx9T6Oa",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=21OH0wlkfbc",
      "display_url" : "youtube.com\/watch?v=21OH0w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "79952628414562304",
  "geo" : { },
  "id_str" : "79954724362792960",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza http:\/\/t.co\/Wx9T6Oa is so much better",
  "id" : 79954724362792960,
  "in_reply_to_status_id" : 79952628414562304,
  "created_at" : "2011-06-12 16:54:26 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MongoHQ, the elder",
      "screen_name" : "mongohq",
      "indices" : [ 67, 75 ],
      "id_str" : "2511331628",
      "id" : 2511331628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79645107535618049",
  "text" : "Blerg, mongodb facepalm #2 of the day, can't rename collections on @mongohq. Support issue started, but wtf?",
  "id" : 79645107535618049,
  "created_at" : "2011-06-11 20:24:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Gunderson",
      "screen_name" : "ethangunderson",
      "indices" : [ 0, 15 ],
      "id_str" : "14412520",
      "id" : 14412520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79627000456822784",
  "geo" : { },
  "id_str" : "79629153686650880",
  "in_reply_to_user_id" : 14412520,
  "text" : "@ethangunderson i want to expand capped collection size, so no",
  "id" : 79629153686650880,
  "in_reply_to_status_id" : 79627000456822784,
  "created_at" : "2011-06-11 19:20:44 +0000",
  "in_reply_to_screen_name" : "ethangunderson",
  "in_reply_to_user_id_str" : "14412520",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Brown",
      "screen_name" : "tebrown",
      "indices" : [ 3, 11 ],
      "id_str" : "15411370",
      "id" : 15411370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79628956223012864",
  "text" : "RT @tebrown: Wow: http:\/\/bit.ly\/iCDQp2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79601221685620736",
    "text" : "Wow: http:\/\/bit.ly\/iCDQp2",
    "id" : 79601221685620736,
    "created_at" : "2011-06-11 17:29:44 +0000",
    "user" : {
      "name" : "Travis Brown",
      "screen_name" : "tebrown",
      "protected" : false,
      "id_str" : "15411370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771315252\/teb_normal.jpg",
      "id" : 15411370,
      "verified" : false
    }
  },
  "id" : 79628956223012864,
  "created_at" : "2011-06-11 19:19:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Gunderson",
      "screen_name" : "ethangunderson",
      "indices" : [ 0, 15 ],
      "id_str" : "14412520",
      "id" : 14412520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79623041826566144",
  "geo" : { },
  "id_str" : "79625589220311040",
  "in_reply_to_user_id" : 14412520,
  "text" : "@ethangunderson that function is neat but it does not take the `max` argument. why are capped collections second class citizens in mongo :(",
  "id" : 79625589220311040,
  "in_reply_to_status_id" : 79623041826566144,
  "created_at" : "2011-06-11 19:06:34 +0000",
  "in_reply_to_screen_name" : "ethangunderson",
  "in_reply_to_user_id_str" : "14412520",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/MpBzDaK",
      "expanded_url" : "http:\/\/bit.ly\/iE3Rui",
      "display_url" : "bit.ly\/iE3Rui"
    } ]
  },
  "geo" : { },
  "id_str" : "79624131703877633",
  "text" : "If you don't `rake db:migrate:redo` or `remigrate`, well, that's stupid. http:\/\/t.co\/MpBzDaK",
  "id" : 79624131703877633,
  "created_at" : "2011-06-11 19:00:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79621515263483904",
  "text" : "MongoDB facepalm of the day #1: it mongorestore does not restore capped collection size (or that a collection was even capped)",
  "id" : 79621515263483904,
  "created_at" : "2011-06-11 18:50:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/awYlR98",
      "expanded_url" : "http:\/\/i.imgur.com\/kCMqy.gif",
      "display_url" : "i.imgur.com\/kCMqy.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "79616008834392064",
  "text" : "Current status: http:\/\/t.co\/awYlR98",
  "id" : 79616008834392064,
  "created_at" : "2011-06-11 18:28:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79593520352083969",
  "text" : "I give up. gem \"rake\", \"0.8.7\" in gemfile, all versions of rake nuked from my system and 0.9.2 still gets installed",
  "id" : 79593520352083969,
  "created_at" : "2011-06-11 16:59:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79592480164683776",
  "text" : "Just nuked every version of Rake on my system so I could stop getting the 0.9.2 errors. :( Someday I'll rewrite it!",
  "id" : 79592480164683776,
  "created_at" : "2011-06-11 16:55:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79554174186041346",
  "geo" : { },
  "id_str" : "79563498643927040",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant A+++",
  "id" : 79563498643927040,
  "in_reply_to_status_id" : 79554174186041346,
  "created_at" : "2011-06-11 14:59:50 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 37, 43 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79375738993774592",
  "geo" : { },
  "id_str" : "79377725470679040",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude i'm tempted to register @mwn3d and just tweet as him. or we could both do that. \/cc @ablissfulgal",
  "id" : 79377725470679040,
  "in_reply_to_status_id" : 79375738993774592,
  "created_at" : "2011-06-11 02:41:39 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79372745477066752",
  "geo" : { },
  "id_str" : "79375411884212224",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude por que no los dos?",
  "id" : 79375411884212224,
  "in_reply_to_status_id" : 79372745477066752,
  "created_at" : "2011-06-11 02:32:27 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79363399024263168",
  "geo" : { },
  "id_str" : "79363451893448704",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton YAY GODPHONE",
  "id" : 79363451893448704,
  "in_reply_to_status_id" : 79363399024263168,
  "created_at" : "2011-06-11 01:44:56 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79357701485895680",
  "geo" : { },
  "id_str" : "79358148804214785",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey probably use :methods =&gt; [:errors] instead",
  "id" : 79358148804214785,
  "in_reply_to_status_id" : 79357701485895680,
  "created_at" : "2011-06-11 01:23:51 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79357016728014848",
  "text" : "Pumped to be watching Tanev on ice for the Canucks!",
  "id" : 79357016728014848,
  "created_at" : "2011-06-11 01:19:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79341322917519360",
  "geo" : { },
  "id_str" : "79355168965140480",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv ME GUSTA",
  "id" : 79355168965140480,
  "in_reply_to_status_id" : 79341322917519360,
  "created_at" : "2011-06-11 01:12:01 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79353111659024384",
  "geo" : { },
  "id_str" : "79353319138668544",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh never yaml",
  "id" : 79353319138668544,
  "in_reply_to_status_id" : 79353111659024384,
  "created_at" : "2011-06-11 01:04:40 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 44, 50 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/mCA9cLR",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/mkdevo",
      "display_url" : "youtube.com\/user\/mkdevo"
    } ]
  },
  "geo" : { },
  "id_str" : "79351924641640448",
  "text" : "Wow, this is some ridiculously high quality @phish: http:\/\/t.co\/mCA9cLR",
  "id" : 79351924641640448,
  "created_at" : "2011-06-11 00:59:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79303143049003008",
  "geo" : { },
  "id_str" : "79309469028335616",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape haha are you joking",
  "id" : 79309469028335616,
  "in_reply_to_status_id" : 79303143049003008,
  "created_at" : "2011-06-10 22:10:25 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheil (Em) Smith",
      "screen_name" : "miksago",
      "indices" : [ 0, 8 ],
      "id_str" : "14063149",
      "id" : 14063149
    }, {
      "name" : "Pusher (now @pusher)",
      "screen_name" : "pusherapp",
      "indices" : [ 46, 56 ],
      "id_str" : "444855740",
      "id" : 444855740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79222575904985088",
  "geo" : { },
  "id_str" : "79223745021083648",
  "in_reply_to_user_id" : 14063149,
  "text" : "@miksago yeah we definitely would love to use @pusherapp, but we had to ship first! How are you guys liking it? Any feedback?",
  "id" : 79223745021083648,
  "in_reply_to_status_id" : 79222575904985088,
  "created_at" : "2011-06-10 16:29:47 +0000",
  "in_reply_to_screen_name" : "miksago",
  "in_reply_to_user_id_str" : "14063149",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Williams",
      "screen_name" : "voodootikigod",
      "indices" : [ 0, 14 ],
      "id_str" : "637763",
      "id" : 637763
    }, {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 15, 25 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    }, {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 118, 128 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79180444423299073",
  "geo" : { },
  "id_str" : "79185292652847104",
  "in_reply_to_user_id" : 637763,
  "text" : "@voodootikigod @sprsquish ok, but can I share code between Ruby and Node via C? (i.e., hiredis w\/ custom behavior for @radishapp)",
  "id" : 79185292652847104,
  "in_reply_to_status_id" : 79180444423299073,
  "created_at" : "2011-06-10 13:56:59 +0000",
  "in_reply_to_screen_name" : "voodootikigod",
  "in_reply_to_user_id_str" : "637763",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/Fx9NabP",
      "expanded_url" : "http:\/\/twitpic.com\/59euaf\/full",
      "display_url" : "twitpic.com\/59euaf\/full"
    } ]
  },
  "geo" : { },
  "id_str" : "79184761721069568",
  "text" : "Wow, amazing timing of a lighting strike in Boston: http:\/\/t.co\/Fx9NabP",
  "id" : 79184761721069568,
  "created_at" : "2011-06-10 13:54:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 35, 45 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79175041719336963",
  "geo" : { },
  "id_str" : "79176862500265984",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez hurray! For 2.4? Users of @radishapp will love this",
  "id" : 79176862500265984,
  "in_reply_to_status_id" : 79175041719336963,
  "created_at" : "2011-06-10 13:23:29 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79176450992902144",
  "text" : "Is it possible to share C extensions between Ruby and Node.js? (Can Node even interop with C through NPM?)",
  "id" : 79176450992902144,
  "created_at" : "2011-06-10 13:21:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "karlseguin",
      "screen_name" : "karlseguin",
      "indices" : [ 0, 11 ],
      "id_str" : "15930954",
      "id" : 15930954
    }, {
      "name" : "Justin Etheredge",
      "screen_name" : "JustinEtheredge",
      "indices" : [ 12, 28 ],
      "id_str" : "10165302",
      "id" : 10165302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78969450321293312",
  "geo" : { },
  "id_str" : "79162969669382144",
  "in_reply_to_user_id" : 15930954,
  "text" : "@karlseguin @JustinEtheredge how...how is that even possible, unless one truly does not give a fuck",
  "id" : 79162969669382144,
  "in_reply_to_status_id" : 78969450321293312,
  "created_at" : "2011-06-10 12:28:17 +0000",
  "in_reply_to_screen_name" : "karlseguin",
  "in_reply_to_user_id_str" : "15930954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78979640638701568",
  "geo" : { },
  "id_str" : "78985484990291968",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier hahahah @ablissfulgal sent me this same picture today",
  "id" : 78985484990291968,
  "in_reply_to_status_id" : 78979640638701568,
  "created_at" : "2011-06-10 00:43:01 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78955454243409920",
  "text" : "Holy fuck, housebreaking this pup is difficult. Does this get easier?",
  "id" : 78955454243409920,
  "created_at" : "2011-06-09 22:43:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78760425218510848",
  "geo" : { },
  "id_str" : "78944660990590977",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg yeah dude. are you using bundle --local ?",
  "id" : 78944660990590977,
  "in_reply_to_status_id" : 78760425218510848,
  "created_at" : "2011-06-09 22:00:48 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78940284012068867",
  "text" : "Current status: http:\/\/robrimes.files.wordpress.com\/2011\/06\/r184380_684542.jpg",
  "id" : 78940284012068867,
  "created_at" : "2011-06-09 21:43:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/QEkmWLA",
      "expanded_url" : "http:\/\/bostinnovation.com\/2011\/06\/09\/lessons-learned-from-3-saas-launches-in-2011\/",
      "display_url" : "bostinnovation.com\/2011\/06\/09\/les\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "78871401934766080",
  "text" : "RT @thoughtbot: Some stuff we did & didn't do during 3 SaaS launches in 2011 http:\/\/t.co\/QEkmWLA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 80 ],
        "url" : "http:\/\/t.co\/QEkmWLA",
        "expanded_url" : "http:\/\/bostinnovation.com\/2011\/06\/09\/lessons-learned-from-3-saas-launches-in-2011\/",
        "display_url" : "bostinnovation.com\/2011\/06\/09\/les\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "78855924701339648",
    "text" : "Some stuff we did & didn't do during 3 SaaS launches in 2011 http:\/\/t.co\/QEkmWLA",
    "id" : 78855924701339648,
    "created_at" : "2011-06-09 16:08:12 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 78871401934766080,
  "created_at" : "2011-06-09 17:09:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/bsbzVZO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=2a4gyJsY0mc",
      "display_url" : "youtube.com\/watch?v=2a4gyJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "78836048125374464",
  "text" : "Current status: http:\/\/t.co\/bsbzVZO",
  "id" : 78836048125374464,
  "created_at" : "2011-06-09 14:49:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/TFOySrs",
      "expanded_url" : "http:\/\/i.imgur.com\/qo0eX.jpg",
      "display_url" : "i.imgur.com\/qo0eX.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "78631637054799872",
  "text" : "Current status: http:\/\/t.co\/TFOySrs",
  "id" : 78631637054799872,
  "created_at" : "2011-06-09 01:16:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tyler_jennings",
      "screen_name" : "tyler_jennings",
      "indices" : [ 3, 18 ],
      "id_str" : "10249342",
      "id" : 10249342
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78539889536286720",
  "text" : "RT @tyler_jennings: Hey #ruby dudes, \"composition over inheritance\" called \/ wants to remind you that modules are inheritance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ruby",
        "indices" : [ 4, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10701600305713154",
    "text" : "Hey #ruby dudes, \"composition over inheritance\" called \/ wants to remind you that modules are inheritance.",
    "id" : 10701600305713154,
    "created_at" : "2010-12-03 14:27:14 +0000",
    "user" : {
      "name" : "tyler_jennings",
      "screen_name" : "tyler_jennings",
      "protected" : false,
      "id_str" : "10249342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480457202101006336\/O1rpBUEL_normal.jpeg",
      "id" : 10249342,
      "verified" : false
    }
  },
  "id" : 78539889536286720,
  "created_at" : "2011-06-08 19:12:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 21, 29 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 31, 37 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 39, 49 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78527675806908416",
  "text" : "Invites doled out to @evanphx, @cmeik, @stevelosh. They send out new ones frequently, so don't fret!",
  "id" : 78527675806908416,
  "created_at" : "2011-06-08 18:23:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 91, 100 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78526143447318528",
  "text" : "Also, I need your email too to send the invite...that too. Funny picture + email + reply = @irccloud invite.",
  "id" : 78526143447318528,
  "created_at" : "2011-06-08 18:17:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 9, 18 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78525872843399168",
  "text" : "I have 3 @irccloud invites, who wants one? You must reply with a funny picture to get it, first 3 win!",
  "id" : 78525872843399168,
  "created_at" : "2011-06-08 18:16:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78523420165414912",
  "geo" : { },
  "id_str" : "78524450638794752",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi also we tend not to perma-delete gems unless if *absolutely* necessary (passwords, takedowns, etc)",
  "id" : 78524450638794752,
  "in_reply_to_status_id" : 78523420165414912,
  "created_at" : "2011-06-08 18:11:02 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78523420165414912",
  "geo" : { },
  "id_str" : "78524353439989760",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi can you open a request on help.rubygems.org please? i have a lot of these to handle and little time",
  "id" : 78524353439989760,
  "in_reply_to_status_id" : 78523420165414912,
  "created_at" : "2011-06-08 18:10:39 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78524224855228417",
  "text" : "RT @thoughtbot: Learn about Redis' Pub\/Sub, and how it works! http:\/\/bit.ly\/jTQTNF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78523314909364224",
    "text" : "Learn about Redis' Pub\/Sub, and how it works! http:\/\/bit.ly\/jTQTNF",
    "id" : 78523314909364224,
    "created_at" : "2011-06-08 18:06:31 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 78524224855228417,
  "created_at" : "2011-06-08 18:10:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78490552206757889",
  "text" : "Call me crazy, but I want syntax highlighting within git diffs.",
  "id" : 78490552206757889,
  "created_at" : "2011-06-08 15:56:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78486735679524865",
  "geo" : { },
  "id_str" : "78488870928388096",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen i like, but Why Is YourCase All MessedUp?",
  "id" : 78488870928388096,
  "in_reply_to_status_id" : 78486735679524865,
  "created_at" : "2011-06-08 15:49:39 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BB Calrissian",
      "screen_name" : "mattpodwysocki",
      "indices" : [ 0, 15 ],
      "id_str" : "12699642",
      "id" : 12699642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78483970941128704",
  "geo" : { },
  "id_str" : "78484967751036929",
  "in_reply_to_user_id" : 12699642,
  "text" : "@mattpodwysocki documentation page uses comic sans, immediate quit",
  "id" : 78484967751036929,
  "in_reply_to_status_id" : 78483970941128704,
  "created_at" : "2011-06-08 15:34:09 +0000",
  "in_reply_to_screen_name" : "mattpodwysocki",
  "in_reply_to_user_id_str" : "12699642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78483956214923264",
  "text" : "Wow, damn, I hope this works well: http:\/\/sinonjs.org\/",
  "id" : 78483956214923264,
  "created_at" : "2011-06-08 15:30:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 6, 15 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 59, 66 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78248641197899776",
  "text" : "Woot! @rubygems is moving off the rubyforge bug tracker to @github issues. Contribute! You have one less thing to complain about now!",
  "id" : 78248641197899776,
  "created_at" : "2011-06-07 23:55:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.992665817, -71.22036135 ]
  },
  "id_str" : "78242927532445696",
  "text" : "Made it for #phish! @ Comcast Center http:\/\/gowal.la\/c\/4oqWc",
  "id" : 78242927532445696,
  "created_at" : "2011-06-07 23:32:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78242403953291266",
  "text" : "Phish!!",
  "id" : 78242403953291266,
  "created_at" : "2011-06-07 23:30:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Kane Parker",
      "screen_name" : "moonmaster9000",
      "indices" : [ 0, 15 ],
      "id_str" : "14391298",
      "id" : 14391298
    }, {
      "name" : "Allen Madsen",
      "screen_name" : "blatyo",
      "indices" : [ 16, 23 ],
      "id_str" : "14188909",
      "id" : 14188909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78093639603068928",
  "geo" : { },
  "id_str" : "78102013631672320",
  "in_reply_to_user_id" : 14391298,
  "text" : "@moonmaster9000 @blatyo fixed",
  "id" : 78102013631672320,
  "in_reply_to_status_id" : 78093639603068928,
  "created_at" : "2011-06-07 14:12:25 +0000",
  "in_reply_to_screen_name" : "moonmaster9000",
  "in_reply_to_user_id_str" : "14391298",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Madsen",
      "screen_name" : "blatyo",
      "indices" : [ 0, 7 ],
      "id_str" : "14188909",
      "id" : 14188909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78054031230124033",
  "geo" : { },
  "id_str" : "78057939205750784",
  "in_reply_to_user_id" : 14188909,
  "text" : "@blatyo github issues works. Please say what browser\/os",
  "id" : 78057939205750784,
  "in_reply_to_status_id" : 78054031230124033,
  "created_at" : "2011-06-07 11:17:17 +0000",
  "in_reply_to_screen_name" : "blatyo",
  "in_reply_to_user_id_str" : "14188909",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77904660693917696",
  "text" : "Brought home someone else tonight! Say hi to Geddy! http:\/\/yfrog.com\/5p2dnwj",
  "id" : 77904660693917696,
  "created_at" : "2011-06-07 01:08:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77789801021054976",
  "geo" : { },
  "id_str" : "77792440618192896",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi have you looked at the commit graph for rails since they started using the merge button?",
  "id" : 77792440618192896,
  "in_reply_to_status_id" : 77789801021054976,
  "created_at" : "2011-06-06 17:42:17 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77788784212709376",
  "text" : "Not going well, --abort --abort !! Shaving this yak another day.",
  "id" : 77788784212709376,
  "created_at" : "2011-06-06 17:27:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 105, 112 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77787687117012994",
  "text" : "Ok, going way back to 2004 was dumb, since the history is all linear there anyway. Rewinding to 2008 pre-@github instead.",
  "id" : 77787687117012994,
  "created_at" : "2011-06-06 17:23:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77784237327122433",
  "text" : "Really glad I ran `time` with this rebase...it's HUGE",
  "id" : 77784237327122433,
  "created_at" : "2011-06-06 17:09:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77782197540618240",
  "geo" : { },
  "id_str" : "77782479255240705",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy COUNTER-RETORT http:\/\/bash.org\/?23396",
  "id" : 77782479255240705,
  "in_reply_to_status_id" : 77782197540618240,
  "created_at" : "2011-06-06 17:02:42 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77781675391717376",
  "text" : "Rebasing rails master off of the first commit from DHH in 2004 to see how ridiculous this turns out.",
  "id" : 77781675391717376,
  "created_at" : "2011-06-06 16:59:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77771846279372800",
  "text" : "Seriously, rails. Please use rebase instead of merge: http:\/\/robots.thoughtbot.com\/post\/165641717\/rebase-like-a-boss :(",
  "id" : 77771846279372800,
  "created_at" : "2011-06-06 16:20:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77771620265115648",
  "text" : "History in large git projects should be as linear as possible. Merge commits cause confusion and clutter up history: http:\/\/bit.ly\/iAOaM4",
  "id" : 77771620265115648,
  "created_at" : "2011-06-06 16:19:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77770774508871680",
  "text" : "The GitHub merge button is nice and all, but it's made the Rails git repo look terrible and confusing in gitx\/gitk.",
  "id" : 77770774508871680,
  "created_at" : "2011-06-06 16:16:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 3, 13 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77743122112720896",
  "text" : "RT @radishapp: Week 2 starting, now analyzing over 15,000 #redis commands\/sec on average. Keep it coming!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "redis",
        "indices" : [ 43, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77730744813891584",
    "text" : "Week 2 starting, now analyzing over 15,000 #redis commands\/sec on average. Keep it coming!",
    "id" : 77730744813891584,
    "created_at" : "2011-06-06 13:37:08 +0000",
    "user" : {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "protected" : false,
      "id_str" : "220097555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268075541\/radish_small_normal.png",
      "id" : 220097555,
      "verified" : false
    }
  },
  "id" : 77743122112720896,
  "created_at" : "2011-06-06 14:26:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77720086005288960",
  "geo" : { },
  "id_str" : "77721998104596481",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant haha noooo!",
  "id" : 77721998104596481,
  "in_reply_to_status_id" : 77720086005288960,
  "created_at" : "2011-06-06 13:02:23 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77700365180612608",
  "text" : "Another reason to kill passwords: people suck at making them. http:\/\/bit.ly\/jUyIN2",
  "id" : 77700365180612608,
  "created_at" : "2011-06-06 11:36:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77583462642618368",
  "geo" : { },
  "id_str" : "77583660861243393",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick damn those benchmarks aren't far off...",
  "id" : 77583660861243393,
  "in_reply_to_status_id" : 77583462642618368,
  "created_at" : "2011-06-06 03:52:40 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77220927653421056",
  "text" : "Beat Portal 2. Worth it.",
  "id" : 77220927653421056,
  "created_at" : "2011-06-05 03:51:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77084625784160256",
  "geo" : { },
  "id_str" : "77087916484075521",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit do want!",
  "id" : 77087916484075521,
  "in_reply_to_status_id" : 77084625784160256,
  "created_at" : "2011-06-04 19:02:46 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76868883889405952",
  "geo" : { },
  "id_str" : "76876884142600192",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope oh, duh",
  "id" : 76876884142600192,
  "in_reply_to_status_id" : 76868883889405952,
  "created_at" : "2011-06-04 05:04:12 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 65, 72 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76858816498634753",
  "text" : "How...how did this work!!!?! https:\/\/gist.github.com\/1007556 \/cc @github",
  "id" : 76858816498634753,
  "created_at" : "2011-06-04 03:52:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Mallory",
      "screen_name" : "jakemallory",
      "indices" : [ 0, 12 ],
      "id_str" : "14227832",
      "id" : 14227832
    }, {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 81, 88 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76787991972020225",
  "geo" : { },
  "id_str" : "76794793056935936",
  "in_reply_to_user_id" : 14227832,
  "text" : "@jakemallory hey, can you open a request on http:\/\/help.apptrajectory.com\/ ? \/cc @cpytel",
  "id" : 76794793056935936,
  "in_reply_to_status_id" : 76787991972020225,
  "created_at" : "2011-06-03 23:38:00 +0000",
  "in_reply_to_screen_name" : "jakemallory",
  "in_reply_to_user_id_str" : "14227832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simeon Willbanks",
      "screen_name" : "simeonwillbanks",
      "indices" : [ 0, 16 ],
      "id_str" : "95444818",
      "id" : 95444818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76717455824789504",
  "geo" : { },
  "id_str" : "76786155315666944",
  "in_reply_to_user_id" : 95444818,
  "text" : "@simeonwillbanks I'll toss them up soon...really deserves a blog post",
  "id" : 76786155315666944,
  "in_reply_to_status_id" : 76717455824789504,
  "created_at" : "2011-06-03 23:03:40 +0000",
  "in_reply_to_screen_name" : "simeonwillbanks",
  "in_reply_to_user_id_str" : "95444818",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 3, 13 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "Trajectory",
      "screen_name" : "apptrajectory",
      "indices" : [ 39, 53 ],
      "id_str" : "227333900",
      "id" : 227333900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76785918480101376",
  "text" : "RT @tehviking: You guys need to get on @apptrajectory. Now. Seriously.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trajectory",
        "screen_name" : "apptrajectory",
        "indices" : [ 24, 38 ],
        "id_str" : "227333900",
        "id" : 227333900
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76785516049203200",
    "text" : "You guys need to get on @apptrajectory. Now. Seriously.",
    "id" : 76785516049203200,
    "created_at" : "2011-06-03 23:01:08 +0000",
    "user" : {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "protected" : false,
      "id_str" : "59341538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431152612264509440\/r4L_jVW6_normal.jpeg",
      "id" : 59341538,
      "verified" : false
    }
  },
  "id" : 76785918480101376,
  "created_at" : "2011-06-03 23:02:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76783109584076800",
  "text" : "They never said \"no drinking High & Mighty\" on this bus. At least, that's how this guy is interpreting it. #mbta",
  "id" : 76783109584076800,
  "created_at" : "2011-06-03 22:51:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76714831230672896",
  "geo" : { },
  "id_str" : "76715485193969664",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape I AM SHOCKED AND APPALLED",
  "id" : 76715485193969664,
  "in_reply_to_status_id" : 76714831230672896,
  "created_at" : "2011-06-03 18:22:51 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76710197715935234",
  "geo" : { },
  "id_str" : "76714407622742016",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik congrats, now do you have to rewrite all of your EventMachine into Python or C++? :P",
  "id" : 76714407622742016,
  "in_reply_to_status_id" : 76710197715935234,
  "created_at" : "2011-06-03 18:18:34 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 55, 62 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76713142134120448",
  "text" : "Oh man. http:\/\/www.youtube.com\/watch?v=BV9Xuw0Sojg \/cc @Croaky",
  "id" : 76713142134120448,
  "created_at" : "2011-06-03 18:13:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76712385339068416",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=sAWl5peI8HY",
  "id" : 76712385339068416,
  "created_at" : "2011-06-03 18:10:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 28, 38 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76677153323876352",
  "text" : "http:\/\/heeeeeeeey.com\/ (via @kevinburg)",
  "id" : 76677153323876352,
  "created_at" : "2011-06-03 15:50:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76674933098430464",
  "text" : "% rvm disk-usage all | tail -1\nTotal Disk Usage: 13G",
  "id" : 76674933098430464,
  "created_at" : "2011-06-03 15:41:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 3, 13 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76639883766140928",
  "text" : "RT @radishapp: Deep example of using Redis' Lua scripting branch to make new commands (and use Redis as a triple store!) http:\/\/bit.ly\/j ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76639532367364096",
    "text" : "Deep example of using Redis' Lua scripting branch to make new commands (and use Redis as a triple store!) http:\/\/bit.ly\/jbvoj0",
    "id" : 76639532367364096,
    "created_at" : "2011-06-03 13:21:03 +0000",
    "user" : {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "protected" : false,
      "id_str" : "220097555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268075541\/radish_small_normal.png",
      "id" : 220097555,
      "verified" : false
    }
  },
  "id" : 76639883766140928,
  "created_at" : "2011-06-03 13:22:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76456891462590465",
  "geo" : { },
  "id_str" : "76457151274549248",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight haha, not mine. So tiny!",
  "id" : 76457151274549248,
  "in_reply_to_status_id" : 76456891462590465,
  "created_at" : "2011-06-03 01:16:20 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76453968611512321",
  "text" : "Current status: http:\/\/yfrog.com\/5px11jj",
  "id" : 76453968611512321,
  "created_at" : "2011-06-03 01:03:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76359414898098177",
  "geo" : { },
  "id_str" : "76362871906373634",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman time to found yogapantshub?",
  "id" : 76362871906373634,
  "in_reply_to_status_id" : 76359414898098177,
  "created_at" : "2011-06-02 19:01:42 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76327148322951168",
  "text" : "@seacreature the whole point here is that none of that should have had happened, not that they've been fixed",
  "id" : 76327148322951168,
  "created_at" : "2011-06-02 16:39:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    }, {
      "name" : "hone",
      "screen_name" : "hone",
      "indices" : [ 50, 55 ],
      "id_str" : "6637242",
      "id" : 6637242
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 56, 65 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 66, 73 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76318096645820416",
  "text" : "@seacreature really, is it? i'd like to hear from @hone @indirect @lsegal that it is",
  "id" : 76318096645820416,
  "created_at" : "2011-06-02 16:03:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76317074447798272",
  "text" : "@seacreature everything else that ever used it. Bundler, YARD, Rails, the works.",
  "id" : 76317074447798272,
  "created_at" : "2011-06-02 15:59:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76316678153179136",
  "text" : "@seacreature https:\/\/gist.github.com\/1004684 :(",
  "id" : 76316678153179136,
  "created_at" : "2011-06-02 15:58:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 6, 18 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76281398306148352",
  "geo" : { },
  "id_str" : "76282874743099393",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @seacreature I also added a ton of docs recently for the guides site. More will come.",
  "id" : 76282874743099393,
  "in_reply_to_status_id" : 76281398306148352,
  "created_at" : "2011-06-02 13:43:49 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76271129542672384",
  "text" : "Note to past self: \"downtown\" on the bus does not mean it goes downtown",
  "id" : 76271129542672384,
  "created_at" : "2011-06-02 12:57:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FML",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76270903268347904",
  "text" : "Yep, got on the wrong bus. #FML but heading into boston now, finally",
  "id" : 76270903268347904,
  "created_at" : "2011-06-02 12:56:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76268607448948736",
  "text" : "Oh god, I think I got on the wrong bus. Can I just restart this day over please?",
  "id" : 76268607448948736,
  "created_at" : "2011-06-02 12:47:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76265635327381504",
  "text" : "Well, fuck that train, got on an express bus instead.",
  "id" : 76265635327381504,
  "created_at" : "2011-06-02 12:35:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbcr",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76264638509096960",
  "text" : "Almost just watched cars get clobbered as this disabled train crawled through an intersection without the guards down. Stay classy, #mbcr.",
  "id" : 76264638509096960,
  "created_at" : "2011-06-02 12:31:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbcr",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76262163278348288",
  "text" : "20-25 min delays, now going to check the #mbcr site daily before leaving. *facepalm*",
  "id" : 76262163278348288,
  "created_at" : "2011-06-02 12:21:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "mbcr",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76260748145332224",
  "text" : "Commuter rail now over 15 minutes late, wtf. #mbta #mbcr at least make an announcement, we pay for this shit",
  "id" : 76260748145332224,
  "created_at" : "2011-06-02 12:15:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eaton",
      "screen_name" : "mjeaton",
      "indices" : [ 0, 8 ],
      "id_str" : "6440892",
      "id" : 6440892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76127668487208960",
  "geo" : { },
  "id_str" : "76129979271880705",
  "in_reply_to_user_id" : 6440892,
  "text" : "@mjeaton http:\/\/readthefuckinghig.tumblr.com\/",
  "id" : 76129979271880705,
  "in_reply_to_status_id" : 76127668487208960,
  "created_at" : "2011-06-02 03:36:16 +0000",
  "in_reply_to_screen_name" : "mjeaton",
  "in_reply_to_user_id_str" : "6440892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76105866889277440",
  "text" : "About time they played Rush at this game!!!",
  "id" : 76105866889277440,
  "created_at" : "2011-06-02 02:00:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76101954748678144",
  "text" : "Watching the Penalty Green Lantern Cup!",
  "id" : 76101954748678144,
  "created_at" : "2011-06-02 01:44:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 0, 12 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76096092286091264",
  "geo" : { },
  "id_str" : "76097107471241217",
  "in_reply_to_user_id" : 14838050,
  "text" : "@kylefiedler great odin's raven!",
  "id" : 76097107471241217,
  "in_reply_to_status_id" : 76096092286091264,
  "created_at" : "2011-06-02 01:25:38 +0000",
  "in_reply_to_screen_name" : "kylefiedler",
  "in_reply_to_user_id_str" : "14838050",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76094312730988546",
  "text" : "So much lightning. Definitely have never seen a supercell storm like this.",
  "id" : 76094312730988546,
  "created_at" : "2011-06-02 01:14:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76092974697693185",
  "text" : "Moving away from the windows....holy shit.",
  "id" : 76092974697693185,
  "created_at" : "2011-06-02 01:09:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76092773534662656",
  "text" : "Holy shit, this is getting serious here.",
  "id" : 76092773534662656,
  "created_at" : "2011-06-02 01:08:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76091644549660672",
  "text" : "Crazy lightning over Waltham right now...",
  "id" : 76091644549660672,
  "created_at" : "2011-06-02 01:03:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76080224378421248",
  "text" : "Oh lame, no Tanev for warmup :( Boohiss.",
  "id" : 76080224378421248,
  "created_at" : "2011-06-02 00:18:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76079977161957376",
  "text" : "Excited to watch RIT's Tanev in the Cup finals! http:\/\/en.wikipedia.org\/wiki\/Christopher_Tanev",
  "id" : 76079977161957376,
  "created_at" : "2011-06-02 00:17:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76079314877161472",
  "geo" : { },
  "id_str" : "76079434058309632",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock dude thats tornado sign. get the fuck inside",
  "id" : 76079434058309632,
  "in_reply_to_status_id" : 76079314877161472,
  "created_at" : "2011-06-02 00:15:25 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76055665696702464",
  "text" : "Current status: EPIC BAKED ZITI TIME",
  "id" : 76055665696702464,
  "created_at" : "2011-06-01 22:40:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76036043123601409",
  "text" : "Huge lightning bolts are huge!",
  "id" : 76036043123601409,
  "created_at" : "2011-06-01 21:23:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75901001214861312",
  "text" : "Goat Inventory Tracker: http:\/\/blog.prelode.com\/2011\/05\/goat-inventory-tracker\/",
  "id" : 75901001214861312,
  "created_at" : "2011-06-01 12:26:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
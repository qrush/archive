Grailbird.data.tweets_2015_03 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 33, 47 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573864993977950208",
  "text" : "A TV studio suddenly happened in @coworkbuffalo today",
  "id" : 573864993977950208,
  "created_at" : "2015-03-06 15:17:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573844050316369920",
  "text" : "Why isn't Arrested Development: The Musical a thing?",
  "id" : 573844050316369920,
  "created_at" : "2015-03-06 13:54:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/rHinSfufS7",
      "expanded_url" : "http:\/\/nl.linkedin.com\/pub\/rofl-copter\/58\/503\/825",
      "display_url" : "nl.linkedin.com\/pub\/rofl-copte\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "573825475925176320",
  "geo" : { },
  "id_str" : "573825749238460416",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn ooh better endorse some of these skills http:\/\/t.co\/rHinSfufS7",
  "id" : 573825749238460416,
  "in_reply_to_status_id" : 573825475925176320,
  "created_at" : "2015-03-06 12:41:34 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Priddle",
      "screen_name" : "itspriddle",
      "indices" : [ 0, 11 ],
      "id_str" : "14104108",
      "id" : 14104108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573724419811450881",
  "geo" : { },
  "id_str" : "573724611302457344",
  "in_reply_to_user_id" : 14104108,
  "text" : "@itspriddle same and it took me years to figure out Turtle Rock on Link's Awakening",
  "id" : 573724611302457344,
  "in_reply_to_status_id" : 573724419811450881,
  "created_at" : "2015-03-06 05:59:41 +0000",
  "in_reply_to_screen_name" : "itspriddle",
  "in_reply_to_user_id_str" : "14104108",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573716724719091713\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/MfxUkQSTMR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B_ZAUhWU8AAQQXs.png",
      "id_str" : "573716723829895168",
      "id" : 573716723829895168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B_ZAUhWU8AAQQXs.png",
      "sizes" : [ {
        "h" : 292,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 200
      } ],
      "display_url" : "pic.twitter.com\/MfxUkQSTMR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573715988421701632",
  "geo" : { },
  "id_str" : "573716724719091713",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant http:\/\/t.co\/MfxUkQSTMR",
  "id" : 573716724719091713,
  "in_reply_to_status_id" : 573715988421701632,
  "created_at" : "2015-03-06 05:28:20 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573714129090973696",
  "geo" : { },
  "id_str" : "573714260599009280",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant you could fit a tank through there",
  "id" : 573714260599009280,
  "in_reply_to_status_id" : 573714129090973696,
  "created_at" : "2015-03-06 05:18:33 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bradford do\u00A3\u00A3a sign",
      "screen_name" : "LusciousPear",
      "indices" : [ 0, 13 ],
      "id_str" : "15829680",
      "id" : 15829680
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573713196017577986\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/vwv615gBoS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Y9HIbUYAAQZw4.png",
      "id_str" : "573713195266760704",
      "id" : 573713195266760704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Y9HIbUYAAQZw4.png",
      "sizes" : [ {
        "h" : 75,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 996
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 996
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vwv615gBoS"
    } ],
    "hashtags" : [ {
      "text" : "tips",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573712557111840769",
  "geo" : { },
  "id_str" : "573713196017577986",
  "in_reply_to_user_id" : 15829680,
  "text" : "@LusciousPear huh, great #tips on this site http:\/\/t.co\/vwv615gBoS",
  "id" : 573713196017577986,
  "in_reply_to_status_id" : 573712557111840769,
  "created_at" : "2015-03-06 05:14:19 +0000",
  "in_reply_to_screen_name" : "LusciousPear",
  "in_reply_to_user_id_str" : "15829680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 56, 68 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573710148843106304",
  "geo" : { },
  "id_str" : "573711598100967424",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky nice! Kung Fu is headed this way in the summer. @AqueousBand is hitting CO for the first time next week...maybe SF soon!!!?",
  "id" : 573711598100967424,
  "in_reply_to_status_id" : 573710148843106304,
  "created_at" : "2015-03-06 05:07:58 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    }, {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 13, 23 ],
      "id_str" : "25103",
      "id" : 25103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573704581927952384",
  "geo" : { },
  "id_str" : "573704854779994112",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda @jessitron O(\uD83D\uDE45)",
  "id" : 573704854779994112,
  "in_reply_to_status_id" : 573704581927952384,
  "created_at" : "2015-03-06 04:41:10 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    }, {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 13, 23 ],
      "id_str" : "25103",
      "id" : 25103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573704338645782529",
  "geo" : { },
  "id_str" : "573704465116626944",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda @jessitron O(\u0192)",
  "id" : 573704465116626944,
  "in_reply_to_status_id" : 573704338645782529,
  "created_at" : "2015-03-06 04:39:38 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573701118129102848",
  "geo" : { },
  "id_str" : "573703905344778242",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky Man. If rumors are true, west coast is going to have a great summer. You better make it up for me.",
  "id" : 573703905344778242,
  "in_reply_to_status_id" : 573701118129102848,
  "created_at" : "2015-03-06 04:37:24 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 4, 12 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/hxxJLoNCjy",
      "expanded_url" : "https:\/\/municibid.com\/Browse?Seller=PhillySchools&page=0&ViewFilterOption=ActiveAuctions&SortFilterOptions=5",
      "display_url" : "municibid.com\/Browse?Seller=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573698577697918976",
  "text" : "Hey @dmansen or other Philly friends: want a bus? https:\/\/t.co\/hxxJLoNCjy",
  "id" : 573698577697918976,
  "created_at" : "2015-03-06 04:16:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Prior",
      "screen_name" : "derekprior",
      "indices" : [ 0, 11 ],
      "id_str" : "1658511",
      "id" : 1658511
    }, {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 12, 19 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573665690789416960",
  "geo" : { },
  "id_str" : "573698145542012928",
  "in_reply_to_user_id" : 1658511,
  "text" : "@derekprior @cpytel gotta think bigger. Thoughtbot Alpha Centauri.",
  "id" : 573698145542012928,
  "in_reply_to_status_id" : 573665690789416960,
  "created_at" : "2015-03-06 04:14:31 +0000",
  "in_reply_to_screen_name" : "derekprior",
  "in_reply_to_user_id_str" : "1658511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "indices" : [ 0, 11 ],
      "id_str" : "3621751",
      "id" : 3621751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573672157437390848",
  "geo" : { },
  "id_str" : "573697843887632385",
  "in_reply_to_user_id" : 3621751,
  "text" : "@abackstrom old school jarts is awesome, one of my best RIT memories. Also I understand why they are banned and you shouldn't drink &amp; play",
  "id" : 573697843887632385,
  "in_reply_to_status_id" : 573672157437390848,
  "created_at" : "2015-03-06 04:13:19 +0000",
  "in_reply_to_screen_name" : "abackstrom",
  "in_reply_to_user_id_str" : "3621751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573671640116170753",
  "text" : "Went to the suburbs tonight to a chain store and parked next to a minivan with large anti vaccination vinyl stickers all over it. \uD83C\uDDFA\uD83C\uDDF8",
  "id" : 573671640116170753,
  "created_at" : "2015-03-06 02:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "indices" : [ 3, 14 ],
      "id_str" : "14606079",
      "id" : 14606079
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ProPublica\/status\/573643662191562752\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TGG40GwRpC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_X93xXUcAAMlM4.png",
      "id_str" : "573643662145384448",
      "id" : 573643662145384448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_X93xXUcAAMlM4.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 755
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 755
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TGG40GwRpC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/JG7vpCekUN",
      "expanded_url" : "http:\/\/www.motherjones.com\/media\/2015\/03\/here-are-some-ridiculous-things-weve-learned-about-silicon-valley-ellen-pao-trial",
      "display_url" : "motherjones.com\/media\/2015\/03\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573652517914980352",
  "text" : "RT @ProPublica: Men-only co. trips? Playboy chats? Inside Silicon Valley's $16m gender discrimination trial: http:\/\/t.co\/JG7vpCekUN http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ProPublica\/status\/573643662191562752\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/TGG40GwRpC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_X93xXUcAAMlM4.png",
        "id_str" : "573643662145384448",
        "id" : 573643662145384448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_X93xXUcAAMlM4.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 755
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 755
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TGG40GwRpC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/JG7vpCekUN",
        "expanded_url" : "http:\/\/www.motherjones.com\/media\/2015\/03\/here-are-some-ridiculous-things-weve-learned-about-silicon-valley-ellen-pao-trial",
        "display_url" : "motherjones.com\/media\/2015\/03\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "573643662191562752",
    "text" : "Men-only co. trips? Playboy chats? Inside Silicon Valley's $16m gender discrimination trial: http:\/\/t.co\/JG7vpCekUN http:\/\/t.co\/TGG40GwRpC",
    "id" : 573643662191562752,
    "created_at" : "2015-03-06 00:38:01 +0000",
    "user" : {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "protected" : false,
      "id_str" : "14606079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000124929472\/259b586b1b577eb1f4f2c5e07abd582a_normal.png",
      "id" : 14606079,
      "verified" : true
    }
  },
  "id" : 573652517914980352,
  "created_at" : "2015-03-06 01:13:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573604599996682240",
  "geo" : { },
  "id_str" : "573605473523363840",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison agreed! the fixture's in a pretty low-traffic spot and is on maybe &lt; 20-mins-1 hr a day, so decided to just eat it for now",
  "id" : 573605473523363840,
  "in_reply_to_status_id" : 573604599996682240,
  "created_at" : "2015-03-05 22:06:16 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 30, 41 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573604032217903104\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/kZorBnlzX7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_XZ08jUcAE5ylm.png",
      "id_str" : "573604031190298625",
      "id" : 573604031190298625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_XZ08jUcAE5ylm.png",
      "sizes" : [ {
        "h" : 931,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 931,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kZorBnlzX7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573604032217903104",
  "text" : "Found out I had access to the @thoughtbot blog still and found a queued post for 30 years from now http:\/\/t.co\/kZorBnlzX7",
  "id" : 573604032217903104,
  "created_at" : "2015-03-05 22:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Young",
      "screen_name" : "JeffYoung",
      "indices" : [ 3, 13 ],
      "id_str" : "80111587",
      "id" : 80111587
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JeffYoung\/status\/573561536968527874\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Iq8JF0FGuL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_WzLbGVAAAHpFD.png",
      "id_str" : "573561536393838592",
      "id" : 573561536393838592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_WzLbGVAAAHpFD.png",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Iq8JF0FGuL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573601587135827968",
  "text" : "RT @JeffYoung: This crucial exchange between Justice Ginsburg and Carvin at the Obamacare arguments hasn't gotten enough attention. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JeffYoung\/status\/573561536968527874\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Iq8JF0FGuL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_WzLbGVAAAHpFD.png",
        "id_str" : "573561536393838592",
        "id" : 573561536393838592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_WzLbGVAAAHpFD.png",
        "sizes" : [ {
          "h" : 217,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 145,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Iq8JF0FGuL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573561536968527874",
    "text" : "This crucial exchange between Justice Ginsburg and Carvin at the Obamacare arguments hasn't gotten enough attention. http:\/\/t.co\/Iq8JF0FGuL",
    "id" : 573561536968527874,
    "created_at" : "2015-03-05 19:11:41 +0000",
    "user" : {
      "name" : "Jeffrey Young",
      "screen_name" : "JeffYoung",
      "protected" : false,
      "id_str" : "80111587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1841297315\/Jeffrey_Young_1_cropped_small_normal.jpg",
      "id" : 80111587,
      "verified" : true
    }
  },
  "id" : 573601587135827968,
  "created_at" : "2015-03-05 21:50:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Grayce",
      "screen_name" : "allisongrayce",
      "indices" : [ 3, 17 ],
      "id_str" : "15567042",
      "id" : 15567042
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 121, 131 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dreamjob",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573575888836538368",
  "text" : "RT @allisongrayce: It's official! Excited to announce I'll be joining the Basecamp team as a marketing designer. Woohoo! @37signals #dreamj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 102, 112 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dreamjob",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573575070779506688",
    "text" : "It's official! Excited to announce I'll be joining the Basecamp team as a marketing designer. Woohoo! @37signals #dreamjob",
    "id" : 573575070779506688,
    "created_at" : "2015-03-05 20:05:28 +0000",
    "user" : {
      "name" : "Allison Grayce",
      "screen_name" : "allisongrayce",
      "protected" : false,
      "id_str" : "15567042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573255719530586112\/sOD32fRo_normal.jpeg",
      "id" : 15567042,
      "verified" : false
    }
  },
  "id" : 573575888836538368,
  "created_at" : "2015-03-05 20:08:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/cvoNsoPivN",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6r1-HTiwGiY",
      "display_url" : "youtube.com\/watch?v=6r1-HT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573569224158789632",
  "text" : "Sleater Kinney live is a force of nature. https:\/\/t.co\/cvoNsoPivN",
  "id" : 573569224158789632,
  "created_at" : "2015-03-05 19:42:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573549382445973505",
  "geo" : { },
  "id_str" : "573550438336741376",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc oh great they converted some hapless millenial",
  "id" : 573550438336741376,
  "in_reply_to_status_id" : 573549382445973505,
  "created_at" : "2015-03-05 18:27:35 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 3, 13 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ShaunKing\/status\/573544439945129984\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/NS3F0agk1d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_WjoP7WYAAT5Da.jpg",
      "id_str" : "573544439425163264",
      "id" : 573544439425163264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_WjoP7WYAAT5Da.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NS3F0agk1d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573549661660651520",
  "text" : "RT @ShaunKing: Whoa. That's how close the plane at LaGuardia was from plunging into the water. http:\/\/t.co\/NS3F0agk1d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ShaunKing\/status\/573544439945129984\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/NS3F0agk1d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_WjoP7WYAAT5Da.jpg",
        "id_str" : "573544439425163264",
        "id" : 573544439425163264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_WjoP7WYAAT5Da.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NS3F0agk1d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573544439945129984",
    "text" : "Whoa. That's how close the plane at LaGuardia was from plunging into the water. http:\/\/t.co\/NS3F0agk1d",
    "id" : 573544439945129984,
    "created_at" : "2015-03-05 18:03:45 +0000",
    "user" : {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "protected" : false,
      "id_str" : "755113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552566266305597441\/0P_nGARo_normal.jpeg",
      "id" : 755113,
      "verified" : false
    }
  },
  "id" : 573549661660651520,
  "created_at" : "2015-03-05 18:24:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/L92hSV84aO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=I1wg1DNHbNU",
      "display_url" : "youtube.com\/watch?v=I1wg1D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573547473324507136",
  "text" : "Current status https:\/\/t.co\/L92hSV84aO",
  "id" : 573547473324507136,
  "created_at" : "2015-03-05 18:15:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan M",
      "screen_name" : "spiffymego",
      "indices" : [ 0, 11 ],
      "id_str" : "887786240",
      "id" : 887786240
    }, {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 12, 27 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573544294063214593",
  "geo" : { },
  "id_str" : "573544499516850176",
  "in_reply_to_user_id" : 887786240,
  "text" : "@spiffymego @ChristineLSloc Upstairs seems busy at night...terrifying.",
  "id" : 573544499516850176,
  "in_reply_to_status_id" : 573544294063214593,
  "created_at" : "2015-03-05 18:03:59 +0000",
  "in_reply_to_screen_name" : "spiffymego",
  "in_reply_to_user_id_str" : "887786240",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573543517525508096",
  "geo" : { },
  "id_str" : "573543832114999296",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc I've passed Sad Balding Scientologist Dude on Main\/Virginia quite a few time at his little table.",
  "id" : 573543832114999296,
  "in_reply_to_status_id" : 573543517525508096,
  "created_at" : "2015-03-05 18:01:20 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573537470714933249",
  "geo" : { },
  "id_str" : "573538064431063040",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison oh awesome. We ended up getting an edison bulb for a new fixture and it cost nearly this much. would rather have LED.",
  "id" : 573538064431063040,
  "in_reply_to_status_id" : 573537470714933249,
  "created_at" : "2015-03-05 17:38:25 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Cocca",
      "screen_name" : "tomcocca",
      "indices" : [ 0, 9 ],
      "id_str" : "335336807",
      "id" : 335336807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573500343650250752",
  "geo" : { },
  "id_str" : "573500715181568000",
  "in_reply_to_user_id" : 335336807,
  "text" : "@tomcocca Yeah! It was fun. It's sad to hear Trey getting closer to Coventry though.",
  "id" : 573500715181568000,
  "in_reply_to_status_id" : 573500343650250752,
  "created_at" : "2015-03-05 15:10:00 +0000",
  "in_reply_to_screen_name" : "tomcocca",
  "in_reply_to_user_id_str" : "335336807",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/bjviI1EI3m",
      "expanded_url" : "http:\/\/youtu.be\/DTXILOwwaQk?t=26m15s",
      "display_url" : "youtu.be\/DTXILOwwaQk?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573490232521199618",
  "text" : "Almost a week into listening the 12\/31\/95 Coil and I still can't get over how wonderful it is. http:\/\/t.co\/bjviI1EI3m",
  "id" : 573490232521199618,
  "created_at" : "2015-03-05 14:28:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Adria Richards",
      "screen_name" : "adriarichards",
      "indices" : [ 11, 25 ],
      "id_str" : "14268164",
      "id" : 14268164
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573486626355027969\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/2sa9n8y48q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_VvDC_UgAEqgIp.jpg",
      "id_str" : "573486625692352513",
      "id" : 573486625692352513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_VvDC_UgAEqgIp.jpg",
      "sizes" : [ {
        "h" : 369,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/2sa9n8y48q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573486138146451456",
  "geo" : { },
  "id_str" : "573486626355027969",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @adriarichards http:\/\/t.co\/2sa9n8y48q",
  "id" : 573486626355027969,
  "in_reply_to_status_id" : 573486138146451456,
  "created_at" : "2015-03-05 14:14:01 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 0, 12 ],
      "id_str" : "15686931",
      "id" : 15686931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573485273876688897",
  "geo" : { },
  "id_str" : "573485567050059778",
  "in_reply_to_user_id" : 15686931,
  "text" : "@chris_joyce i'm waiting for someone to start Industrial zoning.",
  "id" : 573485567050059778,
  "in_reply_to_status_id" : 573485273876688897,
  "created_at" : "2015-03-05 14:09:48 +0000",
  "in_reply_to_screen_name" : "chris_joyce",
  "in_reply_to_user_id_str" : "15686931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 0, 12 ],
      "id_str" : "48160411",
      "id" : 48160411
    }, {
      "name" : "Keith Knoer",
      "screen_name" : "kknoer",
      "indices" : [ 13, 20 ],
      "id_str" : "28633363",
      "id" : 28633363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573483196395945984",
  "geo" : { },
  "id_str" : "573483730771185664",
  "in_reply_to_user_id" : 48160411,
  "text" : "@timbouchard @kknoer nooo the one day i can't make it downtown.",
  "id" : 573483730771185664,
  "in_reply_to_status_id" : 573483196395945984,
  "created_at" : "2015-03-05 14:02:30 +0000",
  "in_reply_to_screen_name" : "timbouchard",
  "in_reply_to_user_id_str" : "48160411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573481635397550081\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/aoO9ifgTPi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Vqgg5VEAARs-D.png",
      "id_str" : "573481634378354688",
      "id" : 573481634378354688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Vqgg5VEAARs-D.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aoO9ifgTPi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "573481635397550081",
  "text" : "Weekend 14 of http:\/\/t.co\/biwDqHL2ML starts tomorrow and is going strong. Here's a stereoscopic view of downtown http:\/\/t.co\/aoO9ifgTPi",
  "id" : 573481635397550081,
  "created_at" : "2015-03-05 13:54:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573468669260464128",
  "geo" : { },
  "id_str" : "573473939818577920",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV someone left a towel on one of my front yard snow banks. I think it's somewhere from 2-3' deep now",
  "id" : 573473939818577920,
  "in_reply_to_status_id" : 573468669260464128,
  "created_at" : "2015-03-05 13:23:36 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley needs tats",
      "screen_name" : "rabcyr",
      "indices" : [ 0, 7 ],
      "id_str" : "26157562",
      "id" : 26157562
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573347646028447745\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/379Zz1gYg9",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B_TwpSbU8AEYzhY.png",
      "id_str" : "573347644694654977",
      "id" : 573347644694654977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B_TwpSbU8AEYzhY.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/379Zz1gYg9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573347220445138946",
  "geo" : { },
  "id_str" : "573347646028447745",
  "in_reply_to_user_id" : 26157562,
  "text" : "@rabcyr http:\/\/t.co\/379Zz1gYg9",
  "id" : 573347646028447745,
  "in_reply_to_status_id" : 573347220445138946,
  "created_at" : "2015-03-05 05:01:45 +0000",
  "in_reply_to_screen_name" : "rabcyr",
  "in_reply_to_user_id_str" : "26157562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573346708039462912",
  "text" : "Instead of sorting my GIFs folder by emotion, I need a facial detection algorithm that reads my stupid face and returns the closest gif",
  "id" : 573346708039462912,
  "created_at" : "2015-03-05 04:58:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rusty Foster",
      "screen_name" : "rustyk5",
      "indices" : [ 0, 8 ],
      "id_str" : "577124971",
      "id" : 577124971
    }, {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 9, 20 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573343862317559809",
  "geo" : { },
  "id_str" : "573344684006756353",
  "in_reply_to_user_id" : 577124971,
  "text" : "@rustyk5 @sarahjeong i put on my robe and lawyer hat",
  "id" : 573344684006756353,
  "in_reply_to_status_id" : 573343862317559809,
  "created_at" : "2015-03-05 04:49:59 +0000",
  "in_reply_to_screen_name" : "rustyk5",
  "in_reply_to_user_id_str" : "577124971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "indices" : [ 0, 11 ],
      "id_str" : "16008234",
      "id" : 16008234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573344377923354625",
  "geo" : { },
  "id_str" : "573344528981106688",
  "in_reply_to_user_id" : 16008234,
  "text" : "@stephperry this is an Onion headline, verbatim",
  "id" : 573344528981106688,
  "in_reply_to_status_id" : 573344377923354625,
  "created_at" : "2015-03-05 04:49:22 +0000",
  "in_reply_to_screen_name" : "stephperry",
  "in_reply_to_user_id_str" : "16008234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley needs tats",
      "screen_name" : "rabcyr",
      "indices" : [ 0, 7 ],
      "id_str" : "26157562",
      "id" : 26157562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573339157214461953",
  "geo" : { },
  "id_str" : "573341409945628673",
  "in_reply_to_user_id" : 26157562,
  "text" : "@rabcyr Yeah definitely need a traffic cone. Something about it screams \"DO NOT TOUCH!\"",
  "id" : 573341409945628673,
  "in_reply_to_status_id" : 573339157214461953,
  "created_at" : "2015-03-05 04:36:58 +0000",
  "in_reply_to_screen_name" : "rabcyr",
  "in_reply_to_user_id_str" : "26157562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573338497836167168",
  "text" : "Dumb question. Does anyone in Buffalo have a small (&lt; 7\") traffic\/flag football\/soccer cone they'd be willing to part with tomorrow?",
  "id" : 573338497836167168,
  "created_at" : "2015-03-05 04:25:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573290560775053312",
  "text" : "Secret fantasy: The Blue Man Group communicates internally only with Vines, no talking, only badass drum beats and strange staring at things",
  "id" : 573290560775053312,
  "created_at" : "2015-03-05 01:14:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/HnXm3BQ7ye",
      "expanded_url" : "https:\/\/web.archive.org\/web\/20091116140008\/http:\/\/www.gccis.rit.edu\/node\/266",
      "display_url" : "web.archive.org\/web\/2009111614\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573287538200199168",
  "text" : "Didn't know him, but found Mike Ey in my email from when he was the GCCIS student spotlight in 2009: https:\/\/t.co\/HnXm3BQ7ye RIP.",
  "id" : 573287538200199168,
  "created_at" : "2015-03-05 01:02:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573277423753543680",
  "geo" : { },
  "id_str" : "573280538053644289",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer yeah of the Minecraft files themselves and renders for the map",
  "id" : 573280538053644289,
  "in_reply_to_status_id" : 573277423753543680,
  "created_at" : "2015-03-05 00:35:05 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573275758916988931",
  "geo" : { },
  "id_str" : "573276936161521664",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky I\u0357\u0322\u032C\u0320\u0329\u031D\u0332\u032C \u0365\u0309\u0302\u0307\u0305\u034C\u0343\u0341\u0355\u0356\u0316\u0349\u0316\u033C\u0319w\u0352\u035D\u032E\u0325\u033C\u033A\u032A\u032Fi\u0309\u030E\u0335\u033Bl\u0308\u034C\u0364\u0368\u0350\u0339\u0319\u032D\u0345\u0356l\u036F\u036B\u0365\u0350\u030D\u031A\u0363\u0321\u0355\u0331\u033C\u0331\u0323\u0332\u0353 \u0351\u0367\u035Di\u0336\u034E\u032E\u0354\u0316n\u0363\u0306\u0367\u034D\u0325\u0329\u033Bv\u0369\u0310\u0309\u030D\u0312\u033F\u030A\u0348\u0331\u032Ce\u0307\u030E\u036C\u035B\u0303\u0357\u0335s\u0301\u0312\u0342\u0320\u0329\u033C\u0333\u0354\u0348t\u0305\u0357\u036A\u0312\u030F\u0305\u0342",
  "id" : 573276936161521664,
  "in_reply_to_status_id" : 573275758916988931,
  "created_at" : "2015-03-05 00:20:47 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "in_reply_to_status_id_str" : "573274497450524673",
  "geo" : { },
  "id_str" : "573275069566205954",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer http:\/\/t.co\/biwDqHL2ML's repo is around 2gb. I just split off the last once since it was around 6-8 ish",
  "id" : 573275069566205954,
  "in_reply_to_status_id" : 573274497450524673,
  "created_at" : "2015-03-05 00:13:22 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenn",
      "screen_name" : "jennschiffer",
      "indices" : [ 0, 13 ],
      "id_str" : "12524622",
      "id" : 12524622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bird",
      "indices" : [ 23, 28 ]
    }, {
      "text" : "photos",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/dSIq4jRZ4y",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/qrush\/9288168243\/",
      "display_url" : "flickr.com\/photos\/qrush\/9\u2026"
    }, {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/qBupceZ09X",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/qrush\/9281135270\/",
      "display_url" : "flickr.com\/photos\/qrush\/9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "573214446702743552",
  "geo" : { },
  "id_str" : "573216376728522752",
  "in_reply_to_user_id" : 12524622,
  "text" : "@jennschiffer here's 2 #bird #photos https:\/\/t.co\/dSIq4jRZ4y https:\/\/t.co\/qBupceZ09X",
  "id" : 573216376728522752,
  "in_reply_to_status_id" : 573214446702743552,
  "created_at" : "2015-03-04 20:20:08 +0000",
  "in_reply_to_screen_name" : "jennschiffer",
  "in_reply_to_user_id_str" : "12524622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 82, 88 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Gndnj3GgqI",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=GPYH0HaStmw",
      "display_url" : "youtube.com\/watch?v=GPYH0H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573213459384565760",
  "text" : "15 year old absolutely crushes and transitions beautifully through nearly a dozen @phish songs https:\/\/t.co\/Gndnj3GgqI",
  "id" : 573213459384565760,
  "created_at" : "2015-03-04 20:08:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "One Kings Lane",
      "screen_name" : "onekingslane",
      "indices" : [ 45, 58 ],
      "id_str" : "19789726",
      "id" : 19789726
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/holman\/status\/573198011783782401\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/oQz6ZwqQhz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RojezWoAAVRsE.png",
      "id_str" : "573198011356061696",
      "id" : 573198011356061696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RojezWoAAVRsE.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1488
      } ],
      "display_url" : "pic.twitter.com\/oQz6ZwqQhz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573204439730921472",
  "text" : "RT @holman: \u201CUse Ruby To Get Some Ladies\u201D at @onekingslane http:\/\/t.co\/oQz6ZwqQhz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One Kings Lane",
        "screen_name" : "onekingslane",
        "indices" : [ 33, 46 ],
        "id_str" : "19789726",
        "id" : 19789726
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/holman\/status\/573198011783782401\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/oQz6ZwqQhz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RojezWoAAVRsE.png",
        "id_str" : "573198011356061696",
        "id" : 573198011356061696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RojezWoAAVRsE.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 149,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 656,
          "resize" : "fit",
          "w" : 1488
        } ],
        "display_url" : "pic.twitter.com\/oQz6ZwqQhz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573198011783782401",
    "text" : "\u201CUse Ruby To Get Some Ladies\u201D at @onekingslane http:\/\/t.co\/oQz6ZwqQhz",
    "id" : 573198011783782401,
    "created_at" : "2015-03-04 19:07:10 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550019686230794240\/gWlpdYw2_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 573204439730921472,
  "created_at" : "2015-03-04 19:32:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573189349078122496",
  "text" : "I think 99% of all open source on Android is published by Square.",
  "id" : 573189349078122496,
  "created_at" : "2015-03-04 18:32:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 3, 12 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    }, {
      "name" : "SuesSpecial",
      "screen_name" : "SuesSpecial",
      "indices" : [ 86, 98 ],
      "id_str" : "3070353112",
      "id" : 3070353112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573183230003847170",
  "text" : "RT @borncamp: I created a bot to tweet  the daily special of Sues NY Deli on Main St. @SuesSpecial",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SuesSpecial",
        "screen_name" : "SuesSpecial",
        "indices" : [ 72, 84 ],
        "id_str" : "3070353112",
        "id" : 3070353112
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573180227393888256",
    "text" : "I created a bot to tweet  the daily special of Sues NY Deli on Main St. @SuesSpecial",
    "id" : 573180227393888256,
    "created_at" : "2015-03-04 17:56:30 +0000",
    "user" : {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "protected" : false,
      "id_str" : "1002573926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425741462311952384\/lPAjNC1C_normal.jpeg",
      "id" : 1002573926,
      "verified" : false
    }
  },
  "id" : 573183230003847170,
  "created_at" : "2015-03-04 18:08:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "indices" : [ 3, 14 ],
      "id_str" : "16008234",
      "id" : 16008234
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stephperry\/status\/573180090923683840\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/gmWwKvsCuw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RYQVNUsAAiGZi.jpg",
      "id_str" : "573180090177073152",
      "id" : 573180090177073152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RYQVNUsAAiGZi.jpg",
      "sizes" : [ {
        "h" : 486,
        "resize" : "fit",
        "w" : 914
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 914
      } ],
      "display_url" : "pic.twitter.com\/gmWwKvsCuw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573181805756612608",
  "text" : "RT @stephperry: Prediction: Later this year we will reach peak \"dumpster fire\" as figurative pejorative http:\/\/t.co\/gmWwKvsCuw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stephperry\/status\/573180090923683840\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/gmWwKvsCuw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RYQVNUsAAiGZi.jpg",
        "id_str" : "573180090177073152",
        "id" : 573180090177073152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RYQVNUsAAiGZi.jpg",
        "sizes" : [ {
          "h" : 486,
          "resize" : "fit",
          "w" : 914
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 319,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 914
        } ],
        "display_url" : "pic.twitter.com\/gmWwKvsCuw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573180090923683840",
    "text" : "Prediction: Later this year we will reach peak \"dumpster fire\" as figurative pejorative http:\/\/t.co\/gmWwKvsCuw",
    "id" : 573180090923683840,
    "created_at" : "2015-03-04 17:55:57 +0000",
    "user" : {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "protected" : false,
      "id_str" : "16008234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572217545717866496\/Ssw9W0fi_normal.jpeg",
      "id" : 16008234,
      "verified" : false
    }
  },
  "id" : 573181805756612608,
  "created_at" : "2015-03-04 18:02:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Miller",
      "screen_name" : "incanus77",
      "indices" : [ 0, 10 ],
      "id_str" : "4765141",
      "id" : 4765141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573161315520274432",
  "geo" : { },
  "id_str" : "573161693926322176",
  "in_reply_to_user_id" : 4765141,
  "text" : "@incanus77 \"vaper prototyping\"",
  "id" : 573161693926322176,
  "in_reply_to_status_id" : 573161315520274432,
  "created_at" : "2015-03-04 16:42:51 +0000",
  "in_reply_to_screen_name" : "incanus77",
  "in_reply_to_user_id_str" : "4765141",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 0, 9 ],
      "id_str" : "1051521",
      "id" : 1051521
    }, {
      "name" : "WBEZ",
      "screen_name" : "WBEZ",
      "indices" : [ 10, 15 ],
      "id_str" : "13749282",
      "id" : 13749282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573159864001671168",
  "geo" : { },
  "id_str" : "573160195444113408",
  "in_reply_to_user_id" : 1051521,
  "text" : "@migreyes @WBEZ wat",
  "id" : 573160195444113408,
  "in_reply_to_status_id" : 573159864001671168,
  "created_at" : "2015-03-04 16:36:54 +0000",
  "in_reply_to_screen_name" : "migreyes",
  "in_reply_to_user_id_str" : "1051521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573151168681123841",
  "geo" : { },
  "id_str" : "573155066263306240",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen hey thanks!",
  "id" : 573155066263306240,
  "in_reply_to_status_id" : 573151168681123841,
  "created_at" : "2015-03-04 16:16:31 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Cocca",
      "screen_name" : "tomcocca",
      "indices" : [ 0, 9 ],
      "id_str" : "335336807",
      "id" : 335336807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573150100534501376",
  "geo" : { },
  "id_str" : "573150496652980224",
  "in_reply_to_user_id" : 335336807,
  "text" : "@tomcocca I need to see TAB still. Saw Jennifer and Nat with Everyone Orchestra and they are killer.",
  "id" : 573150496652980224,
  "in_reply_to_status_id" : 573150100534501376,
  "created_at" : "2015-03-04 15:58:21 +0000",
  "in_reply_to_screen_name" : "tomcocca",
  "in_reply_to_user_id_str" : "335336807",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Cocca",
      "screen_name" : "tomcocca",
      "indices" : [ 0, 9 ],
      "id_str" : "335336807",
      "id" : 335336807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573148647283691520",
  "geo" : { },
  "id_str" : "573148918151843842",
  "in_reply_to_user_id" : 335336807,
  "text" : "@tomcocca queued for today, thanks! Also a 4 song second set. I can't even.",
  "id" : 573148918151843842,
  "in_reply_to_status_id" : 573148647283691520,
  "created_at" : "2015-03-04 15:52:05 +0000",
  "in_reply_to_screen_name" : "tomcocca",
  "in_reply_to_user_id_str" : "335336807",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Cocca",
      "screen_name" : "tomcocca",
      "indices" : [ 0, 9 ],
      "id_str" : "335336807",
      "id" : 335336807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573147519271739392",
  "geo" : { },
  "id_str" : "573147969257644032",
  "in_reply_to_user_id" : 335336807,
  "text" : "@tomcocca i should do a relisten to them all. Highlights off the top of my head: 6\/23\/12 mule, 7\/1\/14 paug &gt; ghost",
  "id" : 573147969257644032,
  "in_reply_to_status_id" : 573147519271739392,
  "created_at" : "2015-03-04 15:48:19 +0000",
  "in_reply_to_screen_name" : "tomcocca",
  "in_reply_to_user_id_str" : "335336807",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573146993985503233",
  "geo" : { },
  "id_str" : "573147470655594498",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain I AM CHAMFERED EDGE ALUMINUM MAN",
  "id" : 573147470655594498,
  "in_reply_to_status_id" : 573146993985503233,
  "created_at" : "2015-03-04 15:46:20 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573129818872651776",
  "geo" : { },
  "id_str" : "573147039594356738",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen we had the ice dams cleared out on the bad side. All damage seems to be interior to the wall.",
  "id" : 573147039594356738,
  "in_reply_to_status_id" : 573129818872651776,
  "created_at" : "2015-03-04 15:44:37 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 25, 31 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573146455508164608",
  "text" : "Totaled it up finally: 9 @phish shows thus far 2011-2014. Hoping to see some summer tour dates soon.",
  "id" : 573146455508164608,
  "created_at" : "2015-03-04 15:42:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/biwDqHtrVd",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    }, {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/mDMtFLgE3e",
      "expanded_url" : "https:\/\/flic.kr\/p\/rsGWVk",
      "display_url" : "flic.kr\/p\/rsGWVk"
    } ]
  },
  "geo" : { },
  "id_str" : "573146117824745472",
  "text" : "http:\/\/t.co\/biwDqHtrVd week 13 - apple store https:\/\/t.co\/mDMtFLgE3e",
  "id" : 573146117824745472,
  "created_at" : "2015-03-04 15:40:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Green",
      "screen_name" : "jagthedrummer",
      "indices" : [ 0, 14 ],
      "id_str" : "19013274",
      "id" : 19013274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573012395137748992",
  "geo" : { },
  "id_str" : "573127518074503168",
  "in_reply_to_user_id" : 19013274,
  "text" : "@jagthedrummer I don't remember if I've seen it. I need to start keeping a list.",
  "id" : 573127518074503168,
  "in_reply_to_status_id" : 573012395137748992,
  "created_at" : "2015-03-04 14:27:03 +0000",
  "in_reply_to_screen_name" : "jagthedrummer",
  "in_reply_to_user_id_str" : "19013274",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573126664399405056\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/o1FsIym1vh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_QnqPCU0AAEFfP.jpg",
      "id_str" : "573126659127169024",
      "id" : 573126659127169024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_QnqPCU0AAEFfP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/o1FsIym1vh"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573126664399405056\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/o1FsIym1vh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_QnqeSU4AE-Y3Y.png",
      "id_str" : "573126663220813825",
      "id" : 573126663220813825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_QnqeSU4AE-Y3Y.png",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 1278
      } ],
      "display_url" : "pic.twitter.com\/o1FsIym1vh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573126664399405056",
  "text" : "\"We really need a front-end engineer that knows THUNDER WAVE. Are you COOL enough for our culture?\" http:\/\/t.co\/o1FsIym1vh",
  "id" : 573126664399405056,
  "created_at" : "2015-03-04 14:23:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573125260322611203\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/zsmTsK7Gsd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_QmYt6UsAE2tzN.png",
      "id_str" : "573125258665832449",
      "id" : 573125258665832449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_QmYt6UsAE2tzN.png",
      "sizes" : [ {
        "h" : 503,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 1346
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zsmTsK7Gsd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573125260322611203",
  "text" : "\"BE THE MAN!!\" the job ad\/pokemon ability chart reads, discriminating and self-selecting the best devops pokemons http:\/\/t.co\/zsmTsK7Gsd",
  "id" : 573125260322611203,
  "created_at" : "2015-03-04 14:18:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573121672837918720\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/9z5n0MWkMU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_QjH9JVEAA681s.png",
      "id_str" : "573121672162643968",
      "id" : 573121672162643968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_QjH9JVEAA681s.png",
      "sizes" : [ {
        "h" : 748,
        "resize" : "fit",
        "w" : 1842
      }, {
        "h" : 138,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9z5n0MWkMU"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573121672837918720\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/9z5n0MWkMU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_QjHXfVAAA2V-d.jpg",
      "id_str" : "573121662054367232",
      "id" : 573121662054367232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_QjHXfVAAA2V-d.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/9z5n0MWkMU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573121672837918720",
  "text" : "Your hiring process is already very broken, so instead lets treat humans like pokemon and catch them instead http:\/\/t.co\/9z5n0MWkMU",
  "id" : 573121672837918720,
  "created_at" : "2015-03-04 14:03:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/573115838116585472\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/B8fHefPp2b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Qd0UaUoAAaYTd.png",
      "id_str" : "573115837252411392",
      "id" : 573115837252411392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Qd0UaUoAAaYTd.png",
      "sizes" : [ {
        "h" : 617,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 942,
        "resize" : "fit",
        "w" : 1562
      } ],
      "display_url" : "pic.twitter.com\/B8fHefPp2b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573115838116585472",
  "text" : "THIS. IS HACKER NEWS.\n\n*Upbeat trumpeting theme song with eagles and leet hackers clacking away on vintage keyboards* http:\/\/t.co\/B8fHefPp2b",
  "id" : 573115838116585472,
  "created_at" : "2015-03-04 13:40:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 3, 13 ],
      "id_str" : "816041347",
      "id" : 816041347
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 30, 45 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "Hotel @ Lafayette",
      "screen_name" : "Hotel_Lafayette",
      "indices" : [ 53, 69 ],
      "id_str" : "1137892344",
      "id" : 1137892344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573094673713012736",
  "text" : "RT @BreadHive: In 15 minutes, @PublicEspresso at the @Hotel_Lafayette opens \uD83C\uDF81\uD83C\uDF89\u2615",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PublicEspresso",
        "screen_name" : "PublicEspresso",
        "indices" : [ 15, 30 ],
        "id_str" : "1472209542",
        "id" : 1472209542
      }, {
        "name" : "Hotel @ Lafayette",
        "screen_name" : "Hotel_Lafayette",
        "indices" : [ 38, 54 ],
        "id_str" : "1137892344",
        "id" : 1137892344
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573086793492529152",
    "text" : "In 15 minutes, @PublicEspresso at the @Hotel_Lafayette opens \uD83C\uDF81\uD83C\uDF89\u2615",
    "id" : 573086793492529152,
    "created_at" : "2015-03-04 11:45:13 +0000",
    "user" : {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "protected" : false,
      "id_str" : "816041347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459318201117974529\/Pzr0U68v_normal.png",
      "id" : 816041347,
      "verified" : false
    }
  },
  "id" : 573094673713012736,
  "created_at" : "2015-03-04 12:16:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/pzEQSpykUe",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=AxXKvkHZF9g",
      "display_url" : "m.youtube.com\/watch?v=AxXKvk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572997108099227648",
  "text" : "If I can learn vim over a few years (and still learning) this has to be possible right!? Gorgeous ending here. https:\/\/t.co\/pzEQSpykUe",
  "id" : 572997108099227648,
  "created_at" : "2015-03-04 05:48:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572977252419280896\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/sxrg2D2exh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_OfxlYUQAAjFDp.png",
      "id_str" : "572977251802693632",
      "id" : 572977251802693632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_OfxlYUQAAjFDp.png",
      "sizes" : [ {
        "h" : 114,
        "resize" : "fit",
        "w" : 684
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 114,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 56,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 684
      } ],
      "display_url" : "pic.twitter.com\/sxrg2D2exh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572977252419280896",
  "text" : "Who in the right mind would program such a feature? What could possibly compel you? http:\/\/t.co\/sxrg2D2exh",
  "id" : 572977252419280896,
  "created_at" : "2015-03-04 04:29:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572959662892445697",
  "text" : "Page finishes this beautiful solo and immediately gets to work busting out Maze. Trey's the lead, but Page. Page. Man. Boy. Page makes it.",
  "id" : 572959662892445697,
  "created_at" : "2015-03-04 03:20:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572959343043166208",
  "text" : "I can't get over the Coil from 12\/31\/95. A thing of beauty.",
  "id" : 572959343043166208,
  "created_at" : "2015-03-04 03:18:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572939989085913088",
  "geo" : { },
  "id_str" : "572940082144935936",
  "in_reply_to_user_id" : 5743852,
  "text" : "@whentheponydies we got broken into on 12\/23 our first year here :(",
  "id" : 572940082144935936,
  "in_reply_to_status_id" : 572939989085913088,
  "created_at" : "2015-03-04 02:02:14 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572939738879041540",
  "geo" : { },
  "id_str" : "572939989085913088",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies dude fuck, sorry :( File a police report.",
  "id" : 572939989085913088,
  "in_reply_to_status_id" : 572939738879041540,
  "created_at" : "2015-03-04 02:01:52 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 0, 9 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572939774769545217",
  "geo" : { },
  "id_str" : "572939930063618048",
  "in_reply_to_user_id" : 1002573926,
  "text" : "@borncamp \"George W. Bush Gentle Foreign Detainee Questioning Act\"",
  "id" : 572939930063618048,
  "in_reply_to_status_id" : 572939774769545217,
  "created_at" : "2015-03-04 02:01:38 +0000",
  "in_reply_to_screen_name" : "borncamp",
  "in_reply_to_user_id_str" : "1002573926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572936623689605120",
  "geo" : { },
  "id_str" : "572939732839079936",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik this is around 50% of my repos or higher",
  "id" : 572939732839079936,
  "in_reply_to_status_id" : 572936623689605120,
  "created_at" : "2015-03-04 02:00:51 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Centers",
      "screen_name" : "jcenters",
      "indices" : [ 3, 12 ],
      "id_str" : "63636463",
      "id" : 63636463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572920783535661056",
  "text" : "RT @jcenters: It says something that one of the most successful developers of all time regretfully took a multi-billion buyout to escape ga\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572871609985314817",
    "text" : "It says something that one of the most successful developers of all time regretfully took a multi-billion buyout to escape gamers.",
    "id" : 572871609985314817,
    "created_at" : "2015-03-03 21:30:09 +0000",
    "user" : {
      "name" : "Josh Centers",
      "screen_name" : "jcenters",
      "protected" : false,
      "id_str" : "63636463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497771746842259457\/EScqB5aS_normal.jpeg",
      "id" : 63636463,
      "verified" : false
    }
  },
  "id" : 572920783535661056,
  "created_at" : "2015-03-04 00:45:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Brutal House",
      "screen_name" : "BrutalHouse",
      "indices" : [ 0, 12 ],
      "id_str" : "2347646468",
      "id" : 2347646468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572892482922405889",
  "geo" : { },
  "id_str" : "572893223409958912",
  "in_reply_to_user_id" : 2347646468,
  "text" : "@BrutalHouse second photo does not look like the Falls at all.",
  "id" : 572893223409958912,
  "in_reply_to_status_id" : 572892482922405889,
  "created_at" : "2015-03-03 22:56:02 +0000",
  "in_reply_to_screen_name" : "BrutalHouse",
  "in_reply_to_user_id_str" : "2347646468",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pikachu",
      "screen_name" : "Piiiikaachu",
      "indices" : [ 3, 15 ],
      "id_str" : "785741952",
      "id" : 785741952
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Piiiikaachu\/status\/572245956030296064\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Ce33YiTAI5",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B_EGQkMUoAA1-Qg.png",
      "id_str" : "572245509315796992",
      "id" : 572245509315796992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B_EGQkMUoAA1-Qg.png",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/Ce33YiTAI5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572821678176276480",
  "text" : "RT @Piiiikaachu: REVERSED GIFS ARE THE BEST. http:\/\/t.co\/Ce33YiTAI5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Piiiikaachu\/status\/572245956030296064\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/Ce33YiTAI5",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B_EGQkMUoAA1-Qg.png",
        "id_str" : "572245509315796992",
        "id" : 572245509315796992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B_EGQkMUoAA1-Qg.png",
        "sizes" : [ {
          "h" : 306,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/Ce33YiTAI5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572245956030296064",
    "text" : "REVERSED GIFS ARE THE BEST. http:\/\/t.co\/Ce33YiTAI5",
    "id" : 572245956030296064,
    "created_at" : "2015-03-02 04:04:02 +0000",
    "user" : {
      "name" : "Pikachu",
      "screen_name" : "Piiiikaachu",
      "protected" : false,
      "id_str" : "785741952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556163239197675520\/3mSPGH6p_normal.png",
      "id" : 785741952,
      "verified" : false
    }
  },
  "id" : 572821678176276480,
  "created_at" : "2015-03-03 18:11:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 0, 10 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 11, 26 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/oqRF3tfCuL",
      "expanded_url" : "https:\/\/github.com\/qrush\/skyway\/issues",
      "display_url" : "github.com\/qrush\/skyway\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "572814127925747712",
  "geo" : { },
  "id_str" : "572814522274226176",
  "in_reply_to_user_id" : 2850371250,
  "text" : "@chumprock @UnclePhilsBlog Yes, that's on my list, and marking what shows you've been to. Feel free to dump ideas https:\/\/t.co\/oqRF3tfCuL",
  "id" : 572814522274226176,
  "in_reply_to_status_id" : 572814127925747712,
  "created_at" : "2015-03-03 17:43:19 +0000",
  "in_reply_to_screen_name" : "chumprock",
  "in_reply_to_user_id_str" : "2850371250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 0, 13 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572794876682735616",
  "geo" : { },
  "id_str" : "572795084380508160",
  "in_reply_to_user_id" : 16275936,
  "text" : "@rachbarnhart is that off Mt. Read? I think I worked in that building.",
  "id" : 572795084380508160,
  "in_reply_to_status_id" : 572794876682735616,
  "created_at" : "2015-03-03 16:26:04 +0000",
  "in_reply_to_screen_name" : "rachbarnhart",
  "in_reply_to_user_id_str" : "16275936",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Glazebrook",
      "screen_name" : "mostlikely_to",
      "indices" : [ 0, 14 ],
      "id_str" : "73204959",
      "id" : 73204959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572778481643343872",
  "geo" : { },
  "id_str" : "572780691890577408",
  "in_reply_to_user_id" : 73204959,
  "text" : "@mostlikely_to cool. fucking miracles.",
  "id" : 572780691890577408,
  "in_reply_to_status_id" : 572778481643343872,
  "created_at" : "2015-03-03 15:28:53 +0000",
  "in_reply_to_screen_name" : "mostlikely_to",
  "in_reply_to_user_id_str" : "73204959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 0, 10 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572773405830856706",
  "geo" : { },
  "id_str" : "572774846880456704",
  "in_reply_to_user_id" : 2850371250,
  "text" : "@chumprock suggestions for other top 2?",
  "id" : 572774846880456704,
  "in_reply_to_status_id" : 572773405830856706,
  "created_at" : "2015-03-03 15:05:39 +0000",
  "in_reply_to_screen_name" : "chumprock",
  "in_reply_to_user_id_str" : "2850371250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 0, 10 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 89, 101 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572772696670523393",
  "geo" : { },
  "id_str" : "572772965332463616",
  "in_reply_to_user_id" : 2850371250,
  "text" : "@chumprock I'm somewhat newer. ~10 shows though. Making up for it with a healthy dose of @AqueousBand",
  "id" : 572772965332463616,
  "in_reply_to_status_id" : 572772696670523393,
  "created_at" : "2015-03-03 14:58:11 +0000",
  "in_reply_to_screen_name" : "chumprock",
  "in_reply_to_user_id_str" : "2850371250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Glazebrook",
      "screen_name" : "mostlikely_to",
      "indices" : [ 0, 14 ],
      "id_str" : "73204959",
      "id" : 73204959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572772423323549696",
  "geo" : { },
  "id_str" : "572772873066160129",
  "in_reply_to_user_id" : 73204959,
  "text" : "@mostlikely_to wait, does this mean I work with another phish fan and we haven't talked about this ever???",
  "id" : 572772873066160129,
  "in_reply_to_status_id" : 572772423323549696,
  "created_at" : "2015-03-03 14:57:49 +0000",
  "in_reply_to_screen_name" : "mostlikely_to",
  "in_reply_to_user_id_str" : "73204959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Glazebrook",
      "screen_name" : "mostlikely_to",
      "indices" : [ 0, 14 ],
      "id_str" : "73204959",
      "id" : 73204959
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 20, 34 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572772423323549696",
  "geo" : { },
  "id_str" : "572772702383169536",
  "in_reply_to_user_id" : 73204959,
  "text" : "@mostlikely_to yes, @Carols10cents has been trying to get me to listen for ages now",
  "id" : 572772702383169536,
  "in_reply_to_status_id" : 572772423323549696,
  "created_at" : "2015-03-03 14:57:08 +0000",
  "in_reply_to_screen_name" : "mostlikely_to",
  "in_reply_to_user_id_str" : "73204959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/mL55nNyl4j",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=DTXILOwwaQk",
      "display_url" : "youtube.com\/watch?v=DTXILO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572772203265167360",
  "text" : "How have I not listened to this show? Wow. https:\/\/t.co\/mL55nNyl4j",
  "id" : 572772203265167360,
  "created_at" : "2015-03-03 14:55:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 46, 52 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/572741954569703425\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/BySVafX8hU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_LJxWTUwAAtADn.jpg",
      "id_str" : "572741952266878976",
      "id" : 572741952266878976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_LJxWTUwAAtADn.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1092,
        "resize" : "fit",
        "w" : 1092
      } ],
      "display_url" : "pic.twitter.com\/BySVafX8hU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572772053868265472",
  "text" : "RT @aquaranto: Hey Twitter family! It\u2019s a\u2026\ncc @qrush http:\/\/t.co\/BySVafX8hU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 31, 37 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/572741954569703425\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/BySVafX8hU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_LJxWTUwAAtADn.jpg",
        "id_str" : "572741952266878976",
        "id" : 572741952266878976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_LJxWTUwAAtADn.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1092,
          "resize" : "fit",
          "w" : 1092
        } ],
        "display_url" : "pic.twitter.com\/BySVafX8hU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572741954569703425",
    "text" : "Hey Twitter family! It\u2019s a\u2026\ncc @qrush http:\/\/t.co\/BySVafX8hU",
    "id" : 572741954569703425,
    "created_at" : "2015-03-03 12:54:57 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 572772053868265472,
  "created_at" : "2015-03-03 14:54:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Nephew",
      "screen_name" : "snephew25",
      "indices" : [ 0, 10 ],
      "id_str" : "125562735",
      "id" : 125562735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572768022181634048",
  "geo" : { },
  "id_str" : "572768668167380993",
  "in_reply_to_user_id" : 125562735,
  "text" : "@snephew25 it's madness there. i'm shocked that it's that popular",
  "id" : 572768668167380993,
  "in_reply_to_status_id" : 572768022181634048,
  "created_at" : "2015-03-03 14:41:06 +0000",
  "in_reply_to_screen_name" : "snephew25",
  "in_reply_to_user_id_str" : "125562735",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "indices" : [ 3, 8 ],
      "id_str" : "3364",
      "id" : 3364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/eWy1Zgkjaw",
      "expanded_url" : "http:\/\/www.reuters.com\/article\/2015\/02\/20\/us-cybersecurity-statedept-idUSKBN0LO03R20150220",
      "display_url" : "reuters.com\/article\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572760369229217792",
  "text" : "RT @cjoh: Hillary Clinton using her personal email for her state dept. work was the most secure thing she could have done: http:\/\/t.co\/eWy1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/eWy1Zgkjaw",
        "expanded_url" : "http:\/\/www.reuters.com\/article\/2015\/02\/20\/us-cybersecurity-statedept-idUSKBN0LO03R20150220",
        "display_url" : "reuters.com\/article\/2015\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "572759941116764160",
    "text" : "Hillary Clinton using her personal email for her state dept. work was the most secure thing she could have done: http:\/\/t.co\/eWy1Zgkjaw",
    "id" : 572759941116764160,
    "created_at" : "2015-03-03 14:06:25 +0000",
    "user" : {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "protected" : false,
      "id_str" : "3364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000681085924\/1e889c21e483e36bd67798eef968375e_normal.jpeg",
      "id" : 3364,
      "verified" : false
    }
  },
  "id" : 572760369229217792,
  "created_at" : "2015-03-03 14:08:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572750009327738880",
  "geo" : { },
  "id_str" : "572750145785221120",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 no shirt no shoes no service does not include pants",
  "id" : 572750145785221120,
  "in_reply_to_status_id" : 572750009327738880,
  "created_at" : "2015-03-03 13:27:30 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572749367511134208",
  "geo" : { },
  "id_str" : "572749830470029313",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 go to intelligentsia !!!",
  "id" : 572749830470029313,
  "in_reply_to_status_id" : 572749367511134208,
  "created_at" : "2015-03-03 13:26:15 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacky",
      "screen_name" : "jackyalcine",
      "indices" : [ 0, 12 ],
      "id_str" : "44119449",
      "id" : 44119449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572728064557236224",
  "geo" : { },
  "id_str" : "572730945809223681",
  "in_reply_to_user_id" : 44119449,
  "text" : "@jackyalcine is Kerbal Space Program still on sale?",
  "id" : 572730945809223681,
  "in_reply_to_status_id" : 572728064557236224,
  "created_at" : "2015-03-03 12:11:12 +0000",
  "in_reply_to_screen_name" : "jackyalcine",
  "in_reply_to_user_id_str" : "44119449",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572592008625307648",
  "geo" : { },
  "id_str" : "572592234375225344",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits agreed. Backbone is still my favorite. But lately been using no frameworks if possible.",
  "id" : 572592234375225344,
  "in_reply_to_status_id" : 572592008625307648,
  "created_at" : "2015-03-03 03:00:01 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/aISiaQFQxf",
      "expanded_url" : "http:\/\/www.allenpike.com\/2015\/javascript-framework-fatigue\/",
      "display_url" : "allenpike.com\/2015\/javascrip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572589684754280448",
  "text" : "The state of JavaScript is awful http:\/\/t.co\/aISiaQFQxf",
  "id" : 572589684754280448,
  "created_at" : "2015-03-03 02:49:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572530410975985665",
  "geo" : { },
  "id_str" : "572530526478716929",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis congrats!",
  "id" : 572530526478716929,
  "in_reply_to_status_id" : 572530410975985665,
  "created_at" : "2015-03-02 22:54:49 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Covert",
      "screen_name" : "brycecovert",
      "indices" : [ 3, 15 ],
      "id_str" : "42809339",
      "id" : 42809339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/wlwemONkW2",
      "expanded_url" : "http:\/\/bit.ly\/1N92PHr",
      "display_url" : "bit.ly\/1N92PHr"
    } ]
  },
  "geo" : { },
  "id_str" : "572473214833713154",
  "text" : "RT @brycecovert: I spoke to a woman who says she was fired for being pregnant and then wound up homeless: http:\/\/t.co\/wlwemONkW2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/wlwemONkW2",
        "expanded_url" : "http:\/\/bit.ly\/1N92PHr",
        "display_url" : "bit.ly\/1N92PHr"
      } ]
    },
    "geo" : { },
    "id_str" : "572446556848308224",
    "text" : "I spoke to a woman who says she was fired for being pregnant and then wound up homeless: http:\/\/t.co\/wlwemONkW2",
    "id" : 572446556848308224,
    "created_at" : "2015-03-02 17:21:09 +0000",
    "user" : {
      "name" : "Bryce Covert",
      "screen_name" : "brycecovert",
      "protected" : false,
      "id_str" : "42809339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573203627415760896\/1ZN_K0Xq_normal.jpeg",
      "id" : 42809339,
      "verified" : true
    }
  },
  "id" : 572473214833713154,
  "created_at" : "2015-03-02 19:07:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Ohms",
      "screen_name" : "jayohms",
      "indices" : [ 3, 11 ],
      "id_str" : "79914475",
      "id" : 79914475
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 44, 54 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572465706010353664",
  "text" : "RT @jayohms: I\u2019m now the 13th programmer at @37signals - how lucky! I\u2019m just happy they didn\u2019t have me start on a Friday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 31, 41 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572445889060573184",
    "text" : "I\u2019m now the 13th programmer at @37signals - how lucky! I\u2019m just happy they didn\u2019t have me start on a Friday.",
    "id" : 572445889060573184,
    "created_at" : "2015-03-02 17:18:30 +0000",
    "user" : {
      "name" : "Jay Ohms",
      "screen_name" : "jayohms",
      "protected" : false,
      "id_str" : "79914475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423509103575441408\/9ljixyVE_normal.jpeg",
      "id" : 79914475,
      "verified" : false
    }
  },
  "id" : 572465706010353664,
  "created_at" : "2015-03-02 18:37:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 43, 49 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572419600664539136\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/PCab7aFNWI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Gkl02UQAIDMQ3.jpg",
      "id_str" : "572419597401341954",
      "id" : 572419597401341954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Gkl02UQAIDMQ3.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PCab7aFNWI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572419600664539136",
  "text" : "Happy Camper provides a great backdrop for @phish at my home battlestation http:\/\/t.co\/PCab7aFNWI",
  "id" : 572419600664539136,
  "created_at" : "2015-03-02 15:34:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572409482841489411\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/oD59V9TWbT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B_GbZCFUsAE-QFl.png",
      "id_str" : "572409482010996737",
      "id" : 572409482010996737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B_GbZCFUsAE-QFl.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/oD59V9TWbT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572409082377842688",
  "geo" : { },
  "id_str" : "572409482841489411",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide http:\/\/t.co\/oD59V9TWbT",
  "id" : 572409482841489411,
  "in_reply_to_status_id" : 572409082377842688,
  "created_at" : "2015-03-02 14:53:50 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572391223090012160\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/BBdmSchNaI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_GKvOpU8AQWlNX.png",
      "id_str" : "572391171642683396",
      "id" : 572391171642683396,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_GKvOpU8AQWlNX.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BBdmSchNaI"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572391223090012160\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/BBdmSchNaI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_GKyKjUsAAExJO.png",
      "id_str" : "572391222083366912",
      "id" : 572391222083366912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_GKyKjUsAAExJO.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BBdmSchNaI"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572391223090012160\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/BBdmSchNaI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_GKx8jVEAEgLt3.png",
      "id_str" : "572391218325295105",
      "id" : 572391218325295105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_GKx8jVEAEgLt3.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BBdmSchNaI"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572391223090012160\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/BBdmSchNaI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_GKvWlVEAEbq-Q.png",
      "id_str" : "572391173773398017",
      "id" : 572391173773398017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_GKvWlVEAEbq-Q.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BBdmSchNaI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "572391223090012160",
  "text" : "A few snapshots from this weekend 13 of http:\/\/t.co\/biwDqHL2ML! http:\/\/t.co\/BBdmSchNaI",
  "id" : 572391223090012160,
  "created_at" : "2015-03-02 13:41:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572370243164585984",
  "text" : "Twitch Plays Pancake",
  "id" : 572370243164585984,
  "created_at" : "2015-03-02 12:17:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572369675843026948",
  "text" : "OH \"I don't care about the physics of pancake flipping\"",
  "id" : 572369675843026948,
  "created_at" : "2015-03-02 12:15:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572203838045859840",
  "text" : "I miss going on my porch.",
  "id" : 572203838045859840,
  "created_at" : "2015-03-02 01:16:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    }, {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 12, 22 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572203442204217345",
  "geo" : { },
  "id_str" : "572203641760686080",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll @chumprock oooh",
  "id" : 572203641760686080,
  "in_reply_to_status_id" : 572203442204217345,
  "created_at" : "2015-03-02 01:15:53 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Hillman",
      "screen_name" : "alexhillman",
      "indices" : [ 3, 15 ],
      "id_str" : "8412",
      "id" : 8412
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/alexhillman\/status\/571762824680226816\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/waieYQkyTc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-9PQmrWkAAIj8-.jpg",
      "id_str" : "571762824378224640",
      "id" : 571762824378224640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-9PQmrWkAAIj8-.jpg",
      "sizes" : [ {
        "h" : 155,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 61,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/waieYQkyTc"
    } ],
    "hashtags" : [ {
      "text" : "coworking",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572171686897848322",
  "text" : "RT @alexhillman: #coworking isn\u2019t a desk rental business, it\u2019s a happiness business. Been saying this for years, now more evidence: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/alexhillman\/status\/571762824680226816\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/waieYQkyTc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-9PQmrWkAAIj8-.jpg",
        "id_str" : "571762824378224640",
        "id" : 571762824378224640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-9PQmrWkAAIj8-.jpg",
        "sizes" : [ {
          "h" : 155,
          "resize" : "fit",
          "w" : 860
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 108,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 61,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 155,
          "resize" : "fit",
          "w" : 860
        } ],
        "display_url" : "pic.twitter.com\/waieYQkyTc"
      } ],
      "hashtags" : [ {
        "text" : "coworking",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571762824680226816",
    "text" : "#coworking isn\u2019t a desk rental business, it\u2019s a happiness business. Been saying this for years, now more evidence: http:\/\/t.co\/waieYQkyTc",
    "id" : 571762824680226816,
    "created_at" : "2015-02-28 20:04:14 +0000",
    "user" : {
      "name" : "Alex Hillman",
      "screen_name" : "alexhillman",
      "protected" : false,
      "id_str" : "8412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568151215826280449\/3ImoO_mn_normal.jpeg",
      "id" : 8412,
      "verified" : false
    }
  },
  "id" : 572171686897848322,
  "created_at" : "2015-03-01 23:08:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 3, 18 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/rdjpmgfPzk",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/govbeat\/wp\/2015\/02\/27\/the-future-of-urbanism-according-to-the-27-year-old-mayor-of-ithaca\/?postshare=9201425182474326",
      "display_url" : "washingtonpost.com\/blogs\/govbeat\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572150431356346368",
  "text" : "RT @ChristineLSloc: TIL that the mayor of one of my favorite cities in NYS is 27. http:\/\/t.co\/rdjpmgfPzk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/rdjpmgfPzk",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/govbeat\/wp\/2015\/02\/27\/the-future-of-urbanism-according-to-the-27-year-old-mayor-of-ithaca\/?postshare=9201425182474326",
        "display_url" : "washingtonpost.com\/blogs\/govbeat\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "572149082032103426",
    "text" : "TIL that the mayor of one of my favorite cities in NYS is 27. http:\/\/t.co\/rdjpmgfPzk",
    "id" : 572149082032103426,
    "created_at" : "2015-03-01 21:39:05 +0000",
    "user" : {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "protected" : false,
      "id_str" : "73221502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569953927438024704\/y_kM5xtD_normal.jpeg",
      "id" : 73221502,
      "verified" : false
    }
  },
  "id" : 572150431356346368,
  "created_at" : "2015-03-01 21:44:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572140806406086656",
  "geo" : { },
  "id_str" : "572150158378475521",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos flip on the left side only",
  "id" : 572150158378475521,
  "in_reply_to_status_id" : 572140806406086656,
  "created_at" : "2015-03-01 21:43:22 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoo boy, its vrunt! ",
      "screen_name" : "vrunt",
      "indices" : [ 92, 98 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "explainamoviebyitstitle",
      "indices" : [ 0, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572138684641746944",
  "text" : "#explainamoviebyitstitle they're in a really old park. Maybe from the Jurrasic time period. @vrunt",
  "id" : 572138684641746944,
  "created_at" : "2015-03-01 20:57:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/572136139261255681\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/M1XhHD3xbo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_CiyItUwAAslVU.png",
      "id_str" : "572136134890799104",
      "id" : 572136134890799104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_CiyItUwAAslVU.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/M1XhHD3xbo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572136139261255681",
  "text" : "NOOOO MY BEEFY ARM!!! also, blue berries?!? http:\/\/t.co\/M1XhHD3xbo",
  "id" : 572136139261255681,
  "created_at" : "2015-03-01 20:47:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/ZQFZJaUVzO",
      "expanded_url" : "http:\/\/imgur.com\/a\/ewjpt",
      "display_url" : "imgur.com\/a\/ewjpt"
    } ]
  },
  "geo" : { },
  "id_str" : "572122014657327104",
  "text" : "Niagara Square mini-model. This is great. http:\/\/t.co\/ZQFZJaUVzO",
  "id" : 572122014657327104,
  "created_at" : "2015-03-01 19:51:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572062592212078594",
  "geo" : { },
  "id_str" : "572066851565506560",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns all sides rage sides",
  "id" : 572066851565506560,
  "in_reply_to_status_id" : 572062592212078594,
  "created_at" : "2015-03-01 16:12:20 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 3, 14 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "taboot",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/OYUTww23bI",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=osQfS9dU_wU",
      "display_url" : "youtube.com\/watch?v=osQfS9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572006881239035905",
  "text" : "RT @Dianna_2Ns: The best thing I've seen on the internet in quite some time :) https:\/\/t.co\/OYUTww23bI #taboot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "taboot",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/OYUTww23bI",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=osQfS9dU_wU",
        "display_url" : "youtube.com\/watch?v=osQfS9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "571514093242339328",
    "text" : "The best thing I've seen on the internet in quite some time :) https:\/\/t.co\/OYUTww23bI #taboot",
    "id" : 571514093242339328,
    "created_at" : "2015-02-28 03:35:52 +0000",
    "user" : {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "protected" : false,
      "id_str" : "67117740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546699404082950144\/apgZNPDY_normal.jpeg",
      "id" : 67117740,
      "verified" : false
    }
  },
  "id" : 572006881239035905,
  "created_at" : "2015-03-01 12:14:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
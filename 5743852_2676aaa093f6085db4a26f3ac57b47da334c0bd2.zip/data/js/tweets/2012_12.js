Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/loZh39Sn",
      "expanded_url" : "http:\/\/quaran.to\/2012\/",
      "display_url" : "quaran.to\/2012\/"
    } ]
  },
  "geo" : { },
  "id_str" : "285898391370747906",
  "text" : "Thanks, 2012: http:\/\/t.co\/loZh39Sn",
  "id" : 285898391370747906,
  "created_at" : "2013-01-01 00:01:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285872417413402625",
  "geo" : { },
  "id_str" : "285874789703352322",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes Woot!",
  "id" : 285874789703352322,
  "in_reply_to_status_id" : 285872417413402625,
  "created_at" : "2012-12-31 22:27:15 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/1Y9UiATV",
      "expanded_url" : "http:\/\/theamericankid.com\/post\/38138659411\/dogs-are-always-happy",
      "display_url" : "theamericankid.com\/post\/381386594\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285873028896784384",
  "text" : "Story of my dog's life: http:\/\/t.co\/1Y9UiATV",
  "id" : 285873028896784384,
  "created_at" : "2012-12-31 22:20:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285871945474535425",
  "geo" : { },
  "id_str" : "285872096641441792",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes Dude, RubyMotion is $200. Cmon now.",
  "id" : 285872096641441792,
  "in_reply_to_status_id" : 285871945474535425,
  "created_at" : "2012-12-31 22:16:33 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/kvW95IJ3",
      "expanded_url" : "http:\/\/jekyllrb.com\/",
      "display_url" : "jekyllrb.com"
    } ]
  },
  "geo" : { },
  "id_str" : "285871243914272770",
  "text" : "Excited to see my old http:\/\/t.co\/kvW95IJ3 design go away for 2013...new site is so much better!",
  "id" : 285871243914272770,
  "created_at" : "2012-12-31 22:13:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 7, 17 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 18, 32 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285844323294142464",
  "geo" : { },
  "id_str" : "285844380340867072",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @magnachef @communitybeer Oh snap i'm coming down.",
  "id" : 285844380340867072,
  "in_reply_to_status_id" : 285844323294142464,
  "created_at" : "2012-12-31 20:26:25 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 11, 25 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285843147500703744",
  "geo" : { },
  "id_str" : "285844323294142464",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @communitybeer whoa, you guys are open today?",
  "id" : 285844323294142464,
  "in_reply_to_status_id" : 285843147500703744,
  "created_at" : "2012-12-31 20:26:12 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/LYmRudUi",
      "expanded_url" : "http:\/\/flic.kr\/p\/dGbdnC",
      "display_url" : "flic.kr\/p\/dGbdnC"
    } ]
  },
  "geo" : { },
  "id_str" : "285808855299014658",
  "text" : "Factory FUN. ISN'T THIS SO MUCH FUN?! http:\/\/t.co\/LYmRudUi",
  "id" : 285808855299014658,
  "created_at" : "2012-12-31 18:05:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/kHy3QIQI",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjDqhHan",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjDq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285802575897432066",
  "text" : "View my 10 latest photos on Flickr: http:\/\/t.co\/kHy3QIQI",
  "id" : 285802575897432066,
  "created_at" : "2012-12-31 17:40:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe",
      "screen_name" : "cwgabriel",
      "indices" : [ 3, 13 ],
      "id_str" : "14464369",
      "id" : 14464369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/lrcxXsNq",
      "expanded_url" : "http:\/\/penny-arcade.com\/comic",
      "display_url" : "penny-arcade.com\/comic"
    } ]
  },
  "geo" : { },
  "id_str" : "285799117370839041",
  "text" : "RT @cwgabriel: If you have played Spaceteam, this has happened to you: http:\/\/t.co\/lrcxXsNq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/lrcxXsNq",
        "expanded_url" : "http:\/\/penny-arcade.com\/comic",
        "display_url" : "penny-arcade.com\/comic"
      } ]
    },
    "geo" : { },
    "id_str" : "285798626146537473",
    "text" : "If you have played Spaceteam, this has happened to you: http:\/\/t.co\/lrcxXsNq",
    "id" : 285798626146537473,
    "created_at" : "2012-12-31 17:24:37 +0000",
    "user" : {
      "name" : "Gabe",
      "screen_name" : "cwgabriel",
      "protected" : false,
      "id_str" : "14464369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3768125890\/e4a85b59dba5e6cf43bd754daf6ea79f_normal.jpeg",
      "id" : 14464369,
      "verified" : false
    }
  },
  "id" : 285799117370839041,
  "created_at" : "2012-12-31 17:26:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 16, 25 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/Dih7bxvF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "285793957663875073",
  "text" : "I'd love to see @OpenHack break 100 cities in 2013. Let's make it happen! http:\/\/t.co\/Dih7bxvF",
  "id" : 285793957663875073,
  "created_at" : "2012-12-31 17:06:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thorben",
      "screen_name" : "walski",
      "indices" : [ 0, 7 ],
      "id_str" : "9292372",
      "id" : 9292372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285510863559983108",
  "geo" : { },
  "id_str" : "285511914354790400",
  "in_reply_to_user_id" : 9292372,
  "text" : "@walski only backbone seems worth it.",
  "id" : 285511914354790400,
  "in_reply_to_status_id" : 285510863559983108,
  "created_at" : "2012-12-30 22:25:19 +0000",
  "in_reply_to_screen_name" : "walski",
  "in_reply_to_user_id_str" : "9292372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thorben",
      "screen_name" : "walski",
      "indices" : [ 0, 7 ],
      "id_str" : "9292372",
      "id" : 9292372
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 8, 14 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285503670844547072",
  "geo" : { },
  "id_str" : "285510404459872257",
  "in_reply_to_user_id" : 9292372,
  "text" : "@walski @drnic why are they all terrible?",
  "id" : 285510404459872257,
  "in_reply_to_status_id" : 285503670844547072,
  "created_at" : "2012-12-30 22:19:19 +0000",
  "in_reply_to_screen_name" : "walski",
  "in_reply_to_user_id_str" : "9292372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285454874395701248",
  "text" : "Bills game: cold, snow, bacon, beer. Don\u2019t care about the outcome, still a good time.",
  "id" : 285454874395701248,
  "created_at" : "2012-12-30 18:38:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285020312804945920",
  "geo" : { },
  "id_str" : "285020659644518400",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo holy crap, you\u2019re making my day already. Happy New Years man, and keep it up!",
  "id" : 285020659644518400,
  "in_reply_to_status_id" : 285020312804945920,
  "created_at" : "2012-12-29 13:53:15 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 11, 24 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284904866663514114",
  "geo" : { },
  "id_str" : "284913874514345985",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything @steveklabnik this brings me back to configuring animated smilies for vbulletin.",
  "id" : 284913874514345985,
  "in_reply_to_status_id" : 284904866663514114,
  "created_at" : "2012-12-29 06:48:55 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284875853320552448",
  "geo" : { },
  "id_str" : "284878415432138753",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer agreed!",
  "id" : 284878415432138753,
  "in_reply_to_status_id" : 284875853320552448,
  "created_at" : "2012-12-29 04:28:01 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284828173835841537",
  "geo" : { },
  "id_str" : "284852249530871808",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg you flying a spaceship?",
  "id" : 284852249530871808,
  "in_reply_to_status_id" : 284828173835841537,
  "created_at" : "2012-12-29 02:44:03 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "12 Grain",
      "screen_name" : "12grainstudio",
      "indices" : [ 0, 14 ],
      "id_str" : "15650314",
      "id" : 15650314
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 33, 47 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284841115172085760",
  "geo" : { },
  "id_str" : "284851893312815105",
  "in_reply_to_user_id" : 15650314,
  "text" : "@12grainstudio you could work at @coworkbuffalo, we\u2019d totally get some ribbon for you! :)",
  "id" : 284851893312815105,
  "in_reply_to_status_id" : 284841115172085760,
  "created_at" : "2012-12-29 02:42:38 +0000",
  "in_reply_to_screen_name" : "12grainstudio",
  "in_reply_to_user_id_str" : "15650314",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 5, 19 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/AoMuCUgr",
      "expanded_url" : "http:\/\/flic.kr\/p\/dFaK22",
      "display_url" : "flic.kr\/p\/dFaK22"
    } ]
  },
  "geo" : { },
  "id_str" : "284847843980767232",
  "text" : "Yep, @communitybeer and 7 Wonders. http:\/\/t.co\/AoMuCUgr",
  "id" : 284847843980767232,
  "created_at" : "2012-12-29 02:26:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/IE9XGySk",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjDonGc9",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjDo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284812743045951488",
  "text" : "View my 6 latest photos on Flickr: http:\/\/t.co\/IE9XGySk",
  "id" : 284812743045951488,
  "created_at" : "2012-12-29 00:07:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wilkening",
      "screen_name" : "bwilken",
      "indices" : [ 0, 8 ],
      "id_str" : "117543486",
      "id" : 117543486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284723358317301760",
  "geo" : { },
  "id_str" : "284809851928997888",
  "in_reply_to_user_id" : 117543486,
  "text" : "@bwilken I'd beg to differ on a global scale :)",
  "id" : 284809851928997888,
  "in_reply_to_status_id" : 284723358317301760,
  "created_at" : "2012-12-28 23:55:34 +0000",
  "in_reply_to_screen_name" : "bwilken",
  "in_reply_to_user_id_str" : "117543486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Skud Bayley",
      "screen_name" : "Skud",
      "indices" : [ 0, 5 ],
      "id_str" : "823980",
      "id" : 823980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284802220858421248",
  "geo" : { },
  "id_str" : "284802998557872129",
  "in_reply_to_user_id" : 823980,
  "text" : "@Skud What are you looking for? :)",
  "id" : 284802998557872129,
  "in_reply_to_status_id" : 284802220858421248,
  "created_at" : "2012-12-28 23:28:20 +0000",
  "in_reply_to_screen_name" : "Skud",
  "in_reply_to_user_id_str" : "823980",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WutsUpBuffalo",
      "screen_name" : "WutsUpBuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "596797766",
      "id" : 596797766
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 19, 31 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WutsUpBuffalo\/status\/284752961329053697\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/VfTRPMZk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_OlT0VCQAAcl2e.jpg",
      "id_str" : "284752961337442304",
      "id" : 284752961337442304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_OlT0VCQAAcl2e.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VfTRPMZk"
    } ],
    "hashtags" : [ {
      "text" : "BuffTrucks",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284765615514849281",
  "text" : "RT @WutsUpBuffalo: @whereslloyd 's \"What The Duck\" tacos today, outstandingly incredible! #BuffTrucks http:\/\/t.co\/VfTRPMZk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lloyd Taco Trucks",
        "screen_name" : "whereslloyd",
        "indices" : [ 0, 12 ],
        "id_str" : "156689065",
        "id" : 156689065
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WutsUpBuffalo\/status\/284752961329053697\/photo\/1",
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/VfTRPMZk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_OlT0VCQAAcl2e.jpg",
        "id_str" : "284752961337442304",
        "id" : 284752961337442304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_OlT0VCQAAcl2e.jpg",
        "sizes" : [ {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/VfTRPMZk"
      } ],
      "hashtags" : [ {
        "text" : "BuffTrucks",
        "indices" : [ 71, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284752961329053697",
    "in_reply_to_user_id" : 156689065,
    "text" : "@whereslloyd 's \"What The Duck\" tacos today, outstandingly incredible! #BuffTrucks http:\/\/t.co\/VfTRPMZk",
    "id" : 284752961329053697,
    "created_at" : "2012-12-28 20:09:32 +0000",
    "in_reply_to_screen_name" : "whereslloyd",
    "in_reply_to_user_id_str" : "156689065",
    "user" : {
      "name" : "WutsUpBuffalo",
      "screen_name" : "WutsUpBuffalo",
      "protected" : false,
      "id_str" : "596797766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458712747337711617\/fj3sr-BQ_normal.png",
      "id" : 596797766,
      "verified" : false
    }
  },
  "id" : 284765615514849281,
  "created_at" : "2012-12-28 20:59:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/WrlutpeJ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aQm7YpxgOnA",
      "display_url" : "youtube.com\/watch?v=aQm7Yp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "284760092103036928",
  "geo" : { },
  "id_str" : "284760216841637888",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt http:\/\/t.co\/WrlutpeJ",
  "id" : 284760216841637888,
  "in_reply_to_status_id" : 284760092103036928,
  "created_at" : "2012-12-28 20:38:20 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    }, {
      "name" : "Co.Design",
      "screen_name" : "FastCoDesign",
      "indices" : [ 15, 28 ],
      "id_str" : "158865339",
      "id" : 158865339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284745945650962432",
  "geo" : { },
  "id_str" : "284746540277436416",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael @FastCoDesign I love how a UI design article has constantly shifting click targets to advance the slideshow",
  "id" : 284746540277436416,
  "in_reply_to_status_id" : 284745945650962432,
  "created_at" : "2012-12-28 19:44:00 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 3, 9 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284746165243768832",
  "text" : "RT @chorn: REMINDER:  HackerNews is a waste of your time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284745939053314048",
    "text" : "REMINDER:  HackerNews is a waste of your time.",
    "id" : 284745939053314048,
    "created_at" : "2012-12-28 19:41:36 +0000",
    "user" : {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "protected" : false,
      "id_str" : "744613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2310147637\/niixqq7ibisfwaat2xmg_normal.png",
      "id" : 744613,
      "verified" : false
    }
  },
  "id" : 284746165243768832,
  "created_at" : "2012-12-28 19:42:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 8, 18 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284694787825737728",
  "geo" : { },
  "id_str" : "284696065796612096",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @aquaranto It's usually a symptom that the code doesn't understand how Ruby's truthiness works",
  "id" : 284696065796612096,
  "in_reply_to_status_id" : 284694787825737728,
  "created_at" : "2012-12-28 16:23:26 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 0, 15 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/vdfUZ1AX",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dwarffortress\/comments\/15k35i\/flat_volcano_embark_seed\/.compact",
      "display_url" : "reddit.com\/r\/dwarffortres\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "284689022083821568",
  "geo" : { },
  "id_str" : "284693533632372737",
  "in_reply_to_user_id" : 7611992,
  "text" : "@importantshock yes! Going to download again to try this seed: http:\/\/t.co\/vdfUZ1AX",
  "id" : 284693533632372737,
  "in_reply_to_status_id" : 284689022083821568,
  "created_at" : "2012-12-28 16:13:22 +0000",
  "in_reply_to_screen_name" : "importantshock",
  "in_reply_to_user_id_str" : "7611992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284690049273049089",
  "geo" : { },
  "id_str" : "284691394549932032",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto bangbangs are usually a smell.",
  "id" : 284691394549932032,
  "in_reply_to_status_id" : 284690049273049089,
  "created_at" : "2012-12-28 16:04:52 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Lindsay",
      "screen_name" : "adamlindsay",
      "indices" : [ 0, 12 ],
      "id_str" : "49763",
      "id" : 49763
    }, {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 13, 26 ],
      "id_str" : "15101175",
      "id" : 15101175
    }, {
      "name" : "Wayne A Arthurton",
      "screen_name" : "warthurton",
      "indices" : [ 27, 38 ],
      "id_str" : "732763",
      "id" : 732763
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/284672787220684800\/photo\/1",
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/YOsUcpyW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_NcZEgCYAEajTf.jpg",
      "id_str" : "284672787229073409",
      "id" : 284672787229073409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_NcZEgCYAEajTf.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/YOsUcpyW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284671701814497280",
  "geo" : { },
  "id_str" : "284672787220684800",
  "in_reply_to_user_id" : 49763,
  "text" : "@adamlindsay @davidmoffitt @warthurton Buffalo\u2019s bus stops aren\u2019t much clearer! http:\/\/t.co\/YOsUcpyW",
  "id" : 284672787220684800,
  "in_reply_to_status_id" : 284671701814497280,
  "created_at" : "2012-12-28 14:50:56 +0000",
  "in_reply_to_screen_name" : "adamlindsay",
  "in_reply_to_user_id_str" : "49763",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284493139031494656",
  "geo" : { },
  "id_str" : "284500484084076544",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat you have lupus.",
  "id" : 284500484084076544,
  "in_reply_to_status_id" : 284493139031494656,
  "created_at" : "2012-12-28 03:26:15 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 0, 6 ],
      "id_str" : "14701738",
      "id" : 14701738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284469936968052738",
  "geo" : { },
  "id_str" : "284471334048772098",
  "in_reply_to_user_id" : 14701738,
  "text" : "@troyd haha yes! Buses are running though! :)",
  "id" : 284471334048772098,
  "in_reply_to_status_id" : 284469936968052738,
  "created_at" : "2012-12-28 01:30:25 +0000",
  "in_reply_to_screen_name" : "troyd",
  "in_reply_to_user_id_str" : "14701738",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284457564832399360",
  "geo" : { },
  "id_str" : "284461549899362305",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox yeah I know, the silence is strange. Been doing RubyMotion since it was released.",
  "id" : 284461549899362305,
  "in_reply_to_status_id" : 284457564832399360,
  "created_at" : "2012-12-28 00:51:33 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284451059936669696",
  "geo" : { },
  "id_str" : "284451171916206081",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits that isn\u2019t real WRASSLIN!!!!",
  "id" : 284451171916206081,
  "in_reply_to_status_id" : 284451059936669696,
  "created_at" : "2012-12-28 00:10:18 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284427315436466176",
  "geo" : { },
  "id_str" : "284448989020049409",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer gah! I forgot to give you guys my embeer card for 2 fills. Next time ok?",
  "id" : 284448989020049409,
  "in_reply_to_status_id" : 284427315436466176,
  "created_at" : "2012-12-28 00:01:38 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284427315436466176",
  "geo" : { },
  "id_str" : "284427604302364672",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer Great! Need a refill.",
  "id" : 284427604302364672,
  "in_reply_to_status_id" : 284427315436466176,
  "created_at" : "2012-12-27 22:36:39 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284424638744895488",
  "geo" : { },
  "id_str" : "284425385515565057",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr a lot of patience and humility. Distance yourself from those who don\u2019t add value.",
  "id" : 284425385515565057,
  "in_reply_to_status_id" : 284424638744895488,
  "created_at" : "2012-12-27 22:27:50 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284423764379320320",
  "geo" : { },
  "id_str" : "284424436432650240",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr haters gonna hate. Most get jaded easily\u2026",
  "id" : 284424436432650240,
  "in_reply_to_status_id" : 284423764379320320,
  "created_at" : "2012-12-27 22:24:04 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284423321850892288",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer are you guys open today?",
  "id" : 284423321850892288,
  "created_at" : "2012-12-27 22:19:38 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284349106653110274",
  "text" : "My favorite part of Open Source: Standing on the shoulders of giants. My least favorite part: Immense effort &amp; time wasted on arguments.",
  "id" : 284349106653110274,
  "created_at" : "2012-12-27 17:24:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284347182218366978",
  "geo" : { },
  "id_str" : "284347269694754817",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy Don't add fuel to the fire.",
  "id" : 284347269694754817,
  "in_reply_to_status_id" : 284347182218366978,
  "created_at" : "2012-12-27 17:17:26 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Benjamin",
      "screen_name" : "danbenjamin",
      "indices" : [ 0, 12 ],
      "id_str" : "5905672",
      "id" : 5905672
    }, {
      "name" : "5by5",
      "screen_name" : "5by5",
      "indices" : [ 13, 18 ],
      "id_str" : "106231780",
      "id" : 106231780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284319480023228416",
  "geo" : { },
  "id_str" : "284323425416278016",
  "in_reply_to_user_id" : 5905672,
  "text" : "@danbenjamin @5by5 I'd love to play! I guess I can help moderate too but I don't play very often. Username is qrush.",
  "id" : 284323425416278016,
  "in_reply_to_status_id" : 284319480023228416,
  "created_at" : "2012-12-27 15:42:41 +0000",
  "in_reply_to_screen_name" : "danbenjamin",
  "in_reply_to_user_id_str" : "5905672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pedro belo",
      "screen_name" : "ped",
      "indices" : [ 0, 4 ],
      "id_str" : "7727182",
      "id" : 7727182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284318774746816513",
  "geo" : { },
  "id_str" : "284319530237452288",
  "in_reply_to_user_id" : 7727182,
  "text" : "@ped Oh duh. Yeah it's *so* hard. I recommend beating it on Easy first. (It's still fucking difficult)",
  "id" : 284319530237452288,
  "in_reply_to_status_id" : 284318774746816513,
  "created_at" : "2012-12-27 15:27:13 +0000",
  "in_reply_to_screen_name" : "ped",
  "in_reply_to_user_id_str" : "7727182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284318904086573057",
  "geo" : { },
  "id_str" : "284319452940611584",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten you haven't been doing ruby\/rails for very long ;)",
  "id" : 284319452940611584,
  "in_reply_to_status_id" : 284318904086573057,
  "created_at" : "2012-12-27 15:26:54 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pedro belo",
      "screen_name" : "ped",
      "indices" : [ 0, 4 ],
      "id_str" : "7727182",
      "id" : 7727182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284317862934478849",
  "geo" : { },
  "id_str" : "284318605011738624",
  "in_reply_to_user_id" : 7727182,
  "text" : "@ped First phase? You had no chance to survive anyway ;)",
  "id" : 284318605011738624,
  "in_reply_to_status_id" : 284317862934478849,
  "created_at" : "2012-12-27 15:23:32 +0000",
  "in_reply_to_screen_name" : "ped",
  "in_reply_to_user_id_str" : "7727182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284317236271910912",
  "geo" : { },
  "id_str" : "284317342215843842",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 Interesting...could try that.",
  "id" : 284317342215843842,
  "in_reply_to_status_id" : 284317236271910912,
  "created_at" : "2012-12-27 15:18:31 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 3, 18 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284315912440524800",
  "text" : "RT @colindabkowski: In the Elmwood Village, dudes with snow shovels stationed at nearly every street corner to help push cars. City of G ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284311064500379648",
    "text" : "In the Elmwood Village, dudes with snow shovels stationed at nearly every street corner to help push cars. City of Good Neighbors, y'all.",
    "id" : 284311064500379648,
    "created_at" : "2012-12-27 14:53:34 +0000",
    "user" : {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "protected" : false,
      "id_str" : "18777886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3037884795\/352233dadcadefd39ba870c00adc3091_normal.jpeg",
      "id" : 18777886,
      "verified" : false
    }
  },
  "id" : 284315912440524800,
  "created_at" : "2012-12-27 15:12:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284299197585432576",
  "text" : "Phone died, plugged in, came back with 34%. Been doing this pretty regularly. Is there any way to replace an iPhone battery?",
  "id" : 284299197585432576,
  "created_at" : "2012-12-27 14:06:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284292158465376258",
  "geo" : { },
  "id_str" : "284292278653161474",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik big lake = big snow :)",
  "id" : 284292278653161474,
  "in_reply_to_status_id" : 284292158465376258,
  "created_at" : "2012-12-27 13:38:55 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284291968543109120",
  "text" : "RT @dhh: Rails is omakase. You\u2019re free to say no unagi, but don\u2019t expect the chef to stop serving it at his restaurant because you don\u2019t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284204812189442049",
    "text" : "Rails is omakase. You\u2019re free to say no unagi, but don\u2019t expect the chef to stop serving it at his restaurant because you don\u2019t like it.",
    "id" : 284204812189442049,
    "created_at" : "2012-12-27 07:51:22 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 284291968543109120,
  "created_at" : "2012-12-27 13:37:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284291709049921536",
  "text" : "There are 12 inches of snow outside. It\u2019s time to let this husky romp around a bit. Would love to hit the dog park but the car is buried.",
  "id" : 284291709049921536,
  "created_at" : "2012-12-27 13:36:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Dever",
      "screen_name" : "clarkdever",
      "indices" : [ 0, 11 ],
      "id_str" : "11081432",
      "id" : 11081432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284161779817402369",
  "geo" : { },
  "id_str" : "284161899883536385",
  "in_reply_to_user_id" : 11081432,
  "text" : "@clarkdever Press X to flip Warthog.",
  "id" : 284161899883536385,
  "in_reply_to_status_id" : 284161779817402369,
  "created_at" : "2012-12-27 05:00:51 +0000",
  "in_reply_to_screen_name" : "clarkdever",
  "in_reply_to_user_id_str" : "11081432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 9, 16 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 17, 30 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284151987967246337",
  "geo" : { },
  "id_str" : "284155814699229185",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @hone02 @steveklabnik what?",
  "id" : 284155814699229185,
  "in_reply_to_status_id" : 284151987967246337,
  "created_at" : "2012-12-27 04:36:40 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sweetadelinevt",
      "screen_name" : "sweetadelinevt",
      "indices" : [ 0, 15 ],
      "id_str" : "22527970",
      "id" : 22527970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284133853923274752",
  "geo" : { },
  "id_str" : "284135137858433024",
  "in_reply_to_user_id" : 22527970,
  "text" : "@sweetadelinevt Buffalo.",
  "id" : 284135137858433024,
  "in_reply_to_status_id" : 284133853923274752,
  "created_at" : "2012-12-27 03:14:30 +0000",
  "in_reply_to_screen_name" : "sweetadelinevt",
  "in_reply_to_user_id_str" : "22527970",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284134320967405568",
  "geo" : { },
  "id_str" : "284134968127545344",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik Why is this better than Go?",
  "id" : 284134968127545344,
  "in_reply_to_status_id" : 284134320967405568,
  "created_at" : "2012-12-27 03:13:50 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 0, 9 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284131945850474497",
  "in_reply_to_user_id" : 171845650,
  "text" : "@IRCCloud Hey, been a paying customer for a while now and I keep getting redirected to alpha.irccloud. can I get back on the main domain?",
  "id" : 284131945850474497,
  "created_at" : "2012-12-27 03:01:49 +0000",
  "in_reply_to_screen_name" : "IRCCloud",
  "in_reply_to_user_id_str" : "171845650",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 36 ],
      "url" : "https:\/\/t.co\/cdvNtuvK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=5g9dekYtN3o",
      "display_url" : "youtube.com\/watch?v=5g9dek\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "284129438424248324",
  "geo" : { },
  "id_str" : "284129686928384000",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety also, https:\/\/t.co\/cdvNtuvK",
  "id" : 284129686928384000,
  "in_reply_to_status_id" : 284129438424248324,
  "created_at" : "2012-12-27 02:52:50 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284129079370862592",
  "text" : "I can report accurately that huskies are extremely happy bouncing around 6\" of snow.",
  "id" : 284129079370862592,
  "created_at" : "2012-12-27 02:50:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284128547545690112",
  "geo" : { },
  "id_str" : "284128797165490180",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 Days: 1",
  "id" : 284128797165490180,
  "in_reply_to_status_id" : 284128547545690112,
  "created_at" : "2012-12-27 02:49:18 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284127886997348352",
  "text" : "WINTER IS COMING, LIKE RIGHT NOW, OUTSIDE OF MY HOUSE.",
  "id" : 284127886997348352,
  "created_at" : "2012-12-27 02:45:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284109534857920513",
  "geo" : { },
  "id_str" : "284122567411916800",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide thanks, we needed this.",
  "id" : 284122567411916800,
  "in_reply_to_status_id" : 284109534857920513,
  "created_at" : "2012-12-27 02:24:33 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284093882768175104",
  "text" : "And someone took the puppy. Glad we didn\u2019t drive out\u2026but WTF is up with this year and losing things :(",
  "id" : 284093882768175104,
  "created_at" : "2012-12-27 00:30:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284093648180740097",
  "geo" : { },
  "id_str" : "284093723166523392",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant did this happen?",
  "id" : 284093723166523392,
  "in_reply_to_status_id" : 284093648180740097,
  "created_at" : "2012-12-27 00:29:56 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284092936076021760",
  "geo" : { },
  "id_str" : "284093006284464128",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant uhh, what?",
  "id" : 284093006284464128,
  "in_reply_to_status_id" : 284092936076021760,
  "created_at" : "2012-12-27 00:27:05 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284074346077642752",
  "text" : "Snow is preventing us from going to rescue a new pup. Hoping it won\u2019t be gone by Friday.",
  "id" : 284074346077642752,
  "created_at" : "2012-12-26 23:12:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284058916617351168",
  "geo" : { },
  "id_str" : "284062396253868032",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending my favorite feature of JIRA: when canceling an issue, the two options presented are [Cancel] [Cancel]",
  "id" : 284062396253868032,
  "in_reply_to_status_id" : 284058916617351168,
  "created_at" : "2012-12-26 22:25:27 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/0xn8Sif9",
      "expanded_url" : "http:\/\/bits.blogs.nytimes.com\/2012\/12\/26\/an-early-tale-of-the-internet\/?smid=tw-nytimesbits&seid=auto",
      "display_url" : "bits.blogs.nytimes.com\/2012\/12\/26\/an-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284028199699095552",
  "text" : "\u201CDr. Hart, it says here that you\u2019ve received 2,493,786,916 packets of bits. Is that correct?\u201D - http:\/\/t.co\/0xn8Sif9",
  "id" : 284028199699095552,
  "created_at" : "2012-12-26 20:09:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 72 ],
      "url" : "https:\/\/t.co\/kLP6BOZU",
      "expanded_url" : "https:\/\/www.name.com\/new-gtld",
      "display_url" : "name.com\/new-gtld"
    } ]
  },
  "geo" : { },
  "id_str" : "284000694468489216",
  "text" : "Something about this list just doesn't feel right: https:\/\/t.co\/kLP6BOZU",
  "id" : 284000694468489216,
  "created_at" : "2012-12-26 18:20:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engine Yard Cloud",
      "screen_name" : "eycloud",
      "indices" : [ 0, 8 ],
      "id_str" : "43025324",
      "id" : 43025324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283998209427255296",
  "geo" : { },
  "id_str" : "283998300997292032",
  "in_reply_to_user_id" : 43025324,
  "text" : "@eycloud it\u2019s back!",
  "id" : 283998300997292032,
  "in_reply_to_status_id" : 283998209427255296,
  "created_at" : "2012-12-26 18:10:46 +0000",
  "in_reply_to_screen_name" : "eycloud",
  "in_reply_to_user_id_str" : "43025324",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283997996625063936",
  "text" : "RT @rubygems_status: Dependency API should be back now, we were not forwarding requests to the right IP at Heroku. Sorry folks.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283997956712067073",
    "text" : "Dependency API should be back now, we were not forwarding requests to the right IP at Heroku. Sorry folks.",
    "id" : 283997956712067073,
    "created_at" : "2012-12-26 18:09:23 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 283997996625063936,
  "created_at" : "2012-12-26 18:09:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283994165166092288",
  "text" : "RT @rubygems_status: Looks like the Dependency API is down. Not sure why yet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283994105158172673",
    "text" : "Looks like the Dependency API is down. Not sure why yet.",
    "id" : 283994105158172673,
    "created_at" : "2012-12-26 17:54:05 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 283994165166092288,
  "created_at" : "2012-12-26 17:54:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283985438279102466",
  "geo" : { },
  "id_str" : "283987916089327616",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto wat.",
  "id" : 283987916089327616,
  "in_reply_to_status_id" : 283985438279102466,
  "created_at" : "2012-12-26 17:29:30 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/ZGIMAhnr",
      "expanded_url" : "http:\/\/mikecanex.wordpress.com\/2012\/12\/26\/1922-why-i-quit-being-so-accommodating\/",
      "display_url" : "mikecanex.wordpress.com\/2012\/12\/26\/192\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "283987774992961536",
  "text" : "Stunning essay from 1922: http:\/\/t.co\/ZGIMAhnr Worth the read.",
  "id" : 283987774992961536,
  "created_at" : "2012-12-26 17:28:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Berkopec",
      "screen_name" : "nateberkopec",
      "indices" : [ 0, 13 ],
      "id_str" : "18259813",
      "id" : 18259813
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 56, 70 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283976069235740672",
  "geo" : { },
  "id_str" : "283976435255873538",
  "in_reply_to_user_id" : 18259813,
  "text" : "@nateberkopec ha, we make chemex several times daily at @coworkbuffalo...just tried the individual size. :)",
  "id" : 283976435255873538,
  "in_reply_to_status_id" : 283976069235740672,
  "created_at" : "2012-12-26 16:43:52 +0000",
  "in_reply_to_screen_name" : "nateberkopec",
  "in_reply_to_user_id_str" : "18259813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Levi Neuland",
      "screen_name" : "levineuland",
      "indices" : [ 0, 12 ],
      "id_str" : "15387091",
      "id" : 15387091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283970407755833344",
  "geo" : { },
  "id_str" : "283976290493669376",
  "in_reply_to_user_id" : 15387091,
  "text" : "@levineuland You're next!",
  "id" : 283976290493669376,
  "in_reply_to_status_id" : 283970407755833344,
  "created_at" : "2012-12-26 16:43:18 +0000",
  "in_reply_to_screen_name" : "levineuland",
  "in_reply_to_user_id_str" : "15387091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 31, 42 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283975768860672000",
  "text" : "Made my first Hario pour-over. @kevinpurdy would be proud.",
  "id" : 283975768860672000,
  "created_at" : "2012-12-26 16:41:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/283967310434295810\/photo\/1",
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/9ZFyI8fV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_Daw6qCYAMpnLY.png",
      "id_str" : "283967310438490115",
      "id" : 283967310438490115,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_Daw6qCYAMpnLY.png",
      "sizes" : [ {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 916
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 916
      } ],
      "display_url" : "pic.twitter.com\/9ZFyI8fV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283967310434295810",
  "text" : "WINTER IS COMING http:\/\/t.co\/9ZFyI8fV",
  "id" : 283967310434295810,
  "created_at" : "2012-12-26 16:07:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 13, 24 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283965512625553408",
  "text" : "@juliepagano @ashedryden yes, just an observation in general.",
  "id" : 283965512625553408,
  "created_at" : "2012-12-26 16:00:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283961120149090305",
  "text" : "My rule with the internet shithole that is paper.li is this: if you use it and I'm mentioned, you get flagged\/reported for spam! :D",
  "id" : 283961120149090305,
  "created_at" : "2012-12-26 15:43:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 3, 11 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283960142272274432",
  "text" : "RT @noahhlo: Why are the brightest minds of my generation working on ads instead of developing concrete that doesn't collect snow?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283959887967440896",
    "text" : "Why are the brightest minds of my generation working on ads instead of developing concrete that doesn't collect snow?",
    "id" : 283959887967440896,
    "created_at" : "2012-12-26 15:38:07 +0000",
    "user" : {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "protected" : false,
      "id_str" : "234465384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412045673408651264\/CPEGZ-93_normal.jpeg",
      "id" : 234465384,
      "verified" : false
    }
  },
  "id" : 283960142272274432,
  "created_at" : "2012-12-26 15:39:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/uVgGBpJP",
      "expanded_url" : "http:\/\/contributors.rubyonrails.org\/contributors?window=this-month",
      "display_url" : "contributors.rubyonrails.org\/contributors?w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "283951390580162560",
  "geo" : { },
  "id_str" : "283951547036086273",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic http:\/\/t.co\/uVgGBpJP",
  "id" : 283951547036086273,
  "in_reply_to_status_id" : 283951390580162560,
  "created_at" : "2012-12-26 15:04:59 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/oiis2yL0",
      "expanded_url" : "http:\/\/rubyonrails.org\/core",
      "display_url" : "rubyonrails.org\/core"
    } ]
  },
  "geo" : { },
  "id_str" : "283950777192570880",
  "text" : "Noticed that http:\/\/t.co\/oiis2yL0 is missing some XX chromosomes...hoping that changes over the next few years.",
  "id" : 283950777192570880,
  "created_at" : "2012-12-26 15:01:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283948302041501698",
  "text" : "RT @coworkbuffalo: We are open. Come down and get some work done before the storm hits! Also: bring cookies.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283948253882494976",
    "text" : "We are open. Come down and get some work done before the storm hits! Also: bring cookies.",
    "id" : 283948253882494976,
    "created_at" : "2012-12-26 14:51:53 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 283948302041501698,
  "created_at" : "2012-12-26 14:52:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Sheu \u8A31\u5BB6\u8C6A",
      "screen_name" : "ulysseas",
      "indices" : [ 0, 9 ],
      "id_str" : "229946505",
      "id" : 229946505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283813372695293953",
  "geo" : { },
  "id_str" : "283813496020418560",
  "in_reply_to_user_id" : 229946505,
  "text" : "@ulysseas at least viewing diffs, etc shouldn\u2019t be so difficult",
  "id" : 283813496020418560,
  "in_reply_to_status_id" : 283813372695293953,
  "created_at" : "2012-12-26 05:56:25 +0000",
  "in_reply_to_screen_name" : "ulysseas",
  "in_reply_to_user_id_str" : "229946505",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283812802043469824",
  "text" : "Also GitHub is terrible on mobile. :(",
  "id" : 283812802043469824,
  "created_at" : "2012-12-26 05:53:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/283812681897607168\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/egYZvwBm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_BOIWfCAAAT1sQ.png",
      "id_str" : "283812681905995776",
      "id" : 283812681905995776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_BOIWfCAAAT1sQ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/egYZvwBm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283812681897607168",
  "text" : "GMail\u2019s Open In Chrome pops open Chrome with a GMail back button. Such a good use of internal protocols. http:\/\/t.co\/egYZvwBm",
  "id" : 283812681897607168,
  "created_at" : "2012-12-26 05:53:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283683895914950656",
  "geo" : { },
  "id_str" : "283692376013299713",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark Ged has been very excited and jumpy. Going to get slammed tomorrow with 12\u201D tomorrow",
  "id" : 283692376013299713,
  "in_reply_to_status_id" : 283683895914950656,
  "created_at" : "2012-12-25 21:55:07 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 0, 10 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "283682594514677760",
  "geo" : { },
  "id_str" : "283683820769783808",
  "in_reply_to_user_id" : 13235612,
  "text" : "@alindeman you should upgrade http:\/\/t.co\/t7WATcFT! Feel free to write about it, use that as a sample chapter :)",
  "id" : 283683820769783808,
  "in_reply_to_status_id" : 283682594514677760,
  "created_at" : "2012-12-25 21:21:08 +0000",
  "in_reply_to_screen_name" : "alindeman",
  "in_reply_to_user_id_str" : "13235612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283678337413550080",
  "geo" : { },
  "id_str" : "283680017039384576",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg oh geez",
  "id" : 283680017039384576,
  "in_reply_to_status_id" : 283678337413550080,
  "created_at" : "2012-12-25 21:06:01 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 13, 26 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283624581795819522",
  "geo" : { },
  "id_str" : "283625217610350594",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath @steveklabnik BREAKING NEWS, people believe different things",
  "id" : 283625217610350594,
  "in_reply_to_status_id" : 283624581795819522,
  "created_at" : "2012-12-25 17:28:16 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 0, 11 ],
      "id_str" : "14931637",
      "id" : 14931637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 80 ],
      "url" : "https:\/\/t.co\/sYTAfOs5",
      "expanded_url" : "https:\/\/twitter.com\/search?q=%22I%20didn't%20get%20an%20iPhone%22&src=typd",
      "display_url" : "twitter.com\/search?q=%22I%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "283581620777267200",
  "in_reply_to_user_id" : 14931637,
  "text" : "@MattBinder i\u2019ll let you handle this one. Merry Christmas! https:\/\/t.co\/sYTAfOs5",
  "id" : 283581620777267200,
  "created_at" : "2012-12-25 14:35:01 +0000",
  "in_reply_to_screen_name" : "MattBinder",
  "in_reply_to_user_id_str" : "14931637",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 38 ],
      "url" : "https:\/\/t.co\/sYTAfOs5",
      "expanded_url" : "https:\/\/twitter.com\/search?q=%22I%20didn't%20get%20an%20iPhone%22&src=typd",
      "display_url" : "twitter.com\/search?q=%22I%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "283581372843560960",
  "text" : "Merry Christmas! https:\/\/t.co\/sYTAfOs5",
  "id" : 283581372843560960,
  "created_at" : "2012-12-25 14:34:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/cRIGwS37",
      "expanded_url" : "http:\/\/flic.kr\/p\/dE68yu",
      "display_url" : "flic.kr\/p\/dE68yu"
    } ]
  },
  "geo" : { },
  "id_str" : "283578346237997056",
  "text" : "Christmassed out. http:\/\/t.co\/cRIGwS37",
  "id" : 283578346237997056,
  "created_at" : "2012-12-25 14:22:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283394901620686848",
  "geo" : { },
  "id_str" : "283422562954932224",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr Actually in Ohio ;)",
  "id" : 283422562954932224,
  "in_reply_to_status_id" : 283394901620686848,
  "created_at" : "2012-12-25 04:02:59 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283382067855777793",
  "geo" : { },
  "id_str" : "283382361138270209",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone crazy. Wonder how many bare metal boxes you\u2019d need.",
  "id" : 283382361138270209,
  "in_reply_to_status_id" : 283382067855777793,
  "created_at" : "2012-12-25 01:23:14 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 7, 18 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283382086407188480",
  "geo" : { },
  "id_str" : "283382190585307136",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @ashedryden actually this is funnier and not worth deletion.",
  "id" : 283382190585307136,
  "in_reply_to_status_id" : 283382086407188480,
  "created_at" : "2012-12-25 01:22:33 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283381856513175552",
  "geo" : { },
  "id_str" : "283382086407188480",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden how is car babby formed",
  "id" : 283382086407188480,
  "in_reply_to_status_id" : 283381856513175552,
  "created_at" : "2012-12-25 01:22:09 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283381922745442304",
  "text" : "Snowing on I79. Very glad I am not driving.",
  "id" : 283381922745442304,
  "created_at" : "2012-12-25 01:21:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283380622775418880",
  "geo" : { },
  "id_str" : "283381634911305728",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden wat? Babby?",
  "id" : 283381634911305728,
  "in_reply_to_status_id" : 283380622775418880,
  "created_at" : "2012-12-25 01:20:21 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283381261924454400",
  "geo" : { },
  "id_str" : "283381544117207041",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone that\u2019s insane. Are they weak servers? Just seems like a lot.",
  "id" : 283381544117207041,
  "in_reply_to_status_id" : 283381261924454400,
  "created_at" : "2012-12-25 01:19:59 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283372542117425152",
  "text" : "OH \u201Cthat [bloody mary] is spicy, but I can\u2019t taste the boobs in it!\u201D",
  "id" : 283372542117425152,
  "created_at" : "2012-12-25 00:44:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283360112129761280",
  "geo" : { },
  "id_str" : "283362688447430656",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner I know that I need to try this.",
  "id" : 283362688447430656,
  "in_reply_to_status_id" : 283360112129761280,
  "created_at" : "2012-12-25 00:05:04 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283345845150167041",
  "text" : "The problem with old photos: no tagging.",
  "id" : 283345845150167041,
  "created_at" : "2012-12-24 22:58:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ecRLQk72",
      "expanded_url" : "http:\/\/flic.kr\/p\/dDVQ2S",
      "display_url" : "flic.kr\/p\/dDVQ2S"
    } ]
  },
  "geo" : { },
  "id_str" : "283341023336337408",
  "text" : "Someone dragged out old slides and we're watching them over a sheet. http:\/\/t.co\/ecRLQk72",
  "id" : 283341023336337408,
  "created_at" : "2012-12-24 22:38:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/283246557053210624\/photo\/1",
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/SK5UkmK0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-5LPjFCUAATyu7.png",
      "id_str" : "283246557057404928",
      "id" : 283246557057404928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-5LPjFCUAATyu7.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/SK5UkmK0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283246557053210624",
  "text" : "Siri: the FUTURE http:\/\/t.co\/SK5UkmK0",
  "id" : 283246557053210624,
  "created_at" : "2012-12-24 16:23:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283149499617116160",
  "geo" : { },
  "id_str" : "283245872840572930",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek added, not sure how minefold works with time anymore.",
  "id" : 283245872840572930,
  "in_reply_to_status_id" : 283149499617116160,
  "created_at" : "2012-12-24 16:20:53 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/Oo8MoLHY",
      "expanded_url" : "http:\/\/flic.kr\/p\/dDQc9Y",
      "display_url" : "flic.kr\/p\/dDQc9Y"
    } ]
  },
  "geo" : { },
  "id_str" : "283240169329545216",
  "text" : "Italian Christmas = 3 lbs of fresh pasta. http:\/\/t.co\/Oo8MoLHY",
  "id" : 283240169329545216,
  "created_at" : "2012-12-24 15:58:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283230521620828160",
  "text" : "Sad about the news out of Rochester. As the son of a firefighter &amp; captain I can\u2019t imagine what those families are going through.",
  "id" : 283230521620828160,
  "created_at" : "2012-12-24 15:19:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 12, 22 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283078679301595137",
  "geo" : { },
  "id_str" : "283080938328563713",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @listrophy hah was watching but playing minecraft :3",
  "id" : 283080938328563713,
  "in_reply_to_status_id" : 283078679301595137,
  "created_at" : "2012-12-24 05:25:29 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283004884020776960",
  "geo" : { },
  "id_str" : "283008283378327552",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden we love doing this for grandparents on the iPad. So mind blowing.",
  "id" : 283008283378327552,
  "in_reply_to_status_id" : 283004884020776960,
  "created_at" : "2012-12-24 00:36:47 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/TD77GEBQ",
      "expanded_url" : "http:\/\/flic.kr\/p\/dDCFEy",
      "display_url" : "flic.kr\/p\/dDCFEy"
    } ]
  },
  "geo" : { },
  "id_str" : "282989511284232192",
  "text" : "Geddy wants to play King of Tokyo. http:\/\/t.co\/TD77GEBQ",
  "id" : 282989511284232192,
  "created_at" : "2012-12-23 23:22:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 92 ],
      "url" : "https:\/\/t.co\/nTl5TVCB",
      "expanded_url" : "https:\/\/minefold.com\/servers\/50439",
      "display_url" : "minefold.com\/servers\/50439"
    } ]
  },
  "geo" : { },
  "id_str" : "282971931685294080",
  "text" : "If anyone is up for some Minecraft, @ me your username and let's play! https:\/\/t.co\/nTl5TVCB",
  "id" : 282971931685294080,
  "created_at" : "2012-12-23 22:12:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 68 ],
      "url" : "https:\/\/t.co\/tGMtBlYo",
      "expanded_url" : "https:\/\/minefold.com\/i\/8qVc5HGdIvOA",
      "display_url" : "minefold.com\/i\/8qVc5HGdIvOA"
    } ]
  },
  "geo" : { },
  "id_str" : "282969899414978560",
  "text" : "Checking out Minecraft again...anyone want in? https:\/\/t.co\/tGMtBlYo",
  "id" : 282969899414978560,
  "created_at" : "2012-12-23 22:04:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282966354917724160",
  "geo" : { },
  "id_str" : "282966545372684288",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel it\u2019s the idents.",
  "id" : 282966545372684288,
  "in_reply_to_status_id" : 282966354917724160,
  "created_at" : "2012-12-23 21:50:56 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/CQhlCJEU",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=Lun-CYrXPAE&desktop_uri=%2Fwatch%3Fv%3DLun-CYrXPAE",
      "display_url" : "m.youtube.com\/#\/watch?v=Lun-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "282962860278177792",
  "geo" : { },
  "id_str" : "282963321974554624",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine http:\/\/t.co\/CQhlCJEU",
  "id" : 282963321974554624,
  "in_reply_to_status_id" : 282962860278177792,
  "created_at" : "2012-12-23 21:38:07 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282952881911508993",
  "text" : "Ohio Confederate Flag count: 1, in the front window of a house. Nothing completes a home like announcing how racist you are on the outside.",
  "id" : 282952881911508993,
  "created_at" : "2012-12-23 20:56:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 5, 9 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282716987484958721",
  "geo" : { },
  "id_str" : "282719578860167168",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh @rjs it\u2019s about broken trust for me. User dent or not, they have lost mine.",
  "id" : 282719578860167168,
  "in_reply_to_status_id" : 282716987484958721,
  "created_at" : "2012-12-23 05:29:34 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282705491325497344",
  "text" : "First Contact and then Wrath of Khan on Syfy...this is why I don't have cable.",
  "id" : 282705491325497344,
  "created_at" : "2012-12-23 04:33:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282700473650253825",
  "text" : "Flickr still lets you plug in an ICQ number to your profile.",
  "id" : 282700473650253825,
  "created_at" : "2012-12-23 04:13:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/p23weQIW",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush",
      "display_url" : "flickr.com\/photos\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "282698189600079872",
  "text" : "Officially off Instagram, and back on Flickr. All photos CC licensed. Woot! http:\/\/t.co\/p23weQIW",
  "id" : 282698189600079872,
  "created_at" : "2012-12-23 04:04:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 9, 17 ],
      "id_str" : "6083342",
      "id" : 6083342
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 18, 29 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 30, 42 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/282696885997817856\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ziyJNXee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-xXUe1CUAE_jIy.jpg",
      "id_str" : "282696886002012161",
      "id" : 282696886002012161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-xXUe1CUAE_jIy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ziyJNXee"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282696358450851840",
  "geo" : { },
  "id_str" : "282696885997817856",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @bascule @tenderlove @coreyhaines Am I doing this right? http:\/\/t.co\/ziyJNXee",
  "id" : 282696885997817856,
  "in_reply_to_status_id" : 282696358450851840,
  "created_at" : "2012-12-23 03:59:25 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 9, 17 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282693526582611968",
  "geo" : { },
  "id_str" : "282694988331114496",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @bascule I'm feeling the same way...sympathetic but this just sucks.",
  "id" : 282694988331114496,
  "in_reply_to_status_id" : 282693526582611968,
  "created_at" : "2012-12-23 03:51:52 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282505436492623872",
  "geo" : { },
  "id_str" : "282506996555579392",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant Bought it on amazon though. Do they let you bring it into the store still?",
  "id" : 282506996555579392,
  "in_reply_to_status_id" : 282505436492623872,
  "created_at" : "2012-12-22 15:24:51 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 13, 24 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/h2SphMXm",
      "expanded_url" : "http:\/\/www.bradbranson.com\/wp-content\/uploads\/2012\/06\/his_mind-blown.gif",
      "display_url" : "bradbranson.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "282505057788899328",
  "geo" : { },
  "id_str" : "282505599139328000",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd @dangigante http:\/\/t.co\/h2SphMXm",
  "id" : 282505599139328000,
  "in_reply_to_status_id" : 282505057788899328,
  "created_at" : "2012-12-22 15:19:18 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282504221604081664",
  "text" : "Does your Airport Express need its settings restored every 1-2 weeks? 5GHz not working now or wired connection. Very frustrating.",
  "id" : 282504221604081664,
  "created_at" : "2012-12-22 15:13:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282497086287659009",
  "geo" : { },
  "id_str" : "282498110633148417",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd Tacos for breakfast? Game changing.",
  "id" : 282498110633148417,
  "in_reply_to_status_id" : 282497086287659009,
  "created_at" : "2012-12-22 14:49:32 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/lPyvqXL1",
      "expanded_url" : "http:\/\/www.flickr.com\/holidaygift",
      "display_url" : "flickr.com\/holidaygift"
    } ]
  },
  "geo" : { },
  "id_str" : "282356314963853312",
  "text" : "RT @asianmack: Flickr's holiday gift: 3 months of Pro for free. http:\/\/t.co\/lPyvqXL1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/lPyvqXL1",
        "expanded_url" : "http:\/\/www.flickr.com\/holidaygift",
        "display_url" : "flickr.com\/holidaygift"
      } ]
    },
    "geo" : { },
    "id_str" : "282343164168261632",
    "text" : "Flickr's holiday gift: 3 months of Pro for free. http:\/\/t.co\/lPyvqXL1",
    "id" : 282343164168261632,
    "created_at" : "2012-12-22 04:33:50 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 282356314963853312,
  "created_at" : "2012-12-22 05:26:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282343164168261632",
  "geo" : { },
  "id_str" : "282354222937292802",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack awesome, I need to import my photos now! Thanks dude.",
  "id" : 282354222937292802,
  "in_reply_to_status_id" : 282343164168261632,
  "created_at" : "2012-12-22 05:17:47 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282341042425057280",
  "text" : "I just wanted to play Assassin\u2019s Creed after beating it a few months ago. Forced to watch a cutscene and credits.",
  "id" : 282341042425057280,
  "created_at" : "2012-12-22 04:25:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282281166134988800",
  "geo" : { },
  "id_str" : "282284946666700800",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto WHAT.",
  "id" : 282284946666700800,
  "in_reply_to_status_id" : 282281166134988800,
  "created_at" : "2012-12-22 00:42:30 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 8, 15 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/282284893352906752\/photo\/1",
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/ENP7P8hJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-rgnWoCUAEozzN.jpg",
      "id_str" : "282284893357101057",
      "id" : 282284893357101057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-rgnWoCUAEozzN.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/ENP7P8hJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282284893352906752",
  "text" : "This is @nb3004\u2019s idea of a good time. http:\/\/t.co\/ENP7P8hJ",
  "id" : 282284893352906752,
  "created_at" : "2012-12-22 00:42:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/MD4fGQ9J",
      "expanded_url" : "http:\/\/rebase.github.com\/",
      "display_url" : "rebase.github.com"
    }, {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/JJokt0GG",
      "expanded_url" : "http:\/\/rebase.github.com\/5.html",
      "display_url" : "rebase.github.com\/5.html"
    } ]
  },
  "geo" : { },
  "id_str" : "282217293029707777",
  "text" : "Enjoying the frozen in time aspect of http:\/\/t.co\/MD4fGQ9J  ... awesome graphs on http:\/\/t.co\/JJokt0GG  !",
  "id" : 282217293029707777,
  "created_at" : "2012-12-21 20:13:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/PSLMhOrN",
      "expanded_url" : "http:\/\/smiley.37signals.com",
      "display_url" : "smiley.37signals.com"
    } ]
  },
  "geo" : { },
  "id_str" : "282128332789784576",
  "text" : "RT @dhh: Biggest group at 37signals? Our lovely support team, now 10 strong: http:\/\/t.co\/PSLMhOrN. Compared: 8 designers, 9 programmers, ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/PSLMhOrN",
        "expanded_url" : "http:\/\/smiley.37signals.com",
        "display_url" : "smiley.37signals.com"
      } ]
    },
    "geo" : { },
    "id_str" : "282125265814032384",
    "text" : "Biggest group at 37signals? Our lovely support team, now 10 strong: http:\/\/t.co\/PSLMhOrN. Compared: 8 designers, 9 programmers, 6 sysops.",
    "id" : 282125265814032384,
    "created_at" : "2012-12-21 14:07:59 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 282128332789784576,
  "created_at" : "2012-12-21 14:20:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281977573519548417",
  "text" : "Latest feature of my Xbox: freeze constantly. This is much more fun than Disc Unreadable!",
  "id" : 281977573519548417,
  "created_at" : "2012-12-21 04:21:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 3, 9 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ahuj9\/status\/281967954915123200\/photo\/1",
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/oAdIQhXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-nAXG9CYAA1SkC.jpg",
      "id_str" : "281967954923511808",
      "id" : 281967954923511808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-nAXG9CYAA1SkC.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oAdIQhXh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281969522796277760",
  "text" : "RT @ahuj9: I keep clicking \"polarize\" in Photoshop but none of my pictures come out like this. http:\/\/t.co\/oAdIQhXh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ahuj9\/status\/281967954915123200\/photo\/1",
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/oAdIQhXh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-nAXG9CYAA1SkC.jpg",
        "id_str" : "281967954923511808",
        "id" : 281967954923511808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-nAXG9CYAA1SkC.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/oAdIQhXh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281967954915123200",
    "text" : "I keep clicking \"polarize\" in Photoshop but none of my pictures come out like this. http:\/\/t.co\/oAdIQhXh",
    "id" : 281967954915123200,
    "created_at" : "2012-12-21 03:42:54 +0000",
    "user" : {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "protected" : false,
      "id_str" : "205281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2438738477\/m3tcrt9kvs9x0ff84b31_normal.jpeg",
      "id" : 205281746,
      "verified" : false
    }
  },
  "id" : 281969522796277760,
  "created_at" : "2012-12-21 03:49:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281961029024485377",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik And fixed. woo...",
  "id" : 281961029024485377,
  "created_at" : "2012-12-21 03:15:22 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 35 ],
      "url" : "https:\/\/t.co\/jbUvG9aS",
      "expanded_url" : "https:\/\/gist.github.com\/4350445",
      "display_url" : "gist.github.com\/4350445"
    } ]
  },
  "in_reply_to_status_id_str" : "281948277203673088",
  "geo" : { },
  "id_str" : "281960662282936320",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik https:\/\/t.co\/jbUvG9aS",
  "id" : 281960662282936320,
  "in_reply_to_status_id" : 281948277203673088,
  "created_at" : "2012-12-21 03:13:55 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/16u0yh8f",
      "expanded_url" : "http:\/\/www.neilpeart.net\/index.php?cID=234",
      "display_url" : "neilpeart.net\/index.php?cID=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281960024459341825",
  "text" : "\"[a yearbook was] created by Geddy for all three of us on an app called Oldbooth\" You never know who's using your app! http:\/\/t.co\/16u0yh8f",
  "id" : 281960024459341825,
  "created_at" : "2012-12-21 03:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 90, 100 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/klCbt4JN",
      "expanded_url" : "http:\/\/www.neilpeart.net\/index.php?cID=233",
      "display_url" : "neilpeart.net\/index.php?cID=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281958461758124033",
  "text" : "Love these absolutely human stories from the Professor himself. http:\/\/t.co\/klCbt4JN (via @mletterle)",
  "id" : 281958461758124033,
  "created_at" : "2012-12-21 03:05:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/QRusLKqt",
      "expanded_url" : "http:\/\/codepen.io\/qrush\/full\/ifgux",
      "display_url" : "codepen.io\/qrush\/full\/ifg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281955540375052288",
  "text" : "Gotta start somewhere, right? Just tooling around with requestAnimationFrame. http:\/\/t.co\/QRusLKqt",
  "id" : 281955540375052288,
  "created_at" : "2012-12-21 02:53:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/wh5lQZR8",
      "expanded_url" : "http:\/\/codepen.io\/sstephenson\/pen\/LrJIG",
      "display_url" : "codepen.io\/sstephenson\/pe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281954160558088194",
  "text" : "Really enjoying codepen for sharing fun snippets of code, and finding them too: http:\/\/t.co\/wh5lQZR8",
  "id" : 281954160558088194,
  "created_at" : "2012-12-21 02:48:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cassandra Moffitt",
      "screen_name" : "cassandrarife",
      "indices" : [ 0, 14 ],
      "id_str" : "2585986136",
      "id" : 2585986136
    }, {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 15, 28 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281899406444335104",
  "geo" : { },
  "id_str" : "281938479770914816",
  "in_reply_to_user_id" : 15666852,
  "text" : "@cassandrarife @davidmoffitt Life is pretty good, expensive though and no respawn.",
  "id" : 281938479770914816,
  "in_reply_to_status_id" : 281899406444335104,
  "created_at" : "2012-12-21 01:45:46 +0000",
  "in_reply_to_screen_name" : "ladymoffitt",
  "in_reply_to_user_id_str" : "15666852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281934187487956992",
  "text" : "It sucks to be a dog owner sometimes, but it all evens out. Watching my husky chase stuff and twitch in his dreams is so good.",
  "id" : 281934187487956992,
  "created_at" : "2012-12-21 01:28:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 28, 38 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 46, 54 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 59, 70 ],
      "id_str" : "426455861",
      "id" : 426455861
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/281913563839336449\/photo\/1",
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/fMeva3MW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-mO5IaCEAAA9X_.jpg",
      "id_str" : "281913563847725056",
      "id" : 281913563847725056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-mO5IaCEAAA9X_.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fMeva3MW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281913563839336449",
  "text" : "Oppan Gangham Sock Style on @aquaranto ! (via @jayunit and @cadeparade) http:\/\/t.co\/fMeva3MW",
  "id" : 281913563839336449,
  "created_at" : "2012-12-21 00:06:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281537904948441088",
  "geo" : { },
  "id_str" : "281883746632867841",
  "in_reply_to_user_id" : 38359088,
  "text" : "@becca_waxer HOW IS TWITTER FORMED?",
  "id" : 281883746632867841,
  "in_reply_to_status_id" : 281537904948441088,
  "created_at" : "2012-12-20 22:08:17 +0000",
  "in_reply_to_screen_name" : "BeccaGatesman",
  "in_reply_to_user_id_str" : "38359088",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 8, 22 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281883494395805696",
  "text" : "Hey hey @communitybeer you're open until 7 right? I have several growlers in need of emergency refill.",
  "id" : 281883494395805696,
  "created_at" : "2012-12-20 22:07:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281854637974364160",
  "text" : "RT @mperham: My advice for writing good Ruby code: use objects.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281854314400600065",
    "text" : "My advice for writing good Ruby code: use objects.",
    "id" : 281854314400600065,
    "created_at" : "2012-12-20 20:11:19 +0000",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519271188569128960\/i2t9GfcA_normal.jpeg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 281854637974364160,
  "created_at" : "2012-12-20 20:12:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "indices" : [ 0, 12 ],
      "id_str" : "906546798",
      "id" : 906546798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/j2KG1uYS",
      "expanded_url" : "http:\/\/openhack.github.com\/pittsburgh\/",
      "display_url" : "openhack.github.com\/pittsburgh\/"
    } ]
  },
  "in_reply_to_status_id_str" : "281814679163138048",
  "geo" : { },
  "id_str" : "281852571520466944",
  "in_reply_to_user_id" : 906546798,
  "text" : "@OpenHackPGH you folks need to update http:\/\/t.co\/j2KG1uYS !",
  "id" : 281852571520466944,
  "in_reply_to_status_id" : 281814679163138048,
  "created_at" : "2012-12-20 20:04:24 +0000",
  "in_reply_to_screen_name" : "OpenHackPGH",
  "in_reply_to_user_id_str" : "906546798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "indices" : [ 3, 15 ],
      "id_str" : "906546798",
      "id" : 906546798
    }, {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "indices" : [ 27, 39 ],
      "id_str" : "906546798",
      "id" : 906546798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ko5TANZG",
      "expanded_url" : "http:\/\/www.meetup.com\/pittsburgh-ruby\/events\/96033112\/",
      "display_url" : "meetup.com\/pittsburgh-rub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281852456806252544",
  "text" : "RT @OpenHackPGH: The first @OpenHackPGH will be on January 21st - http:\/\/t.co\/ko5TANZG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack Pittsburgh",
        "screen_name" : "OpenHackPGH",
        "indices" : [ 10, 22 ],
        "id_str" : "906546798",
        "id" : 906546798
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/ko5TANZG",
        "expanded_url" : "http:\/\/www.meetup.com\/pittsburgh-ruby\/events\/96033112\/",
        "display_url" : "meetup.com\/pittsburgh-rub\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281814679163138048",
    "text" : "The first @OpenHackPGH will be on January 21st - http:\/\/t.co\/ko5TANZG",
    "id" : 281814679163138048,
    "created_at" : "2012-12-20 17:33:50 +0000",
    "user" : {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "protected" : false,
      "id_str" : "906546798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2999669692\/b62b12f60738a31585a880c970d66aae_normal.png",
      "id" : 906546798,
      "verified" : false
    }
  },
  "id" : 281852456806252544,
  "created_at" : "2012-12-20 20:03:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281845868691333121",
  "text" : "7 folks at @coworkbuffalo today, 2 meetups held this week at the space. A year ago Buffalo had no coworking space at all. Woot!",
  "id" : 281845868691333121,
  "created_at" : "2012-12-20 19:37:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281830026251485184",
  "geo" : { },
  "id_str" : "281830199497220096",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @kevinpurdy Quite sure a different Paula was involved.",
  "id" : 281830199497220096,
  "in_reply_to_status_id" : 281830026251485184,
  "created_at" : "2012-12-20 18:35:30 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 13, 24 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281826731952852992",
  "text" : "I'm watching @kevinpurdy eat a burger inside of a donut. In 30 years his heart will regret this day.",
  "id" : 281826731952852992,
  "created_at" : "2012-12-20 18:21:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281792654885404672",
  "geo" : { },
  "id_str" : "281793179517337600",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer We have a spare fridge for beer. Trying to avoid the fratboy atmosphere.",
  "id" : 281793179517337600,
  "in_reply_to_status_id" : 281792654885404672,
  "created_at" : "2012-12-20 16:08:24 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robb",
      "screen_name" : "ceterum_censeo",
      "indices" : [ 3, 18 ],
      "id_str" : "20190095",
      "id" : 20190095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281792810099822592",
  "text" : "RT @ceterum_censeo: stash it, pop it, grep it, move it,\nconfig, prune it, format-patch it,\nadd it, reset, add it, show it,\ngit help refl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281789451527671808",
    "text" : "stash it, pop it, grep it, move it,\nconfig, prune it, format-patch it,\nadd it, reset, add it, show it,\ngit help reflog, pull --rebase it,",
    "id" : 281789451527671808,
    "created_at" : "2012-12-20 15:53:35 +0000",
    "user" : {
      "name" : "robb",
      "screen_name" : "ceterum_censeo",
      "protected" : false,
      "id_str" : "20190095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573600942542602240\/fLoIJ-2o_normal.png",
      "id" : 20190095,
      "verified" : false
    }
  },
  "id" : 281792810099822592,
  "created_at" : "2012-12-20 16:06:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 62, 76 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281792428191645696",
  "text" : "Cowork Buffalo = @coworkbuffalo = CWB, Community Beer Works = @communitybeer = CBW",
  "id" : 281792428191645696,
  "created_at" : "2012-12-20 16:05:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/nRCZnkjx",
      "expanded_url" : "https:\/\/gist.github.com\/4345987",
      "display_url" : "gist.github.com\/4345987"
    } ]
  },
  "in_reply_to_status_id_str" : "281758835465670656",
  "geo" : { },
  "id_str" : "281786336460029952",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal Ah, no idea about the other crap you need to support, but just a success\/failure object is fine: https:\/\/t.co\/nRCZnkjx",
  "id" : 281786336460029952,
  "in_reply_to_status_id" : 281758835465670656,
  "created_at" : "2012-12-20 15:41:12 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281729692711661570",
  "geo" : { },
  "id_str" : "281757801548767232",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal too complicated. Why not accept a jquery style object?",
  "id" : 281757801548767232,
  "in_reply_to_status_id" : 281729692711661570,
  "created_at" : "2012-12-20 13:47:49 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281633023345184768",
  "text" : "Carcassone has some sharing too: witness my terrible solitaire score! carcassonne:\/\/\/s\/b84\/13e5\/Nick (love the use of this protocol)",
  "id" : 281633023345184768,
  "created_at" : "2012-12-20 05:31:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/thzHCVQV",
      "expanded_url" : "http:\/\/replay.letterpress.atebits.com\/#9a241c306dc049f04b6c82947c2042a2",
      "display_url" : "replay.letterpress.atebits.com\/#9a241c306dc04\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281625072236646400",
  "text" : "Letterpress replays are really well done: http:\/\/t.co\/thzHCVQV",
  "id" : 281625072236646400,
  "created_at" : "2012-12-20 05:00:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281612310915727361",
  "text" : "You have Carcassone on iOS. I have a Game Center ID of quaranto. You will bring it.",
  "id" : 281612310915727361,
  "created_at" : "2012-12-20 04:09:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quick Left, Inc.",
      "screen_name" : "quickleft",
      "indices" : [ 0, 10 ],
      "id_str" : "17565474",
      "id" : 17565474
    }, {
      "name" : "mkdir -- -rf",
      "screen_name" : "baroquebobcat",
      "indices" : [ 11, 25 ],
      "id_str" : "14247442",
      "id" : 14247442
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 48, 57 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281520478600978432",
  "geo" : { },
  "id_str" : "281609293252395008",
  "in_reply_to_user_id" : 17565474,
  "text" : "@quickleft @baroquebobcat smells like a boulder @openhack ?!",
  "id" : 281609293252395008,
  "in_reply_to_status_id" : 281520478600978432,
  "created_at" : "2012-12-20 03:57:42 +0000",
  "in_reply_to_screen_name" : "quickleft",
  "in_reply_to_user_id_str" : "17565474",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/oRrK074S",
      "expanded_url" : "http:\/\/tailgate32.com\/play\/buf",
      "display_url" : "tailgate32.com\/play\/buf"
    } ]
  },
  "geo" : { },
  "id_str" : "281573557979471872",
  "text" : "Woot, @tailgate_32's Buffalo episode is out! http:\/\/t.co\/oRrK074S",
  "id" : 281573557979471872,
  "created_at" : "2012-12-20 01:35:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Schoolcraft",
      "screen_name" : "jschoolcraft",
      "indices" : [ 0, 13 ],
      "id_str" : "14225666",
      "id" : 14225666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281569547876704256",
  "geo" : { },
  "id_str" : "281569688675307521",
  "in_reply_to_user_id" : 14225666,
  "text" : "@jschoolcraft nope?",
  "id" : 281569688675307521,
  "in_reply_to_status_id" : 281569547876704256,
  "created_at" : "2012-12-20 01:20:19 +0000",
  "in_reply_to_screen_name" : "jschoolcraft",
  "in_reply_to_user_id_str" : "14225666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/fugpXaoe",
      "expanded_url" : "http:\/\/i.qkme.me\/3s9c1q.jpg",
      "display_url" : "i.qkme.me\/3s9c1q.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "281563689973334016",
  "text" : "Finally, Reddit hits on why I hate getting haircuts. http:\/\/t.co\/fugpXaoe",
  "id" : 281563689973334016,
  "created_at" : "2012-12-20 00:56:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/281545538917265408\/photo\/1",
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/hbz9YaOI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-hALQwCcAIZhpo.png",
      "id_str" : "281545538929848322",
      "id" : 281545538929848322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-hALQwCcAIZhpo.png",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 459
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 459
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 459
      } ],
      "display_url" : "pic.twitter.com\/hbz9YaOI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281545538917265408",
  "text" : "Apparently band members on turntable get their own face as an avatar? Really odd. http:\/\/t.co\/hbz9YaOI",
  "id" : 281545538917265408,
  "created_at" : "2012-12-19 23:44:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bandit",
      "screen_name" : "UtilityLimb",
      "indices" : [ 3, 15 ],
      "id_str" : "188124096",
      "id" : 188124096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281488541693911041",
  "text" : "RT @UtilityLimb: Programming Skills: PRIMARILY RUBY AND PYTHON BUT I CAN USE ANY TYPE OF GEM TO CONTROL ANY TYPE OF SNAKE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126780301211992064",
    "text" : "Programming Skills: PRIMARILY RUBY AND PYTHON BUT I CAN USE ANY TYPE OF GEM TO CONTROL ANY TYPE OF SNAKE",
    "id" : 126780301211992064,
    "created_at" : "2011-10-19 22:02:33 +0000",
    "user" : {
      "name" : "bandit",
      "screen_name" : "UtilityLimb",
      "protected" : false,
      "id_str" : "188124096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1641418276\/tumblr_lule5ckvND1qz4yoco1_1280_normal.png",
      "id" : 188124096,
      "verified" : false
    }
  },
  "id" : 281488541693911041,
  "created_at" : "2012-12-19 19:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/281408392558428160\/photo\/1",
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/tqD7SCgo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-fDcSuCQAApXqb.png",
      "id_str" : "281408392562622464",
      "id" : 281408392562622464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-fDcSuCQAApXqb.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/tqD7SCgo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281408392558428160",
  "text" : "My home internet sucks so bad. :( http:\/\/t.co\/tqD7SCgo",
  "id" : 281408392558428160,
  "created_at" : "2012-12-19 14:39:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stuart (UNUSED)",
      "screen_name" : "mortice",
      "indices" : [ 0, 8 ],
      "id_str" : "8102782",
      "id" : 8102782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281406536855736320",
  "geo" : { },
  "id_str" : "281406965215789056",
  "in_reply_to_user_id" : 15951542,
  "text" : "@mortice Not really. The \"full index\" on an internal gem server should be very small...unless if you're hosting 10000s of gems",
  "id" : 281406965215789056,
  "in_reply_to_status_id" : 281406536855736320,
  "created_at" : "2012-12-19 14:33:43 +0000",
  "in_reply_to_screen_name" : "rentalcustard",
  "in_reply_to_user_id_str" : "15951542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stuart (UNUSED)",
      "screen_name" : "mortice",
      "indices" : [ 0, 8 ],
      "id_str" : "8102782",
      "id" : 8102782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/qieLxHHP",
      "expanded_url" : "http:\/\/guides.rubygems.org\/rubygems-org-api\/#misc",
      "display_url" : "guides.rubygems.org\/rubygems-org-a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281393233144193024",
  "geo" : { },
  "id_str" : "281406411961929728",
  "in_reply_to_user_id" : 15951542,
  "text" : "@mortice Bundler uses the dependencies endpoint here: http:\/\/t.co\/qieLxHHP",
  "id" : 281406411961929728,
  "in_reply_to_status_id" : 281393233144193024,
  "created_at" : "2012-12-19 14:31:31 +0000",
  "in_reply_to_screen_name" : "rentalcustard",
  "in_reply_to_user_id_str" : "15951542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stuart (UNUSED)",
      "screen_name" : "mortice",
      "indices" : [ 0, 8 ],
      "id_str" : "8102782",
      "id" : 8102782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281343765787074560",
  "geo" : { },
  "id_str" : "281393141406392320",
  "in_reply_to_user_id" : 15951542,
  "text" : "@mortice what metadata?",
  "id" : 281393141406392320,
  "in_reply_to_status_id" : 281343765787074560,
  "created_at" : "2012-12-19 13:38:47 +0000",
  "in_reply_to_screen_name" : "rentalcustard",
  "in_reply_to_user_id_str" : "15951542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281392814326177792",
  "geo" : { },
  "id_str" : "281393046774505473",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten you can toss any files in a gem\u2026running that code is then your problem :)",
  "id" : 281393046774505473,
  "in_reply_to_status_id" : 281392814326177792,
  "created_at" : "2012-12-19 13:38:25 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 26, 39 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281268781802725376",
  "geo" : { },
  "id_str" : "281271451389132800",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx as proprietor of @herpderpedia, there\u2019s enough shame in just running one",
  "id" : 281271451389132800,
  "in_reply_to_status_id" : 281268781802725376,
  "created_at" : "2012-12-19 05:35:14 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281270796431810560",
  "geo" : { },
  "id_str" : "281271247126532096",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm laaaame. Need a GameOpenHack :)",
  "id" : 281271247126532096,
  "in_reply_to_status_id" : 281270796431810560,
  "created_at" : "2012-12-19 05:34:25 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281256238954708992",
  "geo" : { },
  "id_str" : "281270366217838593",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant I was expecting more trolls",
  "id" : 281270366217838593,
  "in_reply_to_status_id" : 281256238954708992,
  "created_at" : "2012-12-19 05:30:55 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281244058930790400",
  "geo" : { },
  "id_str" : "281270135581462528",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr sure, love the post.",
  "id" : 281270135581462528,
  "in_reply_to_status_id" : 281244058930790400,
  "created_at" : "2012-12-19 05:30:00 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/281243516062023680\/photo\/1",
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/g09FL5Yd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-ctfN7CQAAcCVV.jpg",
      "id_str" : "281243516070412288",
      "id" : 281243516070412288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-ctfN7CQAAcCVV.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/g09FL5Yd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281243516062023680",
  "text" : "Possibly the best Quiddler out ever. http:\/\/t.co\/g09FL5Yd",
  "id" : 281243516062023680,
  "created_at" : "2012-12-19 03:44:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 39, 48 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/281226549238300673\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/izq3E03A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-ceDnkCAAENmiT.jpg",
      "id_str" : "281226549242494977",
      "id" : 281226549242494977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-ceDnkCAAENmiT.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/izq3E03A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281226549238300673",
  "text" : "15 folks, new faces, and a makerbot at @openhack makes for an awesome and productive night! http:\/\/t.co\/izq3E03A",
  "id" : 281226549238300673,
  "created_at" : "2012-12-19 02:36:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "281216859460759553",
  "text" : "Cleared the http:\/\/t.co\/bdjsRgTW support queue of ~50 issues. There are 4567 spam emails. Never going that inbox again.",
  "id" : 281216859460759553,
  "created_at" : "2012-12-19 01:58:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281201961028706306",
  "geo" : { },
  "id_str" : "281203889653563393",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi Search is on \/search. You mean the search input field?",
  "id" : 281203889653563393,
  "in_reply_to_status_id" : 281201961028706306,
  "created_at" : "2012-12-19 01:06:46 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 99, 120 ],
      "url" : "https:\/\/t.co\/X4AnaKnP",
      "expanded_url" : "https:\/\/www.google.com\/search?hl=en&q=%22Ryan+Davis%22+ruby&ie=utf-8&tbm=blg&tbs=qdr:m",
      "display_url" : "google.com\/search?hl=en&q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281199003729797120",
  "text" : "Does anyone know how these kind of spam queries for http:\/\/t.co\/bdjsRgTW are showing up in Google? https:\/\/t.co\/X4AnaKnP",
  "id" : 281199003729797120,
  "created_at" : "2012-12-19 00:47:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 16, 26 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 59, 68 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281191170967748608",
  "text" : "A big thanks to @37signals for chipping in pizza\/wings for @OpenHack Buffalo!",
  "id" : 281191170967748608,
  "created_at" : "2012-12-19 00:16:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281166898492735488",
  "geo" : { },
  "id_str" : "281170521368952833",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn yeah it just doesn't smell right in any way. Glad I did it.",
  "id" : 281170521368952833,
  "in_reply_to_status_id" : 281166898492735488,
  "created_at" : "2012-12-18 22:54:10 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 8, 17 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 114 ],
      "url" : "https:\/\/t.co\/1XfDUUeX",
      "expanded_url" : "https:\/\/github.com\/OpenHack\/openhack.github.com\/issues\/70",
      "display_url" : "github.com\/OpenHack\/openh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281168373021302784",
  "text" : "It's an @OpenHack christmas miracle! Would love your feedback on a global hangout\/talk idea: https:\/\/t.co\/1XfDUUeX",
  "id" : 281168373021302784,
  "created_at" : "2012-12-18 22:45:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/jHO1gnP3",
      "expanded_url" : "http:\/\/blog.instagram.com\/post\/38252135408\/thank-you-and-were-listening",
      "display_url" : "blog.instagram.com\/post\/382521354\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281165473033383936",
  "text" : "Perhaps deleted my account too hastily, but now I can license my photos properly and stop checking \"another\" feed. http:\/\/t.co\/jHO1gnP3",
  "id" : 281165473033383936,
  "created_at" : "2012-12-18 22:34:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 3, 13 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 24, 33 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 45, 59 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/2JtEA15N",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/993-openhack",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281154600218800129",
  "text" : "RT @magnachef: #Buffalo @OpenHack tonight at @CoworkBuffalo - go hack stuff!  http:\/\/t.co\/2JtEA15N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 9, 18 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 30, 44 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/2JtEA15N",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/993-openhack",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281150615718080512",
    "text" : "#Buffalo @OpenHack tonight at @CoworkBuffalo - go hack stuff!  http:\/\/t.co\/2JtEA15N",
    "id" : 281150615718080512,
    "created_at" : "2012-12-18 21:35:04 +0000",
    "user" : {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "protected" : false,
      "id_str" : "23703410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557740024620261376\/4Td91096_normal.jpeg",
      "id" : 23703410,
      "verified" : false
    }
  },
  "id" : 281154600218800129,
  "created_at" : "2012-12-18 21:50:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff",
      "screen_name" : "geodbz",
      "indices" : [ 0, 7 ],
      "id_str" : "16128269",
      "id" : 16128269
    }, {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 8, 21 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281125434123493376",
  "geo" : { },
  "id_str" : "281126253254283264",
  "in_reply_to_user_id" : 16128269,
  "text" : "@geodbz @codemastermm or upgrade git and it will do this for you automatically every so often.",
  "id" : 281126253254283264,
  "in_reply_to_status_id" : 281125434123493376,
  "created_at" : "2012-12-18 19:58:16 +0000",
  "in_reply_to_screen_name" : "geodbz",
  "in_reply_to_user_id_str" : "16128269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 37, 47 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 86, 97 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/GZWlbNGU",
      "expanded_url" : "http:\/\/philippajrice.com\/#item=soppy",
      "display_url" : "philippajrice.com\/#item=soppy"
    } ]
  },
  "geo" : { },
  "id_str" : "281124920681971712",
  "text" : "Found a comic of basically, mine and @aquaranto 's life. http:\/\/t.co\/GZWlbNGU (thanks @ashedryden!)",
  "id" : 281124920681971712,
  "created_at" : "2012-12-18 19:52:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/8yuNffg9",
      "expanded_url" : "http:\/\/www.amazon.com\/Passion-Natural-Water-Based-Lubricant-Gallon\/dp\/B005MR3IVO",
      "display_url" : "amazon.com\/Passion-Natura\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281118402167332864",
  "text" : "Just in case, you know: http:\/\/t.co\/8yuNffg9 (Not prime-able!)",
  "id" : 281118402167332864,
  "created_at" : "2012-12-18 19:27:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 9, 18 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281117316413005825",
  "geo" : { },
  "id_str" : "281117483996422144",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @coderjoe worlds are colliding in extremely strange ways right now",
  "id" : 281117483996422144,
  "in_reply_to_status_id" : 281117316413005825,
  "created_at" : "2012-12-18 19:23:25 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/wuPJ9FQA",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/theyearinreview",
      "display_url" : "youtube.com\/user\/theyearin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281116827579461633",
  "text" : "This is so meta it hurts: http:\/\/t.co\/wuPJ9FQA",
  "id" : 281116827579461633,
  "created_at" : "2012-12-18 19:20:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 8, 20 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 21, 34 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281106928590000129",
  "geo" : { },
  "id_str" : "281108958763155456",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates @coreyhaines @gilesgoatboy Seriously, that's definitely not the only way. Discounting other ways to refactor would be silly.",
  "id" : 281108958763155456,
  "in_reply_to_status_id" : 281106928590000129,
  "created_at" : "2012-12-18 18:49:33 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281089307954016256",
  "geo" : { },
  "id_str" : "281089917994561536",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi what hath i wrought. I'm not trying to discourage discussion here. bring it!",
  "id" : 281089917994561536,
  "in_reply_to_status_id" : 281089307954016256,
  "created_at" : "2012-12-18 17:33:53 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281089192317038592",
  "geo" : { },
  "id_str" : "281089412459290624",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule nyoooooooooo i hate the stop worrying and [something] titles :(",
  "id" : 281089412459290624,
  "in_reply_to_status_id" : 281089192317038592,
  "created_at" : "2012-12-18 17:31:52 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Solnica",
      "screen_name" : "_solnic_",
      "indices" : [ 0, 9 ],
      "id_str" : "14698700",
      "id" : 14698700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281087026579783680",
  "geo" : { },
  "id_str" : "281087531305545730",
  "in_reply_to_user_id" : 14698700,
  "text" : "@_solnic_ It's been in Rails for a while. Even in my talk I encouraged its use in moderation. It's just a simple Extract Method.",
  "id" : 281087531305545730,
  "in_reply_to_status_id" : 281087026579783680,
  "created_at" : "2012-12-18 17:24:24 +0000",
  "in_reply_to_screen_name" : "_solnic_",
  "in_reply_to_user_id_str" : "14698700",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Solnica",
      "screen_name" : "_solnic_",
      "indices" : [ 0, 9 ],
      "id_str" : "14698700",
      "id" : 14698700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281081490912190464",
  "geo" : { },
  "id_str" : "281086594922975232",
  "in_reply_to_user_id" : 14698700,
  "text" : "@_solnic_ Oh cmon now, I'm not trying to shut down discussion about this.",
  "id" : 281086594922975232,
  "in_reply_to_status_id" : 281081490912190464,
  "created_at" : "2012-12-18 17:20:41 +0000",
  "in_reply_to_screen_name" : "_solnic_",
  "in_reply_to_user_id_str" : "14698700",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/9luXzLLw",
      "expanded_url" : "http:\/\/reactimg.com\/images\/81.gif",
      "display_url" : "reactimg.com\/images\/81.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "281077934750593024",
  "geo" : { },
  "id_str" : "281078643868971008",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage http:\/\/t.co\/9luXzLLw",
  "id" : 281078643868971008,
  "in_reply_to_status_id" : 281077934750593024,
  "created_at" : "2012-12-18 16:49:05 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 0, 9 ],
      "id_str" : "14103289",
      "id" : 14103289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281077140592664576",
  "geo" : { },
  "id_str" : "281078441116303360",
  "in_reply_to_user_id" : 14103289,
  "text" : "@plukevdh We have ~250 .live calls, everything is fine. What's the problem?",
  "id" : 281078441116303360,
  "in_reply_to_status_id" : 281077140592664576,
  "created_at" : "2012-12-18 16:48:17 +0000",
  "in_reply_to_screen_name" : "plukevdh",
  "in_reply_to_user_id_str" : "14103289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 0, 9 ],
      "id_str" : "14103289",
      "id" : 14103289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281075989499486208",
  "geo" : { },
  "id_str" : "281076813705400321",
  "in_reply_to_user_id" : 14103289,
  "text" : "@plukevdh Wat?",
  "id" : 281076813705400321,
  "in_reply_to_status_id" : 281075989499486208,
  "created_at" : "2012-12-18 16:41:49 +0000",
  "in_reply_to_screen_name" : "plukevdh",
  "in_reply_to_user_id_str" : "14103289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/pC7vjP95",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3167-code-spelunking-in-the-all-new-basecamp",
      "display_url" : "37signals.com\/svn\/posts\/3167\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281073961658368001",
  "text" : "Concerns are just one piece of the bigger Basecamp puzzle: http:\/\/t.co\/pC7vjP95",
  "id" : 281073961658368001,
  "created_at" : "2012-12-18 16:30:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/wuvFFVkH",
      "expanded_url" : "http:\/\/37svn.com\/3372",
      "display_url" : "37svn.com\/3372"
    } ]
  },
  "geo" : { },
  "id_str" : "281072871390973952",
  "text" : "Bracing for the OO purist reaction to http:\/\/t.co\/wuvFFVkH. Bikeshedding about this draws us further away from who we write software for.",
  "id" : 281072871390973952,
  "created_at" : "2012-12-18 16:26:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281068023203381248",
  "text" : "It's always a little spooky when you leave and arrive on exactly the time Google Maps said you would.",
  "id" : 281068023203381248,
  "created_at" : "2012-12-18 16:06:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281060977661841409",
  "geo" : { },
  "id_str" : "281066406286610433",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef WUP WUP WUP",
  "id" : 281066406286610433,
  "in_reply_to_status_id" : 281060977661841409,
  "created_at" : "2012-12-18 16:00:27 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281040498217586688",
  "geo" : { },
  "id_str" : "281041435422236672",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 This isn't worth it.",
  "id" : 281041435422236672,
  "in_reply_to_status_id" : 281040498217586688,
  "created_at" : "2012-12-18 14:21:14 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281036872757702657",
  "geo" : { },
  "id_str" : "281039965494865920",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden GUILT GAMING",
  "id" : 281039965494865920,
  "in_reply_to_status_id" : 281036872757702657,
  "created_at" : "2012-12-18 14:15:23 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dropbox",
      "screen_name" : "Dropbox",
      "indices" : [ 38, 46 ],
      "id_str" : "14749606",
      "id" : 14749606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281038788296318976",
  "text" : "Instagram account deleted. Hurray for @dropbox photo backup\/sync!",
  "id" : 281038788296318976,
  "created_at" : "2012-12-18 14:10:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281033869996748800",
  "text" : "New Carcassone expansion!!! Woot!",
  "id" : 281033869996748800,
  "created_at" : "2012-12-18 13:51:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280865442501885953",
  "geo" : { },
  "id_str" : "280904837347045376",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr thanks man!",
  "id" : 280904837347045376,
  "in_reply_to_status_id" : 280865442501885953,
  "created_at" : "2012-12-18 05:18:26 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/slkmoA3h",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/65ee239ad0edfeb6f49173feae7ad2fb\/tumblr_mf6kechNF71qz7e7fo1_500.jpg",
      "display_url" : "25.media.tumblr.com\/65ee239ad0edfe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280819108830928898",
  "text" : "Current status: http:\/\/t.co\/slkmoA3h",
  "id" : 280819108830928898,
  "created_at" : "2012-12-17 23:37:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 12, 21 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280813142697734144",
  "text" : "Excited for @openhack Buffalo tomorrow\u202633 cities signed up!",
  "id" : 280813142697734144,
  "created_at" : "2012-12-17 23:14:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 3, 10 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/g6zRCPc9",
      "expanded_url" : "http:\/\/scraps.cssboy.com\/post\/38151581085\/doing-something",
      "display_url" : "scraps.cssboy.com\/post\/381515810\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280710125830950912",
  "text" : "RT @cssboy: If you have a moment, please read this. http:\/\/t.co\/g6zRCPc9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/g6zRCPc9",
        "expanded_url" : "http:\/\/scraps.cssboy.com\/post\/38151581085\/doing-something",
        "display_url" : "scraps.cssboy.com\/post\/381515810\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280709902572322816",
    "text" : "If you have a moment, please read this. http:\/\/t.co\/g6zRCPc9",
    "id" : 280709902572322816,
    "created_at" : "2012-12-17 16:23:50 +0000",
    "user" : {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "protected" : false,
      "id_str" : "3928731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1536392271\/image_normal.jpg",
      "id" : 3928731,
      "verified" : false
    }
  },
  "id" : 280710125830950912,
  "created_at" : "2012-12-17 16:24:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "in_reply_to_status_id_str" : "280707509872910336",
  "geo" : { },
  "id_str" : "280707591405969409",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh http:\/\/t.co\/epnjp2aB",
  "id" : 280707591405969409,
  "in_reply_to_status_id" : 280707509872910336,
  "created_at" : "2012-12-17 16:14:39 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280702580928159744",
  "geo" : { },
  "id_str" : "280703322439155713",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald I'd say we're believers in Intelligent Design ;)",
  "id" : 280703322439155713,
  "in_reply_to_status_id" : 280702580928159744,
  "created_at" : "2012-12-17 15:57:41 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 48, 58 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/wDS8e87b",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3370-why-i-learned-to-make-things#extended",
      "display_url" : "37signals.com\/svn\/posts\/3370\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280701828071575553",
  "text" : "\"Creation is the language that\u2019s spoken most at @37signals\" - http:\/\/t.co\/wDS8e87b",
  "id" : 280701828071575553,
  "created_at" : "2012-12-17 15:51:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280694250084106240",
  "text" : "Good mashups make you smile.",
  "id" : 280694250084106240,
  "created_at" : "2012-12-17 15:21:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280689363489259520",
  "text" : "@billyist Nyoooooooo.... :(",
  "id" : 280689363489259520,
  "created_at" : "2012-12-17 15:02:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "280689222149603331",
  "text" : "DJing in the CoworkBuffalo room. Now playing Yonder Mountain String Band: Snow On The Pines \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 280689222149603331,
  "created_at" : "2012-12-17 15:01:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/rie3CyTs",
      "expanded_url" : "http:\/\/www.rit.edu\/news\/story.php?id=49640&source=enewsletter",
      "display_url" : "rit.edu\/news\/story.php\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280679953052344320",
  "text" : "An RIT Software Engineering grad helped invent the Kinect! Awesome! http:\/\/t.co\/rie3CyTs",
  "id" : 280679953052344320,
  "created_at" : "2012-12-17 14:24:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 3, 11 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280673833474732033",
  "text" : "RT @bokmann: 1-dress up as Santa, take a flight. 2-opt out @ TSA, get frisked. 3-tell passing kids Xmas is cancelled; they wont let toys ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280647925397327872",
    "text" : "1-dress up as Santa, take a flight. 2-opt out @ TSA, get frisked. 3-tell passing kids Xmas is cancelled; they wont let toys thru security.",
    "id" : 280647925397327872,
    "created_at" : "2012-12-17 12:17:34 +0000",
    "user" : {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "protected" : false,
      "id_str" : "14662889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226947944\/dbock-headshot-tight_normal.jpg",
      "id" : 14662889,
      "verified" : false
    }
  },
  "id" : 280673833474732033,
  "created_at" : "2012-12-17 14:00:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 3, 16 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280471876806000640",
  "text" : "RT @Horse_ebooks: Teach your dog to be well behaved and don t bite everyone out there",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280468747943297024",
    "text" : "Teach your dog to be well behaved and don t bite everyone out there",
    "id" : 280468747943297024,
    "created_at" : "2012-12-17 00:25:35 +0000",
    "user" : {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "protected" : false,
      "id_str" : "174958347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096005346\/1_normal.jpg",
      "id" : 174958347,
      "verified" : false
    }
  },
  "id" : 280471876806000640,
  "created_at" : "2012-12-17 00:38:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280460339768868864",
  "geo" : { },
  "id_str" : "280463246417334272",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr delete them all. Doesn\u2019t sound fun anyway.",
  "id" : 280463246417334272,
  "in_reply_to_status_id" : 280460339768868864,
  "created_at" : "2012-12-17 00:03:43 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280397950323154945",
  "geo" : { },
  "id_str" : "280457926806745089",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden tried this, and the hug gesture is a riot.",
  "id" : 280457926806745089,
  "in_reply_to_status_id" : 280397950323154945,
  "created_at" : "2012-12-16 23:42:35 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280453069630734336",
  "geo" : { },
  "id_str" : "280453517288808448",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard I\u2019m actually at inbox 6000+. I rarely archive, only mark as read.",
  "id" : 280453517288808448,
  "in_reply_to_status_id" : 280453069630734336,
  "created_at" : "2012-12-16 23:25:03 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/280452066915270658\/photo\/1",
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/c01xWLYu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-Rdq0FCQAEcHXC.png",
      "id_str" : "280452066919464961",
      "id" : 280452066919464961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-Rdq0FCQAEcHXC.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/c01xWLYu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280452066915270658",
  "text" : "Ominous amount of email awaiting me\u2026 http:\/\/t.co\/c01xWLYu",
  "id" : 280452066915270658,
  "created_at" : "2012-12-16 23:19:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280436317718999040",
  "text" : "It\u2019s gotten to the part of the road trip where my dad starts playing old timey radio.",
  "id" : 280436317718999040,
  "created_at" : "2012-12-16 22:16:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Udell",
      "screen_name" : "judell",
      "indices" : [ 0, 7 ],
      "id_str" : "2937071",
      "id" : 2937071
    }, {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 8, 16 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 55, 69 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280352396247453696",
  "geo" : { },
  "id_str" : "280435728847081472",
  "in_reply_to_user_id" : 2937071,
  "text" : "@judell @jwright wow, the window text is gorgeous. \/cc @coworkbuffalo",
  "id" : 280435728847081472,
  "in_reply_to_status_id" : 280352396247453696,
  "created_at" : "2012-12-16 22:14:22 +0000",
  "in_reply_to_screen_name" : "judell",
  "in_reply_to_user_id_str" : "2937071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Starkman",
      "screen_name" : "MarkStarkman",
      "indices" : [ 0, 13 ],
      "id_str" : "139263008",
      "id" : 139263008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280391424179052545",
  "geo" : { },
  "id_str" : "280391622372491264",
  "in_reply_to_user_id" : 139263008,
  "text" : "@MarkStarkman that\u2019s the joke.",
  "id" : 280391622372491264,
  "in_reply_to_status_id" : 280391424179052545,
  "created_at" : "2012-12-16 19:19:06 +0000",
  "in_reply_to_screen_name" : "MarkStarkman",
  "in_reply_to_user_id_str" : "139263008",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280390061042843648",
  "text" : "Best bathroom graffiti I\u2019ve seen in a while: \u201CRON PUAL WAS RIGHT\u201D",
  "id" : 280390061042843648,
  "created_at" : "2012-12-16 19:12:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 21, 29 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280208977801932800",
  "text" : "Super pleased to see @mojombo back on Jekyll. Keep fighting!",
  "id" : 280208977801932800,
  "created_at" : "2012-12-16 07:13:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gergely Imreh",
      "screen_name" : "imrehg",
      "indices" : [ 0, 7 ],
      "id_str" : "15792797",
      "id" : 15792797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280100549997780993",
  "geo" : { },
  "id_str" : "280208388347027456",
  "in_reply_to_user_id" : 15792797,
  "text" : "@imrehg awesome. How did it go? Did the intros work?",
  "id" : 280208388347027456,
  "in_reply_to_status_id" : 280100549997780993,
  "created_at" : "2012-12-16 07:11:00 +0000",
  "in_reply_to_screen_name" : "imrehg",
  "in_reply_to_user_id_str" : "15792797",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gergely Imreh",
      "screen_name" : "imrehg",
      "indices" : [ 3, 10 ],
      "id_str" : "15792797",
      "id" : 15792797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/klR1dlJs",
      "expanded_url" : "http:\/\/fb.me\/2nvzsO59s",
      "display_url" : "fb.me\/2nvzsO59s"
    } ]
  },
  "geo" : { },
  "id_str" : "280208334244679680",
  "text" : "RT @imrehg: I posted 16 photos on Facebook in the album \"OpenHack Taipei December\" http:\/\/t.co\/klR1dlJs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/klR1dlJs",
        "expanded_url" : "http:\/\/fb.me\/2nvzsO59s",
        "display_url" : "fb.me\/2nvzsO59s"
      } ]
    },
    "geo" : { },
    "id_str" : "280100549997780993",
    "text" : "I posted 16 photos on Facebook in the album \"OpenHack Taipei December\" http:\/\/t.co\/klR1dlJs",
    "id" : 280100549997780993,
    "created_at" : "2012-12-16 00:02:29 +0000",
    "user" : {
      "name" : "Gergely Imreh",
      "screen_name" : "imrehg",
      "protected" : false,
      "id_str" : "15792797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2558670942\/temp1346324077strip20120830-10923-1jc82jh_normal",
      "id" : 15792797,
      "verified" : false
    }
  },
  "id" : 280208334244679680,
  "created_at" : "2012-12-16 07:10:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 3, 11 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 32, 41 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 45, 59 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Rochester.rb",
      "screen_name" : "rochesterrb",
      "indices" : [ 76, 88 ],
      "id_str" : "19015420",
      "id" : 19015420
    }, {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 92, 105 ],
      "id_str" : "19386993",
      "id" : 19386993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PROGRAMMIN",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Jq8LrtPr",
      "expanded_url" : "http:\/\/i.imgur.com\/AJSFu.gif",
      "display_url" : "i.imgur.com\/AJSFu.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "280208168255098880",
  "text" : "RT @jayunit: Looking forward to @openhack at @coworkbuffalo on Tuesday, and @rochesterrb at @coworkingroc on Thursday! #PROGRAMMIN http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 19, 28 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 32, 46 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "Rochester.rb",
        "screen_name" : "rochesterrb",
        "indices" : [ 63, 75 ],
        "id_str" : "19015420",
        "id" : 19015420
      }, {
        "name" : "Coworking Rochester",
        "screen_name" : "coworkingroc",
        "indices" : [ 79, 92 ],
        "id_str" : "19386993",
        "id" : 19386993
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PROGRAMMIN",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/Jq8LrtPr",
        "expanded_url" : "http:\/\/i.imgur.com\/AJSFu.gif",
        "display_url" : "i.imgur.com\/AJSFu.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "280006288266629121",
    "text" : "Looking forward to @openhack at @coworkbuffalo on Tuesday, and @rochesterrb at @coworkingroc on Thursday! #PROGRAMMIN http:\/\/t.co\/Jq8LrtPr",
    "id" : 280006288266629121,
    "created_at" : "2012-12-15 17:47:56 +0000",
    "user" : {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "protected" : false,
      "id_str" : "14238213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1435351938\/jason2_normal.png",
      "id" : 14238213,
      "verified" : false
    }
  },
  "id" : 280208168255098880,
  "created_at" : "2012-12-16 07:10:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis McCrea",
      "screen_name" : "teamcoltra",
      "indices" : [ 0, 11 ],
      "id_str" : "2965502115",
      "id" : 2965502115
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 80, 94 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279626593054384130",
  "geo" : { },
  "id_str" : "280208133715001345",
  "in_reply_to_user_id" : 3252881,
  "text" : "@teamcoltra hey sorry! We discussed it internally and I\u2019ll get back to you. \/cc @coworkbuffalo",
  "id" : 280208133715001345,
  "in_reply_to_status_id" : 279626593054384130,
  "created_at" : "2012-12-16 07:09:59 +0000",
  "in_reply_to_screen_name" : "travisthepirate",
  "in_reply_to_user_id_str" : "3252881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280059935000252416",
  "text" : "OH \u201Cif your day to day thing was eating fish with your face, you\u2019d be pretty cool too\u201D",
  "id" : 280059935000252416,
  "created_at" : "2012-12-15 21:21:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280026791249334272",
  "text" : "OH \u201CSheeple? I don\u2019t like that term. Sheep are smart, they stay in herds to protect themselves\u201D",
  "id" : 280026791249334272,
  "created_at" : "2012-12-15 19:09:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280023754254475264",
  "text" : "OH \u201CIce cubes are the silent killer\u201D",
  "id" : 280023754254475264,
  "created_at" : "2012-12-15 18:57:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Busigin",
      "screen_name" : "mbusigin",
      "indices" : [ 3, 12 ],
      "id_str" : "19111917",
      "id" : 19111917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280022275770679296",
  "text" : "RT @mbusigin: Maybe the single most under-represented and mis-understood economic force in the United States is open-source software.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280004128913108992",
    "text" : "Maybe the single most under-represented and mis-understood economic force in the United States is open-source software.",
    "id" : 280004128913108992,
    "created_at" : "2012-12-15 17:39:21 +0000",
    "user" : {
      "name" : "Matt Busigin",
      "screen_name" : "mbusigin",
      "protected" : false,
      "id_str" : "19111917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558310977192468481\/v6zSqSlj_normal.jpeg",
      "id" : 19111917,
      "verified" : false
    }
  },
  "id" : 280022275770679296,
  "created_at" : "2012-12-15 18:51:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280000871868272641",
  "text" : "Hi Boston! I don\u2019t miss your traffic or insane drivers and pedestrians.",
  "id" : 280000871868272641,
  "created_at" : "2012-12-15 17:26:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279792260000923649",
  "text" : "Staying in a house built in 1824 tonight. Makes you think twice about building virtual things that can last.",
  "id" : 279792260000923649,
  "created_at" : "2012-12-15 03:37:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "christopher burnett",
      "screen_name" : "twoism",
      "indices" : [ 9, 16 ],
      "id_str" : "15786115",
      "id" : 15786115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279733737552506880",
  "geo" : { },
  "id_str" : "279735862605004801",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @twoism awesome. I keep forgetting you\u2019re at twitter.",
  "id" : 279735862605004801,
  "in_reply_to_status_id" : 279733737552506880,
  "created_at" : "2012-12-14 23:53:21 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Kelly",
      "screen_name" : "amateurhuman",
      "indices" : [ 0, 13 ],
      "id_str" : "41456770",
      "id" : 41456770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279715726766505984",
  "geo" : { },
  "id_str" : "279728167718092800",
  "in_reply_to_user_id" : 41456770,
  "text" : "@amateurhuman have never been. Have heard good things.",
  "id" : 279728167718092800,
  "in_reply_to_status_id" : 279715726766505984,
  "created_at" : "2012-12-14 23:22:46 +0000",
  "in_reply_to_screen_name" : "amateurhuman",
  "in_reply_to_user_id_str" : "41456770",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279673519569260545",
  "text" : "I need a chair that will push me in the opposite direction. Feeling constantly like I have to lean over everything.",
  "id" : 279673519569260545,
  "created_at" : "2012-12-14 19:45:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 9, 19 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279671364145782785",
  "geo" : { },
  "id_str" : "279673202005913601",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan @ngauthier you're clearly trying to troll me :( II just think a little research into a few startups would work better to get a job.",
  "id" : 279673202005913601,
  "in_reply_to_status_id" : 279671364145782785,
  "created_at" : "2012-12-14 19:44:22 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher burnett",
      "screen_name" : "twoism",
      "indices" : [ 0, 7 ],
      "id_str" : "15786115",
      "id" : 15786115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279315573006020608",
  "geo" : { },
  "id_str" : "279672844022059008",
  "in_reply_to_user_id" : 15786115,
  "text" : "@twoism woot! would love to hear what twitter uses it for :)",
  "id" : 279672844022059008,
  "in_reply_to_status_id" : 279315573006020608,
  "created_at" : "2012-12-14 19:42:56 +0000",
  "in_reply_to_screen_name" : "twoism",
  "in_reply_to_user_id_str" : "15786115",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher burnett",
      "screen_name" : "twoism",
      "indices" : [ 3, 10 ],
      "id_str" : "15786115",
      "id" : 15786115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 79 ],
      "url" : "https:\/\/t.co\/1j2Q2gsO",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "279672680544890882",
  "text" : "RT @twoism: sub is ruling everything around me right now. https:\/\/t.co\/1j2Q2gsO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 67 ],
        "url" : "https:\/\/t.co\/1j2Q2gsO",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "279315573006020608",
    "text" : "sub is ruling everything around me right now. https:\/\/t.co\/1j2Q2gsO",
    "id" : 279315573006020608,
    "created_at" : "2012-12-13 20:03:16 +0000",
    "user" : {
      "name" : "christopher burnett",
      "screen_name" : "twoism",
      "protected" : false,
      "id_str" : "15786115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549331686895267841\/Rj2wOT5k_normal.jpeg",
      "id" : 15786115,
      "verified" : false
    }
  },
  "id" : 279672680544890882,
  "created_at" : "2012-12-14 19:42:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279669591196708866",
  "geo" : { },
  "id_str" : "279670227120300032",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier A bunch of .doc resumes with Times New Roman headers?",
  "id" : 279670227120300032,
  "in_reply_to_status_id" : 279669591196708866,
  "created_at" : "2012-12-14 19:32:32 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279666397418766338",
  "geo" : { },
  "id_str" : "279666630705950721",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders I have zero pity for kids like this. Maybe it's the 5 years of absolute carelessness and no passion they showed.",
  "id" : 279666630705950721,
  "in_reply_to_status_id" : 279666397418766338,
  "created_at" : "2012-12-14 19:18:15 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279664847438901248",
  "geo" : { },
  "id_str" : "279665556003647488",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella I will be tomorrow, no time for hooliganism. Maybe next time!",
  "id" : 279665556003647488,
  "in_reply_to_status_id" : 279664847438901248,
  "created_at" : "2012-12-14 19:13:59 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/LojwqA6l",
      "expanded_url" : "http:\/\/redeye.firstround.com\/2012\/12\/commonapplication.html",
      "display_url" : "redeye.firstround.com\/2012\/12\/common\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279665448377782272",
  "text" : "If you're applying to 170+ startups, you're doing something very clearly wrong. http:\/\/t.co\/LojwqA6l",
  "id" : 279665448377782272,
  "created_at" : "2012-12-14 19:13:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279662086278234112",
  "text" : "Sad to be heading towards New England today. Sad just in general.",
  "id" : 279662086278234112,
  "created_at" : "2012-12-14 19:00:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian",
      "screen_name" : "brixen",
      "indices" : [ 0, 7 ],
      "id_str" : "2897551",
      "id" : 2897551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279649281537884161",
  "geo" : { },
  "id_str" : "279649584303706112",
  "in_reply_to_user_id" : 2897551,
  "text" : "@brixen Didn't you make your audience say it with you? ;)",
  "id" : 279649584303706112,
  "in_reply_to_status_id" : 279649281537884161,
  "created_at" : "2012-12-14 18:10:31 +0000",
  "in_reply_to_screen_name" : "brixen",
  "in_reply_to_user_id_str" : "2897551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 45, 55 ],
      "id_str" : "14182110",
      "id" : 14182110
    }, {
      "name" : "Brian",
      "screen_name" : "brixen",
      "indices" : [ 82, 89 ],
      "id_str" : "2897551",
      "id" : 2897551
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 90, 102 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/279648485245063168\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/Y0VGXjlq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-GC0NFCEAA3_lC.png",
      "id_str" : "279648485249257472",
      "id" : 279648485249257472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-GC0NFCEAA3_lC.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Y0VGXjlq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279648485245063168",
  "text" : "Found a very familiar slide while watching a @confreaks video during lunch... \/cc @brixen @sstephenson http:\/\/t.co\/Y0VGXjlq",
  "id" : 279648485245063168,
  "created_at" : "2012-12-14 18:06:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279630226084986880",
  "text" : "RT @sstephenson: Honesty and humility are not harmful ideas.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279629897087979520",
    "text" : "Honesty and humility are not harmful ideas.",
    "id" : 279629897087979520,
    "created_at" : "2012-12-14 16:52:17 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 279630226084986880,
  "created_at" : "2012-12-14 16:53:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279626812026388480",
  "text" : "RT @aquaranto: I'm working on a Rails tutorial and in my head I sound like the girl from Jurassic park: \"Rails?! I *know* this!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279620684961964032",
    "text" : "I'm working on a Rails tutorial and in my head I sound like the girl from Jurassic park: \"Rails?! I *know* this!\"",
    "id" : 279620684961964032,
    "created_at" : "2012-12-14 16:15:41 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 279626812026388480,
  "created_at" : "2012-12-14 16:40:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/279421035470794757\/photo\/1",
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/wxWoBvKx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-Cz84qCMAEDRre.png",
      "id_str" : "279421035479183361",
      "id" : 279421035479183361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-Cz84qCMAEDRre.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/wxWoBvKx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279421035470794757",
  "text" : "Spaceteam is hilarious. Good first game! http:\/\/t.co\/wxWoBvKx",
  "id" : 279421035470794757,
  "created_at" : "2012-12-14 03:02:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/kUgHGRgY",
      "expanded_url" : "http:\/\/sstephenson.us\/posts\/you-are-not-your-code",
      "display_url" : "sstephenson.us\/posts\/you-are-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279363658310639617",
  "text" : "RT @sstephenson: You Are Not Your Code: http:\/\/t.co\/kUgHGRgY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/kUgHGRgY",
        "expanded_url" : "http:\/\/sstephenson.us\/posts\/you-are-not-your-code",
        "display_url" : "sstephenson.us\/posts\/you-are-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "279356237697646592",
    "text" : "You Are Not Your Code: http:\/\/t.co\/kUgHGRgY",
    "id" : 279356237697646592,
    "created_at" : "2012-12-13 22:44:51 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 279363658310639617,
  "created_at" : "2012-12-13 23:14:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 0, 10 ],
      "id_str" : "651373",
      "id" : 651373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279352371925106689",
  "geo" : { },
  "id_str" : "279352683192786944",
  "in_reply_to_user_id" : 651373,
  "text" : "@RedWolves Just take the ferry! LOLOL",
  "id" : 279352683192786944,
  "in_reply_to_status_id" : 279352371925106689,
  "created_at" : "2012-12-13 22:30:44 +0000",
  "in_reply_to_screen_name" : "RedWolves",
  "in_reply_to_user_id_str" : "651373",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279331875309363201",
  "geo" : { },
  "id_str" : "279332160710782976",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV Ugh.",
  "id" : 279332160710782976,
  "in_reply_to_status_id" : 279331875309363201,
  "created_at" : "2012-12-13 21:09:11 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279329575694131200",
  "geo" : { },
  "id_str" : "279330234833195008",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV as someone who moved back...I guess so? Millions is an overstatement :)",
  "id" : 279330234833195008,
  "in_reply_to_status_id" : 279329575694131200,
  "created_at" : "2012-12-13 21:01:32 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279326456868392960",
  "geo" : { },
  "id_str" : "279328496944291841",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 This all sounds reasonable. The Python PEP system is similar, and actually makes a ton of sense.",
  "id" : 279328496944291841,
  "in_reply_to_status_id" : 279326456868392960,
  "created_at" : "2012-12-13 20:54:38 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/HImKzpdb",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Buffalo\/comments\/14sxuj\/pedestrian_problems_at_colonial_circle\/",
      "display_url" : "reddit.com\/r\/Buffalo\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279325926150508544",
  "text" : "Anyone familiar with NYS traffic law? http:\/\/t.co\/HImKzpdb",
  "id" : 279325926150508544,
  "created_at" : "2012-12-13 20:44:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279317078152970241",
  "geo" : { },
  "id_str" : "279318289950322690",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Time to eliminate one...;)",
  "id" : 279318289950322690,
  "in_reply_to_status_id" : 279317078152970241,
  "created_at" : "2012-12-13 20:14:04 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 92, 99 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279311882140151808",
  "text" : "RT @coworkbuffalo: To so many of our customers and visitors, we exist once more! Thank you, @Google, for iOS Maps.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 73, 80 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279311572336254978",
    "text" : "To so many of our customers and visitors, we exist once more! Thank you, @Google, for iOS Maps.",
    "id" : 279311572336254978,
    "created_at" : "2012-12-13 19:47:22 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 279311882140151808,
  "created_at" : "2012-12-13 19:48:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279309974511943680",
  "geo" : { },
  "id_str" : "279310352808828928",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts module Manager; end",
  "id" : 279310352808828928,
  "in_reply_to_status_id" : 279309974511943680,
  "created_at" : "2012-12-13 19:42:32 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 41, 55 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279304464643551232",
  "text" : "Used Google Maps iOS to get bus times to @coworkbuffalo. After many weeks of having to do this via the mobile site, I am pleased.",
  "id" : 279304464643551232,
  "created_at" : "2012-12-13 19:19:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 4, 13 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279253356092981248",
  "text" : "Hey @codemash what day do the talks start? (not precompiler)",
  "id" : 279253356092981248,
  "created_at" : "2012-12-13 15:56:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 30, 44 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/279080856998526976\/photo\/1",
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/g4NGXUF7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A99-j5FCQAEMMCY.png",
      "id_str" : "279080857002721281",
      "id" : 279080857002721281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A99-j5FCQAEMMCY.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/g4NGXUF7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279080856998526976",
  "text" : "Finally, native directions to @coworkbuffalo again. See ya Apple Maps. http:\/\/t.co\/g4NGXUF7",
  "id" : 279080856998526976,
  "created_at" : "2012-12-13 04:30:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279045018117869570",
  "geo" : { },
  "id_str" : "279045239220629505",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik 20 drinkups?",
  "id" : 279045239220629505,
  "in_reply_to_status_id" : 279045018117869570,
  "created_at" : "2012-12-13 02:09:04 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/l6mEZtUD",
      "expanded_url" : "https:\/\/gist.github.com\/4273152",
      "display_url" : "gist.github.com\/4273152"
    } ]
  },
  "geo" : { },
  "id_str" : "279042930029764609",
  "text" : "Weaning my class notes off Keynote, so I can share &amp; version them. Latest exercises unproven, but loving teaching. https:\/\/t.co\/l6mEZtUD",
  "id" : 279042930029764609,
  "created_at" : "2012-12-13 01:59:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 79, 88 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/WlSK5u9W",
      "expanded_url" : "http:\/\/openhack.github.com\/rochester",
      "display_url" : "openhack.github.com\/rochester"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/hwnhRF9r",
      "expanded_url" : "http:\/\/openhack.github.com\/austin",
      "display_url" : "openhack.github.com\/austin"
    } ]
  },
  "geo" : { },
  "id_str" : "279031188503531521",
  "text" : "Happy to see some of my favorite cities,  Rochester and Austin are planning an @OpenHack! http:\/\/t.co\/WlSK5u9W http:\/\/t.co\/hwnhRF9r",
  "id" : 279031188503531521,
  "created_at" : "2012-12-13 01:13:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canine Tatum",
      "screen_name" : "aphyr",
      "indices" : [ 0, 6 ],
      "id_str" : "49820803",
      "id" : 49820803
    }, {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 7, 17 ],
      "id_str" : "23830105",
      "id" : 23830105
    }, {
      "name" : "d:-)",
      "screen_name" : "joedahato",
      "indices" : [ 18, 28 ],
      "id_str" : "611856383",
      "id" : 611856383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 50 ],
      "url" : "https:\/\/t.co\/BxSwAgra",
      "expanded_url" : "https:\/\/github.com\/aphyr\/joedahato\/blob\/master\/src\/joedahato\/core.clj#L10-L75",
      "display_url" : "github.com\/aphyr\/joedahat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "279024541899030528",
  "geo" : { },
  "id_str" : "279026636630933504",
  "in_reply_to_user_id" : 49820803,
  "text" : "@aphyr @joedamato @joedahato https:\/\/t.co\/BxSwAgra is the most passive-aggressive block of code i've read",
  "id" : 279026636630933504,
  "in_reply_to_status_id" : 279024541899030528,
  "created_at" : "2012-12-13 00:55:08 +0000",
  "in_reply_to_screen_name" : "aphyr",
  "in_reply_to_user_id_str" : "49820803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279021658302447616",
  "text" : "RT @rubygems_status: People are experience some details in gems showing up via bundler. Solution coming. Here's a workaround: `bundle in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279019743166476288",
    "text" : "People are experience some details in gems showing up via bundler. Solution coming. Here's a workaround: `bundle install --full-index`",
    "id" : 279019743166476288,
    "created_at" : "2012-12-13 00:27:45 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 279021658302447616,
  "created_at" : "2012-12-13 00:35:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 87, 97 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/3pe4pQ6w",
      "expanded_url" : "http:\/\/codepen.io\/",
      "display_url" : "codepen.io"
    } ]
  },
  "geo" : { },
  "id_str" : "279019306803662848",
  "text" : "Oh geez, the CSS Table Flippin' is on the home page of http:\/\/t.co\/3pe4pQ6w now... \/cc @aquaranto",
  "id" : 279019306803662848,
  "created_at" : "2012-12-13 00:26:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279000033574125570",
  "geo" : { },
  "id_str" : "279000270036426753",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison I'm at an equal level here :)",
  "id" : 279000270036426753,
  "in_reply_to_status_id" : 279000033574125570,
  "created_at" : "2012-12-12 23:10:22 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 4, 11 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 12, 21 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 85 ],
      "url" : "https:\/\/t.co\/d1lGiDfS",
      "expanded_url" : "https:\/\/groups.google.com\/group\/rubygems-org\/browse_thread\/thread\/f89d4d54b2cb2e3c?hl=en_US",
      "display_url" : "groups.google.com\/group\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278999486246842368",
  "text" : "Hey @hone02 @indirect can we get some attention\/love over here? https:\/\/t.co\/d1lGiDfS",
  "id" : 278999486246842368,
  "created_at" : "2012-12-12 23:07:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 3, 12 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 65, 78 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278995758475247618",
  "text" : "RT @bitsweat: Give a warm Rails welcome to our newest committer, @steveklabnik!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Dream of the 90s",
        "screen_name" : "steveklabnik",
        "indices" : [ 51, 64 ],
        "id_str" : "22386062",
        "id" : 22386062
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278988738170855425",
    "text" : "Give a warm Rails welcome to our newest committer, @steveklabnik!",
    "id" : 278988738170855425,
    "created_at" : "2012-12-12 22:24:33 +0000",
    "user" : {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "protected" : false,
      "id_str" : "9462972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510089088129458177\/L_F1zcVv_normal.png",
      "id" : 9462972,
      "verified" : false
    }
  },
  "id" : 278995758475247618,
  "created_at" : "2012-12-12 22:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278974440237322240",
  "geo" : { },
  "id_str" : "278974508210192386",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety ......",
  "id" : 278974508210192386,
  "in_reply_to_status_id" : 278974440237322240,
  "created_at" : "2012-12-12 21:28:00 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 44 ],
      "url" : "https:\/\/t.co\/s4mc4KYv",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/205046717509419008",
      "display_url" : "twitter.com\/qrush\/status\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278972672967331840",
  "text" : "Your monthly reminder: https:\/\/t.co\/s4mc4KYv",
  "id" : 278972672967331840,
  "created_at" : "2012-12-12 21:20:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278950137882091520",
  "text" : "RT @jasonfried: Anyone set up a Google Group lately? When did it get so complicated?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278949556631265281",
    "text" : "Anyone set up a Google Group lately? When did it get so complicated?",
    "id" : 278949556631265281,
    "created_at" : "2012-12-12 19:48:51 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 278950137882091520,
  "created_at" : "2012-12-12 19:51:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278946225670201345",
  "geo" : { },
  "id_str" : "278948316472037376",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage I'm in mashup.fm as well :)",
  "id" : 278948316472037376,
  "in_reply_to_status_id" : 278946225670201345,
  "created_at" : "2012-12-12 19:43:55 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278945742398296064",
  "text" : "OH \"begun the gangnam style-mashup wars have\"",
  "id" : 278945742398296064,
  "created_at" : "2012-12-12 19:33:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horia Constantin",
      "screen_name" : "ConstantinHoria",
      "indices" : [ 0, 16 ],
      "id_str" : "769262971",
      "id" : 769262971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278912956492812288",
  "geo" : { },
  "id_str" : "278913268708438016",
  "in_reply_to_user_id" : 769262971,
  "text" : "@ConstantinHoria Nope. Who's writing your paper? ;)",
  "id" : 278913268708438016,
  "in_reply_to_status_id" : 278912956492812288,
  "created_at" : "2012-12-12 17:24:39 +0000",
  "in_reply_to_screen_name" : "ConstantinHoria",
  "in_reply_to_user_id_str" : "769262971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wilhelm Wanecek",
      "screen_name" : "WilhelmWanecek",
      "indices" : [ 0, 15 ],
      "id_str" : "369696862",
      "id" : 369696862
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 25, 35 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278747620682391552",
  "geo" : { },
  "id_str" : "278909400981315584",
  "in_reply_to_user_id" : 369696862,
  "text" : "@WilhelmWanecek This was @aquaranto's idea.",
  "id" : 278909400981315584,
  "in_reply_to_status_id" : 278747620682391552,
  "created_at" : "2012-12-12 17:09:17 +0000",
  "in_reply_to_screen_name" : "WilhelmWanecek",
  "in_reply_to_user_id_str" : "369696862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278902289161408512",
  "geo" : { },
  "id_str" : "278903433275244544",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Rated E for Everyone.",
  "id" : 278903433275244544,
  "in_reply_to_status_id" : 278902289161408512,
  "created_at" : "2012-12-12 16:45:34 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278901549365858304",
  "geo" : { },
  "id_str" : "278901694014816256",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt they wouldn't want to pick up cucumbers and lube for you",
  "id" : 278901694014816256,
  "in_reply_to_status_id" : 278901549365858304,
  "created_at" : "2012-12-12 16:38:40 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 3, 14 ],
      "id_str" : "10774712",
      "id" : 10774712
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 16, 22 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 23, 37 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278901323871682561",
  "text" : "RT @richdownie: @qrush @steelcityruby Yelling == Passion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 7, 21 ],
        "id_str" : "404851600",
        "id" : 404851600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "278879149865709569",
    "geo" : { },
    "id_str" : "278900802209345537",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @steelcityruby Yelling == Passion",
    "id" : 278900802209345537,
    "in_reply_to_status_id" : 278879149865709569,
    "created_at" : "2012-12-12 16:35:07 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "protected" : false,
      "id_str" : "10774712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558639851176603649\/3qXKrGpA_normal.jpeg",
      "id" : 10774712,
      "verified" : false
    }
  },
  "id" : 278901323871682561,
  "created_at" : "2012-12-12 16:37:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carcassonne",
      "screen_name" : "CarcassonneApp",
      "indices" : [ 3, 18 ],
      "id_str" : "49669910",
      "id" : 49669910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/duUBQFGh",
      "expanded_url" : "http:\/\/itun.es\/i6D59XY",
      "display_url" : "itun.es\/i6D59XY"
    } ]
  },
  "geo" : { },
  "id_str" : "278898026821595136",
  "text" : "RT @CarcassonneApp: While we wait for the \u201CTraders &amp; Builders\u201D expansion to be reviewed by Apple, we\u2019ve reduced Lost Cities to half  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/duUBQFGh",
        "expanded_url" : "http:\/\/itun.es\/i6D59XY",
        "display_url" : "itun.es\/i6D59XY"
      } ]
    },
    "geo" : { },
    "id_str" : "278896631095623680",
    "text" : "While we wait for the \u201CTraders &amp; Builders\u201D expansion to be reviewed by Apple, we\u2019ve reduced Lost Cities to half price: http:\/\/t.co\/duUBQFGh",
    "id" : 278896631095623680,
    "created_at" : "2012-12-12 16:18:33 +0000",
    "user" : {
      "name" : "Carcassonne",
      "screen_name" : "CarcassonneApp",
      "protected" : false,
      "id_str" : "49669910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/863254920\/CarcassonneIcon512_normal.png",
      "id" : 49669910,
      "verified" : false
    }
  },
  "id" : 278898026821595136,
  "created_at" : "2012-12-12 16:24:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278892120050376705",
  "geo" : { },
  "id_str" : "278892908038471680",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff What a terrible example. mongo is just not a good choice for relational queries...that's not the point at all. aggregations too.",
  "id" : 278892908038471680,
  "in_reply_to_status_id" : 278892120050376705,
  "created_at" : "2012-12-12 16:03:45 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278890656011780097",
  "text" : "Number of Space Jam mashups played so far this morning: 2.",
  "id" : 278890656011780097,
  "created_at" : "2012-12-12 15:54:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/tdtmrsXX",
      "expanded_url" : "http:\/\/www.google.com\/zeitgeist\/2012\/#explore",
      "display_url" : "google.com\/zeitgeist\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278890166343573504",
  "text" : "The explore map is really well done here: http:\/\/t.co\/tdtmrsXX",
  "id" : 278890166343573504,
  "created_at" : "2012-12-12 15:52:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "278885013263630336",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 278885013263630336,
  "created_at" : "2012-12-12 15:32:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 38 ],
      "url" : "https:\/\/t.co\/QfNRYhgX",
      "expanded_url" : "https:\/\/github.com\/CoderDojo\/CoderDojo-Kata\/pull\/1\/files",
      "display_url" : "github.com\/CoderDojo\/Code\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278880294403182592",
  "text" : "LEET GITHUB HAX: https:\/\/t.co\/QfNRYhgX",
  "id" : 278880294403182592,
  "created_at" : "2012-12-12 15:13:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/QRnspAzi",
      "expanded_url" : "http:\/\/vimeo.com\/55125493",
      "display_url" : "vimeo.com\/55125493"
    }, {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/QIWqD0t2",
      "expanded_url" : "http:\/\/quaran.to\/m",
      "display_url" : "quaran.to\/m"
    } ]
  },
  "geo" : { },
  "id_str" : "278879385900179457",
  "text" : "Watch me yell about M! http:\/\/t.co\/QRnspAzi http:\/\/t.co\/QIWqD0t2",
  "id" : 278879385900179457,
  "created_at" : "2012-12-12 15:10:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278875677141377024",
  "geo" : { },
  "id_str" : "278879149865709569",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby oh god sorry i yelled so much. lol",
  "id" : 278879149865709569,
  "in_reply_to_status_id" : 278875677141377024,
  "created_at" : "2012-12-12 15:09:05 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278875677141377024",
  "geo" : { },
  "id_str" : "278876303237709825",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby uh oh.",
  "id" : 278876303237709825,
  "in_reply_to_status_id" : 278875677141377024,
  "created_at" : "2012-12-12 14:57:46 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278860757817520129",
  "geo" : { },
  "id_str" : "278869581311930369",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss the only bug free software is software that isn\u2019t being used. Striving for absolute perfection is a waste of time.",
  "id" : 278869581311930369,
  "in_reply_to_status_id" : 278860757817520129,
  "created_at" : "2012-12-12 14:31:03 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278769129626939392",
  "geo" : { },
  "id_str" : "278853870694846464",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss very much disagree. To say Jekyll hasn\u2019t had a huge impact in the past ~2 years as \u201Cstable\u201D would be false.",
  "id" : 278853870694846464,
  "in_reply_to_status_id" : 278769129626939392,
  "created_at" : "2012-12-12 13:28:38 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael F. Lamb",
      "screen_name" : "datagrok",
      "indices" : [ 0, 9 ],
      "id_str" : "35888040",
      "id" : 35888040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277585740051927041",
  "geo" : { },
  "id_str" : "278738211449212928",
  "in_reply_to_user_id" : 35888040,
  "text" : "@datagrok neat. There\u2019s a lot of Ruby sub command option libs too, but just plain bash is good too.",
  "id" : 278738211449212928,
  "in_reply_to_status_id" : 277585740051927041,
  "created_at" : "2012-12-12 05:49:02 +0000",
  "in_reply_to_screen_name" : "datagrok",
  "in_reply_to_user_id_str" : "35888040",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/VkGM9FsF",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    }, {
      "indices" : [ 100, 121 ],
      "url" : "https:\/\/t.co\/NIqZZuZE",
      "expanded_url" : "https:\/\/speakerdeck.com\/komagata\/rubygemsniyorudezainfalsezai-li-yong",
      "display_url" : "speakerdeck.com\/komagata\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278737208414969856",
  "text" : "Not sure what this prez is saying, but any link to http:\/\/t.co\/VkGM9FsF wins! - RubyGems\u306B\u3088\u308B\u30C7\u30B6\u30A4\u30F3\u306E\u518D\u5229\u7528 https:\/\/t.co\/NIqZZuZE",
  "id" : 278737208414969856,
  "created_at" : "2012-12-12 05:45:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/hWczTZ57",
      "expanded_url" : "http:\/\/codepen.io\/qrush\/full\/qbioe",
      "display_url" : "codepen.io\/qrush\/full\/qbi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278716000051032064",
  "text" : "Codepen's forking is great. Took a wonderfully done snowflake example and... http:\/\/t.co\/hWczTZ57",
  "id" : 278716000051032064,
  "created_at" : "2012-12-12 04:20:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/278701292241707010\/photo\/1",
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/kfH0X9He",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A94lWULCYAEun6D.png",
      "id_str" : "278701292245901313",
      "id" : 278701292245901313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A94lWULCYAEun6D.png",
      "sizes" : [ {
        "h" : 222,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 225
      } ],
      "display_url" : "pic.twitter.com\/kfH0X9He"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278701292241707010",
  "text" : "Playing around with rotation in canvas, perhaps getting too crazy... http:\/\/t.co\/kfH0X9He",
  "id" : 278701292241707010,
  "created_at" : "2012-12-12 03:22:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/278684934388973569\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/ucoyr0sz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A94WeKcCAAAOuZ9.png",
      "id_str" : "278684934397362176",
      "id" : 278684934397362176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A94WeKcCAAAOuZ9.png",
      "sizes" : [ {
        "h" : 228,
        "resize" : "fit",
        "w" : 229
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 229
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 229
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 229
      } ],
      "display_url" : "pic.twitter.com\/ucoyr0sz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278684934388973569",
  "text" : "Loving playing around with canvas. Just messing with it sometimes produces cool things. http:\/\/t.co\/ucoyr0sz",
  "id" : 278684934388973569,
  "created_at" : "2012-12-12 02:17:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicol\u00E1s Hock Isaza",
      "screen_name" : "nhocki",
      "indices" : [ 0, 7 ],
      "id_str" : "85498700",
      "id" : 85498700
    }, {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 8, 20 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278637565253414912",
  "geo" : { },
  "id_str" : "278643197138309120",
  "in_reply_to_user_id" : 85498700,
  "text" : "@nhocki @therealadam Good is subjective.",
  "id" : 278643197138309120,
  "in_reply_to_status_id" : 278637565253414912,
  "created_at" : "2012-12-11 23:31:29 +0000",
  "in_reply_to_screen_name" : "nhocki",
  "in_reply_to_user_id_str" : "85498700",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    }, {
      "name" : "Mike Clark",
      "screen_name" : "clarkware",
      "indices" : [ 13, 23 ],
      "id_str" : "9941002",
      "id" : 9941002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278634272561176576",
  "geo" : { },
  "id_str" : "278635130908717057",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam @clarkware bingo, that's it!",
  "id" : 278635130908717057,
  "in_reply_to_status_id" : 278634272561176576,
  "created_at" : "2012-12-11 22:59:26 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 15, 25 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278634022417072129",
  "geo" : { },
  "id_str" : "278635039141552128",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @ngauthier right, that's possible to do without keeping the issues count at zero. two different concerns.",
  "id" : 278635039141552128,
  "in_reply_to_status_id" : 278634022417072129,
  "created_at" : "2012-12-11 22:59:04 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    }, {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 10, 22 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278633726546685952",
  "geo" : { },
  "id_str" : "278633958202302464",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen @therealadam Have you ever worked on \"done\" software?",
  "id" : 278633958202302464,
  "in_reply_to_status_id" : 278633726546685952,
  "created_at" : "2012-12-11 22:54:47 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278632325288427520",
  "geo" : { },
  "id_str" : "278633453933711360",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam \"stable\" has a negative connotation as well, sadly :(",
  "id" : 278633453933711360,
  "in_reply_to_status_id" : 278632325288427520,
  "created_at" : "2012-12-11 22:52:46 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 3, 15 ],
      "id_str" : "12661",
      "id" : 12661
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 17, 23 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278633377505095680",
  "text" : "RT @therealadam: @qrush we need a positive term for software that has gone asymptotic because it works fine as-is",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "278627941313818625",
    "geo" : { },
    "id_str" : "278632325288427520",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush we need a positive term for software that has gone asymptotic because it works fine as-is",
    "id" : 278632325288427520,
    "in_reply_to_status_id" : 278627941313818625,
    "created_at" : "2012-12-11 22:48:17 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "protected" : false,
      "id_str" : "12661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1411347027\/jeff_casimir_headshot_normal.jpeg",
      "id" : 12661,
      "verified" : false
    }
  },
  "id" : 278633377505095680,
  "created_at" : "2012-12-11 22:52:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 15, 25 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278632903804612608",
  "geo" : { },
  "id_str" : "278633251365601280",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @ngauthier Yeah I don't see that as a good goal. This isn't Inbox Zero or an achievement to unlock.",
  "id" : 278633251365601280,
  "in_reply_to_status_id" : 278632903804612608,
  "created_at" : "2012-12-11 22:51:58 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278627941313818625",
  "text" : "Today's rubydrama goes into how much the GitHub issue count hurts projects: projects like jekyll, rbenv are not abandoned, just stable.",
  "id" : 278627941313818625,
  "created_at" : "2012-12-11 22:30:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278606915263672321",
  "geo" : { },
  "id_str" : "278607712055595008",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits ah ha. I would have used 1977.",
  "id" : 278607712055595008,
  "in_reply_to_status_id" : 278606915263672321,
  "created_at" : "2012-12-11 21:10:29 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278603220291563520",
  "geo" : { },
  "id_str" : "278606012834009088",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits where did you get that in Cambridge?",
  "id" : 278606012834009088,
  "in_reply_to_status_id" : 278603220291563520,
  "created_at" : "2012-12-11 21:03:44 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "indices" : [ 0, 10 ],
      "id_str" : "47494539",
      "id" : 47494539
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 11, 24 ],
      "id_str" : "9645312",
      "id" : 9645312
    }, {
      "name" : "Adron",
      "screen_name" : "adron",
      "indices" : [ 25, 31 ],
      "id_str" : "16063910",
      "id" : 16063910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278592805318844416",
  "geo" : { },
  "id_str" : "278596944803278848",
  "in_reply_to_user_id" : 47494539,
  "text" : "@kellabyte @ferventcoder @adron Doing OSS was my escape from C#\/VB land. Don't miss it one bit. For those who persist: Keep kicking ass.",
  "id" : 278596944803278848,
  "in_reply_to_status_id" : 278592805318844416,
  "created_at" : "2012-12-11 20:27:42 +0000",
  "in_reply_to_screen_name" : "kellabyte",
  "in_reply_to_user_id_str" : "47494539",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278596640091283456",
  "text" : "Finally, you can go to Cleveland and overpay to see some Rush memorabilia! (Seriously though, it's about time)",
  "id" : 278596640091283456,
  "created_at" : "2012-12-11 20:26:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278559556374761472",
  "text" : "RT @rjs: Struggling with a design decision? Wire up the version you think will be worse and then look for a resulting pain point as proof.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278558917141884930",
    "text" : "Struggling with a design decision? Wire up the version you think will be worse and then look for a resulting pain point as proof.",
    "id" : 278558917141884930,
    "created_at" : "2012-12-11 17:56:35 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 278559556374761472,
  "created_at" : "2012-12-11 17:59:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sindre Sorhus",
      "screen_name" : "sindresorhus",
      "indices" : [ 0, 13 ],
      "id_str" : "170686450",
      "id" : 170686450
    }, {
      "name" : "Nicolas Gallagher",
      "screen_name" : "necolas",
      "indices" : [ 14, 22 ],
      "id_str" : "24974216",
      "id" : 24974216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/2ZxjPVCq",
      "expanded_url" : "http:\/\/www.flipkik.com\/uploads\/pics\/how-to-draw-an-owl.png",
      "display_url" : "flipkik.com\/uploads\/pics\/h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "278485969857040384",
  "geo" : { },
  "id_str" : "278555493927120897",
  "in_reply_to_user_id" : 170686450,
  "text" : "@sindresorhus @necolas that's missing the funny part: http:\/\/t.co\/2ZxjPVCq",
  "id" : 278555493927120897,
  "in_reply_to_status_id" : 278485969857040384,
  "created_at" : "2012-12-11 17:42:59 +0000",
  "in_reply_to_screen_name" : "sindresorhus",
  "in_reply_to_user_id_str" : "170686450",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278542758648635392",
  "geo" : { },
  "id_str" : "278542988504870912",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison no way.",
  "id" : 278542988504870912,
  "in_reply_to_status_id" : 278542758648635392,
  "created_at" : "2012-12-11 16:53:18 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278541830340104192",
  "geo" : { },
  "id_str" : "278542600221364224",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison JJ's here is 15-20 minute drive (worse with traffic\/lights) or 30 via rail. :(",
  "id" : 278542600221364224,
  "in_reply_to_status_id" : 278541830340104192,
  "created_at" : "2012-12-11 16:51:45 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy John's",
      "screen_name" : "jimmyjohns",
      "indices" : [ 27, 38 ],
      "id_str" : "21952592",
      "id" : 21952592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278541465079119872",
  "text" : "Someone needs to open up a @jimmyjohns in downtown Buffalo. #9 please, hot peppers. Too far away.",
  "id" : 278541465079119872,
  "created_at" : "2012-12-11 16:47:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R&R BBQ",
      "screen_name" : "RnRBBQTruck",
      "indices" : [ 0, 12 ],
      "id_str" : "214261325",
      "id" : 214261325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278334731148468224",
  "geo" : { },
  "id_str" : "278540862076620800",
  "in_reply_to_user_id" : 214261325,
  "text" : "@RnRBBQTruck Is the food truck still going to run in the winter? Elma is...very far away.",
  "id" : 278540862076620800,
  "in_reply_to_status_id" : 278334731148468224,
  "created_at" : "2012-12-11 16:44:51 +0000",
  "in_reply_to_screen_name" : "RnRBBQTruck",
  "in_reply_to_user_id_str" : "214261325",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Miller",
      "screen_name" : "jqr",
      "indices" : [ 0, 4 ],
      "id_str" : "14351457",
      "id" : 14351457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278530925309075456",
  "geo" : { },
  "id_str" : "278536679336337408",
  "in_reply_to_user_id" : 14351457,
  "text" : "@jqr @derek_gamerchef I saved the map...my gamertag is \"Doctor Q\". I think if we're both in the same Forge map you can copy it too.",
  "id" : 278536679336337408,
  "in_reply_to_status_id" : 278530925309075456,
  "created_at" : "2012-12-11 16:28:13 +0000",
  "in_reply_to_screen_name" : "jqr",
  "in_reply_to_user_id_str" : "14351457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278461670504947712",
  "geo" : { },
  "id_str" : "278517843685941248",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito alright man, good luck! we'll be here still :)",
  "id" : 278517843685941248,
  "in_reply_to_status_id" : 278461670504947712,
  "created_at" : "2012-12-11 15:13:23 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Theatre of Youth",
      "screen_name" : "TheatreofYouth",
      "indices" : [ 58, 73 ],
      "id_str" : "36101240",
      "id" : 36101240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278517014333620226",
  "text" : "To the Holland Central District schoolbus driver going to @TheatreofYouth who cut off our Metro bus at Allen &amp; Elmwood: You're an asshole.",
  "id" : 278517014333620226,
  "created_at" : "2012-12-11 15:10:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278373892735791105",
  "text" : "Built a Halo 4 race map with @derek_gamerchef with launchers, ramps, traps, hairpins, and of course: Mario Kart sfx. BOOP BOOP BOOP BEEP!",
  "id" : 278373892735791105,
  "created_at" : "2012-12-11 05:41:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278370418782515200",
  "geo" : { },
  "id_str" : "278371657339514880",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt you need to take a break.",
  "id" : 278371657339514880,
  "in_reply_to_status_id" : 278370418782515200,
  "created_at" : "2012-12-11 05:32:29 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278314086033399808",
  "geo" : { },
  "id_str" : "278325552027422721",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito dang dude. Shipping off somewhere?",
  "id" : 278325552027422721,
  "in_reply_to_status_id" : 278314086033399808,
  "created_at" : "2012-12-11 02:29:17 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 119, 133 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278324575387934720",
  "text" : "\u201Cas long as I live on this mortal state, you need my approval before adding something as official Ruby\u201D - viva la BDFL @yukihiro_matz !",
  "id" : 278324575387934720,
  "created_at" : "2012-12-11 02:25:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/HiZD3ZDf",
      "expanded_url" : "http:\/\/bit.ly\/S02cXq",
      "display_url" : "bit.ly\/S02cXq"
    } ]
  },
  "geo" : { },
  "id_str" : "278323928269737984",
  "text" : "Now THIS is open source. Very proud of the Ruby community tonight. http:\/\/t.co\/HiZD3ZDf",
  "id" : 278323928269737984,
  "created_at" : "2012-12-11 02:22:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Assaf",
      "screen_name" : "assaf",
      "indices" : [ 52, 58 ],
      "id_str" : "2367111",
      "id" : 2367111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/5f6HhBP5",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/12\/10\/burrito-bomber-open-source-ha.html",
      "display_url" : "boingboing.net\/2012\/12\/10\/bur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278321132606722048",
  "text" : "B U R R I T O B O M B E R http:\/\/t.co\/5f6HhBP5 (via @assaf)",
  "id" : 278321132606722048,
  "created_at" : "2012-12-11 02:11:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 60, 70 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278293885321609217",
  "text" : "Me - \u201CDid you hear about the Australia iOS 6 maps problem?\u201D @aquaranto - \u201CIs it upside down?\u201D",
  "id" : 278293885321609217,
  "created_at" : "2012-12-11 00:23:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/278199329200676864\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/0rfNVYaE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9xc0OJCIAApBvA.png",
      "id_str" : "278199329209065472",
      "id" : 278199329209065472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9xc0OJCIAApBvA.png",
      "sizes" : [ {
        "h" : 104,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 1009
      } ],
      "display_url" : "pic.twitter.com\/0rfNVYaE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278199329200676864",
  "text" : "Love this UI detail in the latest iTunes: detail view for an album takes on the background color of the album. http:\/\/t.co\/0rfNVYaE",
  "id" : 278199329200676864,
  "created_at" : "2012-12-10 18:07:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randall Thomas",
      "screen_name" : "daksis",
      "indices" : [ 0, 7 ],
      "id_str" : "5437372",
      "id" : 5437372
    }, {
      "name" : "Thunderbolt Labs",
      "screen_name" : "ThunderboltLabs",
      "indices" : [ 8, 24 ],
      "id_str" : "414333099",
      "id" : 414333099
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 25, 32 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278194606401802241",
  "geo" : { },
  "id_str" : "278194787197267968",
  "in_reply_to_user_id" : 5437372,
  "text" : "@daksis @ThunderboltLabs @bryanl or Assassin's Guild.",
  "id" : 278194787197267968,
  "in_reply_to_status_id" : 278194606401802241,
  "created_at" : "2012-12-10 17:49:40 +0000",
  "in_reply_to_screen_name" : "daksis",
  "in_reply_to_user_id_str" : "5437372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 3, 15 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278186250077356033",
  "text" : "RT @bcardarella: At least RubyGems isn\u2019t down",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278185418825019392",
    "text" : "At least RubyGems isn\u2019t down",
    "id" : 278185418825019392,
    "created_at" : "2012-12-10 17:12:26 +0000",
    "user" : {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "protected" : false,
      "id_str" : "18787589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000553511645\/21a9348ff9f9ff11f9278695b8afa76d_normal.jpeg",
      "id" : 18787589,
      "verified" : false
    }
  },
  "id" : 278186250077356033,
  "created_at" : "2012-12-10 17:15:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "278177670209101824",
  "text" : "Come play something. Or just listen. Turntable is great. http:\/\/t.co\/epnjp2aB",
  "id" : 278177670209101824,
  "created_at" : "2012-12-10 16:41:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278170859573768192",
  "geo" : { },
  "id_str" : "278176768224010240",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy FRESH POTS!",
  "id" : 278176768224010240,
  "in_reply_to_status_id" : 278170859573768192,
  "created_at" : "2012-12-10 16:38:04 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "278176281718304768",
  "text" : "DJing in the CoworkBuffalo room. http:\/\/t.co\/epnjp2aB",
  "id" : 278176281718304768,
  "created_at" : "2012-12-10 16:36:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278159925287481344",
  "geo" : { },
  "id_str" : "278170746000379905",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy fresh pot right now!",
  "id" : 278170746000379905,
  "in_reply_to_status_id" : 278159925287481344,
  "created_at" : "2012-12-10 16:14:08 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278010935669583873",
  "geo" : { },
  "id_str" : "278013735291994112",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant it\u2019s not news!",
  "id" : 278013735291994112,
  "in_reply_to_status_id" : 278010935669583873,
  "created_at" : "2012-12-10 05:50:14 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277989803272843264",
  "geo" : { },
  "id_str" : "277994452021309441",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat in conclusion, really.",
  "id" : 277994452021309441,
  "in_reply_to_status_id" : 277989803272843264,
  "created_at" : "2012-12-10 04:33:36 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Tanase",
      "screen_name" : "zenmatt",
      "indices" : [ 0, 8 ],
      "id_str" : "654773",
      "id" : 654773
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 9, 13 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277849382165045248",
  "geo" : { },
  "id_str" : "277867490221125633",
  "in_reply_to_user_id" : 654773,
  "text" : "@zenmatt @dhh I think most are afraid of the guilt of holding up others in line or the fear of missing a flight.",
  "id" : 277867490221125633,
  "in_reply_to_status_id" : 277849382165045248,
  "created_at" : "2012-12-09 20:09:06 +0000",
  "in_reply_to_screen_name" : "zenmatt",
  "in_reply_to_user_id_str" : "654773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Matt Tanase",
      "screen_name" : "zenmatt",
      "indices" : [ 5, 13 ],
      "id_str" : "654773",
      "id" : 654773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277844171274985473",
  "geo" : { },
  "id_str" : "277845908064985088",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh @zenmatt most don\u2019t know its an option, imo",
  "id" : 277845908064985088,
  "in_reply_to_status_id" : 277844171274985473,
  "created_at" : "2012-12-09 18:43:21 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Tanase",
      "screen_name" : "zenmatt",
      "indices" : [ 0, 8 ],
      "id_str" : "654773",
      "id" : 654773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277804775083474944",
  "geo" : { },
  "id_str" : "277808650742005761",
  "in_reply_to_user_id" : 654773,
  "text" : "@zenmatt I get yelled\/talked at a lot too. Mostly just feel bad for them now.",
  "id" : 277808650742005761,
  "in_reply_to_status_id" : 277804775083474944,
  "created_at" : "2012-12-09 16:15:18 +0000",
  "in_reply_to_screen_name" : "zenmatt",
  "in_reply_to_user_id_str" : "654773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277638288511205376",
  "geo" : { },
  "id_str" : "277640315203092481",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 woot!",
  "id" : 277640315203092481,
  "in_reply_to_status_id" : 277638288511205376,
  "created_at" : "2012-12-09 05:06:24 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277628775049609219",
  "text" : "Scotchy scotch scotch.",
  "id" : 277628775049609219,
  "created_at" : "2012-12-09 04:20:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 20, 30 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277534146048438272",
  "geo" : { },
  "id_str" : "277556520881885184",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin thanks! @asianmack\u2019s doodles are \uD83C\uDD92",
  "id" : 277556520881885184,
  "in_reply_to_status_id" : 277534146048438272,
  "created_at" : "2012-12-08 23:33:25 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277524166436069376",
  "geo" : { },
  "id_str" : "277531646201323520",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove MAWWIAGE ! Congrats dude.",
  "id" : 277531646201323520,
  "in_reply_to_status_id" : 277524166436069376,
  "created_at" : "2012-12-08 21:54:35 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 9, 20 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 21, 33 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277528778169786368",
  "geo" : { },
  "id_str" : "277531411639066624",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @Alex_Godin @whereslloyd TACOS!!!",
  "id" : 277531411639066624,
  "in_reply_to_status_id" : 277528778169786368,
  "created_at" : "2012-12-08 21:53:39 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277451372746637312",
  "geo" : { },
  "id_str" : "277455211264622592",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant most people don\u2019t get this, ever.",
  "id" : 277455211264622592,
  "in_reply_to_status_id" : 277451372746637312,
  "created_at" : "2012-12-08 16:50:51 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 0, 11 ],
      "id_str" : "10774712",
      "id" : 10774712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277428027695173632",
  "geo" : { },
  "id_str" : "277431912472129537",
  "in_reply_to_user_id" : 10774712,
  "text" : "@richdownie it\u2019s pretty small. Science museum is ok! Albright Knox is the best though.",
  "id" : 277431912472129537,
  "in_reply_to_status_id" : 277428027695173632,
  "created_at" : "2012-12-08 15:18:17 +0000",
  "in_reply_to_screen_name" : "richdownie",
  "in_reply_to_user_id_str" : "10774712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 20, 34 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277298485060050944",
  "geo" : { },
  "id_str" : "277302007029710849",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove is that @garybernhardt ?",
  "id" : 277302007029710849,
  "in_reply_to_status_id" : 277298485060050944,
  "created_at" : "2012-12-08 06:42:05 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277292080890535936",
  "text" : "Difference between Chicago Uber and normal cabs: Uber would never hand me a book of blocks and have me find my destination.",
  "id" : 277292080890535936,
  "created_at" : "2012-12-08 06:02:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chan",
      "screen_name" : "jtcchan",
      "indices" : [ 3, 11 ],
      "id_str" : "12653762",
      "id" : 12653762
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 30, 36 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/5vx4Rk9Q",
      "expanded_url" : "http:\/\/instagr.am\/p\/S891-vLRvX\/",
      "display_url" : "instagr.am\/p\/S891-vLRvX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "277194099948388352",
  "text" : "RT @jtcchan: Oh nothing, just @qrush flinging shit at the office wall on a Friday. http:\/\/t.co\/5vx4Rk9Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 17, 23 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/5vx4Rk9Q",
        "expanded_url" : "http:\/\/instagr.am\/p\/S891-vLRvX\/",
        "display_url" : "instagr.am\/p\/S891-vLRvX\/"
      } ]
    },
    "geo" : { },
    "id_str" : "277182732541497344",
    "text" : "Oh nothing, just @qrush flinging shit at the office wall on a Friday. http:\/\/t.co\/5vx4Rk9Q",
    "id" : 277182732541497344,
    "created_at" : "2012-12-07 22:48:07 +0000",
    "user" : {
      "name" : "John Chan",
      "screen_name" : "jtcchan",
      "protected" : false,
      "id_str" : "12653762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000269652842\/9f73ce72d0aa0f83539f75e81cb08f16_normal.jpeg",
      "id" : 12653762,
      "verified" : false
    }
  },
  "id" : 277194099948388352,
  "created_at" : "2012-12-07 23:33:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277191628152774656",
  "text" : "Achievement unlocked: Put your shell in an infinite loop.",
  "id" : 277191628152774656,
  "created_at" : "2012-12-07 23:23:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277105484438315008",
  "geo" : { },
  "id_str" : "277106028502470658",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier It was more of a throw.",
  "id" : 277106028502470658,
  "in_reply_to_status_id" : 277105484438315008,
  "created_at" : "2012-12-07 17:43:20 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277104599708610564",
  "text" : "I just touched a poop emoji.",
  "id" : 277104599708610564,
  "created_at" : "2012-12-07 17:37:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Dixon",
      "screen_name" : "obfuscurity",
      "indices" : [ 0, 12 ],
      "id_str" : "66432490",
      "id" : 66432490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277097381303046144",
  "geo" : { },
  "id_str" : "277097943788564480",
  "in_reply_to_user_id" : 66432490,
  "text" : "@obfuscurity so good.",
  "id" : 277097943788564480,
  "in_reply_to_status_id" : 277097381303046144,
  "created_at" : "2012-12-07 17:11:12 +0000",
  "in_reply_to_screen_name" : "obfuscurity",
  "in_reply_to_user_id_str" : "66432490",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albright-Knox",
      "screen_name" : "AlbrightKnox",
      "indices" : [ 12, 25 ],
      "id_str" : "19289541",
      "id" : 19289541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Tg45DFMR",
      "expanded_url" : "http:\/\/instagram.com\/albrightknox",
      "display_url" : "instagram.com\/albrightknox"
    } ]
  },
  "geo" : { },
  "id_str" : "277094329728790528",
  "text" : "I love that @albrightknox has an Instagram: http:\/\/t.co\/Tg45DFMR",
  "id" : 277094329728790528,
  "created_at" : "2012-12-07 16:56:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/bTtHH4SG",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2012\/12\/04\/science\/science-sign-language.html",
      "display_url" : "nytimes.com\/interactive\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277083889409871873",
  "text" : "Awesome use of GIFs...not sure why I never saw this in use at RIT\/NTID: http:\/\/t.co\/bTtHH4SG",
  "id" : 277083889409871873,
  "created_at" : "2012-12-07 16:15:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 24, 34 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277077112278638592",
  "text" : "Apple pie for breakfast @37signals. Yep.",
  "id" : 277077112278638592,
  "created_at" : "2012-12-07 15:48:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 46, 57 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277076491945259008",
  "geo" : { },
  "id_str" : "277076706903351296",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k I can consult with local podcast expert @kevinpurdy about this!",
  "id" : 277076706903351296,
  "in_reply_to_status_id" : 277076491945259008,
  "created_at" : "2012-12-07 15:46:49 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277075529843232768",
  "geo" : { },
  "id_str" : "277076109303091202",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k I'm not getting into Boston until Saturday, sorry :\/ We need to visit more.",
  "id" : 277076109303091202,
  "in_reply_to_status_id" : 277075529843232768,
  "created_at" : "2012-12-07 15:44:26 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276949470275575808",
  "text" : "Today I saw a $200+ bottle of champagne at Walgreens. Today was not a normal day.",
  "id" : 276949470275575808,
  "created_at" : "2012-12-07 07:21:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276946775657566208",
  "text" : "Why is it that every time I travel west, I automatically assume that the hours gained by time zone are free?",
  "id" : 276946775657566208,
  "created_at" : "2012-12-07 07:10:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276888695532032000",
  "text" : "I can\u2019t stress enough how good Uber is. Hi Chicago!",
  "id" : 276888695532032000,
  "created_at" : "2012-12-07 03:19:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276887286665330688",
  "geo" : { },
  "id_str" : "276887645966180353",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini it lives!",
  "id" : 276887645966180353,
  "in_reply_to_status_id" : 276887286665330688,
  "created_at" : "2012-12-07 03:15:33 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FreeGeek Chicago",
      "screen_name" : "freegeekchicago",
      "indices" : [ 0, 16 ],
      "id_str" : "136991902",
      "id" : 136991902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276759684298461184",
  "geo" : { },
  "id_str" : "276760377340067840",
  "in_reply_to_user_id" : 136991902,
  "text" : "@freegeekchicago Oops. Maybe next time!",
  "id" : 276760377340067840,
  "in_reply_to_status_id" : 276759684298461184,
  "created_at" : "2012-12-06 18:49:50 +0000",
  "in_reply_to_screen_name" : "freegeekchicago",
  "in_reply_to_user_id_str" : "136991902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 0, 10 ],
      "id_str" : "14437070",
      "id" : 14437070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276758148025548800",
  "geo" : { },
  "id_str" : "276758464741650432",
  "in_reply_to_user_id" : 14437070,
  "text" : "@marksands I've used it for a few, simple layouts and it's pretty nice. For anything more than that...yeah...",
  "id" : 276758464741650432,
  "in_reply_to_status_id" : 276758148025548800,
  "created_at" : "2012-12-06 18:42:14 +0000",
  "in_reply_to_screen_name" : "marksands",
  "in_reply_to_user_id_str" : "14437070",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Williams",
      "screen_name" : "justin",
      "indices" : [ 0, 7 ],
      "id_str" : "929",
      "id" : 929
    }, {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 8, 18 ],
      "id_str" : "14437070",
      "id" : 14437070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276710335501697026",
  "geo" : { },
  "id_str" : "276757489490489346",
  "in_reply_to_user_id" : 929,
  "text" : "@justin @marksands the error messages are just terrifying and confusing too :(",
  "id" : 276757489490489346,
  "in_reply_to_status_id" : 276710335501697026,
  "created_at" : "2012-12-06 18:38:22 +0000",
  "in_reply_to_screen_name" : "justin",
  "in_reply_to_user_id_str" : "929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FreeGeek Chicago",
      "screen_name" : "freegeekchicago",
      "indices" : [ 0, 16 ],
      "id_str" : "136991902",
      "id" : 136991902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276427231776108546",
  "geo" : { },
  "id_str" : "276755103438999552",
  "in_reply_to_user_id" : 136991902,
  "text" : "@freegeekchicago Will it go later than 8? I'm getting into Chicago tonight and might be able to say hi",
  "id" : 276755103438999552,
  "in_reply_to_status_id" : 276427231776108546,
  "created_at" : "2012-12-06 18:28:53 +0000",
  "in_reply_to_screen_name" : "freegeekchicago",
  "in_reply_to_user_id_str" : "136991902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276733212020072448",
  "geo" : { },
  "id_str" : "276734916190932992",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Cool shit. I'll let you have the \/r\/buffalo karma, they'd love it.",
  "id" : 276734916190932992,
  "in_reply_to_status_id" : 276733212020072448,
  "created_at" : "2012-12-06 17:08:40 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276732296588054528",
  "geo" : { },
  "id_str" : "276733019782524928",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten &lt;Message&gt;Access Denied&lt;\/Message&gt;",
  "id" : 276733019782524928,
  "in_reply_to_status_id" : 276732296588054528,
  "created_at" : "2012-12-06 17:01:08 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syd Lawrence",
      "screen_name" : "sydlawrence",
      "indices" : [ 0, 12 ],
      "id_str" : "14860093",
      "id" : 14860093
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 13, 21 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 127, 136 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276719914566422528",
  "geo" : { },
  "id_str" : "276725760851582976",
  "in_reply_to_user_id" : 14860093,
  "text" : "@sydlawrence @jayunit looks neat! These are good guidelines for bigger events...we could probably link\/support them though via @openhack!",
  "id" : 276725760851582976,
  "in_reply_to_status_id" : 276719914566422528,
  "created_at" : "2012-12-06 16:32:17 +0000",
  "in_reply_to_screen_name" : "sydlawrence",
  "in_reply_to_user_id_str" : "14860093",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 74, 88 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276718864329482240",
  "geo" : { },
  "id_str" : "276719172745043968",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten BigMapBlog has great old maps of Buffalo too. (as seen on @coworkbuffalo's site)",
  "id" : 276719172745043968,
  "in_reply_to_status_id" : 276718864329482240,
  "created_at" : "2012-12-06 16:06:06 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 10, 19 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Willy Is 40",
      "screen_name" : "Willy_Is_Forty",
      "indices" : [ 46, 61 ],
      "id_str" : "701227110",
      "id" : 701227110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 84 ],
      "url" : "https:\/\/t.co\/s1tZVlEr",
      "expanded_url" : "https:\/\/si0.twimg.com\/profile_images\/2406762207\/image.jpg",
      "display_url" : "si0.twimg.com\/profile_images\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276718911607672833",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @bquarant @AqueousBand found it via @Willy_Is_Forty: https:\/\/t.co\/s1tZVlEr",
  "id" : 276718911607672833,
  "created_at" : "2012-12-06 16:05:04 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/NKzfIvfc",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/commons\/a\/af\/Buffalo_Street_Car_and_Bus_Guide_Oct_1935.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276717987283759104",
  "text" : "The street car system in Buffalo was massive in the early 1900s. http:\/\/t.co\/NKzfIvfc  (huge image)",
  "id" : 276717987283759104,
  "created_at" : "2012-12-06 16:01:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 3, 11 ],
      "id_str" : "14408469",
      "id" : 14408469
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "proud",
      "indices" : [ 119, 125 ]
    }, {
      "text" : "fb",
      "indices" : [ 126, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/BM0u6OAg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=X1tJAT7ioEg&feature=youtu.be&t=42m12s",
      "display_url" : "youtube.com\/watch?v=X1tJAT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276717474576216064",
  "text" : "RT @uptonic: I love that Campfire and Basecamp played a role in Obama's successful 2012 campaign: http:\/\/t.co\/BM0u6OAg #proud #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "proud",
        "indices" : [ 106, 112 ]
      }, {
        "text" : "fb",
        "indices" : [ 113, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/BM0u6OAg",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=X1tJAT7ioEg&feature=youtu.be&t=42m12s",
        "display_url" : "youtube.com\/watch?v=X1tJAT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "276716009954631681",
    "text" : "I love that Campfire and Basecamp played a role in Obama's successful 2012 campaign: http:\/\/t.co\/BM0u6OAg #proud #fb",
    "id" : 276716009954631681,
    "created_at" : "2012-12-06 15:53:32 +0000",
    "user" : {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "protected" : false,
      "id_str" : "14408469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558309920806678529\/p_k4_j9p_normal.jpeg",
      "id" : 14408469,
      "verified" : false
    }
  },
  "id" : 276717474576216064,
  "created_at" : "2012-12-06 15:59:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/vM7pitpK",
      "expanded_url" : "http:\/\/s3-ec.buzzfed.com\/static\/enhanced\/webdr01\/2012\/11\/30\/12\/anigif_enhanced-buzz-7145-1354298200-1.gif",
      "display_url" : "s3-ec.buzzfed.com\/static\/enhance\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276717411162525696",
  "text" : "Current status: http:\/\/t.co\/vM7pitpK",
  "id" : 276717411162525696,
  "created_at" : "2012-12-06 15:59:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 86, 95 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276716916637302784",
  "geo" : { },
  "id_str" : "276717324168462336",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo Oh, he's private. is \"Willy is 40\" named after the graffiti on NF Blvd? \/cc @bquarant",
  "id" : 276717324168462336,
  "in_reply_to_status_id" : 276716916637302784,
  "created_at" : "2012-12-06 15:58:45 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/16hgfEZu",
      "expanded_url" : "http:\/\/tmblr.co\/ZyT1fxYnGB3J",
      "display_url" : "tmblr.co\/ZyT1fxYnGB3J"
    } ]
  },
  "geo" : { },
  "id_str" : "276711112660107265",
  "text" : "Love these comics...I wish it was a series. http:\/\/t.co\/16hgfEZu",
  "id" : 276711112660107265,
  "created_at" : "2012-12-06 15:34:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 10, 22 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 62, 71 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270952065675710464",
  "geo" : { },
  "id_str" : "276560102067150848",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant @AqueousBand Holy crap, remembering this now. Maybe @LawnMemo knows?",
  "id" : 276560102067150848,
  "in_reply_to_status_id" : 270952065675710464,
  "created_at" : "2012-12-06 05:34:01 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 26, 36 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276545395365130240",
  "text" : "Going to bring Dixit into @37signals this Friday\u2026let\u2019s see how much havoc this creates. \uD83D\uDE01",
  "id" : 276545395365130240,
  "created_at" : "2012-12-06 04:35:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276495064996384768",
  "geo" : { },
  "id_str" : "276495662789574656",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza And suddenly realizing that Vice City is 10 years old...",
  "id" : 276495662789574656,
  "in_reply_to_status_id" : 276495064996384768,
  "created_at" : "2012-12-06 01:17:57 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276462282278584320",
  "geo" : { },
  "id_str" : "276462642586083328",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit Yes, yes, more comments.",
  "id" : 276462642586083328,
  "in_reply_to_status_id" : 276462282278584320,
  "created_at" : "2012-12-05 23:06:45 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/kKb7ZdKA",
      "expanded_url" : "http:\/\/www.houstonchronicle.com\/",
      "display_url" : "houstonchronicle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "276446747847438336",
  "text" : "Stunning redesign of the Houston Chronicle puts the Buffalo News to shame. http:\/\/t.co\/kKb7ZdKA [bn]raged.",
  "id" : 276446747847438336,
  "created_at" : "2012-12-05 22:03:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276428929764573185",
  "geo" : { },
  "id_str" : "276429764733071360",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt Wow.",
  "id" : 276429764733071360,
  "in_reply_to_status_id" : 276428929764573185,
  "created_at" : "2012-12-05 20:56:06 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276377550656253952",
  "geo" : { },
  "id_str" : "276427784484687872",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn oh geez! Maybe it's not obvious enough in the meetup rules\/howto? Definitely helps out.",
  "id" : 276427784484687872,
  "in_reply_to_status_id" : 276377550656253952,
  "created_at" : "2012-12-05 20:48:14 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276398572528869376",
  "text" : "Flipped a triangle and made a sad smiley happy with canvas in class today. Most got it and some got to the bonus text exercise. Small wins!",
  "id" : 276398572528869376,
  "created_at" : "2012-12-05 18:52:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "OpenHack Louisville",
      "screen_name" : "OpenHackLVL",
      "indices" : [ 10, 22 ],
      "id_str" : "948111204",
      "id" : 948111204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276295776534163457",
  "geo" : { },
  "id_str" : "276371501782032385",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @OpenHackLVL Hmm, not yet. It's kind of meant to be unstructured.",
  "id" : 276371501782032385,
  "in_reply_to_status_id" : 276295776534163457,
  "created_at" : "2012-12-05 17:04:35 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kremer",
      "screen_name" : "mkrmr",
      "indices" : [ 0, 6 ],
      "id_str" : "15118601",
      "id" : 15118601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276182778507300864",
  "geo" : { },
  "id_str" : "276183545691652096",
  "in_reply_to_user_id" : 15118601,
  "text" : "@mkrmr thanks. And yeah\u2026the dog park is irreplaceable",
  "id" : 276183545691652096,
  "in_reply_to_status_id" : 276182778507300864,
  "created_at" : "2012-12-05 04:37:43 +0000",
  "in_reply_to_screen_name" : "mkrmr",
  "in_reply_to_user_id_str" : "15118601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kremer",
      "screen_name" : "mkrmr",
      "indices" : [ 0, 6 ],
      "id_str" : "15118601",
      "id" : 15118601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276181190313115648",
  "geo" : { },
  "id_str" : "276181321628401664",
  "in_reply_to_user_id" : 15118601,
  "text" : "@mkrmr yep. Bad owners :(",
  "id" : 276181321628401664,
  "in_reply_to_status_id" : 276181190313115648,
  "created_at" : "2012-12-05 04:28:52 +0000",
  "in_reply_to_screen_name" : "mkrmr",
  "in_reply_to_user_id_str" : "15118601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276174283133300736",
  "geo" : { },
  "id_str" : "276175432993349634",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt the new iOS app.",
  "id" : 276175432993349634,
  "in_reply_to_status_id" : 276174283133300736,
  "created_at" : "2012-12-05 04:05:28 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276174039800745984",
  "text" : "Stunned by the details in GMail app: status bar to show flash messages (\u201DSent\u201D after reply), default avatars as the first letter are great.",
  "id" : 276174039800745984,
  "created_at" : "2012-12-05 03:59:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/c565YotD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=V-fRuoMIfpw",
      "display_url" : "youtube.com\/watch?v=V-fRuo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "276132249148219392",
  "geo" : { },
  "id_str" : "276132409429344257",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius http:\/\/t.co\/c565YotD",
  "id" : 276132409429344257,
  "in_reply_to_status_id" : 276132249148219392,
  "created_at" : "2012-12-05 01:14:31 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 23, 35 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276113820194324481",
  "geo" : { },
  "id_str" : "276122735703384066",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @aquaranto @singheyjude GOLD",
  "id" : 276122735703384066,
  "in_reply_to_status_id" : 276113820194324481,
  "created_at" : "2012-12-05 00:36:04 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 2, 11 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276121487956660224",
  "text" : "4 @OpenHack meetups are tonight: Toledo, Miami, Louisville, Buffalo! Beyond happy about this.",
  "id" : 276121487956660224,
  "created_at" : "2012-12-05 00:31:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 14, 23 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "OpenHack Louisville",
      "screen_name" : "OpenHackLVL",
      "indices" : [ 45, 57 ],
      "id_str" : "948111204",
      "id" : 948111204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276120375006490624",
  "text" : "Woot, Buffalo @OpenHack 4 is underway! Hi to @OpenHackLVL !",
  "id" : 276120375006490624,
  "created_at" : "2012-12-05 00:26:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 3, 16 ],
      "id_str" : "38450774",
      "id" : 38450774
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 25, 34 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276120232416907265",
  "text" : "RT @robertromito: Hello, @openhack. Nice turn out so far",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 7, 16 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "276114966120128513",
    "text" : "Hello, @openhack. Nice turn out so far",
    "id" : 276114966120128513,
    "created_at" : "2012-12-05 00:05:12 +0000",
    "user" : {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "protected" : false,
      "id_str" : "38450774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/250418735\/myheadshot_normal.jpg",
      "id" : 38450774,
      "verified" : false
    }
  },
  "id" : 276120232416907265,
  "created_at" : "2012-12-05 00:26:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 70, 80 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 85, 97 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276112452452765696",
  "geo" : { },
  "id_str" : "276113719270973440",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden oh yes it does. Foodler in Boston delivered ice cream for @aquaranto and @singheyjude once.",
  "id" : 276113719270973440,
  "in_reply_to_status_id" : 276112452452765696,
  "created_at" : "2012-12-05 00:00:15 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276094496981262336",
  "text" : "git checkout -b goodburger; echo \"WELCOME TO GOOD BURGER, HOME OF THE GOOD BURGER! CAN I TAKE YOUR ORDER?\"",
  "id" : 276094496981262336,
  "created_at" : "2012-12-04 22:43:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276086637556031488",
  "text" : "Doesn't seem to be bothering him (running on it just fine) and I don't want to be that guy, but fucking pitbulls. &gt;:[",
  "id" : 276086637556031488,
  "created_at" : "2012-12-04 22:12:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/PN19Zch9",
      "expanded_url" : "http:\/\/3.bp.blogspot.com\/_KNK6tqSic5U\/TGcEFVm08NI\/AAAAAAAAA8M\/tDHreJ0wUpc\/s320\/RageFace1-291x300.png",
      "display_url" : "3.bp.blogspot.com\/_KNK6tqSic5U\/T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276086496560300032",
  "text" : "Ged's leg is swollen from the dog bite yesterday. http:\/\/t.co\/PN19Zch9",
  "id" : 276086496560300032,
  "created_at" : "2012-12-04 22:12:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reda Lemeden",
      "screen_name" : "kaishin",
      "indices" : [ 0, 8 ],
      "id_str" : "9088822",
      "id" : 9088822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276021753552175104",
  "geo" : { },
  "id_str" : "276022402918539264",
  "in_reply_to_user_id" : 9088822,
  "text" : "@kaishin HOW IS QWERTY A WORD!!!?",
  "id" : 276022402918539264,
  "in_reply_to_status_id" : 276021753552175104,
  "created_at" : "2012-12-04 17:57:23 +0000",
  "in_reply_to_screen_name" : "kaishin",
  "in_reply_to_user_id_str" : "9088822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary G.",
      "screen_name" : "KnittingDev",
      "indices" : [ 0, 12 ],
      "id_str" : "20552033",
      "id" : 20552033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/iciwQnDC",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/6nc1h\/im_in_college_and_i_want_to_contribute_to_an_oss\/",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "276001619735375873",
  "geo" : { },
  "id_str" : "276015523966373888",
  "in_reply_to_user_id" : 20552033,
  "text" : "@KnittingDev I asked this 4 years ago to proggit: http:\/\/t.co\/iciwQnDC",
  "id" : 276015523966373888,
  "in_reply_to_status_id" : 276001619735375873,
  "created_at" : "2012-12-04 17:30:03 +0000",
  "in_reply_to_screen_name" : "KnittingDev",
  "in_reply_to_user_id_str" : "20552033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275993903067435008",
  "geo" : { },
  "id_str" : "276014458957094912",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu we've gotten maybe an inch this year?",
  "id" : 276014458957094912,
  "in_reply_to_status_id" : 275993903067435008,
  "created_at" : "2012-12-04 17:25:49 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoodCoworking",
      "screen_name" : "GoodCoworking",
      "indices" : [ 3, 17 ],
      "id_str" : "603856584",
      "id" : 603856584
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 77, 91 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/u4gbwe4Q",
      "expanded_url" : "http:\/\/goodcoworking.com\/locations\/coworkbuffalo",
      "display_url" : "goodcoworking.com\/locations\/cowo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276006673888452608",
  "text" : "RT @GoodCoworking: Love Coworking at CoworkBuffalo? Share your stories about @coworkbuffalo on GoodCoworking http:\/\/t.co\/u4gbwe4Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 58, 72 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/u4gbwe4Q",
        "expanded_url" : "http:\/\/goodcoworking.com\/locations\/coworkbuffalo",
        "display_url" : "goodcoworking.com\/locations\/cowo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "276002650498150400",
    "text" : "Love Coworking at CoworkBuffalo? Share your stories about @coworkbuffalo on GoodCoworking http:\/\/t.co\/u4gbwe4Q",
    "id" : 276002650498150400,
    "created_at" : "2012-12-04 16:38:54 +0000",
    "user" : {
      "name" : "GoodCoworking",
      "screen_name" : "GoodCoworking",
      "protected" : false,
      "id_str" : "603856584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755335906\/ee77c397c6c30e71f55fd41849ce778f_normal.png",
      "id" : 603856584,
      "verified" : false
    }
  },
  "id" : 276006673888452608,
  "created_at" : "2012-12-04 16:54:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275985806206832641",
  "geo" : { },
  "id_str" : "275986613748764673",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle Thanks! I need to read more of his stuff.",
  "id" : 275986613748764673,
  "in_reply_to_status_id" : 275985806206832641,
  "created_at" : "2012-12-04 15:35:10 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275985680600035328",
  "geo" : { },
  "id_str" : "275986054186676226",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Does that mean I get more free massages?",
  "id" : 275986054186676226,
  "in_reply_to_status_id" : 275985680600035328,
  "created_at" : "2012-12-04 15:32:57 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/BH2WEale",
      "expanded_url" : "http:\/\/news.ycombinator.com\/newest",
      "display_url" : "news.ycombinator.com\/newest"
    } ]
  },
  "geo" : { },
  "id_str" : "275985120433958912",
  "text" : "Pushing my guilt onto Hacker News today, upboats! (You have to find the post since HN's algorithm is stupid): http:\/\/t.co\/BH2WEale",
  "id" : 275985120433958912,
  "created_at" : "2012-12-04 15:29:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275984073976082433",
  "text" : "I just biked to @coworkbuffalo on a sunny, 63 degree day on December 4th. Wat.",
  "id" : 275984073976082433,
  "created_at" : "2012-12-04 15:25:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/E9nn0NY5",
      "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/37183308463\/announcing-inspect-2013-the-rubymotion-conference",
      "display_url" : "blog.rubymotion.com\/post\/371833084\u2026"
    }, {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/IF6AG4k3",
      "expanded_url" : "http:\/\/www.rubymotion.com\/conference",
      "display_url" : "rubymotion.com\/conference"
    } ]
  },
  "geo" : { },
  "id_str" : "275963030070759424",
  "text" : "RT @RubyMotion: Announcing the first RubyMotion conference! Early bird tickets at 20% off. http:\/\/t.co\/E9nn0NY5 http:\/\/t.co\/IF6AG4k3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/E9nn0NY5",
        "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/37183308463\/announcing-inspect-2013-the-rubymotion-conference",
        "display_url" : "blog.rubymotion.com\/post\/371833084\u2026"
      }, {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/IF6AG4k3",
        "expanded_url" : "http:\/\/www.rubymotion.com\/conference",
        "display_url" : "rubymotion.com\/conference"
      } ]
    },
    "geo" : { },
    "id_str" : "275959800620261377",
    "text" : "Announcing the first RubyMotion conference! Early bird tickets at 20% off. http:\/\/t.co\/E9nn0NY5 http:\/\/t.co\/IF6AG4k3",
    "id" : 275959800620261377,
    "created_at" : "2012-12-04 13:48:38 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 275963030070759424,
  "created_at" : "2012-12-04 14:01:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275802256186671104",
  "geo" : { },
  "id_str" : "275812073508831232",
  "in_reply_to_user_id" : 896641,
  "text" : "@JZ the waterfall scene and the fluid dynamics blew my mind. The CG breakthroughs there are amazing.",
  "id" : 275812073508831232,
  "in_reply_to_status_id" : 275802256186671104,
  "created_at" : "2012-12-04 04:01:37 +0000",
  "in_reply_to_screen_name" : "jasonzimdars",
  "in_reply_to_user_id_str" : "896641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275741050671345664",
  "geo" : { },
  "id_str" : "275763121560363008",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine heh, not an option here! Didn\u2019t know you had a dog!",
  "id" : 275763121560363008,
  "in_reply_to_status_id" : 275741050671345664,
  "created_at" : "2012-12-04 00:47:06 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275722308197425152",
  "geo" : { },
  "id_str" : "275740774497394688",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic agreed but there are others too.",
  "id" : 275740774497394688,
  "in_reply_to_status_id" : 275722308197425152,
  "created_at" : "2012-12-03 23:18:18 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275731437729230848",
  "geo" : { },
  "id_str" : "275731779246256128",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench wrist hurts like a mofo. Ged was very freaked out, is recovering ok. Didn\u2019t recognize the other dog.",
  "id" : 275731779246256128,
  "in_reply_to_status_id" : 275731437729230848,
  "created_at" : "2012-12-03 22:42:33 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275730743676780545",
  "text" : "Dog park trip interrupted by the fucking pitbull. 3 cuts on Ged, one bite from Ged on my wrist. Dogs!",
  "id" : 275730743676780545,
  "created_at" : "2012-12-03 22:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275714509677678592",
  "geo" : { },
  "id_str" : "275715060456906752",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k thanks dude! And fixed.",
  "id" : 275715060456906752,
  "in_reply_to_status_id" : 275714509677678592,
  "created_at" : "2012-12-03 21:36:07 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275710550858690560",
  "geo" : { },
  "id_str" : "275710991277367296",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen ...and then you realize it's been that way for months\/years?",
  "id" : 275710991277367296,
  "in_reply_to_status_id" : 275710550858690560,
  "created_at" : "2012-12-03 21:19:57 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275710371795460097",
  "geo" : { },
  "id_str" : "275710886612725760",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen thanks dude....trying to be honest and open about it.",
  "id" : 275710886612725760,
  "in_reply_to_status_id" : 275710371795460097,
  "created_at" : "2012-12-03 21:19:32 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275710077556645890",
  "geo" : { },
  "id_str" : "275710806908346368",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz i'm trying to avoid the sociopath endpoint :)",
  "id" : 275710806908346368,
  "in_reply_to_status_id" : 275710077556645890,
  "created_at" : "2012-12-03 21:19:13 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0432 \u0414\u043C\u0438\u0442\u0440\u0438\u0439",
      "screen_name" : "Emualynk",
      "indices" : [ 0, 9 ],
      "id_str" : "2813936042",
      "id" : 2813936042
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 10, 19 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/lHiWdA1P",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Friend_zone",
      "display_url" : "en.wikipedia.org\/wiki\/Friend_zo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "275705175199604737",
  "geo" : { },
  "id_str" : "275709523803652096",
  "in_reply_to_user_id" : 16183394,
  "text" : "@Emualynk @konklone even better: http:\/\/t.co\/lHiWdA1P",
  "id" : 275709523803652096,
  "in_reply_to_status_id" : 275705175199604737,
  "created_at" : "2012-12-03 21:14:07 +0000",
  "in_reply_to_screen_name" : "noisegrrrl",
  "in_reply_to_user_id_str" : "16183394",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 12, 21 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "benatkin",
      "screen_name" : "benatkin",
      "indices" : [ 22, 31 ],
      "id_str" : "64218381",
      "id" : 64218381
    }, {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 32, 43 ],
      "id_str" : "14420513",
      "id" : 14420513
    }, {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 44, 57 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275708891453616128",
  "geo" : { },
  "id_str" : "275709271319142401",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini @roidrage @benatkin @fromonesrc @technoweenie sorry! herp derp.",
  "id" : 275709271319142401,
  "in_reply_to_status_id" : 275708891453616128,
  "created_at" : "2012-12-03 21:13:07 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275708716949590016",
  "geo" : { },
  "id_str" : "275709014900342784",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie Fixed! This is what I get for pasting.",
  "id" : 275709014900342784,
  "in_reply_to_status_id" : 275708716949590016,
  "created_at" : "2012-12-03 21:12:06 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/CDza8Qai",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3349-open-source-guilt-passion",
      "display_url" : "37signals.com\/svn\/posts\/3349\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275708942976421888",
  "text" : "I'd love to hear your thoughts on guilt in open source - it's not talked about enough: http:\/\/t.co\/CDza8Qai",
  "id" : 275708942976421888,
  "created_at" : "2012-12-03 21:11:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275708703766872065",
  "geo" : { },
  "id_str" : "275708790198894592",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini Let's try that again...",
  "id" : 275708790198894592,
  "in_reply_to_status_id" : 275708703766872065,
  "created_at" : "2012-12-03 21:11:12 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/er35E8P3",
      "expanded_url" : "http:\/\/catb.org\/esr\/writings\/homesteading\/homesteading\/",
      "display_url" : "catb.org\/esr\/writings\/h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275708446979010560",
  "text" : "Homesteading the Noosphere is a great article that's very related to all of OSS passion\/guiltness: http:\/\/t.co\/er35E8P3",
  "id" : 275708446979010560,
  "created_at" : "2012-12-03 21:09:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/CDza8Qai",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3349-open-source-guilt-passion",
      "display_url" : "37signals.com\/svn\/posts\/3349\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275704499392368640",
  "text" : "Wrote up my approach to open source: http:\/\/t.co\/CDza8Qai",
  "id" : 275704499392368640,
  "created_at" : "2012-12-03 20:54:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275692104796225536",
  "text" : "OH: \"PLEASE SLICE MY BRAIN INTO THIN SHEETS AND TURN ME INTO A COMPUTER\"",
  "id" : 275692104796225536,
  "created_at" : "2012-12-03 20:04:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horia Constantin",
      "screen_name" : "ConstantinHoria",
      "indices" : [ 0, 16 ],
      "id_str" : "769262971",
      "id" : 769262971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275678176208879616",
  "geo" : { },
  "id_str" : "275679147093790720",
  "in_reply_to_user_id" : 769262971,
  "text" : "@ConstantinHoria yep.",
  "id" : 275679147093790720,
  "in_reply_to_status_id" : 275678176208879616,
  "created_at" : "2012-12-03 19:13:25 +0000",
  "in_reply_to_screen_name" : "ConstantinHoria",
  "in_reply_to_user_id_str" : "769262971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 45, 54 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/fz3iEMyV",
      "expanded_url" : "http:\/\/rustbuilt.org\/",
      "display_url" : "rustbuilt.org"
    } ]
  },
  "geo" : { },
  "id_str" : "275679023357636611",
  "text" : "Going to put http:\/\/t.co\/fz3iEMyV 's logo on @OpenHack tomorrow night. Love this concept.",
  "id" : 275679023357636611,
  "created_at" : "2012-12-03 19:12:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBuilt",
      "screen_name" : "RustBuilt",
      "indices" : [ 4, 14 ],
      "id_str" : "735197784",
      "id" : 735197784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/FL7COQbz",
      "expanded_url" : "http:\/\/rustbuilt.org",
      "display_url" : "rustbuilt.org"
    } ]
  },
  "geo" : { },
  "id_str" : "275678837755490306",
  "text" : "I'm @RustBuilt. Are you? Join those who are bringing innovation back to the Rust Belt. http:\/\/t.co\/FL7COQbz",
  "id" : 275678837755490306,
  "created_at" : "2012-12-03 19:12:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275675720670384128",
  "geo" : { },
  "id_str" : "275677145534173185",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 OPPAN HONE STYLE",
  "id" : 275677145534173185,
  "in_reply_to_status_id" : 275675720670384128,
  "created_at" : "2012-12-03 19:05:27 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275673809917468672",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 why isn't this your avatar!?",
  "id" : 275673809917468672,
  "created_at" : "2012-12-03 18:52:12 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 10, 17 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275673468136214528",
  "geo" : { },
  "id_str" : "275673703566688256",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems @hone02 amazing",
  "id" : 275673703566688256,
  "in_reply_to_status_id" : 275673468136214528,
  "created_at" : "2012-12-03 18:51:47 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burke Libbey",
      "screen_name" : "burkelibbey",
      "indices" : [ 0, 12 ],
      "id_str" : "16598344",
      "id" : 16598344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275649250786934785",
  "geo" : { },
  "id_str" : "275650816382226433",
  "in_reply_to_user_id" : 16598344,
  "text" : "@burkelibbey neat! Just trying to help you maintain less code :)",
  "id" : 275650816382226433,
  "in_reply_to_status_id" : 275649250786934785,
  "created_at" : "2012-12-03 17:20:50 +0000",
  "in_reply_to_screen_name" : "burkelibbey",
  "in_reply_to_user_id_str" : "16598344",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275639273011679232",
  "geo" : { },
  "id_str" : "275640354622021632",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed I meant both of those in a good way!",
  "id" : 275640354622021632,
  "in_reply_to_status_id" : 275639273011679232,
  "created_at" : "2012-12-03 16:39:16 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275638013021794304",
  "geo" : { },
  "id_str" : "275638736493096960",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed looks ridiculous and silly.",
  "id" : 275638736493096960,
  "in_reply_to_status_id" : 275638013021794304,
  "created_at" : "2012-12-03 16:32:50 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burke Libbey",
      "screen_name" : "burkelibbey",
      "indices" : [ 0, 12 ],
      "id_str" : "16598344",
      "id" : 16598344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275629774821535745",
  "geo" : { },
  "id_str" : "275631118714286081",
  "in_reply_to_user_id" : 16598344,
  "text" : "@burkelibbey huh, not totally following. So if the app depends on m, you need to load your own m first?",
  "id" : 275631118714286081,
  "in_reply_to_status_id" : 275629774821535745,
  "created_at" : "2012-12-03 16:02:34 +0000",
  "in_reply_to_screen_name" : "burkelibbey",
  "in_reply_to_user_id_str" : "16598344",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 3, 13 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 48, 54 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 114, 120 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275629375825780736",
  "text" : "RT @ngauthier: replacing my \"rtest\" script with @qrush's \"m\", because it's just as fast and more powerful. Thanks @qrush!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 33, 39 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 99, 105 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275626735976984576",
    "text" : "replacing my \"rtest\" script with @qrush's \"m\", because it's just as fast and more powerful. Thanks @qrush!",
    "id" : 275626735976984576,
    "created_at" : "2012-12-03 15:45:09 +0000",
    "user" : {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "protected" : false,
      "id_str" : "15243796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539452893112201217\/aJOphfgM_normal.png",
      "id" : 15243796,
      "verified" : false
    }
  },
  "id" : 275629375825780736,
  "created_at" : "2012-12-03 15:55:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burke Libbey",
      "screen_name" : "burkelibbey",
      "indices" : [ 0, 12 ],
      "id_str" : "16598344",
      "id" : 16598344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275629283764994051",
  "in_reply_to_user_id" : 16598344,
  "text" : "@burkelibbey hey, just saw that Zeus uses m. Hell yes! Any reason why it can't use the gem as a normal dep? Just curious.",
  "id" : 275629283764994051,
  "created_at" : "2012-12-03 15:55:16 +0000",
  "in_reply_to_screen_name" : "burkelibbey",
  "in_reply_to_user_id_str" : "16598344",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275610018420768769",
  "geo" : { },
  "id_str" : "275618420358254593",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh I hit 4 airports in a row this past week with no free massages. Chances are on my way to Chicago this week my luck will run out.",
  "id" : 275618420358254593,
  "in_reply_to_status_id" : 275610018420768769,
  "created_at" : "2012-12-03 15:12:06 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275617262478696449",
  "geo" : { },
  "id_str" : "275617894346399744",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit Welcome home dude!",
  "id" : 275617894346399744,
  "in_reply_to_status_id" : 275617262478696449,
  "created_at" : "2012-12-03 15:10:01 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 5, 14 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/B0Ww4vUY",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/92211452\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275607287631081473",
  "text" : "Hey, @OpenHack Buffalo is tomorrow night! If you're going please sign up: http:\/\/t.co\/B0Ww4vUY",
  "id" : 275607287631081473,
  "created_at" : "2012-12-03 14:27:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/KdaJ5OII",
      "expanded_url" : "http:\/\/blog.sleepio.com\/2012\/12\/02\/video-games-and-sleep-loss\/",
      "display_url" : "blog.sleepio.com\/2012\/12\/02\/vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275604801872621569",
  "text" : "Well, duh. The LED attachment plugged into my Game Boy was to AVOID sleep! http:\/\/t.co\/KdaJ5OII",
  "id" : 275604801872621569,
  "created_at" : "2012-12-03 14:17:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/8awttAN9",
      "expanded_url" : "http:\/\/turntable.fm\/jam_bands_no_lames_1up1down",
      "display_url" : "turntable.fm\/jam_bands_no_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275604013901307904",
  "text" : "DJing in the Jam Bands room. Now playing The Velvet Underground: Rock And Roll (Live) #turntablefm http:\/\/t.co\/8awttAN9",
  "id" : 275604013901307904,
  "created_at" : "2012-12-03 14:14:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 0, 11 ],
      "id_str" : "14931637",
      "id" : 14931637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275480598917808128",
  "geo" : { },
  "id_str" : "275485641263947776",
  "in_reply_to_user_id" : 14931637,
  "text" : "@MattBinder I hope they cutaway to a \u201CCard Shop\u201D and did a few action shots of collectibles before approaching the \u201CCard Expert\u201D",
  "id" : 275485641263947776,
  "in_reply_to_status_id" : 275480598917808128,
  "created_at" : "2012-12-03 06:24:29 +0000",
  "in_reply_to_screen_name" : "MattBinder",
  "in_reply_to_user_id_str" : "14931637",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275452392105988097",
  "text" : "BUF live tweets: narrowly missed a homecoming complete with balloons, flowers, and local news camera.",
  "id" : 275452392105988097,
  "created_at" : "2012-12-03 04:12:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275403763722883072",
  "geo" : { },
  "id_str" : "275405707937980416",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety the total loss of control with all of the airline\/flight process is the #1 reason I dislike flying.",
  "id" : 275405707937980416,
  "in_reply_to_status_id" : 275403763722883072,
  "created_at" : "2012-12-03 01:06:52 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Box\u00AE Group",
      "screen_name" : "blueboxgrp",
      "indices" : [ 84, 95 ],
      "id_str" : "19605368",
      "id" : 19605368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275402709971120129",
  "text" : "PHL live tweets: flight delayed again, totally awkward penguin near some dudes with @blueboxgrp shirts. Sorry, was gyro-deprived.",
  "id" : 275402709971120129,
  "created_at" : "2012-12-03 00:54:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 83, 93 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275352416914915328",
  "geo" : { },
  "id_str" : "275354556332904449",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden this is like my idea of a food truck that specializes in ice cream \/cc @aquaranto",
  "id" : 275354556332904449,
  "in_reply_to_status_id" : 275352416914915328,
  "created_at" : "2012-12-02 21:43:36 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 6, 14 ],
      "id_str" : "14436348",
      "id" : 14436348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275350151361605632",
  "geo" : { },
  "id_str" : "275350970177843201",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k @adarshp Zero so far. Boom!",
  "id" : 275350970177843201,
  "in_reply_to_status_id" : 275350151361605632,
  "created_at" : "2012-12-02 21:29:21 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275346460910944256",
  "text" : "I love catching filler words when writing. Killed \"seems to X\" with \"Y\" action verb 3 times. It's like refactoring, just less executing.",
  "id" : 275346460910944256,
  "created_at" : "2012-12-02 21:11:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275326316667076608",
  "text" : "YQB live tweets: Deplaned passengers looking in horror as luggage is carted off by dude with no jacket, safety equipment, or badges.",
  "id" : 275326316667076608,
  "created_at" : "2012-12-02 19:51:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275269948350271488",
  "text" : "Stuck in an airport for 6 hours, but we have wifi and a board game. Things could be worse I guess.",
  "id" : 275269948350271488,
  "created_at" : "2012-12-02 16:07:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275264831941120000",
  "text" : "Fuck, flight canceled out of Quebec City. Fuck fuck fuck.",
  "id" : 275264831941120000,
  "created_at" : "2012-12-02 15:47:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
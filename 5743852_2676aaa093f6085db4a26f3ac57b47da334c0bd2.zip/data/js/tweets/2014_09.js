Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517132266209042432",
  "geo" : { },
  "id_str" : "517133946220339200",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller what in the actual fuck",
  "id" : 517133946220339200,
  "in_reply_to_status_id" : 517132266209042432,
  "created_at" : "2014-10-01 02:08:35 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517122343379140608",
  "geo" : { },
  "id_str" : "517123257770573824",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine Starting to like it more and more.",
  "id" : 517123257770573824,
  "in_reply_to_status_id" : 517122343379140608,
  "created_at" : "2014-10-01 01:26:07 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517121798270627840",
  "geo" : { },
  "id_str" : "517122008618774529",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik SUBSCRIBED",
  "id" : 517122008618774529,
  "in_reply_to_status_id" : 517121798270627840,
  "created_at" : "2014-10-01 01:21:09 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 9, 20 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517112758211735552",
  "geo" : { },
  "id_str" : "517113237884526592",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo yo @shellscape any tips?",
  "id" : 517113237884526592,
  "in_reply_to_status_id" : 517112758211735552,
  "created_at" : "2014-10-01 00:46:18 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517104859225812992",
  "geo" : { },
  "id_str" : "517109064770125824",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine yup",
  "id" : 517109064770125824,
  "in_reply_to_status_id" : 517104859225812992,
  "created_at" : "2014-10-01 00:29:43 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 3, 18 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/colindabkowski\/status\/517091182846169089\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Rl7SiGciQz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By0TsLwCUAAni7I.jpg",
      "id_str" : "517091182006915072",
      "id" : 517091182006915072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0TsLwCUAAni7I.jpg",
      "sizes" : [ {
        "h" : 637,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Rl7SiGciQz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/72HR3EaivF",
      "expanded_url" : "http:\/\/buffalo.com\/2014\/09\/30\/news\/art\/public-art-meets-advertising-riffs-labatt-blue-silos\/",
      "display_url" : "buffalo.com\/2014\/09\/30\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517092682967941120",
  "text" : "RT @colindabkowski: Branded buildings in Buffalo, now with 100 percent more Genny: http:\/\/t.co\/72HR3EaivF http:\/\/t.co\/Rl7SiGciQz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/colindabkowski\/status\/517091182846169089\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/Rl7SiGciQz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By0TsLwCUAAni7I.jpg",
        "id_str" : "517091182006915072",
        "id" : 517091182006915072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0TsLwCUAAni7I.jpg",
        "sizes" : [ {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Rl7SiGciQz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/72HR3EaivF",
        "expanded_url" : "http:\/\/buffalo.com\/2014\/09\/30\/news\/art\/public-art-meets-advertising-riffs-labatt-blue-silos\/",
        "display_url" : "buffalo.com\/2014\/09\/30\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517091182846169089",
    "text" : "Branded buildings in Buffalo, now with 100 percent more Genny: http:\/\/t.co\/72HR3EaivF http:\/\/t.co\/Rl7SiGciQz",
    "id" : 517091182846169089,
    "created_at" : "2014-09-30 23:18:39 +0000",
    "user" : {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "protected" : false,
      "id_str" : "18777886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3037884795\/352233dadcadefd39ba870c00adc3091_normal.jpeg",
      "id" : 18777886,
      "verified" : false
    }
  },
  "id" : 517092682967941120,
  "created_at" : "2014-09-30 23:24:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "indices" : [ 3, 16 ],
      "id_str" : "896641",
      "id" : 896641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/I5vEGbLENz",
      "expanded_url" : "http:\/\/usecases.responsiveimages.org\/#h2_use-cases",
      "display_url" : "usecases.responsiveimages.org\/#h2_use-cases"
    } ]
  },
  "geo" : { },
  "id_str" : "517088265094967296",
  "text" : "RT @jasonzimdars: You guys, this stuff just isn't getting any easier: http:\/\/t.co\/I5vEGbLENz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/I5vEGbLENz",
        "expanded_url" : "http:\/\/usecases.responsiveimages.org\/#h2_use-cases",
        "display_url" : "usecases.responsiveimages.org\/#h2_use-cases"
      } ]
    },
    "geo" : { },
    "id_str" : "517086538207739904",
    "text" : "You guys, this stuff just isn't getting any easier: http:\/\/t.co\/I5vEGbLENz",
    "id" : 517086538207739904,
    "created_at" : "2014-09-30 23:00:12 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 517088265094967296,
  "created_at" : "2014-09-30 23:07:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/517080355010920448\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ox8gb63tcy",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/By0J1vTCUAAiI7g.png",
      "id_str" : "517080351051501568",
      "id" : 517080351051501568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/By0J1vTCUAAiI7g.png",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/ox8gb63tcy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517080355010920448",
  "text" : "Reddit is starting a cryptocurrency? http:\/\/t.co\/ox8gb63tcy",
  "id" : 517080355010920448,
  "created_at" : "2014-09-30 22:35:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517077838454071297",
  "geo" : { },
  "id_str" : "517078101549793280",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda Horde +1",
  "id" : 517078101549793280,
  "in_reply_to_status_id" : 517077838454071297,
  "created_at" : "2014-09-30 22:26:40 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 17, 26 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517055733528285184",
  "geo" : { },
  "id_str" : "517066868511608832",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox it's all @shildner's fault",
  "id" : 517066868511608832,
  "in_reply_to_status_id" : 517055733528285184,
  "created_at" : "2014-09-30 21:42:02 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/517060403676061697\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/tz0PyaTZgG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Byz3sexIgAAQysp.png",
      "id_str" : "517060400786210816",
      "id" : 517060400786210816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byz3sexIgAAQysp.png",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/tz0PyaTZgG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517060403676061697",
  "text" : "Siri: still useless http:\/\/t.co\/tz0PyaTZgG",
  "id" : 517060403676061697,
  "created_at" : "2014-09-30 21:16:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Traitify",
      "screen_name" : "traitify",
      "indices" : [ 3, 12 ],
      "id_str" : "272983344",
      "id" : 272983344
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 40, 55 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Johnny Winn",
      "screen_name" : "johnny_rugger",
      "indices" : [ 88, 102 ],
      "id_str" : "463158848",
      "id" : 463158848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517049013829238784",
  "text" : "RT @traitify: Proud to be a sponsor for @nickelcityruby this week! Look out for our own @johnny_rugger if you see him there! #ncrc14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 26, 41 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Johnny Winn",
        "screen_name" : "johnny_rugger",
        "indices" : [ 74, 88 ],
        "id_str" : "463158848",
        "id" : 463158848
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516996627727671296",
    "text" : "Proud to be a sponsor for @nickelcityruby this week! Look out for our own @johnny_rugger if you see him there! #ncrc14",
    "id" : 516996627727671296,
    "created_at" : "2014-09-30 17:02:56 +0000",
    "user" : {
      "name" : "Traitify",
      "screen_name" : "traitify",
      "protected" : false,
      "id_str" : "272983344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527955196895174656\/46ttkggy_normal.png",
      "id" : 272983344,
      "verified" : false
    }
  },
  "id" : 517049013829238784,
  "created_at" : "2014-09-30 20:31:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    }, {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 13, 22 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517048722341916672",
  "geo" : { },
  "id_str" : "517048964512641025",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac @borncamp yay for being alive",
  "id" : 517048964512641025,
  "in_reply_to_status_id" : 517048722341916672,
  "created_at" : "2014-09-30 20:30:54 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Krush",
      "screen_name" : "TomKrush",
      "indices" : [ 0, 9 ],
      "id_str" : "13235662",
      "id" : 13235662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517034440237670401",
  "geo" : { },
  "id_str" : "517034772191641601",
  "in_reply_to_user_id" : 13235662,
  "text" : "@TomKrush yep, working on that for iPad first. Hopefully will be out soon.",
  "id" : 517034772191641601,
  "in_reply_to_status_id" : 517034440237670401,
  "created_at" : "2014-09-30 19:34:30 +0000",
  "in_reply_to_screen_name" : "TomKrush",
  "in_reply_to_user_id_str" : "13235662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Sullivan",
      "screen_name" : "stubbornella",
      "indices" : [ 3, 16 ],
      "id_str" : "15629200",
      "id" : 15629200
    }, {
      "name" : "Hacker News",
      "screen_name" : "newsycombinator",
      "indices" : [ 47, 63 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/IfF84Y7djZ",
      "expanded_url" : "http:\/\/danilocampos.com\/2014\/09\/y-combinator-and-the-negative-externalities-of-hacker-news\/",
      "display_url" : "danilocampos.com\/2014\/09\/y-comb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517029449473069056",
  "text" : "RT @stubbornella: Yes! When I get linked to on @newsycombinator I feel sick because I know the trolls are coming. They should fix this. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hacker News",
        "screen_name" : "newsycombinator",
        "indices" : [ 29, 45 ],
        "id_str" : "14335498",
        "id" : 14335498
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/IfF84Y7djZ",
        "expanded_url" : "http:\/\/danilocampos.com\/2014\/09\/y-combinator-and-the-negative-externalities-of-hacker-news\/",
        "display_url" : "danilocampos.com\/2014\/09\/y-comb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517024321483833346",
    "text" : "Yes! When I get linked to on @newsycombinator I feel sick because I know the trolls are coming. They should fix this. http:\/\/t.co\/IfF84Y7djZ",
    "id" : 517024321483833346,
    "created_at" : "2014-09-30 18:52:58 +0000",
    "user" : {
      "name" : "Nicole Sullivan",
      "screen_name" : "stubbornella",
      "protected" : false,
      "id_str" : "15629200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430574860146720768\/Yhs4a60S_normal.jpeg",
      "id" : 15629200,
      "verified" : false
    }
  },
  "id" : 517029449473069056,
  "created_at" : "2014-09-30 19:13:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516948073566588928",
  "geo" : { },
  "id_str" : "517028240192311296",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove Duvel. And any waffle from a van.",
  "id" : 517028240192311296,
  "in_reply_to_status_id" : 516948073566588928,
  "created_at" : "2014-09-30 19:08:33 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/RrsINrgWpz",
      "expanded_url" : "https:\/\/appsto.re\/us\/vsITJ.i",
      "display_url" : "appsto.re\/us\/vsITJ.i"
    } ]
  },
  "geo" : { },
  "id_str" : "517027145487355904",
  "text" : "Basecamp for iPhone supports 6\/6+ now! Also we had a bit of fun with the App Preview: https:\/\/t.co\/RrsINrgWpz",
  "id" : 517027145487355904,
  "created_at" : "2014-09-30 19:04:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Cooke",
      "screen_name" : "nicoleeecooke",
      "indices" : [ 0, 14 ],
      "id_str" : "2247865412",
      "id" : 2247865412
    }, {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 15, 30 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517024414249259009",
  "geo" : { },
  "id_str" : "517024642490306560",
  "in_reply_to_user_id" : 2247865412,
  "text" : "@nicoleeecooke @colindabkowski what a great way to preserve our historic buildings, too",
  "id" : 517024642490306560,
  "in_reply_to_status_id" : 517024414249259009,
  "created_at" : "2014-09-30 18:54:15 +0000",
  "in_reply_to_screen_name" : "nicoleeecooke",
  "in_reply_to_user_id_str" : "2247865412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tori BreadHive",
      "screen_name" : "ToriBreadHive",
      "indices" : [ 0, 14 ],
      "id_str" : "1945549338",
      "id" : 1945549338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517020409552982016",
  "geo" : { },
  "id_str" : "517020643993587713",
  "in_reply_to_user_id" : 1945549338,
  "text" : "@ToriBreadHive if it's left by around 4-5pm i will take it!",
  "id" : 517020643993587713,
  "in_reply_to_status_id" : 517020409552982016,
  "created_at" : "2014-09-30 18:38:21 +0000",
  "in_reply_to_screen_name" : "ToriBreadHive",
  "in_reply_to_user_id_str" : "1945549338",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "James D. Roberts",
      "screen_name" : "jdrcec",
      "indices" : [ 34, 41 ],
      "id_str" : "516593457",
      "id" : 516593457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/zqJL6J3MBg",
      "expanded_url" : "http:\/\/buffalo.com\/2014\/09\/30\/featured\/influential-chef-opening-toutant-next-seabar\/",
      "display_url" : "buffalo.com\/2014\/09\/30\/fea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517014225689280514",
  "text" : "RT @coworkbuffalo: James Roberts (@jdrcec) adding to the very nice food options near our space this winter: http:\/\/t.co\/zqJL6J3MBg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James D. Roberts",
        "screen_name" : "jdrcec",
        "indices" : [ 15, 22 ],
        "id_str" : "516593457",
        "id" : 516593457
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/zqJL6J3MBg",
        "expanded_url" : "http:\/\/buffalo.com\/2014\/09\/30\/featured\/influential-chef-opening-toutant-next-seabar\/",
        "display_url" : "buffalo.com\/2014\/09\/30\/fea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517013602986115072",
    "text" : "James Roberts (@jdrcec) adding to the very nice food options near our space this winter: http:\/\/t.co\/zqJL6J3MBg",
    "id" : 517013602986115072,
    "created_at" : "2014-09-30 18:10:23 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 517014225689280514,
  "created_at" : "2014-09-30 18:12:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516996788432437248",
  "geo" : { },
  "id_str" : "516998659573968897",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv straight tookin 3 starrin Liam Neesons",
  "id" : 516998659573968897,
  "in_reply_to_status_id" : 516996788432437248,
  "created_at" : "2014-09-30 17:11:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyle Troxell",
      "screen_name" : "lyle",
      "indices" : [ 3, 8 ],
      "id_str" : "776168",
      "id" : 776168
    }, {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "indices" : [ 121, 126 ],
      "id_str" : "6603532",
      "id" : 6603532
    }, {
      "name" : "!!Con",
      "screen_name" : "bangbangcon",
      "indices" : [ 127, 139 ],
      "id_str" : "2342590440",
      "id" : 2342590440
    }, {
      "name" : "Lindsey Kuper",
      "screen_name" : "lindsey",
      "indices" : [ 139, 140 ],
      "id_str" : "11033",
      "id" : 11033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/b0rk\/status\/516412676583718912\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/VtVyGo56x6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Byqql6LIYAAD_jP.jpg",
      "id_str" : "516412675535167488",
      "id" : 516412675535167488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byqql6LIYAAD_jP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 915
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 915
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VtVyGo56x6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516996500434345984",
  "text" : "RT @lyle: I'm doing this for my next event to make it clear who's comfortable being photographed: http:\/\/t.co\/VtVyGo56x6 @b0rk @bangbangcon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julia Evans",
        "screen_name" : "b0rk",
        "indices" : [ 111, 116 ],
        "id_str" : "6603532",
        "id" : 6603532
      }, {
        "name" : "!!Con",
        "screen_name" : "bangbangcon",
        "indices" : [ 117, 129 ],
        "id_str" : "2342590440",
        "id" : 2342590440
      }, {
        "name" : "Lindsey Kuper",
        "screen_name" : "lindsey",
        "indices" : [ 130, 138 ],
        "id_str" : "11033",
        "id" : 11033
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/b0rk\/status\/516412676583718912\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/VtVyGo56x6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Byqql6LIYAAD_jP.jpg",
        "id_str" : "516412675535167488",
        "id" : 516412675535167488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byqql6LIYAAD_jP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 515,
          "resize" : "fit",
          "w" : 915
        }, {
          "h" : 515,
          "resize" : "fit",
          "w" : 915
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/VtVyGo56x6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "516412676583718912",
    "geo" : { },
    "id_str" : "516988652749324289",
    "in_reply_to_user_id" : 6603532,
    "text" : "I'm doing this for my next event to make it clear who's comfortable being photographed: http:\/\/t.co\/VtVyGo56x6 @b0rk @bangbangcon @lindsey",
    "id" : 516988652749324289,
    "in_reply_to_status_id" : 516412676583718912,
    "created_at" : "2014-09-30 16:31:14 +0000",
    "in_reply_to_screen_name" : "b0rk",
    "in_reply_to_user_id_str" : "6603532",
    "user" : {
      "name" : "Lyle Troxell",
      "screen_name" : "lyle",
      "protected" : false,
      "id_str" : "776168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/278589780\/Lyle_Photo_373_bw_normal.jpg",
      "id" : 776168,
      "verified" : false
    }
  },
  "id" : 516996500434345984,
  "created_at" : "2014-09-30 17:02:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516990616677679104",
  "geo" : { },
  "id_str" : "516996251078762496",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil your avatar is not a horse",
  "id" : 516996251078762496,
  "in_reply_to_status_id" : 516990616677679104,
  "created_at" : "2014-09-30 17:01:26 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/uZPdTAcW0b",
      "expanded_url" : "https:\/\/twitter.com\/satobuffalo\/status\/516981485921132544",
      "display_url" : "twitter.com\/satobuffalo\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516988135365148672",
  "text" : "Of interest to any early @nickelcityruby attendees: https:\/\/t.co\/uZPdTAcW0b",
  "id" : 516988135365148672,
  "created_at" : "2014-09-30 16:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Cheal",
      "screen_name" : "juliancheal",
      "indices" : [ 3, 15 ],
      "id_str" : "951511",
      "id" : 951511
    }, {
      "name" : "NeuroSky",
      "screen_name" : "NeuroSky",
      "indices" : [ 67, 76 ],
      "id_str" : "50032327",
      "id" : 50032327
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 123, 138 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Boston",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516987932960653312",
  "text" : "RT @juliancheal: Do I know anyone in #Boston of #Buffalo who has a @NeuroSky Neurosky Mindwave I can borrow for my talk at @nickelcityruby?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NeuroSky",
        "screen_name" : "NeuroSky",
        "indices" : [ 50, 59 ],
        "id_str" : "50032327",
        "id" : 50032327
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 106, 121 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Boston",
        "indices" : [ 20, 27 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516763672027623424",
    "text" : "Do I know anyone in #Boston of #Buffalo who has a @NeuroSky Neurosky Mindwave I can borrow for my talk at @nickelcityruby?",
    "id" : 516763672027623424,
    "created_at" : "2014-09-30 01:37:15 +0000",
    "user" : {
      "name" : "Julian Cheal",
      "screen_name" : "juliancheal",
      "protected" : false,
      "id_str" : "951511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422007171\/IMG_0617_normal.JPG",
      "id" : 951511,
      "verified" : false
    }
  },
  "id" : 516987932960653312,
  "created_at" : "2014-09-30 16:28:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yoder",
      "screen_name" : "doug_yoder",
      "indices" : [ 3, 14 ],
      "id_str" : "14680570",
      "id" : 14680570
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 43, 58 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516987916770607104",
  "text" : "RT @doug_yoder: Any NE Ohio folks going to @nickelcityruby this weekend?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 27, 42 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516780518571257856",
    "text" : "Any NE Ohio folks going to @nickelcityruby this weekend?",
    "id" : 516780518571257856,
    "created_at" : "2014-09-30 02:44:11 +0000",
    "user" : {
      "name" : "Doug Yoder",
      "screen_name" : "doug_yoder",
      "protected" : false,
      "id_str" : "14680570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426210551124217856\/RWKWZxPn_normal.jpeg",
      "id" : 14680570,
      "verified" : false
    }
  },
  "id" : 516987916770607104,
  "created_at" : "2014-09-30 16:28:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516987107035058176",
  "geo" : { },
  "id_str" : "516987723778109440",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil I think you\u2019ve turned into a Markov chain bot",
  "id" : 516987723778109440,
  "in_reply_to_status_id" : 516987107035058176,
  "created_at" : "2014-09-30 16:27:33 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 51, 61 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516975504906153984",
  "text" : "RT @themcgruff: Many of the mothers and fathers at @37signals hang out in our \"All Parent's\" Campfire and celebrate, commiserate and share \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 35, 45 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516974165531066368",
    "text" : "Many of the mothers and fathers at @37signals hang out in our \"All Parent's\" Campfire and celebrate, commiserate and share tips daily.",
    "id" : 516974165531066368,
    "created_at" : "2014-09-30 15:33:40 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 516975504906153984,
  "created_at" : "2014-09-30 15:39:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OnThisDay & Facts",
      "screen_name" : "NotableHistory",
      "indices" : [ 0, 15 ],
      "id_str" : "844766941",
      "id" : 844766941
    }, {
      "name" : "Josh Robinson",
      "screen_name" : "robins36",
      "indices" : [ 16, 25 ],
      "id_str" : "310290717",
      "id" : 310290717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/RY9mTDbQHJ",
      "expanded_url" : "http:\/\/www.redbubble.com\/people\/sannadullaway\/works\/12721913-niagara-street-buffalo-1908",
      "display_url" : "redbubble.com\/people\/sannadu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "516754366011678721",
  "geo" : { },
  "id_str" : "516961524074557440",
  "in_reply_to_user_id" : 844766941,
  "text" : "@NotableHistory @robins36 might be nice to actually link the source http:\/\/t.co\/RY9mTDbQHJ",
  "id" : 516961524074557440,
  "in_reply_to_status_id" : 516754366011678721,
  "created_at" : "2014-09-30 14:43:26 +0000",
  "in_reply_to_screen_name" : "NotableHistory",
  "in_reply_to_user_id_str" : "844766941",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Buchek",
      "screen_name" : "CraigBuchek",
      "indices" : [ 0, 12 ],
      "id_str" : "29504430",
      "id" : 29504430
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 13, 23 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 24, 39 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516938193287933952",
  "geo" : { },
  "id_str" : "516945017785430017",
  "in_reply_to_user_id" : 29504430,
  "text" : "@CraigBuchek @aspleenic @nickelcityruby well aware ;) We took a contingent last year after the conference and I suspect we'll do the same",
  "id" : 516945017785430017,
  "in_reply_to_status_id" : 516938193287933952,
  "created_at" : "2014-09-30 13:37:51 +0000",
  "in_reply_to_screen_name" : "CraigBuchek",
  "in_reply_to_user_id_str" : "29504430",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 136, 140 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516930551031144448",
  "text" : "RT @aspleenic: Pro tip: if you are coming to #ncrc14 and plan to see Niagara Falls and Canada - BRING YOUR PASSPORT :)\nThanks,\nPeej\nCc: @ni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 121, 136 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516782165606940672",
    "text" : "Pro tip: if you are coming to #ncrc14 and plan to see Niagara Falls and Canada - BRING YOUR PASSPORT :)\nThanks,\nPeej\nCc: @nickelcityruby",
    "id" : 516782165606940672,
    "created_at" : "2014-09-30 02:50:44 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 516930551031144448,
  "created_at" : "2014-09-30 12:40:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Yerhot",
      "screen_name" : "yerhot",
      "indices" : [ 3, 10 ],
      "id_str" : "12341642",
      "id" : 12341642
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 92, 107 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516930541380042752",
  "text" : "RT @yerhot: So yeah.  I'm beyond stoked to meet some new rad peeps &amp; see old friends at @nickelcityruby this year.  Come find me to talk gi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 80, 95 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516820420247310336",
    "text" : "So yeah.  I'm beyond stoked to meet some new rad peeps &amp; see old friends at @nickelcityruby this year.  Come find me to talk git &amp; unicorns.",
    "id" : 516820420247310336,
    "created_at" : "2014-09-30 05:22:44 +0000",
    "user" : {
      "name" : "John Yerhot",
      "screen_name" : "yerhot",
      "protected" : false,
      "id_str" : "12341642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566714211850391552\/U4c8udGZ_normal.jpeg",
      "id" : 12341642,
      "verified" : false
    }
  },
  "id" : 516930541380042752,
  "created_at" : "2014-09-30 12:40:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "indices" : [ 3, 17 ],
      "id_str" : "487600344",
      "id" : 487600344
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Bipartisanism\/status\/510221796067401729\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/WvEESA8PES",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
      "id_str" : "510221795660537856",
      "id" : 510221795660537856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WvEESA8PES"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516918357279264768",
  "text" : "RT @Bipartisanism: If roads were like bike lanes. http:\/\/t.co\/WvEESA8PES",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Bipartisanism\/status\/510221796067401729\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/WvEESA8PES",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
        "id_str" : "510221795660537856",
        "id" : 510221795660537856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/WvEESA8PES"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510221796067401729",
    "text" : "If roads were like bike lanes. http:\/\/t.co\/WvEESA8PES",
    "id" : 510221796067401729,
    "created_at" : "2014-09-12 00:22:10 +0000",
    "user" : {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "protected" : false,
      "id_str" : "487600344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815330356\/sampson_normal.png",
      "id" : 487600344,
      "verified" : false
    }
  },
  "id" : 516918357279264768,
  "created_at" : "2014-09-30 11:51:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/516761642395119616\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/Kj1QjzvcJF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Byvn-ZBCcAAbty5.png",
      "id_str" : "516761641317199872",
      "id" : 516761641317199872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byvn-ZBCcAAbty5.png",
      "sizes" : [ {
        "h" : 160,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 1208
      } ],
      "display_url" : "pic.twitter.com\/Kj1QjzvcJF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516761642395119616",
  "text" : "A+ twitter marketing http:\/\/t.co\/Kj1QjzvcJF",
  "id" : 516761642395119616,
  "created_at" : "2014-09-30 01:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNYmedia Network",
      "screen_name" : "wnymedia",
      "indices" : [ 3, 12 ],
      "id_str" : "9106882",
      "id" : 9106882
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 114, 122 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/tOhu64V5Bj",
      "expanded_url" : "http:\/\/youtu.be\/dmESqfvqZow?a",
      "display_url" : "youtu.be\/dmESqfvqZow?a"
    } ]
  },
  "geo" : { },
  "id_str" : "516731805701902336",
  "text" : "RT @wnymedia: Everyone Orchestra @ The Waiting Room (feat. Mike Gantzer from Aqueous): http:\/\/t.co\/tOhu64V5Bj via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 100, 108 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/tOhu64V5Bj",
        "expanded_url" : "http:\/\/youtu.be\/dmESqfvqZow?a",
        "display_url" : "youtu.be\/dmESqfvqZow?a"
      } ]
    },
    "geo" : { },
    "id_str" : "516668633854918656",
    "text" : "Everyone Orchestra @ The Waiting Room (feat. Mike Gantzer from Aqueous): http:\/\/t.co\/tOhu64V5Bj via @YouTube",
    "id" : 516668633854918656,
    "created_at" : "2014-09-29 19:19:36 +0000",
    "user" : {
      "name" : "WNYmedia Network",
      "screen_name" : "wnymedia",
      "protected" : false,
      "id_str" : "9106882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522539886780645376\/5XGVsPob_normal.jpeg",
      "id" : 9106882,
      "verified" : false
    }
  },
  "id" : 516731805701902336,
  "created_at" : "2014-09-29 23:30:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 88, 103 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516675210121322497",
  "geo" : { },
  "id_str" : "516675618801328128",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd is that the special all week? Because you better bring extra on Friday for @nickelcityruby",
  "id" : 516675618801328128,
  "in_reply_to_status_id" : 516675210121322497,
  "created_at" : "2014-09-29 19:47:21 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516675007284379649",
  "geo" : { },
  "id_str" : "516675319311253505",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule \uD83D\uDD12\uD83D\uDC4D",
  "id" : 516675319311253505,
  "in_reply_to_status_id" : 516675007284379649,
  "created_at" : "2014-09-29 19:46:10 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Vormwald",
      "screen_name" : "vormwald",
      "indices" : [ 3, 12 ],
      "id_str" : "215800334",
      "id" : 215800334
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516674839927472128",
  "text" : "RT @vormwald: Pretty excited for @nickelcityruby this week. *Easily* my favorite UpstateNY Ruby conference! #ncrc14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516659605058113536",
    "text" : "Pretty excited for @nickelcityruby this week. *Easily* my favorite UpstateNY Ruby conference! #ncrc14",
    "id" : 516659605058113536,
    "created_at" : "2014-09-29 18:43:43 +0000",
    "user" : {
      "name" : "Mike Vormwald",
      "screen_name" : "vormwald",
      "protected" : false,
      "id_str" : "215800334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501942122531266560\/Z2mGzuuN_normal.jpeg",
      "id" : 215800334,
      "verified" : false
    }
  },
  "id" : 516674839927472128,
  "created_at" : "2014-09-29 19:44:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516674658666827776",
  "geo" : { },
  "id_str" : "516674778325725184",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule so you wouldn\u2019t recommend? Was hoping to try it out soon",
  "id" : 516674778325725184,
  "in_reply_to_status_id" : 516674658666827776,
  "created_at" : "2014-09-29 19:44:01 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516670352580435968",
  "geo" : { },
  "id_str" : "516671092371771392",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden subscribed, i'll cohost. I'll say \"Really?\"",
  "id" : 516671092371771392,
  "in_reply_to_status_id" : 516670352580435968,
  "created_at" : "2014-09-29 19:29:22 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Gorbach",
      "screen_name" : "mgorbach",
      "indices" : [ 0, 9 ],
      "id_str" : "5729122",
      "id" : 5729122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516632731389034496",
  "geo" : { },
  "id_str" : "516657048033845248",
  "in_reply_to_user_id" : 5729122,
  "text" : "@mgorbach we decided to dig into the platform more and really learn it. It wasn\u2019t really going back, but forward.",
  "id" : 516657048033845248,
  "in_reply_to_status_id" : 516632731389034496,
  "created_at" : "2014-09-29 18:33:33 +0000",
  "in_reply_to_screen_name" : "mgorbach",
  "in_reply_to_user_id_str" : "5729122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Probably Corey",
      "screen_name" : "probablycorey",
      "indices" : [ 3, 17 ],
      "id_str" : "1656101",
      "id" : 1656101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516624752215998467",
  "text" : "RT @probablycorey: Child: Do not try and force the nap. That's impossible. Instead... only try to realize the truth.\nMe: What truth?\nChild:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516614425025843200",
    "text" : "Child: Do not try and force the nap. That's impossible. Instead... only try to realize the truth.\nMe: What truth?\nChild: There is no nap.",
    "id" : 516614425025843200,
    "created_at" : "2014-09-29 15:44:11 +0000",
    "user" : {
      "name" : "Probably Corey",
      "screen_name" : "probablycorey",
      "protected" : false,
      "id_str" : "1656101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200175886\/hotdog_normal.png",
      "id" : 1656101,
      "verified" : false
    }
  },
  "id" : 516624752215998467,
  "created_at" : "2014-09-29 16:25:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omer Shapira",
      "screen_name" : "omershapira",
      "indices" : [ 3, 15 ],
      "id_str" : "55855791",
      "id" : 55855791
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/omershapira\/status\/512577588662136832\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/t63hWL52pt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx0KmaUIMAARbLk.png",
      "id_str" : "512577587605155840",
      "id" : 512577587605155840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx0KmaUIMAARbLk.png",
      "sizes" : [ {
        "h" : 305,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/t63hWL52pt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516621156565000192",
  "text" : "RT @omershapira: Had a dream about HN. Woke up and tried to write down all the details: http:\/\/t.co\/t63hWL52pt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/omershapira\/status\/512577588662136832\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/t63hWL52pt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx0KmaUIMAARbLk.png",
        "id_str" : "512577587605155840",
        "id" : 512577587605155840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx0KmaUIMAARbLk.png",
        "sizes" : [ {
          "h" : 305,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/t63hWL52pt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512577588662136832",
    "text" : "Had a dream about HN. Woke up and tried to write down all the details: http:\/\/t.co\/t63hWL52pt",
    "id" : 512577588662136832,
    "created_at" : "2014-09-18 12:23:15 +0000",
    "user" : {
      "name" : "Omer Shapira",
      "screen_name" : "omershapira",
      "protected" : false,
      "id_str" : "55855791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1890064313\/oie_121542TV9Q0Cxb_normal.gif",
      "id" : 55855791,
      "verified" : false
    }
  },
  "id" : 516621156565000192,
  "created_at" : "2014-09-29 16:10:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516609521247338496",
  "geo" : { },
  "id_str" : "516610671492882434",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek oh nice!",
  "id" : 516610671492882434,
  "in_reply_to_status_id" : 516609521247338496,
  "created_at" : "2014-09-29 15:29:16 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 3, 9 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516606353331068928",
  "text" : "RT @ahuj9: Why did you sign up for Ello?\nUsername squatting\/reservation: 85%\nPranks and crimes: 14%\nNeed a new medium to organize militia: \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516604837891276801",
    "text" : "Why did you sign up for Ello?\nUsername squatting\/reservation: 85%\nPranks and crimes: 14%\nNeed a new medium to organize militia: 1%",
    "id" : 516604837891276801,
    "created_at" : "2014-09-29 15:06:06 +0000",
    "user" : {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "protected" : false,
      "id_str" : "205281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2438738477\/m3tcrt9kvs9x0ff84b31_normal.jpeg",
      "id" : 205281746,
      "verified" : false
    }
  },
  "id" : 516606353331068928,
  "created_at" : "2014-09-29 15:12:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Long Nguyen",
      "screen_name" : "lnguyen11288",
      "indices" : [ 3, 16 ],
      "id_str" : "158124243",
      "id" : 158124243
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 40, 55 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516602151754162176",
  "text" : "RT @lnguyen11288: Less then a week till @nickelcityruby. I'm pumped!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 22, 37 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516579257594560512",
    "text" : "Less then a week till @nickelcityruby. I'm pumped!",
    "id" : 516579257594560512,
    "created_at" : "2014-09-29 13:24:27 +0000",
    "user" : {
      "name" : "Long Nguyen",
      "screen_name" : "lnguyen11288",
      "protected" : false,
      "id_str" : "158124243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474603137198616577\/JxeYJx1v_normal.jpeg",
      "id" : 158124243,
      "verified" : false
    }
  },
  "id" : 516602151754162176,
  "created_at" : "2014-09-29 14:55:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Jacobel",
      "screen_name" : "bjacobel",
      "indices" : [ 0, 9 ],
      "id_str" : "15299776",
      "id" : 15299776
    }, {
      "name" : "Michael Gorbach",
      "screen_name" : "mgorbach",
      "indices" : [ 10, 19 ],
      "id_str" : "5729122",
      "id" : 5729122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516587747524771840",
  "geo" : { },
  "id_str" : "516596906181398528",
  "in_reply_to_user_id" : 15299776,
  "text" : "@bjacobel @mgorbach thanks :) iPhone's in RM, iPad is straight ObjC. Still learning a ton.",
  "id" : 516596906181398528,
  "in_reply_to_status_id" : 516587747524771840,
  "created_at" : "2014-09-29 14:34:35 +0000",
  "in_reply_to_screen_name" : "bjacobel",
  "in_reply_to_user_id_str" : "15299776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriesse",
      "screen_name" : "kriesse",
      "indices" : [ 3, 11 ],
      "id_str" : "11531602",
      "id" : 11531602
    }, {
      "name" : "Caroline Drucker",
      "screen_name" : "Bougie",
      "indices" : [ 54, 61 ],
      "id_str" : "14275478",
      "id" : 14275478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/NPiYGPmgV9",
      "expanded_url" : "https:\/\/medium.com\/@bougie\/how-to-host-speakers-who-also-happen-to-be-parents-of-young-children-41fa98bd3ae7",
      "display_url" : "medium.com\/@bougie\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516595264660860928",
  "text" : "RT @kriesse: Conference organizers: Excellent post by @bougie about hosting speakers who are parents of young children, read it: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caroline Drucker",
        "screen_name" : "Bougie",
        "indices" : [ 41, 48 ],
        "id_str" : "14275478",
        "id" : 14275478
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/NPiYGPmgV9",
        "expanded_url" : "https:\/\/medium.com\/@bougie\/how-to-host-speakers-who-also-happen-to-be-parents-of-young-children-41fa98bd3ae7",
        "display_url" : "medium.com\/@bougie\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516468788402089984",
    "text" : "Conference organizers: Excellent post by @bougie about hosting speakers who are parents of young children, read it: https:\/\/t.co\/NPiYGPmgV9",
    "id" : 516468788402089984,
    "created_at" : "2014-09-29 06:05:29 +0000",
    "user" : {
      "name" : "Kriesse",
      "screen_name" : "kriesse",
      "protected" : false,
      "id_str" : "11531602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2434737160\/08j2rc24c3ygq5mtwnwf_normal.jpeg",
      "id" : 11531602,
      "verified" : false
    }
  },
  "id" : 516595264660860928,
  "created_at" : "2014-09-29 14:28:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 13, 25 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516593369255268354",
  "geo" : { },
  "id_str" : "516594177274966018",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @jamesgolick am I living under a rock? Why is that a bad thing?",
  "id" : 516594177274966018,
  "in_reply_to_status_id" : 516593369255268354,
  "created_at" : "2014-09-29 14:23:44 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 13, 25 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516592195483480064",
  "geo" : { },
  "id_str" : "516592643682217984",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick @coreyhaines so where did it fall apart? because it hasn't really for us yet. curious.",
  "id" : 516592643682217984,
  "in_reply_to_status_id" : 516592195483480064,
  "created_at" : "2014-09-29 14:17:38 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 13, 25 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516589374876950529",
  "geo" : { },
  "id_str" : "516591977849032706",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @jamesgolick have either of you tried this in an actual app in practice?",
  "id" : 516591977849032706,
  "in_reply_to_status_id" : 516589374876950529,
  "created_at" : "2014-09-29 14:14:59 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 13, 25 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516589374876950529",
  "geo" : { },
  "id_str" : "516589648999489536",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @jamesgolick yeah they're no excuse for actual design, but they're nice in small doses. like anything else, can be abused",
  "id" : 516589648999489536,
  "in_reply_to_status_id" : 516589374876950529,
  "created_at" : "2014-09-29 14:05:44 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516588756380684288",
  "geo" : { },
  "id_str" : "516588999557668866",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick what's unfortunate?",
  "id" : 516588999557668866,
  "in_reply_to_status_id" : 516588756380684288,
  "created_at" : "2014-09-29 14:03:09 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 5, 20 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/516586909343023104\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/aBHfnbdzqz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BytJDcQCEAAv7mb.png",
      "id_str" : "516586905735925760",
      "id" : 516586905735925760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BytJDcQCEAAv7mb.png",
      "sizes" : [ {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/aBHfnbdzqz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516586909343023104",
  "text" : "It's @nickelcityruby week!!! http:\/\/t.co\/aBHfnbdzqz",
  "id" : 516586909343023104,
  "created_at" : "2014-09-29 13:54:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/EqmNrg2PSQ",
      "expanded_url" : "http:\/\/www.buffalobeerweek.com\/",
      "display_url" : "buffalobeerweek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "516575047960764416",
  "text" : "Great news for @nickelcityruby attendees: it\u2019s Buffalo Beer Week! http:\/\/t.co\/EqmNrg2PSQ",
  "id" : 516575047960764416,
  "created_at" : "2014-09-29 13:07:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516438127603621888",
  "geo" : { },
  "id_str" : "516438351621025793",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant oof. iTunes sounds buuusted. Sure you\u2019re on the latest of that too? Also aren\u2019t you on 10.10?",
  "id" : 516438351621025793,
  "in_reply_to_status_id" : 516438127603621888,
  "created_at" : "2014-09-29 04:04:32 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516436987633762304",
  "geo" : { },
  "id_str" : "516437594612039680",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant iTunes has a factory restore when you plug it in. Also I think there is one on the device too",
  "id" : 516437594612039680,
  "in_reply_to_status_id" : 516436987633762304,
  "created_at" : "2014-09-29 04:01:32 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 0, 12 ],
      "id_str" : "15686931",
      "id" : 15686931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516371794283200513",
  "geo" : { },
  "id_str" : "516379767143034881",
  "in_reply_to_user_id" : 15686931,
  "text" : "@chris_joyce yeah I was counting the DLC",
  "id" : 516379767143034881,
  "in_reply_to_status_id" : 516371794283200513,
  "created_at" : "2014-09-29 00:11:45 +0000",
  "in_reply_to_screen_name" : "chris_joyce",
  "in_reply_to_user_id_str" : "15686931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 0, 12 ],
      "id_str" : "15686931",
      "id" : 15686931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516363174715871232",
  "geo" : { },
  "id_str" : "516371000141701120",
  "in_reply_to_user_id" : 15686931,
  "text" : "@chris_joyce yeah maybe once there is a sale. $80+ for one game is a lot",
  "id" : 516371000141701120,
  "in_reply_to_status_id" : 516363174715871232,
  "created_at" : "2014-09-28 23:36:54 +0000",
  "in_reply_to_screen_name" : "chris_joyce",
  "in_reply_to_user_id_str" : "15686931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "towski",
      "screen_name" : "towski",
      "indices" : [ 0, 7 ],
      "id_str" : "10188202",
      "id" : 10188202
    }, {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 39, 51 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    }, {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 52, 62 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516332511039721472",
  "geo" : { },
  "id_str" : "516332715570786304",
  "in_reply_to_user_id" : 10188202,
  "text" : "@towski oh wow. Should be awesome! \/cc @john_floren @kleptomik",
  "id" : 516332715570786304,
  "in_reply_to_status_id" : 516332511039721472,
  "created_at" : "2014-09-28 21:04:47 +0000",
  "in_reply_to_screen_name" : "towski",
  "in_reply_to_user_id_str" : "10188202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516332324678418432",
  "text" : "Hyrule Warriors is the perfect amount of hack and slash fun. Really glad Nintendo trusted Zelda to another firm like this.",
  "id" : 516332324678418432,
  "created_at" : "2014-09-28 21:03:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "towski",
      "screen_name" : "towski",
      "indices" : [ 0, 7 ],
      "id_str" : "10188202",
      "id" : 10188202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516331805369057281",
  "geo" : { },
  "id_str" : "516332047116140545",
  "in_reply_to_user_id" : 10188202,
  "text" : "@towski wait so does this tie into the actual game if you claim someone?",
  "id" : 516332047116140545,
  "in_reply_to_status_id" : 516331805369057281,
  "created_at" : "2014-09-28 21:02:07 +0000",
  "in_reply_to_screen_name" : "towski",
  "in_reply_to_user_id_str" : "10188202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "towski",
      "screen_name" : "towski",
      "indices" : [ 0, 7 ],
      "id_str" : "10188202",
      "id" : 10188202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516330999173480448",
  "geo" : { },
  "id_str" : "516331211635953664",
  "in_reply_to_user_id" : 10188202,
  "text" : "@towski wow great! Is this a live game?",
  "id" : 516331211635953664,
  "in_reply_to_status_id" : 516330999173480448,
  "created_at" : "2014-09-28 20:58:48 +0000",
  "in_reply_to_screen_name" : "towski",
  "in_reply_to_user_id_str" : "10188202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516287469948399616",
  "geo" : { },
  "id_str" : "516288466913869825",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I think it will take a few years. I also feel a lot of devs can\u2019t keep pace with everything that is new anymore",
  "id" : 516288466913869825,
  "in_reply_to_status_id" : 516287469948399616,
  "created_at" : "2014-09-28 18:08:57 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516278587629248513",
  "text" : "Wasn\u2019t in the video\/board game store for 5 minutes before the clerks started on about spending money on strippers instead of MTG cards",
  "id" : 516278587629248513,
  "created_at" : "2014-09-28 17:29:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "indices" : [ 3, 14 ],
      "id_str" : "982762350",
      "id" : 982762350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Adirondacks",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FrIvKOmzVw",
      "expanded_url" : "http:\/\/ow.ly\/C2tg0",
      "display_url" : "ow.ly\/C2tg0"
    } ]
  },
  "geo" : { },
  "id_str" : "516253688176709632",
  "text" : "RT @NWSBUFFALO: Here is an incredible satellite view of fall color in the #Adirondacks from the Terra satellite. http:\/\/t.co\/FrIvKOmzVw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Adirondacks",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/FrIvKOmzVw",
        "expanded_url" : "http:\/\/ow.ly\/C2tg0",
        "display_url" : "ow.ly\/C2tg0"
      } ]
    },
    "geo" : { },
    "id_str" : "516252915699552256",
    "text" : "Here is an incredible satellite view of fall color in the #Adirondacks from the Terra satellite. http:\/\/t.co\/FrIvKOmzVw",
    "id" : 516252915699552256,
    "created_at" : "2014-09-28 15:47:41 +0000",
    "user" : {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "protected" : false,
      "id_str" : "982762350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465137770696957952\/-6l64r-b_normal.jpeg",
      "id" : 982762350,
      "verified" : true
    }
  },
  "id" : 516253688176709632,
  "created_at" : "2014-09-28 15:50:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516180761150763008",
  "geo" : { },
  "id_str" : "516231455207223296",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss how long did the process take to get approved?",
  "id" : 516231455207223296,
  "in_reply_to_status_id" : 516180761150763008,
  "created_at" : "2014-09-28 14:22:24 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "frank",
      "screen_name" : "fgif",
      "indices" : [ 0, 5 ],
      "id_str" : "56096441",
      "id" : 56096441
    }, {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "indices" : [ 6, 20 ],
      "id_str" : "543918403",
      "id" : 543918403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516223105971544064",
  "geo" : { },
  "id_str" : "516223527947489280",
  "in_reply_to_user_id" : 56096441,
  "text" : "@fgif @TheDefenseman FOOTBALL, JESUS, MAKIN OUT WITH MY GUY FRIENDS",
  "id" : 516223527947489280,
  "in_reply_to_status_id" : 516223105971544064,
  "created_at" : "2014-09-28 13:50:54 +0000",
  "in_reply_to_screen_name" : "fgif",
  "in_reply_to_user_id_str" : "56096441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516188344225497088",
  "geo" : { },
  "id_str" : "516190200859357184",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack iPhones only",
  "id" : 516190200859357184,
  "in_reply_to_status_id" : 516188344225497088,
  "created_at" : "2014-09-28 11:38:28 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/516050610597011456\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/XpgAqzoCsd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BylhSzNCMAALG6o.png",
      "id_str" : "516050607921049600",
      "id" : 516050607921049600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BylhSzNCMAALG6o.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XpgAqzoCsd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516050610597011456",
  "text" : "Kind of creepy that this was tracked without me asking to. The level of detail is intense, down to the minute http:\/\/t.co\/XpgAqzoCsd",
  "id" : 516050610597011456,
  "created_at" : "2014-09-28 02:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You just got Sue'd",
      "screen_name" : "deathbearbrown",
      "indices" : [ 3, 18 ],
      "id_str" : "21491212",
      "id" : 21491212
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/deathbearbrown\/status\/516026212578525184\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ulg1lVECTu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BylLGvuIcAEphpV.png",
      "id_str" : "516026211571888129",
      "id" : 516026211571888129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BylLGvuIcAEphpV.png",
      "sizes" : [ {
        "h" : 659,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ulg1lVECTu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516038165061046272",
  "text" : "RT @deathbearbrown: I made this comic today because this happens to everyone and I hate it. http:\/\/t.co\/ulg1lVECTu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/deathbearbrown\/status\/516026212578525184\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/ulg1lVECTu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BylLGvuIcAEphpV.png",
        "id_str" : "516026211571888129",
        "id" : 516026211571888129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BylLGvuIcAEphpV.png",
        "sizes" : [ {
          "h" : 659,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 773,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ulg1lVECTu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516026212578525184",
    "text" : "I made this comic today because this happens to everyone and I hate it. http:\/\/t.co\/ulg1lVECTu",
    "id" : 516026212578525184,
    "created_at" : "2014-09-28 00:46:51 +0000",
    "user" : {
      "name" : "You just got Sue'd",
      "screen_name" : "deathbearbrown",
      "protected" : false,
      "id_str" : "21491212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571815486883516416\/42vPV3rZ_normal.png",
      "id" : 21491212,
      "verified" : false
    }
  },
  "id" : 516038165061046272,
  "created_at" : "2014-09-28 01:34:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/515988886791933952\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/GPeoweDDU6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BykpJ7yIMAAXgRB.jpg",
      "id_str" : "515988882954137600",
      "id" : 515988882954137600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BykpJ7yIMAAXgRB.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/GPeoweDDU6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515988886791933952",
  "text" : "Cool story, bro. http:\/\/t.co\/GPeoweDDU6",
  "id" : 515988886791933952,
  "created_at" : "2014-09-27 22:18:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515949608997240832",
  "text" : "RT @bquarant: Tank Man of 2014 would be taking a selfie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514893964470935552",
    "text" : "Tank Man of 2014 would be taking a selfie",
    "id" : 514893964470935552,
    "created_at" : "2014-09-24 21:47:42 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 515949608997240832,
  "created_at" : "2014-09-27 19:42:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "based kortney \u270A",
      "screen_name" : "fakerapper",
      "indices" : [ 0, 11 ],
      "id_str" : "14256353",
      "id" : 14256353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515894061996060672",
  "geo" : { },
  "id_str" : "515895130406936576",
  "in_reply_to_user_id" : 14256353,
  "text" : "@fakerapper Sell Out, Bro Down",
  "id" : 515895130406936576,
  "in_reply_to_status_id" : 515894061996060672,
  "created_at" : "2014-09-27 16:05:58 +0000",
  "in_reply_to_screen_name" : "fakerapper",
  "in_reply_to_user_id_str" : "14256353",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sanna Dullaway",
      "screen_name" : "PastInColor",
      "indices" : [ 3, 15 ],
      "id_str" : "470460130",
      "id" : 470460130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/G8EQuZevkv",
      "expanded_url" : "http:\/\/fb.me\/3eKfGjJOf",
      "display_url" : "fb.me\/3eKfGjJOf"
    } ]
  },
  "geo" : { },
  "id_str" : "515892822864457729",
  "text" : "RT @PastInColor: Colorization: Niagara Street, Buffalo, N.Y., 1908. Close-ups in comments! http:\/\/t.co\/G8EQuZevkv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/G8EQuZevkv",
        "expanded_url" : "http:\/\/fb.me\/3eKfGjJOf",
        "display_url" : "fb.me\/3eKfGjJOf"
      } ]
    },
    "geo" : { },
    "id_str" : "515585259946389504",
    "text" : "Colorization: Niagara Street, Buffalo, N.Y., 1908. Close-ups in comments! http:\/\/t.co\/G8EQuZevkv",
    "id" : 515585259946389504,
    "created_at" : "2014-09-26 19:34:39 +0000",
    "user" : {
      "name" : "Sanna Dullaway",
      "screen_name" : "PastInColor",
      "protected" : false,
      "id_str" : "470460130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521748052990648322\/AwKLL669_normal.jpeg",
      "id" : 470460130,
      "verified" : false
    }
  },
  "id" : 515892822864457729,
  "created_at" : "2014-09-27 15:56:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515878205236850688",
  "text" : "RT @r00k: .@nickelcityruby I think I just figured out my keynote. And relief washed over me like a wave.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 1, 16 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515744034329858048",
    "text" : ".@nickelcityruby I think I just figured out my keynote. And relief washed over me like a wave.",
    "id" : 515744034329858048,
    "created_at" : "2014-09-27 06:05:34 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 515878205236850688,
  "created_at" : "2014-09-27 14:58:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 3, 15 ],
      "id_str" : "9526722",
      "id" : 9526722
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515878185641062401",
  "text" : "RT @CoralineAda: Which #rubyfriends will I be seeing at @nickelcityruby next week?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 39, 54 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyfriends",
        "indices" : [ 6, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515500607378317312",
    "text" : "Which #rubyfriends will I be seeing at @nickelcityruby next week?",
    "id" : 515500607378317312,
    "created_at" : "2014-09-26 13:58:16 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 515878185641062401,
  "created_at" : "2014-09-27 14:58:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515877952601341952",
  "text" : "RT @rubygems_status: All of our scheduled reboots are complete. Enjoy your weekend!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515875044128329728",
    "text" : "All of our scheduled reboots are complete. Enjoy your weekend!",
    "id" : 515875044128329728,
    "created_at" : "2014-09-27 14:46:09 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 515877952601341952,
  "created_at" : "2014-09-27 14:57:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EB Farmers Market",
      "screen_name" : "EBFarmersMarket",
      "indices" : [ 40, 56 ],
      "id_str" : "135015214",
      "id" : 135015214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/fXgjgnxyNi",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/fLkrbi3oGkd",
      "display_url" : "swarmapp.com\/c\/fLkrbi3oGkd"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9232461469, -78.8773727417 ]
  },
  "id_str" : "515863785681481730",
  "text" : "I'm at Elmwood Bidwell Farmers Market - @ebfarmersmarket in Buffalo, NY https:\/\/t.co\/fXgjgnxyNi",
  "id" : 515863785681481730,
  "created_at" : "2014-09-27 14:01:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 3, 18 ],
      "id_str" : "43805270",
      "id" : 43805270
    }, {
      "name" : "Albright-Knox",
      "screen_name" : "AlbrightKnox",
      "indices" : [ 46, 59 ],
      "id_str" : "19289541",
      "id" : 19289541
    }, {
      "name" : "BuffaloHistoryMuseum",
      "screen_name" : "BuffaloHistory",
      "indices" : [ 60, 75 ],
      "id_str" : "52098165",
      "id" : 52098165
    }, {
      "name" : "BfloMuseumofScience",
      "screen_name" : "buffaloscience",
      "indices" : [ 76, 91 ],
      "id_str" : "64721924",
      "id" : 64721924
    }, {
      "name" : "Steel Plant Museum",
      "screen_name" : "SPMofWNY",
      "indices" : [ 92, 101 ],
      "id_str" : "196035859",
      "id" : 196035859
    }, {
      "name" : "Burchfield Penney",
      "screen_name" : "BPArtCenter",
      "indices" : [ 102, 114 ],
      "id_str" : "23048137",
      "id" : 23048137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 144 ],
      "url" : "http:\/\/t.co\/ztUR8N1jAu",
      "expanded_url" : "http:\/\/buffalo.com\/2014\/09\/24\/featured\/area-cultural-institutions-to-offer-free-admission\/",
      "display_url" : "buffalo.com\/2014\/09\/24\/fea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515854240460189696",
  "text" : "RT @TheBuffaloNews: Free admission today to: \n@AlbrightKnox\n@BuffaloHistory\n@buffaloscience\n@SPMofWNY\n@BPArtCenter\n&amp; more\nhttp:\/\/t.co\/ztUR8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Albright-Knox",
        "screen_name" : "AlbrightKnox",
        "indices" : [ 26, 39 ],
        "id_str" : "19289541",
        "id" : 19289541
      }, {
        "name" : "BuffaloHistoryMuseum",
        "screen_name" : "BuffaloHistory",
        "indices" : [ 40, 55 ],
        "id_str" : "52098165",
        "id" : 52098165
      }, {
        "name" : "BfloMuseumofScience",
        "screen_name" : "buffaloscience",
        "indices" : [ 56, 71 ],
        "id_str" : "64721924",
        "id" : 64721924
      }, {
        "name" : "Steel Plant Museum",
        "screen_name" : "SPMofWNY",
        "indices" : [ 72, 81 ],
        "id_str" : "196035859",
        "id" : 196035859
      }, {
        "name" : "Burchfield Penney",
        "screen_name" : "BPArtCenter",
        "indices" : [ 82, 94 ],
        "id_str" : "23048137",
        "id" : 23048137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/ztUR8N1jAu",
        "expanded_url" : "http:\/\/buffalo.com\/2014\/09\/24\/featured\/area-cultural-institutions-to-offer-free-admission\/",
        "display_url" : "buffalo.com\/2014\/09\/24\/fea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515840786881970177",
    "text" : "Free admission today to: \n@AlbrightKnox\n@BuffaloHistory\n@buffaloscience\n@SPMofWNY\n@BPArtCenter\n&amp; more\nhttp:\/\/t.co\/ztUR8N1jAu",
    "id" : 515840786881970177,
    "created_at" : "2014-09-27 12:30:02 +0000",
    "user" : {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "protected" : false,
      "id_str" : "43805270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2553395093\/xvx84nnqjk9bokm82d8p_normal.png",
      "id" : 43805270,
      "verified" : true
    }
  },
  "id" : 515854240460189696,
  "created_at" : "2014-09-27 13:23:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515854152153321473",
  "text" : "Hey Siri is such a half baked feature. Can only summon it when you are plugged in and unlocked.",
  "id" : 515854152153321473,
  "created_at" : "2014-09-27 13:23:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515850955145752577",
  "text" : "RT @rubygems_status: We will be experiencing some (hopefully short) downtime today as we reboot some of our servers. Gem installs should no\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515848345483366400",
    "text" : "We will be experiencing some (hopefully short) downtime today as we reboot some of our servers. Gem installs should not be affected.",
    "id" : 515848345483366400,
    "created_at" : "2014-09-27 13:00:04 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 515850955145752577,
  "created_at" : "2014-09-27 13:10:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Collin Van Dyck",
      "screen_name" : "collinvandyck",
      "indices" : [ 3, 17 ],
      "id_str" : "2932878932",
      "id" : 2932878932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515699289847517184",
  "text" : "RT @collinvandyck: what idiot named them dermatologists instead of growth hackers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515562769442029568",
    "text" : "what idiot named them dermatologists instead of growth hackers",
    "id" : 515562769442029568,
    "created_at" : "2014-09-26 18:05:17 +0000",
    "user" : {
      "name" : "an cat enthusiast",
      "screen_name" : "tweets_so_fresh",
      "protected" : false,
      "id_str" : "190633664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570850509125218304\/BKtxd3nN_normal.jpeg",
      "id" : 190633664,
      "verified" : false
    }
  },
  "id" : 515699289847517184,
  "created_at" : "2014-09-27 03:07:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/z7SyGbnguW",
      "expanded_url" : "http:\/\/m.imgur.com\/a\/5lPuC",
      "display_url" : "m.imgur.com\/a\/5lPuC"
    } ]
  },
  "geo" : { },
  "id_str" : "515687057969397760",
  "text" : "A Dwarf Fortress built across a chasm in spectacular fashion  http:\/\/t.co\/z7SyGbnguW",
  "id" : 515687057969397760,
  "created_at" : "2014-09-27 02:19:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515669288552640514",
  "geo" : { },
  "id_str" : "515669462565928960",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler every time I have visited this has bothered me immensely",
  "id" : 515669462565928960,
  "in_reply_to_status_id" : 515669288552640514,
  "created_at" : "2014-09-27 01:09:15 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515669413584838658",
  "text" : "RT @samkottler: The juxtaposition between such incredible wealth and intense poverty in SF is really upsetting.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515669288552640514",
    "text" : "The juxtaposition between such incredible wealth and intense poverty in SF is really upsetting.",
    "id" : 515669288552640514,
    "created_at" : "2014-09-27 01:08:33 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 515669413584838658,
  "created_at" : "2014-09-27 01:09:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/BLQpaWPq8I",
      "expanded_url" : "http:\/\/nikf.org\/blog\/split-screen-ipad-development",
      "display_url" : "nikf.org\/blog\/split-scr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515583311964434432",
  "text" : "Feeling like iOS9 will be Universal only. No more iPhone\/iPad UI split. Hints as to why: http:\/\/t.co\/BLQpaWPq8I",
  "id" : 515583311964434432,
  "created_at" : "2014-09-26 19:26:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 3, 9 ],
      "id_str" : "15265916",
      "id" : 15265916
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 77, 92 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ok9hI3pGgs",
      "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014?discount_code=NCR_dabit",
      "display_url" : "ti.to\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515582756957331457",
  "text" : "RT @dabit: Only one week to go! Remember that you can get a 20% discount for @nickelcityruby using code NCR_dabit https:\/\/t.co\/ok9hI3pGgs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 66, 81 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/ok9hI3pGgs",
        "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014?discount_code=NCR_dabit",
        "display_url" : "ti.to\/nickelcityruby\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515168606905053184",
    "text" : "Only one week to go! Remember that you can get a 20% discount for @nickelcityruby using code NCR_dabit https:\/\/t.co\/ok9hI3pGgs",
    "id" : 515168606905053184,
    "created_at" : "2014-09-25 15:59:01 +0000",
    "user" : {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "protected" : false,
      "id_str" : "15265916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561348487561117696\/q38sJ7kb_normal.jpeg",
      "id" : 15265916,
      "verified" : false
    }
  },
  "id" : 515582756957331457,
  "created_at" : "2014-09-26 19:24:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 3, 13 ],
      "id_str" : "14182110",
      "id" : 14182110
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/XijLnq1MmW",
      "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014",
      "display_url" : "ti.to\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515582736644333568",
  "text" : "RT @confreaks: Next week we will be at @nickelcityruby .. have you bought your ticket? https:\/\/t.co\/XijLnq1MmW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 24, 39 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/XijLnq1MmW",
        "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014",
        "display_url" : "ti.to\/nickelcityruby\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515572469764071424",
    "text" : "Next week we will be at @nickelcityruby .. have you bought your ticket? https:\/\/t.co\/XijLnq1MmW",
    "id" : 515572469764071424,
    "created_at" : "2014-09-26 18:43:50 +0000",
    "user" : {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "protected" : false,
      "id_str" : "14182110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508193987417485312\/4FaFrBga_normal.png",
      "id" : 14182110,
      "verified" : false
    }
  },
  "id" : 515582736644333568,
  "created_at" : "2014-09-26 19:24:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandrill",
      "screen_name" : "mandrillapp",
      "indices" : [ 68, 80 ],
      "id_str" : "540239057",
      "id" : 540239057
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 85, 100 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515582676565123072",
  "text" : "Just got a huge box of some of the nicest notebooks and shirts from @mandrillapp for @nickelcityruby. Thanks!!",
  "id" : 515582676565123072,
  "created_at" : "2014-09-26 19:24:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515575952647024640",
  "text" : "RT @rubygems_status: We're currently investigating higher than normal error rates on the web application. More updates soon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515575772828807168",
    "text" : "We're currently investigating higher than normal error rates on the web application. More updates soon.",
    "id" : 515575772828807168,
    "created_at" : "2014-09-26 18:56:57 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 515575952647024640,
  "created_at" : "2014-09-26 18:57:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik Nyh",
      "screen_name" : "henrik",
      "indices" : [ 0, 7 ],
      "id_str" : "14208392",
      "id" : 14208392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515485599613353984",
  "geo" : { },
  "id_str" : "515487410856005633",
  "in_reply_to_user_id" : 14208392,
  "text" : "@henrik gist it all!",
  "id" : 515487410856005633,
  "in_reply_to_status_id" : 515485599613353984,
  "created_at" : "2014-09-26 13:05:50 +0000",
  "in_reply_to_screen_name" : "henrik",
  "in_reply_to_user_id_str" : "14208392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515360378973216768",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby you HOAXER!",
  "id" : 515360378973216768,
  "created_at" : "2014-09-26 04:41:03 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515358532309635072",
  "geo" : { },
  "id_str" : "515359736540065793",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded oh dang it\u2019s out?! Let me know how it goes.",
  "id" : 515359736540065793,
  "in_reply_to_status_id" : 515358532309635072,
  "created_at" : "2014-09-26 04:38:30 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515305397251354624",
  "geo" : { },
  "id_str" : "515305677397299202",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt I'd appreciate some longer thoughts on building it before people are consuming it vs extracting it from an app",
  "id" : 515305677397299202,
  "in_reply_to_status_id" : 515305397251354624,
  "created_at" : "2014-09-26 01:03:42 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515304430153900032",
  "geo" : { },
  "id_str" : "515304897227399168",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt great answer, thanks. Curious to see how it shakes out when people start using it.",
  "id" : 515304897227399168,
  "in_reply_to_status_id" : 515304430153900032,
  "created_at" : "2014-09-26 01:00:36 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 15, 30 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Aq8JIXLAHR",
      "expanded_url" : "https:\/\/vimeo.com\/107205469",
      "display_url" : "vimeo.com\/107205469"
    } ]
  },
  "geo" : { },
  "id_str" : "515303684591190018",
  "text" : "Coffeelapse of @PublicEspresso in brew @coworkbuffalo https:\/\/t.co\/Aq8JIXLAHR",
  "id" : 515303684591190018,
  "created_at" : "2014-09-26 00:55:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515296979169980416",
  "geo" : { },
  "id_str" : "515303506794668033",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt So why the 1.0 if it's not being used anywhere? Confused.",
  "id" : 515303506794668033,
  "in_reply_to_status_id" : 515296979169980416,
  "created_at" : "2014-09-26 00:55:04 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 4, 10 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/BchQcpVmHy",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=8369084",
      "display_url" : "news.ycombinator.com\/item?id=8369084"
    } ]
  },
  "geo" : { },
  "id_str" : "515289899483013120",
  "text" : "Hey @mattt, you did kind of say AMA... :) https:\/\/t.co\/BchQcpVmHy",
  "id" : 515289899483013120,
  "created_at" : "2014-09-26 00:01:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Smith IV",
      "screen_name" : "JackSmithIV",
      "indices" : [ 0, 12 ],
      "id_str" : "27306129",
      "id" : 27306129
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 37, 41 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515288846003884032",
  "geo" : { },
  "id_str" : "515289796348899328",
  "in_reply_to_user_id" : 27306129,
  "text" : "@JackSmithIV \"No pressure\" Sure. \/cc @dhh",
  "id" : 515289796348899328,
  "in_reply_to_status_id" : 515288846003884032,
  "created_at" : "2014-09-26 00:00:35 +0000",
  "in_reply_to_screen_name" : "JackSmithIV",
  "in_reply_to_user_id_str" : "27306129",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Zn9opKgJQE",
      "expanded_url" : "https:\/\/ello.co\/waxpancake\/post\/oy73kFfDdhOPh8Jv9z9pFA",
      "display_url" : "ello.co\/waxpancake\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515288132514623488",
  "text" : "Not surprising: Ello took a bunch of VC and will probably time bomb like (mostly) every other startup https:\/\/t.co\/Zn9opKgJQE",
  "id" : 515288132514623488,
  "created_at" : "2014-09-25 23:53:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515276944238055424",
  "geo" : { },
  "id_str" : "515277464025567232",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams who took the photo?",
  "id" : 515277464025567232,
  "in_reply_to_status_id" : 515276944238055424,
  "created_at" : "2014-09-25 23:11:35 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Gruber",
      "screen_name" : "gruber",
      "indices" : [ 3, 10 ],
      "id_str" : "33423",
      "id" : 33423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/BR8UvnOKpX",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=O99m7lebirE",
      "display_url" : "youtube.com\/watch?v=O99m7l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515270290461315072",
  "text" : "RT @gruber: \u201CPretty sure it\u2019s the common sense thing.\u201D\n\nhttps:\/\/t.co\/BR8UvnOKpX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/BR8UvnOKpX",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=O99m7lebirE",
        "display_url" : "youtube.com\/watch?v=O99m7l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515240686061641728",
    "text" : "\u201CPretty sure it\u2019s the common sense thing.\u201D\n\nhttps:\/\/t.co\/BR8UvnOKpX",
    "id" : 515240686061641728,
    "created_at" : "2014-09-25 20:45:26 +0000",
    "user" : {
      "name" : "John Gruber",
      "screen_name" : "gruber",
      "protected" : false,
      "id_str" : "33423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3065313266\/7d563f0c22918aba2d6be2eaa9fb92a7_normal.png",
      "id" : 33423,
      "verified" : true
    }
  },
  "id" : 515270290461315072,
  "created_at" : "2014-09-25 22:43:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515235076150673409",
  "geo" : { },
  "id_str" : "515237120714100736",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani I didn't really learn anything of importance from the initial email.",
  "id" : 515237120714100736,
  "in_reply_to_status_id" : 515235076150673409,
  "created_at" : "2014-09-25 20:31:16 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515233541182226433",
  "geo" : { },
  "id_str" : "515233860959744000",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani It hasn't been too helpful yet. Yep, I've been on Twitter a while, people follow me. Going to give it a few days.",
  "id" : 515233860959744000,
  "in_reply_to_status_id" : 515233541182226433,
  "created_at" : "2014-09-25 20:18:19 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merissa",
      "screen_name" : "merissie",
      "indices" : [ 3, 12 ],
      "id_str" : "15338379",
      "id" : 15338379
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justcurious",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515228253884133376",
  "text" : "RT @merissie: When was the last time you emailed a company and got a response 2 or 3 minutes later? What was the company? #justcurious",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "justcurious",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515228029191086080",
    "text" : "When was the last time you emailed a company and got a response 2 or 3 minutes later? What was the company? #justcurious",
    "id" : 515228029191086080,
    "created_at" : "2014-09-25 19:55:09 +0000",
    "user" : {
      "name" : "Merissa",
      "screen_name" : "merissie",
      "protected" : false,
      "id_str" : "15338379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469314426408284160\/ghKxXnvy_normal.jpeg",
      "id" : 15338379,
      "verified" : false
    }
  },
  "id" : 515228253884133376,
  "created_at" : "2014-09-25 19:56:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner  O'Malley",
      "screen_name" : "conner_omalley",
      "indices" : [ 3, 18 ],
      "id_str" : "980990414",
      "id" : 980990414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515220680040665088",
  "text" : "RT @conner_omalley: I am a millennial! And I have a opinion!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515220595563581440",
    "text" : "I am a millennial! And I have a opinion!",
    "id" : 515220595563581440,
    "created_at" : "2014-09-25 19:25:36 +0000",
    "user" : {
      "name" : "Conner  O'Malley",
      "screen_name" : "conner_omalley",
      "protected" : false,
      "id_str" : "980990414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2915663545\/4bce5b79e1a8b21dacd1a6da46b2426b_normal.jpeg",
      "id" : 980990414,
      "verified" : false
    }
  },
  "id" : 515220680040665088,
  "created_at" : "2014-09-25 19:25:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/DCF5g9DbWM",
      "expanded_url" : "http:\/\/io9.com\/scorpion-brings-the-stupidest-most-batshit-insane-hack-1638333877?utm_campaign=socialflow_io9_facebook&utm_source=io9_facebook&utm_medium=socialflow",
      "display_url" : "io9.com\/scorpion-bring\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515220656380600320",
  "text" : "I watched every second of this video and I cannot mentally process it still http:\/\/t.co\/DCF5g9DbWM",
  "id" : 515220656380600320,
  "created_at" : "2014-09-25 19:25:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515210801330671616",
  "text" : "I have no idea how to upload a video to Twitter.",
  "id" : 515210801330671616,
  "created_at" : "2014-09-25 18:46:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 3, 9 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "VGKIDS",
      "screen_name" : "vgkids",
      "indices" : [ 103, 110 ],
      "id_str" : "41824510",
      "id" : 41824510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/BnzePGeBZK",
      "expanded_url" : "https:\/\/basecamp.com\/stickers",
      "display_url" : "basecamp.com\/stickers"
    } ]
  },
  "geo" : { },
  "id_str" : "515181064503848961",
  "text" : "RT @javan: Want some Basecamp stickers? We'll 'em to you for free. https:\/\/t.co\/BnzePGeBZK (powered by @vgkids \u2764\uFE0F)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VGKIDS",
        "screen_name" : "vgkids",
        "indices" : [ 92, 99 ],
        "id_str" : "41824510",
        "id" : 41824510
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/BnzePGeBZK",
        "expanded_url" : "https:\/\/basecamp.com\/stickers",
        "display_url" : "basecamp.com\/stickers"
      } ]
    },
    "geo" : { },
    "id_str" : "515180461614575617",
    "text" : "Want some Basecamp stickers? We'll 'em to you for free. https:\/\/t.co\/BnzePGeBZK (powered by @vgkids \u2764\uFE0F)",
    "id" : 515180461614575617,
    "created_at" : "2014-09-25 16:46:08 +0000",
    "user" : {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "protected" : false,
      "id_str" : "1679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526722729123143680\/0-ppDKP__normal.jpeg",
      "id" : 1679,
      "verified" : false
    }
  },
  "id" : 515181064503848961,
  "created_at" : "2014-09-25 16:48:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Caleb Thompson",
      "screen_name" : "calebthompson",
      "indices" : [ 8, 22 ],
      "id_str" : "290866979",
      "id" : 290866979
    }, {
      "name" : "Nick Rivadeneira",
      "screen_name" : "imNickR",
      "indices" : [ 23, 31 ],
      "id_str" : "20957239",
      "id" : 20957239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515167719310651392",
  "geo" : { },
  "id_str" : "515169579014701056",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @calebthompson @imNickR I will demand this now.",
  "id" : 515169579014701056,
  "in_reply_to_status_id" : 515167719310651392,
  "created_at" : "2014-09-25 16:02:53 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 16, 29 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Ft7NHliyaN",
      "expanded_url" : "http:\/\/whyisthereanything.org\/",
      "display_url" : "whyisthereanything.org"
    } ]
  },
  "in_reply_to_status_id_str" : "515164078357360640",
  "geo" : { },
  "id_str" : "515165372429787136",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez @nicksergeant http:\/\/t.co\/Ft7NHliyaN",
  "id" : 515165372429787136,
  "in_reply_to_status_id" : 515164078357360640,
  "created_at" : "2014-09-25 15:46:10 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "indices" : [ 0, 12 ],
      "id_str" : "6927562",
      "id" : 6927562
    }, {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 13, 21 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515062643069947904",
  "geo" : { },
  "id_str" : "515154813688881152",
  "in_reply_to_user_id" : 6927562,
  "text" : "@thomasfuchs @patio11 have a PoC for this? Interested how it's at all possible",
  "id" : 515154813688881152,
  "in_reply_to_status_id" : 515062643069947904,
  "created_at" : "2014-09-25 15:04:13 +0000",
  "in_reply_to_screen_name" : "thomasfuchs",
  "in_reply_to_user_id_str" : "6927562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "calebthompson",
      "indices" : [ 0, 14 ],
      "id_str" : "290866979",
      "id" : 290866979
    }, {
      "name" : "Nick Rivadeneira",
      "screen_name" : "imNickR",
      "indices" : [ 15, 23 ],
      "id_str" : "20957239",
      "id" : 20957239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515146912417456128",
  "geo" : { },
  "id_str" : "515147374012796930",
  "in_reply_to_user_id" : 290866979,
  "text" : "@calebthompson @imNickR wat",
  "id" : 515147374012796930,
  "in_reply_to_status_id" : 515146912417456128,
  "created_at" : "2014-09-25 14:34:39 +0000",
  "in_reply_to_screen_name" : "calebthompson",
  "in_reply_to_user_id_str" : "290866979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/OXnWoSjsps",
      "expanded_url" : "http:\/\/instagram.com\/p\/tXwe7TMOft\/",
      "display_url" : "instagram.com\/p\/tXwe7TMOft\/"
    } ]
  },
  "geo" : { },
  "id_str" : "515140925241454592",
  "text" : "RT @PublicEspresso: We're launching seven new coffees in seven weeks in a new program we're calling, New Brew Thursday.\u2026 http:\/\/t.co\/OXnWoS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/OXnWoSjsps",
        "expanded_url" : "http:\/\/instagram.com\/p\/tXwe7TMOft\/",
        "display_url" : "instagram.com\/p\/tXwe7TMOft\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.8996510412, -78.8799849696 ]
    },
    "id_str" : "515140153162366976",
    "text" : "We're launching seven new coffees in seven weeks in a new program we're calling, New Brew Thursday.\u2026 http:\/\/t.co\/OXnWoSjsps",
    "id" : 515140153162366976,
    "created_at" : "2014-09-25 14:05:58 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 515140925241454592,
  "created_at" : "2014-09-25 14:09:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Littlelines on Rails",
      "screen_name" : "littlelines",
      "indices" : [ 60, 72 ],
      "id_str" : "22043483",
      "id" : 22043483
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/515139770339827712\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/DRVh6YCDCh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByYk477IEAEiZil.jpg",
      "id_str" : "515139767957458945",
      "id" : 515139767957458945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByYk477IEAEiZil.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/DRVh6YCDCh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515140204056051712",
  "text" : "RT @nickelcityruby: Loving the detail on our 2014 logo from @littlelines. We\u2019re one week away today! http:\/\/t.co\/DRVh6YCDCh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Littlelines on Rails",
        "screen_name" : "littlelines",
        "indices" : [ 40, 52 ],
        "id_str" : "22043483",
        "id" : 22043483
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/515139770339827712\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/DRVh6YCDCh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByYk477IEAEiZil.jpg",
        "id_str" : "515139767957458945",
        "id" : 515139767957458945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByYk477IEAEiZil.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/DRVh6YCDCh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515139770339827712",
    "text" : "Loving the detail on our 2014 logo from @littlelines. We\u2019re one week away today! http:\/\/t.co\/DRVh6YCDCh",
    "id" : 515139770339827712,
    "created_at" : "2014-09-25 14:04:26 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 515140204056051712,
  "created_at" : "2014-09-25 14:06:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niagara Co.Fire Wire",
      "screen_name" : "NCfirewire",
      "indices" : [ 3, 14 ],
      "id_str" : "15285771",
      "id" : 15285771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515132996744396800",
  "text" : "RT @NCfirewire: Niagara Falls fire update : Now at the 115 hour mark and crews remain on scene working on hot spots",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515130658432491520",
    "text" : "Niagara Falls fire update : Now at the 115 hour mark and crews remain on scene working on hot spots",
    "id" : 515130658432491520,
    "created_at" : "2014-09-25 13:28:14 +0000",
    "user" : {
      "name" : "Niagara Co.Fire Wire",
      "screen_name" : "NCfirewire",
      "protected" : false,
      "id_str" : "15285771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3454686745\/3d4247c25ae3f9db113db7db7bcad4e9_normal.jpeg",
      "id" : 15285771,
      "verified" : false
    }
  },
  "id" : 515132996744396800,
  "created_at" : "2014-09-25 13:37:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/514855974658924544\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/20P0SH8vhX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByUij-OCEAAlXEH.jpg",
      "id_str" : "514855733796409344",
      "id" : 514855733796409344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByUij-OCEAAlXEH.jpg",
      "sizes" : [ {
        "h" : 524,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 907,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 907,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 907,
        "resize" : "fit",
        "w" : 588
      } ],
      "display_url" : "pic.twitter.com\/20P0SH8vhX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515113217786253312",
  "text" : "RT @AqueousBand: Hello! We hope everyone is excited for our new album! We honestly think its our best work yet. See you Oct 25! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/514855974658924544\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/20P0SH8vhX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByUij-OCEAAlXEH.jpg",
        "id_str" : "514855733796409344",
        "id" : 514855733796409344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByUij-OCEAAlXEH.jpg",
        "sizes" : [ {
          "h" : 524,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 907,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 907,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 907,
          "resize" : "fit",
          "w" : 588
        } ],
        "display_url" : "pic.twitter.com\/20P0SH8vhX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514855974658924544",
    "text" : "Hello! We hope everyone is excited for our new album! We honestly think its our best work yet. See you Oct 25! http:\/\/t.co\/20P0SH8vhX",
    "id" : 514855974658924544,
    "created_at" : "2014-09-24 19:16:44 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 515113217786253312,
  "created_at" : "2014-09-25 12:18:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 0, 7 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    }, {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 8, 20 ],
      "id_str" : "15686931",
      "id" : 15686931
    }, {
      "name" : "Natalie",
      "screen_name" : "ntljk",
      "indices" : [ 21, 27 ],
      "id_str" : "21778760",
      "id" : 21778760
    }, {
      "name" : "Jim Mackenzie",
      "screen_name" : "mackesque",
      "indices" : [ 28, 38 ],
      "id_str" : "21399337",
      "id" : 21399337
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 39, 48 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515100179360260096",
  "geo" : { },
  "id_str" : "515105790495965185",
  "in_reply_to_user_id" : 2544124698,
  "text" : "@sylvzc @chris_joyce @ntljk @mackesque @shildner wings are keto\/paleo. Kind of.",
  "id" : 515105790495965185,
  "in_reply_to_status_id" : 515100179360260096,
  "created_at" : "2014-09-25 11:49:25 +0000",
  "in_reply_to_screen_name" : "sylvzc",
  "in_reply_to_user_id_str" : "2544124698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aloria",
      "screen_name" : "aloria",
      "indices" : [ 3, 10 ],
      "id_str" : "11250462",
      "id" : 11250462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shellshock",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wO6KhKh7HG",
      "expanded_url" : "http:\/\/www.wptz.com\/money\/bash-bug-could-let-hackers-attack-through-a-light-bulb\/28233332",
      "display_url" : "wptz.com\/money\/bash-bug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515002733191913472",
  "text" : "RT @aloria: Most hysterical #shellshock headline so far: \"'Bash' bug could let hackers attack through a light bulb\u201D\n\nhttp:\/\/t.co\/wO6KhKh7HG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shellshock",
        "indices" : [ 16, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/wO6KhKh7HG",
        "expanded_url" : "http:\/\/www.wptz.com\/money\/bash-bug-could-let-hackers-attack-through-a-light-bulb\/28233332",
        "display_url" : "wptz.com\/money\/bash-bug\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "514939277625815040",
    "text" : "Most hysterical #shellshock headline so far: \"'Bash' bug could let hackers attack through a light bulb\u201D\n\nhttp:\/\/t.co\/wO6KhKh7HG",
    "id" : 514939277625815040,
    "created_at" : "2014-09-25 00:47:45 +0000",
    "user" : {
      "name" : "aloria",
      "screen_name" : "aloria",
      "protected" : false,
      "id_str" : "11250462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571770054959865857\/cmu0Mz8d_normal.jpeg",
      "id" : 11250462,
      "verified" : false
    }
  },
  "id" : 515002733191913472,
  "created_at" : "2014-09-25 04:59:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/90FGQ3qPKF",
      "expanded_url" : "http:\/\/furbo.org\/2014\/09\/24\/in-app-browsers-considered-harmful\/",
      "display_url" : "furbo.org\/2014\/09\/24\/in-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514951936873750528",
  "text" : "\"You should never enter any private information while you\u2019re using an app that\u2019s not Safari.\" - http:\/\/t.co\/90FGQ3qPKF",
  "id" : 514951936873750528,
  "created_at" : "2014-09-25 01:38:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514943899232530432",
  "geo" : { },
  "id_str" : "514944077494632448",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler would love to listen in :)",
  "id" : 514944077494632448,
  "in_reply_to_status_id" : 514943899232530432,
  "created_at" : "2014-09-25 01:06:49 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8gbloIJMlu",
      "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/rubygems-org\/Obzww_ld4fc\/HSDgzm289OcJ",
      "display_url" : "groups.google.com\/d\/msg\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514944017436401664",
  "text" : "RT @samkottler: We're gonna be doing some work on improving RubyGems\/Bundler infrastructure on Friday  - https:\/\/t.co\/8gbloIJMlu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/8gbloIJMlu",
        "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/rubygems-org\/Obzww_ld4fc\/HSDgzm289OcJ",
        "display_url" : "groups.google.com\/d\/msg\/rubygems\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "514943899232530432",
    "text" : "We're gonna be doing some work on improving RubyGems\/Bundler infrastructure on Friday  - https:\/\/t.co\/8gbloIJMlu",
    "id" : 514943899232530432,
    "created_at" : "2014-09-25 01:06:07 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 514944017436401664,
  "created_at" : "2014-09-25 01:06:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Ggg6APYOn7",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=jm27FHBAuRs",
      "display_url" : "youtube.com\/watch?v=jm27FH\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "514930320798257152",
  "geo" : { },
  "id_str" : "514943603102064640",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines we just saw this band and thought the bassist was you for awhile https:\/\/t.co\/Ggg6APYOn7",
  "id" : 514943603102064640,
  "in_reply_to_status_id" : 514930320798257152,
  "created_at" : "2014-09-25 01:04:56 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Sinclair",
      "screen_name" : "jaredsinclair",
      "indices" : [ 0, 14 ],
      "id_str" : "15004156",
      "id" : 15004156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514879708740472832",
  "geo" : { },
  "id_str" : "514902744730050560",
  "in_reply_to_user_id" : 15004156,
  "text" : "@jaredsinclair awful QA at apple lately",
  "id" : 514902744730050560,
  "in_reply_to_status_id" : 514879708740472832,
  "created_at" : "2014-09-24 22:22:35 +0000",
  "in_reply_to_screen_name" : "jaredsinclair",
  "in_reply_to_user_id_str" : "15004156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Sinclair",
      "screen_name" : "jaredsinclair",
      "indices" : [ 0, 14 ],
      "id_str" : "15004156",
      "id" : 15004156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514875463811203072",
  "geo" : { },
  "id_str" : "514877348496568320",
  "in_reply_to_user_id" : 15004156,
  "text" : "@jaredsinclair I just got this same error. Doesn't accept PNGs or JPGs, straight from the simulator",
  "id" : 514877348496568320,
  "in_reply_to_status_id" : 514875463811203072,
  "created_at" : "2014-09-24 20:41:40 +0000",
  "in_reply_to_screen_name" : "jaredsinclair",
  "in_reply_to_user_id_str" : "15004156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wCsxAY8phr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "514866590962053121",
  "text" : "http:\/\/t.co\/wCsxAY8phr is having some trouble, trying to figure out what\/why...",
  "id" : 514866590962053121,
  "created_at" : "2014-09-24 19:58:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 3, 15 ],
      "id_str" : "9526722",
      "id" : 9526722
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514862363774701568",
  "text" : "RT @CoralineAda: My aesthetics talk at @nickelcityruby next week will have ravens! And Douglas Hofstadter! So excited.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 22, 37 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514861755953315842",
    "text" : "My aesthetics talk at @nickelcityruby next week will have ravens! And Douglas Hofstadter! So excited.",
    "id" : 514861755953315842,
    "created_at" : "2014-09-24 19:39:42 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 514862363774701568,
  "created_at" : "2014-09-24 19:42:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/xqwFrLjnHN",
      "expanded_url" : "http:\/\/ello.com\/",
      "display_url" : "ello.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514859522918080512",
  "text" : "This looks like a sweet social network http:\/\/t.co\/xqwFrLjnHN",
  "id" : 514859522918080512,
  "created_at" : "2014-09-24 19:30:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514658549285138432",
  "geo" : { },
  "id_str" : "514831399375749120",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave yeah, maybe if my bank had a concept of a read-only account. the same credentials could be used to transfer all money out.",
  "id" : 514831399375749120,
  "in_reply_to_status_id" : 514658549285138432,
  "created_at" : "2014-09-24 17:39:05 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/n6HPhjmLWp",
      "expanded_url" : "https:\/\/securityblog.redhat.com\/2014\/09\/24\/bash-specially-crafted-environment-variables-code-injection-attack\/",
      "display_url" : "securityblog.redhat.com\/2014\/09\/24\/bas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514823021186404352",
  "text" : "Pretty big bash\/zsh vulnerability, heads up! https:\/\/t.co\/n6HPhjmLWp",
  "id" : 514823021186404352,
  "created_at" : "2014-09-24 17:05:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 3, 12 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 50, 65 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/51d50TCt6a",
      "expanded_url" : "http:\/\/cl.ly\/2i3E2y080s0b",
      "display_url" : "cl.ly\/2i3E2y080s0b"
    } ]
  },
  "geo" : { },
  "id_str" : "514774935063908352",
  "text" : "RT @sebasoga: Stop thinking about it and get your @nickelcityruby now with 20% off: http:\/\/t.co\/51d50TCt6a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/eventualtweet.com\" rel=\"nofollow\"\u003EEventualTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 36, 51 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/51d50TCt6a",
        "expanded_url" : "http:\/\/cl.ly\/2i3E2y080s0b",
        "display_url" : "cl.ly\/2i3E2y080s0b"
      } ]
    },
    "geo" : { },
    "id_str" : "514771234127507457",
    "text" : "Stop thinking about it and get your @nickelcityruby now with 20% off: http:\/\/t.co\/51d50TCt6a",
    "id" : 514771234127507457,
    "created_at" : "2014-09-24 13:40:00 +0000",
    "user" : {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "protected" : false,
      "id_str" : "41438974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488894836628418560\/teTisCDG_normal.jpeg",
      "id" : 41438974,
      "verified" : false
    }
  },
  "id" : 514774935063908352,
  "created_at" : "2014-09-24 13:54:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 3, 9 ],
      "id_str" : "15265916",
      "id" : 15265916
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 105, 120 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dabit\/status\/514536753588228096\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/vYE7Ak4Vqe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByQAcuOCUAE2LRa.jpg",
      "id_str" : "514536750870319105",
      "id" : 514536750870319105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByQAcuOCUAE2LRa.jpg",
      "sizes" : [ {
        "h" : 587,
        "resize" : "fit",
        "w" : 776
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 776
      } ],
      "display_url" : "pic.twitter.com\/vYE7Ak4Vqe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514760462664085505",
  "text" : "RT @dabit: Very happy\/excited to give a technical talk that will include a bunch of slides like this one @nickelcityruby http:\/\/t.co\/vYE7Ak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 94, 109 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dabit\/status\/514536753588228096\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/vYE7Ak4Vqe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByQAcuOCUAE2LRa.jpg",
        "id_str" : "514536750870319105",
        "id" : 514536750870319105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByQAcuOCUAE2LRa.jpg",
        "sizes" : [ {
          "h" : 587,
          "resize" : "fit",
          "w" : 776
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 776
        } ],
        "display_url" : "pic.twitter.com\/vYE7Ak4Vqe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514536753588228096",
    "text" : "Very happy\/excited to give a technical talk that will include a bunch of slides like this one @nickelcityruby http:\/\/t.co\/vYE7Ak4Vqe",
    "id" : 514536753588228096,
    "created_at" : "2014-09-23 22:08:16 +0000",
    "user" : {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "protected" : false,
      "id_str" : "15265916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561348487561117696\/q38sJ7kb_normal.jpeg",
      "id" : 15265916,
      "verified" : false
    }
  },
  "id" : 514760462664085505,
  "created_at" : "2014-09-24 12:57:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/514526148345090049\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MqCxT9vGet",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByP2zfZCUAEDZfZ.jpg",
      "id_str" : "514526146910638081",
      "id" : 514526146910638081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByP2zfZCUAEDZfZ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MqCxT9vGet"
    } ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514760453705039872",
  "text" : "RT @nickelcityruby: Just got our stickers in the mail. Is anyone else super excited?! 10 days left to #ncrc14 \uD83C\uDF89\uD83D\uDE01 http:\/\/t.co\/MqCxT9vGet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/514526148345090049\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/MqCxT9vGet",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByP2zfZCUAEDZfZ.jpg",
        "id_str" : "514526146910638081",
        "id" : 514526146910638081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByP2zfZCUAEDZfZ.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MqCxT9vGet"
      } ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514526148345090049",
    "text" : "Just got our stickers in the mail. Is anyone else super excited?! 10 days left to #ncrc14 \uD83C\uDF89\uD83D\uDE01 http:\/\/t.co\/MqCxT9vGet",
    "id" : 514526148345090049,
    "created_at" : "2014-09-23 21:26:07 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 514760453705039872,
  "created_at" : "2014-09-24 12:57:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DevOps So Fresh",
      "screen_name" : "ascendantlogic",
      "indices" : [ 0, 15 ],
      "id_str" : "15544659",
      "id" : 15544659
    }, {
      "name" : "Ernest W. Durbin III",
      "screen_name" : "EWDurbin",
      "indices" : [ 16, 25 ],
      "id_str" : "14590010",
      "id" : 14590010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/bzLFht1wOG",
      "expanded_url" : "https:\/\/medium.com\/@fart\/why-i-am-the-most-important-devops-thought-leader-46a191ac0f42",
      "display_url" : "medium.com\/@fart\/why-i-am\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "514603589659295745",
  "geo" : { },
  "id_str" : "514608161072742401",
  "in_reply_to_user_id" : 15544659,
  "text" : "@ascendantlogic @EWDurbin clearly you aren\u2019t reading about the Foremost DevOps Thought Leaders https:\/\/t.co\/bzLFht1wOG",
  "id" : 514608161072742401,
  "in_reply_to_status_id" : 514603589659295745,
  "created_at" : "2014-09-24 02:52:01 +0000",
  "in_reply_to_screen_name" : "ascendantlogic",
  "in_reply_to_user_id_str" : "15544659",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Pony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "122932694",
      "id" : 122932694
    }, {
      "name" : "Nat ",
      "screen_name" : "NatDudley",
      "indices" : [ 13, 23 ],
      "id_str" : "130779738",
      "id" : 130779738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514606466842390530",
  "text" : "@seriouspony @NatDudley definitely. I\u2019d imagine this is a problem for a lot of bigger confs (thinking 500+ people) it\u2019s nice to be small :)",
  "id" : 514606466842390530,
  "created_at" : "2014-09-24 02:45:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514605337513431040",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave hey! Is there a way to use Level without giving you my bank password? How are others comfortable with this at all?",
  "id" : 514605337513431040,
  "created_at" : "2014-09-24 02:40:48 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Pony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "122932694",
      "id" : 122932694
    }, {
      "name" : "Nat ",
      "screen_name" : "NatDudley",
      "indices" : [ 13, 23 ],
      "id_str" : "130779738",
      "id" : 130779738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514605018859589632",
  "text" : "@seriouspony @NatDudley there\u2019s always a gamble in trusting speakers to deliver their product - but I feel this way as an organizer.",
  "id" : 514605018859589632,
  "created_at" : "2014-09-24 02:39:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 0, 8 ],
      "id_str" : "304067888",
      "id" : 304067888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514595837755031552",
  "geo" : { },
  "id_str" : "514596304391921665",
  "in_reply_to_user_id" : 304067888,
  "text" : "@ag_dubs maybe it\u2019s margaritalline",
  "id" : 514596304391921665,
  "in_reply_to_status_id" : 514595837755031552,
  "created_at" : "2014-09-24 02:04:54 +0000",
  "in_reply_to_screen_name" : "ag_dubs",
  "in_reply_to_user_id_str" : "304067888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    }, {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 7, 18 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514577888847208448",
  "geo" : { },
  "id_str" : "514578008871419904",
  "in_reply_to_user_id" : 6326912,
  "text" : "@vogon @sarahjeong Can confirm this.",
  "id" : 514578008871419904,
  "in_reply_to_status_id" : 514577888847208448,
  "created_at" : "2014-09-24 00:52:12 +0000",
  "in_reply_to_screen_name" : "vogon",
  "in_reply_to_user_id_str" : "6326912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    }, {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 7, 18 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514564700852326400",
  "geo" : { },
  "id_str" : "514576718984527872",
  "in_reply_to_user_id" : 6326912,
  "text" : "@vogon @sarahjeong it's been absolutely horrible to watch as a former intern. unfollowed, blocked.",
  "id" : 514576718984527872,
  "in_reply_to_status_id" : 514564700852326400,
  "created_at" : "2014-09-24 00:47:04 +0000",
  "in_reply_to_screen_name" : "vogon",
  "in_reply_to_user_id_str" : "6326912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niagara Co.Fire Wire",
      "screen_name" : "NCfirewire",
      "indices" : [ 3, 14 ],
      "id_str" : "15285771",
      "id" : 15285771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514572904718036992",
  "text" : "RT @NCfirewire: Niagara Falls fire update : We are now at hour 78 and crews remain on scene working on hot spots",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514572786556477440",
    "text" : "Niagara Falls fire update : We are now at hour 78 and crews remain on scene working on hot spots",
    "id" : 514572786556477440,
    "created_at" : "2014-09-24 00:31:27 +0000",
    "user" : {
      "name" : "Niagara Co.Fire Wire",
      "screen_name" : "NCfirewire",
      "protected" : false,
      "id_str" : "15285771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3454686745\/3d4247c25ae3f9db113db7db7bcad4e9_normal.jpeg",
      "id" : 15285771,
      "verified" : false
    }
  },
  "id" : 514572904718036992,
  "created_at" : "2014-09-24 00:31:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 18, 28 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514570451931389952",
  "geo" : { },
  "id_str" : "514572089961902080",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev yeesh \/cc @zachwaugh",
  "id" : 514572089961902080,
  "in_reply_to_status_id" : 514570451931389952,
  "created_at" : "2014-09-24 00:28:41 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jQuery",
      "screen_name" : "jquery",
      "indices" : [ 0, 7 ],
      "id_str" : "14538601",
      "id" : 14538601
    }, {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 8, 18 ],
      "id_str" : "651373",
      "id" : 651373
    }, {
      "name" : "Saved You A Click",
      "screen_name" : "SavedYouAClick",
      "indices" : [ 27, 42 ],
      "id_str" : "2480079168",
      "id" : 2480079168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514571466793574401",
  "geo" : { },
  "id_str" : "514571993824260096",
  "in_reply_to_user_id" : 14538601,
  "text" : "@jquery @RedWolves No (\/cc @SavedYouAClick)",
  "id" : 514571993824260096,
  "in_reply_to_status_id" : 514571466793574401,
  "created_at" : "2014-09-24 00:28:18 +0000",
  "in_reply_to_screen_name" : "jquery",
  "in_reply_to_user_id_str" : "14538601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot(t)",
      "screen_name" : "elliottkember",
      "indices" : [ 0, 14 ],
      "id_str" : "903351",
      "id" : 903351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514571442633994240",
  "geo" : { },
  "id_str" : "514571890191388673",
  "in_reply_to_user_id" : 903351,
  "text" : "@elliottkember \u00AF\\_(\u30C4)_\/\u00AF - The Atlantic",
  "id" : 514571890191388673,
  "in_reply_to_status_id" : 514571442633994240,
  "created_at" : "2014-09-24 00:27:53 +0000",
  "in_reply_to_screen_name" : "elliottkember",
  "in_reply_to_user_id_str" : "903351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514569820604751872",
  "geo" : { },
  "id_str" : "514569971163095040",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev What change is this? This might be related to some issues I'm seeing",
  "id" : 514569971163095040,
  "in_reply_to_status_id" : 514569820604751872,
  "created_at" : "2014-09-24 00:20:16 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcy Laycock",
      "screen_name" : "Sutto",
      "indices" : [ 3, 9 ],
      "id_str" : "5099921",
      "id" : 5099921
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 11, 17 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514569741692719104",
  "text" : "RT @Sutto: @qrush I spent 2-3 days just fixing bugs. Most common case: Missing Autolayout Constraints, and random rounding issues from",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "514569389564104704",
    "geo" : { },
    "id_str" : "514569616375300096",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush I spent 2-3 days just fixing bugs. Most common case: Missing Autolayout Constraints, and random rounding issues from",
    "id" : 514569616375300096,
    "in_reply_to_status_id" : 514569389564104704,
    "created_at" : "2014-09-24 00:18:51 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Darcy Laycock",
      "screen_name" : "Sutto",
      "protected" : false,
      "id_str" : "5099921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451326949848129536\/ocEpp7Hs_normal.jpeg",
      "id" : 5099921,
      "verified" : false
    }
  },
  "id" : 514569741692719104,
  "created_at" : "2014-09-24 00:19:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514569505842798594",
  "text" : "And yes, been using autolayout. Doesn't mean you are immune from everything.",
  "id" : 514569505842798594,
  "created_at" : "2014-09-24 00:18:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514569389564104704",
  "text" : "If your app \"just worked\" after adding the new 6, 6+ launch images, congrats. Doubtful it'll be the case for most devs.",
  "id" : 514569389564104704,
  "created_at" : "2014-09-24 00:17:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514509647382732801",
  "text" : "iOS development just got as awful as web development did for dealing with multiple screen resolutions with 6, 6+. Just, awful.",
  "id" : 514509647382732801,
  "created_at" : "2014-09-23 20:20:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/pEmo9urhzA",
      "expanded_url" : "http:\/\/youtu.be\/50zL8TnMBN8",
      "display_url" : "youtu.be\/50zL8TnMBN8"
    }, {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/eXldmsJZNs",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514479610822529024",
  "text" : "RT @nickelcityruby: You know, this song is another enticement to make it to Buffalo for #ncrc14 - http:\/\/t.co\/pEmo9urhzA  - http:\/\/t.co\/eXl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/pEmo9urhzA",
        "expanded_url" : "http:\/\/youtu.be\/50zL8TnMBN8",
        "display_url" : "youtu.be\/50zL8TnMBN8"
      }, {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/eXldmsJZNs",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "514479003739381761",
    "text" : "You know, this song is another enticement to make it to Buffalo for #ncrc14 - http:\/\/t.co\/pEmo9urhzA  - http:\/\/t.co\/eXldmsJZNs",
    "id" : 514479003739381761,
    "created_at" : "2014-09-23 18:18:47 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 514479610822529024,
  "created_at" : "2014-09-23 18:21:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 13, 25 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Nuk1HfDgm0",
      "expanded_url" : "https:\/\/soundcloud.com\/unclephilsblog\/sets\/2014-07-04-aqueous-at-trips?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/unclephilsblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514434885629382656",
  "text" : "Fun set from @AqueousBand with quality audio, as always https:\/\/t.co\/Nuk1HfDgm0",
  "id" : 514434885629382656,
  "created_at" : "2014-09-23 15:23:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514421020657471488",
  "geo" : { },
  "id_str" : "514421166799212544",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik well dwarf fortress can be a TD, with enough traps and goblins",
  "id" : 514421166799212544,
  "in_reply_to_status_id" : 514421020657471488,
  "created_at" : "2014-09-23 14:28:58 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 48, 63 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/L6I9dw0vbM",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514398451933536256",
  "text" : "RT @kevinpurdy: My smart friends are working on @nickelcityruby, Oct. 3\/4. It's fun, whether you're Ruby-ish or not. http:\/\/t.co\/L6I9dw0vbM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 32, 47 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/L6I9dw0vbM",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "507260748201226240",
    "text" : "My smart friends are working on @nickelcityruby, Oct. 3\/4. It's fun, whether you're Ruby-ish or not. http:\/\/t.co\/L6I9dw0vbM",
    "id" : 507260748201226240,
    "created_at" : "2014-09-03 20:16:01 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 514398451933536256,
  "created_at" : "2014-09-23 12:58:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blithe Rocher",
      "screen_name" : "Blithe",
      "indices" : [ 3, 10 ],
      "id_str" : "6304322",
      "id" : 6304322
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/kYQKnjLv4p",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514398362099929088",
  "text" : "RT @Blithe: Really sad to be missing @nickelcityruby this year. Looks like it\u2019s going to be amazing. http:\/\/t.co\/kYQKnjLv4p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 25, 40 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/kYQKnjLv4p",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.6290945342, -90.2089697248 ]
    },
    "id_str" : "512272156630462464",
    "text" : "Really sad to be missing @nickelcityruby this year. Looks like it\u2019s going to be amazing. http:\/\/t.co\/kYQKnjLv4p",
    "id" : 512272156630462464,
    "created_at" : "2014-09-17 16:09:34 +0000",
    "user" : {
      "name" : "Blithe Rocher",
      "screen_name" : "Blithe",
      "protected" : false,
      "id_str" : "6304322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458955053814906880\/1dIp3MNa_normal.jpeg",
      "id" : 6304322,
      "verified" : false
    }
  },
  "id" : 514398362099929088,
  "created_at" : "2014-09-23 12:58:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Wheeler",
      "screen_name" : "benjiwheeler",
      "indices" : [ 0, 13 ],
      "id_str" : "14382523",
      "id" : 14382523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/NtRRojEyDa",
      "expanded_url" : "https:\/\/appsto.re\/us\/LDp32.i",
      "display_url" : "appsto.re\/us\/LDp32.i"
    } ]
  },
  "in_reply_to_status_id_str" : "514260364859809792",
  "geo" : { },
  "id_str" : "514260513530716160",
  "in_reply_to_user_id" : 14382523,
  "text" : "@benjiwheeler Laser Dog Super Mega Action Bundle by Laser Dog\nhttps:\/\/t.co\/NtRRojEyDa",
  "id" : 514260513530716160,
  "in_reply_to_status_id" : 514260364859809792,
  "created_at" : "2014-09-23 03:50:35 +0000",
  "in_reply_to_screen_name" : "benjiwheeler",
  "in_reply_to_user_id_str" : "14382523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 101, 114 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vRgd0eNr15",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dwarffortress\/comments\/2h5t7d\/psa_animals_not_breeding_they_might_be_asexual_or\/.compact",
      "display_url" : "reddit.com\/r\/dwarffortres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514260064538861568",
  "text" : "Domesticated animals in dwarf fortress might not breed due to asexual or homosexual orientations \/cc @dwarfort_txt  http:\/\/t.co\/vRgd0eNr15",
  "id" : 514260064538861568,
  "created_at" : "2014-09-23 03:48:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514258213730926594",
  "text" : "First time buying an App Bundle\u2026it\u2019s nice! Wondering what took so long for this to happen.",
  "id" : 514258213730926594,
  "created_at" : "2014-09-23 03:41:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/514257666718191616\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/NtTgtU4IKc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByMCn4MCAAEhGv7.jpg",
      "id_str" : "514257666571370497",
      "id" : 514257666571370497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByMCn4MCAAEhGv7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NtTgtU4IKc"
    } ],
    "hashtags" : [ {
      "text" : "aloneGame",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/wlum4EuBC6",
      "expanded_url" : "http:\/\/www.alone-game.com",
      "display_url" : "alone-game.com"
    }, {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/wlum4EuBC6",
      "expanded_url" : "http:\/\/www.alone-game.com",
      "display_url" : "alone-game.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514257666718191616",
  "text" : "I scored 3236M in Veteran mode! #aloneGame http:\/\/t.co\/wlum4EuBC6 http:\/\/t.co\/wlum4EuBC6 http:\/\/t.co\/NtTgtU4IKc",
  "id" : 514257666718191616,
  "created_at" : "2014-09-23 03:39:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/YkkzShGHP3",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/141781-save-hot-posts-in-r-gifs-to-gifs-folder-in-dropbox",
      "display_url" : "ifttt.com\/recipes\/141781\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "514131732287987712",
  "geo" : { },
  "id_str" : "514132589548802048",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier https:\/\/t.co\/YkkzShGHP3",
  "id" : 514132589548802048,
  "in_reply_to_status_id" : 514131732287987712,
  "created_at" : "2014-09-22 19:22:16 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514110746327015425",
  "geo" : { },
  "id_str" : "514125033686310912",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier I do have r\/gifs piping into my Dropbox :)",
  "id" : 514125033686310912,
  "in_reply_to_status_id" : 514110746327015425,
  "created_at" : "2014-09-22 18:52:14 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 24, 39 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 60, 75 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/lsOqpDkULY",
      "expanded_url" : "http:\/\/instagram.com\/p\/tQgi8hsOdy\/",
      "display_url" : "instagram.com\/p\/tQgi8hsOdy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "514120300980482050",
  "text" : "Possibly coming soon to @nickelcityruby attendees thanks to @PublicEspresso - http:\/\/t.co\/lsOqpDkULY",
  "id" : 514120300980482050,
  "created_at" : "2014-09-22 18:33:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514108456551583746",
  "geo" : { },
  "id_str" : "514108529431416832",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @coworkbuffalo 1",
  "id" : 514108529431416832,
  "in_reply_to_status_id" : 514108456551583746,
  "created_at" : "2014-09-22 17:46:39 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514107658593648640",
  "geo" : { },
  "id_str" : "514107799303766016",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham i've been debating this as construction has been dragging on here all summer",
  "id" : 514107799303766016,
  "in_reply_to_status_id" : 514107658593648640,
  "created_at" : "2014-09-22 17:43:45 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514106743060987904",
  "geo" : { },
  "id_str" : "514106917686231040",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen oh totally. do anything but actual work",
  "id" : 514106917686231040,
  "in_reply_to_status_id" : 514106743060987904,
  "created_at" : "2014-09-22 17:40:15 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/514106448544944128\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/44CCMN3pHX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByJ5FprCMAA879_.jpg",
      "id_str" : "514106445466316800",
      "id" : 514106445466316800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByJ5FprCMAA879_.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/44CCMN3pHX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514106448544944128",
  "text" : "Current count of dudes staring at the junction box: 11 http:\/\/t.co\/44CCMN3pHX",
  "id" : 514106448544944128,
  "created_at" : "2014-09-22 17:38:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/514103704689975297\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/LcXrhwtCqx",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ByJ2l2_CEAAVuig.png",
      "id_str" : "514103700260786176",
      "id" : 514103700260786176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ByJ2l2_CEAAVuig.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/LcXrhwtCqx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/KpOSZO0VC6",
      "expanded_url" : "https:\/\/github.com\/qrush\/kidsmash-mac",
      "display_url" : "github.com\/qrush\/kidsmash\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514103704689975297",
  "text" : "Fun little Swift game experiment from the weekend - https:\/\/t.co\/KpOSZO0VC6 http:\/\/t.co\/LcXrhwtCqx",
  "id" : 514103704689975297,
  "created_at" : "2014-09-22 17:27:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/514100635814199297\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/O8KhSZT6Zb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByJzzPgCUAAiSZi.jpg",
      "id_str" : "514100631645081600",
      "id" : 514100631645081600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByJzzPgCUAAiSZi.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/O8KhSZT6Zb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514100635814199297",
  "text" : "Current count of dudes staring at the junction box: 7 http:\/\/t.co\/O8KhSZT6Zb",
  "id" : 514100635814199297,
  "created_at" : "2014-09-22 17:15:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514080510847373312",
  "text" : "Fire in NF still going, getting close to 48 hours now.",
  "id" : 514080510847373312,
  "created_at" : "2014-09-22 15:55:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Mackenzie",
      "screen_name" : "mackesque",
      "indices" : [ 3, 13 ],
      "id_str" : "21399337",
      "id" : 21399337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/dFYp38TNiE",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514071993776226305",
  "text" : "RT @mackesque: If you can, you should go to http:\/\/t.co\/dFYp38TNiE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/dFYp38TNiE",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "512266604122370048",
    "text" : "If you can, you should go to http:\/\/t.co\/dFYp38TNiE",
    "id" : 512266604122370048,
    "created_at" : "2014-09-17 15:47:30 +0000",
    "user" : {
      "name" : "Jim Mackenzie",
      "screen_name" : "mackesque",
      "protected" : false,
      "id_str" : "21399337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526799615589249025\/idQeXGSk_normal.png",
      "id" : 21399337,
      "verified" : false
    }
  },
  "id" : 514071993776226305,
  "created_at" : "2014-09-22 15:21:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 3, 14 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/iI3IB6nLYI",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514071973341564928",
  "text" : "RT @jaytennier: And you don't need to know Ruby either. Trust me on this, I'd go if I could. http:\/\/t.co\/iI3IB6nLYI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/iI3IB6nLYI",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "512384822032216064",
    "text" : "And you don't need to know Ruby either. Trust me on this, I'd go if I could. http:\/\/t.co\/iI3IB6nLYI",
    "id" : 512384822032216064,
    "created_at" : "2014-09-17 23:37:15 +0000",
    "user" : {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "protected" : false,
      "id_str" : "15020118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428887276228067329\/L0TrLGr5_normal.jpeg",
      "id" : 15020118,
      "verified" : false
    }
  },
  "id" : 514071973341564928,
  "created_at" : "2014-09-22 15:21:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/p0Yc9pUdRS",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
      "display_url" : "nickelcityruby.com\/#register"
    } ]
  },
  "geo" : { },
  "id_str" : "514071952613724160",
  "text" : "RT @nickelcityruby: Have you grabbed your ticket for #ncrc14 yet?  Are you headed to the Code Retreat?  If not, time is running out!! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/p0Yc9pUdRS",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
        "display_url" : "nickelcityruby.com\/#register"
      } ]
    },
    "geo" : { },
    "id_str" : "514045662602993664",
    "text" : "Have you grabbed your ticket for #ncrc14 yet?  Are you headed to the Code Retreat?  If not, time is running out!! http:\/\/t.co\/p0Yc9pUdRS",
    "id" : 514045662602993664,
    "created_at" : "2014-09-22 13:36:51 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 514071952613724160,
  "created_at" : "2014-09-22 15:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514071632533413890",
  "text" : "If you haven't yet, and you're local to WNY, Toronto, PGH, anywhere Northeast, you're going to miss out - http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 514071632533413890,
  "created_at" : "2014-09-22 15:20:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 16, 31 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514071380346667010",
  "text" : "T-11 days until @nickelcityruby kicks off. Woot!",
  "id" : 514071380346667010,
  "created_at" : "2014-09-22 15:19:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abdelkader Boudih",
      "screen_name" : "IchThain",
      "indices" : [ 0, 9 ],
      "id_str" : "1244397780",
      "id" : 1244397780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514047083775811584",
  "geo" : { },
  "id_str" : "514047309370228736",
  "in_reply_to_user_id" : 1244397780,
  "text" : "@IchThain I think the rubygems team needs to have a policy on that first\u2026can you post about this to the .org google group?",
  "id" : 514047309370228736,
  "in_reply_to_status_id" : 514047083775811584,
  "created_at" : "2014-09-22 13:43:23 +0000",
  "in_reply_to_screen_name" : "IchThain",
  "in_reply_to_user_id_str" : "1244397780",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abdelkader Boudih",
      "screen_name" : "IchThain",
      "indices" : [ 0, 9 ],
      "id_str" : "1244397780",
      "id" : 1244397780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514046315312201728",
  "geo" : { },
  "id_str" : "514046418663653376",
  "in_reply_to_user_id" : 1244397780,
  "text" : "@IchThain awful.",
  "id" : 514046418663653376,
  "in_reply_to_status_id" : 514046315312201728,
  "created_at" : "2014-09-22 13:39:51 +0000",
  "in_reply_to_screen_name" : "IchThain",
  "in_reply_to_user_id_str" : "1244397780",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    }, {
      "name" : "Erie County, NY",
      "screen_name" : "ErieCountyNY",
      "indices" : [ 136, 140 ],
      "id_str" : "2776817201",
      "id" : 2776817201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514034892426838017",
  "text" : "RT @markpoloncarz: There is now an official Erie County, NY twitter page for all of our departments. Get the latest from county govt at @Er\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erie County, NY",
        "screen_name" : "ErieCountyNY",
        "indices" : [ 117, 130 ],
        "id_str" : "2776817201",
        "id" : 2776817201
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514032525568913408",
    "text" : "There is now an official Erie County, NY twitter page for all of our departments. Get the latest from county govt at @ErieCountyNY",
    "id" : 514032525568913408,
    "created_at" : "2014-09-22 12:44:39 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 514034892426838017,
  "created_at" : "2014-09-22 12:54:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Poland",
      "screen_name" : "tylerpoland",
      "indices" : [ 3, 15 ],
      "id_str" : "56105138",
      "id" : 56105138
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 58, 73 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/6IvxqotAbu",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "514026674015318016",
  "text" : "RT @tylerpoland: Hello World! I just picked up my pass to @nickelcityruby; will I see you there: http:\/\/t.co\/6IvxqotAbu ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 41, 56 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/6IvxqotAbu",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "512966380132773889",
    "text" : "Hello World! I just picked up my pass to @nickelcityruby; will I see you there: http:\/\/t.co\/6IvxqotAbu ?",
    "id" : 512966380132773889,
    "created_at" : "2014-09-19 14:08:10 +0000",
    "user" : {
      "name" : "Tyler Poland",
      "screen_name" : "tylerpoland",
      "protected" : false,
      "id_str" : "56105138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2792814035\/25484d17e0b868d203c6ae044e8aa109_normal.png",
      "id" : 56105138,
      "verified" : false
    }
  },
  "id" : 514026674015318016,
  "created_at" : "2014-09-22 12:21:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 3, 15 ],
      "id_str" : "9526722",
      "id" : 9526722
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 109, 124 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514026634970542080",
  "text" : "RT @CoralineAda: I\u2019m putting the finishing touches on my new \u201CAesthetics and the Evolution of Code\u201D talk for @nickelcityruby. Not long now!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 92, 107 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513896072381743104",
    "text" : "I\u2019m putting the finishing touches on my new \u201CAesthetics and the Evolution of Code\u201D talk for @nickelcityruby. Not long now!",
    "id" : 513896072381743104,
    "created_at" : "2014-09-22 03:42:26 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 514026634970542080,
  "created_at" : "2014-09-22 12:21:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513885079471669248",
  "geo" : { },
  "id_str" : "513885295314350080",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik i am convinced you are in some lucid dream and not on a bus",
  "id" : 513885295314350080,
  "in_reply_to_status_id" : 513885079471669248,
  "created_at" : "2014-09-22 02:59:36 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513884535381950464",
  "geo" : { },
  "id_str" : "513885115030585345",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini yeah the web version didn't cut it anymore. Can I do a Kickstarter for $99 to pay Apple?",
  "id" : 513885115030585345,
  "in_reply_to_status_id" : 513884535381950464,
  "created_at" : "2014-09-22 02:58:53 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/KpOSZO0VC6",
      "expanded_url" : "https:\/\/github.com\/qrush\/kidsmash-mac",
      "display_url" : "github.com\/qrush\/kidsmash\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513880917589241856",
  "text" : "Published my little Swift experiment from this weekend, if you have tiny hands that like to smash keyboards https:\/\/t.co\/KpOSZO0VC6",
  "id" : 513880917589241856,
  "created_at" : "2014-09-22 02:42:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513814991108333569",
  "geo" : { },
  "id_str" : "513816776476332035",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo or documentation :trollface:",
  "id" : 513816776476332035,
  "in_reply_to_status_id" : 513814991108333569,
  "created_at" : "2014-09-21 22:27:20 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niagara Co.Fire Wire",
      "screen_name" : "NCfirewire",
      "indices" : [ 3, 14 ],
      "id_str" : "15285771",
      "id" : 15285771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513816556870959105",
  "text" : "RT @NCfirewire: Niagara Falls E5 &amp; E8 requested back to the the scene to help with a  new flare up",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513816282228350976",
    "text" : "Niagara Falls E5 &amp; E8 requested back to the the scene to help with a  new flare up",
    "id" : 513816282228350976,
    "created_at" : "2014-09-21 22:25:22 +0000",
    "user" : {
      "name" : "Niagara Co.Fire Wire",
      "screen_name" : "NCfirewire",
      "protected" : false,
      "id_str" : "15285771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3454686745\/3d4247c25ae3f9db113db7db7bcad4e9_normal.jpeg",
      "id" : 15285771,
      "verified" : false
    }
  },
  "id" : 513816556870959105,
  "created_at" : "2014-09-21 22:26:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "jlsmp",
      "indices" : [ 0, 6 ],
      "id_str" : "1856037409",
      "id" : 1856037409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513808637266264064",
  "geo" : { },
  "id_str" : "513808903549616128",
  "in_reply_to_user_id" : 1856037409,
  "text" : "@jlsmp the web version is processing.js!",
  "id" : 513808903549616128,
  "in_reply_to_status_id" : 513808637266264064,
  "created_at" : "2014-09-21 21:56:03 +0000",
  "in_reply_to_screen_name" : "jlsmp",
  "in_reply_to_user_id_str" : "1856037409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Chung",
      "screen_name" : "iamwil",
      "indices" : [ 0, 7 ],
      "id_str" : "9162442",
      "id" : 9162442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/eWRPlpBKuu",
      "expanded_url" : "http:\/\/quaran.to\/kidsmash",
      "display_url" : "quaran.to\/kidsmash"
    } ]
  },
  "in_reply_to_status_id_str" : "513806466403164160",
  "geo" : { },
  "id_str" : "513807755098873856",
  "in_reply_to_user_id" : 9162442,
  "text" : "@iamwil http:\/\/t.co\/eWRPlpBKuu building a Mac app version",
  "id" : 513807755098873856,
  "in_reply_to_status_id" : 513806466403164160,
  "created_at" : "2014-09-21 21:51:29 +0000",
  "in_reply_to_screen_name" : "iamwil",
  "in_reply_to_user_id_str" : "9162442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513803345233207297",
  "geo" : { },
  "id_str" : "513804764425895936",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss also up for beta testing once I figure how bad the new TF is?",
  "id" : 513804764425895936,
  "in_reply_to_status_id" : 513803345233207297,
  "created_at" : "2014-09-21 21:39:36 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513803345233207297",
  "geo" : { },
  "id_str" : "513803999389048833",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss pointer is a SKSprite, faces are SKShapes.",
  "id" : 513803999389048833,
  "in_reply_to_status_id" : 513803345233207297,
  "created_at" : "2014-09-21 21:36:34 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/513803728403431424\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/60m59drLKd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByFlxH_CAAA2OtK.jpg",
      "id_str" : "513803727128363008",
      "id" : 513803727128363008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByFlxH_CAAA2OtK.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/60m59drLKd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513803728403431424",
  "text" : "Faces on the shapes is just the best. http:\/\/t.co\/60m59drLKd",
  "id" : 513803728403431424,
  "created_at" : "2014-09-21 21:35:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/513791546152349696\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/euccvDRCF3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByFasCUCYAISYly.jpg",
      "id_str" : "513791545078603778",
      "id" : 513791545078603778,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByFasCUCYAISYly.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/euccvDRCF3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513791546152349696",
  "text" : "KidSmash continues to evolve. Shapes, pointer, letters in. http:\/\/t.co\/euccvDRCF3",
  "id" : 513791546152349696,
  "created_at" : "2014-09-21 20:47:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513767793229983745",
  "text" : "Over 24 hours later and the fire in Niagara Falls is still going. Wind picked up and rain never showed up :(",
  "id" : 513767793229983745,
  "created_at" : "2014-09-21 19:12:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "indices" : [ 0, 14 ],
      "id_str" : "543918403",
      "id" : 543918403
    }, {
      "name" : "sweet michael",
      "screen_name" : "michaeljhudson",
      "indices" : [ 38, 53 ],
      "id_str" : "35050151",
      "id" : 35050151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513746243403538432",
  "geo" : { },
  "id_str" : "513747437635108865",
  "in_reply_to_user_id" : 543918403,
  "text" : "@TheDefenseman here\u2019s another one for @michaeljhudson, fits right in",
  "id" : 513747437635108865,
  "in_reply_to_status_id" : 513746243403538432,
  "created_at" : "2014-09-21 17:51:48 +0000",
  "in_reply_to_screen_name" : "TheDefenseman",
  "in_reply_to_user_id_str" : "543918403",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513744491019124736",
  "text" : "RT @vrunt: please god what the hell did i do to deserve all this *flashback to 12 years ago when i threw a flashbang at my own team in Coun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386914281952133120",
    "text" : "please god what the hell did i do to deserve all this *flashback to 12 years ago when i threw a flashbang at my own team in CounterStrike*",
    "id" : 386914281952133120,
    "created_at" : "2013-10-06 18:02:08 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 513744491019124736,
  "created_at" : "2014-09-21 17:40:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bucky Isotope",
      "screen_name" : "BuckyIsotope",
      "indices" : [ 3, 16 ],
      "id_str" : "402181679",
      "id" : 402181679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513739040151986176",
  "text" : "RT @BuckyIsotope: Squirtle\nPikachu\nSquirtle\nPikachu\nSQUIRTLE\nPIKACHU\nSQUIRTLE!!!\nPIKACHU!!!\n\n-Pokemon arguing in a comments section about i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513735124513353728",
    "text" : "Squirtle\nPikachu\nSquirtle\nPikachu\nSQUIRTLE\nPIKACHU\nSQUIRTLE!!!\nPIKACHU!!!\n\n-Pokemon arguing in a comments section about impeaching Obama",
    "id" : 513735124513353728,
    "created_at" : "2014-09-21 17:02:53 +0000",
    "user" : {
      "name" : "Bucky Isotope",
      "screen_name" : "BuckyIsotope",
      "protected" : false,
      "id_str" : "402181679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571749048715091968\/tjdQByeC_normal.jpeg",
      "id" : 402181679,
      "verified" : false
    }
  },
  "id" : 513739040151986176,
  "created_at" : "2014-09-21 17:18:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 3, 8 ],
      "id_str" : "20612109",
      "id" : 20612109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/tt4BpxKnfF",
      "expanded_url" : "http:\/\/bit.ly\/XTXiz3",
      "display_url" : "bit.ly\/XTXiz3"
    } ]
  },
  "geo" : { },
  "id_str" : "513731045569482753",
  "text" : "RT @WBFO: Fire in Falls finally under control: Windy conditions helped turn a Niagara Falls industrial fire into a chall... http:\/\/t.co\/tt4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/tt4BpxKnfF",
        "expanded_url" : "http:\/\/bit.ly\/XTXiz3",
        "display_url" : "bit.ly\/XTXiz3"
      } ]
    },
    "geo" : { },
    "id_str" : "513730227827003392",
    "text" : "Fire in Falls finally under control: Windy conditions helped turn a Niagara Falls industrial fire into a chall... http:\/\/t.co\/tt4BpxKnfF",
    "id" : 513730227827003392,
    "created_at" : "2014-09-21 16:43:25 +0000",
    "user" : {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "protected" : false,
      "id_str" : "20612109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458688569347801088\/UcIrcXjC_normal.jpeg",
      "id" : 20612109,
      "verified" : false
    }
  },
  "id" : 513731045569482753,
  "created_at" : "2014-09-21 16:46:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513730331392737280",
  "text" : "RT @TweetsofOld: Never boil coffee. Always drip it. A person who will boil coffee will eat with their knife or commit some other mortal sin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513726822044151809",
    "text" : "Never boil coffee. Always drip it. A person who will boil coffee will eat with their knife or commit some other mortal sin. TX1889",
    "id" : 513726822044151809,
    "created_at" : "2014-09-21 16:29:53 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 513730331392737280,
  "created_at" : "2014-09-21 16:43:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513684481623228416",
  "geo" : { },
  "id_str" : "513684821554388992",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos hahaha. No worries \uD83D\uDE01",
  "id" : 513684821554388992,
  "in_reply_to_status_id" : 513684481623228416,
  "created_at" : "2014-09-21 13:42:59 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513683483613741056",
  "geo" : { },
  "id_str" : "513684198058512388",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos if you are playing KB today and up for a toddler running amok let me know :)",
  "id" : 513684198058512388,
  "in_reply_to_status_id" : 513683483613741056,
  "created_at" : "2014-09-21 13:40:31 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513683483613741056",
  "geo" : { },
  "id_str" : "513683966201581569",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos I have had people cry in Agricola because they can\u2019t feed their family. Game Center ID is quaranto",
  "id" : 513683966201581569,
  "in_reply_to_status_id" : 513683483613741056,
  "created_at" : "2014-09-21 13:39:35 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513681108492648448",
  "geo" : { },
  "id_str" : "513683239391612929",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos would happily teach the former 2. Love agricola. Want to pick up Ora et Labora too.",
  "id" : 513683239391612929,
  "in_reply_to_status_id" : 513681108492648448,
  "created_at" : "2014-09-21 13:36:42 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Collin",
      "screen_name" : "robbiereviews",
      "indices" : [ 3, 17 ],
      "id_str" : "17835068",
      "id" : 17835068
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/robbiereviews\/status\/513242916383645697\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/SfCG9ibruF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx9ntjBIMAAJihy.jpg",
      "id_str" : "513242914735271936",
      "id" : 513242914735271936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx9ntjBIMAAJihy.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SfCG9ibruF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513683060592627712",
  "text" : "RT @robbiereviews: There's something troubling about this book's tone http:\/\/t.co\/SfCG9ibruF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/robbiereviews\/status\/513242916383645697\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/SfCG9ibruF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx9ntjBIMAAJihy.jpg",
        "id_str" : "513242914735271936",
        "id" : 513242914735271936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx9ntjBIMAAJihy.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/SfCG9ibruF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513242916383645697",
    "text" : "There's something troubling about this book's tone http:\/\/t.co\/SfCG9ibruF",
    "id" : 513242916383645697,
    "created_at" : "2014-09-20 08:27:01 +0000",
    "user" : {
      "name" : "Robbie Collin",
      "screen_name" : "robbiereviews",
      "protected" : false,
      "id_str" : "17835068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492625785329442816\/UvAPpyQX_normal.jpeg",
      "id" : 17835068,
      "verified" : true
    }
  },
  "id" : 513683060592627712,
  "created_at" : "2014-09-21 13:36:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513676862690951168",
  "geo" : { },
  "id_str" : "513677072581918720",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh Step into the freezer \u2611\uFE0F",
  "id" : 513677072581918720,
  "in_reply_to_status_id" : 513676862690951168,
  "created_at" : "2014-09-21 13:12:12 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513676285487636480",
  "geo" : { },
  "id_str" : "513676674722828288",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos it\u2019s fantastic. Quick too.",
  "id" : 513676674722828288,
  "in_reply_to_status_id" : 513676285487636480,
  "created_at" : "2014-09-21 13:10:37 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513674774468624384",
  "geo" : { },
  "id_str" : "513676029047496705",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos Agricola, Settlers, or Carcassone?",
  "id" : 513676029047496705,
  "in_reply_to_status_id" : 513674774468624384,
  "created_at" : "2014-09-21 13:08:03 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Ly",
      "screen_name" : "HeatherLyWGRZ",
      "indices" : [ 3, 17 ],
      "id_str" : "404788027",
      "id" : 404788027
    }, {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "indices" : [ 139, 140 ],
      "id_str" : "15308015",
      "id" : 15308015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NiagaraFalls",
      "indices" : [ 19, 32 ]
    }, {
      "text" : "Greenpac",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513665857327611904",
  "text" : "RT @HeatherLyWGRZ: #NiagaraFalls firefighters say it could be a day or more before #Greenpac fire is fully out. Worried about embers sparki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WGRZ",
        "screen_name" : "WGRZ",
        "indices" : [ 134, 139 ],
        "id_str" : "15308015",
        "id" : 15308015
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NiagaraFalls",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "Greenpac",
        "indices" : [ 64, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513642825024819200",
    "text" : "#NiagaraFalls firefighters say it could be a day or more before #Greenpac fire is fully out. Worried about embers sparking more fires @WGRZ",
    "id" : 513642825024819200,
    "created_at" : "2014-09-21 10:56:07 +0000",
    "user" : {
      "name" : "Heather Ly",
      "screen_name" : "HeatherLyWGRZ",
      "protected" : false,
      "id_str" : "404788027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571446132582326273\/j8buJc2o_normal.jpeg",
      "id" : 404788027,
      "verified" : true
    }
  },
  "id" : 513665857327611904,
  "created_at" : "2014-09-21 12:27:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radek",
      "screen_name" : "radexp",
      "indices" : [ 0, 7 ],
      "id_str" : "107770370",
      "id" : 107770370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513664504467832832",
  "geo" : { },
  "id_str" : "513665589529681921",
  "in_reply_to_user_id" : 107770370,
  "text" : "@radexp it\u2019s possible to treat any Cocoa API as a third party now that Swift has its own native types. Perfect to fence off and forget",
  "id" : 513665589529681921,
  "in_reply_to_status_id" : 513664504467832832,
  "created_at" : "2014-09-21 12:26:34 +0000",
  "in_reply_to_screen_name" : "radexp",
  "in_reply_to_user_id_str" : "107770370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Harty",
      "screen_name" : "Ebscer",
      "indices" : [ 3, 10 ],
      "id_str" : "13324802",
      "id" : 13324802
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 98, 113 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/KG3pb91IZM",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "513664168499494915",
  "text" : "RT @Ebscer: If you are looking to do something the first weekend of October you should join me at @nickelcityruby Details at http:\/\/t.co\/KG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 86, 101 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KG3pb91IZM",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "513082547199557634",
    "text" : "If you are looking to do something the first weekend of October you should join me at @nickelcityruby Details at http:\/\/t.co\/KG3pb91IZM",
    "id" : 513082547199557634,
    "created_at" : "2014-09-19 21:49:46 +0000",
    "user" : {
      "name" : "Eric Harty",
      "screen_name" : "Ebscer",
      "protected" : false,
      "id_str" : "13324802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140388192\/Biglogo_normal.png",
      "id" : 13324802,
      "verified" : false
    }
  },
  "id" : 513664168499494915,
  "created_at" : "2014-09-21 12:20:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513664021900177410",
  "text" : "The interface between the two and how badly they are muddled will be a huge factor going forward for all iOS\/OSX apps",
  "id" : 513664021900177410,
  "created_at" : "2014-09-21 12:20:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513663836696485888",
  "text" : "Another Swift lesson: it feels cleaner to stay in Swift types than Cocoa.",
  "id" : 513663836696485888,
  "created_at" : "2014-09-21 12:19:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513663079675355136",
  "geo" : { },
  "id_str" : "513663656622444544",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh ah cool. Will try that.",
  "id" : 513663656622444544,
  "in_reply_to_status_id" : 513663079675355136,
  "created_at" : "2014-09-21 12:18:53 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Ly",
      "screen_name" : "HeatherLyWGRZ",
      "indices" : [ 3, 17 ],
      "id_str" : "404788027",
      "id" : 404788027
    }, {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "indices" : [ 139, 140 ],
      "id_str" : "15308015",
      "id" : 15308015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NiagaraFalls",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513652630816452610",
  "text" : "RT @HeatherLyWGRZ: 80 firefighters still on scene of massive fire at Greenpac in #NiagaraFalls Paper\/cardboard bales burning since 2:30p Sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WGRZ",
        "screen_name" : "WGRZ",
        "indices" : [ 128, 133 ],
        "id_str" : "15308015",
        "id" : 15308015
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NiagaraFalls",
        "indices" : [ 62, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513638744499707904",
    "text" : "80 firefighters still on scene of massive fire at Greenpac in #NiagaraFalls Paper\/cardboard bales burning since 2:30p Saturday. @WGRZ",
    "id" : 513638744499707904,
    "created_at" : "2014-09-21 10:39:54 +0000",
    "user" : {
      "name" : "Heather Ly",
      "screen_name" : "HeatherLyWGRZ",
      "protected" : false,
      "id_str" : "404788027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571446132582326273\/j8buJc2o_normal.jpeg",
      "id" : 404788027,
      "verified" : true
    }
  },
  "id" : 513652630816452610,
  "created_at" : "2014-09-21 11:35:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Tqi9UOMxbp",
      "expanded_url" : "http:\/\/thenounproject.com\/term\/childbirth\/27245\/",
      "display_url" : "thenounproject.com\/term\/childbirt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513565583086874625",
  "text" : "This icon attempts to accurately depict childbirth http:\/\/t.co\/Tqi9UOMxbp",
  "id" : 513565583086874625,
  "created_at" : "2014-09-21 05:49:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513559886148292609",
  "text" : "Concise lambdas are *wonderful* in Swift. Quick little example on an Array&lt;String&gt; to join: var word = history.reduce(\"\") \u007B $0 + $1 \u007D",
  "id" : 513559886148292609,
  "created_at" : "2014-09-21 05:26:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/513550382048354304\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/XZyxNQY3OH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByB_WchCYAEsXmz.jpg",
      "id_str" : "513550381108846593",
      "id" : 513550381108846593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByB_WchCYAEsXmz.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/XZyxNQY3OH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/eWRPlpBKuu",
      "expanded_url" : "http:\/\/quaran.to\/kidsmash",
      "display_url" : "quaran.to\/kidsmash"
    } ]
  },
  "geo" : { },
  "id_str" : "513550382048354304",
  "text" : "Learning Swift by reimplmenting http:\/\/t.co\/eWRPlpBKuu in SpriteKit. Fun and mind-bending. http:\/\/t.co\/XZyxNQY3OH",
  "id" : 513550382048354304,
  "created_at" : "2014-09-21 04:48:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "indices" : [ 3, 14 ],
      "id_str" : "982762350",
      "id" : 982762350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NWSBUFFALO\/status\/513429125550194688\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/drgr3Tj1Rj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByAREYsCAAAuZzH.png",
      "id_str" : "513429124564516864",
      "id" : 513429124564516864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByAREYsCAAAuZzH.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/drgr3Tj1Rj"
    } ],
    "hashtags" : [ {
      "text" : "fire",
      "indices" : [ 41, 46 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "radar",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "bufwx",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513534675738849281",
  "text" : "RT @NWSBUFFALO: Smoke plume from a large #fire in Niagara Falls Saturday afternoon as detected by #Buffalo weather #radar. #bufwx http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NWSBUFFALO\/status\/513429125550194688\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/drgr3Tj1Rj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByAREYsCAAAuZzH.png",
        "id_str" : "513429124564516864",
        "id" : 513429124564516864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByAREYsCAAAuZzH.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/drgr3Tj1Rj"
      } ],
      "hashtags" : [ {
        "text" : "fire",
        "indices" : [ 25, 30 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "radar",
        "indices" : [ 99, 105 ]
      }, {
        "text" : "bufwx",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513429125550194688",
    "text" : "Smoke plume from a large #fire in Niagara Falls Saturday afternoon as detected by #Buffalo weather #radar. #bufwx http:\/\/t.co\/drgr3Tj1Rj",
    "id" : 513429125550194688,
    "created_at" : "2014-09-20 20:46:57 +0000",
    "user" : {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "protected" : false,
      "id_str" : "982762350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465137770696957952\/-6l64r-b_normal.jpeg",
      "id" : 982762350,
      "verified" : true
    }
  },
  "id" : 513534675738849281,
  "created_at" : "2014-09-21 03:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/FjGdGbTQwh",
      "expanded_url" : "https:\/\/www.facebook.com\/video.php?v=692470264154561&set=vb.453173798084210&type=2&theater",
      "display_url" : "facebook.com\/video.php?v=69\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513532953477926912",
  "text" : "Video of the bales burning - holy shit. https:\/\/t.co\/FjGdGbTQwh",
  "id" : 513532953477926912,
  "created_at" : "2014-09-21 03:39:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/J7uATXBnd4",
      "expanded_url" : "https:\/\/www.facebook.com\/media\/set\/?set=a.692476507487270.1073741946.453173798084210&type=1",
      "display_url" : "facebook.com\/media\/set\/?set\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513532023974023168",
  "text" : "My dad's fighting an awful fire at a paper recycling plant tonight in Niagara Falls. Been burning for ~12 hours. https:\/\/t.co\/J7uATXBnd4",
  "id" : 513532023974023168,
  "created_at" : "2014-09-21 03:35:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Squeaky Wheel",
      "screen_name" : "squeakybuffalo",
      "indices" : [ 37, 52 ],
      "id_str" : "104226970",
      "id" : 104226970
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/513332958892015616\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zYA45LLT5o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx-5myiCEAA-C4V.jpg",
      "id_str" : "513332958594207744",
      "id" : 513332958594207744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx-5myiCEAA-C4V.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zYA45LLT5o"
    } ],
    "hashtags" : [ {
      "text" : "30on30",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513480182166863872",
  "text" : "RT @coworkbuffalo: Inside hour 18 of @squeakybuffalo's #30on30 fundraiser. Currently: yoga, chill out, coffee. http:\/\/t.co\/zYA45LLT5o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Squeaky Wheel",
        "screen_name" : "squeakybuffalo",
        "indices" : [ 18, 33 ],
        "id_str" : "104226970",
        "id" : 104226970
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/513332958892015616\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/zYA45LLT5o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx-5myiCEAA-C4V.jpg",
        "id_str" : "513332958594207744",
        "id" : 513332958594207744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx-5myiCEAA-C4V.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zYA45LLT5o"
      } ],
      "hashtags" : [ {
        "text" : "30on30",
        "indices" : [ 36, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513332958892015616",
    "text" : "Inside hour 18 of @squeakybuffalo's #30on30 fundraiser. Currently: yoga, chill out, coffee. http:\/\/t.co\/zYA45LLT5o",
    "id" : 513332958892015616,
    "created_at" : "2014-09-20 14:24:49 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 513480182166863872,
  "created_at" : "2014-09-21 00:09:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denny's",
      "screen_name" : "DennysDiner",
      "indices" : [ 3, 15 ],
      "id_str" : "23112346",
      "id" : 23112346
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DennysDiner\/status\/513377550530523136\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/lnr63ShRWJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx_iKXrIUAA09q0.jpg",
      "id_str" : "513377550325010432",
      "id" : 513377550325010432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx_iKXrIUAA09q0.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/lnr63ShRWJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513383677925920768",
  "text" : "RT @DennysDiner: *sigh* hi, welcome to goth denny's. i'm your server, raven, you can like, sit down or something *sigh* http:\/\/t.co\/lnr63Sh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DennysDiner\/status\/513377550530523136\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/lnr63ShRWJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx_iKXrIUAA09q0.jpg",
        "id_str" : "513377550325010432",
        "id" : 513377550325010432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx_iKXrIUAA09q0.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/lnr63ShRWJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513377550530523136",
    "text" : "*sigh* hi, welcome to goth denny's. i'm your server, raven, you can like, sit down or something *sigh* http:\/\/t.co\/lnr63ShRWJ",
    "id" : 513377550530523136,
    "created_at" : "2014-09-20 17:22:00 +0000",
    "user" : {
      "name" : "Denny's",
      "screen_name" : "DennysDiner",
      "protected" : false,
      "id_str" : "23112346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558638271891136513\/D8hJKugG_normal.jpeg",
      "id" : 23112346,
      "verified" : true
    }
  },
  "id" : 513383677925920768,
  "created_at" : "2014-09-20 17:46:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "basic derek",
      "screen_name" : "djbender",
      "indices" : [ 0, 9 ],
      "id_str" : "14161178",
      "id" : 14161178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513343690937352192",
  "geo" : { },
  "id_str" : "513344100708282368",
  "in_reply_to_user_id" : 14161178,
  "text" : "@djbender that seems to be for total backups. this is just photos. Dropbox is already the backup, this is cold storage",
  "id" : 513344100708282368,
  "in_reply_to_status_id" : 513343690937352192,
  "created_at" : "2014-09-20 15:09:05 +0000",
  "in_reply_to_screen_name" : "djbender",
  "in_reply_to_user_id_str" : "14161178",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/oLfW45KOvZ",
      "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014?discount_code=NCR_r00k",
      "display_url" : "ti.to\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513343791848103936",
  "text" : "RT @r00k: Wanna see me keynote at Nickel City Ruby? Okay, fine. How about if it's 20% off? https:\/\/t.co\/oLfW45KOvZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/oLfW45KOvZ",
        "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014?discount_code=NCR_r00k",
        "display_url" : "ti.to\/nickelcityruby\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513053086928367616",
    "text" : "Wanna see me keynote at Nickel City Ruby? Okay, fine. How about if it's 20% off? https:\/\/t.co\/oLfW45KOvZ",
    "id" : 513053086928367616,
    "created_at" : "2014-09-19 19:52:42 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 513343791848103936,
  "created_at" : "2014-09-20 15:07:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513343426197078016",
  "text" : "Finally getting a second backup of photos going on Glacier. Transmit makes this easy but it's manual. I wish IFTTT supported S3.",
  "id" : 513343426197078016,
  "created_at" : "2014-09-20 15:06:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Neistat",
      "screen_name" : "CaseyNeistat",
      "indices" : [ 3, 16 ],
      "id_str" : "154221292",
      "id" : 154221292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/KnS8KAYrwE",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Ef_BznBwktw",
      "display_url" : "youtube.com\/watch?v=Ef_Bzn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513330792273944577",
  "text" : "RT @CaseyNeistat: My new movie.  it's hard to watch and makes me very sad -- iPhone 6 Lines and the Chinese Mafia - https:\/\/t.co\/KnS8KAYrwE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/KnS8KAYrwE",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Ef_BznBwktw",
        "display_url" : "youtube.com\/watch?v=Ef_Bzn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513302046670610432",
    "text" : "My new movie.  it's hard to watch and makes me very sad -- iPhone 6 Lines and the Chinese Mafia - https:\/\/t.co\/KnS8KAYrwE",
    "id" : 513302046670610432,
    "created_at" : "2014-09-20 12:21:59 +0000",
    "user" : {
      "name" : "Casey Neistat",
      "screen_name" : "CaseyNeistat",
      "protected" : false,
      "id_str" : "154221292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481123524329734146\/jk4aTqws_normal.png",
      "id" : 154221292,
      "verified" : true
    }
  },
  "id" : 513330792273944577,
  "created_at" : "2014-09-20 14:16:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513311235668860928",
  "text" : "RT @rubygems_status: Our DNS provider is experiencing a DDoS attack. They are working hard to mitigate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513309288811360256",
    "text" : "Our DNS provider is experiencing a DDoS attack. They are working hard to mitigate.",
    "id" : 513309288811360256,
    "created_at" : "2014-09-20 12:50:45 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 513311235668860928,
  "created_at" : "2014-09-20 12:58:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513311214538342401",
  "text" : "RT @rubygems_status: If you need immediate access, you can try 54.186.104.15. Please remember this may change in the future.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513309877247021056",
    "text" : "If you need immediate access, you can try 54.186.104.15. Please remember this may change in the future.",
    "id" : 513309877247021056,
    "created_at" : "2014-09-20 12:53:06 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 513311214538342401,
  "created_at" : "2014-09-20 12:58:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 3, 9 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 11, 17 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 18, 27 ],
      "id_str" : "148198686",
      "id" : 148198686
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 28, 39 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 40, 52 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513302098562150400",
  "text" : "RT @aeden: @qrush @dnsimple @samkottler @dwradcliffe yes, it is affecting all of our name servers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "DNSimple",
        "screen_name" : "dnsimple",
        "indices" : [ 7, 16 ],
        "id_str" : "148198686",
        "id" : 148198686
      }, {
        "name" : "Sam Kottler",
        "screen_name" : "samkottler",
        "indices" : [ 17, 28 ],
        "id_str" : "103914540",
        "id" : 103914540
      }, {
        "name" : "David Radcliffe",
        "screen_name" : "dwradcliffe",
        "indices" : [ 29, 41 ],
        "id_str" : "19627341",
        "id" : 19627341
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "513301096857477120",
    "geo" : { },
    "id_str" : "513301984657801218",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @dnsimple @samkottler @dwradcliffe yes, it is affecting all of our name servers",
    "id" : 513301984657801218,
    "in_reply_to_status_id" : 513301096857477120,
    "created_at" : "2014-09-20 12:21:44 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "protected" : false,
      "id_str" : "18673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2563132054\/E0DA531E-B898-4E2D-BDEE-872F91795912_normal",
      "id" : 18673,
      "verified" : false
    }
  },
  "id" : 513302098562150400,
  "created_at" : "2014-09-20 12:22:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513301559698919425",
  "text" : "Seems like http:\/\/t.co\/2bA9BVLhWr might be having DNS trouble. Sorry everyone.",
  "id" : 513301559698919425,
  "created_at" : "2014-09-20 12:20:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 0, 9 ],
      "id_str" : "148198686",
      "id" : 148198686
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 68, 74 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 75, 86 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 87, 99 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "513287346889175040",
  "geo" : { },
  "id_str" : "513301096857477120",
  "in_reply_to_user_id" : 148198686,
  "text" : "@dnsimple any idea if this is affecting http:\/\/t.co\/2bA9BVLhWr? \/cc @aeden @samkottler @dwradcliffe getting lots of pingdom alerts",
  "id" : 513301096857477120,
  "in_reply_to_status_id" : 513287346889175040,
  "created_at" : "2014-09-20 12:18:12 +0000",
  "in_reply_to_screen_name" : "dnsimple",
  "in_reply_to_user_id_str" : "148198686",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513288334396112896",
  "geo" : { },
  "id_str" : "513291876728721408",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik damn.",
  "id" : 513291876728721408,
  "in_reply_to_status_id" : 513288334396112896,
  "created_at" : "2014-09-20 11:41:34 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ZleoIWX2TT",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2014\/09\/19\/travel\/reif-larsen-norway.html?_r=0",
      "display_url" : "nytimes.com\/interactive\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513291419998375936",
  "text" : "Great article \uD83D\uDC49 Norway the Slow Way http:\/\/t.co\/ZleoIWX2TT",
  "id" : 513291419998375936,
  "created_at" : "2014-09-20 11:39:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/513119452443860992\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/9rSrzWJZ77",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx73av4CcAA-F6G.png",
      "id_str" : "513119446466981888",
      "id" : 513119446466981888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx73av4CcAA-F6G.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9rSrzWJZ77"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513119192615501824",
  "geo" : { },
  "id_str" : "513119452443860992",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik tweetbot thinks I am you http:\/\/t.co\/9rSrzWJZ77",
  "id" : 513119452443860992,
  "in_reply_to_status_id" : 513119192615501824,
  "created_at" : "2014-09-20 00:16:25 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Granieri, Jr",
      "screen_name" : "samgranieri",
      "indices" : [ 0, 12 ],
      "id_str" : "8387442",
      "id" : 8387442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513107391039434753",
  "geo" : { },
  "id_str" : "513117814396186624",
  "in_reply_to_user_id" : 8387442,
  "text" : "@samgranieri Just beginning, something stupid :)",
  "id" : 513117814396186624,
  "in_reply_to_status_id" : 513107391039434753,
  "created_at" : "2014-09-20 00:09:54 +0000",
  "in_reply_to_screen_name" : "samgranieri",
  "in_reply_to_user_id_str" : "8387442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 82, 97 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/513113406409170944\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KnND3F1vfO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx7x7BsCAAAkD7j.png",
      "id_str" : "513113403934507008",
      "id" : 513113403934507008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx7x7BsCAAAkD7j.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KnND3F1vfO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513113406409170944",
  "text" : "Is this new? Siri can change settings (like enable\/disable VoiceOver) in iOS8 \/cc @AustinSeraphin http:\/\/t.co\/KnND3F1vfO",
  "id" : 513113406409170944,
  "created_at" : "2014-09-19 23:52:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "protip",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513109601739612160",
  "geo" : { },
  "id_str" : "513111397400449024",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh you forgot #protip",
  "id" : 513111397400449024,
  "in_reply_to_status_id" : 513109601739612160,
  "created_at" : "2014-09-19 23:44:24 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    }, {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 12, 22 ],
      "id_str" : "97221495",
      "id" : 97221495
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 31, 43 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513099737340604416",
  "geo" : { },
  "id_str" : "513107358981963776",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora @BillybobN usually @AqueousBand has it so filled there is nowhere to sit",
  "id" : 513107358981963776,
  "in_reply_to_status_id" : 513099737340604416,
  "created_at" : "2014-09-19 23:28:22 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513107174638096384",
  "text" : "It\u2019s amazing how fast a few notes can escape muscle memory, but your brain keeps them in cold storage. Defrosting is painful but joyful \uD83C\uDFB9",
  "id" : 513107174638096384,
  "created_at" : "2014-09-19 23:27:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513093213284872192",
  "geo" : { },
  "id_str" : "513095653849698304",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN they have tables?!?",
  "id" : 513095653849698304,
  "in_reply_to_status_id" : 513093213284872192,
  "created_at" : "2014-09-19 22:41:51 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513092996246827008",
  "geo" : { },
  "id_str" : "513095358474252288",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik a statement from his former life",
  "id" : 513095358474252288,
  "in_reply_to_status_id" : 513092996246827008,
  "created_at" : "2014-09-19 22:40:40 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 3, 12 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 85, 99 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/elC4jrUaPP",
      "expanded_url" : "http:\/\/brewhouse.io\/blog\/2014\/09\/19\/ruby-kaigi-2014-day-2",
      "display_url" : "brewhouse.io\/blog\/2014\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513092459262259200",
  "text" : "RT @bitsweat: \u201COSS community is like a shark, we must move forward or we will die\u201D - @yukihiro_matz swims to Ruby 3 http:\/\/t.co\/elC4jrUaPP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yukihiro Matsumoto",
        "screen_name" : "yukihiro_matz",
        "indices" : [ 71, 85 ],
        "id_str" : "20104013",
        "id" : 20104013
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/elC4jrUaPP",
        "expanded_url" : "http:\/\/brewhouse.io\/blog\/2014\/09\/19\/ruby-kaigi-2014-day-2",
        "display_url" : "brewhouse.io\/blog\/2014\/09\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513091820956303360",
    "text" : "\u201COSS community is like a shark, we must move forward or we will die\u201D - @yukihiro_matz swims to Ruby 3 http:\/\/t.co\/elC4jrUaPP",
    "id" : 513091820956303360,
    "created_at" : "2014-09-19 22:26:37 +0000",
    "user" : {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "protected" : false,
      "id_str" : "9462972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510089088129458177\/L_F1zcVv_normal.png",
      "id" : 9462972,
      "verified" : false
    }
  },
  "id" : 513092459262259200,
  "created_at" : "2014-09-19 22:29:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Eldredge",
      "screen_name" : "jessabean",
      "indices" : [ 3, 13 ],
      "id_str" : "15735952",
      "id" : 15735952
    }, {
      "name" : "Yonatan Bergman",
      "screen_name" : "YonBergman",
      "indices" : [ 51, 62 ],
      "id_str" : "140877094",
      "id" : 140877094
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jessabean\/status\/513083274659254273\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/HIn08ZXXxT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx7WhNxCQAAfv6i.jpg",
      "id_str" : "513083273686171648",
      "id" : 513083273686171648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx7WhNxCQAAfv6i.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/HIn08ZXXxT"
    } ],
    "hashtags" : [ {
      "text" : "gogaruco",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "sketchnotes",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513084029059338240",
  "text" : "RT @jessabean: \"Building Board Games With Ruby\" by @YonBergman #gogaruco #sketchnotes http:\/\/t.co\/HIn08ZXXxT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yonatan Bergman",
        "screen_name" : "YonBergman",
        "indices" : [ 36, 47 ],
        "id_str" : "140877094",
        "id" : 140877094
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jessabean\/status\/513083274659254273\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/HIn08ZXXxT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx7WhNxCQAAfv6i.jpg",
        "id_str" : "513083273686171648",
        "id" : 513083273686171648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx7WhNxCQAAfv6i.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/HIn08ZXXxT"
      } ],
      "hashtags" : [ {
        "text" : "gogaruco",
        "indices" : [ 48, 57 ]
      }, {
        "text" : "sketchnotes",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513083274659254273",
    "text" : "\"Building Board Games With Ruby\" by @YonBergman #gogaruco #sketchnotes http:\/\/t.co\/HIn08ZXXxT",
    "id" : 513083274659254273,
    "created_at" : "2014-09-19 21:52:39 +0000",
    "user" : {
      "name" : "Jess Eldredge",
      "screen_name" : "jessabean",
      "protected" : false,
      "id_str" : "15735952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500267334050004992\/SBzWigJs_normal.jpeg",
      "id" : 15735952,
      "verified" : false
    }
  },
  "id" : 513084029059338240,
  "created_at" : "2014-09-19 21:55:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/513075972162482176\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/n3ikiBbEKE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx7P4FmCUAAzNKW.jpg",
      "id_str" : "513075970048151552",
      "id" : 513075970048151552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx7P4FmCUAAzNKW.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/n3ikiBbEKE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513075972162482176",
  "text" : "Ancient buried treasure http:\/\/t.co\/n3ikiBbEKE",
  "id" : 513075972162482176,
  "created_at" : "2014-09-19 21:23:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 13, 27 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513061779526938624",
  "geo" : { },
  "id_str" : "513062031314780160",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @coworkbuffalo we've been waiting on soundproofing them properly. contractors and estimates FTL",
  "id" : 513062031314780160,
  "in_reply_to_status_id" : 513061779526938624,
  "created_at" : "2014-09-19 20:28:15 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff O'Connell",
      "screen_name" : "jeffoc1973",
      "indices" : [ 3, 14 ],
      "id_str" : "17807179",
      "id" : 17807179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ClogmaauTX",
      "expanded_url" : "http:\/\/fb.me\/3Pp0DCQat",
      "display_url" : "fb.me\/3Pp0DCQat"
    } ]
  },
  "geo" : { },
  "id_str" : "513059136154525696",
  "text" : "RT @jeffoc1973: So, stop by CoworkBuffalo anytime from today at 4 p.m. to tomorrow at midnight (YES, 30 hours) and be a witness... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ClogmaauTX",
        "expanded_url" : "http:\/\/fb.me\/3Pp0DCQat",
        "display_url" : "fb.me\/3Pp0DCQat"
      } ]
    },
    "geo" : { },
    "id_str" : "513003023736791041",
    "text" : "So, stop by CoworkBuffalo anytime from today at 4 p.m. to tomorrow at midnight (YES, 30 hours) and be a witness... http:\/\/t.co\/ClogmaauTX",
    "id" : 513003023736791041,
    "created_at" : "2014-09-19 16:33:46 +0000",
    "user" : {
      "name" : "Jeff O'Connell",
      "screen_name" : "jeffoc1973",
      "protected" : false,
      "id_str" : "17807179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430560510514192384\/PI90hAKX_normal.jpeg",
      "id" : 17807179,
      "verified" : false
    }
  },
  "id" : 513059136154525696,
  "created_at" : "2014-09-19 20:16:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513059116252545024",
  "text" : "RT @coworkbuffalo: T-minus 3.5 hours until 30-hour VJ set commences. Drop in during Curtain Up, or pretty much any time this night or tomor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513004291389280257",
    "text" : "T-minus 3.5 hours until 30-hour VJ set commences. Drop in during Curtain Up, or pretty much any time this night or tomorrow afternoon.",
    "id" : 513004291389280257,
    "created_at" : "2014-09-19 16:38:48 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 513059116252545024,
  "created_at" : "2014-09-19 20:16:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squeaky Wheel",
      "screen_name" : "squeakybuffalo",
      "indices" : [ 1, 16 ],
      "id_str" : "104226970",
      "id" : 104226970
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/513050279093075970\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/5sAt06jv3b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx64ghHCAAAWreC.jpg",
      "id_str" : "513050276350001152",
      "id" : 513050276350001152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx64ghHCAAAWreC.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5sAt06jv3b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513050279093075970",
  "text" : ".@squeakybuffalo has taken over @coworkbuffalo for Curtain Up! http:\/\/t.co\/5sAt06jv3b",
  "id" : 513050279093075970,
  "created_at" : "2014-09-19 19:41:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512983343617421312",
  "text" : "RT @neiltyson: \u01DD\u0254\u0250ds o\u0287 \u0287nO \u02D9\u0279\u01DD\u0287u\u01DD\u0254 s\u2019\u0265\u0287\u0279\u0250\u018E \u026Fo\u0279\u025F \u028E\u0250\u028D\u0250 suo\u1D09\u0287\u0254\u01DD\u0279\u1D09p ll\u0250 s\u1D09 ,,dn\u201C \u0287\u1D09\u0183\u01DDl \u028Eluo \u01DD\u0265\u2534 \u02D9dn \u0265\u0287\u0279oN \u028Do\u0265s \u0265\u0287\u0279\u0250\u018E \u025Fo sd\u0250\u026F \u0287\u0250\u0265\u0287 \u028E\u0279\u0250\u0279\u0287\u1D09q\u0279\u0250 s\u2019\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512983088612139011",
    "text" : "\u01DD\u0254\u0250ds o\u0287 \u0287nO \u02D9\u0279\u01DD\u0287u\u01DD\u0254 s\u2019\u0265\u0287\u0279\u0250\u018E \u026Fo\u0279\u025F \u028E\u0250\u028D\u0250 suo\u1D09\u0287\u0254\u01DD\u0279\u1D09p ll\u0250 s\u1D09 ,,dn\u201C \u0287\u1D09\u0183\u01DDl \u028Eluo \u01DD\u0265\u2534 \u02D9dn \u0265\u0287\u0279oN \u028Do\u0265s \u0265\u0287\u0279\u0250\u018E \u025Fo sd\u0250\u026F \u0287\u0250\u0265\u0287 \u028E\u0279\u0250\u0279\u0287\u1D09q\u0279\u0250 s\u2019\u0287I",
    "id" : 512983088612139011,
    "created_at" : "2014-09-19 15:14:33 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 512983343617421312,
  "created_at" : "2014-09-19 15:15:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512983235274371072",
  "text" : "I like how programming languages on Wikipedia \"Appeared in $year\". As if they're some monster that sprung up out of tall grass.",
  "id" : 512983235274371072,
  "created_at" : "2014-09-19 15:15:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apollo Ingram",
      "screen_name" : "willmanduffy",
      "indices" : [ 3, 16 ],
      "id_str" : "351346221",
      "id" : 351346221
    }, {
      "name" : "BrooklynJS",
      "screen_name" : "brooklyn_js",
      "indices" : [ 54, 66 ],
      "id_str" : "1965353774",
      "id" : 1965353774
    }, {
      "name" : "John K. Paul",
      "screen_name" : "johnkpaul",
      "indices" : [ 109, 119 ],
      "id_str" : "21327211",
      "id" : 21327211
    }, {
      "name" : "Jed Schmidt",
      "screen_name" : "jedschmidt",
      "indices" : [ 120, 131 ],
      "id_str" : "815114",
      "id" : 815114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/zlhex9hrD9",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0sgUgqPPxoo",
      "display_url" : "youtube.com\/watch?v=0sgUgq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512969387062476800",
  "text" : "RT @willmanduffy: If you mention you work on Rails at @brooklyn_js this happens\n\nhttps:\/\/t.co\/zlhex9hrD9\n\ncc @johnkpaul @jedschmidt + The F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BrooklynJS",
        "screen_name" : "brooklyn_js",
        "indices" : [ 36, 48 ],
        "id_str" : "1965353774",
        "id" : 1965353774
      }, {
        "name" : "John K. Paul",
        "screen_name" : "johnkpaul",
        "indices" : [ 91, 101 ],
        "id_str" : "21327211",
        "id" : 21327211
      }, {
        "name" : "Jed Schmidt",
        "screen_name" : "jedschmidt",
        "indices" : [ 102, 113 ],
        "id_str" : "815114",
        "id" : 815114
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/zlhex9hrD9",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0sgUgqPPxoo",
        "display_url" : "youtube.com\/watch?v=0sgUgq\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512765533553315841",
    "text" : "If you mention you work on Rails at @brooklyn_js this happens\n\nhttps:\/\/t.co\/zlhex9hrD9\n\ncc @johnkpaul @jedschmidt + The Four Fives",
    "id" : 512765533553315841,
    "created_at" : "2014-09-19 00:50:04 +0000",
    "user" : {
      "name" : "Apollo Ingram",
      "screen_name" : "willmanduffy",
      "protected" : false,
      "id_str" : "351346221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554818321330106368\/ylBPWBi1_normal.jpeg",
      "id" : 351346221,
      "verified" : false
    }
  },
  "id" : 512969387062476800,
  "created_at" : "2014-09-19 14:20:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512936417220366336",
  "geo" : { },
  "id_str" : "512948710565625856",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow why do people have been the most beautiful thing in life are the only way I can get the hang of this month in the morning to all",
  "id" : 512948710565625856,
  "in_reply_to_status_id" : 512936417220366336,
  "created_at" : "2014-09-19 12:57:57 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 3, 10 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512934281522343936",
  "text" : "RT @nathos: @qrush who needs clean drinking water when you have Pepsi, the Official Soft Drink of the Buffalo Bills!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512932686005272576",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush who needs clean drinking water when you have Pepsi, the Official Soft Drink of the Buffalo Bills!",
    "id" : 512932686005272576,
    "created_at" : "2014-09-19 11:54:16 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "protected" : false,
      "id_str" : "34953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570421723984429056\/SiXp3XlU_normal.jpeg",
      "id" : 34953,
      "verified" : false
    }
  },
  "id" : 512934281522343936,
  "created_at" : "2014-09-19 12:00:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/4gI56rYsaz",
      "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/washington-politics\/h-word-by-collins-has-expats-groaning-20140918",
      "display_url" : "buffalonews.com\/city-region\/wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512925789231136768",
  "text" : "RT @rachbarnhart: Rep. Collins: \u201CThe reason the Bills are staying in Buffalo is because of Terry Pegula and hydrofracking\" http:\/\/t.co\/4gI5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/4gI56rYsaz",
        "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/washington-politics\/h-word-by-collins-has-expats-groaning-20140918",
        "display_url" : "buffalonews.com\/city-region\/wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512923525196570624",
    "text" : "Rep. Collins: \u201CThe reason the Bills are staying in Buffalo is because of Terry Pegula and hydrofracking\" http:\/\/t.co\/4gI56rYsaz",
    "id" : 512923525196570624,
    "created_at" : "2014-09-19 11:17:52 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 512925789231136768,
  "created_at" : "2014-09-19 11:26:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saved You A Click",
      "screen_name" : "SavedYouAClick",
      "indices" : [ 3, 18 ],
      "id_str" : "2480079168",
      "id" : 2480079168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512826462064238593",
  "text" : "RT @SavedYouAClick: Scotland voted \"No.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512824573679509504",
    "text" : "Scotland voted \"No.\"",
    "id" : 512824573679509504,
    "created_at" : "2014-09-19 04:44:40 +0000",
    "user" : {
      "name" : "Saved You A Click",
      "screen_name" : "SavedYouAClick",
      "protected" : false,
      "id_str" : "2480079168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550693983811170304\/2MaGJRPC_normal.jpeg",
      "id" : 2480079168,
      "verified" : false
    }
  },
  "id" : 512826462064238593,
  "created_at" : "2014-09-19 04:52:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everyone Orchestra",
      "screen_name" : "every1orchestra",
      "indices" : [ 17, 33 ],
      "id_str" : "1863949082",
      "id" : 1863949082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512794802421628928",
  "text" : "Was skeptical of @every1orchestra but this is wonderful to watch unfold",
  "id" : 512794802421628928,
  "created_at" : "2014-09-19 02:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/j6MD7edY7A",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/541b9520498e27257d70c5d5?s=ArNW9w3JsOb6bqf8q5uCuObZzSE&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8935344147, -78.8761340541 ]
  },
  "id_str" : "512790650475929601",
  "text" : "I'm at The Waiting Room for Everyone Orchestra in Buffalo, NY https:\/\/t.co\/j6MD7edY7A",
  "id" : 512790650475929601,
  "created_at" : "2014-09-19 02:29:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 3, 11 ],
      "id_str" : "12145232",
      "id" : 12145232
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 29, 43 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 80, 91 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CDMoyer\/status\/512717051035533313\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/uj9qxhD5Fk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx2JcKaCAAAvgKS.jpg",
      "id_str" : "512717049512984576",
      "id" : 512717049512984576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx2JcKaCAAAvgKS.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uj9qxhD5Fk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512779203956076545",
  "text" : "RT @CDMoyer: I only use this @coworkbuffalo mug when I don't use the keurig. So @kevinpurdy doesn't die a little inside. http:\/\/t.co\/uj9qxh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 16, 30 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "Kevin Purdy",
        "screen_name" : "kevinpurdy",
        "indices" : [ 67, 78 ],
        "id_str" : "14687182",
        "id" : 14687182
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CDMoyer\/status\/512717051035533313\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/uj9qxhD5Fk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx2JcKaCAAAvgKS.jpg",
        "id_str" : "512717049512984576",
        "id" : 512717049512984576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx2JcKaCAAAvgKS.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uj9qxhD5Fk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512717051035533313",
    "text" : "I only use this @coworkbuffalo mug when I don't use the keurig. So @kevinpurdy doesn't die a little inside. http:\/\/t.co\/uj9qxhD5Fk",
    "id" : 512717051035533313,
    "created_at" : "2014-09-18 21:37:25 +0000",
    "user" : {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "protected" : false,
      "id_str" : "12145232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421641487051272192\/IfEg0PgG_normal.jpeg",
      "id" : 12145232,
      "verified" : false
    }
  },
  "id" : 512779203956076545,
  "created_at" : "2014-09-19 01:44:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512769020743798785",
  "text" : "First Kraken\/Cider\/Cinnamon of the season. It's Fall.",
  "id" : 512769020743798785,
  "created_at" : "2014-09-19 01:03:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Nabors",
      "screen_name" : "rachelnabors",
      "indices" : [ 0, 13 ],
      "id_str" : "9550352",
      "id" : 9550352
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 14, 25 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512761623665078272",
  "geo" : { },
  "id_str" : "512767794153144320",
  "in_reply_to_user_id" : 9550352,
  "text" : "@rachelnabors @joefiorini so what is a valid form then? I can understand avoiding IRC, but email?",
  "id" : 512767794153144320,
  "in_reply_to_status_id" : 512761623665078272,
  "created_at" : "2014-09-19 00:59:03 +0000",
  "in_reply_to_screen_name" : "rachelnabors",
  "in_reply_to_user_id_str" : "9550352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512763263864426497",
  "geo" : { },
  "id_str" : "512767206304673792",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo any idea how long they're playing?",
  "id" : 512767206304673792,
  "in_reply_to_status_id" : 512763263864426497,
  "created_at" : "2014-09-19 00:56:43 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 10, 23 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512740857351401472",
  "geo" : { },
  "id_str" : "512744610783715328",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @j_m_williams EXTREME DADOPS",
  "id" : 512744610783715328,
  "in_reply_to_status_id" : 512740857351401472,
  "created_at" : "2014-09-18 23:26:56 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel Mansour",
      "screen_name" : "gabrielmansour",
      "indices" : [ 3, 18 ],
      "id_str" : "771335",
      "id" : 771335
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 83, 98 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "more",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "equality",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512740636814893056",
  "text" : "RT @gabrielmansour: I appreciate the fact that close to half of the presenters for @nickelcityruby are women. #more #equality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 63, 78 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "more",
        "indices" : [ 90, 95 ]
      }, {
        "text" : "equality",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512732145723260929",
    "text" : "I appreciate the fact that close to half of the presenters for @nickelcityruby are women. #more #equality",
    "id" : 512732145723260929,
    "created_at" : "2014-09-18 22:37:24 +0000",
    "user" : {
      "name" : "Gabriel Mansour",
      "screen_name" : "gabrielmansour",
      "protected" : false,
      "id_str" : "771335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1593646748\/image_normal.jpg",
      "id" : 771335,
      "verified" : false
    }
  },
  "id" : 512740636814893056,
  "created_at" : "2014-09-18 23:11:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Grossman",
      "screen_name" : "freerobby",
      "indices" : [ 0, 10 ],
      "id_str" : "15023866",
      "id" : 15023866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512736050280554496",
  "geo" : { },
  "id_str" : "512737272987279360",
  "in_reply_to_user_id" : 15023866,
  "text" : "@freerobby that is more than one person can handle",
  "id" : 512737272987279360,
  "in_reply_to_status_id" : 512736050280554496,
  "created_at" : "2014-09-18 22:57:46 +0000",
  "in_reply_to_screen_name" : "freerobby",
  "in_reply_to_user_id_str" : "15023866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512734979390857217",
  "text" : "Breaking out the Laphroaig this evening. Anyone else in solidarity?",
  "id" : 512734979390857217,
  "created_at" : "2014-09-18 22:48:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512672178999812098",
  "geo" : { },
  "id_str" : "512672382104768512",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek nearly every large company, game companies, etc",
  "id" : 512672382104768512,
  "in_reply_to_status_id" : 512672178999812098,
  "created_at" : "2014-09-18 18:39:55 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 3, 13 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ocjA1RhbGu",
      "expanded_url" : "http:\/\/lemonjar.com\/iosconsole\/",
      "display_url" : "lemonjar.com\/iosconsole\/"
    } ]
  },
  "geo" : { },
  "id_str" : "512633982203084800",
  "text" : "RT @zachwaugh: Might have mentioned it before, but iOS Console has been a lifesaver in developing a share extension - http:\/\/t.co\/ocjA1RhbGu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/ocjA1RhbGu",
        "expanded_url" : "http:\/\/lemonjar.com\/iosconsole\/",
        "display_url" : "lemonjar.com\/iosconsole\/"
      } ]
    },
    "geo" : { },
    "id_str" : "512633757426548736",
    "text" : "Might have mentioned it before, but iOS Console has been a lifesaver in developing a share extension - http:\/\/t.co\/ocjA1RhbGu",
    "id" : 512633757426548736,
    "created_at" : "2014-09-18 16:06:26 +0000",
    "user" : {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "protected" : false,
      "id_str" : "14620798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549681852332535809\/TzOXTBNx_normal.jpeg",
      "id" : 14620798,
      "verified" : false
    }
  },
  "id" : 512633982203084800,
  "created_at" : "2014-09-18 16:07:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 3, 14 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/iI3IB6nLYI",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "512614935549849601",
  "text" : "RT @jaytennier: Local tech folks, you should be going to http:\/\/t.co\/iI3IB6nLYI because I can't. You won't find a better line up this close\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/iI3IB6nLYI",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "512384439528468480",
    "text" : "Local tech folks, you should be going to http:\/\/t.co\/iI3IB6nLYI because I can't. You won't find a better line up this close to home.",
    "id" : 512384439528468480,
    "created_at" : "2014-09-17 23:35:44 +0000",
    "user" : {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "protected" : false,
      "id_str" : "15020118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428887276228067329\/L0TrLGr5_normal.jpeg",
      "id" : 15020118,
      "verified" : false
    }
  },
  "id" : 512614935549849601,
  "created_at" : "2014-09-18 14:51:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It BTV",
      "screen_name" : "gdiburlington",
      "indices" : [ 3, 17 ],
      "id_str" : "1115888143",
      "id" : 1115888143
    }, {
      "name" : "Mandrill",
      "screen_name" : "mandrillapp",
      "indices" : [ 27, 39 ],
      "id_str" : "540239057",
      "id" : 540239057
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 80, 95 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 143, 144 ]
    }, {
      "text" : "btvruby",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512614920840441856",
  "text" : "RT @gdiburlington: Thnx to @mandrillapp we're giving away 1 ticket to Buffalo's @nickelcityruby on Oct 3 &amp; 4. Tell us why you deserve to go\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mandrill",
        "screen_name" : "mandrillapp",
        "indices" : [ 8, 20 ],
        "id_str" : "540239057",
        "id" : 540239057
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 61, 76 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 126, 133 ]
      }, {
        "text" : "btvruby",
        "indices" : [ 134, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512592463035662337",
    "text" : "Thnx to @mandrillapp we're giving away 1 ticket to Buffalo's @nickelcityruby on Oct 3 &amp; 4. Tell us why you deserve to go! #ncrc14 #btvruby",
    "id" : 512592463035662337,
    "created_at" : "2014-09-18 13:22:21 +0000",
    "user" : {
      "name" : "Girl Develop It BTV",
      "screen_name" : "gdiburlington",
      "protected" : false,
      "id_str" : "1115888143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468910238842646528\/oUljXseN_normal.png",
      "id" : 1115888143,
      "verified" : false
    }
  },
  "id" : 512614920840441856,
  "created_at" : "2014-09-18 14:51:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 0, 9 ],
      "id_str" : "14103289",
      "id" : 14103289
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 59, 66 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Doug Alcorn",
      "screen_name" : "dougalcorn",
      "indices" : [ 71, 82 ],
      "id_str" : "7018192",
      "id" : 7018192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512613483993919488",
  "geo" : { },
  "id_str" : "512614664031592448",
  "in_reply_to_user_id" : 14103289,
  "text" : "@plukevdh just saw the issue...i think you need to talk to @searls and @dougalcorn. we already gave them push on -given",
  "id" : 512614664031592448,
  "in_reply_to_status_id" : 512613483993919488,
  "created_at" : "2014-09-18 14:50:34 +0000",
  "in_reply_to_screen_name" : "plukevdh",
  "in_reply_to_user_id_str" : "14103289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 0, 9 ],
      "id_str" : "14103289",
      "id" : 14103289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512611460569395201",
  "geo" : { },
  "id_str" : "512611993648263168",
  "in_reply_to_user_id" : 14103289,
  "text" : "@plukevdh Check that URL. GitHub issues is not for support.",
  "id" : 512611993648263168,
  "in_reply_to_status_id" : 512611460569395201,
  "created_at" : "2014-09-18 14:39:57 +0000",
  "in_reply_to_screen_name" : "plukevdh",
  "in_reply_to_user_id_str" : "14103289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 0, 9 ],
      "id_str" : "14103289",
      "id" : 14103289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/HsNhGlTez1",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "512609077336477697",
  "geo" : { },
  "id_str" : "512610541244657664",
  "in_reply_to_user_id" : 14103289,
  "text" : "@plukevdh please open a ticket on http:\/\/t.co\/HsNhGlTez1. We've been more liberal than normal on his gems",
  "id" : 512610541244657664,
  "in_reply_to_status_id" : 512609077336477697,
  "created_at" : "2014-09-18 14:34:11 +0000",
  "in_reply_to_screen_name" : "plukevdh",
  "in_reply_to_user_id_str" : "14103289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrb",
      "screen_name" : "mrb_bk",
      "indices" : [ 3, 10 ],
      "id_str" : "10179552",
      "id" : 10179552
    }, {
      "name" : "Joe Armstrong",
      "screen_name" : "joeerl",
      "indices" : [ 69, 76 ],
      "id_str" : "51546468",
      "id" : 51546468
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mrb_bk\/status\/512606633013559296\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/QWpzWDsaIt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx0lBA2CIAApaZX.jpg",
      "id_str" : "512606631926833152",
      "id" : 512606631926833152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx0lBA2CIAApaZX.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QWpzWDsaIt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512610216311926784",
  "text" : "RT @mrb_bk: In case you were wondering why your programs don't work, @joeerl has you covered http:\/\/t.co\/QWpzWDsaIt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Armstrong",
        "screen_name" : "joeerl",
        "indices" : [ 57, 64 ],
        "id_str" : "51546468",
        "id" : 51546468
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mrb_bk\/status\/512606633013559296\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/QWpzWDsaIt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx0lBA2CIAApaZX.jpg",
        "id_str" : "512606631926833152",
        "id" : 512606631926833152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx0lBA2CIAApaZX.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QWpzWDsaIt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512606633013559296",
    "text" : "In case you were wondering why your programs don't work, @joeerl has you covered http:\/\/t.co\/QWpzWDsaIt",
    "id" : 512606633013559296,
    "created_at" : "2014-09-18 14:18:39 +0000",
    "user" : {
      "name" : "mrb",
      "screen_name" : "mrb_bk",
      "protected" : false,
      "id_str" : "10179552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542489705476927488\/f3SZzb6I_normal.png",
      "id" : 10179552,
      "verified" : false
    }
  },
  "id" : 512610216311926784,
  "created_at" : "2014-09-18 14:32:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 0, 9 ],
      "id_str" : "14103289",
      "id" : 14103289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512606818183684096",
  "geo" : { },
  "id_str" : "512608358910550016",
  "in_reply_to_user_id" : 14103289,
  "text" : "@plukevdh I help out when I can, but mostly not. What's up?",
  "id" : 512608358910550016,
  "in_reply_to_status_id" : 512606818183684096,
  "created_at" : "2014-09-18 14:25:31 +0000",
  "in_reply_to_screen_name" : "plukevdh",
  "in_reply_to_user_id_str" : "14103289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/RyywtMRCBs",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/List_of_U.S._state_partition_proposals",
      "display_url" : "en.m.wikipedia.org\/wiki\/List_of_U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512576648210690048",
  "text" : "In honor of Scottish independence, here's a list of every US state that has tried to secede\/split http:\/\/t.co\/RyywtMRCBs",
  "id" : 512576648210690048,
  "created_at" : "2014-09-18 12:19:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/512450023586426880\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/iqVb9j90wm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxyWlDPCYAA66Dx.png",
      "id_str" : "512450020881096704",
      "id" : 512450020881096704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxyWlDPCYAA66Dx.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iqVb9j90wm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512450023586426880",
  "text" : "Well this totally isn\u2019t terrifying http:\/\/t.co\/iqVb9j90wm",
  "id" : 512450023586426880,
  "created_at" : "2014-09-18 03:56:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512448431877406720",
  "geo" : { },
  "id_str" : "512448707103436802",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft 202 Mucus Accepted",
  "id" : 512448707103436802,
  "in_reply_to_status_id" : 512448431877406720,
  "created_at" : "2014-09-18 03:51:07 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    }, {
      "name" : "Wailin Wong",
      "screen_name" : "VelocityWong",
      "indices" : [ 13, 26 ],
      "id_str" : "15222743",
      "id" : 15222743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512424934954389506",
  "geo" : { },
  "id_str" : "512427917419085824",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney @VelocityWong perhaps it was an evil stepmother?",
  "id" : 512427917419085824,
  "in_reply_to_status_id" : 512424934954389506,
  "created_at" : "2014-09-18 02:28:30 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    }, {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 14, 29 ],
      "id_str" : "81525784",
      "id" : 81525784
    }, {
      "name" : "Jessica Suttles",
      "screen_name" : "jlsuttles",
      "indices" : [ 30, 40 ],
      "id_str" : "21170138",
      "id" : 21170138
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 41, 54 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512423993409019904",
  "geo" : { },
  "id_str" : "512424492098785281",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman @franklinwebber @jlsuttles @steveklabnik dear lord",
  "id" : 512424492098785281,
  "in_reply_to_status_id" : 512423993409019904,
  "created_at" : "2014-09-18 02:14:53 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/cGY2D52kMM",
      "expanded_url" : "http:\/\/www.artlebedev.com\/everything\/optimus\/popularis\/",
      "display_url" : "artlebedev.com\/everything\/opt\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "512412829698105344",
  "geo" : { },
  "id_str" : "512413771940122624",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda http:\/\/t.co\/cGY2D52kMM",
  "id" : 512413771940122624,
  "in_reply_to_status_id" : 512412829698105344,
  "created_at" : "2014-09-18 01:32:18 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512404176656035840",
  "text" : "Found slides for a class I'm going to speak at, and at the top: \"Phones and other electronics: OFF and AWAY\" ...I would have failed.",
  "id" : 512404176656035840,
  "created_at" : "2014-09-18 00:54:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512391364516904960",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik you're not following me, so I sent you an email :D",
  "id" : 512391364516904960,
  "created_at" : "2014-09-18 00:03:15 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512341213157294080",
  "geo" : { },
  "id_str" : "512341434909745152",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik yeah i feel this way too, just had a drought lately",
  "id" : 512341434909745152,
  "in_reply_to_status_id" : 512341213157294080,
  "created_at" : "2014-09-17 20:44:51 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512314055932272640",
  "geo" : { },
  "id_str" : "512337952886648832",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik Yep, same here. Crazy.",
  "id" : 512337952886648832,
  "in_reply_to_status_id" : 512314055932272640,
  "created_at" : "2014-09-17 20:31:01 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Priestman",
      "screen_name" : "CPriestman",
      "indices" : [ 3, 14 ],
      "id_str" : "182438807",
      "id" : 182438807
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CPriestman\/status\/512291273051742208\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/jn5Bct2os1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxwGMksCcAAQKW9.jpg",
      "id_str" : "512291270689976320",
      "id" : 512291270689976320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxwGMksCcAAQKW9.jpg",
      "sizes" : [ {
        "h" : 545,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jn5Bct2os1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512335661257338880",
  "text" : "RT @CPriestman: http:\/\/t.co\/jn5Bct2os1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CPriestman\/status\/512291273051742208\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/jn5Bct2os1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxwGMksCcAAQKW9.jpg",
        "id_str" : "512291270689976320",
        "id" : 512291270689976320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxwGMksCcAAQKW9.jpg",
        "sizes" : [ {
          "h" : 545,
          "resize" : "fit",
          "w" : 761
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 761
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jn5Bct2os1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512291273051742208",
    "text" : "http:\/\/t.co\/jn5Bct2os1",
    "id" : 512291273051742208,
    "created_at" : "2014-09-17 17:25:32 +0000",
    "user" : {
      "name" : "Chris Priestman",
      "screen_name" : "CPriestman",
      "protected" : false,
      "id_str" : "182438807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000687447995\/ad5062b785750003e351f31ea6256a83_normal.jpeg",
      "id" : 182438807,
      "verified" : false
    }
  },
  "id" : 512335661257338880,
  "created_at" : "2014-09-17 20:21:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512332755212828673",
  "geo" : { },
  "id_str" : "512333351487688705",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej holy shit, that stamp was the best",
  "id" : 512333351487688705,
  "in_reply_to_status_id" : 512332755212828673,
  "created_at" : "2014-09-17 20:12:44 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 25, 37 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/iTGIpCODCC",
      "expanded_url" : "http:\/\/kck.st\/1qJJ3IA",
      "display_url" : "kck.st\/1qJJ3IA"
    } ]
  },
  "geo" : { },
  "id_str" : "512327078327234560",
  "text" : "I just backed NoPhone on @Kickstarter http:\/\/t.co\/iTGIpCODCC",
  "id" : 512327078327234560,
  "created_at" : "2014-09-17 19:47:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 3, 11 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/goldman\/status\/512226163146887168\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rb3DHOfusQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxvK-vrCYAIpYh8.jpg",
      "id_str" : "512226161934360578",
      "id" : 512226161934360578,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxvK-vrCYAIpYh8.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/rb3DHOfusQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512294286377750528",
  "text" : "RT @goldman: Yo but how high were you when you decided to go live on an ocean platform. \n\n\"No not like. It *is* Waterworld man.\" http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/goldman\/status\/512226163146887168\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/rb3DHOfusQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxvK-vrCYAIpYh8.jpg",
        "id_str" : "512226161934360578",
        "id" : 512226161934360578,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxvK-vrCYAIpYh8.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/rb3DHOfusQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512226163146887168",
    "text" : "Yo but how high were you when you decided to go live on an ocean platform. \n\n\"No not like. It *is* Waterworld man.\" http:\/\/t.co\/rb3DHOfusQ",
    "id" : 512226163146887168,
    "created_at" : "2014-09-17 13:06:48 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "protected" : false,
      "id_str" : "291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477959286736183296\/O2mhuuPG_normal.jpeg",
      "id" : 291,
      "verified" : false
    }
  },
  "id" : 512294286377750528,
  "created_at" : "2014-09-17 17:37:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 3, 12 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/7UhHz0LYu4",
      "expanded_url" : "http:\/\/rubyconf.org\/scholarship",
      "display_url" : "rubyconf.org\/scholarship"
    } ]
  },
  "geo" : { },
  "id_str" : "512290810457378816",
  "text" : "RT @rubyconf: We are now accepting applications for our Opportunity Scholarship! Apply from now through Oct 1 here: http:\/\/t.co\/7UhHz0LYu4 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/7UhHz0LYu4",
        "expanded_url" : "http:\/\/rubyconf.org\/scholarship",
        "display_url" : "rubyconf.org\/scholarship"
      } ]
    },
    "geo" : { },
    "id_str" : "512290783043387392",
    "text" : "We are now accepting applications for our Opportunity Scholarship! Apply from now through Oct 1 here: http:\/\/t.co\/7UhHz0LYu4 Please RT!",
    "id" : 512290783043387392,
    "created_at" : "2014-09-17 17:23:35 +0000",
    "user" : {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "protected" : false,
      "id_str" : "16222737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461644046767644672\/O1nVULuF_normal.png",
      "id" : 16222737,
      "verified" : false
    }
  },
  "id" : 512290810457378816,
  "created_at" : "2014-09-17 17:23:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512266238857199616",
  "geo" : { },
  "id_str" : "512268125631303681",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox thanks, tried that. Let's see if it goes through...I wish this was easier.",
  "id" : 512268125631303681,
  "in_reply_to_status_id" : 512266238857199616,
  "created_at" : "2014-09-17 15:53:33 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512263791904452608",
  "text" : "Convinced we'd be sold out with this lineup in NYC, SF, Boston, etc. Seriously wonderful group of speakers.",
  "id" : 512263791904452608,
  "created_at" : "2014-09-17 15:36:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "512263684656082944",
  "text" : "Ruby folks, I'd appreciate an RT or link to http:\/\/t.co\/3UAdoKZw7Q in your streams today :D",
  "id" : 512263684656082944,
  "created_at" : "2014-09-17 15:35:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yhjteaaViy",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "512258534050758657",
  "text" : "3 more days to lock down our insanely discounted room for Buffalo's best developer conference this Fall. Do it up! http:\/\/t.co\/yhjteaaViy",
  "id" : 512258534050758657,
  "created_at" : "2014-09-17 15:15:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne hugs at GDC",
      "screen_name" : "WanyoDos",
      "indices" : [ 0, 9 ],
      "id_str" : "394072776",
      "id" : 394072776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512256910079574016",
  "geo" : { },
  "id_str" : "512257099154219010",
  "in_reply_to_user_id" : 394072776,
  "text" : "@WanyoDos awful",
  "id" : 512257099154219010,
  "in_reply_to_status_id" : 512256910079574016,
  "created_at" : "2014-09-17 15:09:44 +0000",
  "in_reply_to_screen_name" : "WanyoDos",
  "in_reply_to_user_id_str" : "394072776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne hugs at GDC",
      "screen_name" : "WanyoDos",
      "indices" : [ 0, 9 ],
      "id_str" : "394072776",
      "id" : 394072776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512255609451077632",
  "in_reply_to_user_id" : 394072776,
  "text" : "@WanyoDos this is not a roguelike",
  "id" : 512255609451077632,
  "created_at" : "2014-09-17 15:03:49 +0000",
  "in_reply_to_screen_name" : "WanyoDos",
  "in_reply_to_user_id_str" : "394072776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/512240643008000000\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/UqSkIGOyw5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxvYJmcCQAI9C39.png",
      "id_str" : "512240642085240834",
      "id" : 512240642085240834,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxvYJmcCQAI9C39.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UqSkIGOyw5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512240643008000000",
  "text" : "Current status http:\/\/t.co\/UqSkIGOyw5",
  "id" : 512240643008000000,
  "created_at" : "2014-09-17 14:04:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "Charles Lowell",
      "screen_name" : "cowboyd",
      "indices" : [ 11, 19 ],
      "id_str" : "791224",
      "id" : 791224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512221738009378816",
  "geo" : { },
  "id_str" : "512224600088780800",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking @cowboyd I have never felt this urge. Maybe for game developers who seem obsessed with NIH",
  "id" : 512224600088780800,
  "in_reply_to_status_id" : 512221738009378816,
  "created_at" : "2014-09-17 13:00:35 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Qzi0veuCQr",
      "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/97668474211\/announcing-the-public-beta-of-rubymotion-for-android",
      "display_url" : "blog.rubymotion.com\/post\/976684742\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512219475957923840",
  "text" : "RT @RubyMotion: RubyMotion for Android is now available in public beta. Enjoy! http:\/\/t.co\/Qzi0veuCQr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Qzi0veuCQr",
        "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/97668474211\/announcing-the-public-beta-of-rubymotion-for-android",
        "display_url" : "blog.rubymotion.com\/post\/976684742\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512212282315505664",
    "text" : "RubyMotion for Android is now available in public beta. Enjoy! http:\/\/t.co\/Qzi0veuCQr",
    "id" : 512212282315505664,
    "created_at" : "2014-09-17 12:11:39 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 512219475957923840,
  "created_at" : "2014-09-17 12:40:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512073011877253120",
  "text" : "Last few iOS game purchases have been total duds. I wish there was a refund process.",
  "id" : 512073011877253120,
  "created_at" : "2014-09-17 02:58:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 0, 15 ],
      "id_str" : "130242651",
      "id" : 130242651
    }, {
      "name" : "Buffalo Game Space",
      "screen_name" : "BuffGameSpace",
      "indices" : [ 16, 30 ],
      "id_str" : "1370047219",
      "id" : 1370047219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/Nmun47pitd",
      "expanded_url" : "http:\/\/coworking.org",
      "display_url" : "coworking.org"
    } ]
  },
  "in_reply_to_status_id_str" : "512066402950590466",
  "geo" : { },
  "id_str" : "512066742617513984",
  "in_reply_to_user_id" : 130242651,
  "text" : "@Chris_Langford @BuffGameSpace cool. Also please read: http:\/\/t.co\/Nmun47pitd",
  "id" : 512066742617513984,
  "in_reply_to_status_id" : 512066402950590466,
  "created_at" : "2014-09-17 02:33:19 +0000",
  "in_reply_to_screen_name" : "Chris_Langford",
  "in_reply_to_user_id_str" : "130242651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Game Space",
      "screen_name" : "BuffGameSpace",
      "indices" : [ 0, 14 ],
      "id_str" : "1370047219",
      "id" : 1370047219
    }, {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 15, 30 ],
      "id_str" : "130242651",
      "id" : 130242651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512059790055727104",
  "geo" : { },
  "id_str" : "512065767588651008",
  "in_reply_to_user_id" : 1370047219,
  "text" : "@BuffGameSpace @Chris_Langford where is this new space going to be?",
  "id" : 512065767588651008,
  "in_reply_to_status_id" : 512059790055727104,
  "created_at" : "2014-09-17 02:29:27 +0000",
  "in_reply_to_screen_name" : "BuffGameSpace",
  "in_reply_to_user_id_str" : "1370047219",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 11, 21 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 22, 27 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Chris Swenor",
      "screen_name" : "chrisswenor",
      "indices" : [ 28, 40 ],
      "id_str" : "17627242",
      "id" : 17627242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512036973696270336",
  "geo" : { },
  "id_str" : "512056956219969536",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @magnachef @popo @chrisswenor lmao \"I am getting so much work done. Toddlers are easy.\"",
  "id" : 512056956219969536,
  "in_reply_to_status_id" : 512036973696270336,
  "created_at" : "2014-09-17 01:54:26 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Dinosaurescu",
      "screen_name" : "notwaldorf",
      "indices" : [ 3, 14 ],
      "id_str" : "167834639",
      "id" : 167834639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512013227136282624",
  "text" : "RT @notwaldorf: Ned Flanders introduces git:\n\nalias syncaroonie=\"git pull\"\nalias brancharino=\"git checkout -b\"\nalias oopsadoodle=\"git reset\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511919514309505025",
    "text" : "Ned Flanders introduces git:\n\nalias syncaroonie=\"git pull\"\nalias brancharino=\"git checkout -b\"\nalias oopsadoodle=\"git reset --hard HEAD\"",
    "id" : 511919514309505025,
    "created_at" : "2014-09-16 16:48:17 +0000",
    "user" : {
      "name" : "Monica Dinosaurescu",
      "screen_name" : "notwaldorf",
      "protected" : false,
      "id_str" : "167834639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552145324072902656\/41TncGzr_normal.jpeg",
      "id" : 167834639,
      "verified" : false
    }
  },
  "id" : 512013227136282624,
  "created_at" : "2014-09-16 23:00:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511998359721103360",
  "geo" : { },
  "id_str" : "511998496501542912",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits yeah looking for the former",
  "id" : 511998496501542912,
  "in_reply_to_status_id" : 511998359721103360,
  "created_at" : "2014-09-16 22:02:08 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 3, 14 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "19 IDEAS",
      "screen_name" : "19IDEAS",
      "indices" : [ 90, 98 ],
      "id_str" : "266352448",
      "id" : 266352448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geek",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/jKQR0GoNSV",
      "expanded_url" : "https:\/\/ti.to\/-\/MtdaHw",
      "display_url" : "ti.to\/-\/MtdaHw"
    } ]
  },
  "geo" : { },
  "id_str" : "511994753245016064",
  "text" : "RT @dangigante: I just registered for Nickel City Ruby Conf 2014 https:\/\/t.co\/jKQR0GoNSV. @19IDEAS represent #geek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "19 IDEAS",
        "screen_name" : "19IDEAS",
        "indices" : [ 74, 82 ],
        "id_str" : "266352448",
        "id" : 266352448
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "geek",
        "indices" : [ 93, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/jKQR0GoNSV",
        "expanded_url" : "https:\/\/ti.to\/-\/MtdaHw",
        "display_url" : "ti.to\/-\/MtdaHw"
      } ]
    },
    "geo" : { },
    "id_str" : "511967654869860353",
    "text" : "I just registered for Nickel City Ruby Conf 2014 https:\/\/t.co\/jKQR0GoNSV. @19IDEAS represent #geek",
    "id" : 511967654869860353,
    "created_at" : "2014-09-16 19:59:35 +0000",
    "user" : {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "protected" : false,
      "id_str" : "43151378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482218130996232192\/bISq7rRg_normal.jpeg",
      "id" : 43151378,
      "verified" : false
    }
  },
  "id" : 511994753245016064,
  "created_at" : "2014-09-16 21:47:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/511981833077026817\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/EEjcsetywb",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BxrswqQCQAI5yRh.png",
      "id_str" : "511981828379394050",
      "id" : 511981828379394050,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BxrswqQCQAI5yRh.png",
      "sizes" : [ {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/EEjcsetywb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511981585416343552",
  "geo" : { },
  "id_str" : "511981833077026817",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone http:\/\/t.co\/EEjcsetywb",
  "id" : 511981833077026817,
  "in_reply_to_status_id" : 511981585416343552,
  "created_at" : "2014-09-16 20:55:55 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katie rose",
      "screen_name" : "katierosepipkin",
      "indices" : [ 3, 19 ],
      "id_str" : "28825574",
      "id" : 28825574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511980282082123776",
  "text" : "RT @katierosepipkin: \u3000\n\n\u3000\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\n\u3000\u258F\uA386\uA394\uA387\uA388  \uA38B\uA2B7\uA38C\uA38E\uA38F\uA390\uA391\uA392\uA393\uA394\uA395\uA396\uA397\uA2AA\uA399\uA39A  \u258F\n\u3000\u258F\uA2A3\uA2A5\uA2A7\uA2A8\uA2AA\uA2AB \uA2AC\uA2AD\uA2AE\uA2AF\uA2B1\uA2B2\uA2B5\uA2B7\uA2B9\uA2BA\uA2BB\uA2BC\uA2BD\uA2BF  \u258F\n\u3000\u2594\u2594\u2572\u2571\u2594\u2594\u2594\u2594\u2594\u2594\u2594\u2594\u2594\n\n\u3000     \u3000\uD83C\uDF11\n\n\u3000\u3000\u3000\u3000\u3000",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505416675785965568",
    "text" : "\u3000\n\n\u3000\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\u2581\n\u3000\u258F\uA386\uA394\uA387\uA388  \uA38B\uA2B7\uA38C\uA38E\uA38F\uA390\uA391\uA392\uA393\uA394\uA395\uA396\uA397\uA2AA\uA399\uA39A  \u258F\n\u3000\u258F\uA2A3\uA2A5\uA2A7\uA2A8\uA2AA\uA2AB \uA2AC\uA2AD\uA2AE\uA2AF\uA2B1\uA2B2\uA2B5\uA2B7\uA2B9\uA2BA\uA2BB\uA2BC\uA2BD\uA2BF  \u258F\n\u3000\u2594\u2594\u2572\u2571\u2594\u2594\u2594\u2594\u2594\u2594\u2594\u2594\u2594\n\n\u3000     \u3000\uD83C\uDF11\n\n\u3000\u3000\u3000\u3000\u3000",
    "id" : 505416675785965568,
    "created_at" : "2014-08-29 18:08:20 +0000",
    "user" : {
      "name" : "katie rose",
      "screen_name" : "katierosepipkin",
      "protected" : false,
      "id_str" : "28825574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522519044251869185\/VCQZz_O3_normal.jpeg",
      "id" : 28825574,
      "verified" : false
    }
  },
  "id" : 511980282082123776,
  "created_at" : "2014-09-16 20:49:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrminer",
      "screen_name" : "mrminer",
      "indices" : [ 0, 8 ],
      "id_str" : "16519576",
      "id" : 16519576
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 9, 18 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511976311607554049",
  "geo" : { },
  "id_str" : "511977839092973568",
  "in_reply_to_user_id" : 16519576,
  "text" : "@mrminer @LawnMemo just checked iTunes. Plays: 24. Nearly 9 hours of listening to this. I can't get enough of it.",
  "id" : 511977839092973568,
  "in_reply_to_status_id" : 511976311607554049,
  "created_at" : "2014-09-16 20:40:03 +0000",
  "in_reply_to_screen_name" : "mrminer",
  "in_reply_to_user_id_str" : "16519576",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/jgwOX9jNva",
      "expanded_url" : "http:\/\/www.synthesiagame.com\/",
      "display_url" : "synthesiagame.com"
    } ]
  },
  "geo" : { },
  "id_str" : "511975141685751809",
  "text" : "Anyone tried out http:\/\/t.co\/jgwOX9jNva ? Any good? Worth buying a MIDI adapter for?",
  "id" : 511975141685751809,
  "created_at" : "2014-09-16 20:29:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511963869347315712",
  "geo" : { },
  "id_str" : "511965785653116928",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine ooh maybe ! we'll consider it. \/cc @nickelcityruby",
  "id" : 511965785653116928,
  "in_reply_to_status_id" : 511963869347315712,
  "created_at" : "2014-09-16 19:52:09 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511947513583382528",
  "geo" : { },
  "id_str" : "511956285059637248",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx Anything team related, how to work in a group, together",
  "id" : 511956285059637248,
  "in_reply_to_status_id" : 511947513583382528,
  "created_at" : "2014-09-16 19:14:24 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 0, 8 ],
      "id_str" : "14436348",
      "id" : 14436348
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 9, 16 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 17, 28 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511931014831034368",
  "geo" : { },
  "id_str" : "511944630804692992",
  "in_reply_to_user_id" : 14436348,
  "text" : "@adarshp @jyurek @thoughtbot a viking eats pho in NYC, breaks a bell in central park during a rodeo then flees westward to SF",
  "id" : 511944630804692992,
  "in_reply_to_status_id" : 511931014831034368,
  "created_at" : "2014-09-16 18:28:06 +0000",
  "in_reply_to_screen_name" : "adarshp",
  "in_reply_to_user_id_str" : "14436348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/9kk11gLNLZ",
      "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014",
      "display_url" : "ti.to\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511942693682180097",
  "text" : "RT @nickelcityruby: Tickets are selling and you don't want to be left out of #ncrc14 - grab yours now while they are still available! https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 57, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/9kk11gLNLZ",
        "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/nickel-city-ruby-conf-2014",
        "display_url" : "ti.to\/nickelcityruby\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "511942567223898114",
    "text" : "Tickets are selling and you don't want to be left out of #ncrc14 - grab yours now while they are still available! https:\/\/t.co\/9kk11gLNLZ",
    "id" : 511942567223898114,
    "created_at" : "2014-09-16 18:19:54 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 511942693682180097,
  "created_at" : "2014-09-16 18:20:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 6, 21 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/hve1Sv08CL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Wcz_kDCBTBk",
      "display_url" : "youtube.com\/watch?v=Wcz_kD\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "511929273725112320",
  "geo" : { },
  "id_str" : "511929411428302848",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu @nickelcityruby for $99, anything is possible https:\/\/t.co\/hve1Sv08CL",
  "id" : 511929411428302848,
  "in_reply_to_status_id" : 511929273725112320,
  "created_at" : "2014-09-16 17:27:37 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/7DU6BNejeD",
      "expanded_url" : "http:\/\/bryan.io\/post\/97658826431\/everything-that-went-wrong-while-building-the-tumblr",
      "display_url" : "bryan.io\/post\/976588264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511927543226564608",
  "text" : "The hoops iOS devs have to jump through are on fire, way too high, extremely dangerous, but no one seems to care http:\/\/t.co\/7DU6BNejeD",
  "id" : 511927543226564608,
  "created_at" : "2014-09-16 17:20:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 78, 93 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/yhjteaaViy",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "511884019114328065",
  "text" : "You've got until Friday to get your t-shirt size and our great hotel rate for @nickelcityruby locked down: http:\/\/t.co\/yhjteaaViy",
  "id" : 511884019114328065,
  "created_at" : "2014-09-16 14:27:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 0, 11 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511883471040823296",
  "geo" : { },
  "id_str" : "511883685474205697",
  "in_reply_to_user_id" : 25678101,
  "text" : "@natebenson what building is that?",
  "id" : 511883685474205697,
  "in_reply_to_status_id" : 511883471040823296,
  "created_at" : "2014-09-16 14:25:55 +0000",
  "in_reply_to_screen_name" : "natebenson",
  "in_reply_to_user_id_str" : "25678101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aanand Prasad",
      "screen_name" : "aanand",
      "indices" : [ 0, 7 ],
      "id_str" : "14149919",
      "id" : 14149919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511860528096890880",
  "geo" : { },
  "id_str" : "511863559169384448",
  "in_reply_to_user_id" : 14149919,
  "text" : "@aanand everything to do with game development and developers makes me sick.",
  "id" : 511863559169384448,
  "in_reply_to_status_id" : 511860528096890880,
  "created_at" : "2014-09-16 13:05:57 +0000",
  "in_reply_to_screen_name" : "aanand",
  "in_reply_to_user_id_str" : "14149919",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511671805543972864",
  "geo" : { },
  "id_str" : "511673002736361472",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Well, TIL. Are these easy to extend with custom attributes? i.e., show button on one device, not other",
  "id" : 511673002736361472,
  "in_reply_to_status_id" : 511671805543972864,
  "created_at" : "2014-09-16 00:28:44 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511671598869274624",
  "text" : "Is there any way to avoid constantly checking if your device is an iPad or iPhone in Universal apps? Seems awful.",
  "id" : 511671598869274624,
  "created_at" : "2014-09-16 00:23:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Robinson",
      "screen_name" : "robins36",
      "indices" : [ 0, 9 ],
      "id_str" : "310290717",
      "id" : 310290717
    }, {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 10, 23 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511590955347349504",
  "geo" : { },
  "id_str" : "511593910112509953",
  "in_reply_to_user_id" : 310290717,
  "text" : "@robins36 @TommyCreenan this is the worst name for an eating establishment in history",
  "id" : 511593910112509953,
  "in_reply_to_status_id" : 511590955347349504,
  "created_at" : "2014-09-15 19:14:27 +0000",
  "in_reply_to_screen_name" : "robins36",
  "in_reply_to_user_id_str" : "310290717",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 3, 12 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 53, 68 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/oDrmLuket8",
      "expanded_url" : "http:\/\/cl.ly\/2r3P073n3J11",
      "display_url" : "cl.ly\/2r3P073n3J11"
    } ]
  },
  "geo" : { },
  "id_str" : "511576677978079232",
  "text" : "RT @sebasoga: Looking forward to having a great time @nickelcityruby. Still haven't bought you ticket? Get 20% off here: http:\/\/t.co\/oDrmLu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/eventualtweet.com\" rel=\"nofollow\"\u003EEventualTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 39, 54 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/oDrmLuket8",
        "expanded_url" : "http:\/\/cl.ly\/2r3P073n3J11",
        "display_url" : "cl.ly\/2r3P073n3J11"
      } ]
    },
    "geo" : { },
    "id_str" : "511529883617337346",
    "text" : "Looking forward to having a great time @nickelcityruby. Still haven't bought you ticket? Get 20% off here: http:\/\/t.co\/oDrmLuket8",
    "id" : 511529883617337346,
    "created_at" : "2014-09-15 15:00:02 +0000",
    "user" : {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "protected" : false,
      "id_str" : "41438974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488894836628418560\/teTisCDG_normal.jpeg",
      "id" : 41438974,
      "verified" : false
    }
  },
  "id" : 511576677978079232,
  "created_at" : "2014-09-15 18:05:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KFgP5wWJK7",
      "expanded_url" : "http:\/\/itunes.com\/soi-remove",
      "display_url" : "itunes.com\/soi-remove"
    } ]
  },
  "geo" : { },
  "id_str" : "511573977639055360",
  "text" : "RT @SteveStreza: Saner heads prevail. Apple now has a way to remove the U2 album from your library. http:\/\/t.co\/KFgP5wWJK7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/KFgP5wWJK7",
        "expanded_url" : "http:\/\/itunes.com\/soi-remove",
        "display_url" : "itunes.com\/soi-remove"
      } ]
    },
    "geo" : { },
    "id_str" : "511573931543650304",
    "text" : "Saner heads prevail. Apple now has a way to remove the U2 album from your library. http:\/\/t.co\/KFgP5wWJK7",
    "id" : 511573931543650304,
    "created_at" : "2014-09-15 17:55:04 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 511573977639055360,
  "created_at" : "2014-09-15 17:55:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/511565333207842816\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ge9lsscHTv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxlx9SRCcAMo7mj.jpg",
      "id_str" : "511565330372521987",
      "id" : 511565330372521987,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxlx9SRCcAMo7mj.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/ge9lsscHTv"
    } ],
    "hashtags" : [ {
      "text" : "ncr14",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511565579681923072",
  "text" : "RT @nickelcityruby: Prototyping some swag bag designs #ncr14 http:\/\/t.co\/ge9lsscHTv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/511565333207842816\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/ge9lsscHTv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxlx9SRCcAMo7mj.jpg",
        "id_str" : "511565330372521987",
        "id" : 511565330372521987,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxlx9SRCcAMo7mj.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/ge9lsscHTv"
      } ],
      "hashtags" : [ {
        "text" : "ncr14",
        "indices" : [ 34, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511565333207842816",
    "text" : "Prototyping some swag bag designs #ncr14 http:\/\/t.co\/ge9lsscHTv",
    "id" : 511565333207842816,
    "created_at" : "2014-09-15 17:20:54 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 511565579681923072,
  "created_at" : "2014-09-15 17:21:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511561889177161728",
  "text" : "RT @aquaranto: I have a lot of patience for this kind of thing but, for the record, an intelligent woman in tech is not a \"smart cookie\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511561641024974848",
    "text" : "I have a lot of patience for this kind of thing but, for the record, an intelligent woman in tech is not a \"smart cookie\"",
    "id" : 511561641024974848,
    "created_at" : "2014-09-15 17:06:14 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 511561889177161728,
  "created_at" : "2014-09-15 17:07:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 63, 78 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7wIth3jyDa",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "511520423339507713",
  "text" : "RT @aspleenic: Seriously - if you aren't planning on coming to @nickelcityruby you are going to miss out on a whole lot of awesome http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 48, 63 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/7wIth3jyDa",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "510853120591937536",
    "text" : "Seriously - if you aren't planning on coming to @nickelcityruby you are going to miss out on a whole lot of awesome http:\/\/t.co\/7wIth3jyDa",
    "id" : 510853120591937536,
    "created_at" : "2014-09-13 18:10:49 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 511520423339507713,
  "created_at" : "2014-09-15 14:22:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511367446733664256",
  "geo" : { },
  "id_str" : "511381217682280449",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej I\u2019ve got a Dropbox folder full of filters if you want them. I treat LR like a fancy and fussy Instagram",
  "id" : 511381217682280449,
  "in_reply_to_status_id" : 511367446733664256,
  "created_at" : "2014-09-15 05:09:17 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 5, 10 ],
      "id_str" : "676573",
      "id" : 676573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/oC5KCTETjY",
      "expanded_url" : "http:\/\/quaran.to\/gifs\/0007\/",
      "display_url" : "quaran.to\/gifs\/0007\/"
    } ]
  },
  "in_reply_to_status_id_str" : "511297077087698944",
  "geo" : { },
  "id_str" : "511305147268362241",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh @tobi nothing has ever come clos. This reminded me of it: http:\/\/t.co\/oC5KCTETjY",
  "id" : 511305147268362241,
  "in_reply_to_status_id" : 511297077087698944,
  "created_at" : "2014-09-15 00:07:01 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511170246183776256",
  "geo" : { },
  "id_str" : "511170415406759936",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak call it \"Neue American\" and you'll get the hipsters back",
  "id" : 511170415406759936,
  "in_reply_to_status_id" : 511170246183776256,
  "created_at" : "2014-09-14 15:11:38 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510626784950624257",
  "geo" : { },
  "id_str" : "511168677811462144",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 holy shit, you're on Tufte's ranch?",
  "id" : 511168677811462144,
  "in_reply_to_status_id" : 510626784950624257,
  "created_at" : "2014-09-14 15:04:44 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/511161513936441344\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/IN182b8ITH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxgCsC3IYAAmg89.jpg",
      "id_str" : "511161513412157440",
      "id" : 511161513412157440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxgCsC3IYAAmg89.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IN182b8ITH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511163007141834752",
  "text" : "RT @kevinpurdy: GOD BLESS YOU, CORPORATE TRANSACTION! http:\/\/t.co\/IN182b8ITH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/511161513936441344\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/IN182b8ITH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxgCsC3IYAAmg89.jpg",
        "id_str" : "511161513412157440",
        "id" : 511161513412157440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxgCsC3IYAAmg89.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IN182b8ITH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511161513936441344",
    "text" : "GOD BLESS YOU, CORPORATE TRANSACTION! http:\/\/t.co\/IN182b8ITH",
    "id" : 511161513936441344,
    "created_at" : "2014-09-14 14:36:16 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 511163007141834752,
  "created_at" : "2014-09-14 14:42:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/14YZ7HuQgi",
      "expanded_url" : "http:\/\/vimeo.com\/m\/94502406",
      "display_url" : "vimeo.com\/m\/94502406"
    } ]
  },
  "geo" : { },
  "id_str" : "510985348063571968",
  "text" : "Hilarious little animated short http:\/\/t.co\/14YZ7HuQgi",
  "id" : 510985348063571968,
  "created_at" : "2014-09-14 02:56:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/U2rX2JiW3M",
      "expanded_url" : "https:\/\/github.com\/d235j\/360Controller",
      "display_url" : "github.com\/d235j\/360Contr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510970575980752896",
  "text" : "Octodad works great on OSX with Xbox 360 controllers and this driver: https:\/\/t.co\/U2rX2JiW3M",
  "id" : 510970575980752896,
  "created_at" : "2014-09-14 01:57:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/GTqUfGDzzX",
      "expanded_url" : "http:\/\/vimeo.com\/sandwichvideo\/aeropress",
      "display_url" : "vimeo.com\/sandwichvideo\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510943608757686272",
  "text" : "AeroPress \u201CRitual\u201D http:\/\/t.co\/GTqUfGDzzX",
  "id" : 510943608757686272,
  "created_at" : "2014-09-14 00:10:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510800331865726976",
  "text" : "@AlMehltretter GASP are you saying people probably leave their house at a normal time during the day to do things?",
  "id" : 510800331865726976,
  "created_at" : "2014-09-13 14:41:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510789739856015360",
  "geo" : { },
  "id_str" : "510789866444300288",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt LESS THAN YESTERDAY",
  "id" : 510789866444300288,
  "in_reply_to_status_id" : 510789739856015360,
  "created_at" : "2014-09-13 13:59:28 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/OS77bh5e1Y",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/54144d77498e6c4ef77e7a5a?s=_Tm2vpBwaczp2xZCQeGVqF1zvNk&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.923291, -78.876985 ]
  },
  "id_str" : "510789559719043072",
  "text" : "I'm at Caffe Aroma in Buffalo, NY https:\/\/t.co\/OS77bh5e1Y",
  "id" : 510789559719043072,
  "created_at" : "2014-09-13 13:58:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/5xs36P26vp",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=DNL0DucIViI",
      "display_url" : "m.youtube.com\/watch?v=DNL0Du\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510769934054350848",
  "text" : "Never heard of Octodad before last night. This game is a riot. http:\/\/t.co\/5xs36P26vp",
  "id" : 510769934054350848,
  "created_at" : "2014-09-13 12:40:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/510607758115495936\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/WDXeUlhseE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxYLDIhCEAEDks1.jpg",
      "id_str" : "510607756206673921",
      "id" : 510607756206673921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxYLDIhCEAEDks1.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WDXeUlhseE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510607758115495936",
  "text" : "Current status http:\/\/t.co\/WDXeUlhseE",
  "id" : 510607758115495936,
  "created_at" : "2014-09-13 01:55:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510601817303314433",
  "geo" : { },
  "id_str" : "510602071020957697",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents to be the first place for a few weeks of my friends are so cute I can\u2019t have to go home to a new phone case you want me too",
  "id" : 510602071020957697,
  "in_reply_to_status_id" : 510601817303314433,
  "created_at" : "2014-09-13 01:33:14 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Norman",
      "screen_name" : "jaredrnorman",
      "indices" : [ 0, 13 ],
      "id_str" : "199937424",
      "id" : 199937424
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 14, 28 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510593780450594816",
  "geo" : { },
  "id_str" : "510601615997669376",
  "in_reply_to_user_id" : 199937424,
  "text" : "@jaredrnorman @Carols10cents I love the fact is the most recent version and the other side is a very nice but it doesn\u2019t the first place",
  "id" : 510601615997669376,
  "in_reply_to_status_id" : 510593780450594816,
  "created_at" : "2014-09-13 01:31:26 +0000",
  "in_reply_to_screen_name" : "jaredrnorman",
  "in_reply_to_user_id_str" : "199937424",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/hDq0GZNf6Q",
      "expanded_url" : "https:\/\/flic.kr\/p\/pbH7Cz",
      "display_url" : "flic.kr\/p\/pbH7Cz"
    } ]
  },
  "geo" : { },
  "id_str" : "510590059779596289",
  "text" : "Sunday alley https:\/\/t.co\/hDq0GZNf6Q",
  "id" : 510590059779596289,
  "created_at" : "2014-09-13 00:45:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510584294272561152",
  "text" : "RT @rubygems_status: We're currently experiencing networking connectivity issues between machines in our production cluster. Working to rec\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510584089750306816",
    "text" : "We're currently experiencing networking connectivity issues between machines in our production cluster. Working to recover service ASAP!",
    "id" : 510584089750306816,
    "created_at" : "2014-09-13 00:21:47 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 510584294272561152,
  "created_at" : "2014-09-13 00:22:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMG",
      "screen_name" : "UnionAMG",
      "indices" : [ 0, 9 ],
      "id_str" : "130943883",
      "id" : 130943883
    }, {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 10, 21 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510578959025971200",
  "geo" : { },
  "id_str" : "510583559480823808",
  "in_reply_to_user_id" : 130943883,
  "text" : "@UnionAMG @nickelcity holy fuck, what is wrong with these people",
  "id" : 510583559480823808,
  "in_reply_to_status_id" : 510578959025971200,
  "created_at" : "2014-09-13 00:19:41 +0000",
  "in_reply_to_screen_name" : "UnionAMG",
  "in_reply_to_user_id_str" : "130943883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/3IfqkW0kCI",
      "expanded_url" : "http:\/\/david.li\/flow\/",
      "display_url" : "david.li\/flow\/"
    } ]
  },
  "geo" : { },
  "id_str" : "510582406454067200",
  "text" : "Particle systems are the best http:\/\/t.co\/3IfqkW0kCI",
  "id" : 510582406454067200,
  "created_at" : "2014-09-13 00:15:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian T. Rice",
      "screen_name" : "BrianTRice",
      "indices" : [ 3, 14 ],
      "id_str" : "651403",
      "id" : 651403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510578471177699328",
  "text" : "RT @BrianTRice: git, ruby, XCode, and Visual Studio are right at the top of this list.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "510513394047123456",
    "geo" : { },
    "id_str" : "510513545289547776",
    "in_reply_to_user_id" : 651403,
    "text" : "git, ruby, XCode, and Visual Studio are right at the top of this list.",
    "id" : 510513545289547776,
    "in_reply_to_status_id" : 510513394047123456,
    "created_at" : "2014-09-12 19:41:28 +0000",
    "in_reply_to_screen_name" : "BrianTRice",
    "in_reply_to_user_id_str" : "651403",
    "user" : {
      "name" : "Brian T. Rice",
      "screen_name" : "BrianTRice",
      "protected" : false,
      "id_str" : "651403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458739899869323264\/H1RjB43H_normal.jpeg",
      "id" : 651403,
      "verified" : false
    }
  },
  "id" : 510578471177699328,
  "created_at" : "2014-09-12 23:59:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian T. Rice",
      "screen_name" : "BrianTRice",
      "indices" : [ 3, 14 ],
      "id_str" : "651403",
      "id" : 651403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510578467922911233",
  "text" : "RT @BrianTRice: Dev stack narcissism: where every tool demands that you understand its idioms without ever explaining them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510513394047123456",
    "text" : "Dev stack narcissism: where every tool demands that you understand its idioms without ever explaining them.",
    "id" : 510513394047123456,
    "created_at" : "2014-09-12 19:40:52 +0000",
    "user" : {
      "name" : "Brian T. Rice",
      "screen_name" : "BrianTRice",
      "protected" : false,
      "id_str" : "651403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458739899869323264\/H1RjB43H_normal.jpeg",
      "id" : 651403,
      "verified" : false
    }
  },
  "id" : 510578467922911233,
  "created_at" : "2014-09-12 23:59:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510573324314095617",
  "geo" : { },
  "id_str" : "510573807879196672",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel In a row and the rest of my friends and your family is so much better now that the company said in the world is full of the year",
  "id" : 510573807879196672,
  "in_reply_to_status_id" : 510573324314095617,
  "created_at" : "2014-09-12 23:40:56 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510571307075792896",
  "geo" : { },
  "id_str" : "510573131392483328",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents the best way for the next two weeks ago I had a good time waster but I have no idea what to say I have to go back and forth",
  "id" : 510573131392483328,
  "in_reply_to_status_id" : 510571307075792896,
  "created_at" : "2014-09-12 23:38:15 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 3, 17 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 19, 25 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510573031463194624",
  "text" : "RT @Carols10cents: @qrush I hate that would like Twitter and the Pittsburgh Steelers jersey, you can only stop and I think my head to be ba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetlanes.com\" rel=\"nofollow\"\u003ETweet Lanes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "510494169370853376",
    "geo" : { },
    "id_str" : "510571307075792896",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush I hate that would like Twitter and the Pittsburgh Steelers jersey, you can only stop and I think my head to be back stage. I'm not up",
    "id" : 510571307075792896,
    "in_reply_to_status_id" : 510494169370853376,
    "created_at" : "2014-09-12 23:31:00 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "protected" : false,
      "id_str" : "194688433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446291681252364288\/_okxMUY1_normal.jpeg",
      "id" : 194688433,
      "verified" : false
    }
  },
  "id" : 510573031463194624,
  "created_at" : "2014-09-12 23:37:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 14, 29 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510552648509300736",
  "geo" : { },
  "id_str" : "510554987659657216",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach @franklinwebber true but statement still stands",
  "id" : 510554987659657216,
  "in_reply_to_status_id" : 510552648509300736,
  "created_at" : "2014-09-12 22:26:09 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/510551245958823936\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/uhHF7hWdXa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxXXppjCAAAlmBv.png",
      "id_str" : "510551243303813120",
      "id" : 510551243303813120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxXXppjCAAAlmBv.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uhHF7hWdXa"
    } ],
    "hashtags" : [ {
      "text" : "track",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "height",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "HealthKit",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510551245958823936",
  "text" : "I can\u2019t wait to #track my #height with #HealthKit http:\/\/t.co\/uhHF7hWdXa",
  "id" : 510551245958823936,
  "created_at" : "2014-09-12 22:11:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 0, 15 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510549335004573696",
  "geo" : { },
  "id_str" : "510549865810501632",
  "in_reply_to_user_id" : 81525784,
  "text" : "@franklinwebber who pays for this?",
  "id" : 510549865810501632,
  "in_reply_to_status_id" : 510549335004573696,
  "created_at" : "2014-09-12 22:05:48 +0000",
  "in_reply_to_screen_name" : "franklinwebber",
  "in_reply_to_user_id_str" : "81525784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/NKiXxgld0n",
      "expanded_url" : "http:\/\/bit.ly\/1pgDr7B",
      "display_url" : "bit.ly\/1pgDr7B"
    } ]
  },
  "geo" : { },
  "id_str" : "510548991847575552",
  "text" : "RT @ashedryden: Boston: do me a favor and get your tickets\/ping your friends to get tickets tonight if possible: http:\/\/t.co\/NKiXxgld0n Sta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/NKiXxgld0n",
        "expanded_url" : "http:\/\/bit.ly\/1pgDr7B",
        "display_url" : "bit.ly\/1pgDr7B"
      } ]
    },
    "geo" : { },
    "id_str" : "510548929717731328",
    "text" : "Boston: do me a favor and get your tickets\/ping your friends to get tickets tonight if possible: http:\/\/t.co\/NKiXxgld0n Starting at $15",
    "id" : 510548929717731328,
    "created_at" : "2014-09-12 22:02:05 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 510548991847575552,
  "created_at" : "2014-09-12 22:02:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 3, 8 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510546065032900608",
  "text" : "RT @coda: iOS 8 democratizes Markov chains which is a great day to be a good day to be a little bit of a new one is the best thing ever is \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510545867661512704",
    "text" : "iOS 8 democratizes Markov chains which is a great day to be a good day to be a little bit of a new one is the best thing ever is when you ha",
    "id" : 510545867661512704,
    "created_at" : "2014-09-12 21:49:54 +0000",
    "user" : {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "protected" : false,
      "id_str" : "637533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530569133880926208\/HVC_bWBj_normal.jpeg",
      "id" : 637533,
      "verified" : false
    }
  },
  "id" : 510546065032900608,
  "created_at" : "2014-09-12 21:50:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510534712691924992",
  "text" : "20 days to @nickelcityruby! Woot!",
  "id" : 510534712691924992,
  "created_at" : "2014-09-12 21:05:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510532951109410816",
  "geo" : { },
  "id_str" : "510533026187444224",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik who drew these?",
  "id" : 510533026187444224,
  "in_reply_to_status_id" : 510532951109410816,
  "created_at" : "2014-09-12 20:58:53 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 8, 15 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510527343434424320",
  "geo" : { },
  "id_str" : "510529023802228736",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss @soffes oof",
  "id" : 510529023802228736,
  "in_reply_to_status_id" : 510527343434424320,
  "created_at" : "2014-09-12 20:42:59 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/510517816567418881\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/fBF9KSCZft",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxW5P1ACMAEx4Di.png",
      "id_str" : "510517814352818177",
      "id" : 510517814352818177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxW5P1ACMAEx4Di.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fBF9KSCZft"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510517816567418881",
  "text" : "iOS8 is bullshit http:\/\/t.co\/fBF9KSCZft",
  "id" : 510517816567418881,
  "created_at" : "2014-09-12 19:58:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510494169370853376",
  "text" : "The only way I can get past it is not an option for me to the gym and the rest of my friends and I don\u2019t know how I feel so good at it",
  "id" : 510494169370853376,
  "created_at" : "2014-09-12 18:24:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510494031298560000",
  "text" : "I\u2019m I love it so I can get the hang of this month in the morning is a great way for a while ago I have to go home to the point of view",
  "id" : 510494031298560000,
  "created_at" : "2014-09-12 18:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510493861810929664",
  "text" : "I have no idea what to say I have to go home to the fact is a great way of the day before my eyes are the same thing as the new version",
  "id" : 510493861810929664,
  "created_at" : "2014-09-12 18:23:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510492744930713600",
  "text" : "Last 3 tweets brought to by the iOS8 predictive keyboard",
  "id" : 510492744930713600,
  "created_at" : "2014-09-12 18:18:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510492638345039872",
  "text" : "I love you so much fun and I have to be a good day to be a good time to get a new one is the best thing ever is when you have to be a good",
  "id" : 510492638345039872,
  "created_at" : "2014-09-12 18:18:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510492469369139200",
  "text" : "The fact I can see it as an excuse for the next few weeks of a sudden it was you at all times in a while ago but the fact I can see it",
  "id" : 510492469369139200,
  "created_at" : "2014-09-12 18:17:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510492387487916033",
  "text" : "I\u2019m to get my money to pay to see my friends to be able the first place I have no clue who I was in my room for a long way in hell",
  "id" : 510492387487916033,
  "created_at" : "2014-09-12 18:17:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510443576199622656",
  "geo" : { },
  "id_str" : "510463773941837824",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale that's fantastic.",
  "id" : 510463773941837824,
  "in_reply_to_status_id" : 510443576199622656,
  "created_at" : "2014-09-12 16:23:42 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 3, 12 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "indices" : [ 42, 51 ],
      "id_str" : "19278778",
      "id" : 19278778
    }, {
      "name" : "Rocky Mountain Ruby",
      "screen_name" : "rockymtnruby",
      "indices" : [ 59, 72 ],
      "id_str" : "288454983",
      "id" : 288454983
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 80, 95 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Web Directions",
      "screen_name" : "webdirections",
      "indices" : [ 103, 117 ],
      "id_str" : "5388702",
      "id" : 5388702
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 125, 134 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zomg",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "loltravel",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510422420419657728",
  "text" : "RT @sarahmei: Soooo maybe I'll see you at @gogaruco and\/or @rockymtnruby and\/or @nickelcityruby and\/or @webdirections and\/or @rubyconf? #zo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Golden Gate RubyConf",
        "screen_name" : "gogaruco",
        "indices" : [ 28, 37 ],
        "id_str" : "19278778",
        "id" : 19278778
      }, {
        "name" : "Rocky Mountain Ruby",
        "screen_name" : "rockymtnruby",
        "indices" : [ 45, 58 ],
        "id_str" : "288454983",
        "id" : 288454983
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 66, 81 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Web Directions",
        "screen_name" : "webdirections",
        "indices" : [ 89, 103 ],
        "id_str" : "5388702",
        "id" : 5388702
      }, {
        "name" : "rubyconf",
        "screen_name" : "rubyconf",
        "indices" : [ 111, 120 ],
        "id_str" : "16222737",
        "id" : 16222737
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zomg",
        "indices" : [ 122, 127 ]
      }, {
        "text" : "loltravel",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510251614972567553",
    "text" : "Soooo maybe I'll see you at @gogaruco and\/or @rockymtnruby and\/or @nickelcityruby and\/or @webdirections and\/or @rubyconf? #zomg #loltravel",
    "id" : 510251614972567553,
    "created_at" : "2014-09-12 02:20:39 +0000",
    "user" : {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "protected" : false,
      "id_str" : "14164724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564645861771079680\/i-bwhBp0_normal.jpeg",
      "id" : 14164724,
      "verified" : false
    }
  },
  "id" : 510422420419657728,
  "created_at" : "2014-09-12 13:39:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 14, 27 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510274336130080769",
  "geo" : { },
  "id_str" : "510278021412950017",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @steveklabnik replace crowd cheering with...well, whatever suits you. Keep crying.",
  "id" : 510278021412950017,
  "in_reply_to_status_id" : 510274336130080769,
  "created_at" : "2014-09-12 04:05:35 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510271583211229185",
  "geo" : { },
  "id_str" : "510272669409746944",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik This is such Livejournal fanfic material it's insane.",
  "id" : 510272669409746944,
  "in_reply_to_status_id" : 510271583211229185,
  "created_at" : "2014-09-12 03:44:19 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/OaNqLDLpmb",
      "expanded_url" : "http:\/\/jiggity.com\/steve.html",
      "display_url" : "jiggity.com\/steve.html"
    } ]
  },
  "geo" : { },
  "id_str" : "510266913331904512",
  "text" : "In case you haven't read your dose of Steve Jobs fanfiction lately - http:\/\/t.co\/OaNqLDLpmb",
  "id" : 510266913331904512,
  "created_at" : "2014-09-12 03:21:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/OQ41iAW8G7",
      "expanded_url" : "http:\/\/www.phishtracks.com\/shows\/2014-08-29\/simple",
      "display_url" : "phishtracks.com\/shows\/2014-08-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510218937968377856",
  "text" : "Still can't get over 8\/29\/14's Simple. Just explodes and extrapolates into something amazing. http:\/\/t.co\/OQ41iAW8G7",
  "id" : 510218937968377856,
  "created_at" : "2014-09-12 00:10:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 81, 91 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fossetcon",
      "indices" : [ 31, 41 ]
    }, {
      "text" : "ncrc14",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510208024213204993",
  "text" : "RT @nickelcityruby: Are you at #fossetcon this week?  Find #ncrc14 organizer PJ (@aspleenic) to find out how to get to Buffalo for Nickel C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PJ Hagerty",
        "screen_name" : "aspleenic",
        "indices" : [ 61, 71 ],
        "id_str" : "31435721",
        "id" : 31435721
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fossetcon",
        "indices" : [ 11, 21 ]
      }, {
        "text" : "ncrc14",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510156612620017664",
    "text" : "Are you at #fossetcon this week?  Find #ncrc14 organizer PJ (@aspleenic) to find out how to get to Buffalo for Nickel City Ruby!!",
    "id" : 510156612620017664,
    "created_at" : "2014-09-11 20:03:09 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 510208024213204993,
  "created_at" : "2014-09-11 23:27:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blithe Rocher",
      "screen_name" : "Blithe",
      "indices" : [ 0, 7 ],
      "id_str" : "6304322",
      "id" : 6304322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510132266266546176",
  "geo" : { },
  "id_str" : "510132377834647552",
  "in_reply_to_user_id" : 6304322,
  "text" : "@Blithe Apparently won't be open until 2016. I am not a karaoke guy sadly.",
  "id" : 510132377834647552,
  "in_reply_to_status_id" : 510132266266546176,
  "created_at" : "2014-09-11 18:26:51 +0000",
  "in_reply_to_screen_name" : "Blithe",
  "in_reply_to_user_id_str" : "6304322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Ward",
      "screen_name" : "eviltrout",
      "indices" : [ 0, 10 ],
      "id_str" : "16712921",
      "id" : 16712921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510130842966843392",
  "geo" : { },
  "id_str" : "510130969269903360",
  "in_reply_to_user_id" : 16712921,
  "text" : "@eviltrout WHAT (Also, we're getting a Hero here)",
  "id" : 510130969269903360,
  "in_reply_to_status_id" : 510130842966843392,
  "created_at" : "2014-09-11 18:21:15 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/gjMHSSptiQ",
      "expanded_url" : "http:\/\/ift.tt\/X1KoP9",
      "display_url" : "ift.tt\/X1KoP9"
    } ]
  },
  "geo" : { },
  "id_str" : "510127678721388544",
  "text" : "GIF \u211620: http:\/\/t.co\/gjMHSSptiQ",
  "id" : 510127678721388544,
  "created_at" : "2014-09-11 18:08:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 3, 14 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 95, 109 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 134, 142 ]
    }, {
      "text" : "womenwhocode",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/dzSX2mxHXM",
      "expanded_url" : "http:\/\/www.meetup.com\/Girl-Develop-It-Buffalo\/events\/203391592\/",
      "display_url" : "meetup.com\/Girl-Develop-I\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510115583908511744",
  "text" : "RT @gdiBuffalo: Learn about quick ways to get started with PHP tonight at Code &amp; Coffee at @coworkbuffalo  http:\/\/t.co\/dzSX2mxHXM #buffalo \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 79, 93 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 118, 126 ]
      }, {
        "text" : "womenwhocode",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/dzSX2mxHXM",
        "expanded_url" : "http:\/\/www.meetup.com\/Girl-Develop-It-Buffalo\/events\/203391592\/",
        "display_url" : "meetup.com\/Girl-Develop-I\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510114704388153345",
    "text" : "Learn about quick ways to get started with PHP tonight at Code &amp; Coffee at @coworkbuffalo  http:\/\/t.co\/dzSX2mxHXM #buffalo #womenwhocode",
    "id" : 510114704388153345,
    "created_at" : "2014-09-11 17:16:37 +0000",
    "user" : {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "protected" : false,
      "id_str" : "1232850504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3326614365\/de10a9f13010fc569fd25c1a6392366c_normal.png",
      "id" : 1232850504,
      "verified" : false
    }
  },
  "id" : 510115583908511744,
  "created_at" : "2014-09-11 17:20:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510110380107239424",
  "geo" : { },
  "id_str" : "510110603520667649",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit oh well. we still get compliments on IKEA stuff here because most people have never seen it. Kind of like the remote factor.",
  "id" : 510110603520667649,
  "in_reply_to_status_id" : 510110380107239424,
  "created_at" : "2014-09-11 17:00:19 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510109479778926592",
  "geo" : { },
  "id_str" : "510110025931427841",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski bummer, but i'm sure there has to be another home for them downtown...right?",
  "id" : 510110025931427841,
  "in_reply_to_status_id" : 510109479778926592,
  "created_at" : "2014-09-11 16:58:02 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510108581484826624",
  "geo" : { },
  "id_str" : "510109029268324352",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit I would love for an IKEA to be here...but they seem to build only in the middle of nowhere, atop of giant mountains\/hills",
  "id" : 510109029268324352,
  "in_reply_to_status_id" : 510108581484826624,
  "created_at" : "2014-09-11 16:54:04 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510096252718292992",
  "geo" : { },
  "id_str" : "510101591622316032",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl yuuuup. Done the NYC &lt;=&gt; Boston drive too many times to count.",
  "id" : 510101591622316032,
  "in_reply_to_status_id" : 510096252718292992,
  "created_at" : "2014-09-11 16:24:31 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510094273740423169",
  "text" : "Crazy idea for @nickelcityruby 2015: Movie night!!!?",
  "id" : 510094273740423169,
  "created_at" : "2014-09-11 15:55:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudine Ewing",
      "screen_name" : "ClaudineWgrz",
      "indices" : [ 3, 16 ],
      "id_str" : "467860742",
      "id" : 467860742
    }, {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "indices" : [ 131, 136 ],
      "id_str" : "15308015",
      "id" : 15308015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510093024630562816",
  "text" : "RT @ClaudineWgrz: Downtown Buffalo will soon have an AMC Theater with luxury lounge seats. Similar to the movie theater in Amherst @WGRZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WGRZ",
        "screen_name" : "WGRZ",
        "indices" : [ 113, 118 ],
        "id_str" : "15308015",
        "id" : 15308015
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510085215084380160",
    "text" : "Downtown Buffalo will soon have an AMC Theater with luxury lounge seats. Similar to the movie theater in Amherst @WGRZ",
    "id" : 510085215084380160,
    "created_at" : "2014-09-11 15:19:26 +0000",
    "user" : {
      "name" : "Claudine Ewing",
      "screen_name" : "ClaudineWgrz",
      "protected" : false,
      "id_str" : "467860742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3537259709\/26c5be508982b6b8602407f06f1d7275_normal.jpeg",
      "id" : 467860742,
      "verified" : true
    }
  },
  "id" : 510093024630562816,
  "created_at" : "2014-09-11 15:50:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/7WzSzj7a0D",
      "expanded_url" : "https:\/\/twitter.com\/eileenbuc\/status\/510083142590693377",
      "display_url" : "twitter.com\/eileenbuc\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510085826571550720",
  "text" : "Looks like @coworkbuffalo is going to be next door to a new AMC theater!! https:\/\/t.co\/7WzSzj7a0D",
  "id" : 510085826571550720,
  "created_at" : "2014-09-11 15:21:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eileen M. Uchitelle",
      "screen_name" : "eileencodes",
      "indices" : [ 26, 38 ],
      "id_str" : "390287545",
      "id" : 390287545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/mVS3iQ3mh0",
      "expanded_url" : "https:\/\/twitter.com\/dhh\/status\/510081264142278656",
      "display_url" : "twitter.com\/dhh\/status\/510\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510081528022310912",
  "text" : "Woo! Welcome to Basecamp, @eileencodes!! https:\/\/t.co\/mVS3iQ3mh0",
  "id" : 510081528022310912,
  "created_at" : "2014-09-11 15:04:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    }, {
      "name" : "Patrick Fulton",
      "screen_name" : "patrickfulton",
      "indices" : [ 8, 22 ],
      "id_str" : "8374852",
      "id" : 8374852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510074836656214017",
  "geo" : { },
  "id_str" : "510079331213656064",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd @patrickfulton nope! Literally made the deck that morning.",
  "id" : 510079331213656064,
  "in_reply_to_status_id" : 510074836656214017,
  "created_at" : "2014-09-11 14:56:04 +0000",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 7, 22 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510056271240642560",
  "geo" : { },
  "id_str" : "510068969877688320",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @nickelcityruby we will be adding this back on the ticket form tonight and will email everyone who's seigned up so far",
  "id" : 510068969877688320,
  "in_reply_to_status_id" : 510056271240642560,
  "created_at" : "2014-09-11 14:14:53 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 3, 10 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/L9sEP6MXeO",
      "expanded_url" : "https:\/\/storify.com\/ichris\/who-is-u2",
      "display_url" : "storify.com\/ichris\/who-is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510032019590356992",
  "text" : "RT @jyurek: This is almost worth having a U2 album forced upon me. https:\/\/t.co\/L9sEP6MXeO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/L9sEP6MXeO",
        "expanded_url" : "https:\/\/storify.com\/ichris\/who-is-u2",
        "display_url" : "storify.com\/ichris\/who-is-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510030547318747136",
    "text" : "This is almost worth having a U2 album forced upon me. https:\/\/t.co\/L9sEP6MXeO",
    "id" : 510030547318747136,
    "created_at" : "2014-09-11 11:42:13 +0000",
    "user" : {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "protected" : false,
      "id_str" : "6505422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/26559072\/498945207_94895e9527_s_normal.jpg",
      "id" : 6505422,
      "verified" : false
    }
  },
  "id" : 510032019590356992,
  "created_at" : "2014-09-11 11:48:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Ypn2v03PoI",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "510028743557922816",
  "text" : "RT @nickelcityruby: Register before 9\/19 to guarantee your shirt size! http:\/\/t.co\/Ypn2v03PoI Also, msg your favorite #ncrc14 speaker for a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/Ypn2v03PoI",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "509787415804784640",
    "text" : "Register before 9\/19 to guarantee your shirt size! http:\/\/t.co\/Ypn2v03PoI Also, msg your favorite #ncrc14 speaker for a custom discount code",
    "id" : 509787415804784640,
    "created_at" : "2014-09-10 19:36:05 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 510028743557922816,
  "created_at" : "2014-09-11 11:35:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "North of Normal",
      "screen_name" : "northofnormal",
      "indices" : [ 3, 17 ],
      "id_str" : "16184869",
      "id" : 16184869
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 34, 49 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 75, 89 ],
      "id_str" : "15913837",
      "id" : 15913837
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 96, 105 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510025992492949504",
  "text" : "RT @northofnormal: Registered for @NickelCityRuby today, can\u2019t wait to see @MutualArising &amp; @sarahmei  be smart out loud.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 15, 30 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Eric S",
        "screen_name" : "MutualArising",
        "indices" : [ 56, 70 ],
        "id_str" : "15913837",
        "id" : 15913837
      }, {
        "name" : "Sarah Mei",
        "screen_name" : "sarahmei",
        "indices" : [ 77, 86 ],
        "id_str" : "14164724",
        "id" : 14164724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509854440178737153",
    "text" : "Registered for @NickelCityRuby today, can\u2019t wait to see @MutualArising &amp; @sarahmei  be smart out loud.",
    "id" : 509854440178737153,
    "created_at" : "2014-09-11 00:02:25 +0000",
    "user" : {
      "name" : "North of Normal",
      "screen_name" : "northofnormal",
      "protected" : false,
      "id_str" : "16184869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2135442327\/twittericon_normal.jpg",
      "id" : 16184869,
      "verified" : false
    }
  },
  "id" : 510025992492949504,
  "created_at" : "2014-09-11 11:24:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Noller",
      "screen_name" : "jessenoller",
      "indices" : [ 0, 12 ],
      "id_str" : "14100497",
      "id" : 14100497
    }, {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 13, 21 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510021310664421376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924203265, -78.8793523893 ]
  },
  "id_str" : "510025909768691712",
  "in_reply_to_user_id" : 14100497,
  "text" : "@jessenoller @patio11 it\u2019s all on AWS now.",
  "id" : 510025909768691712,
  "in_reply_to_status_id" : 510021310664421376,
  "created_at" : "2014-09-11 11:23:47 +0000",
  "in_reply_to_screen_name" : "jessenoller",
  "in_reply_to_user_id_str" : "14100497",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 3, 11 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Q49MzJQ5Br",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "510025789421539328",
  "text" : "RT @patio11: http:\/\/t.co\/Q49MzJQ5Br, up to the fairly recent past, ran on a single VPS at Rackspace. You say \"Crazy!\", I say \"Crazily aweso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/Q49MzJQ5Br",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "510006975120564224",
    "text" : "http:\/\/t.co\/Q49MzJQ5Br, up to the fairly recent past, ran on a single VPS at Rackspace. You say \"Crazy!\", I say \"Crazily awesome!\"",
    "id" : 510006975120564224,
    "created_at" : "2014-09-11 10:08:33 +0000",
    "user" : {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "protected" : false,
      "id_str" : "20844341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476049306072276993\/s9QMnPC5_normal.jpeg",
      "id" : 20844341,
      "verified" : false
    }
  },
  "id" : 510025789421539328,
  "created_at" : "2014-09-11 11:23:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509887891497967617",
  "text" : "RT @ggreenwald: Obama is the 4th consecutive US president to announce bombing of Iraq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509882291170967552",
    "text" : "Obama is the 4th consecutive US president to announce bombing of Iraq",
    "id" : 509882291170967552,
    "created_at" : "2014-09-11 01:53:06 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418715960158068736\/Lv1oLH3A_normal.jpeg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 509887891497967617,
  "created_at" : "2014-09-11 02:15:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509854073856995328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8922684398, -78.8716117759 ]
  },
  "id_str" : "509856204982865920",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella Microsoft?",
  "id" : 509856204982865920,
  "in_reply_to_status_id" : 509854073856995328,
  "created_at" : "2014-09-11 00:09:26 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greensky Bluegrass",
      "screen_name" : "campgreensky",
      "indices" : [ 19, 32 ],
      "id_str" : "30786579",
      "id" : 30786579
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 41, 51 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Town Ballroom",
      "screen_name" : "townballroom",
      "indices" : [ 56, 69 ],
      "id_str" : "23723314",
      "id" : 23723314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/A8n9wh0Jkq",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/5410e807498e7c9d1df7f263?s=jeA-oatyYoNQkZyKiNDbROcPv5o&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8928187765, -78.8715791702 ]
  },
  "id_str" : "509856007200473088",
  "text" : "It's time for some @campgreensky! \u2013 with @aquaranto (at @TownBallroom for Greensky Bluegrass in Buffalo, NY) https:\/\/t.co\/A8n9wh0Jkq",
  "id" : 509856007200473088,
  "created_at" : "2014-09-11 00:08:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "indices" : [ 3, 14 ],
      "id_str" : "16008234",
      "id" : 16008234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509812707998961665",
  "text" : "RT @stephperry: Buffalo is a city for sale to those who can buy it. Its franchises, future and public offices are for the taking to those w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509811982606684160",
    "text" : "Buffalo is a city for sale to those who can buy it. Its franchises, future and public offices are for the taking to those who already have.",
    "id" : 509811982606684160,
    "created_at" : "2014-09-10 21:13:43 +0000",
    "user" : {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "protected" : false,
      "id_str" : "16008234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572217545717866496\/Ssw9W0fi_normal.jpeg",
      "id" : 16008234,
      "verified" : false
    }
  },
  "id" : 509812707998961665,
  "created_at" : "2014-09-10 21:16:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509809656735088640",
  "text" : "Getting new glasses is like someone hit the Degauss button on your brain. POOOOOOOOEEEEINNNNGGGGGGGGGGZZZZZZZ",
  "id" : 509809656735088640,
  "created_at" : "2014-09-10 21:04:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Sallings",
      "screen_name" : "dlsspy",
      "indices" : [ 3, 10 ],
      "id_str" : "14117412",
      "id" : 14117412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/jUcij5pbz2",
      "expanded_url" : "https:\/\/developer.apple.com\/library\/prerelease\/ios\/documentation\/HealthKit\/Reference\/HealthKit_Constants\/index.html#\/\/apple_ref\/c\/econst\/HKBodyTemperatureSensorLocationRectum",
      "display_url" : "developer.apple.com\/library\/prerel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509808263399886848",
  "text" : "RT @dlsspy: HKBodyTemperatureSensorLocationRectum\nThe temperature was taken in the rectum.\n\nAvailable in iOS 8.0 and later.\n\nhttps:\/\/t.co\/j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/jUcij5pbz2",
        "expanded_url" : "https:\/\/developer.apple.com\/library\/prerelease\/ios\/documentation\/HealthKit\/Reference\/HealthKit_Constants\/index.html#\/\/apple_ref\/c\/econst\/HKBodyTemperatureSensorLocationRectum",
        "display_url" : "developer.apple.com\/library\/prerel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509808147498692608",
    "text" : "HKBodyTemperatureSensorLocationRectum\nThe temperature was taken in the rectum.\n\nAvailable in iOS 8.0 and later.\n\nhttps:\/\/t.co\/jUcij5pbz2",
    "id" : 509808147498692608,
    "created_at" : "2014-09-10 20:58:28 +0000",
    "user" : {
      "name" : "Dustin Sallings",
      "screen_name" : "dlsspy",
      "protected" : false,
      "id_str" : "14117412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57455325\/IMG_0596_2_normal.JPG",
      "id" : 14117412,
      "verified" : false
    }
  },
  "id" : 509808263399886848,
  "created_at" : "2014-09-10 20:58:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509760173183750146",
  "text" : "Just realized I have had zero coffee today, so that might be to blame too. This feeble fleshbag carcass. :(",
  "id" : 509760173183750146,
  "created_at" : "2014-09-10 17:47:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pratik",
      "screen_name" : "lifo",
      "indices" : [ 0, 5 ],
      "id_str" : "6106092",
      "id" : 6106092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509758814338289664",
  "geo" : { },
  "id_str" : "509759394305683457",
  "in_reply_to_user_id" : 6106092,
  "text" : "@lifo yeah I'm worried about fucking that up",
  "id" : 509759394305683457,
  "in_reply_to_status_id" : 509758814338289664,
  "created_at" : "2014-09-10 17:44:45 +0000",
  "in_reply_to_screen_name" : "lifo",
  "in_reply_to_user_id_str" : "6106092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509757987859075072",
  "text" : "Massive headache from new glasses. Is this normal? Been way too long since I got a new pair.",
  "id" : 509757987859075072,
  "created_at" : "2014-09-10 17:39:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/iKQP9eU2Tp",
      "expanded_url" : "http:\/\/www.neilcic.com\/mouthsounds\/",
      "display_url" : "neilcic.com\/mouthsounds\/"
    } ]
  },
  "geo" : { },
  "id_str" : "509754607560454144",
  "text" : "Mouth Sounds is like someone put my teenage years of radio into a blender http:\/\/t.co\/iKQP9eU2Tp",
  "id" : 509754607560454144,
  "created_at" : "2014-09-10 17:25:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 3, 14 ],
      "id_str" : "17386551",
      "id" : 17386551
    }, {
      "name" : "Highrise",
      "screen_name" : "highrise",
      "indices" : [ 32, 41 ],
      "id_str" : "2798898314",
      "id" : 2798898314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cnWODTO2CO",
      "expanded_url" : "http:\/\/blog.highrisehq.com\/post\/97143153266\/highrise-announcements-gmail-forwards-sent-emails",
      "display_url" : "blog.highrisehq.com\/post\/971431532\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509741878758367233",
  "text" : "RT @natekontny: We've been busy @Highrise. If you're a user, I think you're going to like the changes: \n\nhttp:\/\/t.co\/cnWODTO2CO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/draftin.com\" rel=\"nofollow\"\u003EWrite Better. Draft.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Highrise",
        "screen_name" : "highrise",
        "indices" : [ 16, 25 ],
        "id_str" : "2798898314",
        "id" : 2798898314
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/cnWODTO2CO",
        "expanded_url" : "http:\/\/blog.highrisehq.com\/post\/97143153266\/highrise-announcements-gmail-forwards-sent-emails",
        "display_url" : "blog.highrisehq.com\/post\/971431532\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509739932865527808",
    "text" : "We've been busy @Highrise. If you're a user, I think you're going to like the changes: \n\nhttp:\/\/t.co\/cnWODTO2CO",
    "id" : 509739932865527808,
    "created_at" : "2014-09-10 16:27:25 +0000",
    "user" : {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "protected" : false,
      "id_str" : "17386551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769389798\/image1327095694_normal.png",
      "id" : 17386551,
      "verified" : false
    }
  },
  "id" : 509741878758367233,
  "created_at" : "2014-09-10 16:35:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Brown",
      "screen_name" : "ryan_sb",
      "indices" : [ 3, 11 ],
      "id_str" : "165290994",
      "id" : 165290994
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 43, 49 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 63, 78 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509733670777671680",
  "text" : "RT @ryan_sb: After reading approx 1million @qrush tweets about @nickelcityruby finally bought a ticket.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 30, 36 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 50, 65 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509733403827400704",
    "text" : "After reading approx 1million @qrush tweets about @nickelcityruby finally bought a ticket.",
    "id" : 509733403827400704,
    "created_at" : "2014-09-10 16:01:28 +0000",
    "user" : {
      "name" : "Ryan Brown",
      "screen_name" : "ryan_sb",
      "protected" : false,
      "id_str" : "165290994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3536132938\/c49cd8aa1da44366435b56fa5c83675c_normal.jpeg",
      "id" : 165290994,
      "verified" : false
    }
  },
  "id" : 509733670777671680,
  "created_at" : "2014-09-10 16:02:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Brown",
      "screen_name" : "ryan_sb",
      "indices" : [ 0, 8 ],
      "id_str" : "165290994",
      "id" : 165290994
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 9, 24 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509733403827400704",
  "geo" : { },
  "id_str" : "509733635235143680",
  "in_reply_to_user_id" : 165290994,
  "text" : "@ryan_sb @nickelcityruby IT WORKED",
  "id" : 509733635235143680,
  "in_reply_to_status_id" : 509733403827400704,
  "created_at" : "2014-09-10 16:02:23 +0000",
  "in_reply_to_screen_name" : "ryan_sb",
  "in_reply_to_user_id_str" : "165290994",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/w73aSG5ww7",
      "expanded_url" : "http:\/\/www.objc.io\/",
      "display_url" : "objc.io"
    } ]
  },
  "geo" : { },
  "id_str" : "509733553018388481",
  "text" : "New objc.io including a contributor from the Fruit Company. Starting to think Apple might be turning a corner - http:\/\/t.co\/w73aSG5ww7",
  "id" : 509733553018388481,
  "created_at" : "2014-09-10 16:02:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jon hendren",
      "screen_name" : "fart",
      "indices" : [ 71, 76 ],
      "id_str" : "14166714",
      "id" : 14166714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/irbXLthlUy",
      "expanded_url" : "https:\/\/www.linkedin.com\/today\/post\/article\/20140910003236-131675724-devops-thought-leaders-are-why-we-can-t-have-nice-things?utm_medium=socialmedia&utm_campaign=kokasexton&utm_source=kokasexton&_mSplash=1",
      "display_url" : "linkedin.com\/today\/post\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509727975101566976",
  "text" : "The era of DevOps being a confusing mess is coming to an end thanks to @fart https:\/\/t.co\/irbXLthlUy",
  "id" : 509727975101566976,
  "created_at" : "2014-09-10 15:39:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 3, 12 ],
      "id_str" : "49102992",
      "id" : 49102992
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 50, 65 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509719371191574529",
  "text" : "RT @poteland: Still haven't bought your ticket to @nickelcityruby? They gave me a discount code for you! Anyone want it? :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 36, 51 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "508984270506180608",
    "text" : "Still haven't bought your ticket to @nickelcityruby? They gave me a discount code for you! Anyone want it? :D",
    "id" : 508984270506180608,
    "created_at" : "2014-09-08 14:24:41 +0000",
    "user" : {
      "name" : "pote",
      "screen_name" : "poteland",
      "protected" : false,
      "id_str" : "49102992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1395984707\/RedMage_normal.png",
      "id" : 49102992,
      "verified" : false
    }
  },
  "id" : 509719371191574529,
  "created_at" : "2014-09-10 15:05:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lena Levine",
      "screen_name" : "lena_levine",
      "indices" : [ 3, 15 ],
      "id_str" : "439572110",
      "id" : 439572110
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/pfE2YJdEsL",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "509719349473452032",
  "text" : "RT @lena_levine: Are you planning to attend @nickelcityruby this year? If not, you're missing out on some awesome speakers! http:\/\/t.co\/pfE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 27, 42 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/pfE2YJdEsL",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
        "display_url" : "nickelcityruby.com\/#speakers"
      } ]
    },
    "geo" : { },
    "id_str" : "509407634642829312",
    "text" : "Are you planning to attend @nickelcityruby this year? If not, you're missing out on some awesome speakers! http:\/\/t.co\/pfE2YJdEsL #buffalo",
    "id" : 509407634642829312,
    "created_at" : "2014-09-09 18:26:59 +0000",
    "user" : {
      "name" : "Lena Levine",
      "screen_name" : "lena_levine",
      "protected" : false,
      "id_str" : "439572110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1869909257\/ea228_normal.jpg",
      "id" : 439572110,
      "verified" : false
    }
  },
  "id" : 509719349473452032,
  "created_at" : "2014-09-10 15:05:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 3, 13 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509718567357390850",
  "text" : "RT @zachwaugh: What\u2019s the best way to get the console logs from a device running iOS 8 GM? Trying to debug a share extension",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509718540069654528",
    "text" : "What\u2019s the best way to get the console logs from a device running iOS 8 GM? Trying to debug a share extension",
    "id" : 509718540069654528,
    "created_at" : "2014-09-10 15:02:24 +0000",
    "user" : {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "protected" : false,
      "id_str" : "14620798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549681852332535809\/TzOXTBNx_normal.jpeg",
      "id" : 14620798,
      "verified" : false
    }
  },
  "id" : 509718567357390850,
  "created_at" : "2014-09-10 15:02:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509717156205191168",
  "geo" : { },
  "id_str" : "509717408299225089",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller coffee shops\/distractions at home drove me nuts.",
  "id" : 509717408299225089,
  "in_reply_to_status_id" : 509717156205191168,
  "created_at" : "2014-09-10 14:57:54 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Solomon White",
      "screen_name" : "rubysolo",
      "indices" : [ 0, 9 ],
      "id_str" : "6164712",
      "id" : 6164712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/1B4GG4Bwnu",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/09\/09\/dynos-are-done\/",
      "display_url" : "quaran.to\/blog\/2014\/09\/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "509716110086643713",
  "geo" : { },
  "id_str" : "509716392015179776",
  "in_reply_to_user_id" : 6164712,
  "text" : "@rubysolo moved it late last night http:\/\/t.co\/1B4GG4Bwnu",
  "id" : 509716392015179776,
  "in_reply_to_status_id" : 509716110086643713,
  "created_at" : "2014-09-10 14:53:52 +0000",
  "in_reply_to_screen_name" : "rubysolo",
  "in_reply_to_user_id_str" : "6164712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Problem",
      "screen_name" : "BonzoESC",
      "indices" : [ 0, 9 ],
      "id_str" : "7865582",
      "id" : 7865582
    }, {
      "name" : "Nikita",
      "screen_name" : "Niki7a",
      "indices" : [ 10, 17 ],
      "id_str" : "19465618",
      "id" : 19465618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509709098309648384",
  "geo" : { },
  "id_str" : "509709581811863552",
  "in_reply_to_user_id" : 7865582,
  "text" : "@BonzoESC @Niki7a Yeah looking for someone as an organizer has had to...just some basic questions",
  "id" : 509709581811863552,
  "in_reply_to_status_id" : 509709098309648384,
  "created_at" : "2014-09-10 14:26:48 +0000",
  "in_reply_to_screen_name" : "BonzoESC",
  "in_reply_to_user_id_str" : "7865582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509708860769067008",
  "text" : "Has anyone dealt with having to write an invite letter to a conf for a visa before? Would appreciate asking a few q's if you have time.",
  "id" : 509708860769067008,
  "created_at" : "2014-09-10 14:23:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/509705162978381824\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/gnRVORkkaM",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BxLWJBUCAAMg7xX.png",
      "id_str" : "509705158305906691",
      "id" : 509705158305906691,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BxLWJBUCAAMg7xX.png",
      "sizes" : [ {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/gnRVORkkaM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509705162978381824",
  "text" : "Current new glasses status http:\/\/t.co\/gnRVORkkaM",
  "id" : 509705162978381824,
  "created_at" : "2014-09-10 14:09:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan LeClaire",
      "screen_name" : "upthecyberpunks",
      "indices" : [ 3, 19 ],
      "id_str" : "210193709",
      "id" : 210193709
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 34, 40 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Docker",
      "screen_name" : "docker",
      "indices" : [ 71, 78 ],
      "id_str" : "1138959692",
      "id" : 1138959692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ij8MwQzyo9",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/09\/09\/dynos-are-done\/",
      "display_url" : "quaran.to\/blog\/2014\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509689140560924673",
  "text" : "RT @upthecyberpunks: nice post by @qrush : \"Dynos are Done!\" dokku and @docker are here!  http:\/\/t.co\/ij8MwQzyo9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 13, 19 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Docker",
        "screen_name" : "docker",
        "indices" : [ 50, 57 ],
        "id_str" : "1138959692",
        "id" : 1138959692
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/ij8MwQzyo9",
        "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/09\/09\/dynos-are-done\/",
        "display_url" : "quaran.to\/blog\/2014\/09\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509564939158036480",
    "text" : "nice post by @qrush : \"Dynos are Done!\" dokku and @docker are here!  http:\/\/t.co\/ij8MwQzyo9",
    "id" : 509564939158036480,
    "created_at" : "2014-09-10 04:52:03 +0000",
    "user" : {
      "name" : "Nathan LeClaire",
      "screen_name" : "upthecyberpunks",
      "protected" : false,
      "id_str" : "210193709",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492560037705822208\/78Dt9Apg_normal.jpeg",
      "id" : 210193709,
      "verified" : false
    }
  },
  "id" : 509689140560924673,
  "created_at" : "2014-09-10 13:05:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan LeClaire",
      "screen_name" : "upthecyberpunks",
      "indices" : [ 0, 16 ],
      "id_str" : "210193709",
      "id" : 210193709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509564939158036480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244327359, -78.8789315243 ]
  },
  "id_str" : "509689127042707457",
  "in_reply_to_user_id" : 210193709,
  "text" : "@upthecyberpunks thanks!",
  "id" : 509689127042707457,
  "in_reply_to_status_id" : 509564939158036480,
  "created_at" : "2014-09-10 13:05:32 +0000",
  "in_reply_to_screen_name" : "upthecyberpunks",
  "in_reply_to_user_id_str" : "210193709",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/1B4GG4Bwnu",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/09\/09\/dynos-are-done\/",
      "display_url" : "quaran.to\/blog\/2014\/09\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244327359, -78.8789315243 ]
  },
  "id_str" : "509689033249665024",
  "text" : "Dynos are done: http:\/\/t.co\/1B4GG4Bwnu",
  "id" : 509689033249665024,
  "created_at" : "2014-09-10 13:05:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509561648005136386",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243876832, -78.8790378068 ]
  },
  "id_str" : "509562115393208320",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic cool. I stopped paying attention to anything Pivotal. Not sure why.",
  "id" : 509562115393208320,
  "in_reply_to_status_id" : 509561648005136386,
  "created_at" : "2014-09-10 04:40:50 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509561561485045761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243876832, -78.8790378068 ]
  },
  "id_str" : "509561879497170944",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting l think you need to try that tutorial. You are over estimating it.",
  "id" : 509561879497170944,
  "in_reply_to_status_id" : 509561561485045761,
  "created_at" : "2014-09-10 04:39:53 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509559214692249600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924331273, -78.8790631202 ]
  },
  "id_str" : "509559686970892288",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting for sure. It\u2019s a question of motivation not ability",
  "id" : 509559686970892288,
  "in_reply_to_status_id" : 509559214692249600,
  "created_at" : "2014-09-10 04:31:11 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509558666349928448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243481625, -78.8790645451 ]
  },
  "id_str" : "509558825993502722",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting i suppose so. I wouldn\u2019t hand roll it either way.",
  "id" : 509558825993502722,
  "in_reply_to_status_id" : 509558666349928448,
  "created_at" : "2014-09-10 04:27:45 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509558160294547457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241804613, -78.8788345114 ]
  },
  "id_str" : "509558451547041792",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting the latter is really complicated and difficult in comparison. Check that tutorial out.",
  "id" : 509558451547041792,
  "in_reply_to_status_id" : 509558160294547457,
  "created_at" : "2014-09-10 04:26:16 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/1B4GG4Bwnu",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/09\/09\/dynos-are-done\/",
      "display_url" : "quaran.to\/blog\/2014\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509556191517634561",
  "text" : "Updated that post URL. Sorry, no redirects yet. Dynos are done: http:\/\/t.co\/1B4GG4Bwnu",
  "id" : 509556191517634561,
  "created_at" : "2014-09-10 04:17:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 1, 10 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 37, 45 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Buffalo PHP",
      "screen_name" : "BuffaloPHP",
      "indices" : [ 48, 59 ],
      "id_str" : "1508773998",
      "id" : 1508773998
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 68, 82 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/509486091267629056\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/cNIqe57vmv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxIO5XCCIAATQJo.jpg",
      "id_str" : "509486086444163072",
      "id" : 509486086444163072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxIO5XCCIAATQJo.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cNIqe57vmv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915649721, -78.8724222973 ]
  },
  "id_str" : "509486091267629056",
  "text" : ".@sabiddle breaking down bash at the @wnyruby \/ @BuffaloPHP meeting @coworkbuffalo http:\/\/t.co\/cNIqe57vmv",
  "id" : 509486091267629056,
  "created_at" : "2014-09-09 23:38:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/anildash\/status\/509431345492545536\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/lju32zl76W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxHdHAbIcAIWnGt.jpg",
      "id_str" : "509431345312198658",
      "id" : 509431345312198658,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxHdHAbIcAIWnGt.jpg",
      "sizes" : [ {
        "h" : 573,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1295
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lju32zl76W"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/hiBC5KNvQ5",
      "expanded_url" : "https:\/\/medium.com\/message\/apple-liveblog-september-9-2014-6a04ee8edd2",
      "display_url" : "medium.com\/message\/apple-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509433301896298496",
  "text" : "RT @anildash: Hard to imagine why anyone would be uncomfortable trusting private health data to Apple. https:\/\/t.co\/hiBC5KNvQ5 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/anildash\/status\/509431345492545536\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/lju32zl76W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxHdHAbIcAIWnGt.jpg",
        "id_str" : "509431345312198658",
        "id" : 509431345312198658,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxHdHAbIcAIWnGt.jpg",
        "sizes" : [ {
          "h" : 573,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1295
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lju32zl76W"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/hiBC5KNvQ5",
        "expanded_url" : "https:\/\/medium.com\/message\/apple-liveblog-september-9-2014-6a04ee8edd2",
        "display_url" : "medium.com\/message\/apple-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509431345492545536",
    "text" : "Hard to imagine why anyone would be uncomfortable trusting private health data to Apple. https:\/\/t.co\/hiBC5KNvQ5 http:\/\/t.co\/lju32zl76W",
    "id" : 509431345492545536,
    "created_at" : "2014-09-09 20:01:12 +0000",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529664614863101952\/yBQgCUMW_normal.png",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 509433301896298496,
  "created_at" : "2014-09-09 20:08:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/509424736070537216\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/EYPReNC88u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxHXGNfCIAAxgW6.jpg",
      "id_str" : "509424734568587264",
      "id" : 509424734568587264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxHXGNfCIAAxgW6.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EYPReNC88u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509424736070537216",
  "text" : "Won't be getting an APPLE WATCH until it supports a laser http:\/\/t.co\/EYPReNC88u",
  "id" : 509424736070537216,
  "created_at" : "2014-09-09 19:34:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Heaney",
      "screen_name" : "JimHeaney",
      "indices" : [ 3, 13 ],
      "id_str" : "17769496",
      "id" : 17769496
    }, {
      "name" : "Buffalo Bills",
      "screen_name" : "buffalobills",
      "indices" : [ 111, 124 ],
      "id_str" : "25084916",
      "id" : 25084916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/nmujERe3Fe",
      "expanded_url" : "http:\/\/bit.ly\/1qBCNmn",
      "display_url" : "bit.ly\/1qBCNmn"
    } ]
  },
  "geo" : { },
  "id_str" : "509423470313480192",
  "text" : "RT @JimHeaney: Would it be rude to remind folks how Terry Pegula amassed the money that enabled him to buy the @buffalobills? http:\/\/t.co\/n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo Bills",
        "screen_name" : "buffalobills",
        "indices" : [ 96, 109 ],
        "id_str" : "25084916",
        "id" : 25084916
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/nmujERe3Fe",
        "expanded_url" : "http:\/\/bit.ly\/1qBCNmn",
        "display_url" : "bit.ly\/1qBCNmn"
      } ]
    },
    "geo" : { },
    "id_str" : "509393560802955264",
    "text" : "Would it be rude to remind folks how Terry Pegula amassed the money that enabled him to buy the @buffalobills? http:\/\/t.co\/nmujERe3Fe",
    "id" : 509393560802955264,
    "created_at" : "2014-09-09 17:31:03 +0000",
    "user" : {
      "name" : "Jim Heaney",
      "screen_name" : "JimHeaney",
      "protected" : false,
      "id_str" : "17769496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/116604057\/heaney_normal.jpg",
      "id" : 17769496,
      "verified" : false
    }
  },
  "id" : 509423470313480192,
  "created_at" : "2014-09-09 19:29:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Horwitz",
      "screen_name" : "horwitz",
      "indices" : [ 0, 8 ],
      "id_str" : "1720771",
      "id" : 1720771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509407597443960832",
  "geo" : { },
  "id_str" : "509407694931779584",
  "in_reply_to_user_id" : 1720771,
  "text" : "@horwitz he said it when switching to the demo - requires iPhone",
  "id" : 509407694931779584,
  "in_reply_to_status_id" : 509407597443960832,
  "created_at" : "2014-09-09 18:27:13 +0000",
  "in_reply_to_screen_name" : "horwitz",
  "in_reply_to_user_id_str" : "1720771",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Walsh",
      "screen_name" : "davidwalshblog",
      "indices" : [ 3, 18 ],
      "id_str" : "15759583",
      "id" : 15759583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509407545081860096",
  "text" : "RT @davidwalshblog: Imagine being the first asshole to look at his Apple Watch through his Google Glass.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509407282363236352",
    "text" : "Imagine being the first asshole to look at his Apple Watch through his Google Glass.",
    "id" : 509407282363236352,
    "created_at" : "2014-09-09 18:25:35 +0000",
    "user" : {
      "name" : "David Walsh",
      "screen_name" : "davidwalshblog",
      "protected" : false,
      "id_str" : "15759583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2587630901\/6gk0dqubt5512yk18a6o_normal.png",
      "id" : 15759583,
      "verified" : false
    }
  },
  "id" : 509407545081860096,
  "created_at" : "2014-09-09 18:26:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Thurman",
      "screen_name" : "Sam_Thurman",
      "indices" : [ 3, 15 ],
      "id_str" : "14500941",
      "id" : 14500941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509402616644657152",
  "text" : "RT @Sam_Thurman: I'm glad there's going to be an apple watch. This way I can show peopleI'm better than them without reaching into my pocke\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509402464131362816",
    "text" : "I'm glad there's going to be an apple watch. This way I can show peopleI'm better than them without reaching into my pocket.",
    "id" : 509402464131362816,
    "created_at" : "2014-09-09 18:06:26 +0000",
    "user" : {
      "name" : "Sam Thurman",
      "screen_name" : "Sam_Thurman",
      "protected" : false,
      "id_str" : "14500941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3044362080\/8a974758c2e43bc4e415fee6df6c566a_normal.jpeg",
      "id" : 14500941,
      "verified" : false
    }
  },
  "id" : 509402616644657152,
  "created_at" : "2014-09-09 18:07:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509401223783411712",
  "text" : "Does anyone here under 30 wear a watch?",
  "id" : 509401223783411712,
  "created_at" : "2014-09-09 18:01:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denny's",
      "screen_name" : "DennysDiner",
      "indices" : [ 3, 15 ],
      "id_str" : "23112346",
      "id" : 23112346
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DennysDiner\/status\/509396332843646977\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/QXDmcYk0JG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxG9Q_WIEAAsfLp.jpg",
      "id_str" : "509396332449370112",
      "id" : 509396332449370112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxG9Q_WIEAAsfLp.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 933
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 933
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QXDmcYk0JG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509396887577694208",
  "text" : "RT @DennysDiner: http:\/\/t.co\/QXDmcYk0JG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DennysDiner\/status\/509396332843646977\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/QXDmcYk0JG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxG9Q_WIEAAsfLp.jpg",
        "id_str" : "509396332449370112",
        "id" : 509396332449370112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxG9Q_WIEAAsfLp.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 933
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 933
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QXDmcYk0JG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509396332843646977",
    "text" : "http:\/\/t.co\/QXDmcYk0JG",
    "id" : 509396332843646977,
    "created_at" : "2014-09-09 17:42:04 +0000",
    "user" : {
      "name" : "Denny's",
      "screen_name" : "DennysDiner",
      "protected" : false,
      "id_str" : "23112346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558638271891136513\/D8hJKugG_normal.jpeg",
      "id" : 23112346,
      "verified" : true
    }
  },
  "id" : 509396887577694208,
  "created_at" : "2014-09-09 17:44:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509393601571196930",
  "geo" : { },
  "id_str" : "509393729895927809",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam technically both are against apple's app store review guidelines.",
  "id" : 509393729895927809,
  "in_reply_to_status_id" : 509393601571196930,
  "created_at" : "2014-09-09 17:31:43 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509392661321506816",
  "text" : "iPhone 6\/6+ app idea with Barometer: SLINKY app. Throw your phone down some stairs. High score = most amount of stairs dropped",
  "id" : 509392661321506816,
  "created_at" : "2014-09-09 17:27:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509391695386279936",
  "geo" : { },
  "id_str" : "509392024072495104",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh were you cringing at the purple scarf?",
  "id" : 509392024072495104,
  "in_reply_to_status_id" : 509391695386279936,
  "created_at" : "2014-09-09 17:24:57 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509391376622956544",
  "text" : "\"Vain Glory\" - a great two-word summary of the entire Apple ecosystem",
  "id" : 509391376622956544,
  "created_at" : "2014-09-09 17:22:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509389770779140096",
  "text" : "RT @dhh: Apple's recent cloud record: Leaks all celeb pics from their backups, can't stream video online. PLEASE HOLD MY MEDICAL AND FINANC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509389280754827265",
    "text" : "Apple's recent cloud record: Leaks all celeb pics from their backups, can't stream video online. PLEASE HOLD MY MEDICAL AND FINANCIAL DATA!",
    "id" : 509389280754827265,
    "created_at" : "2014-09-09 17:14:03 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 509389770779140096,
  "created_at" : "2014-09-09 17:16:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/EUklPXxKDV",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=IOnc6x1zFeg",
      "display_url" : "youtube.com\/watch?v=IOnc6x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509387241144070146",
  "text" : "Current Apple everyone status https:\/\/t.co\/EUklPXxKDV",
  "id" : 509387241144070146,
  "created_at" : "2014-09-09 17:05:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. History ",
      "screen_name" : "AhistoricalPics",
      "indices" : [ 3, 19 ],
      "id_str" : "2277140276",
      "id" : 2277140276
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AhistoricalPics\/status\/509383542325800960\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/LNY2KFdKuQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGxodfCcAA9C9q.jpg",
      "id_str" : "509383541537271808",
      "id" : 509383541537271808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGxodfCcAA9C9q.jpg",
      "sizes" : [ {
        "h" : 692,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 944
      } ],
      "display_url" : "pic.twitter.com\/LNY2KFdKuQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509383744105361411",
  "text" : "RT @AhistoricalPics: Apple drops its wildly popular Newton, 1660-something http:\/\/t.co\/LNY2KFdKuQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AhistoricalPics\/status\/509383542325800960\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/LNY2KFdKuQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGxodfCcAA9C9q.jpg",
        "id_str" : "509383541537271808",
        "id" : 509383541537271808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGxodfCcAA9C9q.jpg",
        "sizes" : [ {
          "h" : 692,
          "resize" : "fit",
          "w" : 943
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 944
        } ],
        "display_url" : "pic.twitter.com\/LNY2KFdKuQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509383542325800960",
    "text" : "Apple drops its wildly popular Newton, 1660-something http:\/\/t.co\/LNY2KFdKuQ",
    "id" : 509383542325800960,
    "created_at" : "2014-09-09 16:51:15 +0000",
    "user" : {
      "name" : "A. History ",
      "screen_name" : "AhistoricalPics",
      "protected" : false,
      "id_str" : "2277140276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419701923944480769\/AzrkOS2P_normal.jpeg",
      "id" : 2277140276,
      "verified" : false
    }
  },
  "id" : 509383744105361411,
  "created_at" : "2014-09-09 16:52:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 3, 7 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 9, 15 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509362333487869952",
  "text" : "RT @lrz: @qrush Especially when the system is controlled by software in a device that's practically always connected.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "509361088098357248",
    "geo" : { },
    "id_str" : "509361758268846080",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Especially when the system is controlled by software in a device that's practically always connected.",
    "id" : 509361758268846080,
    "in_reply_to_status_id" : 509361088098357248,
    "created_at" : "2014-09-09 15:24:41 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "protected" : false,
      "id_str" : "10452222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459499652228714497\/EiSPykkq_normal.png",
      "id" : 10452222,
      "verified" : false
    }
  },
  "id" : 509362333487869952,
  "created_at" : "2014-09-09 15:26:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509360907194228736",
  "geo" : { },
  "id_str" : "509361088098357248",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz this right here - claiming the system is completely secure\/locked down is bullshit.",
  "id" : 509361088098357248,
  "in_reply_to_status_id" : 509360907194228736,
  "created_at" : "2014-09-09 15:22:01 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J. McIntyre",
      "screen_name" : "_ajm",
      "indices" : [ 0, 5 ],
      "id_str" : "74257747",
      "id" : 74257747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/xJQEffphKM",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/509348319588397057",
      "display_url" : "twitter.com\/qrush\/status\/5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "509360895865389056",
  "geo" : { },
  "id_str" : "509360978991910912",
  "in_reply_to_user_id" : 74257747,
  "text" : "@_ajm Same! Related - https:\/\/t.co\/xJQEffphKM",
  "id" : 509360978991910912,
  "in_reply_to_status_id" : 509360895865389056,
  "created_at" : "2014-09-09 15:21:35 +0000",
  "in_reply_to_screen_name" : "_ajm",
  "in_reply_to_user_id_str" : "74257747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/q1pZ6aVGIq",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Dissent",
      "display_url" : "en.wikipedia.org\/wiki\/Dissent"
    } ]
  },
  "geo" : { },
  "id_str" : "509360103481290752",
  "text" : "Today's letter of the day is D. Today's word of the day is Dissent: http:\/\/t.co\/q1pZ6aVGIq",
  "id" : 509360103481290752,
  "created_at" : "2014-09-09 15:18:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509359761989447680",
  "text" : "Does it really bother no one else that one private company has access to the world's largest biometric network?",
  "id" : 509359761989447680,
  "created_at" : "2014-09-09 15:16:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509359420997107713",
  "geo" : { },
  "id_str" : "509359549501812736",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow I just don't want it on the device at all.",
  "id" : 509359549501812736,
  "in_reply_to_status_id" : 509359420997107713,
  "created_at" : "2014-09-09 15:15:54 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509359240503656448",
  "geo" : { },
  "id_str" : "509359324632580096",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow I don't believe that for a fucking second.",
  "id" : 509359324632580096,
  "in_reply_to_status_id" : 509359240503656448,
  "created_at" : "2014-09-09 15:15:01 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509358876810960896",
  "text" : "3 questions why: Do you really trust Apple with your *actual* fingerprint?",
  "id" : 509358876810960896,
  "created_at" : "2014-09-09 15:13:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509358572258729987",
  "geo" : { },
  "id_str" : "509358791758848001",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j I just do not trust Apple with using biometric data on a normal basis. This position of mine has strengthened with security issues",
  "id" : 509358791758848001,
  "in_reply_to_status_id" : 509358572258729987,
  "created_at" : "2014-09-09 15:12:54 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509358515752677376",
  "text" : "My only real hope for today: Apple releases a new iPhone without TouchID.",
  "id" : 509358515752677376,
  "created_at" : "2014-09-09 15:11:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509356121459789824",
  "geo" : { },
  "id_str" : "509356643717365760",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt we should make a millennials-to-butt extension",
  "id" : 509356643717365760,
  "in_reply_to_status_id" : 509356121459789824,
  "created_at" : "2014-09-09 15:04:21 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509351836046737408",
  "text" : "9\/9\/2014: A momentous day. The day you register for @nickelcityruby while watching an Apple keynote. It will never be forgotten.",
  "id" : 509351836046737408,
  "created_at" : "2014-09-09 14:45:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509348319588397057",
  "text" : "Your semi-annual reminder that any dissent from the (Apple, Bills, etc) firehose seems wrong\/cynical\/whats wrong with you",
  "id" : 509348319588397057,
  "created_at" : "2014-09-09 14:31:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9187725865, -78.8857237404 ]
  },
  "id_str" : "509342851948617728",
  "text" : "Here\u2019s the problem with voting: there\u2019s no Facebook share button on the ballot",
  "id" : 509342851948617728,
  "created_at" : "2014-09-09 14:09:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/509337971850375168\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/RZw6itpKbJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGIL3PCEAAuKTL.png",
      "id_str" : "509337970256515072",
      "id" : 509337970256515072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGIL3PCEAAuKTL.png",
      "sizes" : [ {
        "h" : 438,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/RZw6itpKbJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509337971850375168",
  "text" : "Something is very, very wrong here http:\/\/t.co\/RZw6itpKbJ",
  "id" : 509337971850375168,
  "created_at" : "2014-09-09 13:50:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/6V7DTeOjAI",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/09\/08\/too-many-streams\/",
      "display_url" : "quaran.to\/blog\/2014\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509337288774406144",
  "text" : "Trying to get back into writing daily. Too many streams: http:\/\/t.co\/6V7DTeOjAI",
  "id" : 509337288774406144,
  "created_at" : "2014-09-09 13:47:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509335292822958080",
  "geo" : { },
  "id_str" : "509335916641411072",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw Just finished A Dark Room. Will check out the other.",
  "id" : 509335916641411072,
  "in_reply_to_status_id" : 509335292822958080,
  "created_at" : "2014-09-09 13:42:00 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nesbitt",
      "screen_name" : "joshnesbitt",
      "indices" : [ 0, 12 ],
      "id_str" : "15652424",
      "id" : 15652424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509324890953228288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240819446, -78.879406408 ]
  },
  "id_str" : "509325931740024833",
  "in_reply_to_user_id" : 15652424,
  "text" : "@joshnesbitt yikes. Yeah redirected it long ago",
  "id" : 509325931740024833,
  "in_reply_to_status_id" : 509324890953228288,
  "created_at" : "2014-09-09 13:02:19 +0000",
  "in_reply_to_screen_name" : "joshnesbitt",
  "in_reply_to_user_id_str" : "15652424",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509194282298015745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244273109, -78.8795451461 ]
  },
  "id_str" : "509194918544150529",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby no one does",
  "id" : 509194918544150529,
  "in_reply_to_status_id" : 509194282298015745,
  "created_at" : "2014-09-09 04:21:43 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/XLMEWmSBH2",
      "expanded_url" : "http:\/\/buffalo.craigslist.org\/for\/4631284064.html",
      "display_url" : "buffalo.craigslist.org\/for\/4631284064\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242197418, -78.8800332903 ]
  },
  "id_str" : "509191941548830720",
  "text" : "Semi regular reminder to search for \u201Csign\u201D on your local CL to find creepy\/obviously stolen things http:\/\/t.co\/XLMEWmSBH2",
  "id" : 509191941548830720,
  "created_at" : "2014-09-09 04:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/509175017402138624\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/F7UHFRJJLj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxDz-sXCEAA7ddn.png",
      "id_str" : "509175016278069248",
      "id" : 509175016278069248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxDz-sXCEAA7ddn.png",
      "sizes" : [ {
        "h" : 932,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1320,
        "resize" : "fit",
        "w" : 1450
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/F7UHFRJJLj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509175017402138624",
  "text" : "Ok @nytimes, that's clever. http:\/\/t.co\/F7UHFRJJLj",
  "id" : 509175017402138624,
  "created_at" : "2014-09-09 03:02:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    }, {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 13, 25 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/GdQxeI7Kby",
      "expanded_url" : "http:\/\/somebodyapp.com\/",
      "display_url" : "somebodyapp.com"
    } ]
  },
  "in_reply_to_status_id_str" : "509173940561149952",
  "geo" : { },
  "id_str" : "509174235516784640",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones @antiheroine watch the video - http:\/\/t.co\/GdQxeI7Kby",
  "id" : 509174235516784640,
  "in_reply_to_status_id" : 509173940561149952,
  "created_at" : "2014-09-09 02:59:32 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243555386, -78.8794199378 ]
  },
  "id_str" : "509168166400819200",
  "text" : "Deleted the Firm. Awful game and only relies on memory\/sight. Feeling like iOS games have hit rock bottom.",
  "id" : 509168166400819200,
  "created_at" : "2014-09-09 02:35:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509163105109024768",
  "text" : "RT @coworkbuffalo: Cupcakes, cookies, coffee, and the Big Apple Show on the conference TV at the space tomorrow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509162139278651392",
    "text" : "Cupcakes, cookies, coffee, and the Big Apple Show on the conference TV at the space tomorrow.",
    "id" : 509162139278651392,
    "created_at" : "2014-09-09 02:11:28 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 509163105109024768,
  "created_at" : "2014-09-09 02:15:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 0, 15 ],
      "id_str" : "81525784",
      "id" : 81525784
    }, {
      "name" : "Danimal\/Armcannon",
      "screen_name" : "armcannon",
      "indices" : [ 32, 42 ],
      "id_str" : "86775045",
      "id" : 86775045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/jsYgSbPQzs",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_7k25pwNbj8",
      "display_url" : "youtube.com\/watch?v=_7k25p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "509148859575304193",
  "geo" : { },
  "id_str" : "509149087753461761",
  "in_reply_to_user_id" : 81525784,
  "text" : "@franklinwebber you might enjoy @armcannon's talk - https:\/\/t.co\/jsYgSbPQzs",
  "id" : 509149087753461761,
  "in_reply_to_status_id" : 509148859575304193,
  "created_at" : "2014-09-09 01:19:36 +0000",
  "in_reply_to_screen_name" : "franklinwebber",
  "in_reply_to_user_id_str" : "81525784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/509148843842486272\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/9lCd0aDSaN",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BxDcLG0CMAAmvsr.png",
      "id_str" : "509148841258397696",
      "id" : 509148841258397696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BxDcLG0CMAAmvsr.png",
      "sizes" : [ {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/9lCd0aDSaN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509148843842486272",
  "text" : "I've obtained exclusive early footage of Apple's press event http:\/\/t.co\/9lCd0aDSaN",
  "id" : 509148843842486272,
  "created_at" : "2014-09-09 01:18:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gordon",
      "screen_name" : "mike_gordon",
      "indices" : [ 0, 12 ],
      "id_str" : "15641394",
      "id" : 15641394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509147670997250048",
  "in_reply_to_user_id" : 15641394,
  "text" : "@mike_gordon what do you use to talk\/communicate amongst members of the band? email? sms? something else?",
  "id" : 509147670997250048,
  "created_at" : "2014-09-09 01:13:58 +0000",
  "in_reply_to_screen_name" : "mike_gordon",
  "in_reply_to_user_id_str" : "15641394",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pamela marie",
      "screen_name" : "pwnela",
      "indices" : [ 0, 7 ],
      "id_str" : "40960018",
      "id" : 40960018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/lk5bFo3sbB",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3550",
      "display_url" : "signalvnoise.com\/posts\/3550"
    } ]
  },
  "in_reply_to_status_id_str" : "509086180088901632",
  "geo" : { },
  "id_str" : "509136888842563585",
  "in_reply_to_user_id" : 40960018,
  "text" : "@pwnela thanks :) it's been a preoccupation since day one of starting to organize - https:\/\/t.co\/lk5bFo3sbB",
  "id" : 509136888842563585,
  "in_reply_to_status_id" : 509086180088901632,
  "created_at" : "2014-09-09 00:31:08 +0000",
  "in_reply_to_screen_name" : "pwnela",
  "in_reply_to_user_id_str" : "40960018",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "indices" : [ 3, 12 ],
      "id_str" : "55525953",
      "id" : 55525953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509132034879393793",
  "text" : "RT @Pinboard: \u201COh and one more thing\u2026 the iWatch we just introduced? You\u2019re already wearing it.\u201D Audience looks, screams, but there\u2019s no cl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509118765838381056",
    "text" : "\u201COh and one more thing\u2026 the iWatch we just introduced? You\u2019re already wearing it.\u201D Audience looks, screams, but there\u2019s no clasp or release",
    "id" : 509118765838381056,
    "created_at" : "2014-09-08 23:19:07 +0000",
    "user" : {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "protected" : false,
      "id_str" : "55525953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494414965\/logo_normal.png",
      "id" : 55525953,
      "verified" : false
    }
  },
  "id" : 509132034879393793,
  "created_at" : "2014-09-09 00:11:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 0, 10 ],
      "id_str" : "25103",
      "id" : 25103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509121249403240449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924425779, -78.8794466761 ]
  },
  "id_str" : "509132000960057345",
  "in_reply_to_user_id" : 25103,
  "text" : "@jessitron constantly. This is software engineering.",
  "id" : 509132000960057345,
  "in_reply_to_status_id" : 509121249403240449,
  "created_at" : "2014-09-09 00:11:42 +0000",
  "in_reply_to_screen_name" : "jessitron",
  "in_reply_to_user_id_str" : "25103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "indices" : [ 0, 13 ],
      "id_str" : "3479601",
      "id" : 3479601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509126878670880771",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924425779, -78.8794466761 ]
  },
  "id_str" : "509131339585421312",
  "in_reply_to_user_id" : 3479601,
  "text" : "@justingoboom welcome back!",
  "id" : 509131339585421312,
  "in_reply_to_status_id" : 509126878670880771,
  "created_at" : "2014-09-09 00:09:05 +0000",
  "in_reply_to_screen_name" : "justingoboom",
  "in_reply_to_user_id_str" : "3479601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 3, 18 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheBuffaloNews\/status\/509129596973744128\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/LT7Yq7lkpg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxCKIOKIgAA_V8L.png",
      "id_str" : "509058631737049088",
      "id" : 509058631737049088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxCKIOKIgAA_V8L.png",
      "sizes" : [ {
        "h" : 416,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/LT7Yq7lkpg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/SfZh1f4w36",
      "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/university-at-buffalo\/on-ub-campus-stories-from-old-almshouse-are-pieced-together-from-the-bones-left-behind-20140907",
      "display_url" : "buffalonews.com\/city-region\/un\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509131000220106752",
  "text" : "RT @TheBuffaloNews: Researchers estimate that remains about about 3,000 people are buried beneath UB South Campus\nhttp:\/\/t.co\/SfZh1f4w36 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheBuffaloNews\/status\/509129596973744128\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/LT7Yq7lkpg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxCKIOKIgAA_V8L.png",
        "id_str" : "509058631737049088",
        "id" : 509058631737049088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxCKIOKIgAA_V8L.png",
        "sizes" : [ {
          "h" : 416,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/LT7Yq7lkpg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/SfZh1f4w36",
        "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/university-at-buffalo\/on-ub-campus-stories-from-old-almshouse-are-pieced-together-from-the-bones-left-behind-20140907",
        "display_url" : "buffalonews.com\/city-region\/un\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509129596973744128",
    "text" : "Researchers estimate that remains about about 3,000 people are buried beneath UB South Campus\nhttp:\/\/t.co\/SfZh1f4w36 http:\/\/t.co\/LT7Yq7lkpg",
    "id" : 509129596973744128,
    "created_at" : "2014-09-09 00:02:09 +0000",
    "user" : {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "protected" : false,
      "id_str" : "43805270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2553395093\/xvx84nnqjk9bokm82d8p_normal.png",
      "id" : 43805270,
      "verified" : true
    }
  },
  "id" : 509131000220106752,
  "created_at" : "2014-09-09 00:07:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/hdyJjsAW1U",
      "expanded_url" : "https:\/\/flic.kr\/p\/oRdUN1",
      "display_url" : "flic.kr\/p\/oRdUN1"
    } ]
  },
  "geo" : { },
  "id_str" : "509114444085862401",
  "text" : "Monolith https:\/\/t.co\/hdyJjsAW1U",
  "id" : 509114444085862401,
  "created_at" : "2014-09-08 23:01:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 5, 17 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243605978, -78.8792629975 ]
  },
  "id_str" : "509104615116140544",
  "text" : "This @whereslloyd crispy fish burrito is literally bigger than my baby.",
  "id" : 509104615116140544,
  "created_at" : "2014-09-08 22:22:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 34, 46 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/NB47o8deLL",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/540e24f211d228d58201e76e?s=S0s1vVyvArjyygeL4TmV6aHfaz4&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9189462994, -78.8792461316 ]
  },
  "id_str" : "509096784967528448",
  "text" : "I'm at Lloyd the III Taco Truck - @whereslloyd in Buffalo, NY https:\/\/t.co\/NB47o8deLL",
  "id" : 509096784967528448,
  "created_at" : "2014-09-08 21:51:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/yQozL1QXC3",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
      "display_url" : "nickelcityruby.com\/#register"
    } ]
  },
  "geo" : { },
  "id_str" : "509089635662716928",
  "text" : "RT @wnyruby: If you haven't grabbed your tickets to @nickelcityruby you should pop over now before the tickets dry up - http:\/\/t.co\/yQozL1Q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 39, 54 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/yQozL1QXC3",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
        "display_url" : "nickelcityruby.com\/#register"
      } ]
    },
    "geo" : { },
    "id_str" : "509052640341544960",
    "text" : "If you haven't grabbed your tickets to @nickelcityruby you should pop over now before the tickets dry up - http:\/\/t.co\/yQozL1QXC3",
    "id" : 509052640341544960,
    "created_at" : "2014-09-08 18:56:21 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 509089635662716928,
  "created_at" : "2014-09-08 21:23:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pamela marie",
      "screen_name" : "pwnela",
      "indices" : [ 0, 7 ],
      "id_str" : "40960018",
      "id" : 40960018
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 8, 21 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 22, 36 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509080073388171265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243647587, -78.8792383858 ]
  },
  "id_str" : "509085905563291648",
  "in_reply_to_user_id" : 40960018,
  "text" : "@pwnela @steveklabnik @garybernhardt definitely. Have made it a huge priority now for 2 years running :)",
  "id" : 509085905563291648,
  "in_reply_to_status_id" : 509080073388171265,
  "created_at" : "2014-09-08 21:08:32 +0000",
  "in_reply_to_screen_name" : "pwnela",
  "in_reply_to_user_id_str" : "40960018",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 10, 21 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newjob",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509063263296843776",
  "text" : "Imagining @tenderlove just pretending he has a #newjob in a coffee shop or Panera's and awkwardly handing everyone cat stickers",
  "id" : 509063263296843776,
  "created_at" : "2014-09-08 19:38:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    }, {
      "name" : "Lexington Co-op",
      "screen_name" : "lexingtoncoop",
      "indices" : [ 40, 54 ],
      "id_str" : "39835516",
      "id" : 39835516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509061146759143424",
  "geo" : { },
  "id_str" : "509061309011202049",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora around 1 large container of @lexingtoncoop's",
  "id" : 509061309011202049,
  "in_reply_to_status_id" : 509061146759143424,
  "created_at" : "2014-09-08 19:30:48 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 14, 28 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509054895518154754",
  "geo" : { },
  "id_str" : "509056773148270592",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @garybernhardt also one of my top fears as an organizer",
  "id" : 509056773148270592,
  "in_reply_to_status_id" : 509054895518154754,
  "created_at" : "2014-09-08 19:12:47 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo PHP",
      "screen_name" : "BuffaloPHP",
      "indices" : [ 33, 44 ],
      "id_str" : "1508773998",
      "id" : 1508773998
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 58, 66 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/t1h50cL127",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509053632562470912",
  "text" : "We're doing lightning talks with @BuffaloPHP tomorrow for @WNYRuby! Come sign up! http:\/\/t.co\/t1h50cL127",
  "id" : 509053632562470912,
  "created_at" : "2014-09-08 19:00:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hector Bustillos",
      "screen_name" : "hecbuma",
      "indices" : [ 3, 11 ],
      "id_str" : "41419791",
      "id" : 41419791
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hecbuma\/status\/509008263598571521\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/0hhNB5VvV3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxBcUZdIUAAoZpI.jpg",
      "id_str" : "509008263393071104",
      "id" : 509008263393071104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxBcUZdIUAAoZpI.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0hhNB5VvV3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509014385897906176",
  "text" : "RT @hecbuma: It's pretty nice that @nickelcityruby is using passbook. See you there http:\/\/t.co\/0hhNB5VvV3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 22, 37 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hecbuma\/status\/509008263598571521\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/0hhNB5VvV3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxBcUZdIUAAoZpI.jpg",
        "id_str" : "509008263393071104",
        "id" : 509008263393071104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxBcUZdIUAAoZpI.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0hhNB5VvV3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509008263598571521",
    "text" : "It's pretty nice that @nickelcityruby is using passbook. See you there http:\/\/t.co\/0hhNB5VvV3",
    "id" : 509008263598571521,
    "created_at" : "2014-09-08 16:00:01 +0000",
    "user" : {
      "name" : "Hector Bustillos",
      "screen_name" : "hecbuma",
      "protected" : false,
      "id_str" : "41419791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528897933190893568\/fYSHAUjX_normal.jpeg",
      "id" : 41419791,
      "verified" : false
    }
  },
  "id" : 509014385897906176,
  "created_at" : "2014-09-08 16:24:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/yhjteaaViy",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "508986421684600832",
  "text" : "Just 25 days to go until @nickelcityruby. Our schedule is up and we have a lot of great speakers &amp; events! http:\/\/t.co\/yhjteaaViy",
  "id" : 508986421684600832,
  "created_at" : "2014-09-08 14:33:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan",
      "screen_name" : "KiefWahoo216",
      "indices" : [ 0, 13 ],
      "id_str" : "364834641",
      "id" : 364834641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508972761575092224",
  "geo" : { },
  "id_str" : "508983684347613185",
  "in_reply_to_user_id" : 364834641,
  "text" : "@KiefWahoo216 This show was fantastic. Entire place was dressed up for the Beatles.",
  "id" : 508983684347613185,
  "in_reply_to_status_id" : 508972761575092224,
  "created_at" : "2014-09-08 14:22:21 +0000",
  "in_reply_to_screen_name" : "KiefWahoo216",
  "in_reply_to_user_id_str" : "364834641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 31, 46 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242731445, -78.8789082226 ]
  },
  "id_str" : "508963598136131585",
  "text" : "Getting uncomfortably close to @nickelcityruby! Yes I will be tweeting about this daily. \uD83D\uDE2C",
  "id" : 508963598136131585,
  "created_at" : "2014-09-08 13:02:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Paula's Donuts",
      "screen_name" : "PaulasDonuts",
      "indices" : [ 78, 91 ],
      "id_str" : "739385342",
      "id" : 739385342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508957015729643520",
  "text" : "RT @nickelcityruby: Were you at Nickel City Ruby last year?  Did you love the @PaulasDonuts on day one?  Guess what - they're making a come\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paula's Donuts",
        "screen_name" : "PaulasDonuts",
        "indices" : [ 58, 71 ],
        "id_str" : "739385342",
        "id" : 739385342
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "508955909444632576",
    "text" : "Were you at Nickel City Ruby last year?  Did you love the @PaulasDonuts on day one?  Guess what - they're making a come back - get a ticket!",
    "id" : 508955909444632576,
    "created_at" : "2014-09-08 12:31:59 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 508957015729643520,
  "created_at" : "2014-09-08 12:36:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/8A2MuuTylR",
      "expanded_url" : "http:\/\/ift.tt\/Wwjcr5",
      "display_url" : "ift.tt\/Wwjcr5"
    } ]
  },
  "geo" : { },
  "id_str" : "508831302595117056",
  "text" : "GIF \u211619: http:\/\/t.co\/8A2MuuTylR",
  "id" : 508831302595117056,
  "created_at" : "2014-09-08 04:16:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "indices" : [ 3, 17 ],
      "id_str" : "543918403",
      "id" : 543918403
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheDefenseman\/status\/503307693738950656\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/8YTCGYqsKt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvwbrgjIEAAzM0T.jpg",
      "id_str" : "503307692644241408",
      "id" : 503307692644241408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvwbrgjIEAAzM0T.jpg",
      "sizes" : [ {
        "h" : 392,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/8YTCGYqsKt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508719659579736064",
  "text" : "RT @TheDefenseman: http:\/\/t.co\/8YTCGYqsKt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheDefenseman\/status\/503307693738950656\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/8YTCGYqsKt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvwbrgjIEAAzM0T.jpg",
        "id_str" : "503307692644241408",
        "id" : 503307692644241408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvwbrgjIEAAzM0T.jpg",
        "sizes" : [ {
          "h" : 392,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/8YTCGYqsKt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "503307693738950656",
    "text" : "http:\/\/t.co\/8YTCGYqsKt",
    "id" : 503307693738950656,
    "created_at" : "2014-08-23 22:27:59 +0000",
    "user" : {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "protected" : false,
      "id_str" : "543918403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552977726597246976\/2U6c-X0z_normal.jpeg",
      "id" : 543918403,
      "verified" : false
    }
  },
  "id" : 508719659579736064,
  "created_at" : "2014-09-07 20:53:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest W. Durbin III",
      "screen_name" : "EWDurbin",
      "indices" : [ 3, 12 ],
      "id_str" : "14590010",
      "id" : 14590010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/X3KjsWieHE",
      "expanded_url" : "https:\/\/upload.wikimedia.org\/wikipedia\/commons\/a\/a0\/US_Mean_Center_of_Population_1790-2010.PNG",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508701135750713344",
  "text" : "RT @EWDurbin: This is crazy. https:\/\/t.co\/X3KjsWieHE I thought manifest destiny was dead.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/X3KjsWieHE",
        "expanded_url" : "https:\/\/upload.wikimedia.org\/wikipedia\/commons\/a\/a0\/US_Mean_Center_of_Population_1790-2010.PNG",
        "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "508700927055114240",
    "text" : "This is crazy. https:\/\/t.co\/X3KjsWieHE I thought manifest destiny was dead.",
    "id" : 508700927055114240,
    "created_at" : "2014-09-07 19:38:46 +0000",
    "user" : {
      "name" : "Ernest W. Durbin III",
      "screen_name" : "EWDurbin",
      "protected" : false,
      "id_str" : "14590010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572903830775472128\/a_6Z37mZ_normal.jpeg",
      "id" : 14590010,
      "verified" : false
    }
  },
  "id" : 508701135750713344,
  "created_at" : "2014-09-07 19:39:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508699333676793856",
  "geo" : { },
  "id_str" : "508699630742159360",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan \"You will get your money when your balance hits the threshold of 0.00100000 \u0243\"",
  "id" : 508699630742159360,
  "in_reply_to_status_id" : 508699333676793856,
  "created_at" : "2014-09-07 19:33:37 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508674386665414656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242932411, -78.879471722 ]
  },
  "id_str" : "508697715006394368",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan I think it\u2019s only if you commit a lot",
  "id" : 508697715006394368,
  "in_reply_to_status_id" : 508674386665414656,
  "created_at" : "2014-09-07 19:26:01 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/EoxGMWjAnK",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/sf\/investigative\/2014\/09\/06\/stop-and-seize\/?hpid=z2",
      "display_url" : "washingtonpost.com\/sf\/investigati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508618541046571008",
  "text" : "So apparently cops can just stop and take any (large) amounts of cash from you without reason or warrant http:\/\/t.co\/EoxGMWjAnK",
  "id" : 508618541046571008,
  "created_at" : "2014-09-07 14:11:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Walnes",
      "screen_name" : "joewalnes",
      "indices" : [ 3, 13 ],
      "id_str" : "14770578",
      "id" : 14770578
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/joewalnes\/status\/505365660126310400\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wzBi12KyK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwNrY-ACUAApcN2.jpg",
      "id_str" : "505365659899809792",
      "id" : 505365659899809792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwNrY-ACUAApcN2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 3072
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 109,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wzBi12KyK1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508328017261629440",
  "text" : "RT @joewalnes: console.table().\n\nOne of those handy little things you can use in the browser developer tools console. http:\/\/t.co\/wzBi12KyK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/joewalnes\/status\/505365660126310400\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/wzBi12KyK1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwNrY-ACUAApcN2.jpg",
        "id_str" : "505365659899809792",
        "id" : 505365659899809792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwNrY-ACUAApcN2.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 992,
          "resize" : "fit",
          "w" : 3072
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 109,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wzBi12KyK1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505365660126310400",
    "text" : "console.table().\n\nOne of those handy little things you can use in the browser developer tools console. http:\/\/t.co\/wzBi12KyK1",
    "id" : 505365660126310400,
    "created_at" : "2014-08-29 14:45:37 +0000",
    "user" : {
      "name" : "Joe Walnes",
      "screen_name" : "joewalnes",
      "protected" : false,
      "id_str" : "14770578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1947402120\/joewalnes-photo_normal.jpg",
      "id" : 14770578,
      "verified" : false
    }
  },
  "id" : 508328017261629440,
  "created_at" : "2014-09-06 18:56:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508312512694321152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9235512281, -78.8793574209 ]
  },
  "id_str" : "508312665358204928",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 doubtful. Most are way over 2MB",
  "id" : 508312665358204928,
  "in_reply_to_status_id" : 508312512694321152,
  "created_at" : "2014-09-06 17:55:58 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/FNZvN7Yves",
      "expanded_url" : "http:\/\/ift.tt\/1AjtvvW",
      "display_url" : "ift.tt\/1AjtvvW"
    } ]
  },
  "geo" : { },
  "id_str" : "508304567239737344",
  "text" : "GIF \u211618: http:\/\/t.co\/FNZvN7Yves",
  "id" : 508304567239737344,
  "created_at" : "2014-09-06 17:23:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/QOQoZ8y9W9",
      "expanded_url" : "http:\/\/ift.tt\/YkRoru",
      "display_url" : "ift.tt\/YkRoru"
    } ]
  },
  "geo" : { },
  "id_str" : "508304561342513153",
  "text" : "GIF \u211617: http:\/\/t.co\/QOQoZ8y9W9",
  "id" : 508304561342513153,
  "created_at" : "2014-09-06 17:23:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508300275933659137",
  "text" : "Finding a ton of amazing GIF authors by sourcing all of these images. Expect more.",
  "id" : 508300275933659137,
  "created_at" : "2014-09-06 17:06:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/EtIogw6Tl8",
      "expanded_url" : "http:\/\/ift.tt\/1CCnY7P",
      "display_url" : "ift.tt\/1CCnY7P"
    } ]
  },
  "geo" : { },
  "id_str" : "508297119799984128",
  "text" : "GIF \u211616: http:\/\/t.co\/EtIogw6Tl8",
  "id" : 508297119799984128,
  "created_at" : "2014-09-06 16:54:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/3H1VXwF9Ff",
      "expanded_url" : "http:\/\/ift.tt\/1CCnVZD",
      "display_url" : "ift.tt\/1CCnVZD"
    } ]
  },
  "geo" : { },
  "id_str" : "508297114460639232",
  "text" : "GIF \u211614: http:\/\/t.co\/3H1VXwF9Ff",
  "id" : 508297114460639232,
  "created_at" : "2014-09-06 16:54:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/QXhiXs3gZY",
      "expanded_url" : "http:\/\/ift.tt\/1rkuS8Y",
      "display_url" : "ift.tt\/1rkuS8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "508297116469719041",
  "text" : "GIF \u211615: http:\/\/t.co\/QXhiXs3gZY",
  "id" : 508297116469719041,
  "created_at" : "2014-09-06 16:54:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/JBQrZVGmVx",
      "expanded_url" : "http:\/\/ift.tt\/1rkuV4J",
      "display_url" : "ift.tt\/1rkuV4J"
    } ]
  },
  "geo" : { },
  "id_str" : "508297110807412736",
  "text" : "GIF \u211613: http:\/\/t.co\/JBQrZVGmVx",
  "id" : 508297110807412736,
  "created_at" : "2014-09-06 16:54:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/m1tMN3kz2L",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Burning_Ship_fractal",
      "display_url" : "en.wikipedia.org\/wiki\/Burning_S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508295911357681664",
  "text" : "TIL: http:\/\/t.co\/m1tMN3kz2L",
  "id" : 508295911357681664,
  "created_at" : "2014-09-06 16:49:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/bux6sxSnJm",
      "expanded_url" : "http:\/\/ift.tt\/1xpDjsf",
      "display_url" : "ift.tt\/1xpDjsf"
    } ]
  },
  "geo" : { },
  "id_str" : "508278163911507968",
  "text" : "GIF \u211612: http:\/\/t.co\/bux6sxSnJm",
  "id" : 508278163911507968,
  "created_at" : "2014-09-06 15:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/mNKSO13pr7",
      "expanded_url" : "http:\/\/ift.tt\/1xpDgMU",
      "display_url" : "ift.tt\/1xpDgMU"
    } ]
  },
  "geo" : { },
  "id_str" : "508278161327800320",
  "text" : "GIF \u211611: http:\/\/t.co\/mNKSO13pr7",
  "id" : 508278161327800320,
  "created_at" : "2014-09-06 15:38:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 0, 14 ],
      "id_str" : "184501661",
      "id" : 184501661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508272333883461632",
  "geo" : { },
  "id_str" : "508275530685087744",
  "in_reply_to_user_id" : 184501661,
  "text" : "@MileHighMusik nooo way.",
  "id" : 508275530685087744,
  "in_reply_to_status_id" : 508272333883461632,
  "created_at" : "2014-09-06 15:28:24 +0000",
  "in_reply_to_screen_name" : "MileHighMusik",
  "in_reply_to_user_id_str" : "184501661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abdelkader Boudih",
      "screen_name" : "IchThain",
      "indices" : [ 0, 9 ],
      "id_str" : "1244397780",
      "id" : 1244397780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508270847774056448",
  "geo" : { },
  "id_str" : "508275510615343105",
  "in_reply_to_user_id" : 1244397780,
  "text" : "@IchThain you could just parse `gem list -r`",
  "id" : 508275510615343105,
  "in_reply_to_status_id" : 508270847774056448,
  "created_at" : "2014-09-06 15:28:19 +0000",
  "in_reply_to_screen_name" : "IchThain",
  "in_reply_to_user_id_str" : "1244397780",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/iUIocTkRyK",
      "expanded_url" : "http:\/\/ift.tt\/1pXKROX",
      "display_url" : "ift.tt\/1pXKROX"
    } ]
  },
  "geo" : { },
  "id_str" : "508270246286069760",
  "text" : "GIF \u211610: http:\/\/t.co\/iUIocTkRyK",
  "id" : 508270246286069760,
  "created_at" : "2014-09-06 15:07:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/CSdNUYnRw9",
      "expanded_url" : "http:\/\/ift.tt\/1pXKRym",
      "display_url" : "ift.tt\/1pXKRym"
    } ]
  },
  "geo" : { },
  "id_str" : "508270240804143104",
  "text" : "GIF \u21168: http:\/\/t.co\/CSdNUYnRw9",
  "id" : 508270240804143104,
  "created_at" : "2014-09-06 15:07:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/hAYgw5F7oL",
      "expanded_url" : "http:\/\/ift.tt\/1pXKRyt",
      "display_url" : "ift.tt\/1pXKRyt"
    } ]
  },
  "geo" : { },
  "id_str" : "508270243614310400",
  "text" : "GIF \u21169: http:\/\/t.co\/hAYgw5F7oL",
  "id" : 508270243614310400,
  "created_at" : "2014-09-06 15:07:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/qukPWJtvkc",
      "expanded_url" : "http:\/\/ift.tt\/1pXKOCF",
      "display_url" : "ift.tt\/1pXKOCF"
    } ]
  },
  "geo" : { },
  "id_str" : "508270235594797056",
  "text" : "GIF \u21167: http:\/\/t.co\/qukPWJtvkc",
  "id" : 508270235594797056,
  "created_at" : "2014-09-06 15:07:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Pittsburgh Ruby",
      "screen_name" : "pghrb",
      "indices" : [ 15, 21 ],
      "id_str" : "81523571",
      "id" : 81523571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508260753993113600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240551511, -78.8791753379 ]
  },
  "id_str" : "508261083656638464",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @pghrb 15 reasons why you should be in Buffalo the next day",
  "id" : 508261083656638464,
  "in_reply_to_status_id" : 508260753993113600,
  "created_at" : "2014-09-06 14:31:00 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508258540046540800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242072226, -78.879100648 ]
  },
  "id_str" : "508258644413005824",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer oh. Nah we don\u2019t have anything",
  "id" : 508258644413005824,
  "in_reply_to_status_id" : 508258540046540800,
  "created_at" : "2014-09-06 14:21:18 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508258215340281856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242072226, -78.879100648 ]
  },
  "id_str" : "508258373700038658",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer Mario Kart is great",
  "id" : 508258373700038658,
  "in_reply_to_status_id" : 508258215340281856,
  "created_at" : "2014-09-06 14:20:13 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508257454820696064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241934172, -78.8792450146 ]
  },
  "id_str" : "508257574504771584",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer one is good!",
  "id" : 508257574504771584,
  "in_reply_to_status_id" : 508257454820696064,
  "created_at" : "2014-09-06 14:17:03 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dane Jasper",
      "screen_name" : "dane",
      "indices" : [ 3, 8 ],
      "id_str" : "7575072",
      "id" : 7575072
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dane\/status\/507753598197854208\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/373iwWuzzU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwvnNQHCcAA4t5G.jpg",
      "id_str" : "507753597858115584",
      "id" : 507753597858115584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwvnNQHCcAA4t5G.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com\/373iwWuzzU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508249853265072129",
  "text" : "RT @dane: Poster seen in a school, but good advice in general. http:\/\/t.co\/373iwWuzzU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dane\/status\/507753598197854208\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/373iwWuzzU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwvnNQHCcAA4t5G.jpg",
        "id_str" : "507753597858115584",
        "id" : 507753597858115584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwvnNQHCcAA4t5G.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        } ],
        "display_url" : "pic.twitter.com\/373iwWuzzU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507753598197854208",
    "text" : "Poster seen in a school, but good advice in general. http:\/\/t.co\/373iwWuzzU",
    "id" : 507753598197854208,
    "created_at" : "2014-09-05 04:54:26 +0000",
    "user" : {
      "name" : "Dane Jasper",
      "screen_name" : "dane",
      "protected" : false,
      "id_str" : "7575072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2878368089\/3aa64ef691edfacc6a2d9ce7df4e1201_normal.png",
      "id" : 7575072,
      "verified" : true
    }
  },
  "id" : 508249853265072129,
  "created_at" : "2014-09-06 13:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle",
      "screen_name" : "stockholmux",
      "indices" : [ 0, 12 ],
      "id_str" : "488502368",
      "id" : 488502368
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508244798659366914",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243355043, -78.8791208472 ]
  },
  "id_str" : "508248162692128768",
  "in_reply_to_user_id" : 488502368,
  "text" : "@stockholmux @aquaranto just Magic so far. Not much else.",
  "id" : 508248162692128768,
  "in_reply_to_status_id" : 508244798659366914,
  "created_at" : "2014-09-06 13:39:39 +0000",
  "in_reply_to_screen_name" : "stockholmux",
  "in_reply_to_user_id_str" : "488502368",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Inside",
      "screen_name" : "RubyInside",
      "indices" : [ 3, 14 ],
      "id_str" : "15851832",
      "id" : 15851832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/1d2KmSVAxY",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "508231546944241665",
  "text" : "RT @RubyInside: Nickel City Ruby Conference - October 3-4, 2014 - Buffalo, NY: http:\/\/t.co\/1d2KmSVAxY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/1d2KmSVAxY",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "508229632131596289",
    "text" : "Nickel City Ruby Conference - October 3-4, 2014 - Buffalo, NY: http:\/\/t.co\/1d2KmSVAxY",
    "id" : 508229632131596289,
    "created_at" : "2014-09-06 12:26:01 +0000",
    "user" : {
      "name" : "Ruby Inside",
      "screen_name" : "RubyInside",
      "protected" : false,
      "id_str" : "15851832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/58236097\/large-png-antialiased_normal.png",
      "id" : 15851832,
      "verified" : false
    }
  },
  "id" : 508231546944241665,
  "created_at" : "2014-09-06 12:33:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Bauer",
      "screen_name" : "shane_bauer",
      "indices" : [ 3, 15 ],
      "id_str" : "415985101",
      "id" : 415985101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QRsVkfYLe7",
      "expanded_url" : "http:\/\/mojo.ly\/1u7QhXC",
      "display_url" : "mojo.ly\/1u7QhXC"
    } ]
  },
  "geo" : { },
  "id_str" : "508230606979727360",
  "text" : "RT @shane_bauer: Here are some pictures and tweets from the last 2 days. There will be more coming the next 2 days, and articles soon. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/QRsVkfYLe7",
        "expanded_url" : "http:\/\/mojo.ly\/1u7QhXC",
        "display_url" : "mojo.ly\/1u7QhXC"
      } ]
    },
    "geo" : { },
    "id_str" : "508076956705759235",
    "text" : "Here are some pictures and tweets from the last 2 days. There will be more coming the next 2 days, and articles soon. http:\/\/t.co\/QRsVkfYLe7",
    "id" : 508076956705759235,
    "created_at" : "2014-09-06 02:19:20 +0000",
    "user" : {
      "name" : "Shane Bauer",
      "screen_name" : "shane_bauer",
      "protected" : false,
      "id_str" : "415985101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541819281323741184\/TFd4786v_normal.jpeg",
      "id" : 415985101,
      "verified" : true
    }
  },
  "id" : 508230606979727360,
  "created_at" : "2014-09-06 12:29:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    }, {
      "name" : "Nick Harezga",
      "screen_name" : "nharezga",
      "indices" : [ 7, 16 ],
      "id_str" : "387176232",
      "id" : 387176232
    }, {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 17, 29 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/1TF1fDEiAz",
      "expanded_url" : "http:\/\/butt.holdings",
      "display_url" : "butt.holdings"
    } ]
  },
  "in_reply_to_status_id_str" : "508037382818762752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244321042, -78.8796764014 ]
  },
  "id_str" : "508038065726566400",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d @nharezga @singheyjude http:\/\/t.co\/1TF1fDEiAz",
  "id" : 508038065726566400,
  "in_reply_to_status_id" : 508037382818762752,
  "created_at" : "2014-09-05 23:44:48 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 41, 51 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/Ab2h7k1YyI",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/540a3e7e498ecfa42ed9d6e4?s=fShB154-AaPDdsyaH8vD9arIEa0&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.961502, -78.878471 ]
  },
  "id_str" : "508024702917304320",
  "text" : "Buffalo has a game store finally! \u2013 with @aquaranto (@ Queen City Games in Kenmore, NY) https:\/\/t.co\/Ab2h7k1YyI",
  "id" : 508024702917304320,
  "created_at" : "2014-09-05 22:51:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "twoscooters",
      "indices" : [ 0, 12 ],
      "id_str" : "26902304",
      "id" : 26902304
    }, {
      "name" : "Brett Douville",
      "screen_name" : "brett_douville",
      "indices" : [ 13, 28 ],
      "id_str" : "8266102",
      "id" : 8266102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508010323660394497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243239024, -78.8792034158 ]
  },
  "id_str" : "508012731723571200",
  "in_reply_to_user_id" : 26902304,
  "text" : "@twoscooters @brett_douville you are the most patient person on Earth",
  "id" : 508012731723571200,
  "in_reply_to_status_id" : 508010323660394497,
  "created_at" : "2014-09-05 22:04:08 +0000",
  "in_reply_to_screen_name" : "twoscooters",
  "in_reply_to_user_id_str" : "26902304",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dadops",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508010390232780800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239821858, -78.8791129922 ]
  },
  "id_str" : "508010579018014720",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin not yet! #dadops started again. Will check it out later!",
  "id" : 508010579018014720,
  "in_reply_to_status_id" : 508010390232780800,
  "created_at" : "2014-09-05 21:55:35 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Otto",
      "screen_name" : "mdo",
      "indices" : [ 0, 4 ],
      "id_str" : "8207832",
      "id" : 8207832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507935838328459264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9235435165, -78.879345424 ]
  },
  "id_str" : "508008966895329280",
  "in_reply_to_user_id" : 8207832,
  "text" : "@mdo would expect the same! Also been trying Hyde and it\u2019s great.",
  "id" : 508008966895329280,
  "in_reply_to_status_id" : 507935838328459264,
  "created_at" : "2014-09-05 21:49:10 +0000",
  "in_reply_to_screen_name" : "mdo",
  "in_reply_to_user_id_str" : "8207832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 0, 11 ],
      "id_str" : "28650670",
      "id" : 28650670
    }, {
      "name" : "HI\u039BTVS",
      "screen_name" : "inky",
      "indices" : [ 12, 17 ],
      "id_str" : "13148",
      "id" : 13148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508007427653238785",
  "geo" : { },
  "id_str" : "508007651276365824",
  "in_reply_to_user_id" : 28650670,
  "text" : "@duckinator @inky you actually have to construct a trebuchet to launch the files into a real cloud",
  "id" : 508007651276365824,
  "in_reply_to_status_id" : 508007427653238785,
  "created_at" : "2014-09-05 21:43:57 +0000",
  "in_reply_to_screen_name" : "duckinator",
  "in_reply_to_user_id_str" : "28650670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ORuOTh2yGR",
      "expanded_url" : "http:\/\/quaran.to\/gifs\/0005\/",
      "display_url" : "quaran.to\/gifs\/0005\/"
    } ]
  },
  "geo" : { },
  "id_str" : "508007363719094272",
  "text" : "Added bonus of seeking out original GIF authors: the original GIF is better, bigger http:\/\/t.co\/ORuOTh2yGR",
  "id" : 508007363719094272,
  "created_at" : "2014-09-05 21:42:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/FskI1IgAnf",
      "expanded_url" : "http:\/\/quaran.to\/gifs\/",
      "display_url" : "quaran.to\/gifs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "507999692244799488",
  "text" : "Brought \/gifs back, with 3 properly sourced images: http:\/\/t.co\/FskI1IgAnf Now to find 30+ more...",
  "id" : 507999692244799488,
  "created_at" : "2014-09-05 21:12:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Pettit",
      "screen_name" : "nickrp",
      "indices" : [ 0, 7 ],
      "id_str" : "15349708",
      "id" : 15349708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507994096041205761",
  "geo" : { },
  "id_str" : "507994348231725057",
  "in_reply_to_user_id" : 15349708,
  "text" : "@nickrp it's pronounced \"GIF\"",
  "id" : 507994348231725057,
  "in_reply_to_status_id" : 507994096041205761,
  "created_at" : "2014-09-05 20:51:05 +0000",
  "in_reply_to_screen_name" : "nickrp",
  "in_reply_to_user_id_str" : "15349708",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 11, 23 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507993118319206400",
  "geo" : { },
  "id_str" : "507993321856192512",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack @sstephenson he's Tex Tile's distant cousin",
  "id" : 507993321856192512,
  "in_reply_to_status_id" : 507993118319206400,
  "created_at" : "2014-09-05 20:47:00 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shanley",
      "screen_name" : "shanley",
      "indices" : [ 3, 11 ],
      "id_str" : "50462250",
      "id" : 50462250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507990740257878017",
  "text" : "RT @shanley: Hey guess what literally all these blog posts could be avoided if you just use HTML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507739203505897472",
    "text" : "Hey guess what literally all these blog posts could be avoided if you just use HTML",
    "id" : 507739203505897472,
    "created_at" : "2014-09-05 03:57:14 +0000",
    "user" : {
      "name" : "Shanley",
      "screen_name" : "shanley",
      "protected" : false,
      "id_str" : "50462250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000273217382\/d974a46768ea9f1ba9e54b539f19e7fa_normal.jpeg",
      "id" : 50462250,
      "verified" : false
    }
  },
  "id" : 507990740257878017,
  "created_at" : "2014-09-05 20:36:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shanley",
      "screen_name" : "shanley",
      "indices" : [ 3, 11 ],
      "id_str" : "50462250",
      "id" : 50462250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507990650256498688",
  "text" : "RT @shanley: Fuck markdown use HTML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507738846444793858",
    "text" : "Fuck markdown use HTML",
    "id" : 507738846444793858,
    "created_at" : "2014-09-05 03:55:48 +0000",
    "user" : {
      "name" : "Shanley",
      "screen_name" : "shanley",
      "protected" : false,
      "id_str" : "50462250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000273217382\/d974a46768ea9f1ba9e54b539f19e7fa_normal.jpeg",
      "id" : 50462250,
      "verified" : false
    }
  },
  "id" : 507990650256498688,
  "created_at" : "2014-09-05 20:36:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/6yKaL9raSD",
      "expanded_url" : "https:\/\/twitter.com\/sstephenson\/status\/507931444182667264",
      "display_url" : "twitter.com\/sstephenson\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507989920825106432",
  "text" : "This x100: HTML == Markdown for techies. WYSIWYG\/contenteditable should not be as bad as it is. https:\/\/t.co\/6yKaL9raSD",
  "id" : 507989920825106432,
  "created_at" : "2014-09-05 20:33:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rirug",
      "screen_name" : "rirug",
      "indices" : [ 3, 9 ],
      "id_str" : "18145307",
      "id" : 18145307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/OWn7SmBkff",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "507988664643620864",
  "text" : "RT @rirug: There are a few spots left for Nickel City Ruby. Great presenters, great bagels, and dancing with robots! Who's in? http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/OWn7SmBkff",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "507978302548869120",
    "text" : "There are a few spots left for Nickel City Ruby. Great presenters, great bagels, and dancing with robots! Who's in? http:\/\/t.co\/OWn7SmBkff",
    "id" : 507978302548869120,
    "created_at" : "2014-09-05 19:47:19 +0000",
    "user" : {
      "name" : "rirug",
      "screen_name" : "rirug",
      "protected" : false,
      "id_str" : "18145307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1269125565\/RIRUG_normal.png",
      "id" : 18145307,
      "verified" : false
    }
  },
  "id" : 507988664643620864,
  "created_at" : "2014-09-05 20:28:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507987991248138241",
  "text" : "RT @sstephenson: Markdown\u2019s great for techies. But what if, instead of a spec, those 6 devs had spent 2 years creating a WYSIWYG editor tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507931444182667264",
    "text" : "Markdown\u2019s great for techies. But what if, instead of a spec, those 6 devs had spent 2 years creating a WYSIWYG editor that actually works?",
    "id" : 507931444182667264,
    "created_at" : "2014-09-05 16:41:07 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 507987991248138241,
  "created_at" : "2014-09-05 20:25:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keep Ruby Weird",
      "screen_name" : "keeprubyweird",
      "indices" : [ 0, 14 ],
      "id_str" : "2568409631",
      "id" : 2568409631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507981208614367232",
  "geo" : { },
  "id_str" : "507981485853245440",
  "in_reply_to_user_id" : 2568409631,
  "text" : "@keeprubyweird already bugged all prior attendees\/interested via email",
  "id" : 507981485853245440,
  "in_reply_to_status_id" : 507981208614367232,
  "created_at" : "2014-09-05 19:59:58 +0000",
  "in_reply_to_screen_name" : "keeprubyweird",
  "in_reply_to_user_id_str" : "2568409631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507980656807141376",
  "geo" : { },
  "id_str" : "507980880866840576",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu :(",
  "id" : 507980880866840576,
  "in_reply_to_status_id" : 507980656807141376,
  "created_at" : "2014-09-05 19:57:34 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 103, 118 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507980603556233216",
  "text" : "So we've bugged people on Twitter, Facebook, Meetup...what else are we missing to get the word out for @nickelcityruby?",
  "id" : 507980603556233216,
  "created_at" : "2014-09-05 19:56:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Queen City Games",
      "screen_name" : "qcgamesonline",
      "indices" : [ 0, 14 ],
      "id_str" : "2687962530",
      "id" : 2687962530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507977435317415936",
  "in_reply_to_user_id" : 2687962530,
  "text" : "@qcgamesonline hey do you have board games too? Only seeing MTG related tweets\/fb posts",
  "id" : 507977435317415936,
  "created_at" : "2014-09-05 19:43:53 +0000",
  "in_reply_to_screen_name" : "qcgamesonline",
  "in_reply_to_user_id_str" : "2687962530",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechValley RB",
      "screen_name" : "tvrb",
      "indices" : [ 3, 8 ],
      "id_str" : "138056822",
      "id" : 138056822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/IxkFZYJVRK",
      "expanded_url" : "http:\/\/bit.ly\/1xlABEa",
      "display_url" : "bit.ly\/1xlABEa"
    } ]
  },
  "geo" : { },
  "id_str" : "507971183786995712",
  "text" : "RT @tvrb: Nickel City Ruby - October 2-4 - Buffalo: Nickel City Ruby in Buffalo is coming up October 2-4. They have a gr... http:\/\/t.co\/Ixk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/IxkFZYJVRK",
        "expanded_url" : "http:\/\/bit.ly\/1xlABEa",
        "display_url" : "bit.ly\/1xlABEa"
      } ]
    },
    "geo" : { },
    "id_str" : "507938067261296642",
    "text" : "Nickel City Ruby - October 2-4 - Buffalo: Nickel City Ruby in Buffalo is coming up October 2-4. They have a gr... http:\/\/t.co\/IxkFZYJVRK",
    "id" : 507938067261296642,
    "created_at" : "2014-09-05 17:07:26 +0000",
    "user" : {
      "name" : "TechValley RB",
      "screen_name" : "tvrb",
      "protected" : false,
      "id_str" : "138056822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596294659\/TVRBLogo-egg_normal.jpg",
      "id" : 138056822,
      "verified" : false
    }
  },
  "id" : 507971183786995712,
  "created_at" : "2014-09-05 19:19:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507951606043000832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9231272964, -78.8759458904 ]
  },
  "id_str" : "507952059166244864",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams woooo!! Congrats!!",
  "id" : 507952059166244864,
  "in_reply_to_status_id" : 507951606043000832,
  "created_at" : "2014-09-05 18:03:02 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taras Grescoe",
      "screen_name" : "grescoe",
      "indices" : [ 3, 11 ],
      "id_str" : "458480423",
      "id" : 458480423
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Richard_Florida\/status\/507883361483096064\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/8NimNHL8fP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwxdOY0IcAA6a-B.png",
      "id_str" : "507883359746682880",
      "id" : 507883359746682880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwxdOY0IcAA6a-B.png",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 799
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 115,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8NimNHL8fP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/jK5qaGbsJH",
      "expanded_url" : "http:\/\/bit.ly\/1vWBYaH",
      "display_url" : "bit.ly\/1vWBYaH"
    } ]
  },
  "geo" : { },
  "id_str" : "507936744633692161",
  "text" : "RT @grescoe: \"Can I ride my bike to school, Mom?\" \n\"No. There are too many cars, it's not safe.\"\nhttp:\/\/t.co\/jK5qaGbsJH\nhttp:\/\/t.co\/8NimNHL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Richard_Florida\/status\/507883361483096064\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/8NimNHL8fP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwxdOY0IcAA6a-B.png",
        "id_str" : "507883359746682880",
        "id" : 507883359746682880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwxdOY0IcAA6a-B.png",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 799
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 115,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8NimNHL8fP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/jK5qaGbsJH",
        "expanded_url" : "http:\/\/bit.ly\/1vWBYaH",
        "display_url" : "bit.ly\/1vWBYaH"
      } ]
    },
    "geo" : { },
    "id_str" : "507884274218184704",
    "text" : "\"Can I ride my bike to school, Mom?\" \n\"No. There are too many cars, it's not safe.\"\nhttp:\/\/t.co\/jK5qaGbsJH\nhttp:\/\/t.co\/8NimNHL8fP",
    "id" : 507884274218184704,
    "created_at" : "2014-09-05 13:33:41 +0000",
    "user" : {
      "name" : "Taras Grescoe",
      "screen_name" : "grescoe",
      "protected" : false,
      "id_str" : "458480423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000515338736\/4e02fa12e266219ca317069fedc2251d_normal.jpeg",
      "id" : 458480423,
      "verified" : false
    }
  },
  "id" : 507936744633692161,
  "created_at" : "2014-09-05 17:02:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Otto",
      "screen_name" : "mdo",
      "indices" : [ 0, 4 ],
      "id_str" : "8207832",
      "id" : 8207832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507935644799074304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924213719, -78.8790852499 ]
  },
  "id_str" : "507935771005710336",
  "in_reply_to_user_id" : 8207832,
  "text" : "@mdo \uD83D\uDC4D",
  "id" : 507935771005710336,
  "in_reply_to_status_id" : 507935644799074304,
  "created_at" : "2014-09-05 16:58:19 +0000",
  "in_reply_to_screen_name" : "mdo",
  "in_reply_to_user_id_str" : "8207832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Otto",
      "screen_name" : "mdo",
      "indices" : [ 3, 7 ],
      "id_str" : "8207832",
      "id" : 8207832
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 9, 15 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507935742903857152",
  "text" : "RT @mdo: @qrush Agreed, apologies. I've edited the post. I didn't mean it derogatorily\u2014\"the general population\" also can refer to all human\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "507924234106978304",
    "geo" : { },
    "id_str" : "507935644799074304",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Agreed, apologies. I've edited the post. I didn't mean it derogatorily\u2014\"the general population\" also can refer to all humankind.",
    "id" : 507935644799074304,
    "in_reply_to_status_id" : 507924234106978304,
    "created_at" : "2014-09-05 16:57:49 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Mark Otto",
      "screen_name" : "mdo",
      "protected" : false,
      "id_str" : "8207832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1422223766\/mdo-upside-down-shades_normal.jpg",
      "id" : 8207832,
      "verified" : false
    }
  },
  "id" : 507935742903857152,
  "created_at" : "2014-09-05 16:58:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/CPHL5nPJrn",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244371364, -78.8791503758 ]
  },
  "id_str" : "507928472463753216",
  "text" : "Also our schedule is live now too. Fridays post lunch are a great time to plan your trip here! http:\/\/t.co\/CPHL5nPJrn",
  "id" : 507928472463753216,
  "created_at" : "2014-09-05 16:29:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/gC6tKRaKnR",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "507928337210028032",
  "text" : "RT @nickelcityruby: The schedule is now live for #ncrc14 - check it out!! http:\/\/t.co\/gC6tKRaKnR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/gC6tKRaKnR",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
        "display_url" : "nickelcityruby.com\/#schedule"
      } ]
    },
    "geo" : { },
    "id_str" : "507894945437720576",
    "text" : "The schedule is now live for #ncrc14 - check it out!! http:\/\/t.co\/gC6tKRaKnR",
    "id" : 507894945437720576,
    "created_at" : "2014-09-05 14:16:05 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 507928337210028032,
  "created_at" : "2014-09-05 16:28:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507927927640834048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244371364, -78.8791503758 ]
  },
  "id_str" : "507928208407142400",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock pretty AWS costs are the highest. The problems are many.",
  "id" : 507928208407142400,
  "in_reply_to_status_id" : 507927927640834048,
  "created_at" : "2014-09-05 16:28:16 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 3, 14 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "indices" : [ 51, 60 ],
      "id_str" : "19278778",
      "id" : 19278778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/70Fqv4lBol",
      "expanded_url" : "http:\/\/gogaruco.com\/",
      "display_url" : "gogaruco.com"
    } ]
  },
  "geo" : { },
  "id_str" : "507927125236514817",
  "text" : "RT @joshsusser: There are &lt; 10 tickets left for @gogaruco. Better grab yours today! http:\/\/t.co\/70Fqv4lBol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Golden Gate RubyConf",
        "screen_name" : "gogaruco",
        "indices" : [ 35, 44 ],
        "id_str" : "19278778",
        "id" : 19278778
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/70Fqv4lBol",
        "expanded_url" : "http:\/\/gogaruco.com\/",
        "display_url" : "gogaruco.com"
      } ]
    },
    "geo" : { },
    "id_str" : "507925917654876160",
    "text" : "There are &lt; 10 tickets left for @gogaruco. Better grab yours today! http:\/\/t.co\/70Fqv4lBol",
    "id" : 507925917654876160,
    "created_at" : "2014-09-05 16:19:10 +0000",
    "user" : {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "protected" : false,
      "id_str" : "35954885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502547892230316032\/njGJleCw_normal.png",
      "id" : 35954885,
      "verified" : false
    }
  },
  "id" : 507927125236514817,
  "created_at" : "2014-09-05 16:23:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 3, 10 ],
      "id_str" : "623223",
      "id" : 623223
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 18, 33 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 48, 54 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 100, 115 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/sqHv8LzPAP",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#travel",
      "display_url" : "nickelcityruby.com\/#travel"
    } ]
  },
  "geo" : { },
  "id_str" : "507926304079872000",
  "text" : "RT @kbrock: $100? @nickelcityruby is a bargain! @qrush We\u2019ve extended the group rate until 9\/19 for @nickelcityruby. Hop on it! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 6, 21 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 36, 42 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 88, 103 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/sqHv8LzPAP",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#travel",
        "display_url" : "nickelcityruby.com\/#travel"
      } ]
    },
    "in_reply_to_status_id_str" : "507922737554128896",
    "geo" : { },
    "id_str" : "507926262607003648",
    "in_reply_to_user_id" : 5743852,
    "text" : "$100? @nickelcityruby is a bargain! @qrush We\u2019ve extended the group rate until 9\/19 for @nickelcityruby. Hop on it! http:\/\/t.co\/sqHv8LzPAP",
    "id" : 507926262607003648,
    "in_reply_to_status_id" : 507922737554128896,
    "created_at" : "2014-09-05 16:20:32 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "protected" : false,
      "id_str" : "623223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1346535527\/kb3_normal.jpg",
      "id" : 623223,
      "verified" : false
    }
  },
  "id" : 507926304079872000,
  "created_at" : "2014-09-05 16:20:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 0, 12 ],
      "id_str" : "13168222",
      "id" : 13168222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507924718612389890",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243088484, -78.8793075635 ]
  },
  "id_str" : "507926259511209984",
  "in_reply_to_user_id" : 13168222,
  "text" : "@mark_menard would appreciate pinging TVRB about it",
  "id" : 507926259511209984,
  "in_reply_to_status_id" : 507924718612389890,
  "created_at" : "2014-09-05 16:20:31 +0000",
  "in_reply_to_screen_name" : "mark_menard",
  "in_reply_to_user_id_str" : "13168222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Otto",
      "screen_name" : "mdo",
      "indices" : [ 0, 4 ],
      "id_str" : "8207832",
      "id" : 8207832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507906902630494208",
  "geo" : { },
  "id_str" : "507924234106978304",
  "in_reply_to_user_id" : 8207832,
  "text" : "@mdo isn't it a little fucked up that the language you use to describe your user base references a prison population?",
  "id" : 507924234106978304,
  "in_reply_to_status_id" : 507906902630494208,
  "created_at" : "2014-09-05 16:12:28 +0000",
  "in_reply_to_screen_name" : "mdo",
  "in_reply_to_user_id_str" : "8207832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 45, 60 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/uUDG6iQpoZ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#travel",
      "display_url" : "nickelcityruby.com\/#travel"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244038184, -78.8791051135 ]
  },
  "id_str" : "507922737554128896",
  "text" : "We\u2019ve extended the group rate until 9\/19 for @nickelcityruby. Hop on it! http:\/\/t.co\/uUDG6iQpoZ",
  "id" : 507922737554128896,
  "created_at" : "2014-09-05 16:06:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 3, 13 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507900082382200833",
  "text" : "RT @zachwaugh: New iTunes Connect certainly looks better, but appears they didn\u2019t actually improve anything, all superficial.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507899323280261120",
    "text" : "New iTunes Connect certainly looks better, but appears they didn\u2019t actually improve anything, all superficial.",
    "id" : 507899323280261120,
    "created_at" : "2014-09-05 14:33:29 +0000",
    "user" : {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "protected" : false,
      "id_str" : "14620798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549681852332535809\/TzOXTBNx_normal.jpeg",
      "id" : 14620798,
      "verified" : false
    }
  },
  "id" : 507900082382200833,
  "created_at" : "2014-09-05 14:36:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507874377157709825",
  "text" : "Deleted the gifs repo until I can track down all of the content's creators. Not going to be easy given Reddit doesn't do that at all.",
  "id" : 507874377157709825,
  "created_at" : "2014-09-05 12:54:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/CQKMVz5PNb",
      "expanded_url" : "http:\/\/instagram.com\/p\/skHyUzsOZ2\/",
      "display_url" : "instagram.com\/p\/skHyUzsOZ2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "507873927268270081",
  "text" : "RT @PublicEspresso: Get out of the long line of cars at Timmy Ho's and come stand in the long line at Breadhive for your\u2026 http:\/\/t.co\/CQKMV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/CQKMVz5PNb",
        "expanded_url" : "http:\/\/instagram.com\/p\/skHyUzsOZ2\/",
        "display_url" : "instagram.com\/p\/skHyUzsOZ2\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.918909, -78.885421 ]
    },
    "id_str" : "507873045156233216",
    "text" : "Get out of the long line of cars at Timmy Ho's and come stand in the long line at Breadhive for your\u2026 http:\/\/t.co\/CQKMVz5PNb",
    "id" : 507873045156233216,
    "created_at" : "2014-09-05 12:49:04 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 507873927268270081,
  "created_at" : "2014-09-05 12:52:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Willis",
      "screen_name" : "derekwillis",
      "indices" : [ 0, 12 ],
      "id_str" : "14517538",
      "id" : 14517538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507872704289325056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243509286, -78.8789798041 ]
  },
  "id_str" : "507872904919252993",
  "in_reply_to_user_id" : 14517538,
  "text" : "@derekwillis even if it\u2019s 10%, 20% on the Y it would be clearer.",
  "id" : 507872904919252993,
  "in_reply_to_status_id" : 507872704289325056,
  "created_at" : "2014-09-05 12:48:31 +0000",
  "in_reply_to_screen_name" : "derekwillis",
  "in_reply_to_user_id_str" : "14517538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924403734, -78.8791089117 ]
  },
  "id_str" : "507872739768541184",
  "text" : "And already got complaints of removing authorship. Sigh.",
  "id" : 507872739768541184,
  "created_at" : "2014-09-05 12:47:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Willis",
      "screen_name" : "derekwillis",
      "indices" : [ 0, 12 ],
      "id_str" : "14517538",
      "id" : 14517538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507870863145070592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242930096, -78.8790104818 ]
  },
  "id_str" : "507872073222352897",
  "in_reply_to_user_id" : 14517538,
  "text" : "@derekwillis ok. the title of the graph doesn\u2019t necessarily imply what the axis label is though :)",
  "id" : 507872073222352897,
  "in_reply_to_status_id" : 507870863145070592,
  "created_at" : "2014-09-05 12:45:12 +0000",
  "in_reply_to_screen_name" : "derekwillis",
  "in_reply_to_user_id_str" : "14517538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 0, 14 ],
      "id_str" : "184501661",
      "id" : 184501661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507869966344130560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241246841, -78.8792531082 ]
  },
  "id_str" : "507870321899089920",
  "in_reply_to_user_id" : 184501661,
  "text" : "@MileHighMusik it\u2019s ok. Really different to see Buffalo everywhere. Lots of Lackawanna too.",
  "id" : 507870321899089920,
  "in_reply_to_status_id" : 507869966344130560,
  "created_at" : "2014-09-05 12:38:15 +0000",
  "in_reply_to_screen_name" : "MileHighMusik",
  "in_reply_to_user_id_str" : "184501661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Willis",
      "screen_name" : "derekwillis",
      "indices" : [ 0, 12 ],
      "id_str" : "14517538",
      "id" : 14517538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507865761562771456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242811073, -78.8789876831 ]
  },
  "id_str" : "507867771825172480",
  "in_reply_to_user_id" : 14517538,
  "text" : "@derekwillis what exactly is the Y axis? Pretty confusing.",
  "id" : 507867771825172480,
  "in_reply_to_status_id" : 507865761562771456,
  "created_at" : "2014-09-05 12:28:07 +0000",
  "in_reply_to_screen_name" : "derekwillis",
  "in_reply_to_user_id_str" : "14517538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Neilson",
      "screen_name" : "mandrill",
      "indices" : [ 0, 9 ],
      "id_str" : "2456481",
      "id" : 2456481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507822704473677824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240521789, -78.8791201311 ]
  },
  "id_str" : "507847837317492736",
  "in_reply_to_user_id" : 2456481,
  "text" : "@mandrill sorry to bug you. I wish you could edit tweets :(",
  "id" : 507847837317492736,
  "in_reply_to_status_id" : 507822704473677824,
  "created_at" : "2014-09-05 11:08:54 +0000",
  "in_reply_to_screen_name" : "mandrill",
  "in_reply_to_user_id_str" : "2456481",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507740905223499776",
  "text" : "Literally have a folder of cool GIFs and no easy way to share them at full resolution :(",
  "id" : 507740905223499776,
  "created_at" : "2014-09-05 04:03:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Weizenbaum",
      "screen_name" : "nex3",
      "indices" : [ 0, 5 ],
      "id_str" : "12973272",
      "id" : 12973272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507738601023881216",
  "geo" : { },
  "id_str" : "507740517254574080",
  "in_reply_to_user_id" : 12973272,
  "text" : "@nex3 let's start with \"healthcare\" first",
  "id" : 507740517254574080,
  "in_reply_to_status_id" : 507738601023881216,
  "created_at" : "2014-09-05 04:02:27 +0000",
  "in_reply_to_screen_name" : "nex3",
  "in_reply_to_user_id_str" : "12973272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/bjlJfiLpwM",
      "expanded_url" : "http:\/\/blog.codinghorror.com\/secrets-of-the-javascript-ninjas\/",
      "display_url" : "blog.codinghorror.com\/secrets-of-the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "507737637365751809",
  "geo" : { },
  "id_str" : "507737893964480512",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby \"I've been historically ambivalent about JavaScript\" http:\/\/t.co\/bjlJfiLpwM",
  "id" : 507737893964480512,
  "in_reply_to_status_id" : 507737637365751809,
  "created_at" : "2014-09-05 03:52:01 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507725442884059137\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/fT2Uf0BADB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwvNmV7CQAAppvN.jpg",
      "id_str" : "507725441612791808",
      "id" : 507725441612791808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwvNmV7CQAAppvN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fT2Uf0BADB"
    } ],
    "hashtags" : [ {
      "text" : "WarbyHomeTryOn",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507725442884059137",
  "text" : "Am I doing this right? #WarbyHomeTryOn http:\/\/t.co\/fT2Uf0BADB",
  "id" : 507725442884059137,
  "created_at" : "2014-09-05 03:02:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507712746314428416",
  "geo" : { },
  "id_str" : "507712992595550208",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove every team needs a stats wizard",
  "id" : 507712992595550208,
  "in_reply_to_status_id" : 507712746314428416,
  "created_at" : "2014-09-05 02:13:04 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507710531567124480",
  "geo" : { },
  "id_str" : "507711257659457536",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon Looks like an iPad app...not a web app. Not sure why they obsess over this style of design so much.",
  "id" : 507711257659457536,
  "in_reply_to_status_id" : 507710531567124480,
  "created_at" : "2014-09-05 02:06:11 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 23, 38 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/M1yUh7X5uX",
      "expanded_url" : "https:\/\/twitter.com\/zobar2\/status\/507700910475476993",
      "display_url" : "twitter.com\/zobar2\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507709905860435969",
  "text" : "One gif that describes @nickelcityruby: https:\/\/t.co\/M1yUh7X5uX",
  "id" : 507709905860435969,
  "created_at" : "2014-09-05 02:00:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 61, 76 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GIFs\/status\/507336721860550656\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/U158z6uSxB",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BwpsDvcCIAAj2xn.png",
      "id_str" : "507336719562055680",
      "id" : 507336719562055680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BwpsDvcCIAAj2xn.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/U158z6uSxB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507709630927998976",
  "text" : "RT @zobar2: What's so great about the things you'll learn at @nickelcityruby? I'll let you in on a secret\u2026 https:\/\/t.co\/U158z6uSxB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 49, 64 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GIFs\/status\/507336721860550656\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/U158z6uSxB",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BwpsDvcCIAAj2xn.png",
        "id_str" : "507336719562055680",
        "id" : 507336719562055680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BwpsDvcCIAAj2xn.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/U158z6uSxB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507700910475476993",
    "text" : "What's so great about the things you'll learn at @nickelcityruby? I'll let you in on a secret\u2026 https:\/\/t.co\/U158z6uSxB",
    "id" : 507700910475476993,
    "created_at" : "2014-09-05 01:25:04 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 507709630927998976,
  "created_at" : "2014-09-05 01:59:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507692318812413952",
  "geo" : { },
  "id_str" : "507692507652567041",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 this is also a tech problem",
  "id" : 507692507652567041,
  "in_reply_to_status_id" : 507692318812413952,
  "created_at" : "2014-09-05 00:51:40 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507671769420144641\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/4nVYXDuNcL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwucyM1IQAAgGQX.jpg",
      "id_str" : "507671769260769280",
      "id" : 507671769260769280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwucyM1IQAAgGQX.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4nVYXDuNcL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507671769420144641",
  "text" : "No standing in this alley http:\/\/t.co\/4nVYXDuNcL",
  "id" : 507671769420144641,
  "created_at" : "2014-09-04 23:29:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Dean",
      "screen_name" : "colindean",
      "indices" : [ 0, 10 ],
      "id_str" : "14381906",
      "id" : 14381906
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 11, 19 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507627120692969472",
  "geo" : { },
  "id_str" : "507628412492472320",
  "in_reply_to_user_id" : 14381906,
  "text" : "@colindean @whit537 Flickr. License your photos properly and tons of storage.",
  "id" : 507628412492472320,
  "in_reply_to_status_id" : 507627120692969472,
  "created_at" : "2014-09-04 20:36:59 +0000",
  "in_reply_to_screen_name" : "colindean",
  "in_reply_to_user_id_str" : "14381906",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507628156941893634",
  "text" : "I literally just choked on my own vomit \"Watch Our Latest Webinar: Badgeville for Online Communities\"",
  "id" : 507628156941893634,
  "created_at" : "2014-09-04 20:35:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "indices" : [ 43, 59 ],
      "id_str" : "16450873",
      "id" : 16450873
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 60, 68 ],
      "id_str" : "19976046",
      "id" : 19976046
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 69, 80 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 81, 88 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Stark & Wayne",
      "screen_name" : "starkandwayne",
      "indices" : [ 89, 103 ],
      "id_str" : "925830462",
      "id" : 925830462
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 104, 114 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "PhishMe",
      "screen_name" : "PhishMe",
      "indices" : [ 115, 123 ],
      "id_str" : "92534896",
      "id" : 92534896
    }, {
      "name" : "Littlelines on Rails",
      "screen_name" : "littlelines",
      "indices" : [ 124, 136 ],
      "id_str" : "22043483",
      "id" : 22043483
    }, {
      "name" : "Keith Neilson",
      "screen_name" : "mandrill",
      "indices" : [ 137, 140 ],
      "id_str" : "2456481",
      "id" : 2456481
    }, {
      "name" : "Traitify",
      "screen_name" : "traitify",
      "indices" : [ 139, 140 ],
      "id_str" : "272983344",
      "id" : 272983344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507617617763254273",
  "text" : "RT @nickelcityruby: Thanks to our sponsors @infotechniagara @Synacor @engineyard @github @starkandwayne @37signals @PhishMe @littlelines @m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "infotechniagara",
        "screen_name" : "infotechniagara",
        "indices" : [ 23, 39 ],
        "id_str" : "16450873",
        "id" : 16450873
      }, {
        "name" : "Synacor",
        "screen_name" : "Synacor",
        "indices" : [ 40, 48 ],
        "id_str" : "19976046",
        "id" : 19976046
      }, {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 49, 60 ],
        "id_str" : "7255652",
        "id" : 7255652
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 61, 68 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "Stark & Wayne",
        "screen_name" : "starkandwayne",
        "indices" : [ 69, 83 ],
        "id_str" : "925830462",
        "id" : 925830462
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 84, 94 ],
        "id_str" : "11132462",
        "id" : 11132462
      }, {
        "name" : "PhishMe",
        "screen_name" : "PhishMe",
        "indices" : [ 95, 103 ],
        "id_str" : "92534896",
        "id" : 92534896
      }, {
        "name" : "Littlelines on Rails",
        "screen_name" : "littlelines",
        "indices" : [ 104, 116 ],
        "id_str" : "22043483",
        "id" : 22043483
      }, {
        "name" : "Keith Neilson",
        "screen_name" : "mandrill",
        "indices" : [ 117, 126 ],
        "id_str" : "2456481",
        "id" : 2456481
      }, {
        "name" : "Traitify",
        "screen_name" : "traitify",
        "indices" : [ 133, 142 ],
        "id_str" : "272983344",
        "id" : 272983344
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507592994979983360",
    "text" : "Thanks to our sponsors @infotechniagara @Synacor @engineyard @github @starkandwayne @37signals @PhishMe @littlelines @mandrill &amp; @traitify",
    "id" : 507592994979983360,
    "created_at" : "2014-09-04 18:16:15 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 507617617763254273,
  "created_at" : "2014-09-04 19:54:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leon",
      "screen_name" : "leyawn",
      "indices" : [ 3, 10 ],
      "id_str" : "49708023",
      "id" : 49708023
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/leyawn\/status\/507538934864560129\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/PK9Fq2lY00",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwsj-E-IYAAWzxW.jpg",
      "id_str" : "507538932402511872",
      "id" : 507538932402511872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwsj-E-IYAAWzxW.jpg",
      "sizes" : [ {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1638,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PK9Fq2lY00"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507576375486578688",
  "text" : "RT @leyawn: every one please look at this image from the wiki how to play fantasy football page http:\/\/t.co\/PK9Fq2lY00",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/leyawn\/status\/507538934864560129\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/PK9Fq2lY00",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwsj-E-IYAAWzxW.jpg",
        "id_str" : "507538932402511872",
        "id" : 507538932402511872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwsj-E-IYAAWzxW.jpg",
        "sizes" : [ {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1638,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PK9Fq2lY00"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507538934864560129",
    "text" : "every one please look at this image from the wiki how to play fantasy football page http:\/\/t.co\/PK9Fq2lY00",
    "id" : 507538934864560129,
    "created_at" : "2014-09-04 14:41:26 +0000",
    "user" : {
      "name" : "leon",
      "screen_name" : "leyawn",
      "protected" : false,
      "id_str" : "49708023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3205550236\/70e0971b8c52faf3a44fd9a6194c54f5_normal.gif",
      "id" : 49708023,
      "verified" : false
    }
  },
  "id" : 507576375486578688,
  "created_at" : "2014-09-04 17:10:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 0, 9 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507561599624679425",
  "geo" : { },
  "id_str" : "507563060022616064",
  "in_reply_to_user_id" : 1051521,
  "text" : "@migreyes slowly perishing, carbon bag of water",
  "id" : 507563060022616064,
  "in_reply_to_status_id" : 507561599624679425,
  "created_at" : "2014-09-04 16:17:18 +0000",
  "in_reply_to_screen_name" : "migreyes",
  "in_reply_to_user_id_str" : "1051521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507557252413550593",
  "geo" : { },
  "id_str" : "507557341072343040",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Not even there yet.",
  "id" : 507557341072343040,
  "in_reply_to_status_id" : 507557252413550593,
  "created_at" : "2014-09-04 15:54:34 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507557063091056640",
  "geo" : { },
  "id_str" : "507557167684001792",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss AppCode has been a breath of fresh air",
  "id" : 507557167684001792,
  "in_reply_to_status_id" : 507557063091056640,
  "created_at" : "2014-09-04 15:53:53 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 53, 63 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/LurNA40dkt",
      "expanded_url" : "http:\/\/blog.freshdesk.com\/the-secret-sauce-to-basecamp-support\/?utm_content=bufferff4ae&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "blog.freshdesk.com\/the-secret-sau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507556914847158272",
  "text" : "My coworker got interviewed about working support at @37signals. Oh, and zombies. http:\/\/t.co\/LurNA40dkt",
  "id" : 507556914847158272,
  "created_at" : "2014-09-04 15:52:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 84, 99 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/F5MMx6JTUh",
      "expanded_url" : "http:\/\/youtu.be\/V61VWE5P5z4?t=1m38s",
      "display_url" : "youtu.be\/V61VWE5P5z4?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507556516166000640",
  "text" : "RT @zobar2: What local Buffalo custom gave Anderson Cooper a giggle fit? Find me at @nickelcityruby and I'll clue you in! http:\/\/t.co\/F5MMx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 72, 87 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/F5MMx6JTUh",
        "expanded_url" : "http:\/\/youtu.be\/V61VWE5P5z4?t=1m38s",
        "display_url" : "youtu.be\/V61VWE5P5z4?t=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507289295045287936",
    "text" : "What local Buffalo custom gave Anderson Cooper a giggle fit? Find me at @nickelcityruby and I'll clue you in! http:\/\/t.co\/F5MMx6JTUh",
    "id" : 507289295045287936,
    "created_at" : "2014-09-03 22:09:27 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 507556516166000640,
  "created_at" : "2014-09-04 15:51:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 3, 7 ],
      "id_str" : "5523",
      "id" : 5523
    }, {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "indices" : [ 70, 79 ],
      "id_str" : "19278778",
      "id" : 19278778
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 86, 101 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Brooklyn Beta",
      "screen_name" : "brooklynbeta",
      "indices" : [ 103, 116 ],
      "id_str" : "126424576",
      "id" : 126424576
    }, {
      "name" : "Keep Ruby Weird",
      "screen_name" : "keeprubyweird",
      "indices" : [ 118, 132 ],
      "id_str" : "2568409631",
      "id" : 2568409631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507556478228525057",
  "text" : "RT @pat: Off to the US in a week! Still so much to do! Argh! But: SF, @gogaruco, NYC, @nickelcityruby, @brooklynbeta, @keeprubyweird - much\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Golden Gate RubyConf",
        "screen_name" : "gogaruco",
        "indices" : [ 61, 70 ],
        "id_str" : "19278778",
        "id" : 19278778
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 77, 92 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Brooklyn Beta",
        "screen_name" : "brooklynbeta",
        "indices" : [ 94, 107 ],
        "id_str" : "126424576",
        "id" : 126424576
      }, {
        "name" : "Keep Ruby Weird",
        "screen_name" : "keeprubyweird",
        "indices" : [ 109, 123 ],
        "id_str" : "2568409631",
        "id" : 2568409631
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507326698887475200",
    "text" : "Off to the US in a week! Still so much to do! Argh! But: SF, @gogaruco, NYC, @nickelcityruby, @brooklynbeta, @keeprubyweird - much fun!",
    "id" : 507326698887475200,
    "created_at" : "2014-09-04 00:38:05 +0000",
    "user" : {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "protected" : false,
      "id_str" : "5523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475943177833050112\/KVAIzJUb_normal.png",
      "id" : 5523,
      "verified" : false
    }
  },
  "id" : 507556478228525057,
  "created_at" : "2014-09-04 15:51:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    }, {
      "name" : "Allison BreadHive",
      "screen_name" : "AlisonBreadHive",
      "indices" : [ 10, 26 ],
      "id_str" : "1945604605",
      "id" : 1945604605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507547569871147008",
  "geo" : { },
  "id_str" : "507548071647911937",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos @AlisonBreadHive yessssss",
  "id" : 507548071647911937,
  "in_reply_to_status_id" : 507547569871147008,
  "created_at" : "2014-09-04 15:17:44 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507545559863795712",
  "text" : "I miss writing.",
  "id" : 507545559863795712,
  "created_at" : "2014-09-04 15:07:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507356125188984832\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/GI9aIPVI7T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwp9tGtCUAAR0yL.jpg",
      "id_str" : "507356121879695360",
      "id" : 507356121879695360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwp9tGtCUAAR0yL.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/GI9aIPVI7T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244556283, -78.8794098281 ]
  },
  "id_str" : "507356125188984832",
  "text" : "Final board. 462-414 http:\/\/t.co\/GI9aIPVI7T",
  "id" : 507356125188984832,
  "created_at" : "2014-09-04 02:35:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507354818147401728\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/rEOKCStSWq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwp8hDACMAIWjyj.jpg",
      "id_str" : "507354815215579138",
      "id" : 507354815215579138,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwp8hDACMAIWjyj.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rEOKCStSWq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245469813, -78.8791797125 ]
  },
  "id_str" : "507354818147401728",
  "text" : "East side expands despite threats from local dragon http:\/\/t.co\/rEOKCStSWq",
  "id" : 507354818147401728,
  "created_at" : "2014-09-04 02:29:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507353648007880704\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/K5aalaFgvO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwp7c8GCMAE_szY.jpg",
      "id_str" : "507353645130592257",
      "id" : 507353645130592257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwp7c8GCMAE_szY.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/K5aalaFgvO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243918742, -78.8792403974 ]
  },
  "id_str" : "507353648007880704",
  "text" : "Highways and byways http:\/\/t.co\/K5aalaFgvO",
  "id" : 507353648007880704,
  "created_at" : "2014-09-04 02:25:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507352638518607872\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ErX3aLbqhn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwp6iISCIAAREcO.jpg",
      "id_str" : "507352634789863424",
      "id" : 507352634789863424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwp6iISCIAAREcO.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/ErX3aLbqhn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243912874, -78.8793155831 ]
  },
  "id_str" : "507352638518607872",
  "text" : "Abbey helped make a cool pattern on the north side http:\/\/t.co\/ErX3aLbqhn",
  "id" : 507352638518607872,
  "created_at" : "2014-09-04 02:21:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507349607232180224\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/HUGGBsCITo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwp3xf2CcAAHgPD.jpg",
      "id_str" : "507349600278048768",
      "id" : 507349600278048768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwp3xf2CcAAHgPD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/HUGGBsCITo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.92443732, -78.8793168953 ]
  },
  "id_str" : "507349607232180224",
  "text" : "Dragon visits the east side http:\/\/t.co\/HUGGBsCITo",
  "id" : 507349607232180224,
  "created_at" : "2014-09-04 02:09:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507348308612759552\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/UCGKY4VUIo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwp2mCICYAA1SUZ.jpg",
      "id_str" : "507348303810289664",
      "id" : 507348303810289664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwp2mCICYAA1SUZ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UCGKY4VUIo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244114536, -78.8794375143 ]
  },
  "id_str" : "507348308612759552",
  "text" : "Dueling castles http:\/\/t.co\/UCGKY4VUIo",
  "id" : 507348308612759552,
  "created_at" : "2014-09-04 02:03:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507347285211357184\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/rXXJOCtkKN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwp1qcECEAAeI6S.jpg",
      "id_str" : "507347279980662784",
      "id" : 507347279980662784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwp1qcECEAAeI6S.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rXXJOCtkKN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244231691, -78.8792141079 ]
  },
  "id_str" : "507347285211357184",
  "text" : "The eastern front heats up http:\/\/t.co\/rXXJOCtkKN",
  "id" : 507347285211357184,
  "created_at" : "2014-09-04 01:59:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507344829538246656\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/jP5jvtu4gW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwpzboOCYAEDUXT.jpg",
      "id_str" : "507344826522558465",
      "id" : 507344826522558465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwpzboOCYAEDUXT.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/jP5jvtu4gW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.92449757, -78.8793729991 ]
  },
  "id_str" : "507344829538246656",
  "text" : "Expanding http:\/\/t.co\/jP5jvtu4gW",
  "id" : 507344829538246656,
  "created_at" : "2014-09-04 01:50:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conor Muirhead",
      "screen_name" : "conormuirhead",
      "indices" : [ 0, 14 ],
      "id_str" : "16642275",
      "id" : 16642275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507343583649619969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243619508, -78.8791904986 ]
  },
  "id_str" : "507344036911251456",
  "in_reply_to_user_id" : 16642275,
  "text" : "@conormuirhead it\u2019s great. And a gateway drug",
  "id" : 507344036911251456,
  "in_reply_to_status_id" : 507343583649619969,
  "created_at" : "2014-09-04 01:46:59 +0000",
  "in_reply_to_screen_name" : "conormuirhead",
  "in_reply_to_user_id_str" : "16642275",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conor Muirhead",
      "screen_name" : "conormuirhead",
      "indices" : [ 0, 14 ],
      "id_str" : "16642275",
      "id" : 16642275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507342787751444480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243619508, -78.8791904986 ]
  },
  "id_str" : "507343380653686784",
  "in_reply_to_user_id" : 16642275,
  "text" : "@conormuirhead Carcassone",
  "id" : 507343380653686784,
  "in_reply_to_status_id" : 507342787751444480,
  "created_at" : "2014-09-04 01:44:22 +0000",
  "in_reply_to_screen_name" : "conormuirhead",
  "in_reply_to_user_id_str" : "16642275",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507343243244101632\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/PtfpcEsCZU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwpx_KrCEAAmMjr.jpg",
      "id_str" : "507343238043144192",
      "id" : 507343238043144192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwpx_KrCEAAmMjr.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/PtfpcEsCZU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243619508, -78.8791904986 ]
  },
  "id_str" : "507343243244101632",
  "text" : "Dragon claims its first victim http:\/\/t.co\/PtfpcEsCZU",
  "id" : 507343243244101632,
  "created_at" : "2014-09-04 01:43:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507339469825908736\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/gp4Fjdjz2J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwpujqmCYAAd7H_.jpg",
      "id_str" : "507339467040907264",
      "id" : 507339467040907264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwpujqmCYAAd7H_.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gp4Fjdjz2J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245771142, -78.8790369686 ]
  },
  "id_str" : "507339469825908736",
  "text" : "Big castle had a witch then she was chased off http:\/\/t.co\/gp4Fjdjz2J",
  "id" : 507339469825908736,
  "created_at" : "2014-09-04 01:28:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507336126206451713\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/DoSDiMAQa0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwprg53CUAA9gy6.jpg",
      "id_str" : "507336121064247296",
      "id" : 507336121064247296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwprg53CUAA9gy6.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DoSDiMAQa0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244617792, -78.8788984158 ]
  },
  "id_str" : "507336126206451713",
  "text" : "Bridges abound http:\/\/t.co\/DoSDiMAQa0",
  "id" : 507336126206451713,
  "created_at" : "2014-09-04 01:15:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507333377943273472\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/1vQmnTBKWY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwppBDRCUAA5ICl.jpg",
      "id_str" : "507333374810148864",
      "id" : 507333374810148864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwppBDRCUAA5ICl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1vQmnTBKWY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244339179, -78.879183877 ]
  },
  "id_str" : "507333377943273472",
  "text" : "Several ferries and bridges up http:\/\/t.co\/1vQmnTBKWY",
  "id" : 507333377943273472,
  "created_at" : "2014-09-04 01:04:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507330543248105472\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/RtwRw3erYq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwpmb-MCMAAy2nD.jpg",
      "id_str" : "507330538768576512",
      "id" : 507330538768576512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwpmb-MCMAAy2nD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/RtwRw3erYq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9246306746, -78.879280882 ]
  },
  "id_str" : "507330543248105472",
  "text" : "Starting small http:\/\/t.co\/RtwRw3erYq",
  "id" : 507330543248105472,
  "created_at" : "2014-09-04 00:53:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507328397312131072\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/QKBFJfjCGA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwpkfB7CYAA4QMe.jpg",
      "id_str" : "507328392287379456",
      "id" : 507328392287379456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwpkfB7CYAA4QMe.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QKBFJfjCGA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9246750987, -78.8793071174 ]
  },
  "id_str" : "507328397312131072",
  "text" : "About to try playing 10 Carcassone expansions at once. No fields. http:\/\/t.co\/QKBFJfjCGA",
  "id" : 507328397312131072,
  "created_at" : "2014-09-04 00:44:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/KdmQVztuFj",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/5407935e498e276423b99cf8?s=KM5-69ZVHPXuKnGE0eL4R2LXv10&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9059608525, -78.8871723603 ]
  },
  "id_str" : "507291204527345666",
  "text" : "I'm at The Black Sheep in Buffalo, NY https:\/\/t.co\/KdmQVztuFj",
  "id" : 507291204527345666,
  "created_at" : "2014-09-03 22:17:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Ward",
      "screen_name" : "eviltrout",
      "indices" : [ 0, 10 ],
      "id_str" : "16712921",
      "id" : 16712921
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507289757748301824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.90621036, -78.8870656992 ]
  },
  "id_str" : "507290987715387392",
  "in_reply_to_user_id" : 16712921,
  "text" : "@eviltrout ooooh. are you coming down for @nickelcityruby ?",
  "id" : 507290987715387392,
  "in_reply_to_status_id" : 507289757748301824,
  "created_at" : "2014-09-03 22:16:11 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/GJmeakkiz9",
      "expanded_url" : "http:\/\/buffalorising.com\/2014\/09\/lunch-handlebar-the-hub\/",
      "display_url" : "buffalorising.com\/2014\/09\/lunch-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507273483345072128",
  "text" : "New bar in Buffalo has a board game built into their tables!! http:\/\/t.co\/GJmeakkiz9",
  "id" : 507273483345072128,
  "created_at" : "2014-09-03 21:06:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 37, 52 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 90, 105 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507272016580190208",
  "text" : "RT @kevinpurdy: (Learned a bundle at @AustinSeraphin's talk on iOS &amp; accessibility at @nickelcityruby last year. And I can't even Hello Wor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Austin Seraphin",
        "screen_name" : "AustinSeraphin",
        "indices" : [ 21, 36 ],
        "id_str" : "16393800",
        "id" : 16393800
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 74, 89 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507261135239020544",
    "text" : "(Learned a bundle at @AustinSeraphin's talk on iOS &amp; accessibility at @nickelcityruby last year. And I can't even Hello World in Ruby.)",
    "id" : 507261135239020544,
    "created_at" : "2014-09-03 20:17:33 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 507272016580190208,
  "created_at" : "2014-09-03 21:00:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 3, 13 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 47, 62 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5YKSJyep8q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "507271990697144323",
  "text" : "RT @tehviking: As a nerd\nI want you to come to @nickelcityruby \nSo that you can have a good time with robots and me \nhttp:\/\/t.co\/5YKSJyep8q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 32, 47 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/5YKSJyep8q",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "507266833821347842",
    "text" : "As a nerd\nI want you to come to @nickelcityruby \nSo that you can have a good time with robots and me \nhttp:\/\/t.co\/5YKSJyep8q",
    "id" : 507266833821347842,
    "created_at" : "2014-09-03 20:40:12 +0000",
    "user" : {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "protected" : false,
      "id_str" : "59341538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431152612264509440\/r4L_jVW6_normal.jpeg",
      "id" : 59341538,
      "verified" : false
    }
  },
  "id" : 507271990697144323,
  "created_at" : "2014-09-03 21:00:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507262842601353216",
  "text" : "\"If you want to criticize a religion, write a book.\"",
  "id" : 507262842601353216,
  "created_at" : "2014-09-03 20:24:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507262645448097792",
  "text" : "\"new questions may result in new rules at any time. Perhaps your App will trigger this.\"",
  "id" : 507262645448097792,
  "created_at" : "2014-09-03 20:23:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/bKHZ6IWRYq",
      "expanded_url" : "https:\/\/developer.apple.com\/app-store\/review\/guidelines\/",
      "display_url" : "developer.apple.com\/app-store\/revi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507262481891205120",
  "text" : "The language on https:\/\/t.co\/bKHZ6IWRYq just drips of such smug. \"What line, you ask?\"",
  "id" : 507262481891205120,
  "created_at" : "2014-09-03 20:22:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/507258096356298752\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/kvX7LWRh2g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwokjERCAAECsnb.png",
      "id_str" : "507258092891799553",
      "id" : 507258092891799553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwokjERCAAECsnb.png",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1408,
        "resize" : "fit",
        "w" : 1984
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kvX7LWRh2g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507258096356298752",
  "text" : "Apple: \"We have lots of serious developers who don't want their quality Apps to be surrounded by amateur hour.\" http:\/\/t.co\/kvX7LWRh2g",
  "id" : 507258096356298752,
  "created_at" : "2014-09-03 20:05:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506992560028401665",
  "geo" : { },
  "id_str" : "507257438249037825",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo 8\/29 is my favorite night after listening to them all again. No Quarter is deep and dark, Simple &gt; Wading just blissful.",
  "id" : 507257438249037825,
  "in_reply_to_status_id" : 506992560028401665,
  "created_at" : "2014-09-03 20:02:52 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507252514782461952",
  "geo" : { },
  "id_str" : "507252615961247745",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer Nintendoland. MK8.",
  "id" : 507252615961247745,
  "in_reply_to_status_id" : 507252514782461952,
  "created_at" : "2014-09-03 19:43:42 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    }, {
      "name" : "Phish.net",
      "screen_name" : "phishnet",
      "indices" : [ 12, 21 ],
      "id_str" : "41418199",
      "id" : 41418199
    }, {
      "name" : "Adam Scheinberg",
      "screen_name" : "sethadam1",
      "indices" : [ 22, 32 ],
      "id_str" : "6667632",
      "id" : 6667632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507220528357048320",
  "geo" : { },
  "id_str" : "507220904602923008",
  "in_reply_to_user_id" : 5743852,
  "text" : "@bizarchive @phishnet @sethadam1 sorry, something more constructive: How about exposing 3 maybe? And then a \"More options\" link.",
  "id" : 507220904602923008,
  "in_reply_to_status_id" : 507220528357048320,
  "created_at" : "2014-09-03 17:37:42 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    }, {
      "name" : "Phish.net",
      "screen_name" : "phishnet",
      "indices" : [ 12, 21 ],
      "id_str" : "41418199",
      "id" : 41418199
    }, {
      "name" : "Adam Scheinberg",
      "screen_name" : "sethadam1",
      "indices" : [ 22, 32 ],
      "id_str" : "6667632",
      "id" : 6667632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507217478326689792",
  "geo" : { },
  "id_str" : "507220528357048320",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive @phishnet @sethadam1 that is an immense amount of select boxes :(",
  "id" : 507220528357048320,
  "in_reply_to_status_id" : 507217478326689792,
  "created_at" : "2014-09-03 17:36:12 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 24, 39 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "507218656627924992",
  "text" : "30 days and counting to @nickelcityruby. Help decrease my stress level and increase your brain\/awesome levels: http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 507218656627924992,
  "created_at" : "2014-09-03 17:28:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/b4EwX6bFkQ",
      "expanded_url" : "http:\/\/www.confreaks.com\/events\/nickelcityruby2013",
      "display_url" : "confreaks.com\/events\/nickelc\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/SSC9cGJhVn",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "507218364196872192",
  "text" : "RT @nickelcityruby: Wow, there's just one month left until #ncrc14! Watch talks from 2013: http:\/\/t.co\/b4EwX6bFkQ and register for 2014: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/b4EwX6bFkQ",
        "expanded_url" : "http:\/\/www.confreaks.com\/events\/nickelcityruby2013",
        "display_url" : "confreaks.com\/events\/nickelc\u2026"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/SSC9cGJhVn",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "507174430578343936",
    "text" : "Wow, there's just one month left until #ncrc14! Watch talks from 2013: http:\/\/t.co\/b4EwX6bFkQ and register for 2014: http:\/\/t.co\/SSC9cGJhVn",
    "id" : 507174430578343936,
    "created_at" : "2014-09-03 14:33:01 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 507218364196872192,
  "created_at" : "2014-09-03 17:27:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Long Nguyen",
      "screen_name" : "lnguyen11288",
      "indices" : [ 0, 13 ],
      "id_str" : "158124243",
      "id" : 158124243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507170734024560640",
  "geo" : { },
  "id_str" : "507170847077826560",
  "in_reply_to_user_id" : 158124243,
  "text" : "@lnguyen11288 Not FIOS.",
  "id" : 507170847077826560,
  "in_reply_to_status_id" : 507170734024560640,
  "created_at" : "2014-09-03 14:18:47 +0000",
  "in_reply_to_screen_name" : "lnguyen11288",
  "in_reply_to_user_id_str" : "158124243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 44, 58 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507168498464722944",
  "text" : "Absolutely love how fast the internet is at @coworkbuffalo. Especially when compared to normal TWC home speeds :(",
  "id" : 507168498464722944,
  "created_at" : "2014-09-03 14:09:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 3, 12 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 139, 140 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507148998776336385",
  "text" : "RT @sebasoga: What would you say is the biggest challenge when moving towards a microservice architecture from a monolith application? \/cc \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 125, 140 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506850483160776704",
    "text" : "What would you say is the biggest challenge when moving towards a microservice architecture from a monolith application? \/cc @nickelcityruby",
    "id" : 506850483160776704,
    "created_at" : "2014-09-02 17:05:46 +0000",
    "user" : {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "protected" : false,
      "id_str" : "41438974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488894836628418560\/teTisCDG_normal.jpeg",
      "id" : 41438974,
      "verified" : false
    }
  },
  "id" : 507148998776336385,
  "created_at" : "2014-09-03 12:51:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 3, 12 ],
      "id_str" : "49102992",
      "id" : 49102992
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507148883571384320",
  "text" : "RT @poteland: Do you have your ticket for @nickelcityruby already? I'll be babbling about simplicity there next month, come hang out with m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 28, 43 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506889538275667969",
    "text" : "Do you have your ticket for @nickelcityruby already? I'll be babbling about simplicity there next month, come hang out with me! :)",
    "id" : 506889538275667969,
    "created_at" : "2014-09-02 19:40:58 +0000",
    "user" : {
      "name" : "pote",
      "screen_name" : "poteland",
      "protected" : false,
      "id_str" : "49102992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1395984707\/RedMage_normal.png",
      "id" : 49102992,
      "verified" : false
    }
  },
  "id" : 507148883571384320,
  "created_at" : "2014-09-03 12:51:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506959857795096576",
  "text" : "Anything kid related should have a review\/ranking system for how easy it is to clean mushy, stale food out of its deepest, darkest corners.",
  "id" : 506959857795096576,
  "created_at" : "2014-09-03 00:20:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "greatwhitebuffalo.rb",
      "screen_name" : "willywos",
      "indices" : [ 0, 9 ],
      "id_str" : "11186742",
      "id" : 11186742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506957543176810497",
  "geo" : { },
  "id_str" : "506957776459812864",
  "in_reply_to_user_id" : 11186742,
  "text" : "@willywos just use a git ssh url?",
  "id" : 506957776459812864,
  "in_reply_to_status_id" : 506957543176810497,
  "created_at" : "2014-09-03 00:12:07 +0000",
  "in_reply_to_screen_name" : "willywos",
  "in_reply_to_user_id_str" : "11186742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506945840225976320",
  "geo" : { },
  "id_str" : "506945921779634176",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto Oh BOY!",
  "id" : 506945921779634176,
  "in_reply_to_status_id" : 506945840225976320,
  "created_at" : "2014-09-02 23:25:01 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 3, 6 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 40, 55 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/9pfUrEFbmB",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "506945036416589824",
  "text" : "RT @j3: You should definitely check out @nickelcityruby \u2014 it\u2019s a strong lineup of speakers, great community, and great town: http:\/\/t.co\/9p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 32, 47 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/9pfUrEFbmB",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "506900121247043586",
    "text" : "You should definitely check out @nickelcityruby \u2014 it\u2019s a strong lineup of speakers, great community, and great town: http:\/\/t.co\/9pfUrEFbmB",
    "id" : 506900121247043586,
    "created_at" : "2014-09-02 20:23:01 +0000",
    "user" : {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "protected" : false,
      "id_str" : "1133971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000543599975\/c63a58ff323b22a9e9ad52ffbbfb7f0a_normal.jpeg",
      "id" : 1133971,
      "verified" : false
    }
  },
  "id" : 506945036416589824,
  "created_at" : "2014-09-02 23:21:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 3, 12 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "RSpec - BDD for Ruby",
      "screen_name" : "rspec",
      "indices" : [ 74, 80 ],
      "id_str" : "29239854",
      "id" : 29239854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/A5WDfkZ5vT",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "506945029479211009",
  "text" : "RT @sarahmei: Excited for @nickelcityruby in Oct! Come watch me live code @rspec starting from nothing (or fail spectacularly :D). http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 12, 27 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "RSpec - BDD for Ruby",
        "screen_name" : "rspec",
        "indices" : [ 60, 66 ],
        "id_str" : "29239854",
        "id" : 29239854
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/A5WDfkZ5vT",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "506933431906078720",
    "text" : "Excited for @nickelcityruby in Oct! Come watch me live code @rspec starting from nothing (or fail spectacularly :D). http:\/\/t.co\/A5WDfkZ5vT",
    "id" : 506933431906078720,
    "created_at" : "2014-09-02 22:35:23 +0000",
    "user" : {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "protected" : false,
      "id_str" : "14164724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564645861771079680\/i-bwhBp0_normal.jpeg",
      "id" : 14164724,
      "verified" : false
    }
  },
  "id" : 506945029479211009,
  "created_at" : "2014-09-02 23:21:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506927788507799552",
  "geo" : { },
  "id_str" : "506927861136392192",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 \"yes\" but nowhere as spicy as getting it in location.",
  "id" : 506927861136392192,
  "in_reply_to_status_id" : 506927788507799552,
  "created_at" : "2014-09-02 22:13:15 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/506921984236584961\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/4RnyhvwA8G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwjy2peCIAAN-_9.jpg",
      "id_str" : "506921978737860608",
      "id" : 506921978737860608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwjy2peCIAAN-_9.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/4RnyhvwA8G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243157808, -78.879126933 ]
  },
  "id_str" : "506921984236584961",
  "text" : "Ready for burn http:\/\/t.co\/4RnyhvwA8G",
  "id" : 506921984236584961,
  "created_at" : "2014-09-02 21:49:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506893370258493440",
  "text" : "RT @anildash: \"Of course you can trust us with a perfect digital replica of your actual thumbprint! No, no one could possibly keep your pho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506892885066022912",
    "text" : "\"Of course you can trust us with a perfect digital replica of your actual thumbprint! No, no one could possibly keep your photos secure.\"",
    "id" : 506892885066022912,
    "created_at" : "2014-09-02 19:54:16 +0000",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529664614863101952\/yBQgCUMW_normal.png",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 506893370258493440,
  "created_at" : "2014-09-02 19:56:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 26, 38 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 78, 89 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 90, 101 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/YkqgznRMzR",
      "expanded_url" : "https:\/\/twitter.com\/thegrogshop\/status\/506879791677833216",
      "display_url" : "twitter.com\/thegrogshop\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506883012374446080",
  "text" : "Cleveland friends: Go see @AqueousBand on Friday. https:\/\/t.co\/YkqgznRMzR \/cc @joefiorini @benjaminws (Who else am I missing?)",
  "id" : 506883012374446080,
  "created_at" : "2014-09-02 19:15:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Demyanovich",
      "screen_name" : "demmer12",
      "indices" : [ 3, 12 ],
      "id_str" : "14380132",
      "id" : 14380132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/P7QnTU8q1g",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "506864414163611648",
  "text" : "RT @demmer12: Looking for a conference this Fall? Check out http:\/\/t.co\/P7QnTU8q1g. Cheap tickets. Great speakers. Lots to do in Buffalo.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/P7QnTU8q1g",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "506822907914252288",
    "text" : "Looking for a conference this Fall? Check out http:\/\/t.co\/P7QnTU8q1g. Cheap tickets. Great speakers. Lots to do in Buffalo.",
    "id" : 506822907914252288,
    "created_at" : "2014-09-02 15:16:12 +0000",
    "user" : {
      "name" : "Craig Demyanovich",
      "screen_name" : "demmer12",
      "protected" : false,
      "id_str" : "14380132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1685607817\/craig-demyanovich_normal.jpg",
      "id" : 14380132,
      "verified" : false
    }
  },
  "id" : 506864414163611648,
  "created_at" : "2014-09-02 18:01:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Wilson",
      "screen_name" : "paulanthonywils",
      "indices" : [ 3, 19 ],
      "id_str" : "10112592",
      "id" : 10112592
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 63, 78 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/o8Dk92jXaO",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "506864366868627456",
  "text" : "RT @paulanthonywils: Looks like a great lineup for this year\u2019s @nickelcityruby \n\nhttp:\/\/t.co\/o8Dk92jXaO\n\nYou should go, especially if you\u2019r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 42, 57 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/o8Dk92jXaO",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "506824547258355712",
    "text" : "Looks like a great lineup for this year\u2019s @nickelcityruby \n\nhttp:\/\/t.co\/o8Dk92jXaO\n\nYou should go, especially if you\u2019re near Buffalo NY.",
    "id" : 506824547258355712,
    "created_at" : "2014-09-02 15:22:43 +0000",
    "user" : {
      "name" : "Paul Wilson",
      "screen_name" : "paulanthonywils",
      "protected" : false,
      "id_str" : "10112592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740067459\/my_square_head_640x480_normal.jpg",
      "id" : 10112592,
      "verified" : false
    }
  },
  "id" : 506864366868627456,
  "created_at" : "2014-09-02 18:00:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 3, 11 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506864267916627968",
  "text" : "RT @godfoca: Just bought my ticket for @nickelcityruby. Who else is gonna be there? :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 26, 41 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506851766445826048",
    "text" : "Just bought my ticket for @nickelcityruby. Who else is gonna be there? :)",
    "id" : 506851766445826048,
    "created_at" : "2014-09-02 17:10:52 +0000",
    "user" : {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "protected" : false,
      "id_str" : "9337082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528577378151596033\/_BO7Hbti_normal.jpeg",
      "id" : 9337082,
      "verified" : false
    }
  },
  "id" : 506864267916627968,
  "created_at" : "2014-09-02 18:00:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/3r3IDOQQoi",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/5405ebca498ed861b9c7c5e7?s=7rirHuPn0m20UqAAq5uYNSMRW9I&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.906003, -78.89663241 ]
  },
  "id_str" : "506836388403507200",
  "text" : "I'm at Niagara Seafood in Buffalo, NY https:\/\/t.co\/3r3IDOQQoi",
  "id" : 506836388403507200,
  "created_at" : "2014-09-02 16:09:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/QQR1ZPpHIO",
      "expanded_url" : "http:\/\/bit.ly\/Z5vxo8",
      "display_url" : "bit.ly\/Z5vxo8"
    } ]
  },
  "geo" : { },
  "id_str" : "506770460961284097",
  "text" : "RT @rachbarnhart: Attorney General to sue bank over redlining in Buffalo http:\/\/t.co\/QQR1ZPpHIO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/QQR1ZPpHIO",
        "expanded_url" : "http:\/\/bit.ly\/Z5vxo8",
        "display_url" : "bit.ly\/Z5vxo8"
      } ]
    },
    "geo" : { },
    "id_str" : "506754621399126017",
    "text" : "Attorney General to sue bank over redlining in Buffalo http:\/\/t.co\/QQR1ZPpHIO",
    "id" : 506754621399126017,
    "created_at" : "2014-09-02 10:44:51 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 506770460961284097,
  "created_at" : "2014-09-02 11:47:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506665385383301121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243317247, -78.8793705973 ]
  },
  "id_str" : "506758576077930496",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking listening and dancing to music is AWESOME",
  "id" : 506758576077930496,
  "in_reply_to_status_id" : 506665385383301121,
  "created_at" : "2014-09-02 11:00:34 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/506626136348971008\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/Y8mwng5wPy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwflyHwCMAAe8NU.png",
      "id_str" : "506626132339208192",
      "id" : 506626132339208192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwflyHwCMAAe8NU.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Y8mwng5wPy"
    } ],
    "hashtags" : [ {
      "text" : "dadops",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240188004, -78.8791431542 ]
  },
  "id_str" : "506626136348971008",
  "text" : "#dadops http:\/\/t.co\/Y8mwng5wPy",
  "id" : 506626136348971008,
  "created_at" : "2014-09-02 02:14:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239182299, -78.879181999 ]
  },
  "id_str" : "506584401795244032",
  "text" : "Also there\u2019s a lot of 8 bit art and retro\/chip tune esque music. And actual bands. I wish all kids shows were half this creative.",
  "id" : 506584401795244032,
  "created_at" : "2014-09-01 23:28:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239723327, -78.8791576964 ]
  },
  "id_str" : "506583104207601664",
  "text" : "Yo Gabba Gabba is the Katamari Damacy of kids shows. Ridiculous, unexpected, hilarious.",
  "id" : 506583104207601664,
  "created_at" : "2014-09-01 23:23:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "moe.",
      "screen_name" : "moeperiod",
      "indices" : [ 27, 37 ],
      "id_str" : "60102709",
      "id" : 60102709
    }, {
      "name" : "moe.down",
      "screen_name" : "moedown",
      "indices" : [ 73, 81 ],
      "id_str" : "47634029",
      "id" : 47634029
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/506562971112591361\/photo\/1",
      "indices" : [ 131, 144 ],
      "url" : "http:\/\/t.co\/hwk1UU07Gn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwesVmDIIAENXLs.jpg",
      "id_str" : "506562970093363201",
      "id" : 506562970093363201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwesVmDIIAENXLs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/hwk1UU07Gn"
    } ],
    "hashtags" : [ {
      "text" : "moedown15",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506580645397536768",
  "text" : "RT @AqueousBand: Thank you @moeperiod, family &amp; fans for a fantastic @moedown this year! Wow that was a lot of fun!\n#moedown15 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "moe.",
        "screen_name" : "moeperiod",
        "indices" : [ 10, 20 ],
        "id_str" : "60102709",
        "id" : 60102709
      }, {
        "name" : "moe.down",
        "screen_name" : "moedown",
        "indices" : [ 56, 64 ],
        "id_str" : "47634029",
        "id" : 47634029
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/506562971112591361\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/hwk1UU07Gn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwesVmDIIAENXLs.jpg",
        "id_str" : "506562970093363201",
        "id" : 506562970093363201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwesVmDIIAENXLs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 114,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/hwk1UU07Gn"
      } ],
      "hashtags" : [ {
        "text" : "moedown15",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506562971112591361",
    "text" : "Thank you @moeperiod, family &amp; fans for a fantastic @moedown this year! Wow that was a lot of fun!\n#moedown15 http:\/\/t.co\/hwk1UU07Gn",
    "id" : 506562971112591361,
    "created_at" : "2014-09-01 22:03:18 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 506580645397536768,
  "created_at" : "2014-09-01 23:13:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 0, 10 ],
      "id_str" : "15001533",
      "id" : 15001533
    }, {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 11, 20 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/uwXakt5J1l",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/5e715d1d19cabe9dacab",
      "display_url" : "gist.github.com\/qrush\/5e715d1d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "506540918472966144",
  "geo" : { },
  "id_str" : "506541240456708097",
  "in_reply_to_user_id" : 15001533,
  "text" : "@mikeburns @ubuwaits https:\/\/t.co\/uwXakt5J1l",
  "id" : 506541240456708097,
  "in_reply_to_status_id" : 506540918472966144,
  "created_at" : "2014-09-01 20:36:57 +0000",
  "in_reply_to_screen_name" : "mikeburns",
  "in_reply_to_user_id_str" : "15001533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    }, {
      "name" : "mike_burns",
      "screen_name" : "mike_burns",
      "indices" : [ 10, 21 ],
      "id_str" : "15383804",
      "id" : 15383804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/MOyGgmy9LO",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/dbad7471e17698afa053",
      "display_url" : "gist.github.com\/qrush\/dbad7471\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "506528347208560640",
  "geo" : { },
  "id_str" : "506539145108262913",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits @mike_burns i tried to post https:\/\/t.co\/MOyGgmy9LO but i got an error.",
  "id" : 506539145108262913,
  "in_reply_to_status_id" : 506528347208560640,
  "created_at" : "2014-09-01 20:28:37 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240167351, -78.8791383004 ]
  },
  "id_str" : "506292517533282304",
  "text" : "Not gonna make it to set 2. The curse of Mountain Time.",
  "id" : 506292517533282304,
  "created_at" : "2014-09-01 04:08:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
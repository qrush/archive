Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Monk Buffalo",
      "screen_name" : "BlueMonkBflo",
      "indices" : [ 3, 16 ],
      "id_str" : "248682655",
      "id" : 248682655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/BFcHHu2C3B",
      "expanded_url" : "http:\/\/fb.me\/32BPx7QE6",
      "display_url" : "fb.me\/32BPx7QE6"
    } ]
  },
  "geo" : { },
  "id_str" : "450755820759031809",
  "text" : "RT @BlueMonkBflo: Way to go Blue Monk Employees. http:\/\/t.co\/BFcHHu2C3B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/BFcHHu2C3B",
        "expanded_url" : "http:\/\/fb.me\/32BPx7QE6",
        "display_url" : "fb.me\/32BPx7QE6"
      } ]
    },
    "geo" : { },
    "id_str" : "450748781420871680",
    "text" : "Way to go Blue Monk Employees. http:\/\/t.co\/BFcHHu2C3B",
    "id" : 450748781420871680,
    "created_at" : "2014-03-31 21:37:38 +0000",
    "user" : {
      "name" : "Blue Monk Buffalo",
      "screen_name" : "BlueMonkBflo",
      "protected" : false,
      "id_str" : "248682655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1239424733\/logo_normal.jpg",
      "id" : 248682655,
      "verified" : false
    }
  },
  "id" : 450755820759031809,
  "created_at" : "2014-03-31 22:05:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/VQzfRy8nqw",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/urZ5H2Kg40",
      "expanded_url" : "http:\/\/guides.rubygems.org\/publishing\/#serving_your_own_gems",
      "display_url" : "guides.rubygems.org\/publishing\/#se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450743827671040001",
  "text" : "RT @drbrain: Publishing gems to a private server? Set allowed_push_host to avoid accidentally releasing to http:\/\/t.co\/VQzfRy8nqw: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/VQzfRy8nqw",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/urZ5H2Kg40",
        "expanded_url" : "http:\/\/guides.rubygems.org\/publishing\/#serving_your_own_gems",
        "display_url" : "guides.rubygems.org\/publishing\/#se\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "450736964984000512",
    "text" : "Publishing gems to a private server? Set allowed_push_host to avoid accidentally releasing to http:\/\/t.co\/VQzfRy8nqw: http:\/\/t.co\/urZ5H2Kg40",
    "id" : 450736964984000512,
    "created_at" : "2014-03-31 20:50:41 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 450743827671040001,
  "created_at" : "2014-03-31 21:17:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 10, 22 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450733738398203904",
  "geo" : { },
  "id_str" : "450733872456953856",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer @juliepagano X\/Y is so good. I also picked up FireRed recently.",
  "id" : 450733872456953856,
  "in_reply_to_status_id" : 450733738398203904,
  "created_at" : "2014-03-31 20:38:24 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    }, {
      "name" : "Butt Coin",
      "screen_name" : "ButtCoin",
      "indices" : [ 31, 40 ],
      "id_str" : "305854715",
      "id" : 305854715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450662617783472128",
  "geo" : { },
  "id_str" : "450662754912067584",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak this can't be real \/cc @ButtCoin",
  "id" : 450662754912067584,
  "in_reply_to_status_id" : 450662617783472128,
  "created_at" : "2014-03-31 15:55:48 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : " Tom Lee ",
      "screen_name" : "tjl",
      "indices" : [ 10, 14 ],
      "id_str" : "720863",
      "id" : 720863
    }, {
      "name" : "Benjamin Stein",
      "screen_name" : "benstein",
      "indices" : [ 15, 24 ],
      "id_str" : "783971",
      "id" : 783971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450656937739554816",
  "geo" : { },
  "id_str" : "450661637054140416",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @tjl @benstein I didn't intend to compete. From the start I wanted to fix things for the community. Rubyforge's time was up.",
  "id" : 450661637054140416,
  "in_reply_to_status_id" : 450656937739554816,
  "created_at" : "2014-03-31 15:51:21 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 3, 12 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "npmbot",
      "screen_name" : "npmjs",
      "indices" : [ 84, 90 ],
      "id_str" : "309528017",
      "id" : 309528017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/88ox5M6uW9",
      "expanded_url" : "http:\/\/blog.npmjs.org\/post\/80997676347\/nebulous-profit-meditations",
      "display_url" : "blog.npmjs.org\/post\/809976763\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450642619123523584",
  "text" : "RT @konklone: Oh right. *This* is why it's better to have a Node foundation and not @npmjs Inc. http:\/\/t.co\/88ox5M6uW9 Non-OSS modules in p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "npmbot",
        "screen_name" : "npmjs",
        "indices" : [ 70, 76 ],
        "id_str" : "309528017",
        "id" : 309528017
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/88ox5M6uW9",
        "expanded_url" : "http:\/\/blog.npmjs.org\/post\/80997676347\/nebulous-profit-meditations",
        "display_url" : "blog.npmjs.org\/post\/809976763\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "450642397576564736",
    "text" : "Oh right. *This* is why it's better to have a Node foundation and not @npmjs Inc. http:\/\/t.co\/88ox5M6uW9 Non-OSS modules in public registry.",
    "id" : 450642397576564736,
    "created_at" : "2014-03-31 14:34:54 +0000",
    "user" : {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "protected" : false,
      "id_str" : "5232171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226668113\/blue_normal.png",
      "id" : 5232171,
      "verified" : false
    }
  },
  "id" : 450642619123523584,
  "created_at" : "2014-03-31 14:35:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450621434906558464",
  "geo" : { },
  "id_str" : "450630858286702592",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown i'll be back for Railsconf though!",
  "id" : 450630858286702592,
  "in_reply_to_status_id" : 450621434906558464,
  "created_at" : "2014-03-31 13:49:03 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 62, 72 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450621434906558464",
  "geo" : { },
  "id_str" : "450630824354803713",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown thanks! not too sure what my plans are yet. It's @37signals meetup week.",
  "id" : 450630824354803713,
  "in_reply_to_status_id" : 450621434906558464,
  "created_at" : "2014-03-31 13:48:55 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450617319694168064",
  "text" : "And commuted into work. That was odd. Hello Chicago!",
  "id" : 450617319694168064,
  "created_at" : "2014-03-31 12:55:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450461633538969601",
  "text" : "Commuting into the actual office tomorrow. Feels_strangeman.jpg",
  "id" : 450461633538969601,
  "created_at" : "2014-03-31 02:36:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450389652172578816",
  "geo" : { },
  "id_str" : "450453621646192640",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark whelp",
  "id" : 450453621646192640,
  "in_reply_to_status_id" : 450389652172578816,
  "created_at" : "2014-03-31 02:04:47 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/450410054735261696\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/ZINL7ipYH8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkAtjuCCQAAR2_P.jpg",
      "id_str" : "450410054412288000",
      "id" : 450410054412288000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkAtjuCCQAAR2_P.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZINL7ipYH8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450410054735261696",
  "text" : "Wat? http:\/\/t.co\/ZINL7ipYH8",
  "id" : 450410054735261696,
  "created_at" : "2014-03-30 23:11:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin T.A. Gray",
      "screen_name" : "colinta",
      "indices" : [ 0, 8 ],
      "id_str" : "270963272",
      "id" : 270963272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449958520561991680",
  "geo" : { },
  "id_str" : "449959690890657792",
  "in_reply_to_user_id" : 270963272,
  "text" : "@colinta It\u2019s rendered into HTML. I would prefer to not deal with any formatting at all.",
  "id" : 449959690890657792,
  "in_reply_to_status_id" : 449958520561991680,
  "created_at" : "2014-03-29 17:22:04 +0000",
  "in_reply_to_screen_name" : "colinta",
  "in_reply_to_user_id_str" : "270963272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin T.A. Gray",
      "screen_name" : "colinta",
      "indices" : [ 0, 8 ],
      "id_str" : "270963272",
      "id" : 270963272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449954848973148160",
  "geo" : { },
  "id_str" : "449957753948504065",
  "in_reply_to_user_id" : 270963272,
  "text" : "@colinta nope. IMO it should be plaintext. Docs belong on github or elsewhere.",
  "id" : 449957753948504065,
  "in_reply_to_status_id" : 449954848973148160,
  "created_at" : "2014-03-29 17:14:23 +0000",
  "in_reply_to_screen_name" : "colinta",
  "in_reply_to_user_id_str" : "270963272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 0, 9 ],
      "id_str" : "14212405",
      "id" : 14212405
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 10, 17 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449632901463027712",
  "geo" : { },
  "id_str" : "449635801064689664",
  "in_reply_to_user_id" : 14212405,
  "text" : "@metadave @zobar2 KICKSTART IMMEDIATELY",
  "id" : 449635801064689664,
  "in_reply_to_status_id" : 449632901463027712,
  "created_at" : "2014-03-28 19:55:03 +0000",
  "in_reply_to_screen_name" : "metadave",
  "in_reply_to_user_id_str" : "14212405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/AaaBq4ajRe",
      "expanded_url" : "http:\/\/img3.wikia.nocookie.net\/__cb20130209022103\/adventuretimewithfinnandjake\/images\/f\/f0\/And_its_gone_original.jpg",
      "display_url" : "img3.wikia.nocookie.net\/__cb2013020902\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449632040150110210",
  "geo" : { },
  "id_str" : "449632543784964096",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan http:\/\/t.co\/AaaBq4ajRe",
  "id" : 449632543784964096,
  "in_reply_to_status_id" : 449632040150110210,
  "created_at" : "2014-03-28 19:42:06 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/WJGKoVBuaQ",
      "expanded_url" : "http:\/\/youtubedoubler.com\/?video1=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DnrEyxNqyw24&start1=780&video2=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DPpccpglnNf0&start2=0&authorName=",
      "display_url" : "youtubedoubler.com\/?video1=http%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449613704900771841",
  "text" : "\"Who would buy RapGenius?\" http:\/\/t.co\/WJGKoVBuaQ",
  "id" : 449613704900771841,
  "created_at" : "2014-03-28 18:27:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/3G2XAEsTnA",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nrEyxNqyw24#t=320",
      "display_url" : "youtube.com\/watch?v=nrEyxN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449610411537469440",
  "text" : "This isn't real life. It can't be. This is an Onion article or a Daily Show interview. https:\/\/t.co\/3G2XAEsTnA",
  "id" : 449610411537469440,
  "created_at" : "2014-03-28 18:14:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449604928479047680",
  "text" : "My talk prep in a nutshell: Outline &gt; Theme &gt; Slides &gt; Practice &gt; Practice &gt; Practice &gt; ADD ALL THE GIFs",
  "id" : 449604928479047680,
  "created_at" : "2014-03-28 17:52:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449601716900474880",
  "geo" : { },
  "id_str" : "449602792982712320",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense *that* should be in the postmortem. congrats!",
  "id" : 449602792982712320,
  "in_reply_to_status_id" : 449601716900474880,
  "created_at" : "2014-03-28 17:43:53 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449600922138595328",
  "geo" : { },
  "id_str" : "449601438864244736",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense awesome. curious about the finances of it...anything to share? Profitable?",
  "id" : 449601438864244736,
  "in_reply_to_status_id" : 449600922138595328,
  "created_at" : "2014-03-28 17:38:30 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449583543061331968",
  "geo" : { },
  "id_str" : "449583814197534720",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 so, when's the second round?",
  "id" : 449583814197534720,
  "in_reply_to_status_id" : 449583543061331968,
  "created_at" : "2014-03-28 16:28:28 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "indices" : [ 9, 19 ],
      "id_str" : "14807622",
      "id" : 14807622
    }, {
      "name" : "Lynn Kwon-Dzikiy",
      "screen_name" : "NForestKorean",
      "indices" : [ 20, 34 ],
      "id_str" : "148401790",
      "id" : 148401790
    }, {
      "name" : "Mercado | Revolution",
      "screen_name" : "MercadoWNY",
      "indices" : [ 35, 46 ],
      "id_str" : "2350861464",
      "id" : 2350861464
    }, {
      "name" : "Phil Dzikiy",
      "screen_name" : "phildzikiy",
      "indices" : [ 47, 58 ],
      "id_str" : "272230417",
      "id" : 272230417
    }, {
      "name" : "Elizabeth Callahan",
      "screen_name" : "Bflo_girl",
      "indices" : [ 59, 69 ],
      "id_str" : "264349132",
      "id" : 264349132
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 70, 84 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449526855218249728",
  "geo" : { },
  "id_str" : "449550894762188800",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending @chazadams @NForestKorean @MercadoWNY @phildzikiy @Bflo_girl @coworkbuffalo you better not be lying",
  "id" : 449550894762188800,
  "in_reply_to_status_id" : 449526855218249728,
  "created_at" : "2014-03-28 14:17:40 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Threes",
      "screen_name" : "ThreesGame",
      "indices" : [ 22, 33 ],
      "id_str" : "2278046648",
      "id" : 2278046648
    }, {
      "name" : "Asher Vollmer",
      "screen_name" : "AsherVo",
      "indices" : [ 69, 77 ],
      "id_str" : "16741826",
      "id" : 16741826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/evTkS3tXAZ",
      "expanded_url" : "http:\/\/asherv.com\/threes\/threemails\/",
      "display_url" : "asherv.com\/threes\/threema\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449368657471078400",
  "text" : "Lots of emails behind @ThreesGame: http:\/\/t.co\/evTkS3tXAZ Next game, @AsherVo you need some Basecamp love ;)",
  "id" : 449368657471078400,
  "created_at" : "2014-03-28 02:13:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Myers",
      "screen_name" : "rachelmyers",
      "indices" : [ 0, 12 ],
      "id_str" : "17204571",
      "id" : 17204571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449368167056293888",
  "geo" : { },
  "id_str" : "449368283385303040",
  "in_reply_to_user_id" : 17204571,
  "text" : "@rachelmyers I just gave up hope on that. Although procrastinating from preparing is fun too ;)",
  "id" : 449368283385303040,
  "in_reply_to_status_id" : 449368167056293888,
  "created_at" : "2014-03-28 02:12:02 +0000",
  "in_reply_to_screen_name" : "rachelmyers",
  "in_reply_to_user_id_str" : "17204571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Myers",
      "screen_name" : "rachelmyers",
      "indices" : [ 0, 12 ],
      "id_str" : "17204571",
      "id" : 17204571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/6dfmL1IhiH",
      "expanded_url" : "https:\/\/github.com\/n1k0\/SublimeHighlight",
      "display_url" : "github.com\/n1k0\/SublimeHi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449366754305646592",
  "geo" : { },
  "id_str" : "449367220049551360",
  "in_reply_to_user_id" : 17204571,
  "text" : "@rachelmyers Try this instead - https:\/\/t.co\/6dfmL1IhiH then Copy as RTF into keynote.",
  "id" : 449367220049551360,
  "in_reply_to_status_id" : 449366754305646592,
  "created_at" : "2014-03-28 02:07:48 +0000",
  "in_reply_to_screen_name" : "rachelmyers",
  "in_reply_to_user_id_str" : "17204571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan",
      "screen_name" : "alandipert",
      "indices" : [ 0, 11 ],
      "id_str" : "40270600",
      "id" : 40270600
    }, {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 12, 20 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449365363764236288",
  "geo" : { },
  "id_str" : "449366576542666753",
  "in_reply_to_user_id" : 40270600,
  "text" : "@alandipert @zedshaw seriously just freaked me out about this",
  "id" : 449366576542666753,
  "in_reply_to_status_id" : 449365363764236288,
  "created_at" : "2014-03-28 02:05:15 +0000",
  "in_reply_to_screen_name" : "alandipert",
  "in_reply_to_user_id_str" : "40270600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 8, 22 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449289744736714752",
  "text" : "I think @joshuaclayton and I just need to host a podcast where we try to pair on something and scream obscenities loudly for 30 minutes.",
  "id" : 449289744736714752,
  "created_at" : "2014-03-27 20:59:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FinalPhoenix",
      "screen_name" : "FinalPhoenix",
      "indices" : [ 0, 13 ],
      "id_str" : "15140704",
      "id" : 15140704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449262194610286592",
  "geo" : { },
  "id_str" : "449273787738234880",
  "in_reply_to_user_id" : 15140704,
  "text" : "@FinalPhoenix Some days I can.",
  "id" : 449273787738234880,
  "in_reply_to_status_id" : 449262194610286592,
  "created_at" : "2014-03-27 19:56:32 +0000",
  "in_reply_to_screen_name" : "FinalPhoenix",
  "in_reply_to_user_id_str" : "15140704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 0, 16 ],
      "id_str" : "63124269",
      "id" : 63124269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449272546702422016",
  "geo" : { },
  "id_str" : "449273738182160385",
  "in_reply_to_user_id" : 63124269,
  "text" : "@robertodecurnex What?",
  "id" : 449273738182160385,
  "in_reply_to_status_id" : 449272546702422016,
  "created_at" : "2014-03-27 19:56:20 +0000",
  "in_reply_to_screen_name" : "robertodecurnex",
  "in_reply_to_user_id_str" : "63124269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449229270569586688",
  "text" : "I can't even.",
  "id" : 449229270569586688,
  "created_at" : "2014-03-27 16:59:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449000183422939137",
  "geo" : { },
  "id_str" : "449000338192736256",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove ahh. Derp",
  "id" : 449000338192736256,
  "in_reply_to_status_id" : 449000183422939137,
  "created_at" : "2014-03-27 01:49:57 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448999562040975363",
  "geo" : { },
  "id_str" : "448999886634381312",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove on S3\/CF? Or from Rails?",
  "id" : 448999886634381312,
  "in_reply_to_status_id" : 448999562040975363,
  "created_at" : "2014-03-27 01:48:09 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/gnQVl5GAj8",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/14gWV2vqzwobcc\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/14gWV2vq\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "448939455903465472",
  "geo" : { },
  "id_str" : "448939830383091712",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej http:\/\/t.co\/gnQVl5GAj8",
  "id" : 448939830383091712,
  "in_reply_to_status_id" : 448939455903465472,
  "created_at" : "2014-03-26 21:49:31 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448933780934254592",
  "text" : "Anyone else have zero interest in learning the recent crop of frontend JS web frameworks? Is this when I become obsolete and boring?",
  "id" : 448933780934254592,
  "created_at" : "2014-03-26 21:25:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/ZiK5gy6a08",
      "expanded_url" : "http:\/\/aws.amazon.com\/s3\/pricing\/effective-april-2014\/",
      "display_url" : "aws.amazon.com\/s3\/pricing\/eff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448912789910736896",
  "text" : "More good news for http:\/\/t.co\/EmUiG90kOd AWS bills: http:\/\/t.co\/ZiK5gy6a08",
  "id" : 448912789910736896,
  "created_at" : "2014-03-26 20:02:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/J5MiTCpOJY",
      "expanded_url" : "http:\/\/reddit.com\/r\/donuts",
      "display_url" : "reddit.com\/r\/donuts"
    }, {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/G5qzYpE6b6",
      "expanded_url" : "http:\/\/reddit.com\/r\/doughnuts",
      "display_url" : "reddit.com\/r\/doughnuts"
    } ]
  },
  "in_reply_to_status_id_str" : "448910286058049537",
  "geo" : { },
  "id_str" : "448911046154014720",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 http:\/\/t.co\/J5MiTCpOJY or http:\/\/t.co\/G5qzYpE6b6 though?",
  "id" : 448911046154014720,
  "in_reply_to_status_id" : 448910286058049537,
  "created_at" : "2014-03-26 19:55:08 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 14, 26 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448887248571088896",
  "geo" : { },
  "id_str" : "448887533217128448",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @AqueousBand Time to put in $5k then!",
  "id" : 448887533217128448,
  "in_reply_to_status_id" : 448887248571088896,
  "created_at" : "2014-03-26 18:21:42 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 0, 10 ],
      "id_str" : "21003240",
      "id" : 21003240
    }, {
      "name" : "Betty Crockski ",
      "screen_name" : "BettyCrockski",
      "indices" : [ 11, 25 ],
      "id_str" : "1486650266",
      "id" : 1486650266
    }, {
      "name" : "City Dining Cards",
      "screen_name" : "citydiningcards",
      "indices" : [ 26, 42 ],
      "id_str" : "366120789",
      "id" : 366120789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448885568701612032",
  "geo" : { },
  "id_str" : "448886454643474432",
  "in_reply_to_user_id" : 21003240,
  "text" : "@BlockClub @BettyCrockski @citydiningcards Still amazed this hasn't gotten a C&amp;D from General Mills yet.",
  "id" : 448886454643474432,
  "in_reply_to_status_id" : 448885568701612032,
  "created_at" : "2014-03-26 18:17:25 +0000",
  "in_reply_to_screen_name" : "BlockClub",
  "in_reply_to_user_id_str" : "21003240",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "indices" : [ 3, 14 ],
      "id_str" : "22084427",
      "id" : 22084427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448867812132388865",
  "text" : "RT @robdelaney: First thing I saw in Buffalo was a billboard advertising a place where you can play tic tac toe with \"a live chicken.\" I'm \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448833006937964544",
    "text" : "First thing I saw in Buffalo was a billboard advertising a place where you can play tic tac toe with \"a live chicken.\" I'm never leaving.",
    "id" : 448833006937964544,
    "created_at" : "2014-03-26 14:45:02 +0000",
    "user" : {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "protected" : false,
      "id_str" : "22084427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552880428915257344\/1NN2mDeP_normal.png",
      "id" : 22084427,
      "verified" : true
    }
  },
  "id" : 448867812132388865,
  "created_at" : "2014-03-26 17:03:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/rqxYpFeBFk",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3729-basecamp-network-attack-postmortem",
      "display_url" : "signalvnoise.com\/posts\/3729-bas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448837730563153921",
  "text" : "RT @37signals: Basecamp network attack postmortem: https:\/\/t.co\/rqxYpFeBFk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/rqxYpFeBFk",
        "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3729-basecamp-network-attack-postmortem",
        "display_url" : "signalvnoise.com\/posts\/3729-bas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448837430695981056",
    "text" : "Basecamp network attack postmortem: https:\/\/t.co\/rqxYpFeBFk",
    "id" : 448837430695981056,
    "created_at" : "2014-03-26 15:02:37 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 448837730563153921,
  "created_at" : "2014-03-26 15:03:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448669558925455360",
  "geo" : { },
  "id_str" : "448670149898276864",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone time to switch careers",
  "id" : 448670149898276864,
  "in_reply_to_status_id" : 448669558925455360,
  "created_at" : "2014-03-26 03:57:54 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Quirion",
      "screen_name" : "mquirion",
      "indices" : [ 0, 9 ],
      "id_str" : "14187984",
      "id" : 14187984
    }, {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 10, 18 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448626301554135040",
  "geo" : { },
  "id_str" : "448626577178251264",
  "in_reply_to_user_id" : 14187984,
  "text" : "@mquirion @kkuchta did you guys miss the \"cynical\" part?",
  "id" : 448626577178251264,
  "in_reply_to_status_id" : 448626301554135040,
  "created_at" : "2014-03-26 01:04:45 +0000",
  "in_reply_to_screen_name" : "mquirion",
  "in_reply_to_user_id_str" : "14187984",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448625630553190401",
  "text" : "And yes those are TOTALLY RELATED!",
  "id" : 448625630553190401,
  "created_at" : "2014-03-26 01:01:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448625591281930240",
  "text" : "Maybe just cynical, but I'd love these to be wrong: I don't expect the Bills to stay in Buffalo, and Oculus was purely a talent acquisition.",
  "id" : 448625591281930240,
  "created_at" : "2014-03-26 01:00:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448623996804681728",
  "text" : "To everyone complaining about Oculus...have you actually used one?",
  "id" : 448623996804681728,
  "created_at" : "2014-03-26 00:54:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448319783549689856",
  "geo" : { },
  "id_str" : "448506882752536576",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis when are we writing Basecamphack \/ Roguecamp ?!",
  "id" : 448506882752536576,
  "in_reply_to_status_id" : 448319783549689856,
  "created_at" : "2014-03-25 17:09:08 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 46, 58 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Vl0dEPmfjB",
      "expanded_url" : "http:\/\/kck.st\/1ix9pb8",
      "display_url" : "kck.st\/1ix9pb8"
    } ]
  },
  "geo" : { },
  "id_str" : "448502339284893696",
  "text" : "I just backed Aqueous - New Studio Album!! on @Kickstarter http:\/\/t.co\/Vl0dEPmfjB",
  "id" : 448502339284893696,
  "created_at" : "2014-03-25 16:51:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448477506006712320",
  "text" : "What running a coworking space is like: having dreams about configuring underperforming wifi networks.",
  "id" : 448477506006712320,
  "created_at" : "2014-03-25 15:12:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448287990365040640",
  "text" : "Wrote 260 lines of code to prepare for a talk. I don't think I'm doing this right.",
  "id" : 448287990365040640,
  "created_at" : "2014-03-25 02:39:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 0, 7 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448269102075768832",
  "geo" : { },
  "id_str" : "448271399929380864",
  "in_reply_to_user_id" : 9526722,
  "text" : "@Bantik I am both appalled and pleased this actually is valid Ruby.",
  "id" : 448271399929380864,
  "in_reply_to_status_id" : 448269102075768832,
  "created_at" : "2014-03-25 01:33:24 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/IHGodOAdP4",
      "expanded_url" : "http:\/\/apple.stackexchange.com\/questions\/106841\/keynote-6-0-how-to-add-animated-gif",
      "display_url" : "apple.stackexchange.com\/questions\/1068\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448270443854585856",
  "text" : "This is how fucked the new Keynote is: To insert and play a GIF, rename to .MOV: http:\/\/t.co\/IHGodOAdP4",
  "id" : 448270443854585856,
  "created_at" : "2014-03-25 01:29:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448267603518042112",
  "geo" : { },
  "id_str" : "448268456719167488",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat if you hit the wufoo form, we've got it!",
  "id" : 448268456719167488,
  "in_reply_to_status_id" : 448267603518042112,
  "created_at" : "2014-03-25 01:21:43 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448268348300619776",
  "text" : "Just realized Ruby and Toy Story are the same age. Coincidence?",
  "id" : 448268348300619776,
  "created_at" : "2014-03-25 01:21:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David duChemin",
      "screen_name" : "david_duChemin",
      "indices" : [ 0, 15 ],
      "id_str" : "19805003",
      "id" : 19805003
    }, {
      "name" : "Mike Clark",
      "screen_name" : "clarkware",
      "indices" : [ 16, 26 ],
      "id_str" : "9941002",
      "id" : 9941002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/LchpnpIAR0",
      "expanded_url" : "http:\/\/youtu.be\/waEeJJVZ5P8?t=1m10s",
      "display_url" : "youtu.be\/waEeJJVZ5P8?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "448262817159057408",
  "geo" : { },
  "id_str" : "448264714955390976",
  "in_reply_to_user_id" : 19805003,
  "text" : "@david_duChemin @clarkware same, and part of why I love this unboxing video: http:\/\/t.co\/LchpnpIAR0",
  "id" : 448264714955390976,
  "in_reply_to_status_id" : 448262817159057408,
  "created_at" : "2014-03-25 01:06:51 +0000",
  "in_reply_to_screen_name" : "david_duChemin",
  "in_reply_to_user_id_str" : "19805003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448261655403577344",
  "geo" : { },
  "id_str" : "448262908938444801",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald very Mondrian of you.",
  "id" : 448262908938444801,
  "in_reply_to_status_id" : 448261655403577344,
  "created_at" : "2014-03-25 00:59:40 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 10, 17 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448254816314458112",
  "geo" : { },
  "id_str" : "448259175731052544",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @will_j 4 seasons exist for a reason",
  "id" : 448259175731052544,
  "in_reply_to_status_id" : 448254816314458112,
  "created_at" : "2014-03-25 00:44:50 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/448248863694938112\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/S9Kh2mo6Vd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjh_93QCYAAm1le.png",
      "id_str" : "448248863703326720",
      "id" : 448248863703326720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjh_93QCYAAm1le.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 291
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 291
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 292
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 291
      } ],
      "display_url" : "pic.twitter.com\/S9Kh2mo6Vd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448248863694938112",
  "text" : "Oh cool, another counter that I can't figure out how to clear on Twitter. http:\/\/t.co\/S9Kh2mo6Vd",
  "id" : 448248863694938112,
  "created_at" : "2014-03-25 00:03:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448190258925277184",
  "geo" : { },
  "id_str" : "448190954273787904",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek Exactly!",
  "id" : 448190954273787904,
  "in_reply_to_status_id" : 448190258925277184,
  "created_at" : "2014-03-24 20:13:45 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/OVLyE3KBpp",
      "expanded_url" : "http:\/\/www.theatlantic.com\/features\/archive\/2014\/03\/hey-parents-leave-those-kids-alone\/358631\/",
      "display_url" : "theatlantic.com\/features\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448183634738950144",
  "text" : "Buffalo needs a playground like this: http:\/\/t.co\/OVLyE3KBpp",
  "id" : 448183634738950144,
  "created_at" : "2014-03-24 19:44:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448161212589559808",
  "geo" : { },
  "id_str" : "448161446577180674",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 White Album or GTFO",
  "id" : 448161446577180674,
  "in_reply_to_status_id" : 448161212589559808,
  "created_at" : "2014-03-24 18:16:29 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    }, {
      "name" : "Matt Jacobs",
      "screen_name" : "capndesign",
      "indices" : [ 9, 20 ],
      "id_str" : "5504",
      "id" : 5504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/QHKCnxDdax",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/11\/23\/sync-and-edit-files-on-two-iphones\/",
      "display_url" : "quaran.to\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "448151297762414592",
  "geo" : { },
  "id_str" : "448154352268500992",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer @capndesign We ended up with this setup: http:\/\/t.co\/QHKCnxDdax",
  "id" : 448154352268500992,
  "in_reply_to_status_id" : 448151297762414592,
  "created_at" : "2014-03-24 17:48:18 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bostock",
      "screen_name" : "mbostock",
      "indices" : [ 0, 9 ],
      "id_str" : "43593",
      "id" : 43593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448147356957949952",
  "geo" : { },
  "id_str" : "448149655147122688",
  "in_reply_to_user_id" : 43593,
  "text" : "@mbostock how about lakes? :)",
  "id" : 448149655147122688,
  "in_reply_to_status_id" : 448147356957949952,
  "created_at" : "2014-03-24 17:29:38 +0000",
  "in_reply_to_screen_name" : "mbostock",
  "in_reply_to_user_id_str" : "43593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448143562195365888",
  "text" : "RT @themcgruff: Thanks for everyone who emailed and called to offer support and advice. The ops\/sec community is great.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448143395090104320",
    "text" : "Thanks for everyone who emailed and called to offer support and advice. The ops\/sec community is great.",
    "id" : 448143395090104320,
    "created_at" : "2014-03-24 17:04:46 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 448143562195365888,
  "created_at" : "2014-03-24 17:05:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Tom Ward",
      "screen_name" : "tomafro",
      "indices" : [ 8, 16 ],
      "id_str" : "806464",
      "id" : 806464
    }, {
      "name" : "Jeffrey Hardy",
      "screen_name" : "packagethief",
      "indices" : [ 17, 30 ],
      "id_str" : "12089482",
      "id" : 12089482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448083693480189953",
  "geo" : { },
  "id_str" : "448119930794176513",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @tomafro @packagethief I can explain next week.",
  "id" : 448119930794176513,
  "in_reply_to_status_id" : 448083693480189953,
  "created_at" : "2014-03-24 15:31:31 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/b2Tkc4Gt1F",
      "expanded_url" : "https:\/\/gist.github.com\/dhh\/9741477",
      "display_url" : "gist.github.com\/dhh\/9741477"
    } ]
  },
  "geo" : { },
  "id_str" : "448114224523255809",
  "text" : "RT @37signals: We will update you during this attack no later than every 30 minutes. Substantial new findings will be added to https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/b2Tkc4Gt1F",
        "expanded_url" : "https:\/\/gist.github.com\/dhh\/9741477",
        "display_url" : "gist.github.com\/dhh\/9741477"
      } ]
    },
    "geo" : { },
    "id_str" : "448113935292841984",
    "text" : "We will update you during this attack no later than every 30 minutes. Substantial new findings will be added to https:\/\/t.co\/b2Tkc4Gt1F.",
    "id" : 448113935292841984,
    "created_at" : "2014-03-24 15:07:42 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 448114224523255809,
  "created_at" : "2014-03-24 15:08:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/b2Tkc4Gt1F",
      "expanded_url" : "https:\/\/gist.github.com\/dhh\/9741477",
      "display_url" : "gist.github.com\/dhh\/9741477"
    } ]
  },
  "geo" : { },
  "id_str" : "448108651325435904",
  "text" : "RT @37signals: Basecamp is under network attack by criminals trying to blackmail us. What we know so far: https:\/\/t.co\/b2Tkc4Gt1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/b2Tkc4Gt1F",
        "expanded_url" : "https:\/\/gist.github.com\/dhh\/9741477",
        "display_url" : "gist.github.com\/dhh\/9741477"
      } ]
    },
    "geo" : { },
    "id_str" : "448108509285330944",
    "text" : "Basecamp is under network attack by criminals trying to blackmail us. What we know so far: https:\/\/t.co\/b2Tkc4Gt1F",
    "id" : 448108509285330944,
    "created_at" : "2014-03-24 14:46:08 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 448108651325435904,
  "created_at" : "2014-03-24 14:46:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/AgwPszkCaI",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Denial-of-service_attack",
      "display_url" : "en.wikipedia.org\/wiki\/Denial-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448107385588965376",
  "text" : "RT @37signals: Apologies for any slowness in our apps today, but we're experiencing a DDoS attack. You can read up on DDoS here: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dash.37signals.com\" rel=\"nofollow\"\u003E37signals\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/AgwPszkCaI",
        "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Denial-of-service_attack",
        "display_url" : "en.wikipedia.org\/wiki\/Denial-of\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448106627896713216",
    "text" : "Apologies for any slowness in our apps today, but we're experiencing a DDoS attack. You can read up on DDoS here: http:\/\/t.co\/AgwPszkCaI",
    "id" : 448106627896713216,
    "created_at" : "2014-03-24 14:38:40 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 448107385588965376,
  "created_at" : "2014-03-24 14:41:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448106427396407297",
  "text" : "Fuck mondays.",
  "id" : 448106427396407297,
  "created_at" : "2014-03-24 14:37:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Tom Ward",
      "screen_name" : "tomafro",
      "indices" : [ 8, 16 ],
      "id_str" : "806464",
      "id" : 806464
    }, {
      "name" : "Jeffrey Hardy",
      "screen_name" : "packagethief",
      "indices" : [ 48, 61 ],
      "id_str" : "12089482",
      "id" : 12089482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448082129000615936",
  "geo" : { },
  "id_str" : "448083543478898688",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @tomafro after the muffin incident with @packagethief I prefer the train\u2026.preferably on tracks",
  "id" : 448083543478898688,
  "in_reply_to_status_id" : 448082129000615936,
  "created_at" : "2014-03-24 13:06:56 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/5mRSpIji3G",
      "expanded_url" : "https:\/\/twitter.com\/mccanner\/status\/448061827671277568",
      "display_url" : "twitter.com\/mccanner\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448079913040371713",
  "text" : "So about going to Chicago next week\u2026 https:\/\/t.co\/5mRSpIji3G",
  "id" : 448079913040371713,
  "created_at" : "2014-03-24 12:52:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin mccann",
      "screen_name" : "mccanner",
      "indices" : [ 3, 12 ],
      "id_str" : "42313640",
      "id" : 42313640
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mccanner\/status\/448061827671277568\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/4shGl4M8fy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjfV27wCQAAy2WO.jpg",
      "id_str" : "448061827675471872",
      "id" : 448061827675471872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjfV27wCQAAy2WO.jpg",
      "sizes" : [ {
        "h" : 276,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/4shGl4M8fy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/UoEUi0KV88",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2014\/mar\/24\/commuter-train-derails-chicago-ohare-international-airport?CMP=twt_gu",
      "display_url" : "theguardian.com\/world\/2014\/mar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448079554318323712",
  "text" : "RT @mccanner: That train that derailed at O'Hare went *up the escalator* http:\/\/t.co\/UoEUi0KV88 \u2026 http:\/\/t.co\/4shGl4M8fy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mccanner\/status\/448061827671277568\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/4shGl4M8fy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjfV27wCQAAy2WO.jpg",
        "id_str" : "448061827675471872",
        "id" : 448061827675471872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjfV27wCQAAy2WO.jpg",
        "sizes" : [ {
          "h" : 276,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/4shGl4M8fy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/UoEUi0KV88",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2014\/mar\/24\/commuter-train-derails-chicago-ohare-international-airport?CMP=twt_gu",
        "display_url" : "theguardian.com\/world\/2014\/mar\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "448061718791348224",
    "geo" : { },
    "id_str" : "448061827671277568",
    "in_reply_to_user_id" : 42313640,
    "text" : "That train that derailed at O'Hare went *up the escalator* http:\/\/t.co\/UoEUi0KV88 \u2026 http:\/\/t.co\/4shGl4M8fy",
    "id" : 448061827671277568,
    "in_reply_to_status_id" : 448061718791348224,
    "created_at" : "2014-03-24 11:40:39 +0000",
    "in_reply_to_screen_name" : "mccanner",
    "in_reply_to_user_id_str" : "42313640",
    "user" : {
      "name" : "erin mccann",
      "screen_name" : "mccanner",
      "protected" : false,
      "id_str" : "42313640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548615517133864960\/KrLq7Kkf_normal.jpeg",
      "id" : 42313640,
      "verified" : true
    }
  },
  "id" : 448079554318323712,
  "created_at" : "2014-03-24 12:51:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/oMclCVhkYP",
      "expanded_url" : "http:\/\/www.newrepublic.com\/article\/117088\/silicons-valleys-brutal-ageism",
      "display_url" : "newrepublic.com\/article\/117088\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447958467282628609",
  "text" : "I am consistently ashamed of and disgusted by this \u201Cindustry\u201D: http:\/\/t.co\/oMclCVhkYP",
  "id" : 447958467282628609,
  "created_at" : "2014-03-24 04:49:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/JWPHzOeBBd",
      "expanded_url" : "http:\/\/www.theverge.com\/2014\/3\/23\/5539260\/4chan-user-devises-a-way-to-bank-through-gamestop",
      "display_url" : "theverge.com\/2014\/3\/23\/5539\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447845309805101056",
  "text" : "Better than Bitcoin: http:\/\/t.co\/JWPHzOeBBd",
  "id" : 447845309805101056,
  "created_at" : "2014-03-23 21:20:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/mAmgJvPnBI",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/sf\/national\/2014\/03\/22\/sinkhole-of-bureaucracy\/",
      "display_url" : "washingtonpost.com\/sf\/national\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447822083511156736",
  "text" : "Kafkaesque mine in rural Pittsburgh where 600 people process gov't records...by hand. http:\/\/t.co\/mAmgJvPnBI",
  "id" : 447822083511156736,
  "created_at" : "2014-03-23 19:47:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 0, 9 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 10, 20 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447490185710690304",
  "geo" : { },
  "id_str" : "447514536829280256",
  "in_reply_to_user_id" : 14164724,
  "text" : "@sarahmei @aquaranto yep! First big trip.",
  "id" : 447514536829280256,
  "in_reply_to_status_id" : 447490185710690304,
  "created_at" : "2014-03-22 23:25:54 +0000",
  "in_reply_to_screen_name" : "sarahmei",
  "in_reply_to_user_id_str" : "14164724",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Co.Exist",
      "screen_name" : "FastCoExist",
      "indices" : [ 3, 15 ],
      "id_str" : "280716675",
      "id" : 280716675
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FastCoExist\/status\/447467678056599552\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/3uIoFxiRcj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjW5e3aIMAACxpq.jpg",
      "id_str" : "447467677913985024",
      "id" : 447467677913985024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjW5e3aIMAACxpq.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3uIoFxiRcj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/AnSdrh7YJI",
      "expanded_url" : "http:\/\/f-st.co\/WDxoJr0",
      "display_url" : "f-st.co\/WDxoJr0"
    } ]
  },
  "geo" : { },
  "id_str" : "447476692458938368",
  "text" : "RT @FastCoExist: Can these eerie, abandoned grain silos help save Buffalo? http:\/\/t.co\/AnSdrh7YJI http:\/\/t.co\/3uIoFxiRcj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FastCoExist\/status\/447467678056599552\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/3uIoFxiRcj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjW5e3aIMAACxpq.jpg",
        "id_str" : "447467677913985024",
        "id" : 447467677913985024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjW5e3aIMAACxpq.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3uIoFxiRcj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/AnSdrh7YJI",
        "expanded_url" : "http:\/\/f-st.co\/WDxoJr0",
        "display_url" : "f-st.co\/WDxoJr0"
      } ]
    },
    "geo" : { },
    "id_str" : "447467678056599552",
    "text" : "Can these eerie, abandoned grain silos help save Buffalo? http:\/\/t.co\/AnSdrh7YJI http:\/\/t.co\/3uIoFxiRcj",
    "id" : 447467678056599552,
    "created_at" : "2014-03-22 20:19:42 +0000",
    "user" : {
      "name" : "Co.Exist",
      "screen_name" : "FastCoExist",
      "protected" : false,
      "id_str" : "280716675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482524726053445632\/fLzR3gA__normal.png",
      "id" : 280716675,
      "verified" : true
    }
  },
  "id" : 447476692458938368,
  "created_at" : "2014-03-22 20:55:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 0, 8 ],
      "id_str" : "15048829",
      "id" : 15048829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447425132932239361",
  "geo" : { },
  "id_str" : "447470783065899009",
  "in_reply_to_user_id" : 15048829,
  "text" : "@greggyb congrats! If you\u2019re going to Railsconf you can meet our little guy. Arrived around 1.year.ago your date.",
  "id" : 447470783065899009,
  "in_reply_to_status_id" : 447425132932239361,
  "created_at" : "2014-03-22 20:32:02 +0000",
  "in_reply_to_screen_name" : "greggyb",
  "in_reply_to_user_id_str" : "15048829",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 9, 15 ],
      "id_str" : "15453",
      "id" : 15453
    }, {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "indices" : [ 16, 20 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447172020246024192",
  "geo" : { },
  "id_str" : "447175744117280768",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @seldo @izs thanks! Maintaining isn\u2019t easy.",
  "id" : 447175744117280768,
  "in_reply_to_status_id" : 447172020246024192,
  "created_at" : "2014-03-22 00:59:40 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/3E9KjluueQ",
      "expanded_url" : "http:\/\/priceonomics.com\/the-rise-and-fall-of-professional-bowling\/",
      "display_url" : "priceonomics.com\/the-rise-and-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447112771990073344",
  "text" : "My grandparents met in a bowling alley. Fascinating article on the history of the sport: http:\/\/t.co\/3E9KjluueQ",
  "id" : 447112771990073344,
  "created_at" : "2014-03-21 20:49:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 0, 10 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446396871632621569",
  "geo" : { },
  "id_str" : "447085504597479424",
  "in_reply_to_user_id" : 18496432,
  "text" : "@nrrrdcore What about other cities? :)",
  "id" : 447085504597479424,
  "in_reply_to_status_id" : 446396871632621569,
  "created_at" : "2014-03-21 19:01:05 +0000",
  "in_reply_to_screen_name" : "nrrrdcore",
  "in_reply_to_user_id_str" : "18496432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447044186727268353",
  "geo" : { },
  "id_str" : "447045181406072832",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella yeah, they've been playing random GBA games for the last week or so.",
  "id" : 447045181406072832,
  "in_reply_to_status_id" : 447044186727268353,
  "created_at" : "2014-03-21 16:20:51 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/thXUqOroes",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    }, {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/0lYnhtgUcw",
      "expanded_url" : "http:\/\/i.imgur.com\/pjKNp.gif",
      "display_url" : "i.imgur.com\/pjKNp.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "447043886465032193",
  "text" : "Less than 9 hours until the new http:\/\/t.co\/thXUqOroes starts! http:\/\/t.co\/0lYnhtgUcw",
  "id" : 447043886465032193,
  "created_at" : "2014-03-21 16:15:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447034548346707969",
  "geo" : { },
  "id_str" : "447034864110301185",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt Not with 40 people!",
  "id" : 447034864110301185,
  "in_reply_to_status_id" : 447034548346707969,
  "created_at" : "2014-03-21 15:39:51 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/AP6LPForbY",
      "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3457-its-not-a-meetup",
      "display_url" : "signalvnoise.com\/posts\/3457-its\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446989729192374273",
  "text" : "One more week until the first official Basecamp meetup. Working remote is great, but I miss these people. http:\/\/t.co\/AP6LPForbY",
  "id" : 446989729192374273,
  "created_at" : "2014-03-21 12:40:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/NAAt6lRdGp",
      "expanded_url" : "https:\/\/itun.es\/us\/0iCVG",
      "display_url" : "itun.es\/us\/0iCVG"
    } ]
  },
  "geo" : { },
  "id_str" : "446983559366967296",
  "text" : "Found the worse possible ringtone ever: Hey! Listen! - The Legend of Zelda Ringtone by Video Box Sounds https:\/\/t.co\/NAAt6lRdGp",
  "id" : 446983559366967296,
  "created_at" : "2014-03-21 12:15:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/446982023501332480\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/TeNpxMn3JD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjP_yDIIQAAWmkx.jpg",
      "id_str" : "446982023337754624",
      "id" : 446982023337754624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjP_yDIIQAAWmkx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TeNpxMn3JD"
    } ],
    "hashtags" : [ {
      "text" : "ShipShapeTap",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/icuUjB0D5E",
      "expanded_url" : "http:\/\/shipshapetap.com\/",
      "display_url" : "shipshapetap.com"
    } ]
  },
  "geo" : { },
  "id_str" : "446982023501332480",
  "text" : "I just scored 18 in #ShipShapeTap - Can you do better? http:\/\/t.co\/icuUjB0D5E http:\/\/t.co\/TeNpxMn3JD",
  "id" : 446982023501332480,
  "created_at" : "2014-03-21 12:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446714000358014977",
  "geo" : { },
  "id_str" : "446714135854592000",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer aww yeah. Reorder and squash!",
  "id" : 446714135854592000,
  "in_reply_to_status_id" : 446714000358014977,
  "created_at" : "2014-03-20 18:25:24 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "indices" : [ 14, 19 ],
      "id_str" : "14184324",
      "id" : 14184324
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 57, 71 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 87, 94 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 95, 110 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 111, 117 ],
      "id_str" : "34287352",
      "id" : 34287352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446662592161804288",
  "text" : "Going to toss @mwrc's livestream up on the Chromecast at @coworkbuffalo. Who's in? \/cc @zobar2 @1ofyourmeteors @byllc",
  "id" : 446662592161804288,
  "created_at" : "2014-03-20 15:00:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rich rines",
      "screen_name" : "richrines",
      "indices" : [ 0, 10 ],
      "id_str" : "123329223",
      "id" : 123329223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446411763399925760",
  "geo" : { },
  "id_str" : "446652480294645760",
  "in_reply_to_user_id" : 123329223,
  "text" : "@richrines it's great, but it's no excuse to not understand the ecosystem. Our latest work is vanilla so we can really dig into the platform",
  "id" : 446652480294645760,
  "in_reply_to_status_id" : 446411763399925760,
  "created_at" : "2014-03-20 14:20:24 +0000",
  "in_reply_to_screen_name" : "richrines",
  "in_reply_to_user_id_str" : "123329223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yes, even Travis",
      "screen_name" : "travis",
      "indices" : [ 3, 10 ],
      "id_str" : "651963",
      "id" : 651963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/TGFcI156k9",
      "expanded_url" : "https:\/\/twitter.com\/settings\/account",
      "display_url" : "twitter.com\/settings\/accou\u2026"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/QqJXaqU1dR",
      "expanded_url" : "http:\/\/mlkshk.com\/p\/XP9E",
      "display_url" : "mlkshk.com\/p\/XP9E"
    } ]
  },
  "geo" : { },
  "id_str" : "446643713411145728",
  "text" : "RT @travis: PSA: you should go here: https:\/\/t.co\/TGFcI156k9 and request your archive. \n\nWhen you're suspended, http:\/\/t.co\/QqJXaqU1dR no d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/TGFcI156k9",
        "expanded_url" : "https:\/\/twitter.com\/settings\/account",
        "display_url" : "twitter.com\/settings\/accou\u2026"
      }, {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/QqJXaqU1dR",
        "expanded_url" : "http:\/\/mlkshk.com\/p\/XP9E",
        "display_url" : "mlkshk.com\/p\/XP9E"
      } ]
    },
    "geo" : { },
    "id_str" : "446501972120567809",
    "text" : "PSA: you should go here: https:\/\/t.co\/TGFcI156k9 and request your archive. \n\nWhen you're suspended, http:\/\/t.co\/QqJXaqU1dR no dice.",
    "id" : 446501972120567809,
    "created_at" : "2014-03-20 04:22:20 +0000",
    "user" : {
      "name" : "yes, even Travis",
      "screen_name" : "travis",
      "protected" : false,
      "id_str" : "651963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517674288392835073\/IfXj1jzk_normal.png",
      "id" : 651963,
      "verified" : false
    }
  },
  "id" : 446643713411145728,
  "created_at" : "2014-03-20 13:45:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "indices" : [ 3, 8 ],
      "id_str" : "14184324",
      "id" : 14184324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/vA7BncW5mz",
      "expanded_url" : "http:\/\/mtnwestrubyconf.org\/live",
      "display_url" : "mtnwestrubyconf.org\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "446391684096876544",
  "text" : "RT @mwrc: Unable to make it to MWRC this year? Did you know we are live streaming starting tomorrow? Tell your friends!\nhttp:\/\/t.co\/vA7BncW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/vA7BncW5mz",
        "expanded_url" : "http:\/\/mtnwestrubyconf.org\/live",
        "display_url" : "mtnwestrubyconf.org\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "446391073523240960",
    "text" : "Unable to make it to MWRC this year? Did you know we are live streaming starting tomorrow? Tell your friends!\nhttp:\/\/t.co\/vA7BncW5mz",
    "id" : 446391073523240960,
    "created_at" : "2014-03-19 21:01:40 +0000",
    "user" : {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "protected" : false,
      "id_str" : "14184324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000721666197\/a880cf857c53daf9f0abc1b4e66ca55f_normal.png",
      "id" : 14184324,
      "verified" : false
    }
  },
  "id" : 446391684096876544,
  "created_at" : "2014-03-19 21:04:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446377850610794497",
  "geo" : { },
  "id_str" : "446382208803414017",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren just wait until .sexy takes off",
  "id" : 446382208803414017,
  "in_reply_to_status_id" : 446377850610794497,
  "created_at" : "2014-03-19 20:26:26 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/oPfvSx857P",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1HTTRVD3cRo",
      "display_url" : "youtube.com\/watch?v=1HTTRV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446309576745312257",
  "text" : "Current status: http:\/\/t.co\/oPfvSx857P",
  "id" : 446309576745312257,
  "created_at" : "2014-03-19 15:37:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/VQuM0a0Sz5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ZPoqNeR3_UA",
      "display_url" : "youtube.com\/watch?v=ZPoqNe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "446309008559730688",
  "geo" : { },
  "id_str" : "446309251762249729",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 next up, play in your house 24\/7: http:\/\/t.co\/VQuM0a0Sz5",
  "id" : 446309251762249729,
  "in_reply_to_status_id" : 446309008559730688,
  "created_at" : "2014-03-19 15:36:32 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446083994145157120",
  "geo" : { },
  "id_str" : "446087187398811649",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting everything I know is a lie",
  "id" : 446087187398811649,
  "in_reply_to_status_id" : 446083994145157120,
  "created_at" : "2014-03-19 00:54:08 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Scott",
      "screen_name" : "textfiles",
      "indices" : [ 0, 10 ],
      "id_str" : "1465481",
      "id" : 1465481
    }, {
      "name" : "Erin",
      "screen_name" : "embrown",
      "indices" : [ 11, 19 ],
      "id_str" : "425253989",
      "id" : 425253989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446051780422414336",
  "geo" : { },
  "id_str" : "446053307748847617",
  "in_reply_to_user_id" : 1465481,
  "text" : "@textfiles @embrown thanks!!",
  "id" : 446053307748847617,
  "in_reply_to_status_id" : 446051780422414336,
  "created_at" : "2014-03-18 22:39:30 +0000",
  "in_reply_to_screen_name" : "textfiles",
  "in_reply_to_user_id_str" : "1465481",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 15, 26 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/jvjhiKXN3U",
      "expanded_url" : "http:\/\/onestepback.org",
      "display_url" : "onestepback.org"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/aidltjO7Ah",
      "expanded_url" : "https:\/\/twitter.com\/textfiles\/status\/446051780422414336",
      "display_url" : "twitter.com\/textfiles\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446052957638115328",
  "text" : "Elated to hear @jimweirich's http:\/\/t.co\/jvjhiKXN3U is going to be archived in the Wayback Machine soon: https:\/\/t.co\/aidltjO7Ah",
  "id" : 446052957638115328,
  "created_at" : "2014-03-18 22:38:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Scott",
      "screen_name" : "textfiles",
      "indices" : [ 3, 13 ],
      "id_str" : "1465481",
      "id" : 1465481
    }, {
      "name" : "Erin",
      "screen_name" : "embrown",
      "indices" : [ 15, 23 ],
      "id_str" : "425253989",
      "id" : 425253989
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 24, 30 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446052467042967553",
  "text" : "RT @textfiles: @embrown @qrush I set an archiveteam backup of it for the Wayback Machine immediately. It'll be in the Wayback within a day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erin",
        "screen_name" : "embrown",
        "indices" : [ 0, 8 ],
        "id_str" : "425253989",
        "id" : 425253989
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 9, 15 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "446045284477702145",
    "geo" : { },
    "id_str" : "446051780422414336",
    "in_reply_to_user_id" : 425253989,
    "text" : "@embrown @qrush I set an archiveteam backup of it for the Wayback Machine immediately. It'll be in the Wayback within a day.",
    "id" : 446051780422414336,
    "in_reply_to_status_id" : 446045284477702145,
    "created_at" : "2014-03-18 22:33:26 +0000",
    "in_reply_to_screen_name" : "embrown",
    "in_reply_to_user_id_str" : "425253989",
    "user" : {
      "name" : "Jason Scott",
      "screen_name" : "textfiles",
      "protected" : false,
      "id_str" : "1465481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000611389472\/eabaeb13befe96decf6785d0aa4cbaa1_normal.png",
      "id" : 1465481,
      "verified" : false
    }
  },
  "id" : 446052467042967553,
  "created_at" : "2014-03-18 22:36:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/W5WKtqITja",
      "expanded_url" : "http:\/\/onestepback.org\/index.cgi",
      "display_url" : "onestepback.org\/index.cgi"
    } ]
  },
  "geo" : { },
  "id_str" : "446045101597290496",
  "text" : "Has anyone archived http:\/\/t.co\/W5WKtqITja yet?",
  "id" : 446045101597290496,
  "created_at" : "2014-03-18 22:06:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446020134461640704",
  "text" : "OH \"There needs to be a Twitch Plays Live Chat Support\"",
  "id" : 446020134461640704,
  "created_at" : "2014-03-18 20:27:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/vwpzViwRMV",
      "expanded_url" : "http:\/\/developer.android.com\/wear\/index.html",
      "display_url" : "developer.android.com\/wear\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "445957590736855040",
  "text" : "I can hear @kevinpurdy squealing from here: http:\/\/t.co\/vwpzViwRMV",
  "id" : 445957590736855040,
  "created_at" : "2014-03-18 16:19:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445706494613278720",
  "geo" : { },
  "id_str" : "445709988724359168",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain gem.version = \u201C100.0\u201D \uD83D\uDE2D",
  "id" : 445709988724359168,
  "in_reply_to_status_id" : 445706494613278720,
  "created_at" : "2014-03-17 23:55:16 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445694760204787712",
  "text" : "Set up the old DS for Y. Friend code: 3153-5434-5711",
  "id" : 445694760204787712,
  "created_at" : "2014-03-17 22:54:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445685044720328706",
  "text" : "Refactoring tests and blasting Phish. Just an average Monday.",
  "id" : 445685044720328706,
  "created_at" : "2014-03-17 22:16:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Suttles",
      "screen_name" : "jlsuttles",
      "indices" : [ 0, 10 ],
      "id_str" : "21170138",
      "id" : 21170138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445642435603861504",
  "geo" : { },
  "id_str" : "445673506957582337",
  "in_reply_to_user_id" : 21170138,
  "text" : "@jlsuttles nice!",
  "id" : 445673506957582337,
  "in_reply_to_status_id" : 445642435603861504,
  "created_at" : "2014-03-17 21:30:18 +0000",
  "in_reply_to_screen_name" : "jlsuttles",
  "in_reply_to_user_id_str" : "21170138",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hilkert",
      "screen_name" : "brandonhilkert",
      "indices" : [ 0, 15 ],
      "id_str" : "318015337",
      "id" : 318015337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445664197792497664",
  "geo" : { },
  "id_str" : "445664861029019650",
  "in_reply_to_user_id" : 318015337,
  "text" : "@brandonhilkert sent, thanks",
  "id" : 445664861029019650,
  "in_reply_to_status_id" : 445664197792497664,
  "created_at" : "2014-03-17 20:55:57 +0000",
  "in_reply_to_screen_name" : "brandonhilkert",
  "in_reply_to_user_id_str" : "318015337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hilkert",
      "screen_name" : "brandonhilkert",
      "indices" : [ 0, 15 ],
      "id_str" : "318015337",
      "id" : 318015337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/XVyw8xPYMT",
      "expanded_url" : "http:\/\/brandonhilkert.com",
      "display_url" : "brandonhilkert.com"
    } ]
  },
  "geo" : { },
  "id_str" : "445663294213222400",
  "in_reply_to_user_id" : 318015337,
  "text" : "@brandonhilkert hi! your hi [at] http:\/\/t.co\/XVyw8xPYMT email doesn't work. What's the best way to email you?",
  "id" : 445663294213222400,
  "created_at" : "2014-03-17 20:49:44 +0000",
  "in_reply_to_screen_name" : "brandonhilkert",
  "in_reply_to_user_id_str" : "318015337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Suttles",
      "screen_name" : "jlsuttles",
      "indices" : [ 0, 10 ],
      "id_str" : "21170138",
      "id" : 21170138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445642027871772672",
  "geo" : { },
  "id_str" : "445642137741586433",
  "in_reply_to_user_id" : 21170138,
  "text" : "@jlsuttles what is this game!?",
  "id" : 445642137741586433,
  "in_reply_to_status_id" : 445642027871772672,
  "created_at" : "2014-03-17 19:25:39 +0000",
  "in_reply_to_screen_name" : "jlsuttles",
  "in_reply_to_user_id_str" : "21170138",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarcLyon",
      "screen_name" : "MarcLyon",
      "indices" : [ 0, 9 ],
      "id_str" : "16843390",
      "id" : 16843390
    }, {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 10, 18 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 19, 33 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445623643536891905",
  "geo" : { },
  "id_str" : "445626221565444097",
  "in_reply_to_user_id" : 16843390,
  "text" : "@MarcLyon @jwright @coworkbuffalo it's a bit wider than a normal ceramic coffee mug. We're going to have a store up to sell them soon!",
  "id" : 445626221565444097,
  "in_reply_to_status_id" : 445623643536891905,
  "created_at" : "2014-03-17 18:22:25 +0000",
  "in_reply_to_screen_name" : "MarcLyon",
  "in_reply_to_user_id_str" : "16843390",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 3, 11 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jwright\/status\/445622169289359360\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/fz2fw31xrg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi8rAGvIcAAejeG.jpg",
      "id_str" : "445622168941260800",
      "id" : 445622168941260800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi8rAGvIcAAejeG.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/fz2fw31xrg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445622537251069952",
  "text" : "RT @jwright: I got my @coworkbuffalo mug today! Turned out really nice. http:\/\/t.co\/fz2fw31xrg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 9, 23 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jwright\/status\/445622169289359360\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/fz2fw31xrg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi8rAGvIcAAejeG.jpg",
        "id_str" : "445622168941260800",
        "id" : 445622168941260800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi8rAGvIcAAejeG.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/fz2fw31xrg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445622169289359360",
    "text" : "I got my @coworkbuffalo mug today! Turned out really nice. http:\/\/t.co\/fz2fw31xrg",
    "id" : 445622169289359360,
    "created_at" : "2014-03-17 18:06:19 +0000",
    "user" : {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "protected" : false,
      "id_str" : "77673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530926764155879424\/jWjU45VR_normal.jpeg",
      "id" : 77673,
      "verified" : false
    }
  },
  "id" : 445622537251069952,
  "created_at" : "2014-03-17 18:07:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445622169289359360",
  "geo" : { },
  "id_str" : "445622519265894400",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright woot woot! thanks again.",
  "id" : 445622519265894400,
  "in_reply_to_status_id" : 445622169289359360,
  "created_at" : "2014-03-17 18:07:42 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445570961354403840",
  "geo" : { },
  "id_str" : "445603898003181569",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave You killed 500 pounds of  @coworkbuffalo, but can only bring back 10 to the wagon.",
  "id" : 445603898003181569,
  "in_reply_to_status_id" : 445570961354403840,
  "created_at" : "2014-03-17 16:53:42 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445598123063136256",
  "geo" : { },
  "id_str" : "445598413720014849",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej nm u?",
  "id" : 445598413720014849,
  "in_reply_to_status_id" : 445598123063136256,
  "created_at" : "2014-03-17 16:31:55 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 13, 20 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445577781036855296",
  "geo" : { },
  "id_str" : "445580777846091776",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson @sferik \"AS IS\" is still the most misunderstood part of OSS.",
  "id" : 445580777846091776,
  "in_reply_to_status_id" : 445577781036855296,
  "created_at" : "2014-03-17 15:21:50 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/445551888985899008\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rSVfiGoykD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi7rFRFCIAABB8B.jpg",
      "id_str" : "445551888872644608",
      "id" : 445551888872644608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi7rFRFCIAABB8B.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/rSVfiGoykD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445566851259834368",
  "text" : "RT @coworkbuffalo: Random 10 y.o. to backer wearing our shirt: \"Do you play Minecraft?\" Best compliment we could hope for, really. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/445551888985899008\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/rSVfiGoykD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi7rFRFCIAABB8B.jpg",
        "id_str" : "445551888872644608",
        "id" : 445551888872644608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi7rFRFCIAABB8B.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/rSVfiGoykD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445551888985899008",
    "text" : "Random 10 y.o. to backer wearing our shirt: \"Do you play Minecraft?\" Best compliment we could hope for, really. http:\/\/t.co\/rSVfiGoykD",
    "id" : 445551888985899008,
    "created_at" : "2014-03-17 13:27:02 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 445566851259834368,
  "created_at" : "2014-03-17 14:26:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/445322506849615872\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/FxF6vep1hU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi4addBCAAApoR1.jpg",
      "id_str" : "445322506463739904",
      "id" : 445322506463739904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi4addBCAAApoR1.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FxF6vep1hU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445322506849615872",
  "text" : "Pretty strange to be on dead trees http:\/\/t.co\/FxF6vep1hU",
  "id" : 445322506849615872,
  "created_at" : "2014-03-16 22:15:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445300809610182656",
  "text" : "@melissadclayton thanks!",
  "id" : 445300809610182656,
  "created_at" : "2014-03-16 20:49:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445284871729328128",
  "geo" : { },
  "id_str" : "445285347178475520",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents yep, Lightroom. I am actually not sure how to play with the RAW format directly. Just fed it into LR.",
  "id" : 445285347178475520,
  "in_reply_to_status_id" : 445284871729328128,
  "created_at" : "2014-03-16 19:47:54 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/VLMjIbDoer",
      "expanded_url" : "http:\/\/flic.kr\/p\/m7iqHT",
      "display_url" : "flic.kr\/p\/m7iqHT"
    } ]
  },
  "geo" : { },
  "id_str" : "445274946638733312",
  "text" : "Show in RAW for the first time. The \"AUTHORIZED PERSONAL\" only greenhouse is my favorite. http:\/\/t.co\/VLMjIbDoer",
  "id" : 445274946638733312,
  "created_at" : "2014-03-16 19:06:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445264953453191168",
  "text" : "Decided to ImageOptim all of my photo backups on Dropbox. Roughly 10% savings. Not sure if worth it.",
  "id" : 445264953453191168,
  "created_at" : "2014-03-16 18:26:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/kr3O9b2u6Y",
      "expanded_url" : "https:\/\/www.gittip.com\/qrush\/",
      "display_url" : "gittip.com\/qrush\/"
    } ]
  },
  "in_reply_to_status_id_str" : "444686125551349760",
  "geo" : { },
  "id_str" : "444856752022904832",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten https:\/\/t.co\/kr3O9b2u6Y ;)",
  "id" : 444856752022904832,
  "in_reply_to_status_id" : 444686125551349760,
  "created_at" : "2014-03-15 15:24:49 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 8, 23 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 24, 29 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 30, 45 ],
      "id_str" : "19735370",
      "id" : 19735370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444645097661952000",
  "geo" : { },
  "id_str" : "444646309882892288",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 @ChrisVanPatten @popo @BarCampBuffalo Updated the site with some faces and a better favicon. I want a tshirt of this logo.",
  "id" : 444646309882892288,
  "in_reply_to_status_id" : 444645097661952000,
  "created_at" : "2014-03-15 01:28:36 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till!",
      "screen_name" : "klimpong",
      "indices" : [ 0, 9 ],
      "id_str" : "4600051",
      "id" : 4600051
    }, {
      "name" : "Patrick Huesler",
      "screen_name" : "phuesler",
      "indices" : [ 10, 19 ],
      "id_str" : "22169436",
      "id" : 22169436
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 52, 66 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444507664815763456",
  "geo" : { },
  "id_str" : "444530707012915200",
  "in_reply_to_user_id" : 4600051,
  "text" : "@klimpong @phuesler AirPort Extreme works great for @coworkbuffalo",
  "id" : 444530707012915200,
  "in_reply_to_status_id" : 444507664815763456,
  "created_at" : "2014-03-14 17:49:14 +0000",
  "in_reply_to_screen_name" : "klimpong",
  "in_reply_to_user_id_str" : "4600051",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444475776516497409",
  "geo" : { },
  "id_str" : "444479547791376384",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y is it sad that I recognize this husky and the vine account it came from?",
  "id" : 444479547791376384,
  "in_reply_to_status_id" : 444475776516497409,
  "created_at" : "2014-03-14 14:25:56 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Boxer",
      "screen_name" : "jakeboxer",
      "indices" : [ 0, 10 ],
      "id_str" : "14500363",
      "id" : 14500363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444183156791738369",
  "geo" : { },
  "id_str" : "444217503829340161",
  "in_reply_to_user_id" : 14500363,
  "text" : "@jakeboxer frites - san francisco for tater tots",
  "id" : 444217503829340161,
  "in_reply_to_status_id" : 444183156791738369,
  "created_at" : "2014-03-13 21:04:40 +0000",
  "in_reply_to_screen_name" : "jakeboxer",
  "in_reply_to_user_id_str" : "14500363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Boxer",
      "screen_name" : "jakeboxer",
      "indices" : [ 3, 13 ],
      "id_str" : "14500363",
      "id" : 14500363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444217389396131840",
  "text" : "RT @jakeboxer: kale - san francisco for lettuce\naioli - san francisco for mayonnaise\ntruffle mac and cheese - san francisco for mac and che\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "444183156791738369",
    "text" : "kale - san francisco for lettuce\naioli - san francisco for mayonnaise\ntruffle mac and cheese - san francisco for mac and cheese",
    "id" : 444183156791738369,
    "created_at" : "2014-03-13 18:48:11 +0000",
    "user" : {
      "name" : "Jake Boxer",
      "screen_name" : "jakeboxer",
      "protected" : false,
      "id_str" : "14500363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3600152452\/e115759ed87f43c15083e0fe780c2fec_normal.jpeg",
      "id" : 14500363,
      "verified" : false
    }
  },
  "id" : 444217389396131840,
  "created_at" : "2014-03-13 21:04:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/2vyEp33kC4",
      "expanded_url" : "http:\/\/www.buffalonews.com\/business\/encouraging-entrepreneurs-at-a-new-coworking-space-20140313",
      "display_url" : "buffalonews.com\/business\/encou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444177783124529152",
  "text" : "Looks like @coworkbuffalo is in the News again: http:\/\/t.co\/2vyEp33kC4",
  "id" : 444177783124529152,
  "created_at" : "2014-03-13 18:26:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/GKbllSLrUM",
      "expanded_url" : "http:\/\/flic.kr\/p\/kZZyBj",
      "display_url" : "flic.kr\/p\/kZZyBj"
    } ]
  },
  "geo" : { },
  "id_str" : "444115967048949760",
  "text" : "Still here http:\/\/t.co\/GKbllSLrUM",
  "id" : 444115967048949760,
  "created_at" : "2014-03-13 14:21:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Ed0LEWZWvq",
      "expanded_url" : "http:\/\/quaran.to\/archive\/",
      "display_url" : "quaran.to\/archive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "443919502040776705",
  "text" : "Yesterday's twitter outage reminded me to download &amp; update my archive. You should request yours too. http:\/\/t.co\/Ed0LEWZWvq",
  "id" : 443919502040776705,
  "created_at" : "2014-03-13 01:20:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/AYSHHdrZg7",
      "expanded_url" : "http:\/\/club2.nintendo.com\/3ds-pokemon-promo\/",
      "display_url" : "club2.nintendo.com\/3ds-pokemon-pr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "443792594175131648",
  "geo" : { },
  "id_str" : "443793099374866432",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr Waiting to cash in on http:\/\/t.co\/AYSHHdrZg7",
  "id" : 443793099374866432,
  "in_reply_to_status_id" : 443792594175131648,
  "created_at" : "2014-03-12 16:58:14 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 9, 20 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443790207566249984",
  "geo" : { },
  "id_str" : "443791513693061120",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig @tenderlove wow, neat. might check this out too.",
  "id" : 443791513693061120,
  "in_reply_to_status_id" : 443790207566249984,
  "created_at" : "2014-03-12 16:51:56 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/coNEnTT8c4",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/article\/2014\/03\/12\/nsa-plans-infect-millions-computers-malware\/",
      "display_url" : "firstlook.org\/theintercept\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443784653825384448",
  "text" : "I've decided on a new Pokemon naming scheme when I get Y: NSA programs. https:\/\/t.co\/coNEnTT8c4",
  "id" : 443784653825384448,
  "created_at" : "2014-03-12 16:24:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TONX",
      "screen_name" : "tonxcoffee",
      "indices" : [ 11, 22 ],
      "id_str" : "288854366",
      "id" : 288854366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443782270411739136",
  "text" : "Confirmed: @tonxcoffee delivery still happens during blizzard conditions.",
  "id" : 443782270411739136,
  "created_at" : "2014-03-12 16:15:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 68, 76 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443760443266318336",
  "geo" : { },
  "id_str" : "443762288583905280",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant that is awesome. worked on it for a class at RIT. \/cc @dmansen",
  "id" : 443762288583905280,
  "in_reply_to_status_id" : 443760443266318336,
  "created_at" : "2014-03-12 14:55:48 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/443749356152164352\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/XhTZtwt2ls",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiiDsC7CMAElmfZ.png",
      "id_str" : "443749356017954817",
      "id" : 443749356017954817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiiDsC7CMAElmfZ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XhTZtwt2ls"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/Qhm2MqUE5k",
      "expanded_url" : "http:\/\/ifttt.com\/recipes\/147701",
      "display_url" : "ifttt.com\/recipes\/147701"
    } ]
  },
  "geo" : { },
  "id_str" : "443749356152164352",
  "text" : "SMS alerts for Buffalo weather: free and super helpful. http:\/\/t.co\/Qhm2MqUE5k http:\/\/t.co\/XhTZtwt2ls",
  "id" : 443749356152164352,
  "created_at" : "2014-03-12 14:04:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zalar",
      "screen_name" : "ZalarMark",
      "indices" : [ 0, 10 ],
      "id_str" : "483153848",
      "id" : 483153848
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 11, 25 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443732375697371136",
  "geo" : { },
  "id_str" : "443733754746396674",
  "in_reply_to_user_id" : 483153848,
  "text" : "@ZalarMark @Carols10cents oh oops! Well\u2026road trip?! The Q haus has space!",
  "id" : 443733754746396674,
  "in_reply_to_status_id" : 443732375697371136,
  "created_at" : "2014-03-12 13:02:25 +0000",
  "in_reply_to_screen_name" : "ZalarMark",
  "in_reply_to_user_id_str" : "483153848",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "English Pork Pie Co",
      "screen_name" : "EPPC",
      "indices" : [ 0, 5 ],
      "id_str" : "24216325",
      "id" : 24216325
    }, {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 6, 18 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443490919119990784",
  "geo" : { },
  "id_str" : "443731155951443968",
  "in_reply_to_user_id" : 24216325,
  "text" : "@EPPC @BuffaloEats nice! Good time to open too. Where is this?",
  "id" : 443731155951443968,
  "in_reply_to_status_id" : 443490919119990784,
  "created_at" : "2014-03-12 12:52:06 +0000",
  "in_reply_to_screen_name" : "EPPC",
  "in_reply_to_user_id_str" : "24216325",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443720502407069696",
  "geo" : { },
  "id_str" : "443725490801496064",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents ticket reserve is up now! They are also playing in Pittsburgh.",
  "id" : 443725490801496064,
  "in_reply_to_status_id" : 443720502407069696,
  "created_at" : "2014-03-12 12:29:35 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 34, 40 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443476588458299392",
  "text" : "Shortest drive I'll ever have for @phish at CMAC. Can't wait!",
  "id" : 443476588458299392,
  "created_at" : "2014-03-11 20:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443413324189806592",
  "geo" : { },
  "id_str" : "443467763403612161",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine quite the pessimistic way to view time &amp; life",
  "id" : 443467763403612161,
  "in_reply_to_status_id" : 443413324189806592,
  "created_at" : "2014-03-11 19:25:28 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miles Forrest",
      "screen_name" : "MilesForrest",
      "indices" : [ 3, 16 ],
      "id_str" : "1027351",
      "id" : 1027351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/2xeTTeJ6AN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wHduATM-o7M",
      "display_url" : "youtube.com\/watch?v=wHduAT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443461882460909568",
  "text" : "RT @MilesForrest: Microsoft Songsmith version of Nirvana\u2019s \u201CIn Bloom\u201D http:\/\/t.co\/2xeTTeJ6AN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/2xeTTeJ6AN",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wHduATM-o7M",
        "display_url" : "youtube.com\/watch?v=wHduAT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443437797286768640",
    "text" : "Microsoft Songsmith version of Nirvana\u2019s \u201CIn Bloom\u201D http:\/\/t.co\/2xeTTeJ6AN",
    "id" : 443437797286768640,
    "created_at" : "2014-03-11 17:26:24 +0000",
    "user" : {
      "name" : "Miles Forrest",
      "screen_name" : "MilesForrest",
      "protected" : false,
      "id_str" : "1027351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477349916423884800\/5wY8q09Z_normal.png",
      "id" : 1027351,
      "verified" : false
    }
  },
  "id" : 443461882460909568,
  "created_at" : "2014-03-11 19:02:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/CExsRn5Pte",
      "expanded_url" : "http:\/\/www.bizjournals.com\/buffalo\/news\/2014\/03\/11\/forbes-buffalo-is-americas-most-affordable-city.html?ana=twt",
      "display_url" : "bizjournals.com\/buffalo\/news\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443409017503617024",
  "text" : "RT @markpoloncarz: We knew this, now everyone else will as well: Forbes: Buffalo is America's most affordable city http:\/\/t.co\/CExsRn5Pte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/CExsRn5Pte",
        "expanded_url" : "http:\/\/www.bizjournals.com\/buffalo\/news\/2014\/03\/11\/forbes-buffalo-is-americas-most-affordable-city.html?ana=twt",
        "display_url" : "bizjournals.com\/buffalo\/news\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443408815615377408",
    "text" : "We knew this, now everyone else will as well: Forbes: Buffalo is America's most affordable city http:\/\/t.co\/CExsRn5Pte",
    "id" : 443408815615377408,
    "created_at" : "2014-03-11 15:31:14 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 443409017503617024,
  "created_at" : "2014-03-11 15:32:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 3, 14 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/iD8eQKKQnM",
      "expanded_url" : "http:\/\/www.funnyordie.com\/videos\/18e820ec3f\/between-two-ferns-with-zach-galifianakis-president-barack-obama",
      "display_url" : "funnyordie.com\/videos\/18e820e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443354538129383424",
  "text" : "RT @shanselman: \"Why would you have the guy who made the Zune build your website?\" Obama is Between Two Ferns http:\/\/t.co\/iD8eQKKQnM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/iD8eQKKQnM",
        "expanded_url" : "http:\/\/www.funnyordie.com\/videos\/18e820ec3f\/between-two-ferns-with-zach-galifianakis-president-barack-obama",
        "display_url" : "funnyordie.com\/videos\/18e820e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443352602634235905",
    "text" : "\"Why would you have the guy who made the Zune build your website?\" Obama is Between Two Ferns http:\/\/t.co\/iD8eQKKQnM",
    "id" : 443352602634235905,
    "created_at" : "2014-03-11 11:47:52 +0000",
    "user" : {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "protected" : false,
      "id_str" : "5676102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459455847165218816\/I_sH-zvU_normal.jpeg",
      "id" : 5676102,
      "verified" : true
    }
  },
  "id" : 443354538129383424,
  "created_at" : "2014-03-11 11:55:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NWSBUFFALO\/status\/443325915859136512\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Ses1crCkGx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BicCklbCMAEwRDB.png",
      "id_str" : "443325915863330817",
      "id" : 443325915863330817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BicCklbCMAEwRDB.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/Ses1crCkGx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443345609148211200",
  "text" : "WINTER IS COMING (again) http:\/\/t.co\/Ses1crCkGx",
  "id" : 443345609148211200,
  "created_at" : "2014-03-11 11:20:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ian Black",
      "screen_name" : "michaelianblack",
      "indices" : [ 3, 19 ],
      "id_str" : "21035409",
      "id" : 21035409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/GSfVLOTXED",
      "expanded_url" : "http:\/\/imgur.com\/a\/SjcgE",
      "display_url" : "imgur.com\/a\/SjcgE"
    } ]
  },
  "geo" : { },
  "id_str" : "443189551092097024",
  "text" : "RT @michaelianblack: Favorite thing on the Internet today. Photoset of guy at Magic: The Gathering gathering. http:\/\/t.co\/GSfVLOTXED",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/GSfVLOTXED",
        "expanded_url" : "http:\/\/imgur.com\/a\/SjcgE",
        "display_url" : "imgur.com\/a\/SjcgE"
      } ]
    },
    "geo" : { },
    "id_str" : "443179507445673985",
    "text" : "Favorite thing on the Internet today. Photoset of guy at Magic: The Gathering gathering. http:\/\/t.co\/GSfVLOTXED",
    "id" : 443179507445673985,
    "created_at" : "2014-03-11 00:20:03 +0000",
    "user" : {
      "name" : "Michael Ian Black",
      "screen_name" : "michaelianblack",
      "protected" : false,
      "id_str" : "21035409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553990366458683392\/sKvrJgJj_normal.jpeg",
      "id" : 21035409,
      "verified" : true
    }
  },
  "id" : 443189551092097024,
  "created_at" : "2014-03-11 00:59:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443189159667048448",
  "text" : "I miss writing. Read and code all day. Recharge on weekends. Used to crank out a blog post a week! \uD83D\uDE24",
  "id" : 443189159667048448,
  "created_at" : "2014-03-11 00:58:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443096501565521920",
  "text" : "RT @IAM_SHAKESPEARE: Lose all, and more by paying too much rent",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443096453071003648",
    "text" : "Lose all, and more by paying too much rent",
    "id" : 443096453071003648,
    "created_at" : "2014-03-10 18:50:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 443096501565521920,
  "created_at" : "2014-03-10 18:50:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443092395500920832",
  "text" : "Not reading any email over the weekends makes Mondays a lot more scatterbrained...but weekends much nicer.",
  "id" : 443092395500920832,
  "created_at" : "2014-03-10 18:33:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 3, 18 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 27, 34 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/calebthompson\/status\/443043699518603264\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/iVIgiZlhcM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiYB5bUIAAA1fMf.png",
      "id_str" : "443043699438911488",
      "id" : 443043699438911488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiYB5bUIAAA1fMf.png",
      "sizes" : [ {
        "h" : 321,
        "resize" : "fit",
        "w" : 56
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 56
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 56
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 56
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 56
      } ],
      "display_url" : "pic.twitter.com\/iVIgiZlhcM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443045526053715969",
  "text" : "RT @thompson_caleb: @qrush @github What, you don\u2019t know what all of these things are intuitively? http:\/\/t.co\/iVIgiZlhcM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 7, 14 ],
        "id_str" : "13334762",
        "id" : 13334762
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/calebthompson\/status\/443043699518603264\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/iVIgiZlhcM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiYB5bUIAAA1fMf.png",
        "id_str" : "443043699438911488",
        "id" : 443043699438911488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiYB5bUIAAA1fMf.png",
        "sizes" : [ {
          "h" : 321,
          "resize" : "fit",
          "w" : 56
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 56
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 56
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 56
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 56
        } ],
        "display_url" : "pic.twitter.com\/iVIgiZlhcM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "443042528527273984",
    "geo" : { },
    "id_str" : "443043699518603264",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @github What, you don\u2019t know what all of these things are intuitively? http:\/\/t.co\/iVIgiZlhcM",
    "id" : 443043699518603264,
    "in_reply_to_status_id" : 443042528527273984,
    "created_at" : "2014-03-10 15:20:23 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Caleb Thompson",
      "screen_name" : "calebthompson",
      "protected" : false,
      "id_str" : "290866979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552563800159690752\/u_ge2yTN_normal.jpeg",
      "id" : 290866979,
      "verified" : false
    }
  },
  "id" : 443045526053715969,
  "created_at" : "2014-03-10 15:27:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Griffin",
      "screen_name" : "betamatt",
      "indices" : [ 3, 12 ],
      "id_str" : "9976112",
      "id" : 9976112
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443045478607757312",
  "text" : "RT @betamatt: @qrush this used to be referred to as \"mystery meat navigation\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "443042528527273984",
    "geo" : { },
    "id_str" : "443044253908746240",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush this used to be referred to as \"mystery meat navigation\"",
    "id" : 443044253908746240,
    "in_reply_to_status_id" : 443042528527273984,
    "created_at" : "2014-03-10 15:22:36 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Matt Griffin",
      "screen_name" : "betamatt",
      "protected" : false,
      "id_str" : "9976112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/40206432\/Photo_5_normal.jpg",
      "id" : 9976112,
      "verified" : false
    }
  },
  "id" : 443045478607757312,
  "created_at" : "2014-03-10 15:27:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443042528527273984",
  "text" : "The tooltip driven design on GitHub has been driving me nuts. Use words to describe things, not icons! :(",
  "id" : 443042528527273984,
  "created_at" : "2014-03-10 15:15:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442843211657003009",
  "text" : "Cosmos was great. Still truly believe that Computer Science needs a public face like Sagan or Degrasse-Tyson. (And not an entrepreneur.)",
  "id" : 442843211657003009,
  "created_at" : "2014-03-10 02:03:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 11, 18 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442742558666420224",
  "geo" : { },
  "id_str" : "442837526852960256",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @nb3004 can verify that the existing sticker has not faded on a car for over 1.5 years",
  "id" : 442837526852960256,
  "in_reply_to_status_id" : 442742558666420224,
  "created_at" : "2014-03-10 01:41:08 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442829294331777024",
  "text" : "New COSMOS! Can\u2019t wait to watch this with the little one.",
  "id" : 442829294331777024,
  "created_at" : "2014-03-10 01:08:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442741420969844736",
  "geo" : { },
  "id_str" : "442770332517425152",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene definitely shouldn\u2019t be.",
  "id" : 442770332517425152,
  "in_reply_to_status_id" : 442741420969844736,
  "created_at" : "2014-03-09 21:14:08 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Salmon",
      "screen_name" : "felixsalmon",
      "indices" : [ 3, 15 ],
      "id_str" : "16399949",
      "id" : 16399949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/DOLN3EgDJS",
      "expanded_url" : "https:\/\/twitter.com\/AOLAdvertising\/status\/442690077060128768",
      "display_url" : "twitter.com\/AOLAdvertising\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442719312873152512",
  "text" : "RT @felixsalmon: Is there anybody out there who does *not* think that SXSW has officially jumped the shark? https:\/\/t.co\/DOLN3EgDJS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/DOLN3EgDJS",
        "expanded_url" : "https:\/\/twitter.com\/AOLAdvertising\/status\/442690077060128768",
        "display_url" : "twitter.com\/AOLAdvertising\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "442716675033399297",
    "text" : "Is there anybody out there who does *not* think that SXSW has officially jumped the shark? https:\/\/t.co\/DOLN3EgDJS",
    "id" : 442716675033399297,
    "created_at" : "2014-03-09 17:40:55 +0000",
    "user" : {
      "name" : "Felix Salmon",
      "screen_name" : "felixsalmon",
      "protected" : false,
      "id_str" : "16399949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453561742920929280\/Seu5dsPA_normal.jpeg",
      "id" : 16399949,
      "verified" : true
    }
  },
  "id" : 442719312873152512,
  "created_at" : "2014-03-09 17:51:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442477550288523264",
  "text" : "GBA SP is still my favorite handheld system. Nothing else has beaten this form factor.",
  "id" : 442477550288523264,
  "created_at" : "2014-03-09 01:50:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442379124393267200",
  "text" : "And the ultimate bummer: the internal battery on my Silver cart died, so no saves work :(",
  "id" : 442379124393267200,
  "created_at" : "2014-03-08 19:19:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442358928132018176",
  "text" : "Found my GBA SP and Silver. Thinking of picking up FireRed or LeafGreen before grabbing X or Y. This is what TPP does to my brain \uD83D\uDE26",
  "id" : 442358928132018176,
  "created_at" : "2014-03-08 17:59:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Salmon",
      "screen_name" : "felixsalmon",
      "indices" : [ 3, 15 ],
      "id_str" : "16399949",
      "id" : 16399949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/OifYLPK9st",
      "expanded_url" : "http:\/\/qwantz.com\/index.php?comic=2587",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442327144232808448",
  "text" : "RT @felixsalmon: My feelings about driving, exactly http:\/\/t.co\/OifYLPK9st",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/OifYLPK9st",
        "expanded_url" : "http:\/\/qwantz.com\/index.php?comic=2587",
        "display_url" : "qwantz.com\/index.php?comi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "442319947533144064",
    "text" : "My feelings about driving, exactly http:\/\/t.co\/OifYLPK9st",
    "id" : 442319947533144064,
    "created_at" : "2014-03-08 15:24:28 +0000",
    "user" : {
      "name" : "Felix Salmon",
      "screen_name" : "felixsalmon",
      "protected" : false,
      "id_str" : "16399949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453561742920929280\/Seu5dsPA_normal.jpeg",
      "id" : 16399949,
      "verified" : true
    }
  },
  "id" : 442327144232808448,
  "created_at" : "2014-03-08 15:53:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/RwbLVaKXHP",
      "expanded_url" : "http:\/\/bulbapedia.bulbagarden.net\/wiki\/Satoshi_(Zensho)",
      "display_url" : "bulbapedia.bulbagarden.net\/wiki\/Satoshi_(\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442307414767837184",
  "text" : "I found the creator of Bitcoin! He was in plain sight this entire time. http:\/\/t.co\/RwbLVaKXHP",
  "id" : 442307414767837184,
  "created_at" : "2014-03-08 14:34:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 101, 115 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442089787378266112",
  "text" : "Still hard to believe we have a location on Main St packed with 40+ people who backed and believe in @coworkbuffalo tonight.",
  "id" : 442089787378266112,
  "created_at" : "2014-03-08 00:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "britt c. h.",
      "screen_name" : "brittch",
      "indices" : [ 3, 11 ],
      "id_str" : "9361822",
      "id" : 9361822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/mmR1TGndko",
      "expanded_url" : "http:\/\/ied.rca.ac.uk\/de-computation\/space-replay",
      "display_url" : "ied.rca.ac.uk\/de-computation\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442023731351658496",
  "text" : "RT @brittch: A black sphere that floats about replaying ambient noise it'd previously captured: http:\/\/t.co\/mmR1TGndko Simple, vaguely cree\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/mmR1TGndko",
        "expanded_url" : "http:\/\/ied.rca.ac.uk\/de-computation\/space-replay",
        "display_url" : "ied.rca.ac.uk\/de-computation\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "442005171476762624",
    "text" : "A black sphere that floats about replaying ambient noise it'd previously captured: http:\/\/t.co\/mmR1TGndko Simple, vaguely creepy, and neat!",
    "id" : 442005171476762624,
    "created_at" : "2014-03-07 18:33:39 +0000",
    "user" : {
      "name" : "britt c. h.",
      "screen_name" : "brittch",
      "protected" : false,
      "id_str" : "9361822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529494231023226881\/GScR4XHN_normal.png",
      "id" : 9361822,
      "verified" : false
    }
  },
  "id" : 442023731351658496,
  "created_at" : "2014-03-07 19:47:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 10, 19 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442022543092772865",
  "geo" : { },
  "id_str" : "442023224038400000",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems @ryanbigg dear god I hope not",
  "id" : 442023224038400000,
  "in_reply_to_status_id" : 442022543092772865,
  "created_at" : "2014-03-07 19:45:23 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442013017522176000",
  "geo" : { },
  "id_str" : "442013298863525888",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg irb(main):002:0&gt; 3.method(:+)[4] =&gt; 7",
  "id" : 442013298863525888,
  "in_reply_to_status_id" : 442013017522176000,
  "created_at" : "2014-03-07 19:05:57 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441990734959218688",
  "geo" : { },
  "id_str" : "441991003755380736",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 is that Joker in Sunnyvale trailer park?",
  "id" : 441991003755380736,
  "in_reply_to_status_id" : 441990734959218688,
  "created_at" : "2014-03-07 17:37:21 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 3, 9 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ahuj9\/status\/441963134262067200\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Qit1S5LBX5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiIrIPTCQAASjOh.jpg",
      "id_str" : "441963133981048832",
      "id" : 441963133981048832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiIrIPTCQAASjOh.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/Qit1S5LBX5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441967671475970048",
  "text" : "RT @ahuj9: this is headline news in buffalo http:\/\/t.co\/Qit1S5LBX5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ahuj9\/status\/441963134262067200\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/Qit1S5LBX5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiIrIPTCQAASjOh.jpg",
        "id_str" : "441963133981048832",
        "id" : 441963133981048832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiIrIPTCQAASjOh.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/Qit1S5LBX5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441963134262067200",
    "text" : "this is headline news in buffalo http:\/\/t.co\/Qit1S5LBX5",
    "id" : 441963134262067200,
    "created_at" : "2014-03-07 15:46:37 +0000",
    "user" : {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "protected" : false,
      "id_str" : "205281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2438738477\/m3tcrt9kvs9x0ff84b31_normal.jpeg",
      "id" : 205281746,
      "verified" : false
    }
  },
  "id" : 441967671475970048,
  "created_at" : "2014-03-07 16:04:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441787850619883520",
  "geo" : { },
  "id_str" : "441788719516123137",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k yes sir, family in tow. sounds good.",
  "id" : 441788719516123137,
  "in_reply_to_status_id" : 441787850619883520,
  "created_at" : "2014-03-07 04:13:33 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441784829513056256",
  "geo" : { },
  "id_str" : "441785029245407232",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k not happening on either front. i haven't seen any language lately that has been remotely of interest.",
  "id" : 441785029245407232,
  "in_reply_to_status_id" : 441784829513056256,
  "created_at" : "2014-03-07 03:58:53 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 124, 133 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441777629524676610",
  "geo" : { },
  "id_str" : "441778244421840898",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone I'm pretty sure we had to either go find or buy a strategy guide at a store. I just remember it being brutal. \/cc @bquarant",
  "id" : 441778244421840898,
  "in_reply_to_status_id" : 441777629524676610,
  "created_at" : "2014-03-07 03:31:55 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441777157157564417",
  "text" : "Ruby PSA: (1..10) != [1..10]",
  "id" : 441777157157564417,
  "created_at" : "2014-03-07 03:27:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441776867243474944",
  "geo" : { },
  "id_str" : "441777064257916928",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone Too scarred from the Water Temple?",
  "id" : 441777064257916928,
  "in_reply_to_status_id" : 441776867243474944,
  "created_at" : "2014-03-07 03:27:14 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    }, {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 11, 19 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441770880843001857",
  "geo" : { },
  "id_str" : "441775485408665600",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox @jeresig RIT definitely isn't for everyone. Saw it chew up and spit out too many friends.",
  "id" : 441775485408665600,
  "in_reply_to_status_id" : 441770880843001857,
  "created_at" : "2014-03-07 03:20:58 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/46GENpdycs",
      "expanded_url" : "http:\/\/mechanize.rubyforge.org\/EXAMPLES_rdoc.html",
      "display_url" : "mechanize.rubyforge.org\/EXAMPLES_rdoc.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441775258391965696",
  "text" : "LOL: Mechanize gem still has HTTP login to Rubyforge as an example http:\/\/t.co\/46GENpdycs",
  "id" : 441775258391965696,
  "created_at" : "2014-03-07 03:20:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441769817406582784",
  "geo" : { },
  "id_str" : "441770364192833536",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox Oops! We need to catch up again. Going to Railsconf?",
  "id" : 441770364192833536,
  "in_reply_to_status_id" : 441769817406582784,
  "created_at" : "2014-03-07 03:00:37 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    }, {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 11, 19 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441769416775061504",
  "geo" : { },
  "id_str" : "441769620882464768",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox @jeresig well aware of him, I meant you! :)",
  "id" : 441769620882464768,
  "in_reply_to_status_id" : 441769416775061504,
  "created_at" : "2014-03-07 02:57:39 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    }, {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 11, 19 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441768558448488448",
  "geo" : { },
  "id_str" : "441769113434603520",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox @jeresig you went to RIT too!!??",
  "id" : 441769113434603520,
  "in_reply_to_status_id" : 441768558448488448,
  "created_at" : "2014-03-07 02:55:38 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441767810046640128",
  "text" : "Modeling sets, setlists, and other things for live gigs. I would have paid better attention in my database class if this was the content.",
  "id" : 441767810046640128,
  "created_at" : "2014-03-07 02:50:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441760149217083392",
  "text" : "YOLO: `rm Gemfile.lock`",
  "id" : 441760149217083392,
  "created_at" : "2014-03-07 02:20:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441749731471929344",
  "geo" : { },
  "id_str" : "441750942875394048",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza oh yeah. I had White but had to stop at some point since it was too addictive. Blue, Silver, Sapphire otherwise were great.",
  "id" : 441750942875394048,
  "in_reply_to_status_id" : 441749731471929344,
  "created_at" : "2014-03-07 01:43:26 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441744516567932928",
  "geo" : { },
  "id_str" : "441749574885986304",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza is Y worth it? Thinking of picking it up.",
  "id" : 441749574885986304,
  "in_reply_to_status_id" : 441744516567932928,
  "created_at" : "2014-03-07 01:38:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/pljWjELpdk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1bBTIb_sFBo",
      "display_url" : "youtube.com\/watch?v=1bBTIb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441698500670021632",
  "text" : "Buffalo history circa 1836. Feels like SimCity: http:\/\/t.co\/pljWjELpdk",
  "id" : 441698500670021632,
  "created_at" : "2014-03-06 22:15:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/441682662701297665\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/regnf95LIl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiEsCplCUAAO_dZ.png",
      "id_str" : "441682662491574272",
      "id" : 441682662491574272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiEsCplCUAAO_dZ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/regnf95LIl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441682662701297665",
  "text" : "I apparently am both wired and failing this colorblindness test. http:\/\/t.co\/regnf95LIl",
  "id" : 441682662701297665,
  "created_at" : "2014-03-06 21:12:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 7, 17 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441667451302842368",
  "geo" : { },
  "id_str" : "441667619070816256",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @stevelosh looks cool. I hope it attracts more than just CS, SE, IT majors.",
  "id" : 441667619070816256,
  "in_reply_to_status_id" : 441667451302842368,
  "created_at" : "2014-03-06 20:12:20 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup CEO",
      "screen_name" : "voozahq",
      "indices" : [ 32, 40 ],
      "id_str" : "524691753",
      "id" : 524691753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/DdloQP5aDc",
      "expanded_url" : "http:\/\/vimeo.com\/88209254",
      "display_url" : "vimeo.com\/88209254"
    } ]
  },
  "geo" : { },
  "id_str" : "441666104730345472",
  "text" : "This is a sick joke right? Or a @voozahq spot? http:\/\/t.co\/DdloQP5aDc",
  "id" : 441666104730345472,
  "created_at" : "2014-03-06 20:06:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Yiq9VvhIYD",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/9395413",
      "display_url" : "gist.github.com\/qrush\/9395413"
    } ]
  },
  "geo" : { },
  "id_str" : "441631200059199488",
  "text" : "Just learned about class_attribute. I can't tell you how many times I've written this myself: https:\/\/t.co\/Yiq9VvhIYD",
  "id" : 441631200059199488,
  "created_at" : "2014-03-06 17:47:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ga2M11y9qL",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Timeline_of_the_far_future",
      "display_url" : "en.wikipedia.org\/wiki\/Timeline_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441608429958729729",
  "text" : "Just in case you're having a good day, take a quick readthrough of the Timeline of the Far Future. https:\/\/t.co\/ga2M11y9qL",
  "id" : 441608429958729729,
  "created_at" : "2014-03-06 16:17:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441542957133754368",
  "geo" : { },
  "id_str" : "441548215142191105",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer woot!!",
  "id" : 441548215142191105,
  "in_reply_to_status_id" : 441542957133754368,
  "created_at" : "2014-03-06 12:17:52 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441421475619536896",
  "text" : "Next winter I am just going to get a sweater permanently sewn onto my skin. Then I won\u2019t need any extra layers for the Vortex.",
  "id" : 441421475619536896,
  "created_at" : "2014-03-06 03:54:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 36, 43 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441415762410868736",
  "text" : "M\u0340\u0361\u0315\u034F\u0361U\u0358\u0328\u0361\u0321\u0335R\u031B\u0362\u0321\u0315D\u0328\u0328\u0328\u0336\u0336E\u0340\u0337\u0340R\u035D\u0321\u0321 \/cc @gabebw",
  "id" : 441415762410868736,
  "created_at" : "2014-03-06 03:31:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441415014801768448",
  "geo" : { },
  "id_str" : "441415296658591746",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw MURDER",
  "id" : 441415296658591746,
  "in_reply_to_status_id" : 441415014801768448,
  "created_at" : "2014-03-06 03:29:42 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441414853610053632",
  "text" : "Tuned into Twitch just in time to watch them straight up a pokemon. Anarchy is brutal.",
  "id" : 441414853610053632,
  "created_at" : "2014-03-06 03:27:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441406671311474688",
  "geo" : { },
  "id_str" : "441407165815721984",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy this is an abomination",
  "id" : 441407165815721984,
  "in_reply_to_status_id" : 441406671311474688,
  "created_at" : "2014-03-06 02:57:23 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441385701452812288",
  "geo" : { },
  "id_str" : "441386077794742272",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee What's up Gary?",
  "id" : 441386077794742272,
  "in_reply_to_status_id" : 441385701452812288,
  "created_at" : "2014-03-06 01:33:36 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/rHinSfdcQ7",
      "expanded_url" : "http:\/\/nl.linkedin.com\/pub\/rofl-copter\/58\/503\/825",
      "display_url" : "nl.linkedin.com\/pub\/rofl-copte\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441376746751799296",
  "geo" : { },
  "id_str" : "441380105667899394",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn please endorse me then: http:\/\/t.co\/rHinSfdcQ7",
  "id" : 441380105667899394,
  "in_reply_to_status_id" : 441376746751799296,
  "created_at" : "2014-03-06 01:09:52 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441371645324709888",
  "text" : "@juliepagano @aquaranto spotted a jigglypuff hot air balloon in one, does that count?",
  "id" : 441371645324709888,
  "created_at" : "2014-03-06 00:36:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441364850522857472",
  "text" : "Grinding through Pok\u00E9mon season 1 on Netflix. I feel like I only saw one episode I recorded over and over again on VHS when I was little.",
  "id" : 441364850522857472,
  "created_at" : "2014-03-06 00:09:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441328670284591104",
  "text" : "Current status: roleplaying VOIP phone setup",
  "id" : 441328670284591104,
  "created_at" : "2014-03-05 21:45:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441103625306112001",
  "geo" : { },
  "id_str" : "441320943252561920",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik &lt;small&gt;including you?&lt;\/small&gt;",
  "id" : 441320943252561920,
  "in_reply_to_status_id" : 441103625306112001,
  "created_at" : "2014-03-05 21:14:46 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/SYyCqOvs7c",
      "expanded_url" : "http:\/\/www.powerhoof.com\/crawl\/",
      "display_url" : "powerhoof.com\/crawl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "441313410207064064",
  "text" : "This would be perfect for Wii U: http:\/\/t.co\/SYyCqOvs7c",
  "id" : 441313410207064064,
  "created_at" : "2014-03-05 20:44:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ThPYgN4Mja",
      "expanded_url" : "http:\/\/youtubedoubler.com\/?video1=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DQH2-TGUlwu4&start1=&video2=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DMK6TXMsvgQg&start2=&authorName=",
      "display_url" : "youtubedoubler.com\/?video1=http%3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441311597529944064",
  "geo" : { },
  "id_str" : "441312248254844928",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh Sure: http:\/\/t.co\/ThPYgN4Mja",
  "id" : 441312248254844928,
  "in_reply_to_status_id" : 441311597529944064,
  "created_at" : "2014-03-05 20:40:13 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Horwitz",
      "screen_name" : "horwitz",
      "indices" : [ 0, 8 ],
      "id_str" : "1720771",
      "id" : 1720771
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 24, 35 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441295027164049408",
  "geo" : { },
  "id_str" : "441295729814818816",
  "in_reply_to_user_id" : 1720771,
  "text" : "@horwitz @coworkbuffalo @kevinpurdy thanks! Nothing like some blood, sweat, tears, and constantly mopping up salt grime on our floors.",
  "id" : 441295729814818816,
  "in_reply_to_status_id" : 441295027164049408,
  "created_at" : "2014-03-05 19:34:35 +0000",
  "in_reply_to_screen_name" : "horwitz",
  "in_reply_to_user_id_str" : "1720771",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441284930904293377",
  "geo" : { },
  "id_str" : "441294358675857408",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit what's funny is that this Wegmans is one of the few of their stores in Buffalo\/Rochester that is even remotely walkable",
  "id" : 441294358675857408,
  "in_reply_to_status_id" : 441284930904293377,
  "created_at" : "2014-03-05 19:29:08 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441271966352154624",
  "geo" : { },
  "id_str" : "441272399334371328",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton do they have a veggie option now? :P",
  "id" : 441272399334371328,
  "in_reply_to_status_id" : 441271966352154624,
  "created_at" : "2014-03-05 18:01:53 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441269479855915008",
  "geo" : { },
  "id_str" : "441270254455373824",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante mostly would just mess with it via heroku\u2019s rails console. Could jump on Skype or Gtalk maybe?",
  "id" : 441270254455373824,
  "in_reply_to_status_id" : 441269479855915008,
  "created_at" : "2014-03-05 17:53:21 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Horwitz",
      "screen_name" : "horwitz",
      "indices" : [ 0, 8 ],
      "id_str" : "1720771",
      "id" : 1720771
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441255792038395904",
  "in_reply_to_user_id" : 1720771,
  "text" : "@horwitz thanks for stopping by @coworkbuffalo! Come back sometime :)",
  "id" : 441255792038395904,
  "created_at" : "2014-03-05 16:55:53 +0000",
  "in_reply_to_screen_name" : "horwitz",
  "in_reply_to_user_id_str" : "1720771",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/wCsxAXRmfr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "441240562348195840",
  "text" : "I miss the stats pages on http:\/\/t.co\/wCsxAXRmfr...we need them back.",
  "id" : 441240562348195840,
  "created_at" : "2014-03-05 15:55:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/wCsxAXRmfr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/y4kFyhchGu",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/9369942",
      "display_url" : "gist.github.com\/qrush\/9369942"
    } ]
  },
  "geo" : { },
  "id_str" : "441240446627377152",
  "text" : "While we're on http:\/\/t.co\/wCsxAXRmfr stats: 11K gems pushed in February 2014, averaging 395\/day! https:\/\/t.co\/y4kFyhchGu",
  "id" : 441240446627377152,
  "created_at" : "2014-03-05 15:54:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441235128346345472",
  "text" : "I bumped my glasses yesterday, and now my entire worldview is altered thanks to their alignment being off.",
  "id" : 441235128346345472,
  "created_at" : "2014-03-05 15:33:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "indyK1ng",
      "screen_name" : "indyK1ng",
      "indices" : [ 0, 9 ],
      "id_str" : "18765238",
      "id" : 18765238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441160213333557248",
  "geo" : { },
  "id_str" : "441225850349166592",
  "in_reply_to_user_id" : 18765238,
  "text" : "@indyK1ng well\u2026lucky that RubyGems team helped out and Ruby Central took over finances. Was around 400\/mo for just S3 in 2009",
  "id" : 441225850349166592,
  "in_reply_to_status_id" : 441160213333557248,
  "created_at" : "2014-03-05 14:56:54 +0000",
  "in_reply_to_screen_name" : "indyK1ng",
  "in_reply_to_user_id_str" : "18765238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441051298595491841",
  "geo" : { },
  "id_str" : "441051877686276096",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 wow thanks! I am not, in Buffalo NY. Visiting Chicago at the end of the month though.",
  "id" : 441051877686276096,
  "in_reply_to_status_id" : 441051298595491841,
  "created_at" : "2014-03-05 03:25:36 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 49, 57 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/V08n0wpi2S",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=7344793",
      "display_url" : "news.ycombinator.com\/item?id=7344793"
    } ]
  },
  "geo" : { },
  "id_str" : "441045204712165376",
  "text" : "An actual kind statement on HN, for once. Thanks @patio11. https:\/\/t.co\/V08n0wpi2S",
  "id" : 441045204712165376,
  "created_at" : "2014-03-05 02:59:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441029163399798784",
  "geo" : { },
  "id_str" : "441029250921951233",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y check out the first line \"Name\"",
  "id" : 441029250921951233,
  "in_reply_to_status_id" : 441029163399798784,
  "created_at" : "2014-03-05 01:55:42 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Perry",
      "screen_name" : "DeanPerry",
      "indices" : [ 0, 10 ],
      "id_str" : "5489202",
      "id" : 5489202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441024101034242048",
  "geo" : { },
  "id_str" : "441024512604135424",
  "in_reply_to_user_id" : 5489202,
  "text" : "@DeanPerry we have a few external mirrors too. Ruby Central handles financials, it is a 501.3c.",
  "id" : 441024512604135424,
  "in_reply_to_status_id" : 441024101034242048,
  "created_at" : "2014-03-05 01:36:52 +0000",
  "in_reply_to_screen_name" : "DeanPerry",
  "in_reply_to_user_id_str" : "5489202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wCsxAXRmfr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/7kgNyxS752",
      "expanded_url" : "https:\/\/db.tt\/PXNKk3rt",
      "display_url" : "db.tt\/PXNKk3rt"
    } ]
  },
  "geo" : { },
  "id_str" : "441023587525218305",
  "text" : "http:\/\/t.co\/wCsxAXRmfr's AWS bill for March: https:\/\/t.co\/7kgNyxS752 It's come a long way since one little S3 bucket...",
  "id" : 441023587525218305,
  "created_at" : "2014-03-05 01:33:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/hMzE1mrhub",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    }, {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/vpEZ8RTLWT",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/3v13d2g8klwer3d\/AWS%20-%20RubyCentral%20-%20Feb2014.pdf",
      "display_url" : "dropbox.com\/s\/3v13d2g8klwe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441014525362315265",
  "text" : "RT @evanphx: http:\/\/t.co\/hMzE1mrhub AWS bill for Feb 2014. https:\/\/t.co\/vpEZ8RTLWT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/hMzE1mrhub",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      }, {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/vpEZ8RTLWT",
        "expanded_url" : "https:\/\/www.dropbox.com\/s\/3v13d2g8klwer3d\/AWS%20-%20RubyCentral%20-%20Feb2014.pdf",
        "display_url" : "dropbox.com\/s\/3v13d2g8klwe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441009238991577089",
    "text" : "http:\/\/t.co\/hMzE1mrhub AWS bill for Feb 2014. https:\/\/t.co\/vpEZ8RTLWT",
    "id" : 441009238991577089,
    "created_at" : "2014-03-05 00:36:10 +0000",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 441014525362315265,
  "created_at" : "2014-03-05 00:57:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 9, 17 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441007142581960705",
  "geo" : { },
  "id_str" : "441008261815222272",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @mperham Yeeesh. I remember paying 400\/mo!",
  "id" : 441008261815222272,
  "in_reply_to_status_id" : 441007142581960705,
  "created_at" : "2014-03-05 00:32:17 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pourmecoffee\/status\/441004440561016832\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/uH0loc266d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh7DM7LCQAAIKgX.jpg",
      "id_str" : "441004440338710528",
      "id" : 441004440338710528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh7DM7LCQAAIKgX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 1180
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uH0loc266d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Oih0Pw5iB4",
      "expanded_url" : "http:\/\/www.ibtimes.co.uk\/niagara-falls-freezes-over-beautiful-photos-1438779",
      "display_url" : "ibtimes.co.uk\/niagara-falls-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441007011539329025",
  "text" : "RT @pourmecoffee: Niagara Falls last night (Photo: Mark Blinch\/Reuters) http:\/\/t.co\/Oih0Pw5iB4 http:\/\/t.co\/uH0loc266d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pourmecoffee\/status\/441004440561016832\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/uH0loc266d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh7DM7LCQAAIKgX.jpg",
        "id_str" : "441004440338710528",
        "id" : 441004440338710528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh7DM7LCQAAIKgX.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1180
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uH0loc266d"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/Oih0Pw5iB4",
        "expanded_url" : "http:\/\/www.ibtimes.co.uk\/niagara-falls-freezes-over-beautiful-photos-1438779",
        "display_url" : "ibtimes.co.uk\/niagara-falls-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441004440561016832",
    "text" : "Niagara Falls last night (Photo: Mark Blinch\/Reuters) http:\/\/t.co\/Oih0Pw5iB4 http:\/\/t.co\/uH0loc266d",
    "id" : 441004440561016832,
    "created_at" : "2014-03-05 00:17:06 +0000",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528514130257657856\/Ki8MgmBV_normal.jpeg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 441007011539329025,
  "created_at" : "2014-03-05 00:27:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 80, 88 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440998015386402816",
  "geo" : { },
  "id_str" : "441003185109762048",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham crazy. I can't imagine RG being anywhere close to that amount of $ \/cc @evanphx",
  "id" : 441003185109762048,
  "in_reply_to_status_id" : 440998015386402816,
  "created_at" : "2014-03-05 00:12:07 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/pdgDNGVS5t",
      "expanded_url" : "http:\/\/gifgif.media.mit.edu\/results",
      "display_url" : "gifgif.media.mit.edu\/results"
    } ]
  },
  "geo" : { },
  "id_str" : "440957251415601152",
  "text" : "Classifying gifs by emotion: http:\/\/t.co\/pdgDNGVS5t (I need this for my gifs folder)",
  "id" : 440957251415601152,
  "created_at" : "2014-03-04 21:09:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440948012291211264",
  "geo" : { },
  "id_str" : "440948261558312960",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh I have had &gt; 2 phish songs playing for a non-trivial amount of time in iTunes\/Chrome and not realized for a while",
  "id" : 440948261558312960,
  "in_reply_to_status_id" : 440948012291211264,
  "created_at" : "2014-03-04 20:33:52 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 12, 28 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440945597458444289",
  "geo" : { },
  "id_str" : "440946284342411265",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @whentheponydies my current timbuk2 is on its last legs...but has performed amazingly since 2005. wouldn't go with any else.",
  "id" : 440946284342411265,
  "in_reply_to_status_id" : 440945597458444289,
  "created_at" : "2014-03-04 20:26:01 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 23, 33 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440944258439081984",
  "geo" : { },
  "id_str" : "440944670189711360",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies yeah, @aquaranto has already notified me. need to get on it!",
  "id" : 440944670189711360,
  "in_reply_to_status_id" : 440944258439081984,
  "created_at" : "2014-03-04 20:19:36 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440900103449374721",
  "geo" : { },
  "id_str" : "440910267631677440",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer @coworkbuffalo we have a lot to sell. You can still \"pledge\" ;)",
  "id" : 440910267631677440,
  "in_reply_to_status_id" : 440900103449374721,
  "created_at" : "2014-03-04 18:02:54 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 35, 49 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/440898334484475904\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/oAGJ5pqooi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh5isvGCUAEjD17.jpg",
      "id_str" : "440898334224437249",
      "id" : 440898334224437249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh5isvGCUAEjD17.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oAGJ5pqooi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440898334484475904",
  "text" : "Last piece of Kickstarter swag for @coworkbuffalo is in! http:\/\/t.co\/oAGJ5pqooi",
  "id" : 440898334484475904,
  "created_at" : "2014-03-04 17:15:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 14, 23 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 27, 41 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Buffalo PHP",
      "screen_name" : "BuffaloPHP",
      "indices" : [ 81, 92 ],
      "id_str" : "1508773998",
      "id" : 1508773998
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 93, 101 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Buffalo PASS",
      "screen_name" : "BuffaloPASS",
      "indices" : [ 102, 114 ],
      "id_str" : "1468216825",
      "id" : 1468216825
    }, {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 115, 125 ],
      "id_str" : "817437266",
      "id" : 817437266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/80o2X9h3aF",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo\/",
      "display_url" : "openhack.github.io\/buffalo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "440879075310055424",
  "text" : "March's first @OpenHack at @coworkbuffalo is tonight! http:\/\/t.co\/80o2X9h3aF \/cc @BuffaloPHP @wnyruby @BuffaloPASS @BuffaloJS",
  "id" : 440879075310055424,
  "created_at" : "2014-03-04 15:58:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440868904676495360",
  "text" : "RT @coworkbuffalo: One of our amazing members brought bagels in today. And veggie cream cheese. You're missing out!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440868321638903808",
    "text" : "One of our amazing members brought bagels in today. And veggie cream cheese. You're missing out!",
    "id" : 440868321638903808,
    "created_at" : "2014-03-04 15:16:13 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 440868904676495360,
  "created_at" : "2014-03-04 15:18:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440697650640220161",
  "text" : "And flooded my second fort with lava because I built an up\/down stair instead of just a down stair. :|",
  "id" : 440697650640220161,
  "created_at" : "2014-03-04 03:58:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 3, 12 ],
      "id_str" : "18824526",
      "id" : 18824526
    }, {
      "name" : "Noah Kantrowitz",
      "screen_name" : "kantrn",
      "indices" : [ 71, 78 ],
      "id_str" : "1841791",
      "id" : 1841791
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jacobian\/status\/440613715247788033\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/kNk956qlUs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh1f1t4CMAA3yLg.jpg",
      "id_str" : "440613715004502016",
      "id" : 440613715004502016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh1f1t4CMAA3yLg.jpg",
      "sizes" : [ {
        "h" : 440,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kNk956qlUs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440676344666406913",
  "text" : "RT @jacobian: Everything I love about Bitcoin, in a single thread \/via @kantrn http:\/\/t.co\/kNk956qlUs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Noah Kantrowitz",
        "screen_name" : "kantrn",
        "indices" : [ 57, 64 ],
        "id_str" : "1841791",
        "id" : 1841791
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jacobian\/status\/440613715247788033\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/kNk956qlUs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh1f1t4CMAA3yLg.jpg",
        "id_str" : "440613715004502016",
        "id" : 440613715004502016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh1f1t4CMAA3yLg.jpg",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 146,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kNk956qlUs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440613715247788033",
    "text" : "Everything I love about Bitcoin, in a single thread \/via @kantrn http:\/\/t.co\/kNk956qlUs",
    "id" : 440613715247788033,
    "created_at" : "2014-03-03 22:24:30 +0000",
    "user" : {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "protected" : false,
      "id_str" : "18824526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70449715\/me-as-a-baby_normal.jpg",
      "id" : 18824526,
      "verified" : false
    }
  },
  "id" : 440676344666406913,
  "created_at" : "2014-03-04 02:33:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 0, 7 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440517270062649344",
  "geo" : { },
  "id_str" : "440647224632938496",
  "in_reply_to_user_id" : 15507545,
  "text" : "@hiteak we might do another printing if we get enough interest!",
  "id" : 440647224632938496,
  "in_reply_to_status_id" : 440517270062649344,
  "created_at" : "2014-03-04 00:37:39 +0000",
  "in_reply_to_screen_name" : "hiteak",
  "in_reply_to_user_id_str" : "15507545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FAKEGRIMLOCK",
      "screen_name" : "FAKEGRIMLOCK",
      "indices" : [ 1, 14 ],
      "id_str" : "188768528",
      "id" : 188768528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/UuYos4VsKy",
      "expanded_url" : "http:\/\/avc.com\/2014\/03\/43north-a-5mm-business-plan-competition\/#comment-1268873992",
      "display_url" : "avc.com\/2014\/03\/43nort\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440597489087811584",
  "text" : ".@FAKEGRIMLOCK on Buffalo: http:\/\/t.co\/UuYos4VsKy",
  "id" : 440597489087811584,
  "created_at" : "2014-03-03 21:20:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/gYdHwZzFOa",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "440535753777352704",
  "text" : "RT @evanphx: What do community package servers other than http:\/\/t.co\/gYdHwZzFOa do about \"name squatting\" and derelict owners?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/gYdHwZzFOa",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "440535646738714624",
    "text" : "What do community package servers other than http:\/\/t.co\/gYdHwZzFOa do about \"name squatting\" and derelict owners?",
    "id" : 440535646738714624,
    "created_at" : "2014-03-03 17:14:17 +0000",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 440535753777352704,
  "created_at" : "2014-03-03 17:14:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/440512965712678912\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Oem12V8nYe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh0ENUSCcAA5CG_.jpg",
      "id_str" : "440512965381353472",
      "id" : 440512965381353472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh0ENUSCcAA5CG_.jpg",
      "sizes" : [ {
        "h" : 1810,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1061,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2688,
        "resize" : "fit",
        "w" : 1520
      } ],
      "display_url" : "pic.twitter.com\/Oem12V8nYe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440513412901384192",
  "text" : "RT @coworkbuffalo: T-shirts are in for backers. Less than 5 days until backer party. Rolling on a Monday. http:\/\/t.co\/Oem12V8nYe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/440512965712678912\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/Oem12V8nYe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh0ENUSCcAA5CG_.jpg",
        "id_str" : "440512965381353472",
        "id" : 440512965381353472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh0ENUSCcAA5CG_.jpg",
        "sizes" : [ {
          "h" : 1810,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1061,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2688,
          "resize" : "fit",
          "w" : 1520
        } ],
        "display_url" : "pic.twitter.com\/Oem12V8nYe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440512965712678912",
    "text" : "T-shirts are in for backers. Less than 5 days until backer party. Rolling on a Monday. http:\/\/t.co\/Oem12V8nYe",
    "id" : 440512965712678912,
    "created_at" : "2014-03-03 15:44:10 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 440513412901384192,
  "created_at" : "2014-03-03 15:45:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440513204033437696",
  "geo" : { },
  "id_str" : "440513328859709442",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh you don't need any of those things to trade Magic cards!",
  "id" : 440513328859709442,
  "in_reply_to_status_id" : 440513204033437696,
  "created_at" : "2014-03-03 15:45:36 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitchell Thomas ",
      "screen_name" : "mitchbones",
      "indices" : [ 0, 11 ],
      "id_str" : "2776062463",
      "id" : 2776062463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440336428514283520",
  "geo" : { },
  "id_str" : "440510935531126784",
  "in_reply_to_user_id" : 9045272,
  "text" : "@mitchbones pretty sure the last time I did this, I roasted the entire inside of the fort.",
  "id" : 440510935531126784,
  "in_reply_to_status_id" : 440336428514283520,
  "created_at" : "2014-03-03 15:36:05 +0000",
  "in_reply_to_screen_name" : "mitchstewart08",
  "in_reply_to_user_id_str" : "9045272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 43, 57 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/SoUb3mS4Xw",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/15244",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440503420878082048",
  "text" : "RT @zobar2: Hey! Guess what's happening at @coworkbuffalo tomorrow evening? http:\/\/t.co\/SoUb3mS4Xw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 31, 45 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/SoUb3mS4Xw",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/15244",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440501616467132418",
    "text" : "Hey! Guess what's happening at @coworkbuffalo tomorrow evening? http:\/\/t.co\/SoUb3mS4Xw",
    "id" : 440501616467132418,
    "created_at" : "2014-03-03 14:59:04 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 440503420878082048,
  "created_at" : "2014-03-03 15:06:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440336124712476672",
  "text" : "Second game of dwarves going much better. Parked next to a volcano and already devising how to pipe magma out for invaders.",
  "id" : 440336124712476672,
  "created_at" : "2014-03-03 04:01:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/440332442671403009\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/3VdXNGLS1t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhxgBg0CUAA1i-_.png",
      "id_str" : "440332442679791616",
      "id" : 440332442679791616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhxgBg0CUAA1i-_.png",
      "sizes" : [ {
        "h" : 196,
        "resize" : "fit",
        "w" : 118
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 118
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 118
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 118
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 118
      } ],
      "display_url" : "pic.twitter.com\/3VdXNGLS1t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440332442671403009",
  "text" : "All day with these dwarves. http:\/\/t.co\/3VdXNGLS1t",
  "id" : 440332442671403009,
  "created_at" : "2014-03-03 03:46:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Siegel",
      "screen_name" : "jdsiegel",
      "indices" : [ 0, 9 ],
      "id_str" : "16503291",
      "id" : 16503291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440320927197179904",
  "geo" : { },
  "id_str" : "440321730851000321",
  "in_reply_to_user_id" : 16503291,
  "text" : "@jdsiegel for me it would just be a lot of pausing, silence, and then \"OH GOD\"",
  "id" : 440321730851000321,
  "in_reply_to_status_id" : 440320927197179904,
  "created_at" : "2014-03-03 03:04:16 +0000",
  "in_reply_to_screen_name" : "jdsiegel",
  "in_reply_to_user_id_str" : "16503291",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440314375690141696",
  "text" : "...he hears a groan behind him, and his slain comrade has risen from the dead! The fort falls as his undead brother strangles him to death.",
  "id" : 440314375690141696,
  "created_at" : "2014-03-03 02:35:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440314170240552960",
  "text" : "The other circles back to camp, immediately goes for a drink and to heal his wounds...",
  "id" : 440314170240552960,
  "created_at" : "2014-03-03 02:34:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440314055060758528",
  "text" : "One enters a clearing in the forest, catches his breath...and finds 4 more undead Kangaroos waiting for him.",
  "id" : 440314055060758528,
  "created_at" : "2014-03-03 02:33:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440313917529546752",
  "text" : "Then, the dwarves decide to split up. Thinking Armok will give them a break and allow one to report back of this cursed place.",
  "id" : 440313917529546752,
  "created_at" : "2014-03-03 02:33:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440313668350119937",
  "text" : "I immediately conscript everyone and they managed to take down one, with 5 deaths. The 2 dwarves remaining get chased around...",
  "id" : 440313668350119937,
  "created_at" : "2014-03-03 02:32:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440313474371973121",
  "text" : "One struts over and punches a dog through the brain, killing it instantly.",
  "id" : 440313474371973121,
  "created_at" : "2014-03-03 02:31:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440313396727005185",
  "text" : "First fort in at least already fallen. Embarked on the corner of a haunted forest. Immediately 2 undead kangaroo show up.",
  "id" : 440313396727005185,
  "created_at" : "2014-03-03 02:31:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Aimonetti",
      "screen_name" : "mattetti",
      "indices" : [ 0, 9 ],
      "id_str" : "16476741",
      "id" : 16476741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/rEyVvcLG2Q",
      "expanded_url" : "http:\/\/www.gomohu.com\/",
      "display_url" : "gomohu.com"
    } ]
  },
  "in_reply_to_status_id_str" : "440307307654565888",
  "geo" : { },
  "id_str" : "440307493416079360",
  "in_reply_to_user_id" : 16476741,
  "text" : "@mattetti better link: http:\/\/t.co\/rEyVvcLG2Q works great for us!",
  "id" : 440307493416079360,
  "in_reply_to_status_id" : 440307307654565888,
  "created_at" : "2014-03-03 02:07:41 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440306616672325633",
  "text" : "And lo, Nick set off to play Dwarf Fortress. Little does he know, he'll spend the majority of the time just figuring out where to embark.",
  "id" : 440306616672325633,
  "created_at" : "2014-03-03 02:04:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440298686698901504",
  "text" : "Who don't have I have on Hearthstone yet? I'm qrush (#1208).",
  "id" : 440298686698901504,
  "created_at" : "2014-03-03 01:32:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "indices" : [ 0, 5 ],
      "id_str" : "6603532",
      "id" : 6603532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440023032178814976",
  "geo" : { },
  "id_str" : "440176577716838400",
  "in_reply_to_user_id" : 6603532,
  "text" : "@b0rk that being sad: pairing is great. All the time though would be exhausting (for me)",
  "id" : 440176577716838400,
  "in_reply_to_status_id" : 440023032178814976,
  "created_at" : "2014-03-02 17:27:28 +0000",
  "in_reply_to_screen_name" : "b0rk",
  "in_reply_to_user_id_str" : "6603532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "indices" : [ 0, 5 ],
      "id_str" : "6603532",
      "id" : 6603532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440023032178814976",
  "geo" : { },
  "id_str" : "440176475782664192",
  "in_reply_to_user_id" : 6603532,
  "text" : "@b0rk sure: anxiety, fear of being judged, difficulty to do remotely, and higher stress from being \"on\" more than going solo",
  "id" : 440176475782664192,
  "in_reply_to_status_id" : 440023032178814976,
  "created_at" : "2014-03-02 17:27:04 +0000",
  "in_reply_to_screen_name" : "b0rk",
  "in_reply_to_user_id_str" : "6603532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 3, 18 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/PW0R6MqgCM",
      "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/at-50-the-buffalo-style-chicken-wing-has-conquered-the-world-20140301",
      "display_url" : "buffalonews.com\/city-region\/at\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440124723008008194",
  "text" : "RT @TheBuffaloNews: At 50, the Buffalo-style chicken wing has conquered the world  http:\/\/t.co\/PW0R6MqgCM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/PW0R6MqgCM",
        "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/at-50-the-buffalo-style-chicken-wing-has-conquered-the-world-20140301",
        "display_url" : "buffalonews.com\/city-region\/at\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440103633309290496",
    "text" : "At 50, the Buffalo-style chicken wing has conquered the world  http:\/\/t.co\/PW0R6MqgCM",
    "id" : 440103633309290496,
    "created_at" : "2014-03-02 12:37:37 +0000",
    "user" : {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "protected" : false,
      "id_str" : "43805270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2553395093\/xvx84nnqjk9bokm82d8p_normal.png",
      "id" : 43805270,
      "verified" : true
    }
  },
  "id" : 440124723008008194,
  "created_at" : "2014-03-02 14:01:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439951235068600320",
  "text" : "Any ACNL owners who didn't register their game *and* have the box still willing to fork over their PIN to me? Tossed mine out in the move :(",
  "id" : 439951235068600320,
  "created_at" : "2014-03-02 02:32:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439945010105294848",
  "geo" : { },
  "id_str" : "439949597331300352",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris what's a DVD?",
  "id" : 439949597331300352,
  "in_reply_to_status_id" : 439945010105294848,
  "created_at" : "2014-03-02 02:25:32 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439845541854597120",
  "geo" : { },
  "id_str" : "439846618943086592",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr seems legit! ;)",
  "id" : 439846618943086592,
  "in_reply_to_status_id" : 439845541854597120,
  "created_at" : "2014-03-01 19:36:20 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439786443666636800",
  "geo" : { },
  "id_str" : "439806206245621760",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar definitely not me!",
  "id" : 439806206245621760,
  "in_reply_to_status_id" : 439786443666636800,
  "created_at" : "2014-03-01 16:55:45 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439803999282528256",
  "geo" : { },
  "id_str" : "439805417519325184",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl nice! I have several of the Architecture series. Need to get around to submitting my Carcassonne set to CUUSOO",
  "id" : 439805417519325184,
  "in_reply_to_status_id" : 439803999282528256,
  "created_at" : "2014-03-01 16:52:37 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439803834601594880",
  "geo" : { },
  "id_str" : "439804159932772352",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer airport! Express is good enough for us, Extreme is great at Cowork.",
  "id" : 439804159932772352,
  "in_reply_to_status_id" : 439803834601594880,
  "created_at" : "2014-03-01 16:47:37 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439777193636294656",
  "text" : "Saturday morning cartoons on Prime with the little dude...AAHH Real Monsters came out in 1994?!?",
  "id" : 439777193636294656,
  "created_at" : "2014-03-01 15:00:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 3, 8 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/SVWoQFLI8s",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G4vubz942rY",
      "display_url" : "youtube.com\/watch?v=G4vubz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439742396511690752",
  "text" : "RT @beep: http:\/\/t.co\/SVWoQFLI8s is a thing i have now seen\n\napparently",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/SVWoQFLI8s",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G4vubz942rY",
        "display_url" : "youtube.com\/watch?v=G4vubz\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439739421790048257",
    "text" : "http:\/\/t.co\/SVWoQFLI8s is a thing i have now seen\n\napparently",
    "id" : 439739421790048257,
    "created_at" : "2014-03-01 12:30:22 +0000",
    "user" : {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "protected" : false,
      "id_str" : "12534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561270834401382400\/AJ669BlB_normal.png",
      "id" : 12534,
      "verified" : false
    }
  },
  "id" : 439742396511690752,
  "created_at" : "2014-03-01 12:42:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 73, 85 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439737233545777152",
  "geo" : { },
  "id_str" : "439738745525239808",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik YouTube drummers have the most ridiculous setups. You're going to @AqueousBand on the 7th right?",
  "id" : 439738745525239808,
  "in_reply_to_status_id" : 439737233545777152,
  "created_at" : "2014-03-01 12:27:41 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439736997863645184",
  "geo" : { },
  "id_str" : "439737048069468160",
  "in_reply_to_user_id" : 5743852,
  "text" : "@cmeik AUTOCORRECT",
  "id" : 439737048069468160,
  "in_reply_to_status_id" : 439736997863645184,
  "created_at" : "2014-03-01 12:20:56 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439731752118935552",
  "geo" : { },
  "id_str" : "439736997863645184",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik slapped da bass man!",
  "id" : 439736997863645184,
  "in_reply_to_status_id" : 439731752118935552,
  "created_at" : "2014-03-01 12:20:44 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439637840578609152",
  "text" : "5 epidemic cards. 1 outbreak. 2 eradications, 2 cures. Possibly the best and cleanest Pandemic game I will ever play.",
  "id" : 439637840578609152,
  "created_at" : "2014-03-01 05:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439622774252789760",
  "geo" : { },
  "id_str" : "439637423010492416",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison no, had a \"master\" deck on our end. Announced every card, which is what normally happens anyway",
  "id" : 439637423010492416,
  "in_reply_to_status_id" : 439622774252789760,
  "created_at" : "2014-03-01 05:45:04 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
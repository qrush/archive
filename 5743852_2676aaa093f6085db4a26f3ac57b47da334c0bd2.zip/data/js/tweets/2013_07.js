Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 3, 12 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Lindsay",
      "screen_name" : "not_young",
      "indices" : [ 139, 140 ],
      "id_str" : "327528552",
      "id" : 327528552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/jBLpDE8rZ6",
      "expanded_url" : "http:\/\/konklone.com\/post\/the-door-to-the-fisa-court",
      "display_url" : "konklone.com\/post\/the-door-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362783147143872512",
  "text" : "RT @konklone: Took a trip to a federal courthouse and found the FISA Court's door:  http:\/\/t.co\/jBLpDE8rZ6 No photos allowed! So: drawings \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lindsay",
        "screen_name" : "not_young",
        "indices" : [ 128, 138 ],
        "id_str" : "327528552",
        "id" : 327528552
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/jBLpDE8rZ6",
        "expanded_url" : "http:\/\/konklone.com\/post\/the-door-to-the-fisa-court",
        "display_url" : "konklone.com\/post\/the-door-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362623343037382659",
    "text" : "Took a trip to a federal courthouse and found the FISA Court's door:  http:\/\/t.co\/jBLpDE8rZ6 No photos allowed! So: drawings by @not_young.",
    "id" : 362623343037382659,
    "created_at" : "2013-07-31 17:18:36 +0000",
    "user" : {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "protected" : false,
      "id_str" : "5232171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226668113\/blue_normal.png",
      "id" : 5232171,
      "verified" : false
    }
  },
  "id" : 362783147143872512,
  "created_at" : "2013-08-01 03:53:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "indices" : [ 0, 12 ],
      "id_str" : "198661893",
      "id" : 198661893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362771454024105986",
  "geo" : { },
  "id_str" : "362781505908510720",
  "in_reply_to_user_id" : 198661893,
  "text" : "@eliseworthy woot! Fight complexity.",
  "id" : 362781505908510720,
  "in_reply_to_status_id" : 362771454024105986,
  "created_at" : "2013-08-01 03:47:05 +0000",
  "in_reply_to_screen_name" : "eliseworthy",
  "in_reply_to_user_id_str" : "198661893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/aVFhZJu1sr",
      "expanded_url" : "http:\/\/asianmack.com\/snacks",
      "display_url" : "asianmack.com\/snacks"
    } ]
  },
  "geo" : { },
  "id_str" : "362697566573445121",
  "text" : "RT @asianmack: Stop to eat the road trip snacks: http:\/\/t.co\/aVFhZJu1sr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/aVFhZJu1sr",
        "expanded_url" : "http:\/\/asianmack.com\/snacks",
        "display_url" : "asianmack.com\/snacks"
      } ]
    },
    "geo" : { },
    "id_str" : "362697383206862848",
    "text" : "Stop to eat the road trip snacks: http:\/\/t.co\/aVFhZJu1sr",
    "id" : 362697383206862848,
    "created_at" : "2013-07-31 22:12:49 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 362697566573445121,
  "created_at" : "2013-07-31 22:13:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362696923481780224",
  "text" : "RT @steveklabnik: Burnout as a service",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362695254928932865",
    "text" : "Burnout as a service",
    "id" : 362695254928932865,
    "created_at" : "2013-07-31 22:04:21 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 362696923481780224,
  "created_at" : "2013-07-31 22:10:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Violet Blue \u00AE",
      "screen_name" : "violetblue",
      "indices" : [ 3, 14 ],
      "id_str" : "5062341",
      "id" : 5062341
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHat",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362691896788795393",
  "text" : "RT @violetblue: NSA Director Alexander just told #BlackHat keynote attendees that \"we stand for freedom\" - someone shouted \"Bullshit!\" - cr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackHat",
        "indices" : [ 33, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362614194182434816",
    "text" : "NSA Director Alexander just told #BlackHat keynote attendees that \"we stand for freedom\" - someone shouted \"Bullshit!\" - crowd applauded.",
    "id" : 362614194182434816,
    "created_at" : "2013-07-31 16:42:15 +0000",
    "user" : {
      "name" : "Violet Blue \u00AE",
      "screen_name" : "violetblue",
      "protected" : false,
      "id_str" : "5062341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3563900657\/92709dfeb5faaa97a407235905f7d53d_normal.jpeg",
      "id" : 5062341,
      "verified" : true
    }
  },
  "id" : 362691896788795393,
  "created_at" : "2013-07-31 21:51:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 63, 75 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 102, 113 ],
      "id_str" : "17386551",
      "id" : 17386551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/gv4W7NqL7Y",
      "expanded_url" : "http:\/\/5by5.tv\/inbeta\/59",
      "display_url" : "5by5.tv\/inbeta\/59"
    } ]
  },
  "geo" : { },
  "id_str" : "362691028517519361",
  "text" : "RT @kevinpurdy: New &lt;In Beta&gt; up! http:\/\/t.co\/gv4W7NqL7Y @ginatrapani and I interview developer @natekontny about making Draft, previous st\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina Trapani",
        "screen_name" : "ginatrapani",
        "indices" : [ 47, 59 ],
        "id_str" : "930061",
        "id" : 930061
      }, {
        "name" : "Nathan Kontny",
        "screen_name" : "natekontny",
        "indices" : [ 86, 97 ],
        "id_str" : "17386551",
        "id" : 17386551
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/gv4W7NqL7Y",
        "expanded_url" : "http:\/\/5by5.tv\/inbeta\/59",
        "display_url" : "5by5.tv\/inbeta\/59"
      } ]
    },
    "geo" : { },
    "id_str" : "362690908010987520",
    "text" : "New &lt;In Beta&gt; up! http:\/\/t.co\/gv4W7NqL7Y @ginatrapani and I interview developer @natekontny about making Draft, previous startups, &amp; more.",
    "id" : 362690908010987520,
    "created_at" : "2013-07-31 21:47:05 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 362691028517519361,
  "created_at" : "2013-07-31 21:47:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 3, 12 ],
      "id_str" : "18824526",
      "id" : 18824526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362662034912968707",
  "text" : "RT @jacobian: You know you\u2019re a nerd when your first reaction to XKeyscore is wondering what they\u2019re using as a backing database.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362638638829404160",
    "text" : "You know you\u2019re a nerd when your first reaction to XKeyscore is wondering what they\u2019re using as a backing database.",
    "id" : 362638638829404160,
    "created_at" : "2013-07-31 18:19:23 +0000",
    "user" : {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "protected" : false,
      "id_str" : "18824526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70449715\/me-as-a-baby_normal.jpg",
      "id" : 18824526,
      "verified" : false
    }
  },
  "id" : 362662034912968707,
  "created_at" : "2013-07-31 19:52:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris",
      "screen_name" : "BassoonJokes",
      "indices" : [ 3, 16 ],
      "id_str" : "347493197",
      "id" : 347493197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362633518561497089",
  "text" : "RT @BassoonJokes: Has the mayor of Detroit tried the money cheat from Sim City 2000?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362632747191246848",
    "text" : "Has the mayor of Detroit tried the money cheat from Sim City 2000?",
    "id" : 362632747191246848,
    "created_at" : "2013-07-31 17:55:58 +0000",
    "user" : {
      "name" : "chris",
      "screen_name" : "BassoonJokes",
      "protected" : false,
      "id_str" : "347493197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2848959557\/6e03b9bf24f2235e0bde4bc9ef41cd82_normal.jpeg",
      "id" : 347493197,
      "verified" : false
    }
  },
  "id" : 362633518561497089,
  "created_at" : "2013-07-31 17:59:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 3, 9 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/YJ94frstsY",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/interactive\/2013\/jul\/31\/nsa-xkeyscore-program-full-presentation",
      "display_url" : "theguardian.com\/world\/interact\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362617822385410048",
  "text" : "RT @dozba: Page 17: \"Show me all VPN startups [..] and give me the data so I can decrypt and discover the users\" http:\/\/t.co\/YJ94frstsY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/YJ94frstsY",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/interactive\/2013\/jul\/31\/nsa-xkeyscore-program-full-presentation",
        "display_url" : "theguardian.com\/world\/interact\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362617301029236736",
    "text" : "Page 17: \"Show me all VPN startups [..] and give me the data so I can decrypt and discover the users\" http:\/\/t.co\/YJ94frstsY",
    "id" : 362617301029236736,
    "created_at" : "2013-07-31 16:54:36 +0000",
    "user" : {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "protected" : false,
      "id_str" : "44282335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537809944037191681\/kPC8Noli_normal.jpeg",
      "id" : 44282335,
      "verified" : false
    }
  },
  "id" : 362617822385410048,
  "created_at" : "2013-07-31 16:56:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 3, 17 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362610405459247104",
  "text" : "RT @garybernhardt: People who are into gemstones must hate Ruby. Just add \"gem\" to your search to make sure you only get results about gems\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360791964972625920",
    "text" : "People who are into gemstones must hate Ruby. Just add \"gem\" to your search to make sure you only get results about gemstones, guys.",
    "id" : 360791964972625920,
    "created_at" : "2013-07-26 16:01:22 +0000",
    "user" : {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "protected" : false,
      "id_str" : "809685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1170938305\/twitter_headshot_normal.png",
      "id" : 809685,
      "verified" : false
    }
  },
  "id" : 362610405459247104,
  "created_at" : "2013-07-31 16:27:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qQ8jorZtGG",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
      "display_url" : "nickelcityruby.com\/#register"
    } ]
  },
  "geo" : { },
  "id_str" : "362590795041218560",
  "text" : "RT @wnyruby: There are still some tickets available for @nickelcityruby - get them while there are still seats!! http:\/\/t.co\/qQ8jorZtGG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 43, 58 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/qQ8jorZtGG",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
        "display_url" : "nickelcityruby.com\/#register"
      } ]
    },
    "geo" : { },
    "id_str" : "362583234829225984",
    "text" : "There are still some tickets available for @nickelcityruby - get them while there are still seats!! http:\/\/t.co\/qQ8jorZtGG",
    "id" : 362583234829225984,
    "created_at" : "2013-07-31 14:39:14 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 362590795041218560,
  "created_at" : "2013-07-31 15:09:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 0, 11 ],
      "id_str" : "17386551",
      "id" : 17386551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362580354160271360",
  "geo" : { },
  "id_str" : "362582281023533056",
  "in_reply_to_user_id" : 17386551,
  "text" : "@natekontny heh, thanks! break a leg.",
  "id" : 362582281023533056,
  "in_reply_to_status_id" : 362580354160271360,
  "created_at" : "2013-07-31 14:35:26 +0000",
  "in_reply_to_screen_name" : "natekontny",
  "in_reply_to_user_id_str" : "17386551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 77, 92 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2661OVdTnh",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/31\/realestate\/commercial\/once-a-punch-line-buffalo-fights-back.html?pagewanted=all",
      "display_url" : "nytimes.com\/2013\/07\/31\/rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362578193707831297",
  "text" : "\"Buffalo Fights Back\", yet another reason I'm excited to bring people in for @nickelcityruby: http:\/\/t.co\/2661OVdTnh",
  "id" : 362578193707831297,
  "created_at" : "2013-07-31 14:19:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/mUFmAHz1Cu",
      "expanded_url" : "http:\/\/nprfreshair.tumblr.com\/post\/56969894173\/too-early-for-gangsta-rap-never-when-its-the",
      "display_url" : "nprfreshair.tumblr.com\/post\/569698941\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362575315047940096",
  "text" : "New Lonely Island. You know what to do. http:\/\/t.co\/mUFmAHz1Cu",
  "id" : 362575315047940096,
  "created_at" : "2013-07-31 14:07:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Terreri Ramos",
      "screen_name" : "jillterreri",
      "indices" : [ 0, 12 ],
      "id_str" : "46209505",
      "id" : 46209505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/hzHm8Cig9z",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=b9o7DFFimKo",
      "display_url" : "youtube.com\/watch?v=b9o7DF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "362325228703059970",
  "geo" : { },
  "id_str" : "362325432143593472",
  "in_reply_to_user_id" : 46209505,
  "text" : "@jillterreri wait a minute... http:\/\/t.co\/hzHm8Cig9z",
  "id" : 362325432143593472,
  "in_reply_to_status_id" : 362325228703059970,
  "created_at" : "2013-07-30 21:34:49 +0000",
  "in_reply_to_screen_name" : "jillterreri",
  "in_reply_to_user_id_str" : "46209505",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "indices" : [ 0, 10 ],
      "id_str" : "47494539",
      "id" : 47494539
    }, {
      "name" : "mkdir -- -rf",
      "screen_name" : "baroquebobcat",
      "indices" : [ 11, 25 ],
      "id_str" : "14247442",
      "id" : 14247442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362300379188305921",
  "geo" : { },
  "id_str" : "362300712752918528",
  "in_reply_to_user_id" : 47494539,
  "text" : "@kellabyte @baroquebobcat You Only Lock Once?",
  "id" : 362300712752918528,
  "in_reply_to_status_id" : 362300379188305921,
  "created_at" : "2013-07-30 19:56:35 +0000",
  "in_reply_to_screen_name" : "kellabyte",
  "in_reply_to_user_id_str" : "47494539",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brick n motor",
      "screen_name" : "BrickNMotor",
      "indices" : [ 0, 12 ],
      "id_str" : "702218328",
      "id" : 702218328
    }, {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 13, 25 ],
      "id_str" : "21758029",
      "id" : 21758029
    }, {
      "name" : "Larkin Square",
      "screen_name" : "larkinsquare",
      "indices" : [ 26, 39 ],
      "id_str" : "36047275",
      "id" : 36047275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/RRguAXnDfs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "in_reply_to_status_id_str" : "362248247818993665",
  "geo" : { },
  "id_str" : "362253151224602624",
  "in_reply_to_user_id" : 702218328,
  "text" : "@BrickNMotor @BuffaloEats @larkinsquare just move here, I have an uneven amount of spots on http:\/\/t.co\/RRguAXnDfs",
  "id" : 362253151224602624,
  "in_reply_to_status_id" : 362248247818993665,
  "created_at" : "2013-07-30 16:47:36 +0000",
  "in_reply_to_screen_name" : "BrickNMotor",
  "in_reply_to_user_id_str" : "702218328",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/tsknsHeu4y",
      "expanded_url" : "http:\/\/disapprovalface.com\/",
      "display_url" : "disapprovalface.com"
    } ]
  },
  "geo" : { },
  "id_str" : "361970809457213440",
  "text" : "New favorite domain: http:\/\/t.co\/tsknsHeu4y",
  "id" : 361970809457213440,
  "created_at" : "2013-07-29 22:05:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 3, 10 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/TSyB979sxn",
      "expanded_url" : "http:\/\/sethgodin.typepad.com\/seths_blog\/2013\/07\/gardens-not-buildings.html",
      "display_url" : "sethgodin.typepad.com\/seths_blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "361969231857852417",
  "text" : "RT @cpytel: \"Here we grow.\" http:\/\/t.co\/TSyB979sxn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/TSyB979sxn",
        "expanded_url" : "http:\/\/sethgodin.typepad.com\/seths_blog\/2013\/07\/gardens-not-buildings.html",
        "display_url" : "sethgodin.typepad.com\/seths_blog\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "361804917683404800",
    "text" : "\"Here we grow.\" http:\/\/t.co\/TSyB979sxn",
    "id" : 361804917683404800,
    "created_at" : "2013-07-29 11:06:29 +0000",
    "user" : {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "protected" : false,
      "id_str" : "9488922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1617210225\/headshot_normal.png",
      "id" : 9488922,
      "verified" : false
    }
  },
  "id" : 361969231857852417,
  "created_at" : "2013-07-29 21:59:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361953801814540288",
  "geo" : { },
  "id_str" : "361959789808463872",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @aquaranto Not used to that title yet.",
  "id" : 361959789808463872,
  "in_reply_to_status_id" : 361953801814540288,
  "created_at" : "2013-07-29 21:21:53 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/OojResXB4O",
      "expanded_url" : "http:\/\/onion.com\/13U8YRX",
      "display_url" : "onion.com\/13U8YRX"
    } ]
  },
  "geo" : { },
  "id_str" : "361907798126243840",
  "text" : "RT @TheOnion: Vatican Quickly Performs Damage Control On Pope\u2019s Tolerant Remarks http:\/\/t.co\/OojResXB4O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/OojResXB4O",
        "expanded_url" : "http:\/\/onion.com\/13U8YRX",
        "display_url" : "onion.com\/13U8YRX"
      } ]
    },
    "geo" : { },
    "id_str" : "361906715387641859",
    "text" : "Vatican Quickly Performs Damage Control On Pope\u2019s Tolerant Remarks http:\/\/t.co\/OojResXB4O",
    "id" : 361906715387641859,
    "created_at" : "2013-07-29 17:50:59 +0000",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3654358881\/476bd54bd9c2bc0f9a38b4e097ce6af5_normal.jpeg",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 361907798126243840,
  "created_at" : "2013-07-29 17:55:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 3, 13 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361895659453956096",
  "text" : "RT @ashfurrow: No release notes. No API diffs. \n\nIn other words, business as usual.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361895454822252545",
    "text" : "No release notes. No API diffs. \n\nIn other words, business as usual.",
    "id" : 361895454822252545,
    "created_at" : "2013-07-29 17:06:14 +0000",
    "user" : {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "protected" : false,
      "id_str" : "15536268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2566171949\/ashfurrow_square_normal.jpeg",
      "id" : 15536268,
      "verified" : false
    }
  },
  "id" : 361895659453956096,
  "created_at" : "2013-07-29 17:07:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/TFv3EWC0s7",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/husky\/comments\/1j8fcu\/do_you_trust_your_husky_off_the_leash\/cbc9due",
      "display_url" : "reddit.com\/r\/husky\/commen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "361894535976058880",
  "text" : "\"Huskies need a 'job' to focus on. Otherwise they are ADHD (A Dumb Husky Dog).\" http:\/\/t.co\/TFv3EWC0s7",
  "id" : 361894535976058880,
  "created_at" : "2013-07-29 17:02:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361866446353072128",
  "geo" : { },
  "id_str" : "361866809537867778",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape smalllll steps...",
  "id" : 361866809537867778,
  "in_reply_to_status_id" : 361866446353072128,
  "created_at" : "2013-07-29 15:12:25 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/KnxAy7fdgm",
      "expanded_url" : "http:\/\/religion.blogs.cnn.com\/2013\/07\/29\/pope-francis-on-gays-who-am-i-to-judge\/?hpt=hp_t1",
      "display_url" : "religion.blogs.cnn.com\/2013\/07\/29\/pop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "361856530221498369",
  "text" : "Small steps, but good ones: http:\/\/t.co\/KnxAy7fdgm",
  "id" : 361856530221498369,
  "created_at" : "2013-07-29 14:31:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Scalzi",
      "screen_name" : "scalzi",
      "indices" : [ 3, 10 ],
      "id_str" : "14202817",
      "id" : 14202817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361855441841561600",
  "text" : "RT @scalzi: I genuinely believe the Catholic Church had no idea what it was getting with Pope Francis. No idea at all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361854032538648576",
    "text" : "I genuinely believe the Catholic Church had no idea what it was getting with Pope Francis. No idea at all.",
    "id" : 361854032538648576,
    "created_at" : "2013-07-29 14:21:38 +0000",
    "user" : {
      "name" : "John Scalzi",
      "screen_name" : "scalzi",
      "protected" : false,
      "id_str" : "14202817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475245194\/59992708a306aaa836bf1699f8b47d5d_normal.png",
      "id" : 14202817,
      "verified" : true
    }
  },
  "id" : 361855441841561600,
  "created_at" : "2013-07-29 14:27:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Ruby Gem",
      "screen_name" : "gem",
      "indices" : [ 0, 4 ],
      "id_str" : "213747670",
      "id" : 213747670
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 5, 12 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361394389903355905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8811415803, -87.6468721933 ]
  },
  "id_str" : "361471490132152321",
  "in_reply_to_user_id" : 213747670,
  "text" : "@gem @sferik :(",
  "id" : 361471490132152321,
  "in_reply_to_status_id" : 361394389903355905,
  "created_at" : "2013-07-28 13:01:33 +0000",
  "in_reply_to_screen_name" : "gem",
  "in_reply_to_user_id_str" : "213747670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/jbJm801lGr",
      "expanded_url" : "http:\/\/weknowgifs.com\/wp-content\/uploads\/2013\/04\/baseball-player-fuck-gif.gif",
      "display_url" : "weknowgifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "361375615380750336",
  "text" : "Current status: http:\/\/t.co\/jbJm801lGr",
  "id" : 361375615380750336,
  "created_at" : "2013-07-28 06:40:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361374198033158144",
  "geo" : { },
  "id_str" : "361374675210731521",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt I didn\u2019t even consider that one. *mind melts*",
  "id" : 361374675210731521,
  "in_reply_to_status_id" : 361374198033158144,
  "created_at" : "2013-07-28 06:36:51 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361374014372982784",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt is it \u201Cveerunt\u201D or \u201Cverunt\u201D?",
  "id" : 361374014372982784,
  "created_at" : "2013-07-28 06:34:13 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 8, 17 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361336257432924161",
  "geo" : { },
  "id_str" : "361336714121326593",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @mr_ndrsn just heading down now. Where?",
  "id" : 361336714121326593,
  "in_reply_to_status_id" : 361336257432924161,
  "created_at" : "2013-07-28 04:06:00 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361321905006977024",
  "geo" : { },
  "id_str" : "361322194988572673",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt Beads?",
  "id" : 361322194988572673,
  "in_reply_to_status_id" : 361321905006977024,
  "created_at" : "2013-07-28 03:08:18 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alexander rakoczy",
      "screen_name" : "toothrot",
      "indices" : [ 0, 9 ],
      "id_str" : "14238988",
      "id" : 14238988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361319486898454529",
  "geo" : { },
  "id_str" : "361320921958580224",
  "in_reply_to_user_id" : 14238988,
  "text" : "@toothrot ughhhhh",
  "id" : 361320921958580224,
  "in_reply_to_status_id" : 361319486898454529,
  "created_at" : "2013-07-28 03:03:15 +0000",
  "in_reply_to_screen_name" : "toothrot",
  "in_reply_to_user_id_str" : "14238988",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 10, 17 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 18, 26 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361313028337188864",
  "geo" : { },
  "id_str" : "361313971443208193",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @will_j @noahhlo let me know if you guys return to the bar, or get some drinks to go!",
  "id" : 361313971443208193,
  "in_reply_to_status_id" : 361313028337188864,
  "created_at" : "2013-07-28 02:35:38 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 8, 17 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 18, 26 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361269948577882112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8422186321, -87.6264136434 ]
  },
  "id_str" : "361300806139514880",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @mr_ndrsn @noahhlo still there?",
  "id" : 361300806139514880,
  "in_reply_to_status_id" : 361269948577882112,
  "created_at" : "2013-07-28 01:43:19 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361268137087344640",
  "text" : "Why are only hobos and concessions employees at baseball games allowed to yell publicly without consequence?",
  "id" : 361268137087344640,
  "created_at" : "2013-07-27 23:33:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 20, 30 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361205661834555394",
  "text" : "Hello Chicago. It\u2019s @37signals meet up time! \uD83D\uDE01\uD83D\uDC34\uD83D\uDE31",
  "id" : 361205661834555394,
  "created_at" : "2013-07-27 19:25:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361205449934123009",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown you\u2019re hacked bro",
  "id" : 361205449934123009,
  "created_at" : "2013-07-27 19:24:24 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361173676571385856",
  "geo" : { },
  "id_str" : "361177691724062721",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV congrats! See you at the Barkyard sometime?",
  "id" : 361177691724062721,
  "in_reply_to_status_id" : 361173676571385856,
  "created_at" : "2013-07-27 17:34:06 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Shelby",
      "screen_name" : "SteveSHX",
      "indices" : [ 0, 9 ],
      "id_str" : "520674524",
      "id" : 520674524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361102638286241792",
  "geo" : { },
  "id_str" : "361138781874688001",
  "in_reply_to_user_id" : 520674524,
  "text" : "@SteveSHX Awesome!",
  "id" : 361138781874688001,
  "in_reply_to_status_id" : 361102638286241792,
  "created_at" : "2013-07-27 14:59:29 +0000",
  "in_reply_to_screen_name" : "SteveSHX",
  "in_reply_to_user_id_str" : "520674524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Shelby",
      "screen_name" : "SteveSHX",
      "indices" : [ 0, 9 ],
      "id_str" : "520674524",
      "id" : 520674524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360955924984250369",
  "geo" : { },
  "id_str" : "361098828092411907",
  "in_reply_to_user_id" : 520674524,
  "text" : "@SteveSHX 99\/night with our preferred hotel, group code on the site",
  "id" : 361098828092411907,
  "in_reply_to_status_id" : 360955924984250369,
  "created_at" : "2013-07-27 12:20:44 +0000",
  "in_reply_to_screen_name" : "SteveSHX",
  "in_reply_to_user_id_str" : "520674524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Shelby",
      "screen_name" : "SteveSHX",
      "indices" : [ 0, 9 ],
      "id_str" : "520674524",
      "id" : 520674524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/OW8oG3YUj4",
      "expanded_url" : "http:\/\/coderetreat.org\/",
      "display_url" : "coderetreat.org"
    } ]
  },
  "in_reply_to_status_id_str" : "360941246212087808",
  "geo" : { },
  "id_str" : "360946921201868800",
  "in_reply_to_user_id" : 520674524,
  "text" : "@SteveSHX there's info on it here: http:\/\/t.co\/OW8oG3YUj4 we need to get more info about that event, but we have a venue and facilitator :)",
  "id" : 360946921201868800,
  "in_reply_to_status_id" : 360941246212087808,
  "created_at" : "2013-07-27 02:17:06 +0000",
  "in_reply_to_screen_name" : "SteveSHX",
  "in_reply_to_user_id_str" : "520674524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Shelby",
      "screen_name" : "SteveSHX",
      "indices" : [ 0, 9 ],
      "id_str" : "520674524",
      "id" : 520674524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360939593169768448",
  "geo" : { },
  "id_str" : "360940416629092352",
  "in_reply_to_user_id" : 520674524,
  "text" : "@SteveSHX We're working on a definite schedule still for both, hoping to lock it down soon. Most likely 9-5.",
  "id" : 360940416629092352,
  "in_reply_to_status_id" : 360939593169768448,
  "created_at" : "2013-07-27 01:51:15 +0000",
  "in_reply_to_screen_name" : "SteveSHX",
  "in_reply_to_user_id_str" : "520674524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pascal Robert",
      "screen_name" : "pascal_robert",
      "indices" : [ 0, 14 ],
      "id_str" : "19397370",
      "id" : 19397370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360933174617968640",
  "geo" : { },
  "id_str" : "360933794011815939",
  "in_reply_to_user_id" : 19397370,
  "text" : "@pascal_robert Touched some J2EE stuff in college.",
  "id" : 360933794011815939,
  "in_reply_to_status_id" : 360933174617968640,
  "created_at" : "2013-07-27 01:24:56 +0000",
  "in_reply_to_screen_name" : "pascal_robert",
  "in_reply_to_user_id_str" : "19397370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pascal Robert",
      "screen_name" : "pascal_robert",
      "indices" : [ 3, 17 ],
      "id_str" : "19397370",
      "id" : 19397370
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360932199819788288",
  "text" : "RT @pascal_robert: .@qrush JSESSIONID = servlet server. wosid would be for WebObjects...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 1, 7 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "360924774177849344",
    "geo" : { },
    "id_str" : "360928062658985984",
    "in_reply_to_user_id" : 5743852,
    "text" : ".@qrush JSESSIONID = servlet server. wosid would be for WebObjects...",
    "id" : 360928062658985984,
    "in_reply_to_status_id" : 360924774177849344,
    "created_at" : "2013-07-27 01:02:10 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Pascal Robert",
      "screen_name" : "pascal_robert",
      "protected" : false,
      "id_str" : "19397370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521090026252169217\/nWlLYRgc_normal.jpeg",
      "id" : 19397370,
      "verified" : false
    }
  },
  "id" : 360932199819788288,
  "created_at" : "2013-07-27 01:18:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pascal Robert",
      "screen_name" : "pascal_robert",
      "indices" : [ 0, 14 ],
      "id_str" : "19397370",
      "id" : 19397370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360928062658985984",
  "geo" : { },
  "id_str" : "360932171223011328",
  "in_reply_to_user_id" : 19397370,
  "text" : "@pascal_robert ah ha. maybe not. overall: ugh",
  "id" : 360932171223011328,
  "in_reply_to_status_id" : 360928062658985984,
  "created_at" : "2013-07-27 01:18:30 +0000",
  "in_reply_to_screen_name" : "pascal_robert",
  "in_reply_to_user_id_str" : "19397370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360925225019392002",
  "geo" : { },
  "id_str" : "360925674195795968",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV given what it's stocked with, i'm surprised that wasnt a concern. :\/",
  "id" : 360925674195795968,
  "in_reply_to_status_id" : 360925225019392002,
  "created_at" : "2013-07-27 00:52:41 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360924774177849344",
  "text" : "iOS Dev center doesn't seem it went under a rewrite despite a week of downtime. Apache still serving, JSESSIONID (WebObjects?) in cookie.",
  "id" : 360924774177849344,
  "created_at" : "2013-07-27 00:49:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360920180282499074",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9225511082, -78.8810778532 ]
  },
  "id_str" : "360921425655246848",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV yessh. What happened?",
  "id" : 360921425655246848,
  "in_reply_to_status_id" : 360920180282499074,
  "created_at" : "2013-07-27 00:35:48 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enable Labs",
      "screen_name" : "enablelabs",
      "indices" : [ 3, 14 ],
      "id_str" : "163973956",
      "id" : 163973956
    }, {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 31, 43 ],
      "id_str" : "13168222",
      "id" : 13168222
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 75, 90 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/aMmFq76fuA",
      "expanded_url" : "http:\/\/www.enablelabs.com\/blog\/22",
      "display_url" : "enablelabs.com\/blog\/22"
    } ]
  },
  "geo" : { },
  "id_str" : "360891670524473344",
  "text" : "RT @enablelabs: Our president, @mark_menard, has been selected to speak at @nickelcityruby http:\/\/t.co\/aMmFq76fuA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Menard",
        "screen_name" : "mark_menard",
        "indices" : [ 15, 27 ],
        "id_str" : "13168222",
        "id" : 13168222
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 59, 74 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/aMmFq76fuA",
        "expanded_url" : "http:\/\/www.enablelabs.com\/blog\/22",
        "display_url" : "enablelabs.com\/blog\/22"
      } ]
    },
    "geo" : { },
    "id_str" : "360751180156125186",
    "text" : "Our president, @mark_menard, has been selected to speak at @nickelcityruby http:\/\/t.co\/aMmFq76fuA",
    "id" : 360751180156125186,
    "created_at" : "2013-07-26 13:19:18 +0000",
    "user" : {
      "name" : "Enable Labs",
      "screen_name" : "enablelabs",
      "protected" : false,
      "id_str" : "163973956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267165675\/EnableLabsLogoRed400_normal.png",
      "id" : 163973956,
      "verified" : false
    }
  },
  "id" : 360891670524473344,
  "created_at" : "2013-07-26 22:37:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 3, 11 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/OvSUXEE0Zz",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "360891665260617729",
  "text" : "RT @jwright: I can\u2019t believe Nickel City Ruby is not sold out yet. This will be a great conference folks.\n\nhttp:\/\/t.co\/OvSUXEE0Zz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/OvSUXEE0Zz",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "360820059364532224",
    "text" : "I can\u2019t believe Nickel City Ruby is not sold out yet. This will be a great conference folks.\n\nhttp:\/\/t.co\/OvSUXEE0Zz",
    "id" : 360820059364532224,
    "created_at" : "2013-07-26 17:53:00 +0000",
    "user" : {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "protected" : false,
      "id_str" : "77673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530926764155879424\/jWjU45VR_normal.jpeg",
      "id" : 77673,
      "verified" : false
    }
  },
  "id" : 360891665260617729,
  "created_at" : "2013-07-26 22:37:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 81, 91 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360875818781650944",
  "geo" : { },
  "id_str" : "360889842286084097",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss all day with the smart phones and the college loans and the youtubes \/cc @magnachef",
  "id" : 360889842286084097,
  "in_reply_to_status_id" : 360875818781650944,
  "created_at" : "2013-07-26 22:30:18 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360871267861135360",
  "text" : "The worst part is that if I close the PR, *I* look like the asshat.",
  "id" : 360871267861135360,
  "created_at" : "2013-07-26 21:16:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/1riNdz4vj3",
      "expanded_url" : "https:\/\/github.com\/qrush\/motion-layout\/pull\/7",
      "display_url" : "github.com\/qrush\/motion-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360869727620444161",
  "text" : "One great way to get me to respond to your pull request, insult my lack of time\/attention: https:\/\/t.co\/1riNdz4vj3",
  "id" : 360869727620444161,
  "created_at" : "2013-07-26 21:10:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 51, 62 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360837836045418498",
  "geo" : { },
  "id_str" : "360843059996540928",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr K9 Connection on Niagara, referred by one @kevinpurdy",
  "id" : 360843059996540928,
  "in_reply_to_status_id" : 360837836045418498,
  "created_at" : "2013-07-26 19:24:24 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "charley baker",
      "screen_name" : "charley_baker",
      "indices" : [ 0, 14 ],
      "id_str" : "14385792",
      "id" : 14385792
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 93, 99 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360837184036671488",
  "geo" : { },
  "id_str" : "360842986885615618",
  "in_reply_to_user_id" : 14385792,
  "text" : "@charley_baker oh man that would be awesome. life goal is to see a show (really, anyone, but @phish preferably) there",
  "id" : 360842986885615618,
  "in_reply_to_status_id" : 360837184036671488,
  "created_at" : "2013-07-26 19:24:06 +0000",
  "in_reply_to_screen_name" : "charley_baker",
  "in_reply_to_user_id_str" : "14385792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360842898352242691",
  "text" : "@juliepagano haha i'm sure we can arrange that. most likely will be boarding him days of the conf, but night before would work.",
  "id" : 360842898352242691,
  "created_at" : "2013-07-26 19:23:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360835050666864642",
  "geo" : { },
  "id_str" : "360835764491255809",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Most of the session was that, but he responded really well.",
  "id" : 360835764491255809,
  "in_reply_to_status_id" : 360835050666864642,
  "created_at" : "2013-07-26 18:55:24 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "charley baker",
      "screen_name" : "charley_baker",
      "indices" : [ 0, 14 ],
      "id_str" : "14385792",
      "id" : 14385792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360834950817259521",
  "geo" : { },
  "id_str" : "360835673688772609",
  "in_reply_to_user_id" : 14385792,
  "text" : "@charley_baker also part of why \"rush\" is in my handle :)",
  "id" : 360835673688772609,
  "in_reply_to_status_id" : 360834950817259521,
  "created_at" : "2013-07-26 18:55:03 +0000",
  "in_reply_to_screen_name" : "charley_baker",
  "in_reply_to_user_id_str" : "14385792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "charley baker",
      "screen_name" : "charley_baker",
      "indices" : [ 0, 14 ],
      "id_str" : "14385792",
      "id" : 14385792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/0pxGLQi2Jf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=VbC8BHHeZZ0",
      "display_url" : "youtube.com\/watch?v=VbC8BH\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "360833663832817664",
  "geo" : { },
  "id_str" : "360834376348614657",
  "in_reply_to_user_id" : 14385792,
  "text" : "@charley_baker http:\/\/t.co\/0pxGLQi2Jf",
  "id" : 360834376348614657,
  "in_reply_to_status_id" : 360833663832817664,
  "created_at" : "2013-07-26 18:49:53 +0000",
  "in_reply_to_screen_name" : "charley_baker",
  "in_reply_to_user_id_str" : "14385792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/360833100755902466\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/4jqiYX2wq1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQHvyxpCIAAjo9U.jpg",
      "id_str" : "360833100764291072",
      "id" : 360833100764291072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQHvyxpCIAAjo9U.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4jqiYX2wq1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360833100755902466",
  "text" : "First training day for Geddy. Have never seen him heel properly before. Life changing. http:\/\/t.co\/4jqiYX2wq1",
  "id" : 360833100755902466,
  "created_at" : "2013-07-26 18:44:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/6My8JKYsVQ",
      "expanded_url" : "http:\/\/www.speedtest.net\/my-result\/2861813017",
      "display_url" : "speedtest.net\/my-result\/2861\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360791011175313408",
  "text" : "0.05 MB\/s upload right now. AWESOME http:\/\/t.co\/6My8JKYsVQ",
  "id" : 360791011175313408,
  "created_at" : "2013-07-26 15:57:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/360776312970956800\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/qJB2QzNtcC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQG8JSqCUAAVUft.jpg",
      "id_str" : "360776312979345408",
      "id" : 360776312979345408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQG8JSqCUAAVUft.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/qJB2QzNtcC"
    } ],
    "hashtags" : [ {
      "text" : "ACNL",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360776312970956800",
  "text" : "Game of Thrones is bleeding slowly into my #ACNL game... http:\/\/t.co\/qJB2QzNtcC",
  "id" : 360776312970956800,
  "created_at" : "2013-07-26 14:59:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/X8xOaBWO1d",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/commons\/c\/c2\/Penn_Station1.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360579848521007104",
  "text" : "Another stunning photo from old Penn station, the Main Waiting Room: http:\/\/t.co\/X8xOaBWO1d",
  "id" : 360579848521007104,
  "created_at" : "2013-07-26 01:58:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/CaNOmNcCb9",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/commons\/3\/39\/NYP_LOC5.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360578550430040066",
  "text" : "Had no idea Penn Station was more than just a dismal tunnel of shops before 1963: http:\/\/t.co\/CaNOmNcCb9",
  "id" : 360578550430040066,
  "created_at" : "2013-07-26 01:53:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/nSkWNwsOMy",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=emckANIEClM",
      "display_url" : "youtube.com\/watch?v=emckAN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360574029372993537",
  "text" : "1960s era Buffalo Evening News info video. Fascinating look inside the city and newsroom. http:\/\/t.co\/nSkWNwsOMy",
  "id" : 360574029372993537,
  "created_at" : "2013-07-26 01:35:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 50, 65 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360521308330659841",
  "text" : "Fired up a Basecamp project for FAQs, etc for our @nickelcityruby speakers. I don't know how this conf would get organized without it.",
  "id" : 360521308330659841,
  "created_at" : "2013-07-25 22:05:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven R. Baker",
      "screen_name" : "srbaker",
      "indices" : [ 0, 8 ],
      "id_str" : "14106454",
      "id" : 14106454
    }, {
      "name" : "mattwynne",
      "screen_name" : "mattwynne",
      "indices" : [ 9, 19 ],
      "id_str" : "15994184",
      "id" : 15994184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "360516928005091329",
  "geo" : { },
  "id_str" : "360517748721319937",
  "in_reply_to_user_id" : 14106454,
  "text" : "@srbaker @mattwynne Both jekyll and http:\/\/t.co\/2bA9BVLhWr have plenty. As for their \"goodness\", that's up to you to decide :)",
  "id" : 360517748721319937,
  "in_reply_to_status_id" : 360516928005091329,
  "created_at" : "2013-07-25 21:51:44 +0000",
  "in_reply_to_screen_name" : "srbaker",
  "in_reply_to_user_id_str" : "14106454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 3, 6 ],
      "id_str" : "1178441",
      "id" : 1178441
    }, {
      "name" : "Paperless Post Dev",
      "screen_name" : "paperlessdev",
      "indices" : [ 12, 25 ],
      "id_str" : "435432744",
      "id" : 435432744
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aq\/status\/360507344385368064\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ZfoDAGmsQL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQDHhQmCYAA6cQl.jpg",
      "id_str" : "360507344393756672",
      "id" : 360507344393756672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQDHhQmCYAA6cQl.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/ZfoDAGmsQL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360507571267833857",
  "text" : "RT @aq: The @paperlessdev \u2018football\u2019: a deploy button inside a metal briefcase http:\/\/t.co\/ZfoDAGmsQL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paperless Post Dev",
        "screen_name" : "paperlessdev",
        "indices" : [ 4, 17 ],
        "id_str" : "435432744",
        "id" : 435432744
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aq\/status\/360507344385368064\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/ZfoDAGmsQL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQDHhQmCYAA6cQl.jpg",
        "id_str" : "360507344393756672",
        "id" : 360507344393756672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQDHhQmCYAA6cQl.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/ZfoDAGmsQL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360507344385368064",
    "text" : "The @paperlessdev \u2018football\u2019: a deploy button inside a metal briefcase http:\/\/t.co\/ZfoDAGmsQL",
    "id" : 360507344385368064,
    "created_at" : "2013-07-25 21:10:23 +0000",
    "user" : {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "protected" : false,
      "id_str" : "1178441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480436105192677376\/-LIxJ6Db_normal.jpeg",
      "id" : 1178441,
      "verified" : false
    }
  },
  "id" : 360507571267833857,
  "created_at" : "2013-07-25 21:11:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/IrAWZE22C3",
      "expanded_url" : "https:\/\/twitter.com\/ashedryden\/status\/360482490814709760",
      "display_url" : "twitter.com\/ashedryden\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360488448102109184",
  "text" : "This is fucked up: https:\/\/t.co\/IrAWZE22C3",
  "id" : 360488448102109184,
  "created_at" : "2013-07-25 19:55:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RemoteRules",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/L8obs90C8Y",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3590-becoming-remote",
      "display_url" : "37signals.com\/svn\/posts\/3590\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360487838602629121",
  "text" : "RT @dhh: Great story by Kristin about how she didn't have to leave 37signals just because she moved from Chicago: http:\/\/t.co\/L8obs90C8Y #R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RemoteRules",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/L8obs90C8Y",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3590-becoming-remote",
        "display_url" : "37signals.com\/svn\/posts\/3590\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360485233352650754",
    "text" : "Great story by Kristin about how she didn't have to leave 37signals just because she moved from Chicago: http:\/\/t.co\/L8obs90C8Y #RemoteRules",
    "id" : 360485233352650754,
    "created_at" : "2013-07-25 19:42:31 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 360487838602629121,
  "created_at" : "2013-07-25 19:52:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 3, 14 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 28, 43 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 139, 140 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Pj1Zc7RItY",
      "expanded_url" : "http:\/\/bit.ly\/13IpgNN",
      "display_url" : "bit.ly\/13IpgNN"
    } ]
  },
  "geo" : { },
  "id_str" : "360486974345326592",
  "text" : "RT @gdiBuffalo: Excited for @nickelcityruby happening this September!? Check out our Ruby on Rails class http:\/\/t.co\/Pj1Zc7RItY taught by a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 12, 27 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Joe Hsu",
        "screen_name" : "jhsu",
        "indices" : [ 130, 135 ],
        "id_str" : "33823",
        "id" : 33823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Pj1Zc7RItY",
        "expanded_url" : "http:\/\/bit.ly\/13IpgNN",
        "display_url" : "bit.ly\/13IpgNN"
      } ]
    },
    "geo" : { },
    "id_str" : "360485297626152961",
    "text" : "Excited for @nickelcityruby happening this September!? Check out our Ruby on Rails class http:\/\/t.co\/Pj1Zc7RItY taught by awesome @jhsu!",
    "id" : 360485297626152961,
    "created_at" : "2013-07-25 19:42:47 +0000",
    "user" : {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "protected" : false,
      "id_str" : "1232850504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3326614365\/de10a9f13010fc569fd25c1a6392366c_normal.png",
      "id" : 1232850504,
      "verified" : false
    }
  },
  "id" : 360486974345326592,
  "created_at" : "2013-07-25 19:49:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "janey!",
      "screen_name" : "janeylicious",
      "indices" : [ 12, 25 ],
      "id_str" : "6310822",
      "id" : 6310822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360482490814709760",
  "geo" : { },
  "id_str" : "360484820230475776",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @janeylicious \uD83D\uDE10",
  "id" : 360484820230475776,
  "in_reply_to_status_id" : 360482490814709760,
  "created_at" : "2013-07-25 19:40:53 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Las Vegas Ruby Group",
      "screen_name" : "LVRUG",
      "indices" : [ 3, 9 ],
      "id_str" : "326622887",
      "id" : 326622887
    }, {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 55, 58 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/pt9vR3qF8y",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "360465839113256962",
  "text" : "RT @LVRUG: Nickel City Ruby! Awesome line up including @j3 Only $99! http:\/\/t.co\/pt9vR3qF8y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Casimir",
        "screen_name" : "j3",
        "indices" : [ 44, 47 ],
        "id_str" : "1133971",
        "id" : 1133971
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/pt9vR3qF8y",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "360171892851740672",
    "text" : "Nickel City Ruby! Awesome line up including @j3 Only $99! http:\/\/t.co\/pt9vR3qF8y",
    "id" : 360171892851740672,
    "created_at" : "2013-07-24 22:57:25 +0000",
    "user" : {
      "name" : "Las Vegas Ruby Group",
      "screen_name" : "LVRUG",
      "protected" : false,
      "id_str" : "326622887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2185257069\/lvrug_ruby_icon_2012_normal.png",
      "id" : 326622887,
      "verified" : false
    }
  },
  "id" : 360465839113256962,
  "created_at" : "2013-07-25 18:25:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 10, 24 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360461344304144384",
  "geo" : { },
  "id_str" : "360461485496991745",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 @coworkbuffalo Been trying to get them on all the trucks. We need to order more!",
  "id" : 360461485496991745,
  "in_reply_to_status_id" : 360461344304144384,
  "created_at" : "2013-07-25 18:08:09 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Bernstein ",
      "screen_name" : "CastIrony",
      "indices" : [ 3, 13 ],
      "id_str" : "114605798",
      "id" : 114605798
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OurielOhayon\/status\/360283214004240384\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/S1CvPrPK2x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP_7rJ2CQAI7nbv.png",
      "id_str" : "360283214008434690",
      "id" : 360283214008434690,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP_7rJ2CQAI7nbv.png",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/S1CvPrPK2x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360402464706539520",
  "text" : "RT @CastIrony: Ahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahah https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OurielOhayon\/status\/360283214004240384\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/S1CvPrPK2x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BP_7rJ2CQAI7nbv.png",
        "id_str" : "360283214008434690",
        "id" : 360283214008434690,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP_7rJ2CQAI7nbv.png",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 523
        } ],
        "display_url" : "pic.twitter.com\/S1CvPrPK2x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360285794797223937",
    "text" : "Ahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahah https:\/\/t.co\/S1CvPrPK2x",
    "id" : 360285794797223937,
    "created_at" : "2013-07-25 06:30:01 +0000",
    "user" : {
      "name" : "Joel Bernstein ",
      "screen_name" : "CastIrony",
      "protected" : false,
      "id_str" : "114605798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528665369091661824\/8yOLyxvX_normal.jpeg",
      "id" : 114605798,
      "verified" : false
    }
  },
  "id" : 360402464706539520,
  "created_at" : "2013-07-25 14:13:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Devroe",
      "screen_name" : "cdevroe",
      "indices" : [ 3, 11 ],
      "id_str" : "11764",
      "id" : 11764
    }, {
      "name" : "Philip Meissner",
      "screen_name" : "pmeissner",
      "indices" : [ 59, 69 ],
      "id_str" : "26817014",
      "id" : 26817014
    }, {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 75, 86 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/l0ewR7y4QQ",
      "expanded_url" : "https:\/\/vine.co\/v\/hK0ebMpTpTB",
      "display_url" : "vine.co\/v\/hK0ebMpTpTB"
    } ]
  },
  "geo" : { },
  "id_str" : "360213792602341377",
  "text" : "RT @cdevroe: Aa far more satisfying way to use Basecamp by @pmeissner. \/cc @jasonfried https:\/\/t.co\/l0ewR7y4QQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philip Meissner",
        "screen_name" : "pmeissner",
        "indices" : [ 46, 56 ],
        "id_str" : "26817014",
        "id" : 26817014
      }, {
        "name" : "Jason Fried",
        "screen_name" : "jasonfried",
        "indices" : [ 62, 73 ],
        "id_str" : "14372143",
        "id" : 14372143
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/l0ewR7y4QQ",
        "expanded_url" : "https:\/\/vine.co\/v\/hK0ebMpTpTB",
        "display_url" : "vine.co\/v\/hK0ebMpTpTB"
      } ]
    },
    "geo" : { },
    "id_str" : "360169970786762752",
    "text" : "Aa far more satisfying way to use Basecamp by @pmeissner. \/cc @jasonfried https:\/\/t.co\/l0ewR7y4QQ",
    "id" : 360169970786762752,
    "created_at" : "2013-07-24 22:49:47 +0000",
    "user" : {
      "name" : "Colin Devroe",
      "screen_name" : "cdevroe",
      "protected" : false,
      "id_str" : "11764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478541783559729152\/yfYcYWBF_normal.jpeg",
      "id" : 11764,
      "verified" : false
    }
  },
  "id" : 360213792602341377,
  "created_at" : "2013-07-25 01:43:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cz",
      "screen_name" : "netshade",
      "indices" : [ 0, 9 ],
      "id_str" : "785416",
      "id" : 785416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360150801366257664",
  "geo" : { },
  "id_str" : "360152166628990978",
  "in_reply_to_user_id" : 785416,
  "text" : "@netshade I just need it! I turned auto garbage collection off!",
  "id" : 360152166628990978,
  "in_reply_to_status_id" : 360150801366257664,
  "created_at" : "2013-07-24 21:39:02 +0000",
  "in_reply_to_screen_name" : "netshade",
  "in_reply_to_user_id_str" : "785416",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cz",
      "screen_name" : "netshade",
      "indices" : [ 3, 12 ],
      "id_str" : "785416",
      "id" : 785416
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360152028284059648",
  "text" : "RT @netshade: @qrush coming up next on extreme hoarders",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "360144494374555650",
    "geo" : { },
    "id_str" : "360150801366257664",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush coming up next on extreme hoarders",
    "id" : 360150801366257664,
    "in_reply_to_status_id" : 360144494374555650,
    "created_at" : "2013-07-24 21:33:36 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "cz",
      "screen_name" : "netshade",
      "protected" : false,
      "id_str" : "785416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000080242025\/b5607e30094df2313e79dfd53cb23097_normal.jpeg",
      "id" : 785416,
      "verified" : false
    }
  },
  "id" : 360152028284059648,
  "created_at" : "2013-07-24 21:38:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360144494374555650",
  "text" : "$ git stash list | wc -l\n224",
  "id" : 360144494374555650,
  "created_at" : "2013-07-24 21:08:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360142976783089665",
  "geo" : { },
  "id_str" : "360143662186901505",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 Always bookmark.",
  "id" : 360143662186901505,
  "in_reply_to_status_id" : 360142976783089665,
  "created_at" : "2013-07-24 21:05:14 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/NmenEpYVEw",
      "expanded_url" : "http:\/\/mobile.peacebridge.com\/",
      "display_url" : "mobile.peacebridge.com"
    } ]
  },
  "in_reply_to_status_id_str" : "360141415717666819",
  "geo" : { },
  "id_str" : "360141636723949568",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 http:\/\/t.co\/NmenEpYVEw wait until it dies down",
  "id" : 360141636723949568,
  "in_reply_to_status_id" : 360141415717666819,
  "created_at" : "2013-07-24 20:57:11 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyFlow",
      "screen_name" : "rubyflow",
      "indices" : [ 3, 12 ],
      "id_str" : "14482752",
      "id" : 14482752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/4gWTYk9k3e",
      "expanded_url" : "http:\/\/bit.ly\/1biowV6",
      "display_url" : "bit.ly\/1biowV6"
    } ]
  },
  "geo" : { },
  "id_str" : "360141299359285248",
  "text" : "RT @rubyflow: Under 60 days until NickelCityRuby! http:\/\/t.co\/4gWTYk9k3e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/4gWTYk9k3e",
        "expanded_url" : "http:\/\/bit.ly\/1biowV6",
        "display_url" : "bit.ly\/1biowV6"
      } ]
    },
    "geo" : { },
    "id_str" : "360140951123017728",
    "text" : "Under 60 days until NickelCityRuby! http:\/\/t.co\/4gWTYk9k3e",
    "id" : 360140951123017728,
    "created_at" : "2013-07-24 20:54:28 +0000",
    "user" : {
      "name" : "RubyFlow",
      "screen_name" : "rubyflow",
      "protected" : false,
      "id_str" : "14482752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53166491\/apple-touch-icon_normal.png",
      "id" : 14482752,
      "verified" : false
    }
  },
  "id" : 360141299359285248,
  "created_at" : "2013-07-24 20:55:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt McClure",
      "screen_name" : "matt_mcclure",
      "indices" : [ 0, 13 ],
      "id_str" : "13961882",
      "id" : 13961882
    }, {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 14, 23 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360140609106878464",
  "geo" : { },
  "id_str" : "360141288059830274",
  "in_reply_to_user_id" : 13961882,
  "text" : "@matt_mcclure @fowlduck \"Power cord required (not shown).\"",
  "id" : 360141288059830274,
  "in_reply_to_status_id" : 360140609106878464,
  "created_at" : "2013-07-24 20:55:48 +0000",
  "in_reply_to_screen_name" : "matt_mcclure",
  "in_reply_to_user_id_str" : "13961882",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LazyLightning55",
      "screen_name" : "LazyLightning55",
      "indices" : [ 0, 16 ],
      "id_str" : "45477368",
      "id" : 45477368
    }, {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 44, 51 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360128850979594243",
  "geo" : { },
  "id_str" : "360131859222511616",
  "in_reply_to_user_id" : 45477368,
  "text" : "@LazyLightning55 This is killing me. I miss @mkdevo's videos already :(",
  "id" : 360131859222511616,
  "in_reply_to_status_id" : 360128850979594243,
  "created_at" : "2013-07-24 20:18:20 +0000",
  "in_reply_to_screen_name" : "LazyLightning55",
  "in_reply_to_user_id_str" : "45477368",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "360129240655609858",
  "text" : "Under 60 days to go until @nickelcityruby. $99 + $99\/night at our hotel. No other conference is going to come close! http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 360129240655609858,
  "created_at" : "2013-07-24 20:07:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/hjfUi4i1xg",
      "expanded_url" : "http:\/\/i.imgur.com\/UuG6kOE.jpg",
      "display_url" : "i.imgur.com\/UuG6kOE.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "360117988290080768",
  "text" : "\"That coward\" http:\/\/t.co\/hjfUi4i1xg",
  "id" : 360117988290080768,
  "created_at" : "2013-07-24 19:23:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360113464682876931",
  "geo" : { },
  "id_str" : "360113567619493890",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier \"Power cord required (not shown).\"",
  "id" : 360113567619493890,
  "in_reply_to_status_id" : 360113464682876931,
  "created_at" : "2013-07-24 19:05:39 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360112878960914433",
  "geo" : { },
  "id_str" : "360113042530369536",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending Senior VP of Product Engineering Human Management, Co-Founder, Instigator, Press Release",
  "id" : 360113042530369536,
  "in_reply_to_status_id" : 360112878960914433,
  "created_at" : "2013-07-24 19:03:34 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360097269212659712",
  "text" : "RT @SteveStreza: UIAeropressLongPressGestureRecognizer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360097184160546817",
    "text" : "UIAeropressLongPressGestureRecognizer",
    "id" : 360097184160546817,
    "created_at" : "2013-07-24 18:00:33 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 360097269212659712,
  "created_at" : "2013-07-24 18:00:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360086688103546881",
  "geo" : { },
  "id_str" : "360087146859724800",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo Rochester? Would love to finally thank you in person :)",
  "id" : 360087146859724800,
  "in_reply_to_status_id" : 360086688103546881,
  "created_at" : "2013-07-24 17:20:40 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360085460602732545",
  "geo" : { },
  "id_str" : "360086059268325379",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo Dang. What shows?",
  "id" : 360086059268325379,
  "in_reply_to_status_id" : 360085460602732545,
  "created_at" : "2013-07-24 17:16:21 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 14, 20 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/OwQjaqe6vS",
      "expanded_url" : "http:\/\/phish.com\/#\/news\/2013\/24\/2013-fall-tour-announced",
      "display_url" : "phish.com\/#\/news\/2013\/24\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360079947676651520",
  "text" : "4 tickets for @phish in Rochester on 10\/22 requested. Heck yes! http:\/\/t.co\/OwQjaqe6vS",
  "id" : 360079947676651520,
  "created_at" : "2013-07-24 16:52:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mark mcbride",
      "screen_name" : "mccv",
      "indices" : [ 3, 8 ],
      "id_str" : "9160152",
      "id" : 9160152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/1QcGw5ygdA",
      "expanded_url" : "http:\/\/apache.org\/foundation\/",
      "display_url" : "apache.org\/foundation\/"
    } ]
  },
  "geo" : { },
  "id_str" : "360075045319606272",
  "text" : "RT @mccv: No gender imbalance problem in software. None at all. http:\/\/t.co\/1QcGw5ygdA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/1QcGw5ygdA",
        "expanded_url" : "http:\/\/apache.org\/foundation\/",
        "display_url" : "apache.org\/foundation\/"
      } ]
    },
    "geo" : { },
    "id_str" : "360069993309814785",
    "text" : "No gender imbalance problem in software. None at all. http:\/\/t.co\/1QcGw5ygdA",
    "id" : 360069993309814785,
    "created_at" : "2013-07-24 16:12:30 +0000",
    "user" : {
      "name" : "mark mcbride",
      "screen_name" : "mccv",
      "protected" : false,
      "id_str" : "9160152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551456821412909056\/1BZIkwRf_normal.jpeg",
      "id" : 9160152,
      "verified" : false
    }
  },
  "id" : 360075045319606272,
  "created_at" : "2013-07-24 16:32:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    }, {
      "name" : "William Channer",
      "screen_name" : "williamchanner",
      "indices" : [ 110, 125 ],
      "id_str" : "61911654",
      "id" : 61911654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/gyhQxqM9Tz",
      "expanded_url" : "http:\/\/www.amazon.com\/Ways-Connect-Interface-Product-ebook\/dp\/B00DUEF14S",
      "display_url" : "amazon.com\/Ways-Connect-I\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360071432425832448",
  "text" : "RT @rjs: I released a short e-book. It's a collection of essays on product design edited from an interview by @WilliamChanner  http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "William Channer",
        "screen_name" : "williamchanner",
        "indices" : [ 101, 116 ],
        "id_str" : "61911654",
        "id" : 61911654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/gyhQxqM9Tz",
        "expanded_url" : "http:\/\/www.amazon.com\/Ways-Connect-Interface-Product-ebook\/dp\/B00DUEF14S",
        "display_url" : "amazon.com\/Ways-Connect-I\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360044820003176451",
    "text" : "I released a short e-book. It's a collection of essays on product design edited from an interview by @WilliamChanner  http:\/\/t.co\/gyhQxqM9Tz",
    "id" : 360044820003176451,
    "created_at" : "2013-07-24 14:32:29 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 360071432425832448,
  "created_at" : "2013-07-24 16:18:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/U4v62ZFpyA",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Hedonic_treadmill",
      "display_url" : "en.wikipedia.org\/wiki\/Hedonic_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360054002290917379",
  "text" : "TIL about the Hedonic treadmill: http:\/\/t.co\/U4v62ZFpyA",
  "id" : 360054002290917379,
  "created_at" : "2013-07-24 15:08:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360049677976080384",
  "geo" : { },
  "id_str" : "360049781596356608",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy wtf???",
  "id" : 360049781596356608,
  "in_reply_to_status_id" : 360049677976080384,
  "created_at" : "2013-07-24 14:52:12 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ZOocYsPC2Y",
      "expanded_url" : "https:\/\/caremad.io\/blog\/packaging-signing-not-holy-grail\/",
      "display_url" : "caremad.io\/blog\/packaging\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360047248182218752",
  "text" : "Kind of glad Python\/PyPi has similar issues with package signing that Ruby\/RubyGems has: https:\/\/t.co\/ZOocYsPC2Y",
  "id" : 360047248182218752,
  "created_at" : "2013-07-24 14:42:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turntable",
      "screen_name" : "turntablefm",
      "indices" : [ 104, 116 ],
      "id_str" : "1934900918",
      "id" : 1934900918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/BDOQzIyaPA",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "360046687345065985",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing Youngblood Brass Band: Killing Me Softly \u266B\u266A @turntablefm http:\/\/t.co\/BDOQzIyaPA",
  "id" : 360046687345065985,
  "created_at" : "2013-07-24 14:39:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 3, 14 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 55, 69 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360042388447690752",
  "text" : "RT @gdiBuffalo: Every last Friday of the month is free @CoworkBuffalo. Tired working from coffeshop or home? Check it out &amp; meet awesome lo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 39, 53 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360042089393831936",
    "text" : "Every last Friday of the month is free @CoworkBuffalo. Tired working from coffeshop or home? Check it out &amp; meet awesome local developers!",
    "id" : 360042089393831936,
    "created_at" : "2013-07-24 14:21:38 +0000",
    "user" : {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "protected" : false,
      "id_str" : "1232850504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3326614365\/de10a9f13010fc569fd25c1a6392366c_normal.png",
      "id" : 1232850504,
      "verified" : false
    }
  },
  "id" : 360042388447690752,
  "created_at" : "2013-07-24 14:22:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Advice Dog",
      "screen_name" : "BadAdviceDog",
      "indices" : [ 3, 16 ],
      "id_str" : "26144491",
      "id" : 26144491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360041898360053760",
  "text" : "RT @BadAdviceDog: Life hack:\n1.) Drink 7 million 5-Hour Energies. \n2.) Live forever.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359491319829237761",
    "text" : "Life hack:\n1.) Drink 7 million 5-Hour Energies. \n2.) Live forever.",
    "id" : 359491319829237761,
    "created_at" : "2013-07-23 01:53:04 +0000",
    "user" : {
      "name" : "Bad Advice Dog",
      "screen_name" : "BadAdviceDog",
      "protected" : false,
      "id_str" : "26144491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416268492946411520\/RIro9ryl_normal.jpeg",
      "id" : 26144491,
      "verified" : false
    }
  },
  "id" : 360041898360053760,
  "created_at" : "2013-07-24 14:20:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 0, 14 ],
      "id_str" : "679103",
      "id" : 679103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/iDHwDwMDNC",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/359705561505337344",
      "display_url" : "twitter.com\/qrush\/status\/3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "359918126600691713",
  "geo" : { },
  "id_str" : "360039302551441411",
  "in_reply_to_user_id" : 679103,
  "text" : "@travisjeffery there's no branching\/stage switching like our Rails workflow: https:\/\/t.co\/iDHwDwMDNC",
  "id" : 360039302551441411,
  "in_reply_to_status_id" : 359918126600691713,
  "created_at" : "2013-07-24 14:10:33 +0000",
  "in_reply_to_screen_name" : "travisjeffery",
  "in_reply_to_user_id_str" : "679103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greek on the Street",
      "screen_name" : "greekonstreet",
      "indices" : [ 41, 55 ],
      "id_str" : "1553702504",
      "id" : 1553702504
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 108, 119 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/RRguAXnDfs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "359791565100695554",
  "text" : "Yet another food truck in Buffalo! Added @greekonstreet to http:\/\/t.co\/RRguAXnDfs. Thanks for the heads up, @dangigante!",
  "id" : 359791565100695554,
  "created_at" : "2013-07-23 21:46:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359781523823673345",
  "geo" : { },
  "id_str" : "359781864661196802",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit irony: there's an Amazon ad smack in the middle of this article.",
  "id" : 359781864661196802,
  "in_reply_to_status_id" : 359781523823673345,
  "created_at" : "2013-07-23 21:07:35 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359775946749902850",
  "geo" : { },
  "id_str" : "359776154510569472",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave all day with these millenials and their different value systems!",
  "id" : 359776154510569472,
  "in_reply_to_status_id" : 359775946749902850,
  "created_at" : "2013-07-23 20:44:54 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Hart",
      "screen_name" : "onyxraven",
      "indices" : [ 0, 10 ],
      "id_str" : "14319947",
      "id" : 14319947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/iDHwDwMDNC",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/359705561505337344",
      "display_url" : "twitter.com\/qrush\/status\/3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "359767235281170434",
  "geo" : { },
  "id_str" : "359768188549988352",
  "in_reply_to_user_id" : 14319947,
  "text" : "@onyxraven Did you see https:\/\/t.co\/iDHwDwMDNC ? How do you handle this?",
  "id" : 359768188549988352,
  "in_reply_to_status_id" : 359767235281170434,
  "created_at" : "2013-07-23 20:13:14 +0000",
  "in_reply_to_screen_name" : "onyxraven",
  "in_reply_to_user_id_str" : "14319947",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "indices" : [ 3, 9 ],
      "id_str" : "12602932",
      "id" : 12602932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359767470057340928",
  "text" : "RT @wilto: It was dumb making websites that looked like iOS\u2014now we gotta update them to look like iOS7!\n\nAt least this definitely won\u2019t hap\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359763538589384705",
    "text" : "It was dumb making websites that looked like iOS\u2014now we gotta update them to look like iOS7!\n\nAt least this definitely won\u2019t happen again!",
    "id" : 359763538589384705,
    "created_at" : "2013-07-23 19:54:46 +0000",
    "user" : {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "protected" : false,
      "id_str" : "12602932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477441227986444289\/KHCUqTis_normal.png",
      "id" : 12602932,
      "verified" : false
    }
  },
  "id" : 359767470057340928,
  "created_at" : "2013-07-23 20:10:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Hart",
      "screen_name" : "onyxraven",
      "indices" : [ 0, 10 ],
      "id_str" : "14319947",
      "id" : 14319947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359764352129187840",
  "geo" : { },
  "id_str" : "359766826999218177",
  "in_reply_to_user_id" : 14319947,
  "text" : "@onyxraven This isn't even a UI thing. And we don't use IB anyway. This just straight up normal features.",
  "id" : 359766826999218177,
  "in_reply_to_status_id" : 359764352129187840,
  "created_at" : "2013-07-23 20:07:50 +0000",
  "in_reply_to_screen_name" : "onyxraven",
  "in_reply_to_user_id_str" : "14319947",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 8, 15 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359741398876037120",
  "geo" : { },
  "id_str" : "359757450825576448",
  "in_reply_to_user_id" : 5743852,
  "text" : "@gabebw @jayroh best part: Spent a lot of money on underground fence, won't shit outside now, doesn't have enough now for training.",
  "id" : 359757450825576448,
  "in_reply_to_status_id" : 359741398876037120,
  "created_at" : "2013-07-23 19:30:34 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359755278213849089",
  "geo" : { },
  "id_str" : "359756403851804674",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej literally every time crossing the US\/CAN border now with friends: \"PAPERS PLEASE\"",
  "id" : 359756403851804674,
  "in_reply_to_status_id" : 359755278213849089,
  "created_at" : "2013-07-23 19:26:25 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    }, {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 7, 22 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359742488304558082",
  "geo" : { },
  "id_str" : "359743564390998016",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy @MarkVillacampa Haven't heard of this approach. Have you used it? Any posts\/docs?",
  "id" : 359743564390998016,
  "in_reply_to_status_id" : 359742488304558082,
  "created_at" : "2013-07-23 18:35:24 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359741398876037120",
  "text" : "\"I am in desperate need of training advice.\" *stories of husky destruction, running away, etc* \"Have you been to an actual trainer?\" \"No\"",
  "id" : 359741398876037120,
  "created_at" : "2013-07-23 18:26:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/jeZ5gksePl",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3535-beyond-the-default-rails-environments",
      "display_url" : "37signals.com\/svn\/posts\/3535\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "359738515992477699",
  "geo" : { },
  "id_str" : "359739924632707072",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa http:\/\/t.co\/jeZ5gksePl",
  "id" : 359739924632707072,
  "in_reply_to_status_id" : 359738515992477699,
  "created_at" : "2013-07-23 18:20:56 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Brian Griffey",
      "screen_name" : "briangriffey",
      "indices" : [ 8, 21 ],
      "id_str" : "24887250",
      "id" : 24887250
    }, {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 22, 35 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359734987064475648",
  "geo" : { },
  "id_str" : "359736139973799936",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss @briangriffey @jonathanpenn I'm talking about developing two different features (on different branches), and shipping both.",
  "id" : 359736139973799936,
  "in_reply_to_status_id" : 359734987064475648,
  "created_at" : "2013-07-23 18:05:54 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359734648697393153",
  "text" : "900,000 iOS apps and *none* of them *ever* have multiple, concurrent features in dev? There has to be way to do this that doesn't suck.",
  "id" : 359734648697393153,
  "created_at" : "2013-07-23 17:59:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 0, 13 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/iDHwDwMDNC",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/359705561505337344",
      "display_url" : "twitter.com\/qrush\/status\/3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "359730926827220992",
  "geo" : { },
  "id_str" : "359731722021126144",
  "in_reply_to_user_id" : 9896112,
  "text" : "@jonathanpenn you missed this tweet: https:\/\/t.co\/iDHwDwMDNC basically there's no branches\/feature switches built in.",
  "id" : 359731722021126144,
  "in_reply_to_status_id" : 359730926827220992,
  "created_at" : "2013-07-23 17:48:20 +0000",
  "in_reply_to_screen_name" : "jonathanpenn",
  "in_reply_to_user_id_str" : "9896112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359730173542809601",
  "geo" : { },
  "id_str" : "359730622832447488",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej BUT NO! MY WIFE GOT IN!!! *closes window, punches detain button*",
  "id" : 359730622832447488,
  "in_reply_to_status_id" : 359730173542809601,
  "created_at" : "2013-07-23 17:43:58 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359718224385949698",
  "geo" : { },
  "id_str" : "359718790461784065",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald Was mostly trolling. Having used vim for ios dev for the past year or so it's been fantastic.",
  "id" : 359718790461784065,
  "in_reply_to_status_id" : 359718224385949698,
  "created_at" : "2013-07-23 16:56:57 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359717963961606146",
  "geo" : { },
  "id_str" : "359718138218151938",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald Vim?",
  "id" : 359718138218151938,
  "in_reply_to_status_id" : 359717963961606146,
  "created_at" : "2013-07-23 16:54:22 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359712075909574656",
  "text" : "\"Amherst is one safest towns in America, and Zombie Free!\" Actual craigslist listing.",
  "id" : 359712075909574656,
  "created_at" : "2013-07-23 16:30:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Kocurek",
      "screen_name" : "trentkocurek",
      "indices" : [ 0, 13 ],
      "id_str" : "16450691",
      "id" : 16450691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359709183316197377",
  "geo" : { },
  "id_str" : "359710664119435265",
  "in_reply_to_user_id" : 16450691,
  "text" : "@trentkocurek I can't believe it's this bad. What about large teams working on an app?",
  "id" : 359710664119435265,
  "in_reply_to_status_id" : 359709183316197377,
  "created_at" : "2013-07-23 16:24:40 +0000",
  "in_reply_to_screen_name" : "trentkocurek",
  "in_reply_to_user_id_str" : "16450691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359704255893995520",
  "geo" : { },
  "id_str" : "359705561505337344",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa No, Dev A is working on Feature B, Dev C is working on Feature D. B &amp; D need to share one App ID. There's no branching. :(",
  "id" : 359705561505337344,
  "in_reply_to_status_id" : 359704255893995520,
  "created_at" : "2013-07-23 16:04:23 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359703093379739649",
  "text" : "iOS devs: how do you handle multiple features\/branches but still deploying\/shipping to just one App ID? Does not seem easy.",
  "id" : 359703093379739649,
  "created_at" : "2013-07-23 15:54:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ZgIksdTRAA",
      "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/56232015979\/new-in-rubymotion-blocks-rewrite-retain-cycle",
      "display_url" : "blog.rubymotion.com\/post\/562320159\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "359695906460794880",
  "text" : "\"The RubyMotion runtime has been improved to detect and break basic cyclic references.\" http:\/\/t.co\/ZgIksdTRAA",
  "id" : 359695906460794880,
  "created_at" : "2013-07-23 15:26:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359694477679529985",
  "geo" : { },
  "id_str" : "359695256276574208",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan Now you're using an oculus rift? I can never trust you.",
  "id" : 359695256276574208,
  "in_reply_to_status_id" : 359694477679529985,
  "created_at" : "2013-07-23 15:23:26 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359694145377415170",
  "geo" : { },
  "id_str" : "359694257377910785",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan You took that from a window.",
  "id" : 359694257377910785,
  "in_reply_to_status_id" : 359694145377415170,
  "created_at" : "2013-07-23 15:19:28 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359693678517825538",
  "geo" : { },
  "id_str" : "359693918394253313",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw ActiveHogwarts",
  "id" : 359693918394253313,
  "in_reply_to_status_id" : 359693678517825538,
  "created_at" : "2013-07-23 15:18:07 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Thompson",
      "screen_name" : "keiththomps",
      "indices" : [ 0, 12 ],
      "id_str" : "142860206",
      "id" : 142860206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359682658588045312",
  "geo" : { },
  "id_str" : "359693381053591552",
  "in_reply_to_user_id" : 142860206,
  "text" : "@keiththomps Woot! :) It's really not that much code.",
  "id" : 359693381053591552,
  "in_reply_to_status_id" : 359682658588045312,
  "created_at" : "2013-07-23 15:15:59 +0000",
  "in_reply_to_screen_name" : "keiththomps",
  "in_reply_to_user_id_str" : "142860206",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pea53",
      "screen_name" : "pea53",
      "indices" : [ 3, 9 ],
      "id_str" : "17429985",
      "id" : 17429985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359556093648699392",
  "text" : "RT @pea53: I've just sucked 1GB of your memory away. I might one day go as high as five, but I really don't know what that would do to you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359552311313444864",
    "text" : "I've just sucked 1GB of your memory away. I might one day go as high as five, but I really don't know what that would do to you.",
    "id" : 359552311313444864,
    "created_at" : "2013-07-23 05:55:25 +0000",
    "user" : {
      "name" : "pea53",
      "screen_name" : "pea53",
      "protected" : false,
      "id_str" : "17429985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445016404828241920\/M4M2TGl0_normal.png",
      "id" : 17429985,
      "verified" : false
    }
  },
  "id" : 359556093648699392,
  "created_at" : "2013-07-23 06:10:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359352226134757376",
  "geo" : { },
  "id_str" : "359352896007057408",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan @carvere08 i'm convinced you guys never go outside.",
  "id" : 359352896007057408,
  "in_reply_to_status_id" : 359352226134757376,
  "created_at" : "2013-07-22 16:43:01 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359322049895858178",
  "text" : "RT @aquaranto: @qrush on watching Battlestar Galactica: \"If I assume everyone is a Cylon, it'll be a surprise when they're actually human.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359315258634027013",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush on watching Battlestar Galactica: \"If I assume everyone is a Cylon, it'll be a surprise when they're actually human.\"",
    "id" : 359315258634027013,
    "created_at" : "2013-07-22 14:13:28 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 359322049895858178,
  "created_at" : "2013-07-22 14:40:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Source Offsets",
      "screen_name" : "opensource",
      "indices" : [ 0, 11 ],
      "id_str" : "419159838",
      "id" : 419159838
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 52, 61 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359125672964276224",
  "geo" : { },
  "id_str" : "359126721607372800",
  "in_reply_to_user_id" : 419159838,
  "text" : "@opensource @steveklabnik my vote is biased but for @openhack :)",
  "id" : 359126721607372800,
  "in_reply_to_status_id" : 359125672964276224,
  "created_at" : "2013-07-22 01:44:17 +0000",
  "in_reply_to_screen_name" : "opensource",
  "in_reply_to_user_id_str" : "419159838",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 3, 11 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359126326013198336",
  "text" : "RT @dcurtis: Q: What's the best thing to do after a huge security breach?\n\nA: Probably not this: tell no one for 3 days, then send poorly-w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359083925546598400",
    "text" : "Q: What's the best thing to do after a huge security breach?\n\nA: Probably not this: tell no one for 3 days, then send poorly-worded email.",
    "id" : 359083925546598400,
    "created_at" : "2013-07-21 22:54:13 +0000",
    "user" : {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "protected" : false,
      "id_str" : "9395832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542085734891413506\/cn-9G425_normal.png",
      "id" : 9395832,
      "verified" : false
    }
  },
  "id" : 359126326013198336,
  "created_at" : "2013-07-22 01:42:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359068894721347584",
  "geo" : { },
  "id_str" : "359070656303869954",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh I know, how messed up!!",
  "id" : 359070656303869954,
  "in_reply_to_status_id" : 359068894721347584,
  "created_at" : "2013-07-21 22:01:30 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACNL",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359057710244827136",
  "text" : "And that\u2019s twice I\u2019ve sold my fishing rod in #ACNL. Derp.",
  "id" : 359057710244827136,
  "created_at" : "2013-07-21 21:10:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ferris & Cameron",
      "screen_name" : "ruby_make_happy",
      "indices" : [ 0, 16 ],
      "id_str" : "506544731",
      "id" : 506544731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359052859314147328",
  "geo" : { },
  "id_str" : "359056926472019968",
  "in_reply_to_user_id" : 506544731,
  "text" : "@ruby_make_happy yes, stop worrying!",
  "id" : 359056926472019968,
  "in_reply_to_status_id" : 359052859314147328,
  "created_at" : "2013-07-21 21:06:56 +0000",
  "in_reply_to_screen_name" : "ruby_make_happy",
  "in_reply_to_user_id_str" : "506544731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 59, 67 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ZBJ5Edjupu",
      "expanded_url" : "http:\/\/www.nytimes.com\/newsgraphics\/2013\/07\/21\/silk-road\/",
      "display_url" : "nytimes.com\/newsgraphics\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "359047243170463744",
  "text" : "Beautiful use of motion and video in storytelling from the @nytimes. No one else is even coming close. http:\/\/t.co\/ZBJ5Edjupu",
  "id" : 359047243170463744,
  "created_at" : "2013-07-21 20:28:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359028330646872064",
  "geo" : { },
  "id_str" : "359035440642260992",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh if you\u2019re up for visiting a town where a horse\u2019s name is Elmer: 2363-6310-1548",
  "id" : 359035440642260992,
  "in_reply_to_status_id" : 359028330646872064,
  "created_at" : "2013-07-21 19:41:34 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 43, 56 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Jessica Suttles",
      "screen_name" : "jlsuttles",
      "indices" : [ 57, 67 ],
      "id_str" : "21170138",
      "id" : 21170138
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 68, 80 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358795733530460160",
  "geo" : { },
  "id_str" : "358796336516186113",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove you have been missing out. \/cc @steveklabnik @jlsuttles @coreyhaines",
  "id" : 358796336516186113,
  "in_reply_to_status_id" : 358795733530460160,
  "created_at" : "2013-07-21 03:51:27 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Saffron",
      "screen_name" : "samsaffron",
      "indices" : [ 0, 11 ],
      "id_str" : "23302930",
      "id" : 23302930
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358769044033253377",
  "geo" : { },
  "id_str" : "358771607214362624",
  "in_reply_to_user_id" : 23302930,
  "text" : "@samsaffron @steveklabnik that\u2019s usually how upgrades work, at least for 1-2, 2-3. What\u2019s wrong with just flipping it?",
  "id" : 358771607214362624,
  "in_reply_to_status_id" : 358769044033253377,
  "created_at" : "2013-07-21 02:13:11 +0000",
  "in_reply_to_screen_name" : "samsaffron",
  "in_reply_to_user_id_str" : "23302930",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Saffron",
      "screen_name" : "samsaffron",
      "indices" : [ 0, 11 ],
      "id_str" : "23302930",
      "id" : 23302930
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358752660586897408",
  "geo" : { },
  "id_str" : "358767639960625153",
  "in_reply_to_user_id" : 23302930,
  "text" : "@samsaffron @steveklabnik why would you ever want to do this?",
  "id" : 358767639960625153,
  "in_reply_to_status_id" : 358752660586897408,
  "created_at" : "2013-07-21 01:57:25 +0000",
  "in_reply_to_screen_name" : "samsaffron",
  "in_reply_to_user_id_str" : "23302930",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 8, 23 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/yhjteaaViy",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "358615214977073152",
  "text" : "$99 for @nickelcityruby and $99\/night deal with our hotel. You really can't get any better than this. http:\/\/t.co\/yhjteaaViy",
  "id" : 358615214977073152,
  "created_at" : "2013-07-20 15:51:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 5, 11 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/TeXBgB8CR6",
      "expanded_url" : "http:\/\/phish.net\/setlists\/twenty-minute-jams.php",
      "display_url" : "phish.net\/setlists\/twent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358614163628638210",
  "text" : "Only @phish need a list of 20 min+ jams compiled: http:\/\/t.co\/TeXBgB8CR6",
  "id" : 358614163628638210,
  "created_at" : "2013-07-20 15:47:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SHIBATA Hiroshi",
      "screen_name" : "hsbt",
      "indices" : [ 0, 5 ],
      "id_str" : "3408881",
      "id" : 3408881
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 6, 17 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 72, 80 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 81, 89 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358430970543742976",
  "geo" : { },
  "id_str" : "358433178832216065",
  "in_reply_to_user_id" : 3408881,
  "text" : "@hsbt @tenderlove that\u2019s no good :( got a gist of what\u2019s happening? \/cc @evanphx @drbrain",
  "id" : 358433178832216065,
  "in_reply_to_status_id" : 358430970543742976,
  "created_at" : "2013-07-20 03:48:23 +0000",
  "in_reply_to_screen_name" : "hsbt",
  "in_reply_to_user_id_str" : "3408881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Sasso",
      "screen_name" : "WillSasso",
      "indices" : [ 3, 13 ],
      "id_str" : "14771122",
      "id" : 14771122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358427204943740930",
  "text" : "RT @WillSasso: Just got to ComiCon! So cool! Saw Wolverine walking down the street with all his fans! He's gained 200lbs and was drinking M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357978156071796739",
    "text" : "Just got to ComiCon! So cool! Saw Wolverine walking down the street with all his fans! He's gained 200lbs and was drinking Mountain Dew! :D",
    "id" : 357978156071796739,
    "created_at" : "2013-07-18 21:40:17 +0000",
    "user" : {
      "name" : "Will Sasso",
      "screen_name" : "WillSasso",
      "protected" : false,
      "id_str" : "14771122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000254663300\/91ca5467fe6e111e33de587828209f22_normal.jpeg",
      "id" : 14771122,
      "verified" : true
    }
  },
  "id" : 358427204943740930,
  "created_at" : "2013-07-20 03:24:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358417405103841280",
  "geo" : { },
  "id_str" : "358420423341391872",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo What a bummer. Second show that's been postponed for me. Think they'll refund the streams?",
  "id" : 358420423341391872,
  "in_reply_to_status_id" : 358417405103841280,
  "created_at" : "2013-07-20 02:57:42 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358418522822549504",
  "geo" : { },
  "id_str" : "358419333057224704",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity Downtown, in Ontario Place.",
  "id" : 358419333057224704,
  "in_reply_to_status_id" : 358418522822549504,
  "created_at" : "2013-07-20 02:53:22 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358417430495768577",
  "geo" : { },
  "id_str" : "358417852258189312",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity I had 2 extra tickets to Toronto that I sold in the lot before they postponed it :(",
  "id" : 358417852258189312,
  "in_reply_to_status_id" : 358417430495768577,
  "created_at" : "2013-07-20 02:47:29 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358416465843589121",
  "geo" : { },
  "id_str" : "358416774422732801",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity Geez! Yeah they just shut it down. What a bummer.",
  "id" : 358416774422732801,
  "in_reply_to_status_id" : 358416465843589121,
  "created_at" : "2013-07-20 02:43:12 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 13, 19 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 76, 85 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358415522573975554",
  "text" : "And that's 2 @phish shows postponed by bad weather that I've wanted to see. @LawnMemo I hope you make it out ok!",
  "id" : 358415522573975554,
  "created_at" : "2013-07-20 02:38:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 6, 12 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/358414297728172032\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/OPH6oUgXGz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPlX56LCQAMYs7L.jpg",
      "id_str" : "358414297732366339",
      "id" : 358414297732366339,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPlX56LCQAMYs7L.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OPH6oUgXGz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358414297728172032",
  "text" : "Couch @phish tour and the sky lit up by some extreme lightening. \u26A1\uD83D\uDC1F http:\/\/t.co\/OPH6oUgXGz",
  "id" : 358414297728172032,
  "created_at" : "2013-07-20 02:33:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "indices" : [ 3, 13 ],
      "id_str" : "14807622",
      "id" : 14807622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358414008438632448",
  "text" : "RT @chazadams: This storm is easily the art voice thunder storm of 2013 winner",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358412804979572736",
    "text" : "This storm is easily the art voice thunder storm of 2013 winner",
    "id" : 358412804979572736,
    "created_at" : "2013-07-20 02:27:26 +0000",
    "user" : {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "protected" : false,
      "id_str" : "14807622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569604358279794688\/N9fXZs9b_normal.jpeg",
      "id" : 14807622,
      "verified" : false
    }
  },
  "id" : 358414008438632448,
  "created_at" : "2013-07-20 02:32:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/1Cn4aRfrQ6",
      "expanded_url" : "http:\/\/emotibot.net\/pix\/1274.png",
      "display_url" : "emotibot.net\/pix\/1274.png"
    } ]
  },
  "in_reply_to_status_id_str" : "358410892246908928",
  "geo" : { },
  "id_str" : "358411454484983808",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 http:\/\/t.co\/1Cn4aRfrQ6",
  "id" : 358411454484983808,
  "in_reply_to_status_id" : 358410892246908928,
  "created_at" : "2013-07-20 02:22:04 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358411332929847296",
  "text" : "This lightning is literally on top of my house.",
  "id" : 358411332929847296,
  "created_at" : "2013-07-20 02:21:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "SiriusXM JamON",
      "screen_name" : "SXMJamON",
      "indices" : [ 8, 17 ],
      "id_str" : "623102237",
      "id" : 623102237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358410841449701377",
  "geo" : { },
  "id_str" : "358410977097691138",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @SXMJamON So good! My redeye back from SF was made immensely better thanks to a 94 (?) show.",
  "id" : 358410977097691138,
  "in_reply_to_status_id" : 358410841449701377,
  "created_at" : "2013-07-20 02:20:10 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358410150962413571",
  "text" : "This storm just got real in Buffalo. Lots of lightning, high wind. Dog not happy.",
  "id" : 358410150962413571,
  "created_at" : "2013-07-20 02:16:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358409488446930944",
  "geo" : { },
  "id_str" : "358409959203020800",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky Couch tour? Want the stream?",
  "id" : 358409959203020800,
  "in_reply_to_status_id" : 358409488446930944,
  "created_at" : "2013-07-20 02:16:07 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358404680465936384",
  "geo" : { },
  "id_str" : "358404992920592385",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown Tell those rain clouds to stay away! Can you hear it from that far?",
  "id" : 358404992920592385,
  "in_reply_to_status_id" : 358404680465936384,
  "created_at" : "2013-07-20 01:56:23 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358402590758805504",
  "geo" : { },
  "id_str" : "358402982892683264",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius check your goddamn privilege",
  "id" : 358402982892683264,
  "in_reply_to_status_id" : 358402590758805504,
  "created_at" : "2013-07-20 01:48:24 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ferris & Cameron",
      "screen_name" : "ruby_make_happy",
      "indices" : [ 0, 16 ],
      "id_str" : "506544731",
      "id" : 506544731
    }, {
      "name" : "Bitmaker Labs",
      "screen_name" : "bitmakerlabs",
      "indices" : [ 17, 30 ],
      "id_str" : "853592048",
      "id" : 853592048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358397227678449665",
  "geo" : { },
  "id_str" : "358398027683201024",
  "in_reply_to_user_id" : 506544731,
  "text" : "@ruby_make_happy @bitmakerlabs Sure, hit me up: nick [at] quaran.to",
  "id" : 358398027683201024,
  "in_reply_to_status_id" : 358397227678449665,
  "created_at" : "2013-07-20 01:28:43 +0000",
  "in_reply_to_screen_name" : "ruby_make_happy",
  "in_reply_to_user_id_str" : "506544731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 0, 11 ],
      "id_str" : "15020118",
      "id" : 15020118
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 31, 37 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358395412291387392",
  "geo" : { },
  "id_str" : "358395575776972801",
  "in_reply_to_user_id" : 15020118,
  "text" : "@jaytennier Couch touring some @phish at home hoping the power doesn't cut out. Pouring now in EV.",
  "id" : 358395575776972801,
  "in_reply_to_status_id" : 358395412291387392,
  "created_at" : "2013-07-20 01:18:58 +0000",
  "in_reply_to_screen_name" : "jaytennier",
  "in_reply_to_user_id_str" : "15020118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358393431803969537",
  "geo" : { },
  "id_str" : "358394127152455681",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown Dude!",
  "id" : 358394127152455681,
  "in_reply_to_status_id" : 358393431803969537,
  "created_at" : "2013-07-20 01:13:13 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cz",
      "screen_name" : "netshade",
      "indices" : [ 0, 9 ],
      "id_str" : "785416",
      "id" : 785416
    }, {
      "name" : "Alec Gorge",
      "screen_name" : "alecgorge",
      "indices" : [ 10, 20 ],
      "id_str" : "20488553",
      "id" : 20488553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358391295577829380",
  "geo" : { },
  "id_str" : "358391626609074177",
  "in_reply_to_user_id" : 785416,
  "text" : "@netshade @alecgorge Sweet!",
  "id" : 358391626609074177,
  "in_reply_to_status_id" : 358391295577829380,
  "created_at" : "2013-07-20 01:03:17 +0000",
  "in_reply_to_screen_name" : "netshade",
  "in_reply_to_user_id_str" : "785416",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ferris & Cameron",
      "screen_name" : "ruby_make_happy",
      "indices" : [ 0, 16 ],
      "id_str" : "506544731",
      "id" : 506544731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358391382840320000",
  "geo" : { },
  "id_str" : "358391560070639618",
  "in_reply_to_user_id" : 506544731,
  "text" : "@ruby_make_happy Just for the concert. I live in Buffalo...not that far!",
  "id" : 358391560070639618,
  "in_reply_to_status_id" : 358391382840320000,
  "created_at" : "2013-07-20 01:03:01 +0000",
  "in_reply_to_screen_name" : "ruby_make_happy",
  "in_reply_to_user_id_str" : "506544731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ferris & Cameron",
      "screen_name" : "ruby_make_happy",
      "indices" : [ 0, 16 ],
      "id_str" : "506544731",
      "id" : 506544731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358390612896120834",
  "geo" : { },
  "id_str" : "358391003914321920",
  "in_reply_to_user_id" : 506544731,
  "text" : "@ruby_make_happy nope, i'll be heading up for Monday's show though.",
  "id" : 358391003914321920,
  "in_reply_to_status_id" : 358390612896120834,
  "created_at" : "2013-07-20 01:00:48 +0000",
  "in_reply_to_screen_name" : "ruby_make_happy",
  "in_reply_to_user_id_str" : "506544731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358388503391899648",
  "text" : "Phish live stream time. Can't wait for Toronto!",
  "id" : 358388503391899648,
  "created_at" : "2013-07-20 00:50:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drewtoothpaste",
      "screen_name" : "drewtoothpaste",
      "indices" : [ 0, 15 ],
      "id_str" : "14248784",
      "id" : 14248784
    }, {
      "name" : "diego",
      "screen_name" : "flawbot",
      "indices" : [ 16, 24 ],
      "id_str" : "13705192",
      "id" : 13705192
    }, {
      "name" : "Allyson",
      "screen_name" : "Ally_Keck",
      "indices" : [ 25, 35 ],
      "id_str" : "41035556",
      "id" : 41035556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358377868914462720",
  "geo" : { },
  "id_str" : "358379086856454144",
  "in_reply_to_user_id" : 14248784,
  "text" : "@drewtoothpaste @flawbot @Ally_Keck up for more? Can\u2019t play tonight but my code is 2363-6310-1548",
  "id" : 358379086856454144,
  "in_reply_to_status_id" : 358377868914462720,
  "created_at" : "2013-07-20 00:13:27 +0000",
  "in_reply_to_screen_name" : "drewtoothpaste",
  "in_reply_to_user_id_str" : "14248784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 0, 11 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358361837098008576",
  "geo" : { },
  "id_str" : "358366693711548416",
  "in_reply_to_user_id" : 15020118,
  "text" : "@jaytennier just kidding, it got grossly gray out in around 20 mins! Geez. Stay safe.",
  "id" : 358366693711548416,
  "in_reply_to_status_id" : 358361837098008576,
  "created_at" : "2013-07-19 23:24:12 +0000",
  "in_reply_to_screen_name" : "jaytennier",
  "in_reply_to_user_id_str" : "15020118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358363928448872448",
  "text" : "@juliepagano This is more just silly bro humor...not as terrible as this one though. Geez.",
  "id" : 358363928448872448,
  "created_at" : "2013-07-19 23:13:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358363583656112128",
  "text" : "\"Brojectivism is most famously explained in the book Atlas Shrugged; a swoleosophical novel about trap gains.\" \"who is John Glute?\"",
  "id" : 358363583656112128,
  "created_at" : "2013-07-19 23:11:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MYrVS9rdyC",
      "expanded_url" : "http:\/\/i.imgur.com\/JFKBPNl.jpg",
      "display_url" : "i.imgur.com\/JFKBPNl.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "358362639799287808",
  "text" : "\"I've been visiting the iron temple a lot lately...lately the females of my gym have been giving me the stink eye.\" http:\/\/t.co\/MYrVS9rdyC",
  "id" : 358362639799287808,
  "created_at" : "2013-07-19 23:08:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358362187611389952",
  "text" : "\"I have been on the edge of swole-dom for months. Two scoops of the Holy Whey every day. I pray to Brosiedon Himself 4 times a week.\"",
  "id" : 358362187611389952,
  "created_at" : "2013-07-19 23:06:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/XD3UWQ5fEq",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/swoleacceptance\/",
      "display_url" : "reddit.com\/r\/swoleaccepta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358362100990623744",
  "text" : "And today I discovered http:\/\/t.co\/XD3UWQ5fEq, and wept for the world.",
  "id" : 358362100990623744,
  "created_at" : "2013-07-19 23:05:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 0, 11 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358360431645036544",
  "geo" : { },
  "id_str" : "358361402399916033",
  "in_reply_to_user_id" : 15020118,
  "text" : "@jaytennier Decently clear skies in Buffalo but clouds looked scary north off the lake (was at LaSalle Park near the Peace Bridge)",
  "id" : 358361402399916033,
  "in_reply_to_status_id" : 358360431645036544,
  "created_at" : "2013-07-19 23:03:11 +0000",
  "in_reply_to_screen_name" : "jaytennier",
  "in_reply_to_user_id_str" : "15020118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    }, {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 13, 23 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358330955641008128",
  "geo" : { },
  "id_str" : "358331658488918018",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer @renaebair oh geeeeez.",
  "id" : 358331658488918018,
  "in_reply_to_status_id" : 358330955641008128,
  "created_at" : "2013-07-19 21:04:59 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drewtoothpaste",
      "screen_name" : "drewtoothpaste",
      "indices" : [ 0, 15 ],
      "id_str" : "14248784",
      "id" : 14248784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358330609480892416",
  "geo" : { },
  "id_str" : "358330976495075328",
  "in_reply_to_user_id" : 14248784,
  "text" : "@drewtoothpaste i gave you an upacorn.",
  "id" : 358330976495075328,
  "in_reply_to_status_id" : 358330609480892416,
  "created_at" : "2013-07-19 21:02:16 +0000",
  "in_reply_to_screen_name" : "drewtoothpaste",
  "in_reply_to_user_id_str" : "14248784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358327556946137089",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies did you guys cut the video too? *visibly cringes as dude deadlifts his arms off*",
  "id" : 358327556946137089,
  "created_at" : "2013-07-19 20:48:41 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358325262347288576",
  "geo" : { },
  "id_str" : "358325622432464896",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair I have a strong feeling I know why...",
  "id" : 358325622432464896,
  "in_reply_to_status_id" : 358325262347288576,
  "created_at" : "2013-07-19 20:41:00 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 3, 10 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358324021437276160",
  "text" : "RT @maddox: We'll be back soon. It's taking us over 30 hours to remove the linen from this page.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358323793837568000",
    "text" : "We'll be back soon. It's taking us over 30 hours to remove the linen from this page.",
    "id" : 358323793837568000,
    "created_at" : "2013-07-19 20:33:44 +0000",
    "user" : {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "protected" : false,
      "id_str" : "750823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554645994860584960\/dL3zfZ8C_normal.png",
      "id" : 750823,
      "verified" : false
    }
  },
  "id" : 358324021437276160,
  "created_at" : "2013-07-19 20:34:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Gnatyshyn",
      "screen_name" : "gnatok",
      "indices" : [ 3, 10 ],
      "id_str" : "39487252",
      "id" : 39487252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358321931977621504",
  "text" : "RT @gnatok: 99 little bugs in the code\r99 little bugs in the code\rTake one down, patch it around\r117 little bugs in the code",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETw\u0435\u0435tbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358216132299198465",
    "text" : "99 little bugs in the code\r99 little bugs in the code\rTake one down, patch it around\r117 little bugs in the code",
    "id" : 358216132299198465,
    "created_at" : "2013-07-19 13:25:55 +0000",
    "user" : {
      "name" : "Alex Gnatyshyn",
      "screen_name" : "gnatok",
      "protected" : false,
      "id_str" : "39487252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000816001589\/8cd66d38ec55bdb7d0dfb46afdb9c423_normal.jpeg",
      "id" : 39487252,
      "verified" : false
    }
  },
  "id" : 358321931977621504,
  "created_at" : "2013-07-19 20:26:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ric Roberts",
      "screen_name" : "RicRoberts",
      "indices" : [ 0, 11 ],
      "id_str" : "16550758",
      "id" : 16550758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358313734575366145",
  "geo" : { },
  "id_str" : "358314014025056256",
  "in_reply_to_user_id" : 16550758,
  "text" : "@RicRoberts pretty recently :)",
  "id" : 358314014025056256,
  "in_reply_to_status_id" : 358313734575366145,
  "created_at" : "2013-07-19 19:54:52 +0000",
  "in_reply_to_screen_name" : "RicRoberts",
  "in_reply_to_user_id_str" : "16550758",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Hockenberry",
      "screen_name" : "chockenberry",
      "indices" : [ 0, 13 ],
      "id_str" : "36183",
      "id" : 36183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358302840659263488",
  "geo" : { },
  "id_str" : "358307964660105216",
  "in_reply_to_user_id" : 36183,
  "text" : "@chockenberry This is really sad that it's even necessary.",
  "id" : 358307964660105216,
  "in_reply_to_status_id" : 358302840659263488,
  "created_at" : "2013-07-19 19:30:50 +0000",
  "in_reply_to_screen_name" : "chockenberry",
  "in_reply_to_user_id_str" : "36183",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358297558491201536",
  "geo" : { },
  "id_str" : "358298094372257793",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon really curious to see how you're approaching it, and for apps that already exist on iOS6. \/cc @JZ",
  "id" : 358298094372257793,
  "in_reply_to_status_id" : 358297558491201536,
  "created_at" : "2013-07-19 18:51:37 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "head honcho",
      "screen_name" : "PajamaBen_",
      "indices" : [ 3, 14 ],
      "id_str" : "388052215",
      "id" : 388052215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358296774890364928",
  "text" : "RT @PajamaBen_: \"The Sun is dying. We need help\" the scientists are speechless. Cool Dad kicks in the door &amp; removes his shades \"It's dayli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322849941133344768",
    "text" : "\"The Sun is dying. We need help\" the scientists are speechless. Cool Dad kicks in the door &amp; removes his shades \"It's daylight savings time\"",
    "id" : 322849941133344768,
    "created_at" : "2013-04-12 23:13:18 +0000",
    "user" : {
      "name" : "head honcho",
      "screen_name" : "PajamaBen_",
      "protected" : false,
      "id_str" : "388052215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542394445002317824\/aCp8an-I_normal.png",
      "id" : 388052215,
      "verified" : false
    }
  },
  "id" : 358296774890364928,
  "created_at" : "2013-07-19 18:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 8, 19 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358296133195407360",
  "geo" : { },
  "id_str" : "358296551367520256",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw @Alex_Godin I have issues with needles and this made me super uncomfortable.",
  "id" : 358296551367520256,
  "in_reply_to_status_id" : 358296133195407360,
  "created_at" : "2013-07-19 18:45:29 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Tigas",
      "screen_name" : "mtigas",
      "indices" : [ 3, 10 ],
      "id_str" : "13036632",
      "id" : 13036632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358295704730468353",
  "text" : "RT @mtigas: pretty sure error messages like \u201CYou are in a detached HEAD state\u201D are why people are scared of learning programming",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358295121185738752",
    "text" : "pretty sure error messages like \u201CYou are in a detached HEAD state\u201D are why people are scared of learning programming",
    "id" : 358295121185738752,
    "created_at" : "2013-07-19 18:39:48 +0000",
    "user" : {
      "name" : "Mike Tigas",
      "screen_name" : "mtigas",
      "protected" : false,
      "id_str" : "13036632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559526569958338560\/biZTILzR_normal.jpeg",
      "id" : 13036632,
      "verified" : true
    }
  },
  "id" : 358295704730468353,
  "created_at" : "2013-07-19 18:42:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Butt Toucher IRL",
      "screen_name" : "street_doggee",
      "indices" : [ 3, 17 ],
      "id_str" : "502016386",
      "id" : 502016386
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/street_doggee\/status\/358292253460017152\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/P9Jiu51TCa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPjo5_3CMAAKxAx.png",
      "id_str" : "358292253468405760",
      "id" : 358292253468405760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPjo5_3CMAAKxAx.png",
      "sizes" : [ {
        "h" : 207,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 1380
      }, {
        "h" : 68,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/P9Jiu51TCa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358292560210427904",
  "text" : "RT @street_doggee: I love this extension http:\/\/t.co\/P9Jiu51TCa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/street_doggee\/status\/358292253460017152\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/P9Jiu51TCa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPjo5_3CMAAKxAx.png",
        "id_str" : "358292253468405760",
        "id" : 358292253468405760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPjo5_3CMAAKxAx.png",
        "sizes" : [ {
          "h" : 207,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 1380
        }, {
          "h" : 68,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 121,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/P9Jiu51TCa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358292253460017152",
    "text" : "I love this extension http:\/\/t.co\/P9Jiu51TCa",
    "id" : 358292253460017152,
    "created_at" : "2013-07-19 18:28:24 +0000",
    "user" : {
      "name" : "Butt Toucher IRL",
      "screen_name" : "street_doggee",
      "protected" : false,
      "id_str" : "502016386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529384635097051137\/lFD57GRa_normal.jpeg",
      "id" : 502016386,
      "verified" : false
    }
  },
  "id" : 358292560210427904,
  "created_at" : "2013-07-19 18:29:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358291529779003392",
  "geo" : { },
  "id_str" : "358291914052743168",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens \"Does Cisco make you disco?\" *vomits internally*",
  "id" : 358291914052743168,
  "in_reply_to_status_id" : 358291529779003392,
  "created_at" : "2013-07-19 18:27:03 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "Blue Monk Buffalo",
      "screen_name" : "BlueMonkBflo",
      "indices" : [ 122, 135 ],
      "id_str" : "248682655",
      "id" : 248682655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Dudl5PKET2",
      "expanded_url" : "http:\/\/www.canalsidebuffalo.com\/",
      "display_url" : "canalsidebuffalo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "358272344243970049",
  "geo" : { },
  "id_str" : "358272864937455616",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden cool. highly suggest dropping by Canalside http:\/\/t.co\/Dudl5PKET2 I'd love to buy you at beer at Liberty Hound (or @BlueMonkBflo)!",
  "id" : 358272864937455616,
  "in_reply_to_status_id" : 358272344243970049,
  "created_at" : "2013-07-19 17:11:22 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358268699863568384",
  "geo" : { },
  "id_str" : "358270874744406016",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden you're headed this way? Let me know if you have some free time.",
  "id" : 358270874744406016,
  "in_reply_to_status_id" : 358268699863568384,
  "created_at" : "2013-07-19 17:03:27 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turntable",
      "screen_name" : "turntablefm",
      "indices" : [ 99, 111 ],
      "id_str" : "1934900918",
      "id" : 1934900918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/BDOQzIyaPA",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "358256433717981185",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing The Black Keys: Gold On The Ceiling \u266B\u266A @turntablefm http:\/\/t.co\/BDOQzIyaPA",
  "id" : 358256433717981185,
  "created_at" : "2013-07-19 16:06:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358254625800982530",
  "geo" : { },
  "id_str" : "358256116112695296",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc  PRIORITIES!!!!!",
  "id" : 358256116112695296,
  "in_reply_to_status_id" : 358254625800982530,
  "created_at" : "2013-07-19 16:04:48 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael D. Noga",
      "screen_name" : "rbl00",
      "indices" : [ 3, 9 ],
      "id_str" : "14326195",
      "id" : 14326195
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "philly.rb",
      "screen_name" : "phillyrb",
      "indices" : [ 61, 70 ],
      "id_str" : "17964172",
      "id" : 17964172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358253556802924544",
  "text" : "RT @rbl00: anyone Philly folk going to @NickelCityRuby? \nCC: @phillyrb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 28, 43 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "philly.rb",
        "screen_name" : "phillyrb",
        "indices" : [ 50, 59 ],
        "id_str" : "17964172",
        "id" : 17964172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358199083539775490",
    "text" : "anyone Philly folk going to @NickelCityRuby? \nCC: @phillyrb",
    "id" : 358199083539775490,
    "created_at" : "2013-07-19 12:18:11 +0000",
    "user" : {
      "name" : "Michael D. Noga",
      "screen_name" : "rbl00",
      "protected" : false,
      "id_str" : "14326195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1817644535\/ba00ef1aaa9fe7cbfa5ba11206fb9e1e_normal.jpeg",
      "id" : 14326195,
      "verified" : false
    }
  },
  "id" : 358253556802924544,
  "created_at" : "2013-07-19 15:54:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Berney",
      "screen_name" : "jesseberney",
      "indices" : [ 3, 15 ],
      "id_str" : "47451496",
      "id" : 47451496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357965900386807808",
  "text" : "RT @jesseberney: I mean, did Detroit even TRY a Kickstarter?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357958943294763008",
    "text" : "I mean, did Detroit even TRY a Kickstarter?",
    "id" : 357958943294763008,
    "created_at" : "2013-07-18 20:23:57 +0000",
    "user" : {
      "name" : "Jesse Berney",
      "screen_name" : "jesseberney",
      "protected" : false,
      "id_str" : "47451496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565491094163828738\/BepYxHyi_normal.jpeg",
      "id" : 47451496,
      "verified" : false
    }
  },
  "id" : 357965900386807808,
  "created_at" : "2013-07-18 20:51:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357960319856947200",
  "geo" : { },
  "id_str" : "357960610450911233",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu Oh, it's easy. My birthday is January 1, 1901.",
  "id" : 357960610450911233,
  "in_reply_to_status_id" : 357960319856947200,
  "created_at" : "2013-07-18 20:30:34 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357955168941248512",
  "geo" : { },
  "id_str" : "357955343403327489",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi that so stoopid",
  "id" : 357955343403327489,
  "in_reply_to_status_id" : 357955168941248512,
  "created_at" : "2013-07-18 20:09:39 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    }, {
      "name" : "Kevin Dente",
      "screen_name" : "kevindente",
      "indices" : [ 13, 24 ],
      "id_str" : "778112",
      "id" : 778112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357955047897841667",
  "geo" : { },
  "id_str" : "357955227539881984",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens @kevindente :(",
  "id" : 357955227539881984,
  "in_reply_to_status_id" : 357955047897841667,
  "created_at" : "2013-07-18 20:09:11 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357953584425484288",
  "text" : "If this cicada buzzes any louder I'm going to get the giant net out and sell him to some stupid raccoon.",
  "id" : 357953584425484288,
  "created_at" : "2013-07-18 20:02:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Strickland",
      "screen_name" : "strickland",
      "indices" : [ 0, 11 ],
      "id_str" : "14158522",
      "id" : 14158522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357948266836525057",
  "geo" : { },
  "id_str" : "357951939557851136",
  "in_reply_to_user_id" : 14158522,
  "text" : "@strickland needed the calendar\/me? ;)",
  "id" : 357951939557851136,
  "in_reply_to_status_id" : 357948266836525057,
  "created_at" : "2013-07-18 19:56:07 +0000",
  "in_reply_to_screen_name" : "strickland",
  "in_reply_to_user_id_str" : "14158522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DaveChap",
      "screen_name" : "DaveChap",
      "indices" : [ 3, 12 ],
      "id_str" : "16730984",
      "id" : 16730984
    }, {
      "name" : "Basecamp News",
      "screen_name" : "basecampnews",
      "indices" : [ 99, 112 ],
      "id_str" : "47366813",
      "id" : 47366813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357951773991895041",
  "text" : "RT @DaveChap: Really excited about the new Basecamp iPhone app with Calendar and Me additions. via @basecampnews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp News",
        "screen_name" : "basecampnews",
        "indices" : [ 85, 98 ],
        "id_str" : "47366813",
        "id" : 47366813
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.0809425646, -96.6768514546 ]
    },
    "id_str" : "357912848694915072",
    "text" : "Really excited about the new Basecamp iPhone app with Calendar and Me additions. via @basecampnews",
    "id" : 357912848694915072,
    "created_at" : "2013-07-18 17:20:47 +0000",
    "user" : {
      "name" : "DaveChap",
      "screen_name" : "DaveChap",
      "protected" : false,
      "id_str" : "16730984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439890627614879745\/KC_FlDke_normal.png",
      "id" : 16730984,
      "verified" : false
    }
  },
  "id" : 357951773991895041,
  "created_at" : "2013-07-18 19:55:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Choquette",
      "screen_name" : "meetmicah",
      "indices" : [ 3, 13 ],
      "id_str" : "16518744",
      "id" : 16518744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357951753506914304",
  "text" : "RT @meetmicah: Calendar and Me is now on Basecamp iPhone app! Yeah!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357912272590475264",
    "text" : "Calendar and Me is now on Basecamp iPhone app! Yeah!",
    "id" : 357912272590475264,
    "created_at" : "2013-07-18 17:18:30 +0000",
    "user" : {
      "name" : "Micah Choquette",
      "screen_name" : "meetmicah",
      "protected" : false,
      "id_str" : "16518744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2870715136\/182296d02613c9812075246536c9f7af_normal.jpeg",
      "id" : 16518744,
      "verified" : false
    }
  },
  "id" : 357951753506914304,
  "created_at" : "2013-07-18 19:55:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aray Montalvan-Till",
      "screen_name" : "thearay",
      "indices" : [ 3, 11 ],
      "id_str" : "16717220",
      "id" : 16717220
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 22, 32 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/thearay\/status\/357851439332196352\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/4jZKvUN8kF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPdX_PQCAAEQv1y.jpg",
      "id_str" : "357851439336390657",
      "id" : 357851439336390657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPdX_PQCAAEQv1y.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/4jZKvUN8kF"
    } ],
    "hashtags" : [ {
      "text" : "basecamp",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357951740089348096",
  "text" : "RT @thearay: Congrats @37signals, you just made it to my front screen with your user friendly #basecamp app :) http:\/\/t.co\/4jZKvUN8kF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 9, 19 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/thearay\/status\/357851439332196352\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/4jZKvUN8kF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPdX_PQCAAEQv1y.jpg",
        "id_str" : "357851439336390657",
        "id" : 357851439336390657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPdX_PQCAAEQv1y.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/4jZKvUN8kF"
      } ],
      "hashtags" : [ {
        "text" : "basecamp",
        "indices" : [ 81, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357851439332196352",
    "text" : "Congrats @37signals, you just made it to my front screen with your user friendly #basecamp app :) http:\/\/t.co\/4jZKvUN8kF",
    "id" : 357851439332196352,
    "created_at" : "2013-07-18 13:16:46 +0000",
    "user" : {
      "name" : "Aray Montalvan-Till",
      "screen_name" : "thearay",
      "protected" : false,
      "id_str" : "16717220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553646728243453954\/7OeojUV5_normal.jpeg",
      "id" : 16717220,
      "verified" : false
    }
  },
  "id" : 357951740089348096,
  "created_at" : "2013-07-18 19:55:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/fdaJbs0rJV",
      "expanded_url" : "http:\/\/everytimezone.com\/",
      "display_url" : "everytimezone.com"
    } ]
  },
  "in_reply_to_status_id_str" : "357948221823270912",
  "geo" : { },
  "id_str" : "357948448676380672",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending No pun intended, but time to use http:\/\/t.co\/fdaJbs0rJV ?",
  "id" : 357948448676380672,
  "in_reply_to_status_id" : 357948221823270912,
  "created_at" : "2013-07-18 19:42:15 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/357946685734912001\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/7lPQoc4rzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPeunTyCAAAdro2.png",
      "id_str" : "357946685747494912",
      "id" : 357946685747494912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPeunTyCAAAdro2.png",
      "sizes" : [ {
        "h" : 223,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/7lPQoc4rzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357944731772268545",
  "geo" : { },
  "id_str" : "357946685734912001",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan Thanks. Perspective is always good though (lol) http:\/\/t.co\/7lPQoc4rzR",
  "id" : 357946685734912001,
  "in_reply_to_status_id" : 357944731772268545,
  "created_at" : "2013-07-18 19:35:15 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 66, 77 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/sdNp6cQY23",
      "expanded_url" : "http:\/\/flic.kr\/p\/fc4jDr",
      "display_url" : "flic.kr\/p\/fc4jDr"
    } ]
  },
  "geo" : { },
  "id_str" : "357942603796328448",
  "text" : "Blue Bottle's siphon station from yesterday. This one goes out to @kevinpurdy. http:\/\/t.co\/sdNp6cQY23",
  "id" : 357942603796328448,
  "created_at" : "2013-07-18 19:19:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/0Wp3smwwxJ",
      "expanded_url" : "https:\/\/github.com\/grocer\/grocer",
      "display_url" : "github.com\/grocer\/grocer"
    } ]
  },
  "in_reply_to_status_id_str" : "357941186348056576",
  "geo" : { },
  "id_str" : "357941556705099776",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky None of the above do the implementation work in app for you. Why not just stick with the default? https:\/\/t.co\/0Wp3smwwxJ",
  "id" : 357941556705099776,
  "in_reply_to_status_id" : 357941186348056576,
  "created_at" : "2013-07-18 19:14:52 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357941017758023680",
  "geo" : { },
  "id_str" : "357941147978563584",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle did you read the linked page? just impressed by how simple they are and how much they communicate about their process.",
  "id" : 357941147978563584,
  "in_reply_to_status_id" : 357941017758023680,
  "created_at" : "2013-07-18 19:13:14 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Foy",
      "screen_name" : "cory_foy",
      "indices" : [ 0, 9 ],
      "id_str" : "203878517",
      "id" : 203878517
    }, {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 10, 22 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357932034565472256",
  "geo" : { },
  "id_str" : "357938765374816256",
  "in_reply_to_user_id" : 203878517,
  "text" : "@cory_foy @ryanbriones Don't tempt me, or I'll actually do this with Rush albums.",
  "id" : 357938765374816256,
  "in_reply_to_status_id" : 357932034565472256,
  "created_at" : "2013-07-18 19:03:46 +0000",
  "in_reply_to_screen_name" : "cory_foy",
  "in_reply_to_user_id_str" : "203878517",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khan Academy",
      "screen_name" : "khanacademy",
      "indices" : [ 21, 33 ],
      "id_str" : "16689804",
      "id" : 16689804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/nsfpy1HQZa",
      "expanded_url" : "http:\/\/37svn.com\/3582",
      "display_url" : "37svn.com\/3582"
    } ]
  },
  "geo" : { },
  "id_str" : "357936307252629504",
  "text" : "Really blown away by @khanacademy's development mantras: http:\/\/t.co\/nsfpy1HQZa",
  "id" : 357936307252629504,
  "created_at" : "2013-07-18 18:54:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Buryta",
      "screen_name" : "cburyta",
      "indices" : [ 0, 8 ],
      "id_str" : "5875982",
      "id" : 5875982
    }, {
      "name" : "hal_fulton",
      "screen_name" : "hal_fulton",
      "indices" : [ 58, 69 ],
      "id_str" : "15039745",
      "id" : 15039745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357930275801538561",
  "geo" : { },
  "id_str" : "357930960836235266",
  "in_reply_to_user_id" : 5875982,
  "text" : "@cburyta I learned an immense amount from The Ruby Way by @hal_fulton.",
  "id" : 357930960836235266,
  "in_reply_to_status_id" : 357930275801538561,
  "created_at" : "2013-07-18 18:32:45 +0000",
  "in_reply_to_screen_name" : "cburyta",
  "in_reply_to_user_id_str" : "5875982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357923328205393920",
  "text" : "SF weather: lol hoodies and raincoats, it\u2019s July! Rest of America: WILDFIRES MUGGY HUMID OH GOD SWEAT EWW",
  "id" : 357923328205393920,
  "created_at" : "2013-07-18 18:02:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iosreviewtime",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/6eMPHF18u2",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
      "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357903439285600256",
  "text" : "Basecamp 1.3.0 is out! Woot! https:\/\/t.co\/6eMPHF18u2 2 days of #iosreviewtime.",
  "id" : 357903439285600256,
  "created_at" : "2013-07-18 16:43:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357878070939615232",
  "geo" : { },
  "id_str" : "357878501522669569",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad my Acela experiences were amazing. I have heard nothing but bad things about the lines from Buffalo to Chicago &amp; NYC. :(",
  "id" : 357878501522669569,
  "in_reply_to_status_id" : 357878070939615232,
  "created_at" : "2013-07-18 15:04:18 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 0, 15 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357861648683376640",
  "geo" : { },
  "id_str" : "357877896796319745",
  "in_reply_to_user_id" : 290866979,
  "text" : "@thompson_caleb nope.",
  "id" : 357877896796319745,
  "in_reply_to_status_id" : 357861648683376640,
  "created_at" : "2013-07-18 15:01:54 +0000",
  "in_reply_to_screen_name" : "calebthompson",
  "in_reply_to_user_id_str" : "290866979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Gilbert",
      "screen_name" : "zackgilbert",
      "indices" : [ 3, 15 ],
      "id_str" : "822454",
      "id" : 822454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357877580680007681",
  "text" : "RT @zackgilbert: Most men die at 25... we just don't bury them until they are 70. - Benjamin Franklin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 41.9072505333, -87.6700149916 ]
    },
    "id_str" : "357876313551413250",
    "text" : "Most men die at 25... we just don't bury them until they are 70. - Benjamin Franklin",
    "id" : 357876313551413250,
    "created_at" : "2013-07-18 14:55:36 +0000",
    "user" : {
      "name" : "Zack Gilbert",
      "screen_name" : "zackgilbert",
      "protected" : false,
      "id_str" : "822454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3134954828\/9e9150ffdb52421843862e2c5fc1bd9b_normal.jpeg",
      "id" : 822454,
      "verified" : false
    }
  },
  "id" : 357877580680007681,
  "created_at" : "2013-07-18 15:00:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357875086998896640",
  "text" : "RT @coworkbuffalo: Full house today. Really full house. If you swing by and we're hard up for chairs, we are quite sorry (and looking at ne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357874372175867904",
    "text" : "Full house today. Really full house. If you swing by and we're hard up for chairs, we are quite sorry (and looking at new solutions)",
    "id" : 357874372175867904,
    "created_at" : "2013-07-18 14:47:53 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 357875086998896640,
  "created_at" : "2013-07-18 14:50:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357847228074827776",
  "geo" : { },
  "id_str" : "357849849586122752",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan head to @coworkbuffalo ? ;)",
  "id" : 357849849586122752,
  "in_reply_to_status_id" : 357847228074827776,
  "created_at" : "2013-07-18 13:10:27 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/KQd8dBLBbd",
      "expanded_url" : "http:\/\/www.lefthandedtoons.com\/1476\/",
      "display_url" : "lefthandedtoons.com\/1476\/"
    } ]
  },
  "geo" : { },
  "id_str" : "357839031905681408",
  "text" : "The Patriarchy! http:\/\/t.co\/KQd8dBLBbd",
  "id" : 357839031905681408,
  "created_at" : "2013-07-18 12:27:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357828507872669696",
  "geo" : { },
  "id_str" : "357830915323478016",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz Deal. Bring some beer.",
  "id" : 357830915323478016,
  "in_reply_to_status_id" : 357828507872669696,
  "created_at" : "2013-07-18 11:55:13 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 110, 118 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357828152933883906",
  "geo" : { },
  "id_str" : "357828587484749825",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik On the next flight, but further proves that I am incapable of traveling without something going wrong. @rubiety can verify this.",
  "id" : 357828587484749825,
  "in_reply_to_status_id" : 357828152933883906,
  "created_at" : "2013-07-18 11:45:58 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357821312716128257",
  "geo" : { },
  "id_str" : "357827678314835970",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik safe travels!",
  "id" : 357827678314835970,
  "in_reply_to_status_id" : 357821312716128257,
  "created_at" : "2013-07-18 11:42:21 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357827406121283584",
  "text" : "Is there a service I can pay to make sure my traveling is just normal? No changes, massages, getting lost.",
  "id" : 357827406121283584,
  "created_at" : "2013-07-18 11:41:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357827209345511424",
  "text" : "Missed connection to BUF. :(",
  "id" : 357827209345511424,
  "created_at" : "2013-07-18 11:40:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357728370135539712",
  "text" : "And it\u2019s alive again! It\u2019s been real SF. Thanks for the frequently random meetings with programmer people on public transit and places.",
  "id" : 357728370135539712,
  "created_at" : "2013-07-18 05:07:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357726435533795328",
  "text" : "And my iPhone seems to have shit the bed. :(",
  "id" : 357726435533795328,
  "created_at" : "2013-07-18 05:00:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357722565399158785",
  "text" : "Also isn\u2019t Aqualung particularly creepy for airport Muzak?",
  "id" : 357722565399158785,
  "created_at" : "2013-07-18 04:44:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357721414138204160",
  "text" : "TSA agent who was dutifully patting me down: \u201CI hate my job\u201D",
  "id" : 357721414138204160,
  "created_at" : "2013-07-18 04:40:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 0, 12 ],
      "id_str" : "6556972",
      "id" : 6556972
    }, {
      "name" : "Tracy Brisson",
      "screen_name" : "tracybrisson",
      "indices" : [ 13, 26 ],
      "id_str" : "18010521",
      "id" : 18010521
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 68, 78 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357674987324313601",
  "geo" : { },
  "id_str" : "357675240161157120",
  "in_reply_to_user_id" : 6556972,
  "text" : "@techpickles @tracybrisson I got the baby version of this book from @aquaranto.",
  "id" : 357675240161157120,
  "in_reply_to_status_id" : 357674987324313601,
  "created_at" : "2013-07-18 01:36:37 +0000",
  "in_reply_to_screen_name" : "techpickles",
  "in_reply_to_user_id_str" : "6556972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357668997669453824",
  "text" : "RT @helloflemster: It is officially July 17th, meaning I can officially use these emojis. \uD83D\uDCC5 \uD83D\uDCC6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357362311972929536",
    "text" : "It is officially July 17th, meaning I can officially use these emojis. \uD83D\uDCC5 \uD83D\uDCC6",
    "id" : 357362311972929536,
    "created_at" : "2013-07-17 04:53:09 +0000",
    "user" : {
      "name" : "Chelsea Fleming ",
      "screen_name" : "chelseaphlegm",
      "protected" : false,
      "id_str" : "226306699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573293673296891904\/4o6f1ScJ_normal.jpeg",
      "id" : 226306699,
      "verified" : false
    }
  },
  "id" : 357668997669453824,
  "created_at" : "2013-07-18 01:11:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357661456151486464",
  "geo" : { },
  "id_str" : "357661626184384513",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal heading out tonight, sorry",
  "id" : 357661626184384513,
  "in_reply_to_status_id" : 357661456151486464,
  "created_at" : "2013-07-18 00:42:31 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian",
      "screen_name" : "brixen",
      "indices" : [ 3, 10 ],
      "id_str" : "2897551",
      "id" : 2897551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/rJYDltUCL1",
      "expanded_url" : "http:\/\/rubygems.org\/gems\/r_fast_r_furious",
      "display_url" : "rubygems.org\/gems\/r_fast_r_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357660923785261056",
  "text" : "RT @brixen: Today is a good day to be a Rubyist http:\/\/t.co\/rJYDltUCL1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/rJYDltUCL1",
        "expanded_url" : "http:\/\/rubygems.org\/gems\/r_fast_r_furious",
        "display_url" : "rubygems.org\/gems\/r_fast_r_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357640111296487425",
    "text" : "Today is a good day to be a Rubyist http:\/\/t.co\/rJYDltUCL1",
    "id" : 357640111296487425,
    "created_at" : "2013-07-17 23:17:01 +0000",
    "user" : {
      "name" : "Brian",
      "screen_name" : "brixen",
      "protected" : false,
      "id_str" : "2897551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3091174567\/bfff863ac21d0dac040fc6a133ed721f_normal.jpeg",
      "id" : 2897551,
      "verified" : false
    }
  },
  "id" : 357660923785261056,
  "created_at" : "2013-07-18 00:39:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/TU7SUNgiTO",
      "expanded_url" : "http:\/\/i.imgur.com\/7iGsLF5.gif",
      "display_url" : "i.imgur.com\/7iGsLF5.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "357660365041049600",
  "text" : "Current status: http:\/\/t.co\/TU7SUNgiTO",
  "id" : 357660365041049600,
  "created_at" : "2013-07-18 00:37:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357645332634546178",
  "geo" : { },
  "id_str" : "357652326833598464",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis did you win? It\u2019s so difficult.",
  "id" : 357652326833598464,
  "in_reply_to_status_id" : 357645332634546178,
  "created_at" : "2013-07-18 00:05:34 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    }, {
      "name" : "GRODY HIGHROLLER",
      "screen_name" : "guttermagic",
      "indices" : [ 12, 24 ],
      "id_str" : "18060437",
      "id" : 18060437
    }, {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 43, 59 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357649372294549505",
  "geo" : { },
  "id_str" : "357649996113395712",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods @guttermagic Worlds colliding, @whentheponydies' band is playing that show.",
  "id" : 357649996113395712,
  "in_reply_to_status_id" : 357649372294549505,
  "created_at" : "2013-07-17 23:56:18 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    }, {
      "name" : "GRODY HIGHROLLER",
      "screen_name" : "guttermagic",
      "indices" : [ 12, 24 ],
      "id_str" : "18060437",
      "id" : 18060437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357648841643802624",
  "geo" : { },
  "id_str" : "357649038620897281",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods @guttermagic I am so confused.",
  "id" : 357649038620897281,
  "in_reply_to_status_id" : 357648841643802624,
  "created_at" : "2013-07-17 23:52:30 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 3, 7 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/mpThMSBcZ2",
      "expanded_url" : "https:\/\/gist.github.com\/lrz\/0632449b5ef8465e8312\/raw\/ec9dc06193a0240d448c6684d8f921333fc098e8\/gistfile1.txt",
      "display_url" : "gist.github.com\/lrz\/0632449b5e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357641951748694017",
  "text" : "RT @lrz: I love replying to recruiters. https:\/\/t.co\/mpThMSBcZ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/mpThMSBcZ2",
        "expanded_url" : "https:\/\/gist.github.com\/lrz\/0632449b5ef8465e8312\/raw\/ec9dc06193a0240d448c6684d8f921333fc098e8\/gistfile1.txt",
        "display_url" : "gist.github.com\/lrz\/0632449b5e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357641677827092480",
    "text" : "I love replying to recruiters. https:\/\/t.co\/mpThMSBcZ2",
    "id" : 357641677827092480,
    "created_at" : "2013-07-17 23:23:15 +0000",
    "user" : {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "protected" : false,
      "id_str" : "10452222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459499652228714497\/EiSPykkq_normal.png",
      "id" : 10452222,
      "verified" : false
    }
  },
  "id" : 357641951748694017,
  "created_at" : "2013-07-17 23:24:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 87, 100 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/q9Gcdzc28E",
      "expanded_url" : "http:\/\/www.technologyreview.com\/view\/517101\/edit-wars-reveal-the-10-most-controversial-topics-on-wikipedia\/",
      "display_url" : "technologyreview.com\/view\/517101\/ed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357611558458757128",
  "text" : "\"4. List of World Wrestling Entertainment, Inc. employees\" http:\/\/t.co\/q9Gcdzc28E (via @codinghorror)",
  "id" : 357611558458757128,
  "created_at" : "2013-07-17 21:23:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357601868395978753",
  "geo" : { },
  "id_str" : "357604946666979328",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh geez. where did you order it online (if you did)? most likely going for it after this trial run.",
  "id" : 357604946666979328,
  "in_reply_to_status_id" : 357601868395978753,
  "created_at" : "2013-07-17 20:57:17 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357601112133611521",
  "geo" : { },
  "id_str" : "357601662396936192",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh Rented one for my trip this week, loving it so far. Why can't you change the settings? I got \"read error\" a few times but resolved it.",
  "id" : 357601662396936192,
  "in_reply_to_status_id" : 357601112133611521,
  "created_at" : "2013-07-17 20:44:14 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Miller",
      "screen_name" : "incanus77",
      "indices" : [ 3, 13 ],
      "id_str" : "4765141",
      "id" : 4765141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357575562312679424",
  "text" : "RT @incanus77: Apple, the provisioning process should be: \n\n1. Plug in device. \n2. Click button in Xcode. \n3. There is no Step 3. \n\nJust fi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357567464323809280",
    "text" : "Apple, the provisioning process should be: \n\n1. Plug in device. \n2. Click button in Xcode. \n3. There is no Step 3. \n\nJust fix this already.",
    "id" : 357567464323809280,
    "created_at" : "2013-07-17 18:28:21 +0000",
    "user" : {
      "name" : "Justin Miller",
      "screen_name" : "incanus77",
      "protected" : false,
      "id_str" : "4765141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1730880458\/6611288273_3f2969e2e4_o_normal.jpg",
      "id" : 4765141,
      "verified" : false
    }
  },
  "id" : 357575562312679424,
  "created_at" : "2013-07-17 19:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357567152372465664",
  "text" : "Random unsetup Airport Extreme in the middle of SF, I salute you for free internets.",
  "id" : 357567152372465664,
  "created_at" : "2013-07-17 18:27:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 0, 8 ],
      "id_str" : "18071073",
      "id" : 18071073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357563653953822720",
  "geo" : { },
  "id_str" : "357564482714730496",
  "in_reply_to_user_id" : 18071073,
  "text" : "@ajsharp thanks!",
  "id" : 357564482714730496,
  "in_reply_to_status_id" : 357563653953822720,
  "created_at" : "2013-07-17 18:16:30 +0000",
  "in_reply_to_screen_name" : "ajsharp",
  "in_reply_to_user_id_str" : "18071073",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul smith",
      "screen_name" : "paulsmith",
      "indices" : [ 0, 10 ],
      "id_str" : "4578",
      "id" : 4578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357562743273951233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7825796619, -122.4076680814 ]
  },
  "id_str" : "357564381493604352",
  "in_reply_to_user_id" : 4578,
  "text" : "@paulsmith I do!",
  "id" : 357564381493604352,
  "in_reply_to_status_id" : 357562743273951233,
  "created_at" : "2013-07-17 18:16:06 +0000",
  "in_reply_to_screen_name" : "paulsmith",
  "in_reply_to_user_id_str" : "4578",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/Iw5djFRvtv",
      "expanded_url" : "https:\/\/github.com\/seattlerb\/minitest\/commit\/ccba6a7cdd524a617068797148c60df0d2ae685d",
      "display_url" : "github.com\/seattlerb\/mini\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357550802572820482",
  "text" : "RT @jhsu: dickwag removed https:\/\/t.co\/Iw5djFRvtv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/Iw5djFRvtv",
        "expanded_url" : "https:\/\/github.com\/seattlerb\/minitest\/commit\/ccba6a7cdd524a617068797148c60df0d2ae685d",
        "display_url" : "github.com\/seattlerb\/mini\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357550431007809536",
    "text" : "dickwag removed https:\/\/t.co\/Iw5djFRvtv",
    "id" : 357550431007809536,
    "created_at" : "2013-07-17 17:20:40 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 357550802572820482,
  "created_at" : "2013-07-17 17:22:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357550593235095552",
  "text" : "It\u2019s Always Apparent When A Job Post Is Lame Because They Look Like This - SOMEWHERE - FT",
  "id" : 357550593235095552,
  "created_at" : "2013-07-17 17:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 1, 13 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/K67LU243Yb",
      "expanded_url" : "https:\/\/vine.co\/v\/hmhnYVI07g3",
      "display_url" : "vine.co\/v\/hmhnYVI07g3"
    } ]
  },
  "geo" : { },
  "id_str" : "357535871555211264",
  "text" : ".@whereslloyd III: RETURN OF THE TACO https:\/\/t.co\/K67LU243Yb",
  "id" : 357535871555211264,
  "created_at" : "2013-07-17 16:22:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 0, 10 ],
      "id_str" : "153850397",
      "id" : 153850397
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 82, 97 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 99, 108 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 109, 116 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 117, 128 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357323393688813569",
  "geo" : { },
  "id_str" : "357324749552095232",
  "in_reply_to_user_id" : 153850397,
  "text" : "@Phish_FTR Rock and Roll &gt; Heartbreaker?! Going to get this show for sure. \/cc @UnclePhilsBlog  @LawnMemo @Croaky @phillapier",
  "id" : 357324749552095232,
  "in_reply_to_status_id" : 357323393688813569,
  "created_at" : "2013-07-17 02:23:53 +0000",
  "in_reply_to_screen_name" : "Phish_FTR",
  "in_reply_to_user_id_str" : "153850397",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipolar Fleece",
      "screen_name" : "porkbelt",
      "indices" : [ 0, 9 ],
      "id_str" : "614019653",
      "id" : 614019653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357303982508605440",
  "geo" : { },
  "id_str" : "357304098103635971",
  "in_reply_to_user_id" : 614019653,
  "text" : "@porkbelt GLOCKAMOLE",
  "id" : 357304098103635971,
  "in_reply_to_status_id" : 357303982508605440,
  "created_at" : "2013-07-17 01:01:50 +0000",
  "in_reply_to_screen_name" : "porkbelt",
  "in_reply_to_user_id_str" : "614019653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mason Fischer",
      "screen_name" : "masonforest",
      "indices" : [ 3, 15 ],
      "id_str" : "238231798",
      "id" : 238231798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/794PshmpXF",
      "expanded_url" : "http:\/\/flic.kr\/p\/faZrdc",
      "display_url" : "flic.kr\/p\/faZrdc"
    } ]
  },
  "geo" : { },
  "id_str" : "357293048121667585",
  "text" : ":o @masonforest http:\/\/t.co\/794PshmpXF",
  "id" : 357293048121667585,
  "created_at" : "2013-07-17 00:17:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/ClAPcK3pXF",
      "expanded_url" : "http:\/\/flic.kr\/p\/faZpR8",
      "display_url" : "flic.kr\/p\/faZpR8"
    } ]
  },
  "geo" : { },
  "id_str" : "357291668417949697",
  "text" : "Random awesome street sign found in downtown SF last night. http:\/\/t.co\/ClAPcK3pXF",
  "id" : 357291668417949697,
  "created_at" : "2013-07-17 00:12:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357290845285793793",
  "geo" : { },
  "id_str" : "357291259213250562",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan oh no the \"frameworks\" argument. :(",
  "id" : 357291259213250562,
  "in_reply_to_status_id" : 357290845285793793,
  "created_at" : "2013-07-17 00:10:49 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357290153439531008",
  "geo" : { },
  "id_str" : "357290294267490305",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan I may have asked this before, but have you written\/shipped anything with it?",
  "id" : 357290294267490305,
  "in_reply_to_status_id" : 357290153439531008,
  "created_at" : "2013-07-17 00:06:58 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357283282087460865",
  "geo" : { },
  "id_str" : "357283467060445187",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej we should talk about keto tomorrow. you barely get hungry.",
  "id" : 357283467060445187,
  "in_reply_to_status_id" : 357283282087460865,
  "created_at" : "2013-07-16 23:39:51 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 5, 11 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357266628662140930",
  "geo" : { },
  "id_str" : "357267348954157056",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz @alloy \"tests TakingOverTheWorldViewController\" ...nothing there seems to cover moving from one controller to another.",
  "id" : 357267348954157056,
  "in_reply_to_status_id" : 357266628662140930,
  "created_at" : "2013-07-16 22:35:48 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kareem Kouddous",
      "screen_name" : "kareemk",
      "indices" : [ 0, 8 ],
      "id_str" : "8859412",
      "id" : 8859412
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 9, 13 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357264692382662656",
  "geo" : { },
  "id_str" : "357264869491351552",
  "in_reply_to_user_id" : 8859412,
  "text" : "@kareemk @lrz I've written enough cucumber for one lifetime.",
  "id" : 357264869491351552,
  "in_reply_to_status_id" : 357264692382662656,
  "created_at" : "2013-07-16 22:25:57 +0000",
  "in_reply_to_screen_name" : "kareemk",
  "in_reply_to_user_id_str" : "8859412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357263963668496384",
  "geo" : { },
  "id_str" : "357264142677192705",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz the existing MacBacon stuff doesn't do &gt; 1 controller AFAIK. sharing it yet? :)",
  "id" : 357264142677192705,
  "in_reply_to_status_id" : 357263963668496384,
  "created_at" : "2013-07-16 22:23:03 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357263283604029441",
  "text" : "Are any iOS integration testing tools not terrible\/recommended to use?",
  "id" : 357263283604029441,
  "created_at" : "2013-07-16 22:19:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 0, 8 ],
      "id_str" : "14436348",
      "id" : 14436348
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 15, 26 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/LkX0Xwjzms",
      "expanded_url" : "http:\/\/i.imgur.com\/tmRT8PF.gif",
      "display_url" : "i.imgur.com\/tmRT8PF.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "357259761437249536",
  "geo" : { },
  "id_str" : "357260241752166400",
  "in_reply_to_user_id" : 14436348,
  "text" : "@adarshp @21x9 @thoughtbot http:\/\/t.co\/LkX0Xwjzms",
  "id" : 357260241752166400,
  "in_reply_to_status_id" : 357259761437249536,
  "created_at" : "2013-07-16 22:07:33 +0000",
  "in_reply_to_screen_name" : "adarshp",
  "in_reply_to_user_id_str" : "14436348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 13, 24 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357243246423973889",
  "text" : "Crashing the @thoughtbot SF office today! And yes, I've written more test code than normal today for some strange reason.",
  "id" : 357243246423973889,
  "created_at" : "2013-07-16 21:00:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Baldwin",
      "screen_name" : "alexbaldwin",
      "indices" : [ 0, 12 ],
      "id_str" : "14416798",
      "id" : 14416798
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 36, 47 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357236955320295425",
  "geo" : { },
  "id_str" : "357237621358985216",
  "in_reply_to_user_id" : 14416798,
  "text" : "@alexbaldwin I wouldn't put it past @kevinpurdy to actually write a blog post\/novel about this",
  "id" : 357237621358985216,
  "in_reply_to_status_id" : 357236955320295425,
  "created_at" : "2013-07-16 20:37:40 +0000",
  "in_reply_to_screen_name" : "alexbaldwin",
  "in_reply_to_user_id_str" : "14416798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357227749968060417",
  "geo" : { },
  "id_str" : "357233756966363140",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson woot!",
  "id" : 357233756966363140,
  "in_reply_to_status_id" : 357227749968060417,
  "created_at" : "2013-07-16 20:22:19 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Norman",
      "screen_name" : "lorennorman",
      "indices" : [ 0, 12 ],
      "id_str" : "10410272",
      "id" : 10410272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357190690603671552",
  "geo" : { },
  "id_str" : "357191179936337922",
  "in_reply_to_user_id" : 10410272,
  "text" : "@lorennorman nethack!!!!",
  "id" : 357191179936337922,
  "in_reply_to_status_id" : 357190690603671552,
  "created_at" : "2013-07-16 17:33:08 +0000",
  "in_reply_to_screen_name" : "lorennorman",
  "in_reply_to_user_id_str" : "10410272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 87, 93 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357190126843080704",
  "text" : "Not a fan that the AFNetworking doc URLs changed and no redirects are in place. :( \/cc @mattt",
  "id" : 357190126843080704,
  "created_at" : "2013-07-16 17:28:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357185552497385472",
  "geo" : { },
  "id_str" : "357185943507181569",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 maybe hit up the BOCC list? Nextplex too.",
  "id" : 357185943507181569,
  "in_reply_to_status_id" : 357185552497385472,
  "created_at" : "2013-07-16 17:12:19 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 24, 30 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 98, 107 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357185893007769602",
  "text" : "RT @zobar2: Even though @qrush isn't around &amp; it didn't make the calendar, we can do renegade @openhack anyway! Same time &amp; place, please R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 12, 18 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 86, 95 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357185552497385472",
    "text" : "Even though @qrush isn't around &amp; it didn't make the calendar, we can do renegade @openhack anyway! Same time &amp; place, please RSVP with me.",
    "id" : 357185552497385472,
    "created_at" : "2013-07-16 17:10:46 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 357185893007769602,
  "created_at" : "2013-07-16 17:12:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357181630957371392",
  "geo" : { },
  "id_str" : "357181884234612737",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek Most are not.",
  "id" : 357181884234612737,
  "in_reply_to_status_id" : 357181630957371392,
  "created_at" : "2013-07-16 16:56:11 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357181044295868417",
  "geo" : { },
  "id_str" : "357181412442509313",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek Razors. Sometimes motorized.",
  "id" : 357181412442509313,
  "in_reply_to_status_id" : 357181044295868417,
  "created_at" : "2013-07-16 16:54:19 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 99, 110 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357178748090589185",
  "text" : "Both times I've made coffee in SF I've fucked up the extraction time due to grind density. I blame @kevinpurdy for making me like this.",
  "id" : 357178748090589185,
  "created_at" : "2013-07-16 16:43:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357167696980361216",
  "geo" : { },
  "id_str" : "357172139842994177",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser Haven't seen any yet.",
  "id" : 357172139842994177,
  "in_reply_to_status_id" : 357167696980361216,
  "created_at" : "2013-07-16 16:17:28 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357166218202988544",
  "text" : "The amount of adults using scooters to get around SF is just silly.",
  "id" : 357166218202988544,
  "created_at" : "2013-07-16 15:53:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 0, 14 ],
      "id_str" : "679103",
      "id" : 679103
    }, {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 15, 22 ],
      "id_str" : "7516242",
      "id" : 7516242
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 23, 36 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356985757187051520",
  "geo" : { },
  "id_str" : "356992760630362112",
  "in_reply_to_user_id" : 679103,
  "text" : "@travisjeffery @mislav @steveklabnik wrong topic - not arguing CI, arguing that most open source isn't visually designed well :)",
  "id" : 356992760630362112,
  "in_reply_to_status_id" : 356985757187051520,
  "created_at" : "2013-07-16 04:24:41 +0000",
  "in_reply_to_screen_name" : "travisjeffery",
  "in_reply_to_user_id_str" : "679103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 14, 21 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356950812632686592",
  "geo" : { },
  "id_str" : "356983019246075906",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @mislav I feel the same, those are all outliers\/lucky. Most programmers don't care about design. Also, have you used Jenkins?",
  "id" : 356983019246075906,
  "in_reply_to_status_id" : 356950812632686592,
  "created_at" : "2013-07-16 03:45:58 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 0, 7 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356944844532350978",
  "geo" : { },
  "id_str" : "356946703288516609",
  "in_reply_to_user_id" : 7516242,
  "text" : "@mislav typical open source design. Could complain, or improve it.",
  "id" : 356946703288516609,
  "in_reply_to_status_id" : 356944844532350978,
  "created_at" : "2013-07-16 01:21:40 +0000",
  "in_reply_to_screen_name" : "mislav",
  "in_reply_to_user_id_str" : "7516242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafer Hazen",
      "screen_name" : "raferh",
      "indices" : [ 3, 10 ],
      "id_str" : "19470966",
      "id" : 19470966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Sao6ghfkvV",
      "expanded_url" : "https:\/\/gist.github.com\/rafer\/6003505",
      "display_url" : "gist.github.com\/rafer\/6003505"
    } ]
  },
  "geo" : { },
  "id_str" : "356902479390179330",
  "text" : "RT @raferh: Sorry world, your ruby method names definitely can have newlines. https:\/\/t.co\/Sao6ghfkvV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/Sao6ghfkvV",
        "expanded_url" : "https:\/\/gist.github.com\/rafer\/6003505",
        "display_url" : "gist.github.com\/rafer\/6003505"
      } ]
    },
    "geo" : { },
    "id_str" : "356883689973628932",
    "text" : "Sorry world, your ruby method names definitely can have newlines. https:\/\/t.co\/Sao6ghfkvV",
    "id" : 356883689973628932,
    "created_at" : "2013-07-15 21:11:16 +0000",
    "user" : {
      "name" : "Rafer Hazen",
      "screen_name" : "raferh",
      "protected" : false,
      "id_str" : "19470966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1144188815\/raybarb_normal.jpg",
      "id" : 19470966,
      "verified" : false
    }
  },
  "id" : 356902479390179330,
  "created_at" : "2013-07-15 22:25:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356896697802174464",
  "geo" : { },
  "id_str" : "356896927108960256",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Houses in Detroit are pretty cheap!",
  "id" : 356896927108960256,
  "in_reply_to_status_id" : 356896697802174464,
  "created_at" : "2013-07-15 22:03:52 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 3, 18 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Neomind Labs",
      "screen_name" : "NeomindLabs",
      "indices" : [ 74, 86 ],
      "id_str" : "605670059",
      "id" : 605670059
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 139, 140 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356895421630660608",
  "text" : "RT @AustinSeraphin: I feel pleased to announce that I have teamed up with @NeomindLabs and we will put a little Philadelphia crew together \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neomind Labs",
        "screen_name" : "NeomindLabs",
        "indices" : [ 54, 66 ],
        "id_str" : "605670059",
        "id" : 605670059
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 123, 138 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356891100763521025",
    "text" : "I feel pleased to announce that I have teamed up with @NeomindLabs and we will put a little Philadelphia crew together for @NickelCityRuby.",
    "id" : 356891100763521025,
    "created_at" : "2013-07-15 21:40:43 +0000",
    "user" : {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "protected" : false,
      "id_str" : "16393800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/382052821\/cib8blue_normal.jpg",
      "id" : 16393800,
      "verified" : false
    }
  },
  "id" : 356895421630660608,
  "created_at" : "2013-07-15 21:57:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "indices" : [ 0, 10 ],
      "id_str" : "14807622",
      "id" : 14807622
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 56, 67 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356889251264204800",
  "geo" : { },
  "id_str" : "356889392268328960",
  "in_reply_to_user_id" : 14807622,
  "text" : "@chazadams I'm in SF this week, can't help :( Maybe try @kevinpurdy?",
  "id" : 356889392268328960,
  "in_reply_to_status_id" : 356889251264204800,
  "created_at" : "2013-07-15 21:33:56 +0000",
  "in_reply_to_screen_name" : "chazadams",
  "in_reply_to_user_id_str" : "14807622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Ns4mdTQgob",
      "expanded_url" : "https:\/\/github.com\/blog\/1559-github-s-on-your-phone",
      "display_url" : "github.com\/blog\/1559-gith\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "356882202467909633",
  "text" : "RT @dhh: Great to see Github\u2019s new mobile pages follow the simple CSS + light JS style for speed: https:\/\/t.co\/Ns4mdTQgob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/Ns4mdTQgob",
        "expanded_url" : "https:\/\/github.com\/blog\/1559-github-s-on-your-phone",
        "display_url" : "github.com\/blog\/1559-gith\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "356882101011877888",
    "text" : "Great to see Github\u2019s new mobile pages follow the simple CSS + light JS style for speed: https:\/\/t.co\/Ns4mdTQgob",
    "id" : 356882101011877888,
    "created_at" : "2013-07-15 21:04:58 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 356882202467909633,
  "created_at" : "2013-07-15 21:05:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356868888337715200",
  "geo" : { },
  "id_str" : "356869027450200064",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant IM?",
  "id" : 356869027450200064,
  "in_reply_to_status_id" : 356868888337715200,
  "created_at" : "2013-07-15 20:13:01 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 14, 25 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 30, 37 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356868775187980288",
  "text" : "Big thanks to @engineyard and @github for some coworking space today. \\m\/",
  "id" : 356868775187980288,
  "created_at" : "2013-07-15 20:12:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356865930724249600",
  "geo" : { },
  "id_str" : "356868556861870081",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant did you crash your phone dude?",
  "id" : 356868556861870081,
  "in_reply_to_status_id" : 356865930724249600,
  "created_at" : "2013-07-15 20:11:08 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 0, 14 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356849772914688000",
  "geo" : { },
  "id_str" : "356850098170380289",
  "in_reply_to_user_id" : 5896952,
  "text" : "@BuffaloRising Club Marcella?",
  "id" : 356850098170380289,
  "in_reply_to_status_id" : 356849772914688000,
  "created_at" : "2013-07-15 18:57:48 +0000",
  "in_reply_to_screen_name" : "BuffaloRising",
  "in_reply_to_user_id_str" : "5896952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356849571084767232",
  "geo" : { },
  "id_str" : "356849863507447808",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish :o",
  "id" : 356849863507447808,
  "in_reply_to_status_id" : 356849571084767232,
  "created_at" : "2013-07-15 18:56:52 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregg Pollack",
      "screen_name" : "greggpollack",
      "indices" : [ 0, 13 ],
      "id_str" : "6082492",
      "id" : 6082492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356842065021239296",
  "geo" : { },
  "id_str" : "356842323616858113",
  "in_reply_to_user_id" : 6082492,
  "text" : "@greggpollack related: I have been sneaking Rush references into Rails core tests for a while now :P",
  "id" : 356842323616858113,
  "in_reply_to_status_id" : 356842065021239296,
  "created_at" : "2013-07-15 18:26:54 +0000",
  "in_reply_to_screen_name" : "greggpollack",
  "in_reply_to_user_id_str" : "6082492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 8, 13 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356836103778611200",
  "geo" : { },
  "id_str" : "356836353318719488",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss @r38y I am a terrible person.",
  "id" : 356836353318719488,
  "in_reply_to_status_id" : 356836103778611200,
  "created_at" : "2013-07-15 18:03:10 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356835371671240704",
  "geo" : { },
  "id_str" : "356835699447693312",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss *your* home page ;) it's customized to what reddits you subscribe to.",
  "id" : 356835699447693312,
  "in_reply_to_status_id" : 356835371671240704,
  "created_at" : "2013-07-15 18:00:35 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/s7oqVeWsKK",
      "expanded_url" : "https:\/\/github.com\/blog\/1530-choosing-an-open-source-license",
      "display_url" : "github.com\/blog\/1530-choo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "356812743749287937",
  "text" : "RT @github: Choosing an open source license doesn't need to be scary. Introducing choosealicense .com https:\/\/t.co\/s7oqVeWsKK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hubot.github.com\/\" rel=\"nofollow\"\u003EThe Danger Room\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/s7oqVeWsKK",
        "expanded_url" : "https:\/\/github.com\/blog\/1530-choosing-an-open-source-license",
        "display_url" : "github.com\/blog\/1530-choo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "356812670638366721",
    "text" : "Choosing an open source license doesn't need to be scary. Introducing choosealicense .com https:\/\/t.co\/s7oqVeWsKK",
    "id" : 356812670638366721,
    "created_at" : "2013-07-15 16:29:04 +0000",
    "user" : {
      "name" : "GitHub",
      "screen_name" : "github",
      "protected" : false,
      "id_str" : "13334762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426158315781881856\/sBsvBbjY_normal.png",
      "id" : 13334762,
      "verified" : true
    }
  },
  "id" : 356812743749287937,
  "created_at" : "2013-07-15 16:29:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF00FF",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356810543291580416",
  "text" : "Monthly reminder: Set your Hacker News topcolor to #FF00FF to never take anything on the site seriously.",
  "id" : 356810543291580416,
  "created_at" : "2013-07-15 16:20:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake",
      "screen_name" : "JakeOls",
      "indices" : [ 3, 11 ],
      "id_str" : "55318821",
      "id" : 55318821
    }, {
      "name" : "OpenHack Cleveland",
      "screen_name" : "OpenHackCLE",
      "indices" : [ 19, 31 ],
      "id_str" : "1579371050",
      "id" : 1579371050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356809974917234688",
  "text" : "RT @JakeOls: first @OpenHackCLE meeting was a success #openhack",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack Cleveland",
        "screen_name" : "OpenHackCLE",
        "indices" : [ 6, 18 ],
        "id_str" : "1579371050",
        "id" : 1579371050
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openhack",
        "indices" : [ 41, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356096352658268160",
    "text" : "first @OpenHackCLE meeting was a success #openhack",
    "id" : 356096352658268160,
    "created_at" : "2013-07-13 17:02:41 +0000",
    "user" : {
      "name" : "Jake",
      "screen_name" : "JakeOls",
      "protected" : false,
      "id_str" : "55318821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3758996501\/74964dc6db178b61af226c4b50c1ffae_normal.jpeg",
      "id" : 55318821,
      "verified" : false
    }
  },
  "id" : 356809974917234688,
  "created_at" : "2013-07-15 16:18:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Farkas",
      "screen_name" : "ericfarkas",
      "indices" : [ 3, 14 ],
      "id_str" : "26374438",
      "id" : 26374438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356809957871583232",
  "text" : "RT @ericfarkas: Thinking of starting up an OpenHack on Long Island...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356781702380662785",
    "text" : "Thinking of starting up an OpenHack on Long Island...",
    "id" : 356781702380662785,
    "created_at" : "2013-07-15 14:26:01 +0000",
    "user" : {
      "name" : "Eric Farkas",
      "screen_name" : "ericfarkas",
      "protected" : false,
      "id_str" : "26374438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530472727962861568\/AKoiL9Dl_normal.jpeg",
      "id" : 26374438,
      "verified" : false
    }
  },
  "id" : 356809957871583232,
  "created_at" : "2013-07-15 16:18:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Farkas",
      "screen_name" : "ericfarkas",
      "indices" : [ 0, 11 ],
      "id_str" : "26374438",
      "id" : 26374438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356781702380662785",
  "geo" : { },
  "id_str" : "356809942272966657",
  "in_reply_to_user_id" : 26374438,
  "text" : "@ericfarkas Do it!",
  "id" : 356809942272966657,
  "in_reply_to_status_id" : 356781702380662785,
  "created_at" : "2013-07-15 16:18:14 +0000",
  "in_reply_to_screen_name" : "ericfarkas",
  "in_reply_to_user_id_str" : "26374438",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356453794025971712",
  "text" : "That\u2019s 2 out of 3 times playing New Leaf that I\u2019ve hit the power button instead of Start to save my game. Fuck everything.",
  "id" : 356453794025971712,
  "created_at" : "2013-07-14 16:43:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356328413927190528",
  "geo" : { },
  "id_str" : "356437068429279233",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms totally agree with the conclusion. The sequels are awful.",
  "id" : 356437068429279233,
  "in_reply_to_status_id" : 356328413927190528,
  "created_at" : "2013-07-14 15:36:34 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356231278292500480",
  "geo" : { },
  "id_str" : "356236472027848706",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 oh god the DS started blinking, I somehow turned the game off. I hate how they still punish you for this.",
  "id" : 356236472027848706,
  "in_reply_to_status_id" : 356231278292500480,
  "created_at" : "2013-07-14 02:19:28 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 75, 81 ],
      "id_str" : "15062828",
      "id" : 15062828
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 82, 94 ],
      "id_str" : "248477732",
      "id" : 248477732
    }, {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 95, 107 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356226261728768000",
  "text" : "Alright, finally playing New Leaf. Let's do this thing: 2363-6310-1548 \/cc @vrunt @ecarlsen912 @starguarded (anyone else?)",
  "id" : 356226261728768000,
  "created_at" : "2013-07-14 01:38:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356224061501743104",
  "geo" : { },
  "id_str" : "356224132184150016",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn thanks! Renting an X100S, liking it so far. Finicky though.",
  "id" : 356224132184150016,
  "in_reply_to_status_id" : 356224061501743104,
  "created_at" : "2013-07-14 01:30:26 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Mager \u266B",
      "screen_name" : "mager",
      "indices" : [ 0, 6 ],
      "id_str" : "632023",
      "id" : 632023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356222481012490240",
  "geo" : { },
  "id_str" : "356222870290051073",
  "in_reply_to_user_id" : 632023,
  "text" : "@mager nope!",
  "id" : 356222870290051073,
  "in_reply_to_status_id" : 356222481012490240,
  "created_at" : "2013-07-14 01:25:25 +0000",
  "in_reply_to_screen_name" : "mager",
  "in_reply_to_user_id_str" : "632023",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/MPoADp100w",
      "expanded_url" : "http:\/\/flic.kr\/p\/f8TSqM",
      "display_url" : "flic.kr\/p\/f8TSqM"
    } ]
  },
  "geo" : { },
  "id_str" : "356222220395220992",
  "text" : "Low-light photos are really difficult, but this turned out decent: http:\/\/t.co\/MPoADp100w",
  "id" : 356222220395220992,
  "created_at" : "2013-07-14 01:22:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356213737260195840",
  "text" : "Cool new iOS7 feature: I am no longer receiving any incoming calls. &gt;:|",
  "id" : 356213737260195840,
  "created_at" : "2013-07-14 00:49:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/356185963187302400\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/C5pXU5wuSh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPFtPxICcAAPhS6.jpg",
      "id_str" : "356185963191496704",
      "id" : 356185963191496704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPFtPxICcAAPhS6.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/C5pXU5wuSh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356185963187302400",
  "text" : "Someone straight up copied the Ruby gem logo for this game. http:\/\/t.co\/C5pXU5wuSh",
  "id" : 356185963187302400,
  "created_at" : "2013-07-13 22:58:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 0, 3 ],
      "id_str" : "1178441",
      "id" : 1178441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356118848811966464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7719066906, -122.4364185146 ]
  },
  "id_str" : "356185040557834241",
  "in_reply_to_user_id" : 1178441,
  "text" : "@aq oh man the mothership wegmans! Also sounds good.",
  "id" : 356185040557834241,
  "in_reply_to_status_id" : 356118848811966464,
  "created_at" : "2013-07-13 22:55:05 +0000",
  "in_reply_to_screen_name" : "aq",
  "in_reply_to_user_id_str" : "1178441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356182783766441985",
  "text" : "Of course, had to find a board game store. Gamespace is intense.",
  "id" : 356182783766441985,
  "created_at" : "2013-07-13 22:46:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 0, 3 ],
      "id_str" : "1178441",
      "id" : 1178441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356117512900984832",
  "geo" : { },
  "id_str" : "356118552610213889",
  "in_reply_to_user_id" : 1178441,
  "text" : "@aq you\u2019re near Buffalo and I\u2019min SF. This world is backwards!!",
  "id" : 356118552610213889,
  "in_reply_to_status_id" : 356117512900984832,
  "created_at" : "2013-07-13 18:30:53 +0000",
  "in_reply_to_screen_name" : "aq",
  "in_reply_to_user_id_str" : "1178441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356100507128958976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7875476401, -122.4022576292 ]
  },
  "id_str" : "356111744277561345",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr no idea.",
  "id" : 356111744277561345,
  "in_reply_to_status_id" : 356100507128958976,
  "created_at" : "2013-07-13 18:03:50 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7878399851, -122.4019461256 ]
  },
  "id_str" : "356111681467854848",
  "text" : "Up to 4 times getting lost in SF.",
  "id" : 356111681467854848,
  "created_at" : "2013-07-13 18:03:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356040192718680066",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7756852606, -122.3986529712 ]
  },
  "id_str" : "356040494314303488",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending I already missed one Phish show this week.",
  "id" : 356040494314303488,
  "in_reply_to_status_id" : 356040192718680066,
  "created_at" : "2013-07-13 13:20:43 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356038714411069441",
  "text" : "Scumbag circadian rhythm.",
  "id" : 356038714411069441,
  "created_at" : "2013-07-13 13:13:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Lindsay Pearson",
      "screen_name" : "LindsayPea",
      "indices" : [ 8, 19 ],
      "id_str" : "68170364",
      "id" : 68170364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355920323666903040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7756733093, -122.3987027104 ]
  },
  "id_str" : "355921958589841408",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @LindsayPea I need to see this pup again this week.",
  "id" : 355921958589841408,
  "in_reply_to_status_id" : 355920323666903040,
  "created_at" : "2013-07-13 05:29:42 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355921686740213760",
  "text" : "Already got lost twice in SF. Top score?",
  "id" : 355921686740213760,
  "created_at" : "2013-07-13 05:28:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355893354715824128",
  "text" : "Apparently scarves are acceptable in July when in the Bay Area? I don\u2019t understand anything anymore.",
  "id" : 355893354715824128,
  "created_at" : "2013-07-13 03:36:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7118254816, -122.2217967606 ]
  },
  "id_str" : "355882393636311040",
  "text" : "Hey California, it\u2019s been a while.",
  "id" : 355882393636311040,
  "created_at" : "2013-07-13 02:52:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355782546258280448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7561671789, -122.2068598348 ]
  },
  "id_str" : "355881178760351747",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy yes and no idea.",
  "id" : 355881178760351747,
  "in_reply_to_status_id" : 355782546258280448,
  "created_at" : "2013-07-13 02:47:39 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 12, 23 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355841570383212544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7490943757, -122.2081797899 ]
  },
  "id_str" : "355881111907348480",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried @trevorturk 'MURICA!",
  "id" : 355881111907348480,
  "in_reply_to_status_id" : 355841570383212544,
  "created_at" : "2013-07-13 02:47:23 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/1u6ecmrCLl",
      "expanded_url" : "http:\/\/flic.kr\/p\/f8neNf",
      "display_url" : "flic.kr\/p\/f8neNf"
    } ]
  },
  "geo" : { },
  "id_str" : "355781176717344768",
  "text" : "Descending into Logan, clouds casting shadows on each other. http:\/\/t.co\/1u6ecmrCLl",
  "id" : 355781176717344768,
  "created_at" : "2013-07-12 20:10:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355748538648498176",
  "text" : "TSA masseuse called me \"bro\". Liked my Sabres gear. Said he wanted \"to burn\" some Leafs gear someone brought in.",
  "id" : 355748538648498176,
  "created_at" : "2013-07-12 18:00:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Baldwin",
      "screen_name" : "alexbaldwin",
      "indices" : [ 0, 12 ],
      "id_str" : "14416798",
      "id" : 14416798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355719494309650433",
  "geo" : { },
  "id_str" : "355748217016684545",
  "in_reply_to_user_id" : 14416798,
  "text" : "@alexbaldwin yes, planning on it!",
  "id" : 355748217016684545,
  "in_reply_to_status_id" : 355719494309650433,
  "created_at" : "2013-07-12 17:59:19 +0000",
  "in_reply_to_screen_name" : "alexbaldwin",
  "in_reply_to_user_id_str" : "14416798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 9, 24 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355736731707904001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0030316671, -78.8586097599 ]
  },
  "id_str" : "355737352775282688",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @gabrielgironda :(",
  "id" : 355737352775282688,
  "in_reply_to_status_id" : 355736731707904001,
  "created_at" : "2013-07-12 17:16:08 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355708083659472899",
  "geo" : { },
  "id_str" : "355711046251585536",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan Evil base\/HQ\/lair is now affordable!",
  "id" : 355711046251585536,
  "in_reply_to_status_id" : 355708083659472899,
  "created_at" : "2013-07-12 15:31:36 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Collins",
      "screen_name" : "presidentbeef",
      "indices" : [ 0, 14 ],
      "id_str" : "23978537",
      "id" : 23978537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355705871101214721",
  "geo" : { },
  "id_str" : "355706823208214528",
  "in_reply_to_user_id" : 23978537,
  "text" : "@presidentbeef ok, that's fine - they want to bus everyone from OAK =&gt; SFO, but that's going to overshoot the city itself",
  "id" : 355706823208214528,
  "in_reply_to_status_id" : 355705871101214721,
  "created_at" : "2013-07-12 15:14:50 +0000",
  "in_reply_to_screen_name" : "presidentbeef",
  "in_reply_to_user_id_str" : "23978537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355705380174704640",
  "text" : "Flight change...flying into OAK instead of SFO. Why doesn't BART go to OAK? :(",
  "id" : 355705380174704640,
  "created_at" : "2013-07-12 15:09:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/4e6KdL9SaI",
      "expanded_url" : "http:\/\/youtu.be\/4JjKKlU6O4I?a",
      "display_url" : "youtu.be\/4JjKKlU6O4I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "355526100786483201",
  "text" : "Old video, but funny: Geddy, who's there? http:\/\/t.co\/4e6KdL9SaI",
  "id" : 355526100786483201,
  "created_at" : "2013-07-12 03:16:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/FaoeJEsk94",
      "expanded_url" : "http:\/\/i.imgur.com\/XoscZrT.gif",
      "display_url" : "i.imgur.com\/XoscZrT.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "355523381942161408",
  "text" : "\"It's go time. You've been developing like a beast and your app is ready to go live!\" http:\/\/t.co\/FaoeJEsk94",
  "id" : 355523381942161408,
  "created_at" : "2013-07-12 03:05:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/cXFrxbkzjv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=iwsqFR5bh6Q",
      "display_url" : "youtube.com\/watch?v=iwsqFR\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355521212836876288",
  "geo" : { },
  "id_str" : "355522103577026561",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej holy. shit. http:\/\/t.co\/cXFrxbkzjv",
  "id" : 355522103577026561,
  "in_reply_to_status_id" : 355521212836876288,
  "created_at" : "2013-07-12 03:00:49 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beno\u00EEt Sigoure",
      "screen_name" : "tsunanet",
      "indices" : [ 0, 9 ],
      "id_str" : "1181104357",
      "id" : 1181104357
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 10, 18 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355503155498319872",
  "geo" : { },
  "id_str" : "355507208693366784",
  "in_reply_to_user_id" : 1181104357,
  "text" : "@tsunanet @capotej keto is under 20g of carbs a day, so anything you can do to keep it under works.",
  "id" : 355507208693366784,
  "in_reply_to_status_id" : 355503155498319872,
  "created_at" : "2013-07-12 02:01:38 +0000",
  "in_reply_to_screen_name" : "tsunanet",
  "in_reply_to_user_id_str" : "1181104357",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Chris Aniszczyk",
      "screen_name" : "cra",
      "indices" : [ 9, 13 ],
      "id_str" : "14602130",
      "id" : 14602130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355493943267434497",
  "geo" : { },
  "id_str" : "355497099565080576",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @cra nope! basically need to stay away from them, potatoes, squash, etc.",
  "id" : 355497099565080576,
  "in_reply_to_status_id" : 355493943267434497,
  "created_at" : "2013-07-12 01:21:28 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Aniszczyk",
      "screen_name" : "cra",
      "indices" : [ 0, 4 ],
      "id_str" : "14602130",
      "id" : 14602130
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 5, 13 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355492977734463488",
  "geo" : { },
  "id_str" : "355493222912503808",
  "in_reply_to_user_id" : 14602130,
  "text" : "@cra @capotej Do it! I was on keto for 4 months, it was awesome. This reminds me, I'd love to visit when I'm in town next week :)",
  "id" : 355493222912503808,
  "in_reply_to_status_id" : 355492977734463488,
  "created_at" : "2013-07-12 01:06:03 +0000",
  "in_reply_to_screen_name" : "cra",
  "in_reply_to_user_id_str" : "14602130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355491126867800064",
  "geo" : { },
  "id_str" : "355492001598275584",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej keto?",
  "id" : 355492001598275584,
  "in_reply_to_status_id" : 355491126867800064,
  "created_at" : "2013-07-12 01:01:12 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 0, 14 ],
      "id_str" : "679103",
      "id" : 679103
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 15, 25 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/1PAD2x1vit",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/9262798943\/sizes\/o\/in\/photostream\/",
      "display_url" : "flickr.com\/photos\/qrush\/9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355475172771364864",
  "geo" : { },
  "id_str" : "355484398860251136",
  "in_reply_to_user_id" : 679103,
  "text" : "@travisjeffery @theediguy thanks! blown away so far. you can see forever! http:\/\/t.co\/1PAD2x1vit",
  "id" : 355484398860251136,
  "in_reply_to_status_id" : 355475172771364864,
  "created_at" : "2013-07-12 00:31:00 +0000",
  "in_reply_to_screen_name" : "travisjeffery",
  "in_reply_to_user_id_str" : "679103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JuXyCSqVAD",
      "expanded_url" : "http:\/\/flic.kr\/p\/f7A2q6",
      "display_url" : "flic.kr\/p\/f7A2q6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.891686, -78.89486 ]
  },
  "id_str" : "355471251759833088",
  "text" : "Trying out an X100S this week, first serious camera. Initial tests are stunning. http:\/\/t.co\/JuXyCSqVAD",
  "id" : 355471251759833088,
  "created_at" : "2013-07-11 23:38:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 92, 101 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/G8nkhSi9Oz",
      "expanded_url" : "http:\/\/hellohappy.org\/beautiful-web-type\/",
      "display_url" : "hellohappy.org\/beautiful-web-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355434174670307328",
  "text" : "\"There are over 600 typefaces in the Google web fonts directory. Many of them are awful.\" - @ubuwaits http:\/\/t.co\/G8nkhSi9Oz",
  "id" : 355434174670307328,
  "created_at" : "2013-07-11 21:11:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/U1fBUeQnGv",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "355383609416351744",
  "text" : "RT @nickelcityruby: There are only 2 months left until NickelCityRuby! Don't miss your chance to get a ticket: http:\/\/t.co\/U1fBUeQnGv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/U1fBUeQnGv",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "355382768731037697",
    "text" : "There are only 2 months left until NickelCityRuby! Don't miss your chance to get a ticket: http:\/\/t.co\/U1fBUeQnGv",
    "id" : 355382768731037697,
    "created_at" : "2013-07-11 17:47:09 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 355383609416351744,
  "created_at" : "2013-07-11 17:50:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gautam Trivedi",
      "screen_name" : "Gotham3",
      "indices" : [ 3, 11 ],
      "id_str" : "126903716",
      "id" : 126903716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355380733918978050",
  "text" : "RT @Gotham3: Girlfriend: Ok you hang up :-)\nBoyfriend: No You hang up first :-)\nGirlfriend: no you first\nBoyfriend: No you first\nNSA: both \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354589153553416193",
    "text" : "Girlfriend: Ok you hang up :-)\nBoyfriend: No You hang up first :-)\nGirlfriend: no you first\nBoyfriend: No you first\nNSA: both of you hang up",
    "id" : 354589153553416193,
    "created_at" : "2013-07-09 13:13:36 +0000",
    "user" : {
      "name" : "Gautam Trivedi",
      "screen_name" : "Gotham3",
      "protected" : false,
      "id_str" : "126903716",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573412053131505664\/yk6DBY6s_normal.jpeg",
      "id" : 126903716,
      "verified" : false
    }
  },
  "id" : 355380733918978050,
  "created_at" : "2013-07-11 17:39:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Woodbridge",
      "screen_name" : "jrwoodbridge",
      "indices" : [ 0, 13 ],
      "id_str" : "19318821",
      "id" : 19318821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355372926167547906",
  "geo" : { },
  "id_str" : "355376401739812864",
  "in_reply_to_user_id" : 19318821,
  "text" : "@jrwoodbridge done! sorry.",
  "id" : 355376401739812864,
  "in_reply_to_status_id" : 355372926167547906,
  "created_at" : "2013-07-11 17:21:51 +0000",
  "in_reply_to_screen_name" : "jrwoodbridge",
  "in_reply_to_user_id_str" : "19318821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355175212884570113",
  "geo" : { },
  "id_str" : "355365715429171201",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin I have one! Maybe we should give some out day of.",
  "id" : 355365715429171201,
  "in_reply_to_status_id" : 355175212884570113,
  "created_at" : "2013-07-11 16:39:23 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/s7MZFyfsci",
      "expanded_url" : "http:\/\/petapixel.com\/2013\/07\/10\/dad-captures-one-second-per-day-of-his-sons-first-year-of-life\/",
      "display_url" : "petapixel.com\/2013\/07\/10\/dad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355364977978257408",
  "text" : "This dad is awesome, and this video literally broke me last night: http:\/\/t.co\/s7MZFyfsci",
  "id" : 355364977978257408,
  "created_at" : "2013-07-11 16:36:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/355161377180110848\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Bjgdv8WM3V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO3JZA1CUAAofYu.jpg",
      "id_str" : "355161377188499456",
      "id" : 355161377188499456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO3JZA1CUAAofYu.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Bjgdv8WM3V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355160201793527808",
  "geo" : { },
  "id_str" : "355161377180110848",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast that can\u2019t be possible! http:\/\/t.co\/Bjgdv8WM3V",
  "id" : 355161377180110848,
  "in_reply_to_status_id" : 355160201793527808,
  "created_at" : "2013-07-11 03:07:25 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Anderson",
      "screen_name" : "_jamesaanderson",
      "indices" : [ 0, 16 ],
      "id_str" : "559113060",
      "id" : 559113060
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 28, 36 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 38, 51 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Shane Becker",
      "screen_name" : "veganstraightedge",
      "indices" : [ 53, 71 ],
      "id_str" : "641013",
      "id" : 641013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355092289787408385",
  "geo" : { },
  "id_str" : "355160337877700609",
  "in_reply_to_user_id" : 559113060,
  "text" : "@_jamesaanderson hmm! Maybe @evanphx? @steveklabnik? @veganstraightedge?",
  "id" : 355160337877700609,
  "in_reply_to_status_id" : 355092289787408385,
  "created_at" : "2013-07-11 03:03:17 +0000",
  "in_reply_to_screen_name" : "_jamesaanderson",
  "in_reply_to_user_id_str" : "559113060",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355158721598459904",
  "geo" : { },
  "id_str" : "355159903314255875",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast did you scream for 4 episodes before this photo?",
  "id" : 355159903314255875,
  "in_reply_to_status_id" : 355158721598459904,
  "created_at" : "2013-07-11 03:01:34 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355152222725734401",
  "geo" : { },
  "id_str" : "355154321790349313",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo ughhhhhh\u2026.",
  "id" : 355154321790349313,
  "in_reply_to_status_id" : 355152222725734401,
  "created_at" : "2013-07-11 02:39:23 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355153297881051137",
  "geo" : { },
  "id_str" : "355154150029406208",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan wings at ETS are surprisingly good.",
  "id" : 355154150029406208,
  "in_reply_to_status_id" : 355153297881051137,
  "created_at" : "2013-07-11 02:38:42 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    }, {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 9, 14 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 15, 26 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355122592828506113",
  "geo" : { },
  "id_str" : "355154019955654656",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms @JEG2 @chadfowler I have no tattoos. I have a problem with needles.",
  "id" : 355154019955654656,
  "in_reply_to_status_id" : 355122592828506113,
  "created_at" : "2013-07-11 02:38:11 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355035374432681984",
  "geo" : { },
  "id_str" : "355118706227023872",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv you\u2019re welcome here of you drive through!",
  "id" : 355118706227023872,
  "in_reply_to_status_id" : 355035374432681984,
  "created_at" : "2013-07-11 00:17:52 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355107972772409344",
  "geo" : { },
  "id_str" : "355111894656360451",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo Nothing yet :(",
  "id" : 355111894656360451,
  "in_reply_to_status_id" : 355107972772409344,
  "created_at" : "2013-07-10 23:50:48 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355106081824972802",
  "geo" : { },
  "id_str" : "355106538735681536",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo Fuck the haters! Is there a live stream tonight?",
  "id" : 355106538735681536,
  "in_reply_to_status_id" : 355106081824972802,
  "created_at" : "2013-07-10 23:29:31 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355076640482656258",
  "text" : "Shit Hacker News Says: \"Amusingly, this post made a lot more sense when I remembered that boxers are a type of dog\"",
  "id" : 355076640482656258,
  "created_at" : "2013-07-10 21:30:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/94uW6ibOBu",
      "expanded_url" : "http:\/\/37svn.com\/3567",
      "display_url" : "37svn.com\/3567"
    } ]
  },
  "geo" : { },
  "id_str" : "355076093658669056",
  "text" : "\"It is as though you have contacted support for your vacuum cleaner, when your dishwasher is what is broken.\" http:\/\/t.co\/94uW6ibOBu",
  "id" : 355076093658669056,
  "created_at" : "2013-07-10 21:28:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355028214965469184",
  "geo" : { },
  "id_str" : "355028801450819585",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt \"Sir your bill is over due\" \"HOWDY NEIGHBOR\" \"You haven't paid in 2 months\" \"HAW-HA\" \"Your water will be shut off tomorrow\" \"DOH\"",
  "id" : 355028801450819585,
  "in_reply_to_status_id" : 355028214965469184,
  "created_at" : "2013-07-10 18:20:37 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/uPDpIDEgon",
      "expanded_url" : "http:\/\/www.thisamericanlife.org\/radio-archives\/episode\/233\/starting-from-scratch",
      "display_url" : "thisamericanlife.org\/radio-archives\u2026"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/5kfTxRdXbr",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/thetwo-way\/2013\/07\/10\/200756968\/dogtv-the-channel-for-stay-at-home-pups-is-going-national?ft=1&f=1001&sc=tw&utm_source=twitterfeed&utm_medium=twitter",
      "display_url" : "npr.org\/blogs\/thetwo-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355023614770282497",
  "text" : "The Puppy Channel concept (from http:\/\/t.co\/uPDpIDEgon) seems to have finally been realized: http:\/\/t.co\/5kfTxRdXbr",
  "id" : 355023614770282497,
  "created_at" : "2013-07-10 18:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 117, 132 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "355016087450042369",
  "text" : "Cleared the http:\/\/t.co\/2bA9BVLhWr support queue out of ~20 delete\/merge requests. Want to thank me? Do it in person @nickelcityruby :)",
  "id" : 355016087450042369,
  "created_at" : "2013-07-10 17:30:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355014955398995968",
  "geo" : { },
  "id_str" : "355015732116996096",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath still happy I jumped ship, deleted my account, and now CC license all my photos on Flickr.",
  "id" : 355015732116996096,
  "in_reply_to_status_id" : 355014955398995968,
  "created_at" : "2013-07-10 17:28:41 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354843872372867072",
  "geo" : { },
  "id_str" : "354979605976858624",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin Thanks!",
  "id" : 354979605976858624,
  "in_reply_to_status_id" : 354843872372867072,
  "created_at" : "2013-07-10 15:05:07 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/Ypn2v03PoI",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "354977734570684418",
  "text" : "RT @nickelcityruby: Busy Sept. 20th &amp; 21st?  If not, you should grab your tickets for Nickel City Ruby while they're still available!  http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/Ypn2v03PoI",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "354977526713552896",
    "text" : "Busy Sept. 20th &amp; 21st?  If not, you should grab your tickets for Nickel City Ruby while they're still available!  http:\/\/t.co\/Ypn2v03PoI",
    "id" : 354977526713552896,
    "created_at" : "2013-07-10 14:56:52 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 354977734570684418,
  "created_at" : "2013-07-10 14:57:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Lynch",
      "screen_name" : "BrendanLynch",
      "indices" : [ 0, 13 ],
      "id_str" : "2401751",
      "id" : 2401751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354954572655099905",
  "geo" : { },
  "id_str" : "354954920845254658",
  "in_reply_to_user_id" : 2401751,
  "text" : "@BrendanLynch driving downtown was insane yesterday, haven\u2019t been to Toronto in years. I was impressed by the number of bike lanes though.",
  "id" : 354954920845254658,
  "in_reply_to_status_id" : 354954572655099905,
  "created_at" : "2013-07-10 13:27:02 +0000",
  "in_reply_to_screen_name" : "BrendanLynch",
  "in_reply_to_user_id_str" : "2401751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354837423341043712",
  "text" : "Seeking the good out of a lot of bad luck: found a neat game store, wandered around a huge city, navigated thick fog back home. Good night.",
  "id" : 354837423341043712,
  "created_at" : "2013-07-10 05:40:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354834397331062784",
  "geo" : { },
  "id_str" : "354834601077772289",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle can\u2019t have these g8 protesters^H^H^H rioting in the streets!",
  "id" : 354834601077772289,
  "in_reply_to_status_id" : 354834397331062784,
  "created_at" : "2013-07-10 05:28:56 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354834220088172544",
  "text" : "City of Toronto didn\u2019t force One Direction to stop playing tonight, but for some reason Phish had to. &gt;:(",
  "id" : 354834220088172544,
  "created_at" : "2013-07-10 05:27:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/4E287n06MC",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjGKoLzU",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjGK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354830186249859074",
  "text" : "View my 5 latest photos on Flickr: http:\/\/t.co\/4E287n06MC",
  "id" : 354830186249859074,
  "created_at" : "2013-07-10 05:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 4, 11 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354821771930775555",
  "text" : "And @mkdevo\u2019s account is suspended. Sad day for this fan.",
  "id" : 354821771930775555,
  "created_at" : "2013-07-10 04:37:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Kuroda",
      "screen_name" : "Chrisck5",
      "indices" : [ 3, 12 ],
      "id_str" : "1228066555",
      "id" : 1228066555
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 14, 20 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wewereready",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354817731675164673",
  "text" : "RT @Chrisck5: @phish had to cancel tonight's show as per the orders of city hall. Power outages and weather. Sorry gang, we were ready to g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phish",
        "screen_name" : "phish",
        "indices" : [ 0, 6 ],
        "id_str" : "14503997",
        "id" : 14503997
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wewereready",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354735278201643011",
    "in_reply_to_user_id" : 14503997,
    "text" : "@phish had to cancel tonight's show as per the orders of city hall. Power outages and weather. Sorry gang, we were ready to go. #wewereready",
    "id" : 354735278201643011,
    "created_at" : "2013-07-09 22:54:15 +0000",
    "in_reply_to_screen_name" : "phish",
    "in_reply_to_user_id_str" : "14503997",
    "user" : {
      "name" : "Chris Kuroda",
      "screen_name" : "Chrisck5",
      "protected" : false,
      "id_str" : "1228066555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000300671087\/011d580766bd5019b193fd0553ce245c_normal.jpeg",
      "id" : 1228066555,
      "verified" : false
    }
  },
  "id" : 354817731675164673,
  "created_at" : "2013-07-10 04:21:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 19, 25 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354816537808482305",
  "text" : "Very unhappy about @phish being postponed, was in the lot outside the venue. Didn\u2019t postpone until an hour before the show :(",
  "id" : 354816537808482305,
  "created_at" : "2013-07-10 04:17:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 12, 22 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354789338573307904",
  "geo" : { },
  "id_str" : "354816257561853952",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws @aspleenic sorry guys.",
  "id" : 354816257561853952,
  "in_reply_to_status_id" : 354789338573307904,
  "created_at" : "2013-07-10 04:16:02 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354779117947863041",
  "geo" : { },
  "id_str" : "354816214150815744",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef of course I did, they didn\u2019t cancel until an hour before the show.",
  "id" : 354816214150815744,
  "in_reply_to_status_id" : 354779117947863041,
  "created_at" : "2013-07-10 04:15:52 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/65tG9UoybI",
      "expanded_url" : "http:\/\/www.tangledsillystrings.com\/2013\/07\/shai-hulud-just-likes-to-party.html",
      "display_url" : "tangledsillystrings.com\/2013\/07\/shai-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354673058327445504",
  "text" : "Maud'DIBDIBDIBDIBWUBBBBBBBBB http:\/\/t.co\/65tG9UoybI",
  "id" : 354673058327445504,
  "created_at" : "2013-07-09 18:47:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 23, 29 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354668167836082177",
  "text" : "Now have 2 tickets for @Phish tonight. Any Toronto followers want them? Will trade for good conversations\/karma :)",
  "id" : 354668167836082177,
  "created_at" : "2013-07-09 18:27:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 11, 19 ],
      "id_str" : "14408469",
      "id" : 14408469
    }, {
      "name" : "Pratik",
      "screen_name" : "lifo",
      "indices" : [ 24, 29 ],
      "id_str" : "6106092",
      "id" : 6106092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/UMx8yiKqQP",
      "expanded_url" : "https:\/\/basecamp.com\/announcements\/30",
      "display_url" : "basecamp.com\/announcements\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354656183799394304",
  "text" : "Looks like @uptonic and @lifo earn the Shipping Captains hat today! https:\/\/t.co\/UMx8yiKqQP",
  "id" : 354656183799394304,
  "created_at" : "2013-07-09 17:39:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/68Nlf25qFm",
      "expanded_url" : "http:\/\/vimeo.com\/69474289",
      "display_url" : "vimeo.com\/69474289"
    } ]
  },
  "geo" : { },
  "id_str" : "354654504085491713",
  "text" : "My @RubyMotion talk from #inspect is up! http:\/\/t.co\/68Nlf25qFm",
  "id" : 354654504085491713,
  "created_at" : "2013-07-09 17:33:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 63, 73 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354638634583990272",
  "geo" : { },
  "id_str" : "354644768741015552",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo awesome! We'll need to get them all together soon :) \/cc @magnachef",
  "id" : 354644768741015552,
  "in_reply_to_status_id" : 354638634583990272,
  "created_at" : "2013-07-09 16:54:36 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354454572766478337",
  "geo" : { },
  "id_str" : "354463374588907520",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout your avatar is so misleading. Thanks.",
  "id" : 354463374588907520,
  "in_reply_to_status_id" : 354454572766478337,
  "created_at" : "2013-07-09 04:53:48 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354431582859309058",
  "geo" : { },
  "id_str" : "354443444942409728",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout any suggestions for news sources to follow? Hoping they don't cancel the show tomorrow.",
  "id" : 354443444942409728,
  "in_reply_to_status_id" : 354431582859309058,
  "created_at" : "2013-07-09 03:34:37 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354431582859309058",
  "geo" : { },
  "id_str" : "354436581379158016",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout which reminds me, I have tickets if you or someone you know wants to go",
  "id" : 354436581379158016,
  "in_reply_to_status_id" : 354431582859309058,
  "created_at" : "2013-07-09 03:07:20 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354431582859309058",
  "geo" : { },
  "id_str" : "354436334603083776",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout does not bode well for Phish tomorrow.",
  "id" : 354436334603083776,
  "in_reply_to_status_id" : 354431582859309058,
  "created_at" : "2013-07-09 03:06:21 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/SQre5VaHaN",
      "expanded_url" : "http:\/\/flic.kr\/p\/f5KV9c",
      "display_url" : "flic.kr\/p\/f5KV9c"
    } ]
  },
  "geo" : { },
  "id_str" : "354432249174822913",
  "text" : "The Black Keys at the Outer Harbor. Love this venue. http:\/\/t.co\/SQre5VaHaN",
  "id" : 354432249174822913,
  "created_at" : "2013-07-09 02:50:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354414924480520193",
  "geo" : { },
  "id_str" : "354430849124548609",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout wtf? It\u2019s totally dry here.",
  "id" : 354430849124548609,
  "in_reply_to_status_id" : 354414924480520193,
  "created_at" : "2013-07-09 02:44:34 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Wade Minter",
      "screen_name" : "minter",
      "indices" : [ 0, 7 ],
      "id_str" : "8115722",
      "id" : 8115722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354401491727024128",
  "geo" : { },
  "id_str" : "354403053807468547",
  "in_reply_to_user_id" : 8115722,
  "text" : "@minter Albright-Knox is amazing. Canalside park is nice, get some drinks on Liberty Hound's balcony.",
  "id" : 354403053807468547,
  "in_reply_to_status_id" : 354401491727024128,
  "created_at" : "2013-07-09 00:54:07 +0000",
  "in_reply_to_screen_name" : "minter",
  "in_reply_to_user_id_str" : "8115722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/jhoE76bvPF",
      "expanded_url" : "http:\/\/flic.kr\/p\/f5VV9u",
      "display_url" : "flic.kr\/p\/f5VV9u"
    } ]
  },
  "geo" : { },
  "id_str" : "354397563958460416",
  "text" : "First concert at the outer harbor. Awesome venue! http:\/\/t.co\/jhoE76bvPF",
  "id" : 354397563958460416,
  "created_at" : "2013-07-09 00:32:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    }, {
      "name" : "Steve Eichert",
      "screen_name" : "steveeichert",
      "indices" : [ 7, 20 ],
      "id_str" : "8126672",
      "id" : 8126672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354374521840599040",
  "geo" : { },
  "id_str" : "354380499029995523",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis @steveeichert yeah I need to write more ObjC. I could go either way now.",
  "id" : 354380499029995523,
  "in_reply_to_status_id" : 354374521840599040,
  "created_at" : "2013-07-08 23:24:29 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354315149097709568",
  "geo" : { },
  "id_str" : "354315380858171392",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan Both, yes.",
  "id" : 354315380858171392,
  "in_reply_to_status_id" : 354315149097709568,
  "created_at" : "2013-07-08 19:05:44 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354311936067895296",
  "geo" : { },
  "id_str" : "354312657676931072",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan read more code. most don't read.",
  "id" : 354312657676931072,
  "in_reply_to_status_id" : 354311936067895296,
  "created_at" : "2013-07-08 18:54:55 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354304488774971392",
  "text" : "RT @aquaranto: Any of my awesome San Francisco friends want to go out for my birthday dinner tomorrow night?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354303472776122374",
    "text" : "Any of my awesome San Francisco friends want to go out for my birthday dinner tomorrow night?",
    "id" : 354303472776122374,
    "created_at" : "2013-07-08 18:18:25 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 354304488774971392,
  "created_at" : "2013-07-08 18:22:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 3, 10 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nathos\/status\/354296192806555648\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/X0NnUJMZkx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOq2gp3CEAEHFTH.jpg",
      "id_str" : "354296192810749953",
      "id" : 354296192810749953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOq2gp3CEAEHFTH.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/X0NnUJMZkx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354298664488943616",
  "text" : "RT @nathos: ZOMG new Mac Pros! http:\/\/t.co\/X0NnUJMZkx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nathos\/status\/354296192806555648\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/X0NnUJMZkx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOq2gp3CEAEHFTH.jpg",
        "id_str" : "354296192810749953",
        "id" : 354296192810749953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOq2gp3CEAEHFTH.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/X0NnUJMZkx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354296192806555648",
    "text" : "ZOMG new Mac Pros! http:\/\/t.co\/X0NnUJMZkx",
    "id" : 354296192806555648,
    "created_at" : "2013-07-08 17:49:29 +0000",
    "user" : {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "protected" : false,
      "id_str" : "34953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570421723984429056\/SiXp3XlU_normal.jpeg",
      "id" : 34953,
      "verified" : false
    }
  },
  "id" : 354298664488943616,
  "created_at" : "2013-07-08 17:59:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354293399836299265",
  "geo" : { },
  "id_str" : "354294191687335936",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo what?!?!",
  "id" : 354294191687335936,
  "in_reply_to_status_id" : 354293399836299265,
  "created_at" : "2013-07-08 17:41:32 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354274239152533504",
  "geo" : { },
  "id_str" : "354274669932724225",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo thought of you! Going to Toronto tomorrow?!",
  "id" : 354274669932724225,
  "in_reply_to_status_id" : 354274239152533504,
  "created_at" : "2013-07-08 16:23:58 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/Dm1Mvq6CC0",
      "expanded_url" : "http:\/\/uncrate.com\/",
      "display_url" : "uncrate.com"
    } ]
  },
  "geo" : { },
  "id_str" : "354257497172873217",
  "text" : "So http:\/\/t.co\/Dm1Mvq6CC0 is the Sharper Image for nerds, right?",
  "id" : 354257497172873217,
  "created_at" : "2013-07-08 15:15:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354243881673560066",
  "text" : "\"Every OSS program attempts to expand until it can install packages. Those programs which cannot so expand are replaced by ones which can.\"",
  "id" : 354243881673560066,
  "created_at" : "2013-07-08 14:21:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354236349806686209",
  "geo" : { },
  "id_str" : "354242069767790595",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr there's got to be a law of when an open source project wants to implement a package manager.",
  "id" : 354242069767790595,
  "in_reply_to_status_id" : 354236349806686209,
  "created_at" : "2013-07-08 14:14:25 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/J5WOtJ6m6e",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/world\/video\/2013\/jul\/08\/mos-def-force-fed-guantanamo-bay-video",
      "display_url" : "guardian.co.uk\/world\/video\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354240542802051075",
  "text" : "This video is extremely graphic and made me seriously uncomfortable. Can\u2019t even imagine the pain. http:\/\/t.co\/J5WOtJ6m6e",
  "id" : 354240542802051075,
  "created_at" : "2013-07-08 14:08:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FISA Court",
      "screen_name" : "FISA_Court",
      "indices" : [ 3, 14 ],
      "id_str" : "1576382833",
      "id" : 1576382833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354236466546741248",
  "text" : "RT @FISA_Court: Following the precedent set in US v. \u2588\u2588\u2588\u2588\u2588\u2588 ( \u2588\u2588 U.S. FISC \u2588\u2588\u2588 ), the NSA may legally \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354042408155095040",
    "text" : "Following the precedent set in US v. \u2588\u2588\u2588\u2588\u2588\u2588 ( \u2588\u2588 U.S. FISC \u2588\u2588\u2588 ), the NSA may legally \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588.",
    "id" : 354042408155095040,
    "created_at" : "2013-07-08 01:01:02 +0000",
    "user" : {
      "name" : "FISA Court",
      "screen_name" : "FISA_Court",
      "protected" : false,
      "id_str" : "1576382833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000102509955\/2c0e472e1cd810e6cc61fc835a50bd78_normal.png",
      "id" : 1576382833,
      "verified" : false
    }
  },
  "id" : 354236466546741248,
  "created_at" : "2013-07-08 13:52:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FISA Court",
      "screen_name" : "FISA_Court",
      "indices" : [ 3, 14 ],
      "id_str" : "1576382833",
      "id" : 1576382833
    }, {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 16, 27 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354236433000710145",
  "text" : "RT @FISA_Court: @ggreenwald wants to interview \u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588, \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588. \u2588\u2588\u2588\u2588 \u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588. Shit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Greenwald",
        "screen_name" : "ggreenwald",
        "indices" : [ 0, 11 ],
        "id_str" : "16076032",
        "id" : 16076032
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354233596443238401",
    "in_reply_to_user_id" : 16076032,
    "text" : "@ggreenwald wants to interview \u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588, \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588. \u2588\u2588\u2588\u2588 \u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588. Shit.",
    "id" : 354233596443238401,
    "created_at" : "2013-07-08 13:40:45 +0000",
    "in_reply_to_screen_name" : "ggreenwald",
    "in_reply_to_user_id_str" : "16076032",
    "user" : {
      "name" : "FISA Court",
      "screen_name" : "FISA_Court",
      "protected" : false,
      "id_str" : "1576382833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000102509955\/2c0e472e1cd810e6cc61fc835a50bd78_normal.png",
      "id" : 1576382833,
      "verified" : false
    }
  },
  "id" : 354236433000710145,
  "created_at" : "2013-07-08 13:52:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ZdLIM8ktfH",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/07\/03\/real-life-peter-griffin_n_3541315.html?utm_hp_ref=tw",
      "display_url" : "huffingtonpost.com\/2013\/07\/03\/rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354211491844587520",
  "text" : "Holy crap, this real life Peter Griffin is just too good. http:\/\/t.co\/ZdLIM8ktfH",
  "id" : 354211491844587520,
  "created_at" : "2013-07-08 12:12:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/354093426167390208\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/e28PPGUA3Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOn-GFSCIAAfmGi.png",
      "id_str" : "354093426175778816",
      "id" : 354093426175778816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOn-GFSCIAAfmGi.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/e28PPGUA3Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354093426167390208",
  "text" : "Didn\u2019t notice FaceTime on iOS7 blurs in your face in the background. Such a cool touch. http:\/\/t.co\/e28PPGUA3Y",
  "id" : 354093426167390208,
  "created_at" : "2013-07-08 04:23:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354034717298921473",
  "geo" : { },
  "id_str" : "354041794088009728",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment same, except it opens the camera and crashes the phone :(",
  "id" : 354041794088009728,
  "in_reply_to_status_id" : 354034717298921473,
  "created_at" : "2013-07-08 00:58:36 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353962457150140421",
  "geo" : { },
  "id_str" : "353962890216218625",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel literally the most hostile dev env out there.",
  "id" : 353962890216218625,
  "in_reply_to_status_id" : 353962457150140421,
  "created_at" : "2013-07-07 19:45:04 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 71, 81 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/7g5Se20NsD",
      "expanded_url" : "http:\/\/www.buffalonews.com\/apps\/pbcs.dll\/article?AID=\/20130706\/BUSINESS\/130709454\/1005",
      "display_url" : "buffalonews.com\/apps\/pbcs.dll\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353906931909394435",
  "text" : "\"To succeed in this field, you have to be tenacious. I fought back.\u201D - @aquaranto http:\/\/t.co\/7g5Se20NsD",
  "id" : 353906931909394435,
  "created_at" : "2013-07-07 16:02:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353906304449912833",
  "geo" : { },
  "id_str" : "353906390135357440",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense BLUNCH",
  "id" : 353906390135357440,
  "in_reply_to_status_id" : 353906304449912833,
  "created_at" : "2013-07-07 16:00:33 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 47, 53 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353906212921819139",
  "text" : "Last ditch attempt: I have one more ticket for @phish in Toronto this Tuesday. Any Buffalo\/Toronto followers want in?",
  "id" : 353906212921819139,
  "created_at" : "2013-07-07 15:59:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Metzger",
      "screen_name" : "AlmostWhiteHat",
      "indices" : [ 0, 15 ],
      "id_str" : "1190177485",
      "id" : 1190177485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353887428228034562",
  "geo" : { },
  "id_str" : "353902478099611650",
  "in_reply_to_user_id" : 1190177485,
  "text" : "@AlmostWhiteHat if you have questions let me know! :)",
  "id" : 353902478099611650,
  "in_reply_to_status_id" : 353887428228034562,
  "created_at" : "2013-07-07 15:45:00 +0000",
  "in_reply_to_screen_name" : "AlmostWhiteHat",
  "in_reply_to_user_id_str" : "1190177485",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Metzger",
      "screen_name" : "AlmostWhiteHat",
      "indices" : [ 3, 18 ],
      "id_str" : "1190177485",
      "id" : 1190177485
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 95, 110 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353902359472115717",
  "text" : "RT @AlmostWhiteHat: Giving RoR another shot because its ubiquitous in Buffalo, especially with @nickelcityruby coming up. Not sure if I pre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 75, 90 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353887428228034562",
    "text" : "Giving RoR another shot because its ubiquitous in Buffalo, especially with @nickelcityruby coming up. Not sure if I prefer it to Django yet.",
    "id" : 353887428228034562,
    "created_at" : "2013-07-07 14:45:12 +0000",
    "user" : {
      "name" : "Matt Metzger",
      "screen_name" : "AlmostWhiteHat",
      "protected" : false,
      "id_str" : "1190177485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3517170316\/d42857ff1fb858f0f196b26d7435c707_normal.jpeg",
      "id" : 1190177485,
      "verified" : false
    }
  },
  "id" : 353902359472115717,
  "created_at" : "2013-07-07 15:44:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grayson Wright",
      "screen_name" : "grayson_wright",
      "indices" : [ 3, 18 ],
      "id_str" : "16683371",
      "id" : 16683371
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353840227737022465",
  "text" : "RT @grayson_wright: Marking my calendar for @nickelcityruby.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 24, 39 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353459899247763456",
    "text" : "Marking my calendar for @nickelcityruby.",
    "id" : 353459899247763456,
    "created_at" : "2013-07-06 10:26:21 +0000",
    "user" : {
      "name" : "Grayson Wright",
      "screen_name" : "grayson_wright",
      "protected" : false,
      "id_str" : "16683371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530839756184092672\/UbavpS30_normal.jpeg",
      "id" : 16683371,
      "verified" : false
    }
  },
  "id" : 353840227737022465,
  "created_at" : "2013-07-07 11:37:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/Rwjwu5WQzG",
      "expanded_url" : "https:\/\/vine.co\/v\/hW9xYXtqLzV",
      "display_url" : "vine.co\/v\/hW9xYXtqLzV"
    } ]
  },
  "geo" : { },
  "id_str" : "353691905655181313",
  "text" : "Sparkler! https:\/\/t.co\/Rwjwu5WQzG",
  "id" : 353691905655181313,
  "created_at" : "2013-07-07 01:48:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 23, 33 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353607178986328064",
  "text" : "Now mega worried about @aquaranto heading to SFO tomorrow, and I'm following next Friday. Ugh.",
  "id" : 353607178986328064,
  "created_at" : "2013-07-06 20:11:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353537379212070912",
  "geo" : { },
  "id_str" : "353554945917722624",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo thanks for posting these! Are you headed to the Toronto show?",
  "id" : 353554945917722624,
  "in_reply_to_status_id" : 353537379212070912,
  "created_at" : "2013-07-06 16:44:02 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353506896394719233",
  "geo" : { },
  "id_str" : "353525523898580993",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant so many good covers.",
  "id" : 353525523898580993,
  "in_reply_to_status_id" : 353506896394719233,
  "created_at" : "2013-07-06 14:47:07 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ofzovc4KQs",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/blogs\/bits\/2013\/07\/05\/technology-workers-are-young-really-young\/",
      "display_url" : "mobile.nytimes.com\/blogs\/bits\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353403393462648833",
  "text" : "JOURNALISM 'She added, \u201CGen Y knows Python, social media, and Hadoop,\u201D which are newer versions of those things.\u2019 http:\/\/t.co\/Ofzovc4KQs",
  "id" : 353403393462648833,
  "created_at" : "2013-07-06 06:41:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 29, 35 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353401525818765314",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik I thought you were a @phish fan for a moment :(",
  "id" : 353401525818765314,
  "created_at" : "2013-07-06 06:34:24 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353245078128566272",
  "text" : "RT @samkottler: \"Daddy, how is software made?\" \"Well, when a programmer loves an idea very much they stay up all night and then push to git\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353137064969125888",
    "text" : "\"Daddy, how is software made?\" \"Well, when a programmer loves an idea very much they stay up all night and then push to github the next day\"",
    "id" : 353137064969125888,
    "created_at" : "2013-07-05 13:03:31 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 353245078128566272,
  "created_at" : "2013-07-05 20:12:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 10, 19 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353167707077754880",
  "geo" : { },
  "id_str" : "353172435987738624",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 @zspencer nah, better fuzzy matching for file\/folder names.",
  "id" : 353172435987738624,
  "in_reply_to_status_id" : 353167707077754880,
  "created_at" : "2013-07-05 15:24:05 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353167281154572290",
  "text" : "I need Ctrl-P for my shell.",
  "id" : 353167281154572290,
  "created_at" : "2013-07-05 15:03:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqui Maher",
      "screen_name" : "jacqui",
      "indices" : [ 0, 7 ],
      "id_str" : "355203",
      "id" : 355203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352837195721224192",
  "geo" : { },
  "id_str" : "352838349997867008",
  "in_reply_to_user_id" : 355203,
  "text" : "@jacqui we have not won this often. It looks so good, then suddenly bleak",
  "id" : 352838349997867008,
  "in_reply_to_status_id" : 352837195721224192,
  "created_at" : "2013-07-04 17:16:32 +0000",
  "in_reply_to_screen_name" : "jacqui",
  "in_reply_to_user_id_str" : "355203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco Dao",
      "screen_name" : "TheMan",
      "indices" : [ 0, 7 ],
      "id_str" : "15388795",
      "id" : 15388795
    }, {
      "name" : "bradford do\u00A3\u00A3a sign",
      "screen_name" : "LusciousPear",
      "indices" : [ 8, 21 ],
      "id_str" : "15829680",
      "id" : 15829680
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 46, 59 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352827744301752321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.921022457, -78.8800354985 ]
  },
  "id_str" : "352831726004879360",
  "in_reply_to_user_id" : 15388795,
  "text" : "@TheMan @LusciousPear must resist urge to use @herpderpedia\u2026",
  "id" : 352831726004879360,
  "in_reply_to_status_id" : 352827744301752321,
  "created_at" : "2013-07-04 16:50:13 +0000",
  "in_reply_to_screen_name" : "TheMan",
  "in_reply_to_user_id_str" : "15388795",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco Dao",
      "screen_name" : "TheMan",
      "indices" : [ 3, 10 ],
      "id_str" : "15388795",
      "id" : 15388795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/dmSgickOnC",
      "expanded_url" : "https:\/\/twitter.com\/PenLlawen\/status\/352824120804782080",
      "display_url" : "twitter.com\/PenLlawen\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352831610967687169",
  "text" : "RT @TheMan: Apparently people think America is 2013 years old :( https:\/\/t.co\/dmSgickOnC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/dmSgickOnC",
        "expanded_url" : "https:\/\/twitter.com\/PenLlawen\/status\/352824120804782080",
        "display_url" : "twitter.com\/PenLlawen\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352827744301752321",
    "text" : "Apparently people think America is 2013 years old :( https:\/\/t.co\/dmSgickOnC",
    "id" : 352827744301752321,
    "created_at" : "2013-07-04 16:34:24 +0000",
    "user" : {
      "name" : "Francisco Dao",
      "screen_name" : "TheMan",
      "protected" : false,
      "id_str" : "15388795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1959006948\/FB_Pic_normal.jpg",
      "id" : 15388795,
      "verified" : false
    }
  },
  "id" : 352831610967687169,
  "created_at" : "2013-07-04 16:49:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 3, 12 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 85, 95 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/shildner\/status\/352545747880771584\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/lHFYz73BMg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOR-fWXCAAAswjz.png",
      "id_str" : "352545747884965888",
      "id" : 352545747884965888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOR-fWXCAAAswjz.png",
      "sizes" : [ {
        "h" : 1249,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1249,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1165,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lHFYz73BMg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352600905880842240",
  "text" : "RT @shildner: How to wish your coworkers a happy Independence Day with Campfire from @37signals http:\/\/t.co\/lHFYz73BMg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 71, 81 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/shildner\/status\/352545747880771584\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/lHFYz73BMg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOR-fWXCAAAswjz.png",
        "id_str" : "352545747884965888",
        "id" : 352545747884965888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOR-fWXCAAAswjz.png",
        "sizes" : [ {
          "h" : 1249,
          "resize" : "fit",
          "w" : 643
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1249,
          "resize" : "fit",
          "w" : 643
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1165,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lHFYz73BMg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352545747880771584",
    "text" : "How to wish your coworkers a happy Independence Day with Campfire from @37signals http:\/\/t.co\/lHFYz73BMg",
    "id" : 352545747880771584,
    "created_at" : "2013-07-03 21:53:51 +0000",
    "user" : {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "protected" : false,
      "id_str" : "16225196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440887180529897472\/Hp3eZzzI_normal.jpeg",
      "id" : 16225196,
      "verified" : false
    }
  },
  "id" : 352600905880842240,
  "created_at" : "2013-07-04 01:33:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 20, 30 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/352573522725462016\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/HrLK4nrFBM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOSXwDvCYAABCV-.jpg",
      "id_str" : "352573522733850624",
      "id" : 352573522733850624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOSXwDvCYAABCV-.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/HrLK4nrFBM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352573522725462016",
  "text" : "Current status (\/cc @joeferris): http:\/\/t.co\/HrLK4nrFBM",
  "id" : 352573522725462016,
  "created_at" : "2013-07-03 23:44:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    }, {
      "name" : "Kevin",
      "screen_name" : "kvnsmth",
      "indices" : [ 9, 17 ],
      "id_str" : "6796662",
      "id" : 6796662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352501672255291392",
  "geo" : { },
  "id_str" : "352502378815168512",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin @kvnsmth forgot it was UIScrollView, but I hate trivia questions like this.",
  "id" : 352502378815168512,
  "in_reply_to_status_id" : 352501672255291392,
  "created_at" : "2013-07-03 19:01:30 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/EjVGJU7NaR",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aQm7YpxgOnA",
      "display_url" : "youtube.com\/watch?v=aQm7Yp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "352487674487128065",
  "geo" : { },
  "id_str" : "352487895279480833",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark http:\/\/t.co\/EjVGJU7NaR ?",
  "id" : 352487895279480833,
  "in_reply_to_status_id" : 352487674487128065,
  "created_at" : "2013-07-03 18:03:57 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Gamble",
      "screen_name" : "weyus",
      "indices" : [ 0, 6 ],
      "id_str" : "6207402",
      "id" : 6207402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352485766624059395",
  "geo" : { },
  "id_str" : "352485941950152704",
  "in_reply_to_user_id" : 6207402,
  "text" : "@weyus there's a picture of it in Spot downstairs from us!",
  "id" : 352485941950152704,
  "in_reply_to_status_id" : 352485766624059395,
  "created_at" : "2013-07-03 17:56:12 +0000",
  "in_reply_to_screen_name" : "weyus",
  "in_reply_to_user_id_str" : "6207402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Littlelines on Rails",
      "screen_name" : "littlelines",
      "indices" : [ 3, 15 ],
      "id_str" : "22043483",
      "id" : 22043483
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 47, 62 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/LU6tzWj4ms",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "352483198141345792",
  "text" : "RT @littlelines: We are proud to be sponsoring @nickelcityruby in Buffalo this September.  Be there!  http:\/\/t.co\/LU6tzWj4ms",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 30, 45 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/LU6tzWj4ms",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "352465637697789953",
    "text" : "We are proud to be sponsoring @nickelcityruby in Buffalo this September.  Be there!  http:\/\/t.co\/LU6tzWj4ms",
    "id" : 352465637697789953,
    "created_at" : "2013-07-03 16:35:31 +0000",
    "user" : {
      "name" : "Littlelines on Rails",
      "screen_name" : "littlelines",
      "protected" : false,
      "id_str" : "22043483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3438150358\/77717de39d9648626276c09860fd3260_normal.png",
      "id" : 22043483,
      "verified" : false
    }
  },
  "id" : 352483198141345792,
  "created_at" : "2013-07-03 17:45:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 76, 91 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/wMEs6d5g4V",
      "expanded_url" : "http:\/\/www.jetblue.com\/deals\/the-red-white-and-jetblue-sale\/?intcmp=HPHero01www_Eng__jetblue-airways-red-white-and-jetblue-sale20130403",
      "display_url" : "jetblue.com\/deals\/the-red-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352449216553041920",
  "text" : "Spammed the NYC and Orlando Ruby groups today because flights to BUF around @nickelcityruby are _stupid_ cheap: http:\/\/t.co\/wMEs6d5g4V",
  "id" : 352449216553041920,
  "created_at" : "2013-07-03 15:30:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/EKGCcbiaYC",
      "expanded_url" : "http:\/\/i.imgur.com\/LONLv2z.jpg",
      "display_url" : "i.imgur.com\/LONLv2z.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "352444375915167747",
  "text" : "Current status: http:\/\/t.co\/EKGCcbiaYC",
  "id" : 352444375915167747,
  "created_at" : "2013-07-03 15:11:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/wzpgrC7uqU",
      "expanded_url" : "http:\/\/raisethehammer.org\/article\/1891",
      "display_url" : "raisethehammer.org\/article\/1891"
    } ]
  },
  "geo" : { },
  "id_str" : "352443557392556032",
  "text" : "I love my neighborhood: \"Buffalo Can Teach Us About Thriving Urban Neighbourhoods\" http:\/\/t.co\/wzpgrC7uqU",
  "id" : 352443557392556032,
  "created_at" : "2013-07-03 15:07:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352438649343836160",
  "geo" : { },
  "id_str" : "352439749555920897",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Yeah needs some help on iPad too. MVP!",
  "id" : 352439749555920897,
  "in_reply_to_status_id" : 352438649343836160,
  "created_at" : "2013-07-03 14:52:38 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 3, 11 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/INxA1G4uRE",
      "expanded_url" : "http:\/\/www.gamasutra.com\/view\/feature\/195148\/dwarf_fortress_in_2013.php?print=1",
      "display_url" : "gamasutra.com\/view\/feature\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352439113519083520",
  "text" : "RT @CDMoyer: Enjoyed this article, Dwarf Fortress in 2013 - http:\/\/t.co\/INxA1G4uRE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/INxA1G4uRE",
        "expanded_url" : "http:\/\/www.gamasutra.com\/view\/feature\/195148\/dwarf_fortress_in_2013.php?print=1",
        "display_url" : "gamasutra.com\/view\/feature\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352438832232267777",
    "text" : "Enjoyed this article, Dwarf Fortress in 2013 - http:\/\/t.co\/INxA1G4uRE",
    "id" : 352438832232267777,
    "created_at" : "2013-07-03 14:49:00 +0000",
    "user" : {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "protected" : false,
      "id_str" : "12145232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421641487051272192\/IfEg0PgG_normal.jpeg",
      "id" : 12145232,
      "verified" : false
    }
  },
  "id" : 352439113519083520,
  "created_at" : "2013-07-03 14:50:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/RRguAXnDfs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "352438182807207936",
  "text" : "Hungry yet? http:\/\/t.co\/RRguAXnDfs should look nicer on your mobile devices today.",
  "id" : 352438182807207936,
  "created_at" : "2013-07-03 14:46:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352432318486544384",
  "geo" : { },
  "id_str" : "352432627631923200",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz I had no idea JCVD was Belgian. That makes him even more badass.",
  "id" : 352432627631923200,
  "in_reply_to_status_id" : 352432318486544384,
  "created_at" : "2013-07-03 14:24:20 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miha Rekar",
      "screen_name" : "mr_foto",
      "indices" : [ 0, 8 ],
      "id_str" : "28532360",
      "id" : 28532360
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 9, 13 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352357441943511040",
  "geo" : { },
  "id_str" : "352428359306838018",
  "in_reply_to_user_id" : 28532360,
  "text" : "@mr_foto @dhh I have a feeling at this point, the final, but not sure. There's so many drafts out, it's a mess.",
  "id" : 352428359306838018,
  "in_reply_to_status_id" : 352357441943511040,
  "created_at" : "2013-07-03 14:07:23 +0000",
  "in_reply_to_screen_name" : "mr_foto",
  "in_reply_to_user_id_str" : "28532360",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 74, 86 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/352265069838622720\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ow6SdnnMYO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BON_NvLCYAAJpA0.png",
      "id_str" : "352265069842817024",
      "id" : 352265069842817024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BON_NvLCYAAJpA0.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ow6SdnnMYO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/jdEanKlPPc",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "geo" : { },
  "id_str" : "352265069838622720",
  "text" : "Buffalo: http:\/\/t.co\/jdEanKlPPc has been upgraded for even more efficient @whereslloyd burrito browsing on the go! http:\/\/t.co\/ow6SdnnMYO",
  "id" : 352265069838622720,
  "created_at" : "2013-07-03 03:18:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dillon",
      "screen_name" : "squarism",
      "indices" : [ 0, 9 ],
      "id_str" : "4112941",
      "id" : 4112941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352228600675700736",
  "geo" : { },
  "id_str" : "352230137938460673",
  "in_reply_to_user_id" : 4112941,
  "text" : "@squarism it's just a test gem i have...",
  "id" : 352230137938460673,
  "in_reply_to_status_id" : 352228600675700736,
  "created_at" : "2013-07-03 00:59:43 +0000",
  "in_reply_to_screen_name" : "squarism",
  "in_reply_to_user_id_str" : "4112941",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 14, 21 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 41, 50 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352222642071289857",
  "text" : "Big thanks to @zobar2 for helping me fix @rubygems!",
  "id" : 352222642071289857,
  "created_at" : "2013-07-03 00:29:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 3, 12 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/y13yEGWOpB",
      "expanded_url" : "http:\/\/is.gd\/drtYZa",
      "display_url" : "is.gd\/drtYZa"
    } ]
  },
  "geo" : { },
  "id_str" : "352222446465724416",
  "text" : "RT @rubygems: hola (0.1.3): http:\/\/t.co\/y13yEGWOpB A simple hello world gem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/rubygems.org\" rel=\"nofollow\"\u003ERubyGems.org\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/y13yEGWOpB",
        "expanded_url" : "http:\/\/is.gd\/drtYZa",
        "display_url" : "is.gd\/drtYZa"
      } ]
    },
    "geo" : { },
    "id_str" : "352222298662633473",
    "text" : "hola (0.1.3): http:\/\/t.co\/y13yEGWOpB A simple hello world gem",
    "id" : 352222298662633473,
    "created_at" : "2013-07-03 00:28:34 +0000",
    "user" : {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "protected" : false,
      "id_str" : "14881835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651086638\/rubygems-125x125t_normal.png",
      "id" : 14881835,
      "verified" : false
    }
  },
  "id" : 352222446465724416,
  "created_at" : "2013-07-03 00:29:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 3, 12 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352219966851919872",
  "text" : "RT @rubygems: Hello world!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/rubygems.org\" rel=\"nofollow\"\u003ERubyGems.org\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352219913189998592",
    "text" : "Hello world!",
    "id" : 352219913189998592,
    "created_at" : "2013-07-03 00:19:05 +0000",
    "user" : {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "protected" : false,
      "id_str" : "14881835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651086638\/rubygems-125x125t_normal.png",
      "id" : 14881835,
      "verified" : false
    }
  },
  "id" : 352219966851919872,
  "created_at" : "2013-07-03 00:19:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352131277903765505",
  "geo" : { },
  "id_str" : "352132437456850945",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs I mess this up still on a daily basis trying to swipe up. Also, trying to swipe the volume control on the lock screen is very hard.",
  "id" : 352132437456850945,
  "in_reply_to_status_id" : 352131277903765505,
  "created_at" : "2013-07-02 18:31:30 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Zorn",
      "screen_name" : "miex0r",
      "indices" : [ 0, 7 ],
      "id_str" : "175108814",
      "id" : 175108814
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 8, 15 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352093234069110785",
  "geo" : { },
  "id_str" : "352093876074450946",
  "in_reply_to_user_id" : 175108814,
  "text" : "@miex0r @nb3004 where's your soap shoes?",
  "id" : 352093876074450946,
  "in_reply_to_status_id" : 352093234069110785,
  "created_at" : "2013-07-02 15:58:16 +0000",
  "in_reply_to_screen_name" : "miex0r",
  "in_reply_to_user_id_str" : "175108814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JetBlue Airways",
      "screen_name" : "JetBlue",
      "indices" : [ 40, 48 ],
      "id_str" : "6449282",
      "id" : 6449282
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 59, 74 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/QJKCAknu26",
      "expanded_url" : "http:\/\/www2.jetblue.com\/deals\/the-red-white-and-jetblue-sale\/?source=EM0070213_Hero_Airways",
      "display_url" : "www2.jetblue.com\/deals\/the-red-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352093775629266944",
  "text" : "Flights to BUF from JFK, MCO on sale on @JetBlue! Get your @nickelcityruby flights now! Seriously! http:\/\/t.co\/QJKCAknu26",
  "id" : 352093775629266944,
  "created_at" : "2013-07-02 15:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/wwFjUXJ4Rv",
      "expanded_url" : "http:\/\/api.rubyonrails.org\/classes\/ActiveSupport\/MessageEncryptor.html",
      "display_url" : "api.rubyonrails.org\/classes\/Active\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352075084053233665",
  "text" : "Rails' encryption\/message secrets APIs are always neat to discover. http:\/\/t.co\/wwFjUXJ4Rv",
  "id" : 352075084053233665,
  "created_at" : "2013-07-02 14:43:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 0, 14 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/PtYfJxFQsx",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3503-the-only-camera-you-need-is-an-iphone",
      "display_url" : "37signals.com\/svn\/posts\/3503\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "351849198922117120",
  "geo" : { },
  "id_str" : "351875769569525760",
  "in_reply_to_user_id" : 158443907,
  "text" : "@dragonladyB17 plenty of other nice options here too: http:\/\/t.co\/PtYfJxFQsx",
  "id" : 351875769569525760,
  "in_reply_to_status_id" : 351849198922117120,
  "created_at" : "2013-07-02 01:31:35 +0000",
  "in_reply_to_screen_name" : "dragonladyB17",
  "in_reply_to_user_id_str" : "158443907",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 0, 14 ],
      "id_str" : "158443907",
      "id" : 158443907
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 99, 109 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 114, 118 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351849198922117120",
  "geo" : { },
  "id_str" : "351875454183026690",
  "in_reply_to_user_id" : 158443907,
  "text" : "@dragonladyB17 cars are rough, especially in evening here. Trying out an X100S for my next trip on @asianmack and @dhh\u2019s recommendation",
  "id" : 351875454183026690,
  "in_reply_to_status_id" : 351849198922117120,
  "created_at" : "2013-07-02 01:30:20 +0000",
  "in_reply_to_screen_name" : "dragonladyB17",
  "in_reply_to_user_id_str" : "158443907",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Adams",
      "screen_name" : "adams_ea",
      "indices" : [ 0, 9 ],
      "id_str" : "187416164",
      "id" : 187416164
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 30, 44 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351803436804734977",
  "geo" : { },
  "id_str" : "351804343042838530",
  "in_reply_to_user_id" : 187416164,
  "text" : "@adams_ea this is why we have @coworkbuffalo ;)",
  "id" : 351804343042838530,
  "in_reply_to_status_id" : 351803436804734977,
  "created_at" : "2013-07-01 20:47:46 +0000",
  "in_reply_to_screen_name" : "adams_ea",
  "in_reply_to_user_id_str" : "187416164",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351779864841424896",
  "geo" : { },
  "id_str" : "351780773868736514",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Send in $9.95 for your free L. Ron. Hovercraft kit, vacuum not included!",
  "id" : 351780773868736514,
  "in_reply_to_status_id" : 351779864841424896,
  "created_at" : "2013-07-01 19:14:06 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/U1fBUeQnGv",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "351768884405219328",
  "text" : "RT @nickelcityruby: Tickets are still available for NickelCityRuby 2013! We have a great lineup planned!! Get your ticket here: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/U1fBUeQnGv",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "351762861674082304",
    "text" : "Tickets are still available for NickelCityRuby 2013! We have a great lineup planned!! Get your ticket here: http:\/\/t.co\/U1fBUeQnGv",
    "id" : 351762861674082304,
    "created_at" : "2013-07-01 18:02:56 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 351768884405219328,
  "created_at" : "2013-07-01 18:26:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351720473672957953",
  "geo" : { },
  "id_str" : "351723091098996737",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape take off, eh",
  "id" : 351723091098996737,
  "in_reply_to_status_id" : 351720473672957953,
  "created_at" : "2013-07-01 15:24:54 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351714840865280002",
  "geo" : { },
  "id_str" : "351721155079585793",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo it shouldn't be all booked yet. give them a call, if they don't respond we can sort it out on our end.",
  "id" : 351721155079585793,
  "in_reply_to_status_id" : 351714840865280002,
  "created_at" : "2013-07-01 15:17:12 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 38, 48 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/N0xtObFiiI",
      "expanded_url" : "http:\/\/37signals.com\/reportcard",
      "display_url" : "37signals.com\/reportcard"
    } ]
  },
  "geo" : { },
  "id_str" : "351713801835520004",
  "text" : "RT @dhh: Proud of our improvements on @37signals monthly report card: http:\/\/t.co\/N0xtObFiiI. 99.998% uptime, 94% happiness, quicker respon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 29, 39 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/N0xtObFiiI",
        "expanded_url" : "http:\/\/37signals.com\/reportcard",
        "display_url" : "37signals.com\/reportcard"
      } ]
    },
    "geo" : { },
    "id_str" : "351690538463924227",
    "text" : "Proud of our improvements on @37signals monthly report card: http:\/\/t.co\/N0xtObFiiI. 99.998% uptime, 94% happiness, quicker response.",
    "id" : 351690538463924227,
    "created_at" : "2013-07-01 13:15:33 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 351713801835520004,
  "created_at" : "2013-07-01 14:47:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 15, 24 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/80o2X9y6cF",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo\/",
      "display_url" : "openhack.github.io\/buffalo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "351713724995878912",
  "text" : "Buffalo's 20th @OpenHack meetup is tomorrow. That went fast. http:\/\/t.co\/80o2X9y6cF",
  "id" : 351713724995878912,
  "created_at" : "2013-07-01 14:47:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351708680644866048",
  "geo" : { },
  "id_str" : "351713236179095553",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo Not sure! There's spaces in the code IIRC. We can give a call if you're having trouble.",
  "id" : 351713236179095553,
  "in_reply_to_status_id" : 351708680644866048,
  "created_at" : "2013-07-01 14:45:44 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
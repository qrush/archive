Grailbird.data.tweets_2010_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11402558692",
  "text" : "Hotel booked for the Frozen Four in Detroit next week. Woot!",
  "id" : 11402558692,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mildmojo\u2708",
      "screen_name" : "mildmojo",
      "indices" : [ 0, 9 ],
      "id_str" : "16881717",
      "id" : 16881717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11403860492",
  "geo" : { },
  "id_str" : "11404586879",
  "in_reply_to_user_id" : 16881717,
  "text" : "@mildmojo what's being slow for you? let us know at http:\/\/help.rubygems.org",
  "id" : 11404586879,
  "in_reply_to_status_id" : 11403860492,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mildmojo",
  "in_reply_to_user_id_str" : "16881717",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11404753211",
  "geo" : { },
  "id_str" : "11405091644",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza where is that pizza from?",
  "id" : 11405091644,
  "in_reply_to_status_id" : 11404753211,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11422263573",
  "text" : "Line outside the fieldhouse is still huge. What the fuck, RIT",
  "id" : 11422263573,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11422764502",
  "text" : "2 hours after the box office opened and there's still over 100 people in line and people who waited overnight are getting served.",
  "id" : 11422764502,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11422943247",
  "text" : "How do you fuck this up? Have more people come in when there's a rush. NOT HARD.",
  "id" : 11422943247,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11424322202",
  "text" : "Waiting in line with my laptop now. At least RIT wifi works!",
  "id" : 11424322202,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Madsen",
      "screen_name" : "blatyo",
      "indices" : [ 0, 7 ],
      "id_str" : "14188909",
      "id" : 14188909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11432269747",
  "geo" : { },
  "id_str" : "11432461573",
  "in_reply_to_user_id" : 14188909,
  "text" : "@blatyo those were made with http:\/\/github.com\/nakajima\/slidedown I heard http:\/\/github.com\/schacon\/showoff was good too",
  "id" : 11432461573,
  "in_reply_to_status_id" : 11432269747,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "blatyo",
  "in_reply_to_user_id_str" : "14188909",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11336504862",
  "geo" : { },
  "id_str" : "11337394235",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt there's a lot of forks with HAML support but nothing official yet",
  "id" : 11337394235,
  "in_reply_to_status_id" : 11336504862,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11338091669",
  "text" : "DO WANT http:\/\/kotaku.com\/5505087\/advance-wars-the-board-game",
  "id" : 11338091669,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 98, 109 ],
      "id_str" : "20751318",
      "id" : 20751318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11346057709",
  "text" : "Preparing a talk about RIT football (really the lack thereof) for Thursday, then one on Redis for @BarCampRoc on Saturday.",
  "id" : 11346057709,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoptoadapp",
      "screen_name" : "hoptoadapp",
      "indices" : [ 3, 14 ],
      "id_str" : "15689539",
      "id" : 15689539
    }, {
      "name" : "hoptoadapp",
      "screen_name" : "hoptoadapp",
      "indices" : [ 37, 48 ],
      "id_str" : "15689539",
      "id" : 15689539
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 56, 67 ],
      "id_str" : "7255652",
      "id" : 7255652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11367408985",
  "text" : "RT @hoptoadapp: Read about deploying @hoptoadapp to the @engineyard cloud - \"Hopping in the cloud\" http:\/\/bit.ly\/hoptoad-cloud",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hoptoadapp",
        "screen_name" : "hoptoadapp",
        "indices" : [ 21, 32 ],
        "id_str" : "15689539",
        "id" : 15689539
      }, {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 40, 51 ],
        "id_str" : "7255652",
        "id" : 7255652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11367042992",
    "text" : "Read about deploying @hoptoadapp to the @engineyard cloud - \"Hopping in the cloud\" http:\/\/bit.ly\/hoptoad-cloud",
    "id" : 11367042992,
    "created_at" : "2010-03-31 13:47:22 +0000",
    "user" : {
      "name" : "hoptoadapp",
      "screen_name" : "hoptoadapp",
      "protected" : false,
      "id_str" : "15689539",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1566676288\/avatar_4fc31dfc8964_128_normal.png",
      "id" : 15689539,
      "verified" : false
    }
  },
  "id" : 11367408985,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASSR FC 55",
      "screen_name" : "TNM8",
      "indices" : [ 0, 5 ],
      "id_str" : "1448473316",
      "id" : 1448473316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11350015846",
  "geo" : { },
  "id_str" : "11367531301",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm8 it still makes me go \"huh?\" it kind of sucks that it's so hard to explain.",
  "id" : 11367531301,
  "in_reply_to_status_id" : 11350015846,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Neukirchen",
      "screen_name" : "chneukirchen",
      "indices" : [ 0, 13 ],
      "id_str" : "1879351",
      "id" : 1879351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11375735962",
  "geo" : { },
  "id_str" : "11376847867",
  "in_reply_to_user_id" : 1879351,
  "text" : "@chneukirchen that attitude is not why Rack has become a central part of the Ruby\/Rails community. why do you bitch instead of fix?",
  "id" : 11376847867,
  "in_reply_to_status_id" : 11375735962,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "chneukirchen",
  "in_reply_to_user_id_str" : "1879351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11386851445",
  "text" : "\"Your problem with Vim is that you don't grok vi.\" http:\/\/is.gd\/b8MrJ",
  "id" : 11386851445,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11388647559",
  "text" : "WITHSCORES option for Redis ZSETS makes this super easy: Hash[*$redis.zrange(\"key\", 0, -1 \"withscores\")] http:\/\/is.gd\/b8PlO",
  "id" : 11388647559,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 57, 66 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 71, 78 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11392829671",
  "text" : "Our Go programming class got Droids from Google as well, @marcweil and @paco36. They're giving them away like candy!",
  "id" : 11392829671,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Stark",
      "screen_name" : "GavinStark",
      "indices" : [ 0, 11 ],
      "id_str" : "6110222",
      "id" : 6110222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11306790056",
  "geo" : { },
  "id_str" : "11307205947",
  "in_reply_to_user_id" : 6110222,
  "text" : "@gavinstark yes, @jbarnette\/rubygems is what you're looking for",
  "id" : 11307205947,
  "in_reply_to_status_id" : 11306790056,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "GavinStark",
  "in_reply_to_user_id_str" : "6110222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 47, 57 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11308228797",
  "text" : "I really wish I knew about this ahead of time, @neiltyson is coming to UB tomorrow night. http:\/\/is.gd\/b6Fil",
  "id" : 11308228797,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11313322353",
  "geo" : { },
  "id_str" : "11313611378",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker http:\/\/www.youtube.com\/watch?v=bw4uj_ZPHvY",
  "id" : 11313611378,
  "in_reply_to_status_id" : 11313322353,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11317965234",
  "text" : "Really impressed by http:\/\/landingpad.org 's design and logo. Loving the favicon too. http:\/\/is.gd\/b6Uf4",
  "id" : 11317965234,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shadowspar",
      "screen_name" : "shadowspar",
      "indices" : [ 0, 11 ],
      "id_str" : "16892311",
      "id" : 16892311
    }, {
      "name" : "Matt Liggett",
      "screen_name" : "mml",
      "indices" : [ 12, 16 ],
      "id_str" : "820244",
      "id" : 820244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11322179673",
  "geo" : { },
  "id_str" : "11322795255",
  "in_reply_to_user_id" : 16892311,
  "text" : "@shadowspar @mml I'd love to see bug reports\/issues reported at http:\/\/help.rubygems.org if you find them. Thanks :)",
  "id" : 11322795255,
  "in_reply_to_status_id" : 11322179673,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "shadowspar",
  "in_reply_to_user_id_str" : "16892311",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wynn Netherland",
      "screen_name" : "pengwynn",
      "indices" : [ 0, 9 ],
      "id_str" : "14100886",
      "id" : 14100886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11321765532",
  "geo" : { },
  "id_str" : "11323012967",
  "in_reply_to_user_id" : 14100886,
  "text" : "@pengwynn stop checking it into your repo then! if you're using a tool like Jeweler, there's no need anymore since GitHub gems are dead.",
  "id" : 11323012967,
  "in_reply_to_status_id" : 11321765532,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "pengwynn",
  "in_reply_to_user_id_str" : "14100886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11323996318",
  "text" : "Switching between Go, C#, and Ruby on a daily basis means I try to comment using \/\/ instead of # now. Bah.",
  "id" : 11323996318,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Danna",
      "screen_name" : "mattdanna",
      "indices" : [ 0, 10 ],
      "id_str" : "20463300",
      "id" : 20463300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11326209611",
  "geo" : { },
  "id_str" : "11326347953",
  "in_reply_to_user_id" : 20463300,
  "text" : "@mattdanna great news, definitely will be making the trip!",
  "id" : 11326347953,
  "in_reply_to_status_id" : 11326209611,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattdanna",
  "in_reply_to_user_id_str" : "20463300",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Danna",
      "screen_name" : "mattdanna",
      "indices" : [ 0, 10 ],
      "id_str" : "20463300",
      "id" : 20463300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11326517337",
  "geo" : { },
  "id_str" : "11326680815",
  "in_reply_to_user_id" : 20463300,
  "text" : "@mattdanna CRAPPPPPP",
  "id" : 11326680815,
  "in_reply_to_status_id" : 11326517337,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattdanna",
  "in_reply_to_user_id_str" : "20463300",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Dietrich",
      "screen_name" : "JoshDietrich",
      "indices" : [ 0, 13 ],
      "id_str" : "15683572",
      "id" : 15683572
    }, {
      "name" : "Matt Danna",
      "screen_name" : "mattdanna",
      "indices" : [ 14, 24 ],
      "id_str" : "20463300",
      "id" : 20463300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11326642348",
  "geo" : { },
  "id_str" : "11326986357",
  "in_reply_to_user_id" : 15683572,
  "text" : "@JoshDietrich @mattdanna we definitely need to figure how a way out of it. presidential pardon?",
  "id" : 11326986357,
  "in_reply_to_status_id" : 11326642348,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoshDietrich",
  "in_reply_to_user_id_str" : "15683572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bilson",
      "screen_name" : "cbilson",
      "indices" : [ 0, 8 ],
      "id_str" : "721053",
      "id" : 721053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11331562447",
  "geo" : { },
  "id_str" : "11331636416",
  "in_reply_to_user_id" : 721053,
  "text" : "@cbilson they have http clone but it's slower. git clone http:\/\/github.com\/qrush\/gemcutter.git",
  "id" : 11331636416,
  "in_reply_to_status_id" : 11331562447,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "cbilson",
  "in_reply_to_user_id_str" : "721053",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11332851658",
  "text" : "I'm at TC Riley's (200 Park Point Dr, Rochester). http:\/\/4sq.com\/6QibLZ",
  "id" : 11332851658,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "indices" : [ 0, 14 ],
      "id_str" : "5889062",
      "id" : 5889062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11333310187",
  "geo" : { },
  "id_str" : "11335741078",
  "in_reply_to_user_id" : 5889062,
  "text" : "@thetorpedodog I agree. http:\/\/www.reddit.com\/r\/pics\/comments\/bkf29\/i_completely_forgot_homogeneous_equations_between\/",
  "id" : 11335741078,
  "in_reply_to_status_id" : 11333310187,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "thetorpedodog",
  "in_reply_to_user_id_str" : "5889062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11228987911",
  "text" : "Ended up hardcoding a port and assuming incoming connections on that port connect to the test DB. What a sad state of affairs.",
  "id" : 11228987911,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11252018840",
  "text" : "Redis just leveled up: http:\/\/code.google.com\/p\/redis\/wiki\/PublishSubscribe",
  "id" : 11252018840,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11253111338",
  "geo" : { },
  "id_str" : "11253281299",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape ASP.NET MVC doesn't make it easy to swap databases like Rails does, especially for automated tests. script\/server -e test. done.",
  "id" : 11253281299,
  "in_reply_to_status_id" : 11253111338,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11257654850",
  "geo" : { },
  "id_str" : "11258082312",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano not possible. however I am using colloquy's campfire theme to make them look somewhat similar. http:\/\/is.gd\/b5mHv",
  "id" : 11258082312,
  "in_reply_to_status_id" : 11257654850,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11263020347",
  "text" : "Variable\/class\/function names that make no sense make me furious. Code is read more than written, spend some damn time on naming.",
  "id" : 11263020347,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11266819196",
  "text" : "Just got told by a professor that if I was going to write static HTML for an assignment doing mockups, I should go to the IT floor.",
  "id" : 11266819196,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11267908763",
  "text" : "GitHub Rebase #40! http:\/\/github.com\/blog\/623-github-rebase-40 now in HIGH DEFINITION",
  "id" : 11267908763,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordi",
      "screen_name" : "jordibunster",
      "indices" : [ 0, 13 ],
      "id_str" : "1230538363",
      "id" : 1230538363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11267931155",
  "geo" : { },
  "id_str" : "11268040338",
  "in_reply_to_user_id" : 11457022,
  "text" : "@jordibunster our computing college majors are split roughly by floors in our building: SE, CS, IT",
  "id" : 11268040338,
  "in_reply_to_status_id" : 11267931155,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "notlaforge",
  "in_reply_to_user_id_str" : "11457022",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 0, 10 ],
      "id_str" : "651373",
      "id" : 651373
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 41, 52 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11268041886",
  "geo" : { },
  "id_str" : "11268117135",
  "in_reply_to_user_id" : 651373,
  "text" : "@RedWolves oh nice, definitely! I'm sure @shellscape would love to see that :P",
  "id" : 11268117135,
  "in_reply_to_status_id" : 11268041886,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "RedWolves",
  "in_reply_to_user_id_str" : "651373",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11277187503",
  "text" : "iota is kind of blowing my mind right now. http:\/\/golang.org\/doc\/go_spec.html#Iota",
  "id" : 11277187503,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11172744225",
  "text" : "I'm at Brown's Brewing Company (417 River St, Troy). http:\/\/4sq.com\/8hnNYa",
  "id" : 11172744225,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11172369764",
  "geo" : { },
  "id_str" : "11176293590",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen I have, yes, I'm a communication minor....why?",
  "id" : 11176293590,
  "in_reply_to_status_id" : 11172369764,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Donnelly",
      "screen_name" : "dunalar",
      "indices" : [ 8, 16 ],
      "id_str" : "32317282",
      "id" : 32317282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11176356474",
  "text" : "Over at @dunalar's house for the night outside of Troy. Voice fading fast.",
  "id" : 11176356474,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11176573084",
  "text" : "Really would like to figure out if RIT is offering student tickets for the Frozen Four, definitely planning on going to Detroit!",
  "id" : 11176573084,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariejan de Vroom",
      "screen_name" : "ariejan",
      "indices" : [ 0, 8 ],
      "id_str" : "6156112",
      "id" : 6156112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11206567194",
  "geo" : { },
  "id_str" : "11206799706",
  "in_reply_to_user_id" : 6156112,
  "text" : "@ariejan Do you still have gems.github.com in your source list? maybe try removing it or adding -V to your gem installs",
  "id" : 11206799706,
  "in_reply_to_status_id" : 11206567194,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ariejan",
  "in_reply_to_user_id_str" : "6156112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11206836747",
  "text" : "Back at RIT from Albany. Need to figure out the trip to Detroit! Yes, this is the first time in 5 years I get to be a college sports fan.",
  "id" : 11206836747,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11209562608",
  "text" : "Really? config.ConnectionStrings.ConnectionStrings[\"MyConnectionString\"].ConnectionString",
  "id" : 11209562608,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11210575486",
  "text" : "Photo: Possibly the best hockey game I\u2019ve ever been to. (until April 8th!) http:\/\/tumblr.com\/x177xpswk",
  "id" : 11210575486,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11212256193",
  "text" : "I hate ASP.NET and IIS. Completely fucking impossible to set up a local test server that connects to a different database.",
  "id" : 11212256193,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11168141275",
  "text" : "Yep, definitely don't have my voice now. 4-1 Tigers!",
  "id" : 11168141275,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 46, 57 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11172744193",
  "text" : "I just unlocked the \"I'm on a boat!\" badge on @foursquare! http:\/\/4sq.com\/bvusny",
  "id" : 11172744193,
  "created_at" : "2010-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11130692509",
  "text" : "Totally psyched about the RIT hockey game tomorrow. Had to wait 5 years for a shred of school spirit, this is it! http:\/\/is.gd\/b1wAd",
  "id" : 11130692509,
  "created_at" : "2010-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Dumont",
      "screen_name" : "mdumont",
      "indices" : [ 0, 8 ],
      "id_str" : "16463562",
      "id" : 16463562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11142177964",
  "geo" : { },
  "id_str" : "11142237145",
  "in_reply_to_user_id" : 16463562,
  "text" : "@mdumont How bad is it? Just got up and was planning to head down there.",
  "id" : 11142237145,
  "in_reply_to_status_id" : 11142177964,
  "created_at" : "2010-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mdumont",
  "in_reply_to_user_id_str" : "16463562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11162090551",
  "text" : "I'm at Times Union Center (51 S Pearl St, Albany). http:\/\/4sq.com\/9PYwtH",
  "id" : 11162090551,
  "created_at" : "2010-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11162260357",
  "text" : "So many RIT fans here for the game. Going to be awesome.",
  "id" : 11162260357,
  "created_at" : "2010-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11162397071",
  "text" : "UNH fans are getting booed individually as they come up into the line to get in.",
  "id" : 11162397071,
  "created_at" : "2010-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11166529454",
  "text" : "My voice is going to be gone after the 2nd period.",
  "id" : 11166529454,
  "created_at" : "2010-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 39, 48 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11069815444",
  "geo" : { },
  "id_str" : "11070381418",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc I think anyone who's following @rubygems understands the consequences and what it is :) realtime ftw!",
  "id" : 11070381418,
  "in_reply_to_status_id" : 11069815444,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 12, 22 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11077518553",
  "text" : "~18 million @gemcutter downloads aggregated by day, 141 597 600 bytes = 135MB in Redis with no VM settings. Woot!!",
  "id" : 11077518553,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11089535371",
  "geo" : { },
  "id_str" : "11090038320",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape nice! I hope they record the talks.",
  "id" : 11090038320,
  "in_reply_to_status_id" : 11089535371,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 32, 42 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11090049282",
  "text" : "I sense some download graphs in @gemcutter's near future... http:\/\/gist.github.com\/344878",
  "id" : 11090049282,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sela Davis",
      "screen_name" : "sela_davis",
      "indices" : [ 0, 11 ],
      "id_str" : "7488582",
      "id" : 7488582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11089886267",
  "geo" : { },
  "id_str" : "11090527352",
  "in_reply_to_user_id" : 7488582,
  "text" : "@sela_davis tons of great places around Downtown Crossing...Legrassa's, Chacerero...the list goes on and on",
  "id" : 11090527352,
  "in_reply_to_status_id" : 11089886267,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik DeBill",
      "screen_name" : "edebill",
      "indices" : [ 3, 11 ],
      "id_str" : "39057894",
      "id" : 39057894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11093300916",
  "text" : "RT @edebill: Based on 1 week of tracking (not enough) rubygems.org will have more gems than cpan has perl modules in 231 days.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11091572642",
    "text" : "Based on 1 week of tracking (not enough) rubygems.org will have more gems than cpan has perl modules in 231 days.",
    "id" : 11091572642,
    "created_at" : "2010-03-26 14:24:03 +0000",
    "user" : {
      "name" : "Erik DeBill",
      "screen_name" : "edebill",
      "protected" : false,
      "id_str" : "39057894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460062786203029505\/2o0523Uz_normal.jpeg",
      "id" : 39057894,
      "verified" : false
    }
  },
  "id" : 11093300916,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u044D\u0440\u0438 \u0441\u0430\u0430\u043A\u044F\u043D",
      "screen_name" : "ArmMer",
      "indices" : [ 0, 7 ],
      "id_str" : "369604063",
      "id" : 369604063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11100026087",
  "text" : "@armmer That's actually just 1.9 support for Factory Girl, 1.8 (the first huge set of dots) is working fine.",
  "id" : 11100026087,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11102645805",
  "text" : "TRUE and FALSE are global constants in Ruby. Just in case.",
  "id" : 11102645805,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Dietrich",
      "screen_name" : "JoshDietrich",
      "indices" : [ 0, 13 ],
      "id_str" : "15683572",
      "id" : 15683572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11105894224",
  "geo" : { },
  "id_str" : "11106009446",
  "in_reply_to_user_id" : 15683572,
  "text" : "@JoshDietrich http:\/\/streaming.witr.rit.edu:8000\/live.m3u",
  "id" : 11106009446,
  "in_reply_to_status_id" : 11105894224,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoshDietrich",
  "in_reply_to_user_id_str" : "15683572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11110657756",
  "text" : "RIT hockey advances to the elite 8! I'm going to Albany tomorrow to watch the next hockey game!",
  "id" : 11110657756,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11007124613",
  "text" : "I'm at TC Riley's (200 Park Point Dr, Rochester). http:\/\/4sq.com\/6QibLZ",
  "id" : 11007124613,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11006520944",
  "geo" : { },
  "id_str" : "11010265118",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad Development's stopping right now. Fuck! Have you given up? Is this a fucking class? Jesus christ.",
  "id" : 11010265118,
  "in_reply_to_status_id" : 11006520944,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11010576059",
  "text" : "OH: \"The internet stopped!\"",
  "id" : 11010576059,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Holmwood",
      "screen_name" : "auxesis",
      "indices" : [ 0, 8 ],
      "id_str" : "14380900",
      "id" : 14380900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11008403243",
  "geo" : { },
  "id_str" : "11010851852",
  "in_reply_to_user_id" : 14380900,
  "text" : "@auxesis there's the `gem mirror` command...besides that not much.",
  "id" : 11010851852,
  "in_reply_to_status_id" : 11008403243,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "auxesis",
  "in_reply_to_user_id_str" : "14380900",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Holmwood",
      "screen_name" : "auxesis",
      "indices" : [ 0, 8 ],
      "id_str" : "14380900",
      "id" : 14380900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11013089435",
  "geo" : { },
  "id_str" : "11013223576",
  "in_reply_to_user_id" : 14380900,
  "text" : "@auxesis the gems are all on S3, not sure how that would be possible if at all.",
  "id" : 11013223576,
  "in_reply_to_status_id" : 11013089435,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "auxesis",
  "in_reply_to_user_id_str" : "14380900",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11018814382",
  "text" : "YouTube Disco! http:\/\/www.youtube.com\/disco#q=Rush",
  "id" : 11018814382,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Holmwood",
      "screen_name" : "auxesis",
      "indices" : [ 0, 8 ],
      "id_str" : "14380900",
      "id" : 14380900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11014202352",
  "geo" : { },
  "id_str" : "11019253794",
  "in_reply_to_user_id" : 14380900,
  "text" : "@auxesis haven't used Fuse before, hit me up in #gemcutter tomorrow and let's talk about it",
  "id" : 11019253794,
  "in_reply_to_status_id" : 11014202352,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "auxesis",
  "in_reply_to_user_id_str" : "14380900",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11021510637",
  "geo" : { },
  "id_str" : "11021685635",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape grats! I missed jqueryconf, that should be fun though. whats your talk about?",
  "id" : 11021685635,
  "in_reply_to_status_id" : 11021510637,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 118, 127 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11021968289",
  "text" : "Need some postgresql-fu, need to aggregate by date for Downloads (Version has_many downloads): http:\/\/is.gd\/aXYVh \/cc @hgimenez",
  "id" : 11021968289,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11031573657",
  "geo" : { },
  "id_str" : "11032980717",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham that table has nearly 15 million rows, that will take forever",
  "id" : 11032980717,
  "in_reply_to_status_id" : 11031573657,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11030768437",
  "geo" : { },
  "id_str" : "11033062597",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez i'll try that out and let you know, thanks!",
  "id" : 11033062597,
  "in_reply_to_status_id" : 11030768437,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11030768437",
  "geo" : { },
  "id_str" : "11033810360",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez didn't help too much...can't find any good examples of statistics target queries. http:\/\/gist.github.com\/343258#file_optimize?",
  "id" : 11033810360,
  "in_reply_to_status_id" : 11030768437,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 129, 138 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11031573657",
  "geo" : { },
  "id_str" : "11034493676",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham @ra66i I lied, it took ~7 minutes with some better indexes. that'll do great, thanks! http:\/\/gist.github.com\/343564 \/cc @hgimenez",
  "id" : 11034493676,
  "in_reply_to_status_id" : 11031573657,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11033929772",
  "geo" : { },
  "id_str" : "11036521386",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape nice, i don't see your mugshot on http:\/\/events.jquery.org\/2010\/sf-bay-area\/speakers\/ though :)",
  "id" : 11036521386,
  "in_reply_to_status_id" : 11033929772,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11037840235",
  "geo" : { },
  "id_str" : "11037888415",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari definitely planning on doing that as @ablissfulgal and I move to Boston. any suggestions on tools to help?",
  "id" : 11037888415,
  "in_reply_to_status_id" : 11037840235,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Lindsey",
      "screen_name" : "lesmothian",
      "indices" : [ 0, 11 ],
      "id_str" : "17604253",
      "id" : 17604253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11037987440",
  "geo" : { },
  "id_str" : "11038266748",
  "in_reply_to_user_id" : 17604253,
  "text" : "@lesmothian %s\/texttofind\/texttoreplace\/gc",
  "id" : 11038266748,
  "in_reply_to_status_id" : 11037987440,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "lesmothian",
  "in_reply_to_user_id_str" : "17604253",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warwick Poole",
      "screen_name" : "warwickp",
      "indices" : [ 0, 9 ],
      "id_str" : "6668212",
      "id" : 6668212
    }, {
      "name" : "Ezra Zygmuntowicz",
      "screen_name" : "ezmobius",
      "indices" : [ 32, 41 ],
      "id_str" : "3560241",
      "id" : 3560241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11039400637",
  "geo" : { },
  "id_str" : "11039724445",
  "in_reply_to_user_id" : 6668212,
  "text" : "@warwickp it's been merged into @ezmobius' master and pushed out: http:\/\/rubygems.org\/gems\/redis",
  "id" : 11039724445,
  "in_reply_to_status_id" : 11039400637,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "warwickp",
  "in_reply_to_user_id_str" : "6668212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11039955056",
  "text" : "I really do like Chrome, but it doesn't match up to Firefox\/Firebug yet for doing serious HTML\/CSS work.",
  "id" : 11039955056,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11045360704",
  "text" : "\"Will you stop?\" \"I can't, it's funny!\" \"Go to work!\" \"I am at work!\"",
  "id" : 11045360704,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warwick Poole",
      "screen_name" : "warwickp",
      "indices" : [ 0, 9 ],
      "id_str" : "6668212",
      "id" : 6668212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11046464878",
  "geo" : { },
  "id_str" : "11047333647",
  "in_reply_to_user_id" : 6668212,
  "text" : "@warwickp are you running the latest version of Redis? rake redis:install",
  "id" : 11047333647,
  "in_reply_to_status_id" : 11046464878,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "warwickp",
  "in_reply_to_user_id_str" : "6668212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11049832109",
  "text" : "Interesting Build Engineer discussion: http:\/\/is.gd\/aZ6is I love me some Git and CI, but I would hate doing this 40 hrs\/week.",
  "id" : 11049832109,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 43, 52 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11055578114",
  "text" : "Always blown away to see discussions about @gitready pop up. I need to pay more attention to that site :( http:\/\/is.gd\/aZhzV",
  "id" : 11055578114,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "New Relic",
      "screen_name" : "newrelic",
      "indices" : [ 53, 62 ],
      "id_str" : "15527007",
      "id" : 15527007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11055782166",
  "geo" : { },
  "id_str" : "11055997082",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu I'm not seeing any spikes from around ~4 in @newrelic. Without doing gem install blah -V it's hard to debug these issues :\/",
  "id" : 11055997082,
  "in_reply_to_status_id" : 11055782166,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Car",
      "screen_name" : "IamWilhelm",
      "indices" : [ 0, 11 ],
      "id_str" : "497410203",
      "id" : 497410203
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 79, 89 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11057138800",
  "geo" : { },
  "id_str" : "11058603612",
  "in_reply_to_user_id" : 9162442,
  "text" : "@iamwilhelm yeah, i just dont have a lot of time to write on the site anymore, @gemcutter eats it all :) definitely want to revisit it soon",
  "id" : 11058603612,
  "in_reply_to_status_id" : 11057138800,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "iamwil",
  "in_reply_to_user_id_str" : "9162442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 22, 29 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10988591158",
  "text" : "Ha, no, totally broke @github by tagging trees. Off to tender!",
  "id" : 10988591158,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10988664946",
  "text" : "Or maybe tags are broken for everyone. http:\/\/support.github.com\/discussions\/repos\/2771-tags-not-showing-up",
  "id" : 10988664946,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10996215184",
  "text" : "Video: DANGER ZONE http:\/\/tumblr.com\/x177sb25w",
  "id" : 10996215184,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10999084166",
  "text" : "One oversight with gemcutter's redis spec: we order search results by downloads. ...oops",
  "id" : 10999084166,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10999132537",
  "geo" : { },
  "id_str" : "10999441569",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish going to be ditching that branch and moving it into Redis. http:\/\/gist.github.com\/296921",
  "id" : 10999441569,
  "in_reply_to_status_id" : 10999132537,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11000427300",
  "text" : "I want to see a Kitchen Nightmare type blog\/screencast for OSS projects or software dev shops. YOU PUT FUCKING WHAT IN THAT CODE!?",
  "id" : 11000427300,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11001260172",
  "text" : "\"When I translated the C book into german, Ritchie pointed out to me...\" This professor rocks.",
  "id" : 11001260172,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 0, 10 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11005060297",
  "geo" : { },
  "id_str" : "11005205222",
  "in_reply_to_user_id" : 8372122,
  "text" : "@schambers use \"git reset HEAD &lt;file&gt;...\" to unstage (right from the git status output)",
  "id" : 11005205222,
  "in_reply_to_status_id" : 11005060297,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "schambers",
  "in_reply_to_user_id_str" : "8372122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Chinelato",
      "screen_name" : "willchinelato",
      "indices" : [ 0, 14 ],
      "id_str" : "13260542",
      "id" : 13260542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10951299914",
  "geo" : { },
  "id_str" : "10952144947",
  "in_reply_to_user_id" : 13260542,
  "text" : "@willchinelato how or why is that happening? would appreciate it you could spell it all out at http:\/\/help.rubygems.org",
  "id" : 10952144947,
  "in_reply_to_status_id" : 10951299914,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "willchinelato",
  "in_reply_to_user_id_str" : "13260542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10957228810",
  "text" : "Tonight is resume-stuffing night for RIT 5th years. What a poor method of communication.",
  "id" : 10957228810,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10959362943",
  "text" : "OH: \"There's other people in the world named Tammer!\"",
  "id" : 10959362943,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10960153500",
  "geo" : { },
  "id_str" : "10962391857",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey confused...if it's a local branch just check out a new one from the original commit? need more context.",
  "id" : 10962391857,
  "in_reply_to_status_id" : 10960153500,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 0, 7 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10961719672",
  "geo" : { },
  "id_str" : "10962408739",
  "in_reply_to_user_id" : 15198826,
  "text" : "@paco36 now you just need to change http:\/\/www.tomrudick.com\/ to say that :P",
  "id" : 10962408739,
  "in_reply_to_status_id" : 10961719672,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10973616359",
  "geo" : { },
  "id_str" : "10981440091",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey would be easier if i could see gitk :) feel free to email me: nick@quaran.to",
  "id" : 10981440091,
  "in_reply_to_status_id" : 10973616359,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10988012455",
  "text" : "Ah, how I love gitarchive. git archive --format=zip --prefix=ls\/ master:ls\/ &gt; ls.zip",
  "id" : 10988012455,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10988361430",
  "text" : "Also, I had no idea you could git tag trees. Time to see if github archives them!",
  "id" : 10988361430,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10904588810",
  "text" : "HTTP PATCH: http:\/\/tools.ietf.org\/html\/rfc5789",
  "id" : 10904588810,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 76, 86 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Ezra Zygmuntowicz",
      "screen_name" : "ezmobius",
      "indices" : [ 99, 108 ],
      "id_str" : "3560241",
      "id" : 3560241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10910971699",
  "text" : "Polished off hash support in redis-rb tonight, excited to start using it on @gemcutter! (\u21A5 request @ezmobius!)",
  "id" : 10910971699,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Adam",
      "screen_name" : "lazyatom",
      "indices" : [ 0, 9 ],
      "id_str" : "53413",
      "id" : 53413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10924474623",
  "geo" : { },
  "id_str" : "10924679342",
  "in_reply_to_user_id" : 53413,
  "text" : "@lazyatom afaik hoe now marks itself as a development dependency. also, your gem that link only has audio for me, is that normal?",
  "id" : 10924679342,
  "in_reply_to_status_id" : 10924474623,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "lazyatom",
  "in_reply_to_user_id_str" : "53413",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10925477892",
  "text" : "Just run screen from within screen to open a new screen from your current directory. I mean, duh! http:\/\/is.gd\/aUhRJ",
  "id" : 10925477892,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10934460298",
  "text" : "http:\/\/golang.tumblr.com got linked by http:\/\/blog.golang.org\/ woot!",
  "id" : 10934460298,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10939112675",
  "geo" : { },
  "id_str" : "10939427836",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey just wait until you find out about undo branching. or registers. or window splits. or vimscript. or marks.",
  "id" : 10939427836,
  "in_reply_to_status_id" : 10939112675,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10940038155",
  "text" : "Is git commit --amend that hard to emulate in hg? Really? http:\/\/is.gd\/aUG6t",
  "id" : 10940038155,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 3, 12 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10948102953",
  "text" : "RT @rubygems: redis (0.2.0): Ruby client library for redis key value storage server http:\/\/bit.ly\/bOAPqi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10948072834",
    "text" : "redis (0.2.0): Ruby client library for redis key value storage server http:\/\/bit.ly\/bOAPqi",
    "id" : 10948072834,
    "created_at" : "2010-03-23 22:50:06 +0000",
    "user" : {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "protected" : false,
      "id_str" : "14881835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651086638\/rubygems-125x125t_normal.png",
      "id" : 14881835,
      "verified" : false
    }
  },
  "id" : 10948102953,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suss",
      "screen_name" : "suss",
      "indices" : [ 0, 5 ],
      "id_str" : "3468841",
      "id" : 3468841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10949434526",
  "geo" : { },
  "id_str" : "10950082764",
  "in_reply_to_user_id" : 3468841,
  "text" : "@suss what kind of trouble?",
  "id" : 10950082764,
  "in_reply_to_status_id" : 10949434526,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "suss",
  "in_reply_to_user_id_str" : "3468841",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10870473482",
  "geo" : { },
  "id_str" : "10874275478",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer definitely take a look into Go if you haven't yet. I'm enjoying it so far, it's more Lisp than C.",
  "id" : 10874275478,
  "in_reply_to_status_id" : 10870473482,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10883385555",
  "text" : "Fail: Spending all morning making a cheatsheet for your test at 2pm, and then leaving it at home. 8 more weeks of this crap.",
  "id" : 10883385555,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10893312259",
  "text" : "Didn't think I would be doing this today: sudo apt-get install ed",
  "id" : 10893312259,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10895422896",
  "geo" : { },
  "id_str" : "10895475495",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods Rochester, NY?",
  "id" : 10895475495,
  "in_reply_to_status_id" : 10895422896,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabor Ratky",
      "screen_name" : "rgabo",
      "indices" : [ 0, 6 ],
      "id_str" : "8554342",
      "id" : 8554342
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 64, 73 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10766827015",
  "geo" : { },
  "id_str" : "10776620903",
  "in_reply_to_user_id" : 8554342,
  "text" : "@rgabo yeah, last month alone we had 4,300+ pushes, ~150 a day. @rubygems is an active one :)",
  "id" : 10776620903,
  "in_reply_to_status_id" : 10766827015,
  "created_at" : "2010-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "rgabo",
  "in_reply_to_user_id_str" : "8554342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    }, {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 15, 23 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10781153943",
  "geo" : { },
  "id_str" : "10781808898",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein @bphogan yeah, prereleases definitely need help. I'd be up for any suggestions to improve rubygems.org.",
  "id" : 10781808898,
  "in_reply_to_status_id" : 10781153943,
  "created_at" : "2010-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 28, 38 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10784457621",
  "text" : "Looking into optimizing the @gemcutter indexing process with a touch of Redis. http:\/\/gist.github.com\/338815",
  "id" : 10784457621,
  "created_at" : "2010-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10701949677",
  "geo" : { },
  "id_str" : "10702148005",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn yeah, redis.c being 9000+ lines doesn't help either :\/",
  "id" : 10702148005,
  "in_reply_to_status_id" : 10701949677,
  "created_at" : "2010-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10733522114",
  "text" : "Why isn't there a http:\/\/speed.pypy.org\/timeline\/ for Ruby versions?",
  "id" : 10733522114,
  "created_at" : "2010-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10737762045",
  "geo" : { },
  "id_str" : "10737947489",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis bundler should crap out enough output to tell you what's wrong. usually for me it's just export ARCH='i386' or something",
  "id" : 10737947489,
  "in_reply_to_status_id" : 10737762045,
  "created_at" : "2010-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Timson",
      "screen_name" : "rosstimson",
      "indices" : [ 0, 11 ],
      "id_str" : "14096156",
      "id" : 14096156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10671486859",
  "geo" : { },
  "id_str" : "10671708952",
  "in_reply_to_user_id" : 14096156,
  "text" : "@rosstimson can you tack -V on your gem installs? CloudFront has a Europe edge, I'm not sure what is being slow.",
  "id" : 10671708952,
  "in_reply_to_status_id" : 10671486859,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rosstimson",
  "in_reply_to_user_id_str" : "14096156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Timson",
      "screen_name" : "rosstimson",
      "indices" : [ 0, 11 ],
      "id_str" : "14096156",
      "id" : 14096156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10672064819",
  "geo" : { },
  "id_str" : "10672861525",
  "in_reply_to_user_id" : 14096156,
  "text" : "@rosstimson yeah, that's the latest index, has the latest version of every gem....maybe we need to try and push it out to CF. :\/",
  "id" : 10672861525,
  "in_reply_to_status_id" : 10672064819,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rosstimson",
  "in_reply_to_user_id_str" : "14096156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Timson",
      "screen_name" : "rosstimson",
      "indices" : [ 0, 11 ],
      "id_str" : "14096156",
      "id" : 14096156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10672064819",
  "geo" : { },
  "id_str" : "10673481957",
  "in_reply_to_user_id" : 14096156,
  "text" : "@rosstimson just curious, if you `curl` a few times for that URL and for production.cf.rubygems.org (same file name) which is faster?",
  "id" : 10673481957,
  "in_reply_to_status_id" : 10672064819,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rosstimson",
  "in_reply_to_user_id_str" : "14096156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "At Reply",
      "screen_name" : "reply",
      "indices" : [ 32, 38 ],
      "id_str" : "130584275",
      "id" : 130584275
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 120, 126 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10674066714",
  "text" : "RubyGems installs slow for you? @reply  with the results of http:\/\/is.gd\/aNnD0 for you, doing some experiments. (thanks @raggi!)",
  "id" : 10674066714,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10677147836",
  "text" : "Results seem to be mixed, in some cases CloudFront is 10x faster, some S3 is 2x faster....no idea why that's the case.",
  "id" : 10677147836,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10677586910",
  "geo" : { },
  "id_str" : "10678364719",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek not really, even `gem spec -r` grabs the index. i'm up for improving gemcutter's api to help with this.",
  "id" : 10678364719,
  "in_reply_to_status_id" : 10677586910,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10677877706",
  "geo" : { },
  "id_str" : "10678383404",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky yeah internationally CF seems to help, not so much here in the US. definitely not an easy problem.",
  "id" : 10678383404,
  "in_reply_to_status_id" : 10677877706,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Firsthand Web Design",
      "screen_name" : "firsthand",
      "indices" : [ 0, 10 ],
      "id_str" : "363102903",
      "id" : 363102903
    }, {
      "name" : "See @lindsaar",
      "screen_name" : "raasdnil",
      "indices" : [ 74, 83 ],
      "id_str" : "381961794",
      "id" : 381961794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10680789082",
  "geo" : { },
  "id_str" : "10681971446",
  "in_reply_to_user_id" : 3378651,
  "text" : "@firsthand I would love to but the edit form isn't working on their site. @raasdnil any ideas?",
  "id" : 10681971446,
  "in_reply_to_status_id" : 10680789082,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "nicholasjhenry",
  "in_reply_to_user_id_str" : "3378651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Van Fleet",
      "screen_name" : "bigfleet",
      "indices" : [ 0, 9 ],
      "id_str" : "3123671",
      "id" : 3123671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10682588835",
  "geo" : { },
  "id_str" : "10682995923",
  "in_reply_to_user_id" : 3123671,
  "text" : "@bigfleet how is this different than what happened before bundler? Not sure what you're implying here",
  "id" : 10682995923,
  "in_reply_to_status_id" : 10682588835,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "bigfleet",
  "in_reply_to_user_id_str" : "3123671",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Old",
      "screen_name" : "kevinold",
      "indices" : [ 0, 9 ],
      "id_str" : "9823452",
      "id" : 9823452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10600741927",
  "geo" : { },
  "id_str" : "10600798507",
  "in_reply_to_user_id" : 9823452,
  "text" : "@kevinold that I am, but the rest of the team isn't. lots of frustrations.",
  "id" : 10600798507,
  "in_reply_to_status_id" : 10600741927,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevinold",
  "in_reply_to_user_id_str" : "9823452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Toto",
      "screen_name" : "jptoto",
      "indices" : [ 0, 7 ],
      "id_str" : "13733742",
      "id" : 13733742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10600892652",
  "geo" : { },
  "id_str" : "10601279172",
  "in_reply_to_user_id" : 13733742,
  "text" : "@jptoto we just needed a simple job queue that runs background processes. Why is everything with .NET complicated?",
  "id" : 10601279172,
  "in_reply_to_status_id" : 10600892652,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "jptoto",
  "in_reply_to_user_id_str" : "13733742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Toto",
      "screen_name" : "jptoto",
      "indices" : [ 0, 7 ],
      "id_str" : "13733742",
      "id" : 13733742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10600892652",
  "geo" : { },
  "id_str" : "10601382038",
  "in_reply_to_user_id" : 13733742,
  "text" : "@jptoto seriously, we looked at MSMQ, crazy asp.net cache scheduling, background threading, AsyncControllers...what a mess. All of it.",
  "id" : 10601382038,
  "in_reply_to_status_id" : 10600892652,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "jptoto",
  "in_reply_to_user_id_str" : "13733742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10602980775",
  "geo" : { },
  "id_str" : "10603191195",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham i'll take http:\/\/bigassmessage.com\/de92e7996 for $500",
  "id" : 10603191195,
  "in_reply_to_status_id" : 10602980775,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ruscio",
      "screen_name" : "josephruscio",
      "indices" : [ 0, 13 ],
      "id_str" : "18210643",
      "id" : 18210643
    }, {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 14, 24 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10603144439",
  "geo" : { },
  "id_str" : "10603275999",
  "in_reply_to_user_id" : 18210643,
  "text" : "@josephruscio @joedamato that's actually possible? both @ablissfulgal and I could easily trace that back.",
  "id" : 10603275999,
  "in_reply_to_status_id" : 10603144439,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "josephruscio",
  "in_reply_to_user_id_str" : "18210643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10604359474",
  "geo" : { },
  "id_str" : "10604659380",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato thanks for the tip, definitely going to look into it.",
  "id" : 10604659380,
  "in_reply_to_status_id" : 10604359474,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10608220545",
  "text" : "Not cool to send out a homicidal maniac alert at 2am and have no info on http:\/\/emergency.rit.edu\/. Wtf.",
  "id" : 10608220545,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10608274120",
  "text" : "Reddit breaks the news first, as always. http:\/\/www.reddit.com\/r\/rit\/comments\/bedmr\/rit_intruder_alert_possibly_armed_suicidal_person\/",
  "id" : 10608274120,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10608992621",
  "text" : "RIT ALERT\u2026 GO BACK TO BED. OR WORLD OF WARCRAFT.",
  "id" : 10608992621,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10625189650",
  "text" : "Took all morning but figured out ASP.NET model binding and validation with uploading files. What a pain, sealed classes suck.",
  "id" : 10625189650,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "npverni",
      "screen_name" : "npverni",
      "indices" : [ 0, 8 ],
      "id_str" : "4080231",
      "id" : 4080231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10625313287",
  "geo" : { },
  "id_str" : "10625888664",
  "in_reply_to_user_id" : 4080231,
  "text" : "@npverni yep, in asp.net mvc 2 land for my senior project. going slowly crazy.",
  "id" : 10625888664,
  "in_reply_to_status_id" : 10625313287,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "npverni",
  "in_reply_to_user_id_str" : "4080231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10635117649",
  "geo" : { },
  "id_str" : "10635533665",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton congrats! if you end up driving through rochester instead of flying make sure to stop by.",
  "id" : 10635533665,
  "in_reply_to_status_id" : 10635117649,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10642652630",
  "text" : "Go class code review. Extremely depressing.",
  "id" : 10642652630,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10644666630",
  "text" : "Need to really learn that Go is more Lisp\/Scheme than C. Crazy.",
  "id" : 10644666630,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10600096773",
  "text" : "Horrifying delayed_job clone in C# is hobbling along. Tonight's adventure: Learning that XML serialization hates derived classes. Blech.",
  "id" : 10600096773,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10600161104",
  "text" : "Also, I forgot how much I hated SVN and TortoiseSVN, especially with having multiple files out of date within the same tree. Git spoils me.",
  "id" : 10600161104,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Toto",
      "screen_name" : "jptoto",
      "indices" : [ 0, 7 ],
      "id_str" : "13733742",
      "id" : 13733742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10600454281",
  "geo" : { },
  "id_str" : "10600720059",
  "in_reply_to_user_id" : 13733742,
  "text" : "@jptoto \"enterpise\"...ugh. No code samples even? I'm really glad I'm not doing .net anymore full time. Thanks though, I'll look into it.",
  "id" : 10600720059,
  "in_reply_to_status_id" : 10600454281,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "jptoto",
  "in_reply_to_user_id_str" : "13733742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10600778519",
  "text" : "It's about that time RIT! GMail filter: \"Has the words: Student Government\" =&gt; \"Move to Trash\"",
  "id" : 10600778519,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10543074391",
  "text" : "I'm at Five Guys Burgers & Fries (1100 Jefferson Rd, Rochester). http:\/\/4sq.com\/cgW4od",
  "id" : 10543074391,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10555673833",
  "text" : "Got so caught up with C# hacking that I forgot about GitHub Rebase #39! http:\/\/github.com\/blog\/618-github-rebase-39",
  "id" : 10555673833,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 59, 71 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10568209163",
  "text" : "Video: ChatRoulette, with a dude improvising on piano. via @tristandunn http:\/\/tumblr.com\/x177h7fov",
  "id" : 10568209163,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10569762520",
  "text" : "git config --global alias.springclean \"\\!git remote prune origin && git gc\"",
  "id" : 10569762520,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paolo Negri",
      "screen_name" : "hungryblank",
      "indices" : [ 3, 15 ],
      "id_str" : "15383800",
      "id" : 15383800
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 22, 28 ]
    }, {
      "text" : "vmware",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10569862139",
  "text" : "RT @hungryblank: imho #redis isn't a kv store but it's the 21st century malloc and that's why #vmware sponsors it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "redis",
        "indices" : [ 5, 11 ]
      }, {
        "text" : "vmware",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10567984016",
    "text" : "imho #redis isn't a kv store but it's the 21st century malloc and that's why #vmware sponsors it",
    "id" : 10567984016,
    "created_at" : "2010-03-16 12:43:20 +0000",
    "user" : {
      "name" : "Paolo Negri",
      "screen_name" : "hungryblank",
      "protected" : false,
      "id_str" : "15383800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/247056737\/Picture_29_normal.png",
      "id" : 15383800,
      "verified" : false
    }
  },
  "id" : 10569862139,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10576210939",
  "text" : "On some \"art\" in Java's: \"You are a prisoner of my feelings\"",
  "id" : 10576210939,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10582064564",
  "text" : "I can't imagine that one solid product will come out of http:\/\/rit48.com\/, too much focus on businessy crap.",
  "id" : 10582064564,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10583325324",
  "text" : "Queued up a bunch of Redis blog post ideas for Giant Robots. Any suggestions on what I should cover?",
  "id" : 10583325324,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10583723155",
  "geo" : { },
  "id_str" : "10583912240",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith that's definitely a hard question. i wouldn't keep all of my app's data in Redis, it's not suited for everything.",
  "id" : 10583912240,
  "in_reply_to_status_id" : 10583723155,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASSR FC 55",
      "screen_name" : "TNM8",
      "indices" : [ 0, 5 ],
      "id_str" : "1448473316",
      "id" : 1448473316
    }, {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 78, 86 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10583653402",
  "geo" : { },
  "id_str" : "10583934698",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm8 I'v been dying to try out SLAVEOF and ZSETs more. I don't want to steal @antirez's hash thunder though :)",
  "id" : 10583934698,
  "in_reply_to_status_id" : 10583653402,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10583549987",
  "geo" : { },
  "id_str" : "10584029345",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej perhaps hooking into ActionController to do counters on pageviews? that's a little vague.",
  "id" : 10584029345,
  "in_reply_to_status_id" : 10583549987,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10472560604",
  "geo" : { },
  "id_str" : "10494411489",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit Fixed, that was easy.",
  "id" : 10494411489,
  "in_reply_to_status_id" : 10472560604,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10499777033",
  "text" : "I kind of wish http:\/\/xbmc.org\/ wasn't dead.",
  "id" : 10499777033,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Rogish",
      "screen_name" : "MattRogish",
      "indices" : [ 0, 11 ],
      "id_str" : "8866232",
      "id" : 8866232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10519295126",
  "geo" : { },
  "id_str" : "10523115686",
  "in_reply_to_user_id" : 8866232,
  "text" : "@MattRogish what's the problem?",
  "id" : 10523115686,
  "in_reply_to_status_id" : 10519295126,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "MattRogish",
  "in_reply_to_user_id_str" : "8866232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10525311020",
  "text" : "Just read through Rework in 2 hours. Not much new for SvN readers, solidifies why I currently like small companies over big ones.",
  "id" : 10525311020,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10529330050",
  "text" : "Going over how we can fix MyCourses in Usability. Does \"nuke the planet for orbit\" count?",
  "id" : 10529330050,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10531425306",
  "geo" : { },
  "id_str" : "10531505004",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey just like normal vim. %s\/texttofind\/texttoreplace\/gc",
  "id" : 10531505004,
  "in_reply_to_status_id" : 10531425306,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10533880629",
  "geo" : { },
  "id_str" : "10533903898",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza curl?",
  "id" : 10533903898,
  "in_reply_to_status_id" : 10533880629,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10539897285",
  "text" : "regexps in go: http:\/\/golang.tumblr.com\/post\/450853281\/regexp-matchstring (not as nice as ruby, sadface)",
  "id" : 10539897285,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10445275330",
  "text" : "Charlton Heston Dystopia movie night is about to begin. Soylent Green =&gt; The Omega Man =&gt; Planet of the Apes.",
  "id" : 10445275330,
  "created_at" : "2010-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10479449612",
  "text" : "Broke down and bought Rework along with my textbooks.",
  "id" : 10479449612,
  "created_at" : "2010-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10488736210",
  "text" : "I fucking hate bash scripting. That is all.",
  "id" : 10488736210,
  "created_at" : "2010-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10489697271",
  "text" : "Ended up figuring it out, basically asterisks and escaping characters was just maddening.",
  "id" : 10489697271,
  "created_at" : "2010-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 115, 121 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10489928585",
  "text" : "Ended up doing some wacky eval magic to make it work: http:\/\/github.com\/qrush\/go\/blob\/master\/expr\/expr_test#L4 \/cc @chorn",
  "id" : 10489928585,
  "created_at" : "2010-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10403875481",
  "text" : "@infusedx can you try gem update -V ? If it's still slow open an issue at http:\/\/help.rubygems.org with when you tried to run the cmd",
  "id" : 10403875481,
  "created_at" : "2010-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10405239317",
  "text" : "I'm at MacGregors' Grill and Tap Room (300 Jefferson Rd, Rochester). http:\/\/4sq.com\/6hNKyN",
  "id" : 10405239317,
  "created_at" : "2010-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10431322393",
  "geo" : { },
  "id_str" : "10432708083",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy http:\/\/rubygems.org\/pages\/gem_docs#owner",
  "id" : 10432708083,
  "in_reply_to_status_id" : 10431322393,
  "created_at" : "2010-03-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "define",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10440705584",
  "text" : "Today's ASP.NET adventures: Wrote a simple delayed_job clone, learned that #define works, and loading web.config outside the webapp sucks.",
  "id" : 10440705584,
  "created_at" : "2010-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10355098487",
  "text" : "@postgres_tips What the heck is a vacuum analyze?",
  "id" : 10355098487,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10372382954",
  "text" : "Found out that ASP.NET MVC 2 has an AsyncController baked in: http:\/\/msdn.microsoft.com\/en-us\/library\/ee728598(VS.100).aspx",
  "id" : 10372382954,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10372978292",
  "text" : "Kind of wanted to wake up at 7:00 and do c25k, ended up shutting off *all* of my alarms somehow and didn't wake up until 8:45. wtf.",
  "id" : 10372978292,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10378427920",
  "geo" : { },
  "id_str" : "10378498959",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Could that be used for Ruboto? Still dying to write Ruby on my Droid.",
  "id" : 10378498959,
  "in_reply_to_status_id" : 10378427920,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10380080141",
  "text" : "I really hate how Mercurial aborts pushing new branches. I want to create a new remote branch, that's why I'm pushing it!",
  "id" : 10380080141,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.justin.tv\" rel=\"nofollow\"\u003EJustin.tv\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin.tv",
      "screen_name" : "justintv",
      "indices" : [ 19, 28 ],
      "id_str" : "755068",
      "id" : 755068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10381174015",
  "text" : "Watching 'mwrc' on @justintv http:\/\/justin.tv\/s\/01\/wkzR5qw\/mwrc",
  "id" : 10381174015,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosql",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10391616231",
  "text" : "RT @thoughtbot: Learn about Redis, and cheeseburgers. Mostly Redis though. http:\/\/is.gd\/aopy2 #nosql",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nosql",
        "indices" : [ 78, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10391201566",
    "text" : "Learn about Redis, and cheeseburgers. Mostly Redis though. http:\/\/is.gd\/aopy2 #nosql",
    "id" : 10391201566,
    "created_at" : "2010-03-12 21:39:11 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 10391616231,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10395017402",
  "text" : "RIT Hockey playoffs! (@ Frank Ritter Arena) http:\/\/4sq.com\/6IjpwD",
  "id" : 10395017402,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morel cyrille",
      "screen_name" : "parkaboy",
      "indices" : [ 0, 9 ],
      "id_str" : "1245783253",
      "id" : 1245783253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10318108447",
  "geo" : { },
  "id_str" : "10328096712",
  "in_reply_to_user_id" : 11754212,
  "text" : "@parkaboy Definitely is alive here. Maybe some strange network settings on your end?",
  "id" : 10328096712,
  "in_reply_to_status_id" : 10318108447,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "radiospiel",
  "in_reply_to_user_id_str" : "11754212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10327648675",
  "geo" : { },
  "id_str" : "10328153860",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens \"RTM\" makes zero sense with a web app framework, or anything on the web at all. One more reason why I hate looking back at MS.",
  "id" : 10328153860,
  "in_reply_to_status_id" : 10327648675,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10328638263",
  "text" : "The MWRC webcast is jumpy\/buzzy and the NoSQL webcast site doesn't even work. Great day for the internets.",
  "id" : 10328638263,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aur\u00E9lien Malisart",
      "screen_name" : "aurels",
      "indices" : [ 0, 7 ],
      "id_str" : "14598221",
      "id" : 14598221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10329296467",
  "geo" : { },
  "id_str" : "10329370830",
  "in_reply_to_user_id" : 14598221,
  "text" : "@aurels I use jekyll for gitready: http:\/\/github.com\/qrush\/gitready a bit clunky though, probably better ways to share content than branches",
  "id" : 10329370830,
  "in_reply_to_status_id" : 10329296467,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "aurels",
  "in_reply_to_user_id_str" : "14598221",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10329397103",
  "text" : "NoSQL Boston feed actually works! http:\/\/vivu.tv\/portal\/Join?flow=992-839-6148",
  "id" : 10329397103,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aur\u00E9lien Malisart",
      "screen_name" : "aurels",
      "indices" : [ 0, 7 ],
      "id_str" : "14598221",
      "id" : 14598221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10329758133",
  "geo" : { },
  "id_str" : "10329886851",
  "in_reply_to_user_id" : 14598221,
  "text" : "@aurels Yeah, lots. Kind of a pain, not sure how to work around it yet.",
  "id" : 10329886851,
  "in_reply_to_status_id" : 10329758133,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "aurels",
  "in_reply_to_user_id_str" : "14598221",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 11, 24 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10332455789",
  "text" : "Looks like @wayneeseguin is up at MWRC, preaching the good word of RVM! http:\/\/www.justin.tv\/mwrc",
  "id" : 10332455789,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10336345069",
  "geo" : { },
  "id_str" : "10336440454",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh ha, we should have paired on a hg\/git talk. why is this the first i've heard about refresh here?",
  "id" : 10336440454,
  "in_reply_to_status_id" : 10336345069,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10336549114",
  "geo" : { },
  "id_str" : "10336622024",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh good call. would love to give a Redis talk as well, going to be doing one for BarCampRoc.",
  "id" : 10336622024,
  "in_reply_to_status_id" : 10336549114,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10341341819",
  "text" : "Really confused about how to do background processing in ASP.NET. Why isn't it as simple as delayed_job?",
  "id" : 10341341819,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10297012220",
  "geo" : { },
  "id_str" : "10297191876",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck fixing, thanks :) i was too concerned about the trademark",
  "id" : 10297191876,
  "in_reply_to_status_id" : 10297012220,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Miller",
      "screen_name" : "jqr",
      "indices" : [ 0, 4 ],
      "id_str" : "14351457",
      "id" : 14351457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10298883757",
  "geo" : { },
  "id_str" : "10298946987",
  "in_reply_to_user_id" : 14351457,
  "text" : "@jqr open beard close beard?",
  "id" : 10298946987,
  "in_reply_to_status_id" : 10298883757,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "jqr",
  "in_reply_to_user_id_str" : "14351457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10301758013",
  "text" : "Back on Vista tonight doing ASP.NET MVC 2 again for senior project. Trying hard not to freak out and skin\/make it look like OSX.",
  "id" : 10301758013,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 52, 60 ],
      "id_str" : "22682102",
      "id" : 22682102
    }, {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 61, 68 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10301888793",
  "text" : "My new favorite site: http:\/\/bigassmessage.com\/ \/cc @dmansen @paco36",
  "id" : 10301888793,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10305024935",
  "text" : "I love how VisualStudio mangled all of the text I pasted into the Site.Master I'm currently working with. Thanks!",
  "id" : 10305024935,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10306259102",
  "text" : "Only on Windows will reboots make your tests pass.",
  "id" : 10306259102,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10308226544",
  "geo" : { },
  "id_str" : "10308975266",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej because graduation is 3 months away!",
  "id" : 10308975266,
  "in_reply_to_status_id" : 10308226544,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    }, {
      "name" : "Elijah Manor",
      "screen_name" : "elijahmanor",
      "indices" : [ 13, 25 ],
      "id_str" : "9453872",
      "id" : 9453872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10327083601",
  "geo" : { },
  "id_str" : "10327206335",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens @elijahmanor Is that the final 'release' ? The version numbering scheme for this is so stupid. http:\/\/semver.org",
  "id" : 10327206335,
  "in_reply_to_status_id" : 10327083601,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.justin.tv\" rel=\"nofollow\"\u003EJustin.tv\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin.tv",
      "screen_name" : "justintv",
      "indices" : [ 19, 28 ],
      "id_str" : "755068",
      "id" : 755068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10327521715",
  "text" : "Watching 'mwrc' on @justintv http:\/\/justin.tv\/s\/01\/wkzR5qw\/mwrc",
  "id" : 10327521715,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10327581097",
  "text" : "Not cool, the justin.tv chat auto-posts messages to twitter. Why is that enabled by default?!",
  "id" : 10327581097,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10244797033",
  "geo" : { },
  "id_str" : "10244875354",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates I just don't care enough for that level of auto-completion. You could make a macro to do it, simple enough. http:\/\/is.gd\/a58QA",
  "id" : 10244875354,
  "in_reply_to_status_id" : 10244797033,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10244833288",
  "geo" : { },
  "id_str" : "10244899129",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates ah ha, another problem, I never got used to the stupid TextMate shortcuts. They never really made sense, rails.vim does :)",
  "id" : 10244899129,
  "in_reply_to_status_id" : 10244833288,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10245166144",
  "text" : "No way, he did shave his beard during the show. WTF http:\/\/bit.ly\/9IfTlM",
  "id" : 10245166144,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10258231009",
  "text" : "People complain about MacPorts downloading half the internet....CPAN seems worse.",
  "id" : 10258231009,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10260248902",
  "text" : "Finally got Anna installed. What a pain. http:\/\/anna.sourceforge.net",
  "id" : 10260248902,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10285006983",
  "text" : "I love that go's history goes back to 1972: http:\/\/golang.tumblr.com\/",
  "id" : 10285006983,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10287671120",
  "text" : "OH: I've used a REPL but this sir is no REPL",
  "id" : 10287671120,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Neukirchen",
      "screen_name" : "chneukirchen",
      "indices" : [ 0, 13 ],
      "id_str" : "1879351",
      "id" : 1879351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10287747949",
  "geo" : { },
  "id_str" : "10287938099",
  "in_reply_to_user_id" : 1879351,
  "text" : "@chneukirchen You could easily build a system with gem webhooks to bundle them up as tarballs. http:\/\/rubygems.org\/pages\/gem_docs#webhook",
  "id" : 10287938099,
  "in_reply_to_status_id" : 10287747949,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "chneukirchen",
  "in_reply_to_user_id_str" : "1879351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10292468386",
  "text" : "Tooling around with Go's command line parser, flag: http:\/\/golang.tumblr.com\/post\/439732032\/flag",
  "id" : 10292468386,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10294843137",
  "text" : "Finally found a use for git's pre-commit hook: http:\/\/golang.tumblr.com\/post\/439868556\/git-precommit-hook-for-gofmt",
  "id" : 10294843137,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASSR FC 55",
      "screen_name" : "TNM8",
      "indices" : [ 0, 5 ],
      "id_str" : "1448473316",
      "id" : 1448473316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10292561343",
  "geo" : { },
  "id_str" : "10294862534",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm8 We're still just going over how to set up Makefiles and stuff so I'm going on my own tangents here.",
  "id" : 10294862534,
  "in_reply_to_status_id" : 10292561343,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10295062866",
  "geo" : { },
  "id_str" : "10295137484",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck Just getting a handle on it, haven't written much yet, documenting my progress. no complaints so far.",
  "id" : 10295137484,
  "in_reply_to_status_id" : 10295062866,
  "created_at" : "2010-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10195616980",
  "text" : "Started a little site on Go since we need one for class and since there aren't enough yet. http:\/\/golang.tumblr.com\/",
  "id" : 10195616980,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Rosenthal",
      "screen_name" : "caseyrosenthal",
      "indices" : [ 0, 15 ],
      "id_str" : "17850415",
      "id" : 17850415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10197516799",
  "geo" : { },
  "id_str" : "10197805702",
  "in_reply_to_user_id" : 17850415,
  "text" : "@caseyrosenthal School has started back up, I won't be able to make it. Unless if you want to pay for a plane ticket.",
  "id" : 10197805702,
  "in_reply_to_status_id" : 10197516799,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "caseyrosenthal",
  "in_reply_to_user_id_str" : "17850415",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10196125360",
  "geo" : { },
  "id_str" : "10197814699",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith yes, definitely want to use it for assignments",
  "id" : 10197814699,
  "in_reply_to_status_id" : 10196125360,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwrd Ocampo-Gooding",
      "screen_name" : "edwardog",
      "indices" : [ 0, 9 ],
      "id_str" : "14251580",
      "id" : 14251580
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 49, 60 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10199676099",
  "in_reply_to_user_id" : 14251580,
  "text" : "@edwardog Oh man, that's awesome. I want one for @thoughtbot now.",
  "id" : 10199676099,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "edwardog",
  "in_reply_to_user_id_str" : "14251580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwrd Ocampo-Gooding",
      "screen_name" : "edwardog",
      "indices" : [ 0, 9 ],
      "id_str" : "14251580",
      "id" : 14251580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10199973608",
  "geo" : { },
  "id_str" : "10200089564",
  "in_reply_to_user_id" : 14251580,
  "text" : "@edwardog Thanks man! I would love to see incoming errors for Hoptoad flying in, or at least a counter. The support queue is a great idea.",
  "id" : 10200089564,
  "in_reply_to_status_id" : 10199973608,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "edwardog",
  "in_reply_to_user_id_str" : "14251580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10204657360",
  "text" : "Served up GitHub Rebase 38, plenty of great projects: http:\/\/github.com\/blog\/615-github-rebase-38",
  "id" : 10204657360,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bramidi bram",
      "screen_name" : "Bram85",
      "indices" : [ 0, 7 ],
      "id_str" : "2850019224",
      "id" : 2850019224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10204694014",
  "text" : "@bram85 ooh, pinvoke looks neat. will definitely consider for next week's edition.",
  "id" : 10204694014,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10205509118",
  "text" : "New Tron trailer. Zomg. http:\/\/www.hd-trailers.net\/blog\/2010\/03\/08\/tron-legacy-trailer\/",
  "id" : 10205509118,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10225062596",
  "text" : "Am I the only one that doesn't give a crap about MacHeist? That every piece of software in there is worthless to me?",
  "id" : 10225062596,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imagine RIT",
      "screen_name" : "Imagine_RIT",
      "indices" : [ 0, 12 ],
      "id_str" : "18245231",
      "id" : 18245231
    }, {
      "name" : "Dan Leveille",
      "screen_name" : "danlev",
      "indices" : [ 13, 20 ],
      "id_str" : "13612732",
      "id" : 13612732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10229816315",
  "geo" : { },
  "id_str" : "10229879227",
  "in_reply_to_user_id" : 13612732,
  "text" : "@Imagine_RIT @danlev failtiger!",
  "id" : 10229879227,
  "in_reply_to_status_id" : 10229816315,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "danlev",
  "in_reply_to_user_id_str" : "13612732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10231832706",
  "geo" : { },
  "id_str" : "10231870214",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba with or without the DRM servers that died over the weekend? :)",
  "id" : 10231870214,
  "in_reply_to_status_id" : 10231832706,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    }, {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 24, 32 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10244472314",
  "geo" : { },
  "id_str" : "10244592933",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates I don't get it, @rubiety was complaining about this same thing. Are you using the various visual modes at all?",
  "id" : 10244592933,
  "in_reply_to_status_id" : 10244472314,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10178852644",
  "geo" : { },
  "id_str" : "10179936162",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo OH i know, the version of chronic is very old, so it has hoe as a runtime dep, which brings in gemcutter....sigh. http:\/\/is.gd\/9Yfzu",
  "id" : 10179936162,
  "in_reply_to_status_id" : 10178852644,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10180641929",
  "text" : "Finally got my bass back in action, ended up being a dead string.",
  "id" : 10180641929,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10181535208",
  "text" : "Why I'm glad I stopped playing WoW, and any MMO: http:\/\/is.gd\/9YpUi (70 days \/played here)",
  "id" : 10181535208,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10181702421",
  "geo" : { },
  "id_str" : "10181748914",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie grinding programming rep is way more productive",
  "id" : 10181748914,
  "in_reply_to_status_id" : 10181702421,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 54, 61 ],
      "id_str" : "1566201",
      "id" : 1566201
    }, {
      "name" : "Jeff Rafter",
      "screen_name" : "jeffrafter",
      "indices" : [ 63, 74 ],
      "id_str" : "4176991",
      "id" : 4176991
    }, {
      "name" : "Darcy Laycock",
      "screen_name" : "Sutto",
      "indices" : [ 80, 86 ],
      "id_str" : "5099921",
      "id" : 5099921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10181766005",
  "geo" : { },
  "id_str" : "10181862847",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps looks like fun...you may want to talk to @zapnap, @jeffrafter, and @Sutto to see how this year's Rumble went :)",
  "id" : 10181862847,
  "in_reply_to_status_id" : 10181766005,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10182243680",
  "text" : "http:\/\/8bitnyc.com is awesome, I want one for Boston.",
  "id" : 10182243680,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10182218098",
  "geo" : { },
  "id_str" : "10182275387",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez just a crappy Fender Squier Bronco...I need to learn how to play for real before buying a better one.",
  "id" : 10182275387,
  "in_reply_to_status_id" : 10182218098,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10183738263",
  "geo" : { },
  "id_str" : "10183897616",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil OH WTF. WTFFFFFF. I want to do that.",
  "id" : 10183897616,
  "in_reply_to_status_id" : 10183738263,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10184453735",
  "text" : "Usability class, example of bad usability: vim. Difficulty: \"Can't start typing right away\" *facepalm*",
  "id" : 10184453735,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASSR FC 55",
      "screen_name" : "TNM8",
      "indices" : [ 0, 5 ],
      "id_str" : "1448473316",
      "id" : 1448473316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10184514444",
  "geo" : { },
  "id_str" : "10184575777",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm8 close enough, my home software engineering department. there's a reason I'm a CS major as well.",
  "id" : 10184575777,
  "in_reply_to_status_id" : 10184514444,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Martens",
      "screen_name" : "boblmartens",
      "indices" : [ 0, 12 ],
      "id_str" : "14486263",
      "id" : 14486263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10185520284",
  "geo" : { },
  "id_str" : "10185550328",
  "in_reply_to_user_id" : 14486263,
  "text" : "@boblmartens what else do you need besides rack-test \/ cucumber ?",
  "id" : 10185550328,
  "in_reply_to_status_id" : 10185520284,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "boblmartens",
  "in_reply_to_user_id_str" : "14486263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10185506561",
  "geo" : { },
  "id_str" : "10185571030",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly you can't run code on gem installs, you'd have invoke a `pwned` executable or something.",
  "id" : 10185571030,
  "in_reply_to_status_id" : 10185506561,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10189050124",
  "text" : "@adrpac I use vim on a daily basis, it's my editor of choice. I think considering it a 'usability fail' is a little too much.",
  "id" : 10189050124,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10190663517",
  "text" : "git rerere explained. super useful for continually updating\/rebasing branches. http:\/\/progit.org\/2010\/03\/08\/rerere.html",
  "id" : 10190663517,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10192277830",
  "text" : "Taking a Go programming class. Excited and scared.",
  "id" : 10192277830,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BB Calrissian",
      "screen_name" : "mattpodwysocki",
      "indices" : [ 0, 15 ],
      "id_str" : "12699642",
      "id" : 12699642
    }, {
      "name" : "JP Toto",
      "screen_name" : "jptoto",
      "indices" : [ 16, 23 ],
      "id_str" : "13733742",
      "id" : 13733742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10193019757",
  "geo" : { },
  "id_str" : "10193292281",
  "in_reply_to_user_id" : 12699642,
  "text" : "@mattpodwysocki @jptoto I think it's more of a self-learning class, present on stuff you research. still trying to figure it out.",
  "id" : 10193292281,
  "in_reply_to_status_id" : 10193019757,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattpodwysocki",
  "in_reply_to_user_id_str" : "12699642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10149249634",
  "text" : "Trying to get NetBeans working with the Android SDK is a fucking waste of time.",
  "id" : 10149249634,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10156662782",
  "geo" : { },
  "id_str" : "10156950249",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis I'm considering starting that this week too...any tips\/sites to check out?",
  "id" : 10156950249,
  "in_reply_to_status_id" : 10156662782,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Martens",
      "screen_name" : "boblmartens",
      "indices" : [ 0, 12 ],
      "id_str" : "14486263",
      "id" : 14486263
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 13, 19 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10157095856",
  "geo" : { },
  "id_str" : "10157329206",
  "in_reply_to_user_id" : 14486263,
  "text" : "@boblmartens @jamis pfft, I have a droid. you silly iphone people. i'll check it out with http:\/\/www.dailymile.com\/",
  "id" : 10157329206,
  "in_reply_to_status_id" : 10157095856,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "boblmartens",
  "in_reply_to_user_id_str" : "14486263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Blake",
      "screen_name" : "blaix",
      "indices" : [ 0, 6 ],
      "id_str" : "8239892",
      "id" : 8239892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10173020427",
  "geo" : { },
  "id_str" : "10173096425",
  "in_reply_to_user_id" : 8239892,
  "text" : "@blaix That's totally math!",
  "id" : 10173096425,
  "in_reply_to_status_id" : 10173020427,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "blaix",
  "in_reply_to_user_id_str" : "8239892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Blake",
      "screen_name" : "blaix",
      "indices" : [ 0, 6 ],
      "id_str" : "8239892",
      "id" : 8239892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10174023367",
  "geo" : { },
  "id_str" : "10174158035",
  "in_reply_to_user_id" : 8239892,
  "text" : "@blaix supposedly it was his twin brother Seth for the last sketch",
  "id" : 10174158035,
  "in_reply_to_status_id" : 10174023367,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "blaix",
  "in_reply_to_user_id_str" : "8239892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan",
      "screen_name" : "alandipert",
      "indices" : [ 0, 11 ],
      "id_str" : "40270600",
      "id" : 40270600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10176922280",
  "geo" : { },
  "id_str" : "10176999013",
  "in_reply_to_user_id" : 40270600,
  "text" : "@alandipert we should try to get it running on http:\/\/github.com\/qrush\/unix !",
  "id" : 10176999013,
  "in_reply_to_status_id" : 10176922280,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "alandipert",
  "in_reply_to_user_id_str" : "40270600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10178852644",
  "geo" : { },
  "id_str" : "10179903025",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo that doesn't make any sense... why would it install the gemcutter gem? http:\/\/rubygems.org\/gems\/whenever",
  "id" : 10179903025,
  "in_reply_to_status_id" : 10178852644,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10097438220",
  "text" : "They're making a real series out of Adventure Time. RHOMBUS!",
  "id" : 10097438220,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10102421268",
  "text" : "Alice was great, it's like a Burton-esque LoTR. Let the nerd flame war begin!",
  "id" : 10102421268,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10103648806",
  "text" : "Video: It\u2019s hard to express how excited I am for the return of ADVENTURE TIME http:\/\/tumblr.com\/x1774x0a1",
  "id" : 10103648806,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10105905152",
  "text" : "This is the best SNL monologue I've ever seen.",
  "id" : 10105905152,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10106132299",
  "geo" : { },
  "id_str" : "10106242899",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox I think ever. This sketch is killing it too.",
  "id" : 10106242899,
  "in_reply_to_status_id" : 10106132299,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 89, 96 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10108408616",
  "text" : "Did Zack Galifianakis shave off his beard between sketches? That's crazy. Throwing it to @maddox for color commentary!",
  "id" : 10108408616,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10108537268",
  "text" : "And then Zack had his beard back for the goodbye. wtf?",
  "id" : 10108537268,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10110608847",
  "text" : "Gemcutter's validation logic for gem pushes is getting so ridiculously complicated and convoluted. Needs a rework with ActiveModel.",
  "id" : 10110608847,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10134048383",
  "geo" : { },
  "id_str" : "10134088891",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez oooh maybe I should hold off on moving gemcutter downloads over until that's done, didn't know it would be so soon",
  "id" : 10134088891,
  "in_reply_to_status_id" : 10134048383,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10136368342",
  "geo" : { },
  "id_str" : "10136529558",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl but you can't write Ruby still and have it recognized by dalvik. It's neat that JRuby does work though, but it's not there yet.",
  "id" : 10136529558,
  "in_reply_to_status_id" : 10136368342,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10052382657",
  "geo" : { },
  "id_str" : "10052601826",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Where is this new trailer?",
  "id" : 10052601826,
  "in_reply_to_status_id" : 10052382657,
  "created_at" : "2010-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10057963248",
  "text" : "RT @gemcutter: February Changelog and gem yank! http:\/\/is.gd\/9Nhr7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10057946850",
    "text" : "February Changelog and gem yank! http:\/\/is.gd\/9Nhr7",
    "id" : 10057946850,
    "created_at" : "2010-03-06 03:55:48 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 10057963248,
  "created_at" : "2010-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elad Meidar",
      "screen_name" : "eladmeidar",
      "indices" : [ 0, 11 ],
      "id_str" : "16815376",
      "id" : 16815376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10058764470",
  "geo" : { },
  "id_str" : "10058837904",
  "in_reply_to_user_id" : 16815376,
  "text" : "@eladmeidar bundle pack",
  "id" : 10058837904,
  "in_reply_to_status_id" : 10058764470,
  "created_at" : "2010-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "eladmeidar",
  "in_reply_to_user_id_str" : "16815376",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10063123114",
  "text" : "SensorManager.GRAVITY_DEATH_STAR_I =&gt; 3.5303614E-7",
  "id" : 10063123114,
  "created_at" : "2010-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10085498411",
  "geo" : { },
  "id_str" : "10086727006",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove if you don't like AMERICAN_AMERICA.UTF8 you can GEEEEET OUT",
  "id" : 10086727006,
  "in_reply_to_status_id" : 10085498411,
  "created_at" : "2010-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10086770734",
  "text" : "Homemade banana smoothies. Why haven't I done this before.",
  "id" : 10086770734,
  "created_at" : "2010-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9999177842",
  "text" : "Photo: BEAR APPROVED. Taken by @ablissfulgal on our way back to Buffalo today. http:\/\/tumblr.com\/x1772bdz7",
  "id" : 9999177842,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10002543377",
  "text" : "I feel totally out of place in Eclipse...but it helps when stumbling around with syntax checking and code completion.",
  "id" : 10002543377,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10009458584",
  "text" : "After a night of messing around with OpenGL ES on Android, I'm not sure if I should use that or Canvas for a 2D game... http:\/\/is.gd\/9IXR3",
  "id" : 10009458584,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 27, 40 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10036373687",
  "text" : "Arguing gems and more with @wayneeseguin.",
  "id" : 10036373687,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10038292873",
  "text" : "Git over HTTP is actually viable now? Whoa. http:\/\/progit.org\/2010\/03\/04\/smart-http.html",
  "id" : 10038292873,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10041224157",
  "geo" : { },
  "id_str" : "10041300246",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen argh, we need to get username editing in...patches are welcome :(",
  "id" : 10041300246,
  "in_reply_to_status_id" : 10041224157,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9926899770",
  "geo" : { },
  "id_str" : "9951458726",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez yeah, it would be for a game.",
  "id" : 9951458726,
  "in_reply_to_status_id" : 9926899770,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9951510130",
  "text" : "Made it to Ohio...tomorrow morning going near Pittsburgh then back to Buffalo. I'm giving up driving after this.",
  "id" : 9951510130,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemsday",
      "screen_name" : "gemsday",
      "indices" : [ 3, 11 ],
      "id_str" : "96450909",
      "id" : 96450909
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemsday",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9951678612",
  "text" : "RT @gemsday: Your new home for the hottest RubyGems: http:\/\/gemsday.org\/ #gemsday",
  "id" : 9951678612,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9976063555",
  "text" : "iPhone or Android for new game development? http:\/\/news.ycombinator.com\/item?id=1166950",
  "id" : 9976063555,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9989658384",
  "text" : "Back in Buffalo. I'm done driving for another 3 months.",
  "id" : 9989658384,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9991160479",
  "geo" : { },
  "id_str" : "9991331506",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin should be able to now, sorry!",
  "id" : 9991331506,
  "in_reply_to_status_id" : 9991160479,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9993243800",
  "text" : "I think if my cat sneezes one more time near me or on me I'm going to give him some Nyquil.",
  "id" : 9993243800,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9996831385",
  "geo" : { },
  "id_str" : "9997385256",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc my contributions to human society are now complete",
  "id" : 9997385256,
  "in_reply_to_status_id" : 9996831385,
  "created_at" : "2010-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9899571152",
  "geo" : { },
  "id_str" : "9900166461",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates just stop and use the :R commands, or NERDTree.",
  "id" : 9900166461,
  "in_reply_to_status_id" : 9899571152,
  "created_at" : "2010-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9906934268",
  "text" : "Torn if I should look deeper into iPhone or Android 2D game development...and I own a Droid.",
  "id" : 9906934268,
  "created_at" : "2010-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Fallon",
      "screen_name" : "jayfallon",
      "indices" : [ 0, 10 ],
      "id_str" : "814754",
      "id" : 814754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9907053361",
  "geo" : { },
  "id_str" : "9907473816",
  "in_reply_to_user_id" : 814754,
  "text" : "@jayfallon How would one even do that? I just assume that the iPhone market dwarfs the Android market in general.",
  "id" : 9907473816,
  "in_reply_to_status_id" : 9907053361,
  "created_at" : "2010-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayfallon",
  "in_reply_to_user_id_str" : "814754",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9907640414",
  "text" : "This might work...OpenGL ES works on both platforms.",
  "id" : 9907640414,
  "created_at" : "2010-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9884134639",
  "text" : "YouTube needs a Failwhale.",
  "id" : 9884134639,
  "created_at" : "2010-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9886268248",
  "geo" : { },
  "id_str" : "9886475872",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates make sure you're using rails.vim, jferris' vimrc, and maybe my vim-fu. http:\/\/is.gd\/9xRfL http:\/\/github.com\/qrush\/vim-fu",
  "id" : 9886475872,
  "in_reply_to_status_id" : 9886268248,
  "created_at" : "2010-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]